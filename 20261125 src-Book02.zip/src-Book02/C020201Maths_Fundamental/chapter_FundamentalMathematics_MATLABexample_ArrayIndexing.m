%% chapter_FundamentalMathematics_MATLABexample_ArrayIndexing.m
% Comprehensive indexing techniques in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_ArrayIndexing
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_1_2_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates various indexing techniques including
%              subscript, linear, and logical indexing methods.

% Create sample matrix for indexing demonstrations
sampleMatrix = magic(5); % 5*x5 magic square
disp('Original Matrix (5*x5 Magic Square):');
disp(sampleMatrix);

% Subscript indexing: Access specific element
elementAt_2_3 = sampleMatrix(2, 3);
fprintf('Element at position (2,3): %d\n', elementAt_2_3);

% Linear indexing: Access element using single index
% In column-major order, index 7 corresponds to (2,2)
% Calculation: column 1 has indices 1-5, column 2 starts at 6
elementLinear_7 = sampleMatrix(7);
fprintf('7*th element (linear indexing): %d\n', elementLinear_7);

% Verify linear-to-subscript conversion
[rowIdx, colIdx] = ind2sub(size(sampleMatrix), 7);
fprintf('Linear index 7 corresponds to subscript (%d,%d)\n', rowIdx, colIdx);

% Range selection: Extract submatrix
subMatrix2x3 = sampleMatrix(2:3, 1:3);
disp('Submatrix (rows 2-3, columns 1-3):');
disp(subMatrix2x3);

% Colon operator for entire dimensions
thirdColumn = sampleMatrix(:, 3);
disp('Third column (all rows):');
disp(thirdColumn);

secondRow = sampleMatrix(2, :);
disp('Second row (all columns):');
disp(secondRow);

% Using 'end' keyword for dynamic indexing
lastRow = sampleMatrix(end, :);
disp('Last row:');
disp(lastRow);

% Extract all except last column
allButLastColumn = sampleMatrix(:, 1:end-1);
disp('All columns except the last:');
disp(allButLastColumn);

% Logical indexing: Select elements satisfying condition
% Create logical array identifying elements greater than 15
logicalMask = sampleMatrix > 15;
disp('Logical mask (elements > 15):');
disp(logicalMask);

elementsGreaterThan15 = sampleMatrix(logicalMask);
disp('Elements greater than 15 (returned as column vector):');
disp(elementsGreaterThan15);

% Logical indexing for modification: Set elements <= 10 to zero
modifiedMatrix = sampleMatrix;
modifiedMatrix(modifiedMatrix <= 10) = 0;
disp('Matrix after setting elements <= 10 to zero:');
disp(modifiedMatrix);

% Complex logical conditions using multiple criteria
% Select elements between 10 and 20 (inclusive)
complexMask = (sampleMatrix >= 10) & (sampleMatrix <= 20);
elementsBetween10And20 = sampleMatrix(complexMask);
disp('Elements between 10 and 20 (inclusive):');
disp(elementsBetween10And20);

% Demonstrate non-contiguous indexing
selectedIndices = [1, 3, 5];
selectedRows = sampleMatrix(selectedIndices, :);
disp('Rows 1, 3, and 5:');
disp(selectedRows);
