%% chapter_Math_section_Transform_FilterDesign.m
% Comprehensive Digital Filter Design and Analysis in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_section_Transform_FilterDesign
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function demonstrateDigitalFilterDesign()
% Comprehensive Digital Filter Design Demonstration
% Dr Leo Chen - Digital Signal Processing Mathematics
% Illustrates FIR and IIR filter design, analysis, and comparison

% Design specifications
samplingFrequency = 1000;           % Hz
passbandFrequency = 100;            % Hz
stopbandFrequency = 150;            % Hz
passbandRipple = 1;                 % dB
stopbandAttenuation = 60;           % dB

% Design IIR filters using classical methods
designIIRFilters(samplingFrequency, passbandFrequency, ...
    stopbandFrequency, passbandRipple, stopbandAttenuation);

% Design FIR filters using various techniques
designFIRFilters(samplingFrequency, passbandFrequency, ...
    stopbandFrequency, stopbandAttenuation);

% Demonstrate adaptive filtering
demonstrateAdaptiveFiltering(samplingFrequency);

% Compare filter implementations
compareFilterPerformance(samplingFrequency);

end

function designIIRFilters(fs, fp, fst, Rp, Rs)
% Design and analyze IIR filters

% Normalize frequencies
Wp = fp / (fs/2);
Wst = fst / (fs/2);

% Butterworth filter design
[nButterworth, WnButterworth] = buttord(Wp, Wst, Rp, Rs);
[bButterworth, aButterworth] = butter(nButterworth, WnButterworth);

% Chebyshev Type I filter design
[nChebyshev, WnChebyshev] = cheb1ord(Wp, Wst, Rp, Rs);
[bChebyshev, aChebyshev] = cheby1(nChebyshev, Rp, WnChebyshev);

% Elliptic filter design
[nElliptic, WnElliptic] = ellipord(Wp, Wst, Rp, Rs);
[bElliptic, aElliptic] = ellip(nElliptic, Rp, Rs, WnElliptic);

% Frequency response analysis
[hButterworth, w] = freqz(bButterworth, aButterworth, 2048, fs);
[hChebyshev, ~] = freqz(bChebyshev, aChebyshev, 2048, fs);
[hElliptic, ~] = freqz(bElliptic, aElliptic, 2048, fs);

% visualisation
figure('Name', 'IIR Filter Comparison');

% Magnitude response
subplot(2, 2, 1);
plot(w, 20*log10(abs(hButterworth)), 'b-', 'LineWidth', 1.5, ...
     'DisplayName', sprintf('Butterworth (Order %d)', nButterworth));
hold on;
plot(w, 20*log10(abs(hChebyshev)), 'r--', 'LineWidth', 1.5, ...
     'DisplayName', sprintf('Chebyshev I (Order %d)', nChebyshev));
plot(w, 20*log10(abs(hElliptic)), 'g:', 'LineWidth', 2, ...
     'DisplayName', sprintf('Elliptic (Order %d)', nElliptic));
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('Magnitude (dB)', 'Interpreter', 'latex');
title('IIR Filter Magnitude Response', 'Interpreter', 'latex');
legend('Location', 'southwest', 'Interpreter', 'latex');
grid on;
ylim([-80, 5]);

% Phase response
subplot(2, 2, 2);
plot(w, unwrap(angle(hButterworth))*180/pi, 'b-', 'LineWidth', 1.5);
hold on;
plot(w, unwrap(angle(hChebyshev))*180/pi, 'r--', 'LineWidth', 1.5);
plot(w, unwrap(angle(hElliptic))*180/pi, 'g:', 'LineWidth', 2);
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('Phase (degrees)', 'Interpreter', 'latex');
title('IIR Filter Phase Response', 'Interpreter', 'latex');
grid on;

% Pole-zero plot for Butterworth
subplot(2, 2, 3);
zplane(bButterworth, aButterworth);
title('Butterworth Pole-Zero Diagram', 'Interpreter', 'latex');

% Pole-zero plot for Elliptic
subplot(2, 2, 4);
zplane(bElliptic, aElliptic);
title('Elliptic Pole-Zero Diagram', 'Interpreter', 'latex');

end

function designFIRFilters(fs, fp, fst, Rs)
% Design and analyze FIR filters

% Normalized frequencies
Wp = fp / (fs/2);
Wst = fst / (fs/2);

% Window-based design (Hamming)
filterOrder = 100;
idealCutoff = (Wp + Wst) / 2;
bHamming = fir1(filterOrder, idealCutoff, hamming(filterOrder + 1));

% Window-based design (Kaiser)
[nKaiser, Wn, beta, ftype] = kaiserord([fp fst], [1 0], ...
    [10^(-1/20) 10^(-Rs/20)], fs);
bKaiser = fir1(nKaiser, Wn, ftype, kaiser(nKaiser + 1, beta), 'noscale');

% Parks-McClellan (equiripple) design
bParksMcClellan = firpm(filterOrder, [0 Wp Wst 1], [1 1 0 0]);

% Frequency response analysis
[hHamming, w] = freqz(bHamming, 1, 2048, fs);
[hKaiser, ~] = freqz(bKaiser, 1, 2048, fs);
[hParksMcClellan, ~] = freqz(bParksMcClellan, 1, 2048, fs);

% visualisation
figure('Name', 'FIR Filter Comparison');

% Magnitude response
subplot(2, 1, 1);
plot(w, 20*log10(abs(hHamming)), 'b-', 'LineWidth', 1.5, ...
     'DisplayName', sprintf('Hamming (Order %d)', filterOrder));
hold on;
plot(w, 20*log10(abs(hKaiser)), 'r--', 'LineWidth', 1.5, ...
     'DisplayName', sprintf('Kaiser (Order %d)', nKaiser));
plot(w, 20*log10(abs(hParksMcClellan)), 'g:', 'LineWidth', 2, ...
     'DisplayName', sprintf('Parks-McClellan (Order %d)', filterOrder));
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('Magnitude (dB)', 'Interpreter', 'latex');
title('FIR Filter Magnitude Response', 'Interpreter', 'latex');
legend('Location', 'southwest', 'Interpreter', 'latex');
grid on;
ylim([-80, 5]);

% Phase response (demonstrating linear phase)
subplot(2, 1, 2);
plot(w, unwrap(angle(hHamming))*180/pi, 'b-', 'LineWidth', 1.5);
hold on;
plot(w, unwrap(angle(hKaiser))*180/pi, 'r--', 'LineWidth', 1.5);
plot(w, unwrap(angle(hParksMcClellan))*180/pi, 'g:', 'LineWidth', 2);
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('Phase (degrees)', 'Interpreter', 'latex');
title('FIR Filter Phase Response (Linear)', 'Interpreter', 'latex');
grid on;

end

function demonstrateAdaptiveFiltering(fs)
% Demonstrate LMS adaptive filtering for noise cancellation

% Signal generation
duration = 5;
t = 0:1/fs:duration-1/fs;
desiredSignal = sin(2*pi*50*t);              % 50 Hz signal of interest
interferenceSignal = 0.5*sin(2*pi*120*t);    % 120 Hz interference
noisySignal = desiredSignal + interferenceSignal + 0.1*randn(size(t));

% Reference signal (correlated with interference)
referenceSignal = sin(2*pi*120*t + 0.1*randn(size(t)));

% LMS adaptive filter
filterOrder = 32;
stepSize = 0.01;
[filteredSignal, error, weights] = lmsAdaptiveFilter(noisySignal, ...
    referenceSignal, filterOrder, stepSize);

% visualisation
figure('Name', 'Adaptive Filtering (LMS)');

% Signal comparison
subplot(3, 1, 1);
plot(t(1:500), desiredSignal(1:500), 'g-', 'LineWidth', 1.5, ...
     'DisplayName', 'Desired Signal');
hold on;
plot(t(1:500), noisySignal(1:500), 'r:', 'LineWidth', 1, ...
     'DisplayName', 'Noisy Signal');
plot(t(1:500), filteredSignal(1:500), 'b--', 'LineWidth', 1.5, ...
     'DisplayName', 'Filtered Output');
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
title('Adaptive Noise Cancellation', 'Interpreter', 'latex');
legend('Location', 'best', 'Interpreter', 'latex');
grid on;

% Learning curve
subplot(3, 1, 2);
plot(t, error.^2, 'b-', 'LineWidth', 1);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Squared Error', 'Interpreter', 'latex');
title('LMS Convergence (Learning Curve)', 'Interpreter', 'latex');
grid on;

% Weight evolution
subplot(3, 1, 3);
imagesc(t, 1:filterOrder, weights);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Filter Coefficient Index', 'Interpreter', 'latex');
title('Adaptive Filter Weight Evolution', 'Interpreter', 'latex');
colorbar;
colormap('jet');

end

function [y, e, w] = lmsAdaptiveFilter(d, x, M, mu)
% LMS adaptive filter implementation
% d: desired signal
% x: reference input
% M: filter order
% mu: step size

N = length(d);
w = zeros(M, N);           % Weight history
y = zeros(1, N);           % Filter output
e = zeros(1, N);           % Error signal

for n = M:N
    xVec = x(n:-1:n-M+1)';
    y(n) = w(:, n-1)' * xVec;
    e(n) = d(n) - y(n);
    w(:, n) = w(:, n-1) + mu * e(n) * xVec;
end

end

function compareFilterPerformance(fs)
% Compare computational complexity and performance

fprintf('\n=== Digital Filter Performance Comparison ===\n\n');

% Design representative filters
[bIIR, aIIR] = butter(4, 0.2);           % 4*th-order IIR
bFIR = fir1(40, 0.2);                     % 40*th-order FIR

fprintf('IIR Filter (Butterworth, 4*th order):\n');
fprintf('  Number of multiplications per output: %d\n', length(bIIR) + length(aIIR) - 1);
fprintf('  Stability: ');
if max(abs(roots(aIIR))) < 1
    fprintf('Stable\n');
else
    fprintf('Unstable\n');
end
fprintf('  Phase response: Nonlinear\n\n');

fprintf('FIR Filter (Hamming window, 40*th order):\n');
fprintf('  Number of multiplications per output: %d\n', length(bFIR));
fprintf('  Stability: Always stable\n');
fprintf('  Phase response: Linear\n\n');

end
