%% chapter_AI_Mechanics_Problem8_lstm_syntax.m
% LSTM network architecture syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem8_lstm_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define LSTM network for multi-step time series forecasting
% numFeatures: number of input channels (e.g., 8 sensor streams)
% numHiddenUnits: LSTM layer size
% numResponses: number of forecast steps (e.g., 168 for 7-day ahead)

numFeatures = 8;
numHiddenUnits = 128;
numResponses = 168;

layers = [
    sequenceInputLayer(numFeatures, 'Name', 'input')
    
    % First LSTM layer (bidirectional)
    bilstmLayer(numHiddenUnits, 'OutputMode', 'sequence', 'Name', 'bilstm1')
    dropoutLayer(0.2, 'Name', 'dropout1')
    
    % Second LSTM layer
    bilstmLayer(numHiddenUnits, 'OutputMode', 'sequence', 'Name', 'bilstm2')
    dropoutLayer(0.2, 'Name', 'dropout2')
    
    % Attention mechanism (custom layer or manual implementation)
    % For simplicity, using fully connected + softmax
    fullyConnectedLayer(numHiddenUnits, 'Name', 'fc_attention')
    softmaxLayer('Name', 'attention_weights')
    
    % Output layers
    fullyConnectedLayer(numResponses, 'Name', 'fc_output')
    regressionLayer('Name', 'regression')
];

% Training options
options = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'MiniBatchSize', 64, ...
    'InitialLearnRate', 1e-3, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 20, ...
    'LearnRateDropFactor', 0.5, ...
    'ValidationData', {XValidation, YValidation}, ...
    'ValidationFrequency', 50, ...
    'Plots', 'training-progress', ...
    'Verbose', false);
