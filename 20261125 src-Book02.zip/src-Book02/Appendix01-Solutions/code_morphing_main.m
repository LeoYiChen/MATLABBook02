%% code_morphing_main.m
% Main script for active morphing simulation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:morphing_main
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Active Morphing System Simulation
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: 2024
% Description: Simulates 2D membrane morphing under active actuation
% with AI-enhanced optimisation

%% Initialisation
clear; close all; clc;

% Domain parameters
Lx = 1.0;  % Domain width (m)
Ly = 1.0;  % Domain height (m)
Nx = 50;   % Number of nodes in x-direction
Ny = 50;   % Number of nodes in y-direction

% Material properties
youngsModulus = 1e6;     % Young's modulus (Pa)
poissonsRatio = 0.3;     % Poisson's ratio
thickness = 0.01;        % Membrane thickness (m)

% Discretisation
dx = Lx / (Nx - 1);
dy = Ly / (Ny - 1);
[X, Y] = meshgrid(linspace(0, Lx, Nx), linspace(0, Ly, Ny));

% Initial configuration (flat membrane)
U_initial = zeros(Ny, Nx);  % Displacement in z-direction

%% Define Actuation Pattern
% Gaussian actuation centred in the domain
x0 = Lx / 2;  % Centre x-coordinate
y0 = Ly / 2;  % Centre y-coordinate
sigma = 0.15; % Spatial extent of actuation
amplitude = 1e4; % Actuation force amplitude (N/m^2)

F_active = amplitude * exp(-((X - x0).^2 + (Y - y0).^2) / (2 * sigma^2));

%% Compute Morphed Configuration
fprintf('Computing equilibrium configuration...\n');

% Set up optimisation options
options = optimoptions('fminunc', ...
    'Display', 'iter', ...
    'Algorithm', 'quasi-newton', ...
    'MaxIterations', 500, ...
    'OptimalityTolerance', 1e-6);

% Initial guess (vectorised displacement field)
u0 = reshape(U_initial, [], 1);

% Optimise total energy
[u_optimal, energy_min] = fminunc(@(u) computeTotalEnergy(u, X, Y, ...
    F_active, youngsModulus, poissonsRatio, thickness, dx, dy), u0, options);

% Reshape solution
U_final = reshape(u_optimal, Ny, Nx);

fprintf('Minimum energy: %.6e J\n', energy_min);

%% Visualise Results
visualiseMorphing(X, Y, U_initial, U_final, F_active);

%% Discrete Model Comparison
fprintf('\nComparing with discrete spring-mass model...\n');
U_discrete = discreteSpringMassModel(X, Y, F_active, youngsModulus, dx, dy);
compareModels(X, Y, U_final, U_discrete);

%% AI-Enhanced Inverse Design
fprintf('\nPerforming AI-enhanced inverse design...\n');
targetShape = generateTargetShape(X, Y);
[optimalActuation, designHistory] = inverseDesignAI(X, Y, targetShape, ...
    youngsModulus, poissonsRatio, thickness, dx, dy);

fprintf('Inverse design completed successfully.\n');
