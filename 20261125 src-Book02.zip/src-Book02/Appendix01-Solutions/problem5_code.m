%% problem5_code.m
% Multi-Objective Ethical Optimisation for Microgrid EMS
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem5_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Multi-Objective Ethical Optimisation for Microgrid Energy Management
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-17
% Description: Implements NSGA-II multi-objective optimisation balancing
%              economic, environmental, and equity objectives in microgrid dispatch

clear; close all; clc;

%% 1. Microgrid System Definition
fprintf('========================================\n');
fprintf('Multi-Objective Ethical Optimisation - Microgrid EMS\n');
fprintf('========================================\n\n');

fprintf('Step 1: Defining microgrid system parameters...\n');

rng(321); % Reproducibility

% Time horizon
numHours = 24; % One day
timeHours = 1:numHours;

% Microgrid components
pvCapacity = 100; % kW
batteryCapacity = 200; % kWh
batteryEfficiency = 0.9;
batteryInitialSoC = 0.5; % Initial state of charge (50%)
dieselCapacity = 80; % kW
dieselFuelCost = 1.50; % GBP per kWh
dieselEmissions = 0.8; % kg CO2 per kWh
gridEmissions = 0.4; % kg CO2 per kWh (cleaner than diesel)
gridBuyCost = 0.20; % GBP per kWh
gridSellPrice = 0.10; % GBP per kWh (export)

% Household composition
numHouseholds = 50;
incomeQuintiles = [1, 2, 3, 4, 5]; % 1-Lowest, 5-Highest
householdsPerQuintile = 10;

householdIncome = [];
for quintile = incomeQuintiles
    householdIncome = [householdIncome; quintile * ones(householdsPerQuintile, 1)];
end

% Generate hourly demand profiles (income-dependent)
householdDemand = zeros(numHouseholds, numHours);

for householdIdx = 1:numHouseholds
    quintile = householdIncome(householdIdx);
    
    % Base demand increases with income
    baseDemand = 0.5 + 0.3 * quintile; % kW average
    
    % Time-varying profile
    hourOfDay = 1:numHours;
    dailyProfile = 0.4 + 0.3 * exp(-((hourOfDay - 8).^2) / 20) + ...
                   0.4 * exp(-((hourOfDay - 19).^2) / 20);
    
    householdDemand(householdIdx, :) = baseDemand * dailyProfile + ...
                                       0.1 * randn(1, numHours);
    householdDemand(householdIdx, :) = max(householdDemand(householdIdx, :), 0);
end

totalDemand = sum(householdDemand, 1); % Aggregate microgrid demand

% PV generation profile (solar radiation pattern)
pvGeneration = pvCapacity * (0.1 + 0.6 * exp(-((timeHours - 13).^2) / 30));
pvGeneration(timeHours < 6 | timeHours > 20) = 0; % Nighttime

fprintf('Microgrid Configuration:\n');
fprintf('  PV capacity: %d kW\n', pvCapacity);
fprintf('  Battery capacity: %d kWh (efficiency: %.1f%%)\n', ...
        batteryCapacity, batteryEfficiency * 100);
fprintf('  Diesel generator: %d kW (cost: GBP %.2f/kWh, emissions: %.2f kg CO2/kWh)\n', ...
        dieselCapacity, dieselFuelCost, dieselEmissions);
fprintf('  Grid connection: Buy GBP %.2f/kWh, Sell GBP %.2f/kWh\n', ...
        gridBuyCost, gridSellPrice);
fprintf('  Households: %d (across %d income quintiles)\n', ...
        numHouseholds, length(incomeQuintiles));
fprintf('  Total demand range: [%.2f, %.2f] kW\n', min(totalDemand), max(totalDemand));
fprintf('  PV generation range: [%.2f, %.2f] kW\n\n', min(pvGeneration), max(pvGeneration));

%% 2. Objective Function Definition
fprintf('Step 2: Defining multi-objective optimisation problem...\n');

% Decision variables: [batteryCharge(24), batteryDischarge(24), dieselGen(24), 
%                      gridImport(24), gridExport(24), loadCurtailment(50x24)]
% Total: 24 + 24 + 24 + 24 + 24 + 1200 = 1320 variables

% For computational tractability, simplify load curtailment to aggregate per quintile
% Decision variables: [batteryCharge(24), batteryDischarge(24), dieselGen(24),
%                      gridImport(24), gridExport(24), curtailmentQuintile(5x24)]
% Total: 24*5 + 5*24 = 240 variables

numVars = 5 * numHours + numHouseholds * numHours / householdsPerQuintile * numHours;

% Simplified: aggregate curtailment per hour (uniform across households)
% Decision variables: [batteryCharge(24), batteryDischarge(24), dieselGen(24),
%                      gridImport(24), gridExport(24), totalCurtailment(24)]
numVars = 6 * numHours; % 144 variables

fprintf('Objective Functions:\n');
fprintf('  1. Economic: Minimise total cost (diesel fuel + grid purchases - grid sales)\n');
fprintf('  2. Environmental: Minimise CO2 emissions (diesel + grid)\n');
fprintf('  3. Equity: Minimise Gini coefficient of load curtailment across income quintiles\n');
fprintf('Decision Variables: %d (battery charge/discharge, diesel, grid, curtailment)\n\n', numVars);

%% 3. Multi-Objective Genetic Algorithm (Simplified NSGA-II)
fprintf('Step 3: Running multi-objective genetic algorithm...\n');

% Optimisation parameters
populationSize = 100;
numGenerations = 50;
numObjectives = 3;

% Variable bounds
lb = zeros(1, numVars); % Non-negative
ub = [repmat(batteryCapacity/4, 1, numHours), ... % Battery charge limit per hour
      repmat(batteryCapacity/4, 1, numHours), ... % Battery discharge limit
      repmat(dieselCapacity, 1, numHours), ...    % Diesel generation
      repmat(max(totalDemand), 1, numHours), ...  % Grid import
      repmat(max(pvGeneration), 1, numHours), ... % Grid export
      totalDemand]; % Curtailment (max = total demand)

% Objective function handle
objectiveFunc = @(x) evaluateMicrogridObjectives(x, numHours, totalDemand, ...
                pvGeneration, batteryCapacity, batteryEfficiency, batteryInitialSoC, ...
                dieselFuelCost, dieselEmissions, gridBuyCost, gridSellPrice, ...
                gridEmissions, householdDemand, householdIncome, incomeQuintiles);

% Configure multi-objective optimisation
options = optimoptions('gamultiobj', ...
    'PopulationSize', populationSize, ...
    'MaxGenerations', numGenerations, ...
    'Display', 'off', ...
    'PlotFcn', []);

fprintf('Running NSGA-II: Population=%d, Generations=%d\n', populationSize, numGenerations);
fprintf('This may take several minutes...\n');

% Run optimisation
[paretoSolutions, paretoObjectives] = gamultiobj(objectiveFunc, numVars, ...
    [], [], [], [], lb, ub, [], options);

numParetoPoints = size(paretoSolutions, 1);

fprintf('Pareto frontier generated: %d non-dominated solutions\n\n', numParetoPoints);

%% 4. Pareto Frontier Analysis
fprintf('Step 4: Analysing Pareto frontier trade-offs...\n');

% Extract objective values
costObjective = paretoObjectives(:, 1);
emissionsObjective = paretoObjectives(:, 2);
equityObjective = paretoObjectives(:, 3); % Gini coefficient

fprintf('Pareto Frontier Statistics:\n');
fprintf('  Cost range: [GBP %.2f, GBP %.2f]\n', min(costObjective), max(costObjective));
fprintf('  Emissions range: [%.2f kg CO2, %.2f kg CO2]\n', ...
        min(emissionsObjective), max(emissionsObjective));
fprintf('  Equity (Gini) range: [%.4f, %.4f] (0=perfect equality, 1=perfect inequality)\n\n', ...
        min(equityObjective), max(equityObjective));

% Identify extreme solutions
[minCost, minCostIdx] = min(costObjective);
[minEmissions, minEmissionsIdx] = min(emissionsObjective);
[minGini, minGiniIdx] = min(equityObjective);

fprintf('Extreme Pareto Solutions:\n');
fprintf('  Minimum Cost: GBP %.2f, Emissions: %.2f kg CO2, Gini: %.4f\n', ...
        costObjective(minCostIdx), emissionsObjective(minCostIdx), equityObjective(minCostIdx));
fprintf('  Minimum Emissions: GBP %.2f, Emissions: %.2f kg CO2, Gini: %.4f\n', ...
        costObjective(minEmissionsIdx), emissionsObjective(minEmissionsIdx), ...
        equityObjective(minEmissionsIdx));
fprintf('  Minimum Gini (Equity): GBP %.2f, Emissions: %.2f kg CO2, Gini: %.4f\n\n', ...
        costObjective(minGiniIdx), emissionsObjective(minGiniIdx), equityObjective(minGiniIdx));

%% 5. Social Welfare Function Selection
fprintf('Step 5: Applying social welfare functions for solution selection...\n');

% Normalise objectives to [0, 1] for comparable weighting
costNorm = (costObjective - min(costObjective)) / (max(costObjective) - min(costObjective));
emissionsNorm = (emissionsObjective - min(emissionsObjective)) / ...
                (max(emissionsObjective) - min(emissionsObjective));
equityNorm = (equityObjective - min(equityObjective)) / ...
             (max(equityObjective) - min(equityObjective));

% 1. Utilitarian (equal weights, minimise sum)
utilitarianScore = costNorm + emissionsNorm + equityNorm;
[~, utilitarianIdx] = min(utilitarianScore);

fprintf('Social Welfare Solutions:\n');
fprintf('  Utilitarian (equal weights): Cost=GBP %.2f, Emissions=%.2f kg, Gini=%.4f\n', ...
        costObjective(utilitarianIdx), emissionsObjective(utilitarianIdx), ...
        equityObjective(utilitarianIdx));

% 2. Rawlsian (maximise minimum welfare, focus on equity)
% Interpret as minimising worst-case objective
rawlsianScore = max([costNorm, emissionsNorm, equityNorm], [], 2);
[~, rawlsianIdx] = min(rawlsianScore);

fprintf('  Rawlsian (maximin): Cost=GBP %.2f, Emissions=%.2f kg, Gini=%.4f\n', ...
        costObjective(rawlsianIdx), emissionsObjective(rawlsianIdx), ...
        equityObjective(rawlsianIdx));

% 3. Nash Bargaining (maximise product of gains)
% Assume disagreement point = worst objectives
disagreementCost = max(costObjective);
disagreementEmissions = max(emissionsObjective);
disagreementGini = max(equityObjective);

nashProduct = (disagreementCost - costObjective) .* ...
              (disagreementEmissions - emissionsObjective) .* ...
              (disagreementGini - equityObjective);
[~, nashIdx] = max(nashProduct);

fprintf('  Nash Bargaining: Cost=GBP %.2f, Emissions=%.2f kg, Gini=%.4f\n\n', ...
        costObjective(nashIdx), emissionsObjective(nashIdx), equityObjective(nashIdx));

%% 6. Stakeholder Preference Weighting
fprintf('Step 6: Computing stakeholder-weighted solutions...\n');

% Define stakeholder preference profiles
stakeholders = struct();

% Utility operator: prioritise cost
stakeholders(1).name = 'Utility Operator';
stakeholders(1).weights = [0.7, 0.2, 0.1]; % [cost, emissions, equity]

% Environmental advocate: prioritise emissions
stakeholders(2).name = 'Environmental Advocate';
stakeholders(2).weights = [0.1, 0.8, 0.1];

% Social equity organisation: prioritise equity
stakeholders(3).name = 'Social Equity Organisation';
stakeholders(3).weights = [0.1, 0.1, 0.8];

% Balanced stakeholder: equal weights
stakeholders(4).name = 'Balanced Stakeholder';
stakeholders(4).weights = [0.33, 0.33, 0.34];

fprintf('Stakeholder-Weighted Solutions:\n');

for stakeholderIdx = 1:length(stakeholders)
    weights = stakeholders(stakeholderIdx).weights;
    
    % Compute weighted sum
    weightedScore = weights(1) * costNorm + weights(2) * emissionsNorm + ...
                    weights(3) * equityNorm;
    
    [~, selectedIdx] = min(weightedScore);
    
    stakeholders(stakeholderIdx).selectedIdx = selectedIdx;
    stakeholders(stakeholderIdx).cost = costObjective(selectedIdx);
    stakeholders(stakeholderIdx).emissions = emissionsObjective(selectedIdx);
    stakeholders(stakeholderIdx).gini = equityObjective(selectedIdx);
    
    fprintf('  %s (w=[%.2f,%.2f,%.2f]): Cost=GBP %.2f, Emissions=%.2f kg, Gini=%.4f\n', ...
            stakeholders(stakeholderIdx).name, weights(1), weights(2), weights(3), ...
            stakeholders(stakeholderIdx).cost, stakeholders(stakeholderIdx).emissions, ...
            stakeholders(stakeholderIdx).gini);
end

fprintf('\n');

%% 7. Visualisation
fprintf('Step 7: Generating visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: 3D Pareto Frontier
fig1 = figure('Position', [100, 100, 1400, 600]);

subplot(1, 2, 1);
scatter3(costObjective, emissionsObjective, equityObjective, 30, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
scatter3(costObjective(minCostIdx), emissionsObjective(minCostIdx), equityObjective(minCostIdx), ...
         100, 'r', 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 1.5, 'DisplayName', 'Min Cost');
scatter3(costObjective(minEmissionsIdx), emissionsObjective(minEmissionsIdx), equityObjective(minEmissionsIdx), ...
         100, 'g', 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 1.5, 'DisplayName', 'Min Emissions');
scatter3(costObjective(minGiniIdx), emissionsObjective(minGiniIdx), equityObjective(minGiniIdx), ...
         100, 'm', 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 1.5, 'DisplayName', 'Min Gini');
xlabel('Cost (GBP)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Emissions (kg CO$_2$)', 'Interpreter', 'latex', 'FontSize', 11);
zlabel('Equity (Gini)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{3D Pareto Frontier}', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
view(45, 30);

subplot(1, 2, 2);
scatter(costObjective, emissionsObjective, 30, equityObjective, 'filled', 'MarkerFaceAlpha', 0.7);
colorbar;
colormap('jet');
xlabel('Cost (GBP)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Emissions (kg CO$_2$)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Cost-Emissions Trade-off (Coloured by Equity)}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle('\textbf{Multi-Objective Pareto Frontier - Microgrid EMS}', ...
        'Interpreter', 'latex', 'FontSize', 14);

saveas(fig1, 'figures/Problem5_Pareto_Frontier.fig');
saveas(fig1, 'figures/Problem5_Pareto_Frontier.eps', 'epsc');
saveas(fig1, 'figures/Problem5_Pareto_Frontier.jpg');
fprintf('Saved: Problem5_Pareto_Frontier\n');

% Figure 2: Social Welfare Selections
fig2 = figure('Position', [150, 150, 1200, 500]);

selectedIndices = [utilitarianIdx, rawlsianIdx, nashIdx];
selectedNames = {'Utilitarian', 'Rawlsian', 'Nash'};
selectedColors = {'b', 'r', 'g'};

scatter3(costObjective, emissionsObjective, equityObjective, 20, 'k', 'filled', ...
         'MarkerFaceAlpha', 0.2, 'DisplayName', 'Pareto Frontier');
hold on;

for selIdx = 1:length(selectedIndices)
    idx = selectedIndices(selIdx);
    scatter3(costObjective(idx), emissionsObjective(idx), equityObjective(idx), ...
             120, selectedColors{selIdx}, 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 2, ...
             'DisplayName', selectedNames{selIdx});
end

xlabel('Cost (GBP)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Emissions (kg CO$_2$)', 'Interpreter', 'latex', 'FontSize', 11);
zlabel('Equity (Gini)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Social Welfare Function Solutions}', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
view(45, 30);

saveas(fig2, 'figures/Problem5_Social_Welfare.fig');
saveas(fig2, 'figures/Problem5_Social_Welfare.eps', 'epsc');
saveas(fig2, 'figures/Problem5_Social_Welfare.jpg');
fprintf('Saved: Problem5_Social_Welfare\n');

% Figure 3: Stakeholder Preferences
fig3 = figure('Position', [200, 200, 1200, 500]);

scatter3(costObjective, emissionsObjective, equityObjective, 20, 'k', 'filled', ...
         'MarkerFaceAlpha', 0.2, 'DisplayName', 'Pareto Frontier');
hold on;

stakeholderColors = {'b', 'g', 'r', 'm'};
stakeholderMarkers = {'o', 's', 'd', '^'};

for stakeholderIdx = 1:length(stakeholders)
    idx = stakeholders(stakeholderIdx).selectedIdx;
    scatter3(costObjective(idx), emissionsObjective(idx), equityObjective(idx), ...
             120, stakeholderColors{stakeholderIdx}, stakeholderMarkers{stakeholderIdx}, ...
             'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 2, ...
             'DisplayName', stakeholders(stakeholderIdx).name);
end

xlabel('Cost (GBP)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Emissions (kg CO$_2$)', 'Interpreter', 'latex', 'FontSize', 11);
zlabel('Equity (Gini)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Stakeholder-Weighted Solutions}', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'bestoutside');
grid on;
view(45, 30);

saveas(fig3, 'figures/Problem5_Stakeholder_Preferences.fig');
saveas(fig3, 'figures/Problem5_Stakeholder_Preferences.eps', 'epsc');
saveas(fig3, 'figures/Problem5_Stakeholder_Preferences.jpg');
fprintf('Saved: Problem5_Stakeholder_Preferences\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');

%% Helper Function: Evaluate Microgrid Objectives
function objectives = evaluateMicrogridObjectives(x, numHours, totalDemand, ...
    pvGeneration, batteryCapacity, batteryEfficiency, batteryInitialSoC, ...
    dieselFuelCost, dieselEmissions, gridBuyCost, gridSellPrice, gridEmissions, ...
    householdDemand, householdIncome, incomeQuintiles)
    
    % Extract decision variables
    batteryCharge = x(1:numHours);
    batteryDischarge = x(numHours+1:2*numHours);
    dieselGen = x(2*numHours+1:3*numHours);
    gridImport = x(3*numHours+1:4*numHours);
    gridExport = x(4*numHours+1:5*numHours);
    curtailment = x(5*numHours+1:6*numHours);
    
    % Battery state of charge tracking
    batterySoC = zeros(1, numHours + 1);
    batterySoC(1) = batteryInitialSoC * batteryCapacity;
    
    % Initialise objective values
    totalCost = 0;
    totalEmissions = 0;
    
    % Energy balance and cost calculation
    for hour = 1:numHours
        % Battery dynamics
        batterySoC(hour+1) = batterySoC(hour) + ...
                             batteryCharge(hour) * batteryEfficiency - ...
                             batteryDischarge(hour) / batteryEfficiency;
        
        % Enforce battery constraints
        if batterySoC(hour+1) < 0 || batterySoC(hour+1) > batteryCapacity
            objectives = [1e6, 1e6, 1]; % Penalty for infeasibility
            return;
        end
        
        % Energy balance check
        supplyDemandBalance = pvGeneration(hour) + batteryDischarge(hour) + ...
                              dieselGen(hour) + gridImport(hour) - ...
                              batteryCharge(hour) - gridExport(hour) - ...
                              (totalDemand(hour) - curtailment(hour));
        
        % Penalty for energy imbalance
        if abs(supplyDemandBalance) > 0.1
            objectives = [1e6, 1e6, 1];
            return;
        end
        
        % Cost accumulation
        totalCost = totalCost + dieselGen(hour) * dieselFuelCost + ...
                    gridImport(hour) * gridBuyCost - ...
                    gridExport(hour) * gridSellPrice;
        
        % Emissions accumulation
        totalEmissions = totalEmissions + dieselGen(hour) * dieselEmissions + ...
                         gridImport(hour) * gridEmissions;
    end
    
    % Equity calculation (Gini coefficient of curtailment across quintiles)
    curtailmentPerQuintile = zeros(length(incomeQuintiles), 1);
    
    for quintileIdx = 1:length(incomeQuintiles)
        quintile = incomeQuintiles(quintileIdx);
        householdsInQuintile = find(householdIncome == quintile);
        
        % Distribute curtailment proportionally
        quintileDemand = sum(sum(householdDemand(householdsInQuintile, :)));
        totalMicrogridDemand = sum(totalDemand);
        
        curtailmentPerQuintile(quintileIdx) = sum(curtailment) * ...
                                               (quintileDemand / totalMicrogridDemand);
    end
    
    % Gini coefficient calculation
    n = length(curtailmentPerQuintile);
    curtailmentSorted = sort(curtailmentPerQuintile);
    
    if sum(curtailmentSorted) == 0
        giniCoefficient = 0; % Perfect equality (no curtailment)
    else
        cumulativeShare = cumsum(curtailmentSorted) / sum(curtailmentSorted);
        giniCoefficient = 1 - 2 * sum(cumulativeShare) / n + 1 / n;
    end
    
    % Return objectives: [cost, emissions, equity]
    objectives = [totalCost, totalEmissions, giniCoefficient];
end
