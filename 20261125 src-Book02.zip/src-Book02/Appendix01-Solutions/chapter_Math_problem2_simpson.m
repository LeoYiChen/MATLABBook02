%% chapter_Math_problem2_simpson.m
% Simpson's rule implementation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem2_simpson
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Composite Simpson's 1/3 rule
h = (b - a) / n;  % n must be even
x = a:h:b;
y = f(x);
W = (h/3) * (y(1) + 4*sum(y(2:2:end-1)) + ...
              2*sum(y(3:2:end-2)) + y(end));
