%% chapter_FundamentalMathematics_MATLABexample_ColonOperator.m
% Sequence generation using the colon operator.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_ColonOperator
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_1_1_Example03.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates the colon operator for sequence generation
%              in various practical contexts.

% Simple integer sequence with unit increment
integerSequence = 1:10;
disp('Integer sequence from 1 to 10:');
disp(integerSequence);

% Sequence with specified step size
evenNumbers = 2:2:20;
disp('Even numbers from 2 to 20:');
disp(evenNumbers);

% Decreasing sequence using negative step
countdown = 10:-1:1;
disp('Countdown sequence from 10 to 1:');
disp(countdown);

% Fractional step size for fine discretisation
fineGrid = 0:0.1:1;
disp('Fine grid from 0 to 1 with step 0.1:');
disp(fineGrid);

% Comparison with linspace for endpoint inclusion
% The colon operator may not include endpoint if step doesn't align
colonVector = 0:0.3:1;
linspaceVector = linspace(0, 1, 4);
disp('Colon operator (0:0.3:1):');
disp(colonVector);
disp('Linspace equivalent (0 to 1, 4 points):');
disp(linspaceVector);
disp('Note: linspace always includes both endpoints');
