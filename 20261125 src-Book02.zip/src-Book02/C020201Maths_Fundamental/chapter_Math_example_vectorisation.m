%% chapter_Math_example_vectorisation.m
% Vectorisation examples.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_vectorisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Non-vectorised approach (slower)

% Vectorised approach (faster)

% Demonstration
x = rand(1, 1000000);  % One million random numbers

% Time loop version
tic;
y1 = computeSumOfSquaresLoop(x);
time1 = toc;

% Time vectorised version
tic;
y2 = computeSumOfSquaresVectorised(x);
time2 = toc;

fprintf('Loop time: %.6f seconds\n', time1);
fprintf('Vectorised time: %.6f seconds\n', time2);
fprintf('Speedup: %.1fx\n', time1/time2);
% Typical output shows 10-100*x speedup for vectorised version

% Local functions (moved to end so this listing is a valid MATLAB script)
function y = computeSumOfSquaresLoop(x)
    n = length(x);
    y = zeros(size(x));
    for k = 1:n
        y(k) = x(k)^2;
    end
end

function y = computeSumOfSquaresVectorised(x)
    y = x.^2;  % Single element-wise operation
end
