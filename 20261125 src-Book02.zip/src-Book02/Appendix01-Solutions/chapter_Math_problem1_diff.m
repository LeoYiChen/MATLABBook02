%% chapter_Math_problem1_diff.m
% Numerical differentiation using finite differences.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem1_diff
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Forward difference
dydx_forward = (y(2:end) - y(1:end-1)) / dx;

% Backward difference  
dydx_backward = (y(2:end) - y(1:end-1)) / dx;

% Central difference
dydx_central = (y(3:end) - y(1:end-2)) / (2*dx);
