%% chapter_AIforMechatronics_problem10_code.m
% Model compression and edge deployment pipeline.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem10_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 10: Model Compression and Edge Deployment Pipeline
% Author: Dr Yi Chen
% Purpose: Implement model compression for edge deployment
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox, Deep Learning Toolbox Converter
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Load and prepare dataset
fprintf('=== Model Compression and Edge Deployment Pipeline ===\n\n');
fprintf('Step 1: Loading and preparing dataset...\n');

% Use MNIST-like synthetic dataset for demonstration
% In practice, use real datasets: imageDatastore, etc.

imageSize = [28, 28, 1];
numClasses = 10;
numTrainImages = 5000;
numTestImages = 1000;

% Generate synthetic images (normally load real data)
XTrain = rand([imageSize, numTrainImages], 'single');
YTrain = categorical(randi([1, numClasses], numTrainImages, 1));

XTest = rand([imageSize, numTestImages], 'single');
YTest = categorical(randi([1, numClasses], numTestImages, 1));

fprintf('  Training images: %d\n', numTrainImages);
fprintf('  Test images: %d\n', numTestImages);
fprintf('  Image size: [%d, %d, %d]\n', imageSize);
fprintf('  Number of classes: %d\n', numClasses);

%% Step 2: Define and train baseline (teacher) network
fprintf('\nStep 2: Training baseline teacher network...\n');

% Large teacher network
layersTeacher = [
    imageInputLayer(imageSize, 'Name', 'input', 'Normalization', 'none')
    
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    globalAveragePooling2dLayer('Name', 'gap')
    
    fullyConnectedLayer(256, 'Name', 'fc1')
    reluLayer('Name', 'relu_fc')
    dropoutLayer(0.5, 'Name', 'dropout')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc_out')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

optionsTeacher = trainingOptions('adam', ...
    'MaxEpochs', 30, ...
    'MiniBatchSize', 64, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 15, ...
    'LearnRateDropFactor', 0.5, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
netTeacher = trainNetwork(XTrain, YTrain, layersTeacher, optionsTeacher);
trainingTimeTeacher = toc;

% Evaluate teacher
YPredTeacher = classify(netTeacher, XTest);
accuracyTeacher = sum(YPredTeacher == YTest) / numel(YTest);

fprintf('  Teacher training completed in %.2f seconds\n', trainingTimeTeacher);
fprintf('  Teacher accuracy: %.2f%%\n', accuracyTeacher * 100);

%% Step 3: Analyse baseline model size and complexity
fprintf('\nStep 3: Analysing baseline model...\n');

% Count parameters
paramsTeacher = countParameters(layersTeacher);

% Estimate model size (FP32)
modelSizeTeacher_MB = paramsTeacher * 4 / (1024^2); % 4 bytes per FP32

fprintf('  Teacher parameters: %d\n', paramsTeacher);
fprintf('  Teacher model size: %.2f MB (FP32)\n', modelSizeTeacher_MB);

%% Step 4: Implement quantisation (simulated)
fprintf('\nStep 4: Implementing quantisation...\n');

% MATLAB's dlquantizer for actual quantisation
% Here we simulate the effect

% INT8 quantisation reduces size by ~4x (32-bit to 8-bit)
modelSizeQuantised_MB = modelSizeTeacher_MB / 4;

% Typical accuracy degradation: 0.5-2%
accuracyQuantised = accuracyTeacher - 0.01 * (0.5 + 1.5 * rand());

% Speedup: ~2-4x on appropriate hardware
speedupQuantisation = 2.5 + 1.5 * rand();

fprintf('  Quantised model size: %.2f MB (INT8)\n', modelSizeQuantised_MB);
fprintf('  Estimated quantised accuracy: %.2f%%\n', accuracyQuantised * 100);
fprintf('  Estimated speedup: %.2fx\n', speedupQuantisation);
fprintf('  Compression ratio: %.2fx\n', modelSizeTeacher_MB / modelSizeQuantised_MB);

%% Step 5: Implement structured pruning
fprintf('\nStep 5: Implementing structured pruning...\n');

% Simplified pruning: remove filters with smallest L1 norms
% In practice, use analyzeNetworkForPruning, etc.

pruningRatio = 0.5; % Remove 50% of filters

% Simulate pruned model
paramsPruned = round(paramsTeacher * (1 - pruningRatio));
modelSizePruned_MB = paramsPruned * 4 / (1024^2);

% Accuracy degradation from pruning
accuracyPruned = accuracyTeacher - 0.02 * (2 + 3 * rand());

% FLOPs reduction approximately matches parameter reduction
speedupPruning = 1 / (1 - pruningRatio);

fprintf('  Pruning ratio: %.0f%%\n', pruningRatio * 100);
fprintf('  Pruned parameters: %d\n', paramsPruned);
fprintf('  Pruned model size: %.2f MB\n', modelSizePruned_MB);
fprintf('  Estimated pruned accuracy: %.2f%%\n', accuracyPruned * 100);
fprintf('  Estimated speedup: %.2fx\n', speedupPruning);

%% Step 6: Train compact student network (knowledge distillation)
fprintf('\nStep 6: Training student network via knowledge distillation...\n');

% Small student network
layersStudent = [
    imageInputLayer(imageSize, 'Name', 'input', 'Normalization', 'none')
    
    convolution2dLayer(3, 16, 'Padding', 'same', 'Name', 'conv1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    globalAveragePooling2dLayer('Name', 'gap')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc_out')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

% Train student normally (without distillation for simplicity)
% Real distillation uses soft targets from teacher
optionsStudent = trainingOptions('adam', ...
    'MaxEpochs', 30, ...
    'MiniBatchSize', 64, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 15, ...
    'LearnRateDropFactor', 0.5, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
netStudent = trainNetwork(XTrain, YTrain, layersStudent, optionsStudent);
trainingTimeStudent = toc;

% Evaluate student
YPredStudent = classify(netStudent, XTest);
accuracyStudent = sum(YPredStudent == YTest) / numel(YTest);

% Analyse student size
paramsStudent = countParameters(layersStudent);
modelSizeStudent_MB = paramsStudent * 4 / (1024^2);

compressionRatioStudent = paramsTeacher / paramsStudent;

fprintf('  Student training completed in %.2f seconds\n', trainingTimeStudent);
fprintf('  Student accuracy: %.2f%%\n', accuracyStudent * 100);
fprintf('  Student parameters: %d\n', paramsStudent);
fprintf('  Student model size: %.2f MB\n', modelSizeStudent_MB);
fprintf('  Compression ratio: %.2fx\n', compressionRatioStudent);

%% Step 7: Combined compression (student + quantisation)
fprintf('\nStep 7: Applying combined compression...\n');

% Student network + INT8 quantisation
modelSizeStudentQuant_MB = modelSizeStudent_MB / 4;
accuracyStudentQuant = accuracyStudent - 0.01 * (0.5 + rand());

totalCompressionRatio = modelSizeTeacher_MB / modelSizeStudentQuant_MB;
accuracyDrop = (accuracyTeacher - accuracyStudentQuant) * 100;

fprintf('  Combined compressed size: %.2f MB\n', modelSizeStudentQuant_MB);
fprintf('  Combined accuracy: %.2f%%\n', accuracyStudentQuant * 100);
fprintf('  Total compression ratio: %.2fx\n', totalCompressionRatio);
fprintf('  Accuracy degradation: %.2f%%\n', accuracyDrop);

%% Step 8: Inference speed benchmarking
fprintf('\nStep 8: Benchmarking inference speed...\n');

numRuns = 100;

% Teacher inference timing
inferenceTimesTeacher = zeros(numRuns, 1);
for runIdx = 1:numRuns
    sampleImage = XTest(:, :, :, randi(numTestImages));
    tic;
    classify(netTeacher, sampleImage);
    inferenceTimesTeacher(runIdx) = toc * 1000; % ms
end

% Student inference timing
inferenceTimesStudent = zeros(numRuns, 1);
for runIdx = 1:numRuns
    sampleImage = XTest(:, :, :, randi(numTestImages));
    tic;
    classify(netStudent, sampleImage);
    inferenceTimesStudent(runIdx) = toc * 1000; % ms
end

avgInferenceTeacher = mean(inferenceTimesTeacher);
avgInferenceStudent = mean(inferenceTimesStudent);
speedupStudent = avgInferenceTeacher / avgInferenceStudent;

% Quantised student (simulated additional 2-3x speedup)
avgInferenceStudentQuant = avgInferenceStudent / (2 + rand());
totalSpeedup = avgInferenceTeacher / avgInferenceStudentQuant;

fprintf('  Teacher inference: %.2f ms\n', avgInferenceTeacher);
fprintf('  Student inference: %.2f ms (%.2fx faster)\n', ...
    avgInferenceStudent, speedupStudent);
fprintf('  Student+Quant inference: %.2f ms (%.2fx faster)\n', ...
    avgInferenceStudentQuant, totalSpeedup);

%% Step 9: Edge deployment simulation
fprintf('\nStep 9: Simulating edge deployment constraints...\n');

% Define edge device constraints
edgeMemoryLimit_MB = 2.0; % 2 MB model size limit
edgeLatencyLimit_ms = 50; % 50 ms inference time limit
edgeEnergyBudget_mJ = 100; % 100 mJ per inference

% Check teacher network
teacherFitsMemory = modelSizeTeacher_MB <= edgeMemoryLimit_MB;
teacherMeetsLatency = avgInferenceTeacher <= edgeLatencyLimit_ms;

% Check student network
studentFitsMemory = modelSizeStudent_MB <= edgeMemoryLimit_MB;
studentMeetsLatency = avgInferenceStudent <= edgeLatencyLimit_ms;

% Check compressed student
compressedFitsMemory = modelSizeStudentQuant_MB <= edgeMemoryLimit_MB;
compressedMeetsLatency = avgInferenceStudentQuant <= edgeLatencyLimit_ms;

fprintf('  Edge constraints: Memory   %.1f MB, Latency   %.0f ms\n', ...
    edgeMemoryLimit_MB, edgeLatencyLimit_ms);
fprintf('\n  Teacher network:\n');
fprintf('    Memory: %.2f MB [%s]\n', modelSizeTeacher_MB, ...
    statusString(teacherFitsMemory));
fprintf('    Latency: %.2f ms [%s]\n', avgInferenceTeacher, ...
    statusString(teacherMeetsLatency));

fprintf('\n  Student network:\n');
fprintf('    Memory: %.2f MB [%s]\n', modelSizeStudent_MB, ...
    statusString(studentFitsMemory));
fprintf('    Latency: %.2f ms [%s]\n', avgInferenceStudent, ...
    statusString(studentMeetsLatency));

fprintf('\n  Compressed student:\n');
fprintf('    Memory: %.2f MB [%s]\n', modelSizeStudentQuant_MB, ...
    statusString(compressedFitsMemory));
fprintf('    Latency: %.2f ms [%s]\n', avgInferenceStudentQuant, ...
    statusString(compressedMeetsLatency));

% Energy estimation (proportional to FLOPs and latency)
energyTeacher = avgInferenceTeacher * 2.5; % Simplified model
energyStudent = avgInferenceStudent * 2.5;
energyCompressed = avgInferenceStudentQuant * 2.5;

fprintf('\n  Estimated energy consumption:\n');
fprintf('    Teacher: %.1f mJ\n', energyTeacher);
fprintf('    Student: %.1f mJ\n', energyStudent);
fprintf('    Compressed: %.1f mJ [%s]\n', energyCompressed, ...
    statusString(energyCompressed <= edgeEnergyBudget_mJ));

%% Step 10: Visualisation
fprintf('\nStep 10: Generating comparison visualisations...\n');

figure('Name', 'Model Compression Analysis', ...
    'Position', [100, 100, 1400, 900]);

% Model size comparison
subplot(2, 3, 1);
modelNames = {'Teacher', 'Quantised', 'Pruned', 'Student', 'Student+Quant'};
modelSizes = [modelSizeTeacher_MB, modelSizeQuantised_MB, ...
    modelSizePruned_MB, modelSizeStudent_MB, modelSizeStudentQuant_MB];
bar(modelSizes);
hold on;
yline(edgeMemoryLimit_MB, 'r-', 'LineWidth', 2, 'DisplayName', 'Edge Limit');
set(gca, 'XTickLabel', modelNames);
ylabel('Model Size (MB)', 'Interpreter', 'latex');
title('Model Size Comparison', 'Interpreter', 'latex');
xtickangle(45);
legend('Interpreter', 'latex');
grid on;
hold off;

% Accuracy comparison
subplot(2, 3, 2);
accuracies = [accuracyTeacher, accuracyQuantised, ...
    accuracyPruned, accuracyStudent, accuracyStudentQuant] * 100;
bar(accuracies);
set(gca, 'XTickLabel', modelNames);
ylabel('Accuracy (\%)', 'Interpreter', 'latex');
title('Accuracy Comparison', 'Interpreter', 'latex');
ylim([min(accuracies)-5, 100]);
xtickangle(45);
grid on;

% Inference speed comparison
subplot(2, 3, 3);
inferenceTimes = [avgInferenceTeacher, avgInferenceTeacher/speedupQuantisation, ...
    avgInferenceTeacher/speedupPruning, avgInferenceStudent, avgInferenceStudentQuant];
bar(inferenceTimes);
hold on;
yline(edgeLatencyLimit_ms, 'r-', 'LineWidth', 2, 'DisplayName', 'Edge Limit');
set(gca, 'XTickLabel', modelNames);
ylabel('Inference Time (ms)', 'Interpreter', 'latex');
title('Inference Speed Comparison', 'Interpreter', 'latex');
xtickangle(45);
legend('Interpreter', 'latex');
grid on;
hold off;

% Compression ratio vs accuracy trade-off
subplot(2, 3, 4);
compressionRatios = modelSizeTeacher_MB ./ modelSizes;
scatter(compressionRatios, accuracies, 200, 'filled');
for idx = 1:length(modelNames)
    text(compressionRatios(idx) + 0.5, accuracies(idx), ...
        modelNames{idx}, 'Interpreter', 'latex', 'FontSize', 9);
end
xlabel('Compression Ratio', 'Interpreter', 'latex');
ylabel('Accuracy (\%)', 'Interpreter', 'latex');
title('Compression-Accuracy Trade-off', 'Interpreter', 'latex');
grid on;

% Parameter count comparison
subplot(2, 3, 5);
paramCounts = [paramsTeacher, paramsTeacher, paramsPruned, paramsStudent, paramsStudent];
bar(log10(paramCounts));
set(gca, 'XTickLabel', modelNames);
ylabel('$\log_{10}$(Parameters)', 'Interpreter', 'latex');
title('Model Complexity', 'Interpreter', 'latex');
xtickangle(45);
grid on;

% Pareto frontier: Size vs Accuracy
subplot(2, 3, 6);
plot(modelSizes, accuracies, 'bo-', 'LineWidth', 2, 'MarkerSize', 10, ...
    'MarkerFaceColor', 'b');
hold on;
xline(edgeMemoryLimit_MB, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Memory Limit');
xlabel('Model Size (MB)', 'Interpreter', 'latex');
ylabel('Accuracy (\%)', 'Interpreter', 'latex');
title('Pareto Frontier', 'Interpreter', 'latex');
legend('Interpreter', 'latex');
grid on;
hold off;

suptitle('Model Compression for Edge Deployment', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 10 completed successfully.\n');

%% Helper Functions

function numParams = countParameters(layers)
    % Count total number of trainable parameters
    numParams = 0;
    for i = 1:length(layers)
        if isprop(layers(i), 'Weights')
            if ~isempty(layers(i).Weights)
                numParams = numParams + numel(layers(i).Weights);
            end
        end
        if isprop(layers(i), 'Bias')
            if ~isempty(layers(i).Bias)
                numParams = numParams + numel(layers(i).Bias);
            end
        end
    end
end

function str = statusString(passes)
    % Return pass/fail status string
    if passes
        str = 'PASS';
    else
        str = 'FAIL';
    end
end
