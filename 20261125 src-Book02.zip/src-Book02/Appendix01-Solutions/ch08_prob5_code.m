%% ch08_prob5_code.m
% Transfer learning with imageDatastore (MATLABBook02_Chapter08_Problem5.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob5_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem5.m
% --------------------------------
% Purpose : Deep-learning image classification via transfer learning.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later; Deep Learning Toolbox required
% --------------------------------
clc; clear; close all;

%% Step 1 – Generate synthetic image dataset
fprintf('=== Step 1: Generating synthetic image dataset ===\n');
baseFolder  = fullfile(pwd, 'SyntheticImageData');
classNames  = {'ClassA', 'ClassB', 'ClassC'};
numClasses  = numel(classNames);
imagesPerClass = 200;   % Increase for more robust training
imageSize   = [224 224 3];

for classIdx = 1:numClasses
    classFolder = fullfile(baseFolder, classNames{classIdx});
    if ~isfolder(classFolder), mkdir(classFolder); end
    for imgIdx = 1:imagesPerClass
        syntheticImage = uint8(randi([0 255], imageSize));
        % Add class-specific pattern for learnability
        patternOffset = classIdx * 60;
        syntheticImage(:,:,classIdx) = ...
            syntheticImage(:,:,classIdx) + uint8(patternOffset);
        fileName = fullfile(classFolder, ...
            sprintf('img_%04d.jpg', imgIdx));
        imwrite(syntheticImage, fileName);
    end
    fprintf('  Created %d images in %s\n', imagesPerClass, ...
        classNames{classIdx});
end

%% Step 2 – Create imageDatastore
fprintf('\n=== Step 2: Creating imageDatastore ===\n');
imageDS = imageDatastore(baseFolder, ...
    'IncludeSubfolders', true, ...
    'LabelSource',       'foldernames');
fprintf('  Total images: %d\n', numel(imageDS.Files));
fprintf('  Classes: %s\n', strjoin(classNames, ', '));

%% Step 3 – Split into train / validation / test
[trainDS, valDS, testDS] = splitEachLabel(imageDS, 0.7, 0.15, 0.15, ...
    'randomized');
fprintf('  Training: %d | Validation: %d | Test: %d\n', ...
    numel(trainDS.Files), numel(valDS.Files), numel(testDS.Files));

%% Step 4 – Load pre-trained network and modify layers
fprintf('\n=== Step 4: Modifying resnet18 ===\n');
baseNetwork = resnet18;
layerGraph  = layerGraph(baseNetwork);

% Replace final FC and classification layers
numOriginalFC = baseNetwork.Layers(end-2).OutputSize;
newFCLayer    = fullyConnectedLayer(numClasses, 'Name', 'new_fc', ...
    'WeightLearnRateFactor', 10, 'BiasLearnRateFactor', 10);
newSoftmax    = softmaxLayer('Name', 'new_softmax');
newClassLayer = classificationLayer('Name', 'new_classoutput');

layerGraph = replaceLayer(layerGraph, 'fc1000',    newFCLayer);
layerGraph = replaceLayer(layerGraph, 'prob',       newSoftmax);
layerGraph = replaceLayer(layerGraph, 'ClassificationLayer_predictions', ...
    newClassLayer);
fprintf('  Network layers modified for %d classes.\n', numClasses);

%% Step 5 – Augmented datastore and training options
augTrainDS = augmentedImageDatastore(imageSize(1:2), trainDS);
augValDS   = augmentedImageDatastore(imageSize(1:2), valDS);

trainingOptions = trainingOptions('adam', ...
    'MaxEpochs',          10, ...
    'MiniBatchSize',      32, ...
    'InitialLearnRate',   1e-4, ...
    'ValidationData',     augValDS, ...
    'ValidationFrequency',10, ...
    'Shuffle',            'every-epoch', ...
    'Verbose',            true, ...
    'Plots',              'training-progress');

%% Step 6 – Train the network
fprintf('\n=== Step 6: Training network ===\n');
[trainedNetwork, trainingInfo] = trainNetwork(augTrainDS, ...
    layerGraph, trainingOptions);
fprintf('  Training complete. Final validation accuracy: %.2f%%\n', ...
    trainingInfo.FinalValidationAccuracy);

%% Step 7 – Evaluate on test set
fprintf('\n=== Step 7: Evaluating on test set ===\n');
augTestDS      = augmentedImageDatastore(imageSize(1:2), testDS);
predictedLabels = classify(trainedNetwork, augTestDS);
trueLabels      = testDS.Labels;
testAccuracy    = mean(predictedLabels == trueLabels) * 100;
fprintf('  Test accuracy: %.2f%%\n', testAccuracy);

figCM = figure('Name','Confusion Matrix','Position',[100 100 600 500]);
confusionchart(trueLabels, predictedLabels);
title('\textbf{Test-Set Confusion Matrix}', 'Interpreter','latex');

%% Step 8 – Save model and figures
save('Ch08_Problem5_TrainedModel.mat', 'trainedNetwork');
savefig(figCM, 'Ch08_Problem5_ConfusionMatrix.fig');
exportgraphics(figCM, 'Ch08_Problem5_ConfusionMatrix.eps', ...
    'ContentType','vector');
exportgraphics(figCM, 'Ch08_Problem5_ConfusionMatrix.jpg', ...
    'Resolution', 300);
fprintf('  Model and figures saved.\n');

fprintf('\n=== Problem 5 Complete ===\n');
% --------------------------------
% Computational Complexity:
% Image generation is O(numClasses * imagesPerClass * imagePixels).
% Transfer learning trains only the final layers; each epoch
% processes N_train / batchSize mini-batches, each requiring a
% forward and backward pass through the network: O(epochs *
% N_train * networkFLOPs / batchSize). Classification of the test
% set is O(N_test * forwardPassFLOPs). The imageDatastore ensures
% memory usage is O(batchSize * imagePixels) per iteration.
% --------------------------------
