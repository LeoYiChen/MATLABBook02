%% chapter_AI_Mechanics_Problem5_damage_syntax.m
% Phase-field damage evolution syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem5_damage_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Solve damage evolution equation (AT2 model)
% Laplacian using finite differences
Lap_d = del2(d, dx, dy);  % 5-point stencil Laplacian

% Driving force (history field prevents healing)
psiPlus = 0.5 * lambda * (tr_eps_pos)^2 + mu * (eps_dev : eps_dev);
H = max(H, psiPlus);  % History field

% Damage evolution: Gc*(d/l - l*Lap_d) = 2*(1-d)*H
% Rearrange: (Gc/l + 2*H)*d - Gc*l*Lap_d = 2*H
A_coeff = Gc / l_scale + 2 * H;
b_rhs = 2 * H;

% Linear solve (Helmholtz equation)
d_new = (b_rhs + Gc * l_scale * Lap_d) ./ A_coeff;

% Enforce irreversibility and bounds
d_new = max(d_old, d_new);  % No healing
d_new = min(1, max(0, d_new));  % Clamp to [0,1]
