%% chapter_UQ_algorithm_basicMC.m
% Canonical Monte Carlo algorithm expressed as pseudocode.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_UQ_algorithm_basicMC
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% 1. Draw N independent samples from the joint input distribution
% 2. Evaluate the deterministic model once per sample
% 3. Summarise the output ensemble (mean, variance, quantiles, exceedance)
% 4. Quantify sampling error and confirm convergence before concluding
