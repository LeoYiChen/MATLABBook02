%% Appendix01-Solutions_code_246.m
% PSO for PID Controller Optimization
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Particle Swarm Optimization for PID Control
% Problem 13: PSO for Controller Design
% Author: Control Systems Course
% Description: Complete PSO implementation for PID tuning of heat exchanger

clear all; close all; clc;

%% System Definition: Heat Exchanger Temperature Control
fprintf('=== PSO for PID Controller Optimization ===\n');
fprintf('Application: Heat Exchanger Temperature Control\n\n');

% FOPDT Model: G(s) = K*exp(-theta*s) / (tau*s + 1)
K = 2.5;        % Gain (C/% valve)
theta = 5;      % Time delay (s)
tau = 30;       % Time constant (s)

fprintf('System Parameters:\n');
fprintf('  Gain K = %.2f C/%%\n', K);
fprintf('  Time delay theta = %.1f s\n', theta);
fprintf('  Time constant tau = %.1f s\n', tau);
fprintf('  Delay/Time constant ratio = %.3f\n\n', theta/tau);

% Create transfer function with Pade approximation
% Second-order Pade approximation for exp(-theta*s)
num_delay = [theta^2/12, -theta/2, 1];
den_delay = [theta^2/12, theta/2, 1];
G_delay = tf(num_delay, den_delay);

% First-order process
G_process = tf(K, [tau, 1]);

% Combined system
G = G_process * G_delay;

fprintf('Transfer function (with 2nd-order Pade):\n');
fprintf('G(s) = %.2f * [s^2 - %.2fs + %.2f] / [(%.1fs + 1)(s^2 + %.2fs + %.2f)]\n\n', ...
        K, theta/2, 12/theta^2, tau, theta/2, 12/theta^2);

% Discretization
Ts = 0.1;  % 100ms sampling (typical for temperature control)
Gz = c2d(G, Ts, 'tustin');
fprintf('Sampling time: %.3f s\n\n', Ts);

%% Classical Tuning Rules (for comparison)
fprintf('Classical Tuning Rules:\n');

% Ziegler-Nichols (step response method)
Kp_ZN = 1.2 * tau / (K * theta);
Ki_ZN = Kp_ZN / (2 * theta);
Kd_ZN = Kp_ZN * theta / 2;
fprintf('  Ziegler-Nichols: Kp=%.3f, Ki=%.3f, Kd=%.3f\n', Kp_ZN, Ki_ZN, Kd_ZN);

% Cohen-Coon
Kp_CC = (tau / (K * theta)) * (1.35 + 0.25*theta/tau);
Ti_CC = theta * (2.5 + 0.6*theta/tau);
Td_CC = theta * (0.37*tau / (tau + 0.2*theta));
Ki_CC = Kp_CC / Ti_CC;
Kd_CC = Kp_CC * Td_CC;
fprintf('  Cohen-Coon: Kp=%.3f, Ki=%.3f, Kd=%.3f\n\n', Kp_CC, Ki_CC, Kd_CC);

%% PSO Parameters
pso_params = struct();

% Swarm configuration
pso_params.swarm_size = 30;          % Number of particles
pso_params.max_iterations = 100;     % Maximum iterations
pso_params.n_runs = 3;               % Multiple runs for robustness

% PSO coefficients
pso_params.w_max = 0.9;              % Initial inertia weight
pso_params.w_min = 0.4;              % Final inertia weight
pso_params.c1 = 2.0;                 % Cognitive coefficient
pso_params.c2 = 2.0;                 % Social coefficient

% Search space bounds
pso_params.Kp_min = 0;
pso_params.Kp_max = 10;
pso_params.Ki_min = 0;
pso_params.Ki_max = 2;
pso_params.Kd_min = 0;
pso_params.Kd_max = 20;

% Velocity limits (20% of search space)
pso_params.v_max_Kp = 0.2 * (pso_params.Kp_max - pso_params.Kp_min);
pso_params.v_max_Ki = 0.2 * (pso_params.Ki_max - pso_params.Ki_min);
pso_params.v_max_Kd = 0.2 * (pso_params.Kd_max - pso_params.Kd_min);

fprintf('PSO Configuration:\n');
fprintf('  Swarm size: %d particles\n', pso_params.swarm_size);
fprintf('  Max iterations: %d\n', pso_params.max_iterations);
fprintf('  Inertia weight: %.2f -> %.2f (linear decrease)\n', ...
        pso_params.w_max, pso_params.w_min);
fprintf('  Cognitive coefficient c1: %.2f\n', pso_params.c1);
fprintf('  Social coefficient c2: %.2f\n\n', pso_params.c2);

%% Objective Function Parameters
obj_params = struct();
obj_params.Ts = Ts;
obj_params.T_sim = 200;              % Long simulation for delay system
obj_params.setpoint = 10;            % 10 degree setpoint

% Weights for multi-objective cost
obj_params.w_ITAE = 1.0;
obj_params.w_control = 0.01;
obj_params.w_overshoot = 50;
obj_params.w_settling = 0.5;

% Constraints
obj_params.max_overshoot = 10;       % 10% max (safety)
obj_params.max_control = 100;        % Valve limit
obj_params.min_control = 0;
obj_params.min_GM = 3;               % 3 dB minimum
obj_params.min_PM = 30;              % 30 degrees minimum

fprintf('Optimization Objectives:\n');
fprintf('  Minimize: %.1f*ITAE + %.3f*ControlEffort + %.1f*Overshoot + %.1f*SettlingTime\n', ...
        obj_params.w_ITAE, obj_params.w_control, obj_params.w_overshoot, obj_params.w_settling);
fprintf('\nConstraints:\n');
fprintf('  Max overshoot: %.1f%%\n', obj_params.max_overshoot);
fprintf('  Control range: [%.0f, %.0f] %%\n', obj_params.min_control, obj_params.max_control);
fprintf('  Min gain margin: %.1f dB\n', obj_params.min_GM);
fprintf('  Min phase margin: %.1f deg\n\n', obj_params.min_PM);

%% Initialize Storage for Multiple Runs
all_runs_data = cell(pso_params.n_runs, 1);
best_solutions = zeros(pso_params.n_runs, 4); % Kp, Ki, Kd, fitness

%% PSO Main Loop - Multiple Runs
fprintf('Starting PSO optimization (%d independent runs)...\n', pso_params.n_runs);
fprintf('Run | Best Fitness | Kp      | Ki      | Kd      | Time\n');
fprintf('--|-------|-----|-----|-----|----\n');

for run = 1:pso_params.n_runs
    tic;
    
    % Initialize swarm
    swarm = initialize_swarm(pso_params);
    
    % Storage for this run
    gbest_history = zeros(pso_params.max_iterations, 1);
    gbest_position_history = zeros(pso_params.max_iterations, 3);
    swarm_diversity = zeros(pso_params.max_iterations, 1);
    
    % Evaluate initial swarm
    fitness = zeros(pso_params.swarm_size, 1);
    for i = 1:pso_params.swarm_size
        fitness(i) = evaluate_pid_fitness(swarm.position(i,:), G, Gz, obj_params);
    end
    
    % Initialize personal and global bests
    swarm.pbest_position = swarm.position;
    swarm.pbest_fitness = fitness;
    
    [gbest_fitness, gbest_idx] = min(fitness);
    gbest_position = swarm.position(gbest_idx, :);
    
    % PSO iterations
    for iter = 1:pso_params.max_iterations
        
        % Update inertia weight (linear decrease)
        w = pso_params.w_max - (pso_params.w_max - pso_params.w_min) * ...
            (iter / pso_params.max_iterations);
        
        % Update each particle
        for i = 1:pso_params.swarm_size
            
            % Random coefficients
            r1 = rand(1, 3);
            r2 = rand(1, 3);
            
            % Velocity update
            cognitive = pso_params.c1 * r1 .* (swarm.pbest_position(i,:) - swarm.position(i,:));
            social = pso_params.c2 * r2 .* (gbest_position - swarm.position(i,:));
            
            swarm.velocity(i,:) = w * swarm.velocity(i,:) + cognitive + social;
            
            % Velocity clamping
            swarm.velocity(i,1) = max(-pso_params.v_max_Kp, min(pso_params.v_max_Kp, swarm.velocity(i,1)));
            swarm.velocity(i,2) = max(-pso_params.v_max_Ki, min(pso_params.v_max_Ki, swarm.velocity(i,2)));
            swarm.velocity(i,3) = max(-pso_params.v_max_Kd, min(pso_params.v_max_Kd, swarm.velocity(i,3)));
            
            % Position update
            swarm.position(i,:) = swarm.position(i,:) + swarm.velocity(i,:);
            
            % Boundary handling (reflecting)
            swarm.position(i,1) = enforce_bounds(swarm.position(i,1), pso_params.Kp_min, pso_params.Kp_max);
            swarm.position(i,2) = enforce_bounds(swarm.position(i,2), pso_params.Ki_min, pso_params.Ki_max);
            swarm.position(i,3) = enforce_bounds(swarm.position(i,3), pso_params.Kd_min, pso_params.Kd_max);
            
            % Evaluate fitness
            fitness(i) = evaluate_pid_fitness(swarm.position(i,:), G, Gz, obj_params);
            
            % Update personal best
            if fitness(i) < swarm.pbest_fitness(i)
                swarm.pbest_fitness(i) = fitness(i);
                swarm.pbest_position(i,:) = swarm.position(i,:);
            end
        end
        
        % Update global best
        [current_best_fitness, current_best_idx] = min(fitness);
        if current_best_fitness < gbest_fitness
            gbest_fitness = current_best_fitness;
            gbest_position = swarm.position(current_best_idx, :);
        end
        
        % Record history
        gbest_history(iter) = gbest_fitness;
        gbest_position_history(iter, :) = gbest_position;
        
        % Calculate swarm diversity (average distance to centroid)
        centroid = mean(swarm.position, 1);
        distances = sqrt(sum((swarm.position - centroid).^2, 2));
        swarm_diversity(iter) = mean(distances);
    end
    
    elapsed_time = toc;
    
    % Store run data
    all_runs_data{run}.gbest_history = gbest_history;
    all_runs_data{run}.gbest_position_history = gbest_position_history;
    all_runs_data{run}.diversity = swarm_diversity;
    all_runs_data{run}.final_swarm = swarm;
    
    best_solutions(run, 1:3) = gbest_position;
    best_solutions(run, 4) = gbest_fitness;
    
    fprintf('%3d | %12.4f | %7.3f | %7.3f | %7.3f | %.2fs\n', ...
            run, gbest_fitness, gbest_position(1), gbest_position(2), gbest_position(3), elapsed_time);
end

%% Select Best Solution from All Runs
[best_fitness_overall, best_run_idx] = min(best_solutions(:, 4));
best_Kp = best_solutions(best_run_idx, 1);
best_Ki = best_solutions(best_run_idx, 2);
best_Kd = best_solutions(best_run_idx, 3);

fprintf('\n=== Best Solution (Run %d) ===\n', best_run_idx);
fprintf('Kp = %.4f\n', best_Kp);
fprintf('Ki = %.4f\n', best_Ki);
fprintf('Kd = %.4f\n', best_Kd);
fprintf('Fitness = %.4f\n\n', best_fitness_overall);

%% Performance Comparison
fprintf('=== Performance Comparison ===\n');

controllers = struct();

% PSO optimal
controllers(1).name = 'PSO Optimal';
controllers(1).Kp = best_Kp;
controllers(1).Ki = best_Ki;
controllers(1).Kd = best_Kd;

% Ziegler-Nichols
controllers(2).name = 'Ziegler-Nichols';
controllers(2).Kp = Kp_ZN;
controllers(2).Ki = Ki_ZN;
controllers(2).Kd = Kd_ZN;

% Cohen-Coon
controllers(3).name = 'Cohen-Coon';
controllers(3).Kp = Kp_CC;
controllers(3).Ki = Ki_CC;
controllers(3).Kd = Kd_CC;

% Manual conservative tuning
controllers(4).name = 'Conservative';
controllers(4).Kp = 2.0;
controllers(4).Ki = 0.2;
controllers(4).Kd = 5.0;

% Simulate each controller
T_sim = 200;
time = 0:Ts:T_sim;
r = obj_params.setpoint * ones(1, length(time));

% Add disturbance at t=100s
disturbance = zeros(1, length(time));
disturbance(time >= 100) = -2;  % -2 degree load disturbance

for i = 1:length(controllers)
    Kp = controllers(i).Kp;
    Ki = controllers(i).Ki;
    Kd = controllers(i).Kd;
    
    % Simulate with disturbance
    [y, u, e] = simulate_pid_with_disturbance(Gz, Kp, Ki, Kd, r, disturbance, Ts, obj_params);
    
    % Calculate metrics
    metrics = calculate_performance_metrics(y, u, e, r, Ts);
    
    % Stability margins
    C = pid(Kp, Ki, Kd, Ts);
    L = G * C;
    [Gm, Pm, ~, ~] = margin(L);
    
    % Store results
    controllers(i).y = y;
    controllers(i).u = u;
    controllers(i).e = e;
    controllers(i).metrics = metrics;
    controllers(i).GM = 20*log10(Gm);
    controllers(i).PM = Pm;
    
    % Display
    fprintf('\n%s (Kp=%.3f, Ki=%.3f, Kd=%.3f):\n', ...
            controllers(i).name, Kp, Ki, Kd);
    fprintf('  Rise time: %.2f s\n', metrics.rise_time);
    fprintf('  Overshoot: %.2f%%\n', metrics.overshoot);
    fprintf('  Settling time: %.2f s\n', metrics.settling_time);
    fprintf('  ITAE: %.4f\n', metrics.ITAE);
    fprintf('  Control effort: %.4f\n', metrics.control_effort);
    fprintf('  Gain margin: %.2f dB\n', controllers(i).GM);
    fprintf('  Phase margin: %.2f deg\n', controllers(i).PM);
    
    % Check constraint violations
    violations = '';
    if metrics.overshoot > obj_params.max_overshoot
        violations = [violations, 'Overshoot! '];
    end
    if any(u > obj_params.max_control) || any(u < obj_params.min_control)
        violations = [violations, 'Saturation! '];
    end
    if controllers(i).GM < obj_params.min_GM
        violations = [violations, 'GM! '];
    end
    if controllers(i).PM < obj_params.min_PM
        violations = [violations, 'PM! '];
    end
    if ~isempty(violations)
        fprintf('  *** Violations: %s\n', violations);
    end
end

%% Detailed Visualization

% Figure 1: PSO Convergence Analysis
figure('Position', [50 50 1400 900]);

% Plot 1: Convergence curves for all runs
subplot(2,3,1);
colors = lines(pso_params.n_runs);
hold on;
for run = 1:pso_params.n_runs
    plot(1:pso_params.max_iterations, all_runs_data{run}.gbest_history, ...
         'Color', colors(run,:), 'LineWidth', 1.5);
end
hold off;
grid on;
xlabel('Iteration');
ylabel('Best Fitness');
title('PSO Convergence (All Runs)');
legend(arrayfun(@(x) sprintf('Run %d', x), 1:pso_params.n_runs, 'UniformOutput', false), ...
       'Location', 'northeast');
set(gca, 'YScale', 'log');

% Plot 2: Diversity evolution
subplot(2,3,2);
plot(1:pso_params.max_iterations, all_runs_data{best_run_idx}.diversity, ...
     'b-', 'LineWidth', 2);
grid on;
xlabel('Iteration');
ylabel('Swarm Diversity');
title('Swarm Diversity Evolution (Best Run)');

% Plot 3: Parameter evolution
subplot(2,3,3);
gbest_pos_hist = all_runs_data{best_run_idx}.gbest_position_history;
plot(1:pso_params.max_iterations, gbest_pos_hist(:,1), 'r-', 'LineWidth', 2); hold on;
plot(1:pso_params.max_iterations, gbest_pos_hist(:,2), 'g-', 'LineWidth', 2);
plot(1:pso_params.max_iterations, gbest_pos_hist(:,3), 'b-', 'LineWidth', 2);
grid on;
xlabel('Iteration');
ylabel('Parameter Value');
title('PID Parameter Evolution');
legend('K_p', 'K_i', 'K_d', 'Location', 'best');

% Plot 4: Final swarm distribution (Kp vs Ki)
subplot(2,3,4);
final_swarm = all_runs_data{best_run_idx}.final_swarm;
scatter(final_swarm.position(:,1), final_swarm.position(:,2), 50, ...
        final_swarm.pbest_fitness, 'filled');
hold on;
plot(best_Kp, best_Ki, 'rp', 'MarkerSize', 20, 'MarkerFaceColor', 'r', 'LineWidth', 2);
colorbar;
xlabel('K_p');
ylabel('K_i');
title('Final Swarm Distribution (K_p vs K_i)');
grid on;

% Plot 5: Final swarm distribution (Kp vs Kd)
subplot(2,3,5);
scatter(final_swarm.position(:,1), final_swarm.position(:,3), 50, ...
        final_swarm.pbest_fitness, 'filled');
hold on;
plot(best_Kp, best_Kd, 'rp', 'MarkerSize', 20, 'MarkerFaceColor', 'r', 'LineWidth', 2);
colorbar;
xlabel('K_p');
ylabel('K_d');
title('Final Swarm Distribution (K_p vs K_d)');
grid on;

% Plot 6: Inertia weight schedule
subplot(2,3,6);
iterations = 1:pso_params.max_iterations;
w_schedule = pso_params.w_max - (pso_params.w_max - pso_params.w_min) * ...
             (iterations / pso_params.max_iterations);
plot(iterations, w_schedule, 'k-', 'LineWidth', 2);
grid on;
xlabel('Iteration');
ylabel('Inertia Weight w');
title('Inertia Weight Schedule');
ylim([0 1]);

sgtitle('PSO Algorithm Analysis', 'FontSize', 14, 'FontWeight', 'bold');

% Figure 2: Controller Comparison
figure('Position', [100 100 1400 900]);

% Plot 1: Step responses
subplot(3,2,1);
plot(time, r, 'k-', 'LineWidth', 1.5); hold on;
colors_ctrl = {'r', 'b', 'g', 'm'};
for i = 1:length(controllers)
    plot(time, controllers(i).y, colors_ctrl{i}, 'LineWidth', 2);
end
yline(r(1) * 1.1, 'k:', 'LineWidth', 1);  % 10% overshoot line
grid on;
xlabel('Time (s)');
ylabel('Temperature ( C)');
title('Setpoint Tracking with Disturbance');
legend(['Setpoint', {controllers.name}, '10% overshoot'], 'Location', 'southeast');

% Plot 2: Control signals
subplot(3,2,3);
hold on;
for i = 1:length(controllers)
    plot(time, controllers(i).u, colors_ctrl{i}, 'LineWidth', 2);
end
yline(obj_params.max_control, 'k-', 'LineWidth', 1);
yline(obj_params.min_control, 'k-', 'LineWidth', 1);
grid on;
xlabel('Time (s)');
ylabel('Valve Opening (%)');
title('Control Signal');
legend([{controllers.name}, 'Limits'], 'Location', 'northeast');

% Plot 3: Error signals
subplot(3,2,5);
hold on;
for i = 1:length(controllers)
    plot(time, controllers(i).e, colors_ctrl{i}, 'LineWidth', 1.5);
end
grid on;
xlabel('Time (s)');
ylabel('Error ( C)');
title('Tracking Error');
legend({controllers.name}, 'Location', 'northeast');

% Plot 4: Performance metrics bar chart
subplot(3,2,2);
metrics_data = zeros(length(controllers), 4);
for i = 1:length(controllers)
    metrics_data(i,1) = controllers(i).metrics.ITAE / 100;  % Scaled
    metrics_data(i,2) = controllers(i).metrics.overshoot;
    metrics_data(i,3) = controllers(i).metrics.settling_time / 10;  % Scaled
    metrics_data(i,4) = controllers(i).metrics.control_effort / 1000;  % Scaled
end
bar(metrics_data);
set(gca, 'XTickLabel', {controllers.name});
ylabel('Normalized Metric Value');
title('Performance Metrics Comparison');
legend('ITAE/100', 'Overshoot %', 't_s/10', 'Effort/1000', 'Location', 'northwest');
grid on;

% Plot 5: Stability margins
subplot(3,2,4);
margins_data = [[controllers.GM]', [controllers.PM]'];
bar(margins_data);
set(gca, 'XTickLabel', {controllers.name});
ylabel('Margin Value');
title('Stability Margins');
legend('Gain Margin (dB)', 'Phase Margin (deg)', 'Location', 'northwest');
yline(obj_params.min_GM, 'r-', 'Min GM');
yline(obj_params.min_PM, 'b-', 'Min PM');
grid on;

% Plot 6: Nyquist plots
subplot(3,2,6);
hold on;
for i = 1:length(controllers)
    C = pid(controllers(i).Kp, controllers(i).Ki, controllers(i).Kd, Ts);
    L = G * C;
    nyquist(L);
end
grid on;
title('Nyquist Plots');
legend({controllers.name}, 'Location', 'southwest');

sgtitle('Controller Performance Comparison', 'FontSize', 14, 'FontWeight', 'bold');

% Figure 3: Robustness Analysis
figure('Position', [150 150 1200 800]);

% Test robustness to parameter variations
param_variations = -30:5:30;  % -30% to +30%
n_variations = length(param_variations);

robustness_ITAE = zeros(length(controllers), n_variations);

for ctrl_idx = 1:length(controllers)
    Kp = controllers(ctrl_idx).Kp;
    Ki = controllers(ctrl_idx).Ki;
    Kd = controllers(ctrl_idx).Kd;
    
    for var_idx = 1:n_variations
        % Vary process gain
        K_varied = K * (1 + param_variations(var_idx)/100);
        G_varied = tf(K_varied, [tau, 1]) * G_delay;
        Gz_varied = c2d(G_varied, Ts, 'tustin');
        
        % Simulate
        [y_var, u_var, e_var] = simulate_pid_response(Gz_varied, Kp, Ki, Kd, r, Ts);
        
        % Check stability
        if any(isnan(y_var)) || any(isinf(y_var)) || max(abs(y_var)) > 100
            robustness_ITAE(ctrl_idx, var_idx) = 1e6;  % Unstable
        else
            robustness_ITAE(ctrl_idx, var_idx) = Ts * sum((0:length(e_var)-1)' .* abs(e_var'));
        end
    end
end

% Plot robustness
subplot(2,2,1);
hold on;
for i = 1:length(controllers)
    plot(param_variations, robustness_ITAE(i,:), [colors_ctrl{i} '-'], ...
         'LineWidth', 2, 'Marker', 'o');
end
grid on;
xlabel('Process Gain Variation (%)');
ylabel('ITAE');
title('Robustness to Gain Uncertainty');
legend({controllers.name}, 'Location', 'northwest');
set(gca, 'YScale', 'log');

% Sensitivity analysis (PSO optimal only)
subplot(2,2,2);
Kp_range = linspace(0.5*best_Kp, 1.5*best_Kp, 20);
Ki_range = linspace(0.5*best_Ki, 1.5*best_Ki, 20);
sensitivity_map = zeros(length(Kp_range), length(Ki_range));

for i = 1:length(Kp_range)
    for j = 1:length(Ki_range)
        [y_sens, u_sens, e_sens] = simulate_pid_response(Gz, Kp_range(i), Ki_range(j), best_Kd, r, Ts);
        if any(isnan(y_sens)) || any(isinf(y_sens))
            sensitivity_map(i,j) = 1e6;
        else
            sensitivity_map(i,j) = Ts * sum((0:length(e_sens)-1)' .* abs(e_sens'));
        end
    end
end

contourf(Ki_range, Kp_range, sensitivity_map, 20);
hold on;
plot(best_Ki, best_Kp, 'r*', 'MarkerSize', 15, 'LineWidth', 3);
colorbar;
xlabel('K_i');
ylabel('K_p');
title('Sensitivity Map (K_d fixed)');

% Bode plots comparison
subplot(2,2,3);
hold on;
for i = 1:length(controllers)
    C = pid(controllers(i).Kp, controllers(i).Ki, controllers(i).Kd, Ts);
    L = G * C;
    bode(L);
end
grid on;
title('Bode Plots of Loop Transfer Functions');
legend({controllers.name}, 'Location', 'southwest');

% Step response detail (first 50s)
subplot(2,2,4);
idx_zoom = time <= 50;
plot(time(idx_zoom), r(idx_zoom), 'k-', 'LineWidth', 1.5); hold on;
for i = 1:length(controllers)
    plot(time(idx_zoom), controllers(i).y(idx_zoom), colors_ctrl{i}, 'LineWidth', 2);
end
grid on;
xlabel('Time (s)');
ylabel('Temperature ( C)');
title('Step Response (First 50s)');
legend(['Setpoint', {controllers.name}], 'Location', 'southeast');

sgtitle('Robustness and Sensitivity Analysis', 'FontSize', 13, 'FontWeight', 'bold');

% Figure 4: Swarm Animation (selected iterations)
figure('Position', [200 200 1000 800]);
selected_iterations = [1, 10, 30, 50, 70, 100];
swarm_positions_all = cell(pso_params.max_iterations, 1);

% Re-run best case to capture swarm positions (simplified)
% For animation purposes, we'll use the final swarm and interpolate
% In a full implementation, you'd store all positions at each iteration

for idx = 1:length(selected_iterations)
    iter = selected_iterations(idx);
    
    subplot(2, 3, idx);
    
    % For demonstration, show evolution towards final position
    % In reality, you'd store swarm positions at each iteration
    alpha = iter / pso_params.max_iterations;
    
    % Simulate swarm movement (interpolated for visualization)
    init_positions = rand(pso_params.swarm_size, 3) .* ...
                    [pso_params.Kp_max - pso_params.Kp_min, ...
                     pso_params.Ki_max - pso_params.Ki_min, ...
                     pso_params.Kd_max - pso_params.Kd_min];
    current_positions = (1-alpha) * init_positions + ...
                       alpha * repmat([best_Kp, best_Ki, best_Kd], pso_params.swarm_size, 1);
    
    scatter3(current_positions(:,1), current_positions(:,2), current_positions(:,3), ...
             50, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    plot3(best_Kp, best_Ki, best_Kd, 'r*', 'MarkerSize', 20, 'LineWidth', 3);
    
    xlabel('K_p'); ylabel('K_i'); zlabel('K_d');
    title(sprintf('Iteration %d', iter));
    grid on;
    view(45, 30);
    
    xlim([pso_params.Kp_min, pso_params.Kp_max]);
    ylim([pso_params.Ki_min, pso_params.Ki_max]);
    zlim([pso_params.Kd_min, pso_params.Kd_max]);
end

sgtitle('Swarm Evolution (3D Parameter Space)', 'FontSize', 13, 'FontWeight', 'bold');

fprintf('\n=== PSO Optimization Complete ===\n');
fprintf('Best PID Controller: Kp=%.4f, Ki=%.4f, Kd=%.4f\n', best_Kp, best_Ki, best_Kd);
fprintf('Achieved ITAE: %.4f (%.1f%% better than Z-N)\n', ...
        controllers(1).metrics.ITAE, ...
        (controllers(2).metrics.ITAE - controllers(1).metrics.ITAE) / ...
        controllers(2).metrics.ITAE * 100);

%% Helper Functions

function swarm = initialize_swarm(params)
    % Initialize swarm with random positions and velocities
    
    swarm.position = zeros(params.swarm_size, 3);
    swarm.velocity = zeros(params.swarm_size, 3);
    
    for i = 1:params.swarm_size
        % Random positions within bounds
        swarm.position(i,1) = params.Kp_min + rand()*(params.Kp_max - params.Kp_min);
        swarm.position(i,2) = params.Ki_min + rand()*(params.Ki_max - params.Ki_min);
        swarm.position(i,3) = params.Kd_min + rand()*(params.Kd_max - params.Kd_min);
        
        % Random initial velocities
        swarm.velocity(i,1) = -params.v_max_Kp + 2*rand()*params.v_max_Kp;
        swarm.velocity(i,2) = -params.v_max_Ki + 2*rand()*params.v_max_Ki;
        swarm.velocity(i,3) = -params.v_max_Kd + 2*rand()*params.v_max_Kd;
    end
    
    swarm.pbest_position = [];
    swarm.pbest_fitness = [];
end

function value = enforce_bounds(value, min_val, max_val)
    % Enforce bounds with reflection
    if value < min_val
        value = min_val + (min_val - value);
        if value > max_val
            value = min_val;
        end
    elseif value > max_val
        value = max_val - (value - max_val);
        if value < min_val
            value = max_val;
        end
    end
end

function fitness = evaluate_pid_fitness(pid_params, G, Gz, params)
    % Evaluate PID controller fitness
    
    Kp = pid_params(1);
    Ki = pid_params(2);
    Kd = pid_params(3);
    
    Ts = params.Ts;
    T_sim = params.T_sim;
    time = 0:Ts:T_sim;
    r = params.setpoint * ones(1, length(time));
    
    % Simulate response
    [y, u, e] = simulate_pid_response(Gz, Kp, Ki, Kd, r, Ts);
    
    % Check for instability
    if any(isnan(y)) || any(isinf(y)) || max(abs(y)) > 1000
        fitness = 1e10;
        return;
    end
    
    % Calculate metrics
    metrics = calculate_performance_metrics(y, u, e, r, Ts);
    
    % Check stability margins
    try
        C = pid(Kp, Ki, Kd, Ts);
        L = G * C;
        [Gm, Pm, ~, ~] = margin(L);
        GM_dB = 20*log10(Gm);
    catch
        fitness = 1e10;
        return;
    end
    
    % Multi-objective cost with penalties
    cost_ITAE = params.w_ITAE * metrics.ITAE;
    cost_control = params.w_control * metrics.control_effort;
    cost_overshoot = params.w_overshoot * max(0, metrics.overshoot);
    cost_settling = params.w_settling * metrics.settling_time;
    
    % Constraint penalties
    penalty = 0;
    
    if metrics.overshoot > params.max_overshoot
        penalty = penalty + 1000 * (metrics.overshoot - params.max_overshoot);
    end
    
    if any(u > params.max_control) || any(u < params.min_control)
        penalty = penalty + 1000 * sum(max(0, u - params.max_control)) + ...
                            1000 * sum(max(0, params.min_control - u));
    end
    
    if GM_dB < params.min_GM
        penalty = penalty + 1000 * (params.min_GM - GM_dB);
    end
    
    if Pm < params.min_PM
        penalty = penalty + 1000 * (params.min_PM - Pm);
    end
    
    fitness = cost_ITAE + cost_control + cost_overshoot + cost_settling + penalty;
end

function [y, u, e] = simulate_pid_response(Gz, Kp, Ki, Kd, r, Ts)
    % Simulate PID response (same as previous problems)
    
    N = length(r);
    y = zeros(1, N);
    u = zeros(1, N);
    e = zeros(1, N);
    
    integral = 0;
    prev_error = 0;
    prev_derivative = 0;
    
    N_filter = 10;
    tau_d = Kd / N_filter;
    
    x = zeros(size(Gz.A, 1), 1);
    
    for k = 1:N
        y(k) = Gz.C * x;
        e(k) = r(k) - y(k);
        
        proportional = Kp * e(k);
        integral = integral + Ki * Ts * e(k);
        integral = max(-1000, min(1000, integral));
        
        derivative = (tau_d / (tau_d + N_filter * Ts)) * prev_derivative + ...
                     (Kd * N_filter / (tau_d + N_filter * Ts)) * (e(k) - prev_error);
        
        u(k) = proportional + integral + derivative;
        
        if k < N
            x = Gz.A * x + Gz.B * u(k);
        end
        
        prev_error = e(k);
        prev_derivative = derivative;
    end
end

function [y, u, e] = simulate_pid_with_disturbance(Gz, Kp, Ki, Kd, r, d, Ts, params)
    % Simulate PID with load disturbance
    
    N = length(r);
    y = zeros(1, N);
    u = zeros(1, N);
    e = zeros(1, N);
    
    integral = 0;
    prev_error = 0;
    prev_derivative = 0;
    
    N_filter = 10;
    tau_d = Kd / N_filter;
    
    x = zeros(size(Gz.A, 1), 1);
    
    for k = 1:N
        y(k) = Gz.C * x + d(k);  % Add disturbance to output
        e(k) = r(k) - y(k);
        
        proportional = Kp * e(k);
        integral = integral + Ki * Ts * e(k);
        integral = max(-1000, min(1000, integral));
        
        derivative = (tau_d / (tau_d + N_filter * Ts)) * prev_derivative + ...
                     (Kd * N_filter / (tau_d + N_filter * Ts)) * (e(k) - prev_error);
        
        u(k) = proportional + integral + derivative;
        u(k) = max(params.min_control, min(params.max_control, u(k)));
        
        if k < N
            x = Gz.A * x + Gz.B * u(k);
        end
        
        prev_error = e(k);
        prev_derivative = derivative;
    end
end

function metrics = calculate_performance_metrics(y, u, e, r, Ts)
    % Calculate comprehensive performance metrics
    
    time = (0:length(y)-1) * Ts;
    final_value = r(end);
    
    % Rise time (10% to 90%)
    idx_10 = find(y >= 0.1*final_value, 1, 'first');
    idx_90 = find(y >= 0.9*final_value, 1, 'first');
    if ~isempty(idx_10) && ~isempty(idx_90)
        metrics.rise_time = time(idx_90) - time(idx_10);
    else
        metrics.rise_time = NaN;
    end
    
    % Overshoot
    metrics.overshoot = max(0, (max(y) - final_value) / abs(final_value) * 100);
    
    % Settling time (2% criterion)
    settling_band = 0.02 * abs(final_value);
    settled = abs(y - final_value) <= settling_band;
    
    % Find last time outside band
    outside_band_idx = find(~settled);
    if ~isempty(outside_band_idx)
        metrics.settling_time = time(outside_band_idx(end));
    else
        metrics.settling_time = 0;
    end
    
    % Performance indices
    metrics.IAE = Ts * sum(abs(e));
    metrics.ITAE = Ts * sum(time' .* abs(e'));
    metrics.ISE = Ts * sum(e.^2);
    metrics.ITSE = Ts * sum(time' .* e'.^2);
    
    % Control effort
    metrics.control_effort = Ts * sum(u.^2);
    metrics.max_control = max(abs(u));
end
