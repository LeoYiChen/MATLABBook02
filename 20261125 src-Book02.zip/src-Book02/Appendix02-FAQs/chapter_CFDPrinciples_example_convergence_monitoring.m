%% chapter_CFDPrinciples_example_convergence_monitoring.m
% Comprehensive convergence monitoring system.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_convergence_monitoring
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function convergenceStatus = monitorConvergence(residualHistory, ...
    monitoredQuantities, massFlowData, convergenceCriteria)
    % MONITORCONVERGENCE Quantitative convergence assessment
    % Evaluates multiple convergence metrics with automated decision-making
    %
    % Inputs:
    %   residualHistory      - Struct with fields for each equation (e.g., 
    %                          continuity, momentum, energy, turbulence)
    %   monitoredQuantities  - Struct with physical quantities (drag, lift,
    %                          pressure drop, etc.) over iterations
    %   massFlowData        - Struct: inletMassFlow, outletMassFlow vectors
    %   convergenceCriteria - Struct: residualTol, asymptoteWindow,
    %                          massImbalanceTol
    %
    % Output:
    %   convergenceStatus   - Comprehensive convergence assessment
    %
    % Author: Dr Leo Chen
    % Institution: University of Cambridge
    % Version: 3.0
    %
    % References:
    %   [1] Ferziger & Peric (2002) Computational Methods for Fluid Dynamics
    %   [2] Blazek (2015) Computational Fluid Dynamics
    %   [3] Versteeg & Malalasekera (2007) Introduction to CFD
    
    fprintf('=== Convergence Monitoring System ===\n\n');
    
    convergenceStatus = struct();
    convergenceStatus.timestamp = datetime('now');
    
    % Extract criteria
    if isfield(convergenceCriteria, 'residualTol')
        residTol = convergenceCriteria.residualTol;
    else
        residTol = 1e-4;  % Default tolerance
    end
    
    if isfield(convergenceCriteria, 'massImbalanceTol')
        massImbalTol = convergenceCriteria.massImbalanceTol;
    else
        massImbalTol = 1e-4;  % 0.01% default
    end
    
    if isfield(convergenceCriteria, 'asymptoteWindow')
        asymptWindow = convergenceCriteria.asymptoteWindow;
    else
        asymptWindow = 50;  % Last 50 iterations
    end
    
    convergenceStatus.criteria = struct('residualTol', residTol, ...
                                        'massImbalanceTol', massImbalTol, ...
                                        'asymptoteWindow', asymptWindow);
    
    % 1. Residual convergence check
    residualCheck = assessResidualConvergence(residualHistory, residTol);
    convergenceStatus.residuals = residualCheck;
    
    % 2. Mass conservation check
    massCheck = assessMassConservation(massFlowData, massImbalTol);
    convergenceStatus.massConservation = massCheck;
    
    % 3. Monitored quantities asymptotic behaviour
    quantityCheck = assessAsymptoticBehaviour(monitoredQuantities, asymptWindow);
    convergenceStatus.monitoredQuantities = quantityCheck;
    
    % 4. Overall convergence decision
    overallConverged = residualCheck.allConverged && ...
                       massCheck.withinTolerance && ...
                       quantityCheck.asymptotic;
    
    convergenceStatus.overallConverged = overallConverged;
    
    % Generate convergence report
    generateConvergenceReport(convergenceStatus);
    
    % Visualise convergence history
    visualiseConvergenceHistory(residualHistory, monitoredQuantities, ...
                                massFlowData);
    
    if overallConverged
        fprintf('\n*** CONVERGENCE ACHIEVED ***\n');
    else
        fprintf('\n*** CONVERGENCE NOT YET ACHIEVED ***\n');
        provideConvergenceGuidance(convergenceStatus);
    end
    
    fprintf('\nConvergence monitoring completed.\n');
end

function residCheck = assessResidualConvergence(residHist, tolerance)
    % Assess residual convergence for all equations
    
    residCheck = struct();
    
    equations = fieldnames(residHist);
    numEquations = length(equations);
    
    fprintf('Residual convergence assessment:\n');
    fprintf('  Tolerance: %.2e\n\n', tolerance);
    
    convergedCount = 0;
    
    for i = 1:numEquations
        eqName = equations{i};
        residuals = residHist.(eqName);
        
        % Current residual (last iteration)
        currentResid = residuals(end);
        
        % Minimum residual achieved
        minResid = min(residuals);
        
        % Reduction from initial
        initialResid = residuals(1);
        reduction = currentResid / initialResid;
        
        % Check convergence
        isConverged = currentResid < tolerance;
        
        % Store results
        residCheck.(eqName) = struct('current', currentResid, ...
                                      'minimum', minResid, ...
                                      'initial', initialResid, ...
                                      'reduction', reduction, ...
                                      'converged', isConverged);
        
        fprintf('  %s:\n', eqName);
        fprintf('    Current: %.4e\n', currentResid);
        fprintf('    Reduction: %.2e\n', reduction);
        fprintf('    Status: %s\n', convergenceStatus(isConverged));
        
        if isConverged
            convergedCount = convergedCount + 1;
        end
    end
    
    residCheck.allConverged = (convergedCount == numEquations);
    residCheck.numConverged = convergedCount;
    residCheck.totalEquations = numEquations;
    
    fprintf('\n  Overall: %d/%d equations converged\n\n', ...
            convergedCount, numEquations);
end

function massCheck = assessMassConservation(massFlowData, tolerance)
    % Assess global mass conservation
    
    massCheck = struct();
    
    inletFlow = massFlowData.inletMassFlow(end);
    outletFlow = massFlowData.outletMassFlow(end);
    
    % Compute imbalance
    imbalance = abs(inletFlow - outletFlow) / inletFlow;
    
    massCheck.inletMassFlow = inletFlow;
    massCheck.outletMassFlow = outletFlow;
    massCheck.imbalance = imbalance;
    massCheck.withinTolerance = imbalance < tolerance;
    
    fprintf('Mass conservation assessment:\n');
    fprintf('  Inlet mass flow: %.6f kg/s\n', inletFlow);
    fprintf('  Outlet mass flow: %.6f kg/s\n', outletFlow);
    fprintf('  Imbalance: %.4e (%.6f%%)\n', imbalance, imbalance*100);
    fprintf('  Tolerance: %.4e (%.6f%%)\n', tolerance, tolerance*100);
    fprintf('  Status: %s\n\n', convergenceStatus(massCheck.withinTolerance));
    
    % Check time history stability
    if length(massFlowData.inletMassFlow) > 10
        recentImbalance = abs(massFlowData.inletMassFlow(end-9:end) - ...
                             massFlowData.outletMassFlow(end-9:end)) ./ ...
                             massFlowData.inletMassFlow(end-9:end);
        
        imbalanceStd = std(recentImbalance);
        massCheck.recentStd = imbalanceStd;
        
        fprintf('  Recent imbalance std: %.4e\n\n', imbalanceStd);
    end
end

function quantCheck = assessAsymptoticBehaviour(monitoredQty, window)
    % Assess if monitored quantities have reached asymptotic values
    
    quantCheck = struct();
    
    quantities = fieldnames(monitoredQty);
    numQuantities = length(quantities);
    
    fprintf('Asymptotic behaviour assessment:\n');
    fprintf('  Analysis window: last %d iterations\n\n', window);
    
    asymptoticCount = 0;
    
    for i = 1:numQuantities
        qtyName = quantities{i};
        values = monitoredQty.(qtyName);
        
        numIter = length(values);
        
        if numIter < window
            fprintf('  %s: Insufficient data (need %d iterations)\n', ...
                    qtyName, window);
            quantCheck.(qtyName) = struct('asymptotic', false, ...
                                          'reason', 'insufficient_data');
            continue;
        end
        
        % Extract recent window
        recentValues = values(end-window+1:end);
        
        % Compute statistics
        meanValue = mean(recentValues);
        stdValue = std(recentValues);
        
        % Relative standard deviation
        if abs(meanValue) > 1e-12
            relativeStd = stdValue / abs(meanValue);
        else
            relativeStd = stdValue;
        end
        
        % Check for asymptotic behaviour (relative std < 0.5%)
        isAsymptotic = relativeStd < 0.005;
        
        % Also check monotonic decrease/increase in last portion
        lastTenth = recentValues(end-round(window/10):end);
        range = max(lastTenth) - min(lastTenth);
        relativeRange = range / abs(meanValue);
        
        isStable = relativeRange < 0.01;  % Less than 1% variation
        
        isAsymptotic = isAsymptotic && isStable;
        
        % Store results
        quantCheck.(qtyName) = struct('mean', meanValue, ...
                                       'std', stdValue, ...
                                       'relativeStd', relativeStd, ...
                                       'asymptotic', isAsymptotic);
        
        fprintf('  %s:\n', qtyName);
        fprintf('    Mean: %.6e\n', meanValue);
        fprintf('    Std: %.6e (%.4f%% relative)\n', stdValue, relativeStd*100);
        fprintf('    Status: %s\n', convergenceStatus(isAsymptotic));
        
        if isAsymptotic
            asymptoticCount = asymptoticCount + 1;
        end
    end
    
    quantCheck.asymptotic = (asymptoticCount == numQuantities);
    quantCheck.numAsymptotic = asymptoticCount;
    quantCheck.totalQuantities = numQuantities;
    
    fprintf('\n  Overall: %d/%d quantities asymptotic\n\n', ...
            asymptoticCount, numQuantities);
end

function generateConvergenceReport(convStatus)
    % Generate comprehensive convergence report
    
    fprintf('\n=== CONVERGENCE REPORT ===\n\n');
    
    fprintf('CRITERIA:\n');
    fprintf('  Residual tolerance: %.2e\n', convStatus.criteria.residualTol);
    fprintf('  Mass imbalance tolerance: %.4e\n', ...
            convStatus.criteria.massImbalanceTol);
    fprintf('  Asymptote window: %d iterations\n\n', ...
            convStatus.criteria.asymptoteWindow);
    
    fprintf('RESIDUAL STATUS:\n');
    fprintf('  Converged equations: %d/%d\n', ...
            convStatus.residuals.numConverged, ...
            convStatus.residuals.totalEquations);
    fprintf('  All converged: %s\n\n', ...
            convergenceStatus(convStatus.residuals.allConverged));
    
    fprintf('MASS CONSERVATION:\n');
    fprintf('  Imbalance: %.4e (%.6f%%)\n', ...
            convStatus.massConservation.imbalance, ...
            convStatus.massConservation.imbalance*100);
    fprintf('  Within tolerance: %s\n\n', ...
            convergenceStatus(convStatus.massConservation.withinTolerance));
    
    fprintf('MONITORED QUANTITIES:\n');
    fprintf('  Asymptotic quantities: %d/%d\n', ...
            convStatus.monitoredQuantities.numAsymptotic, ...
            convStatus.monitoredQuantities.totalQuantities);
    fprintf('  All asymptotic: %s\n\n', ...
            convergenceStatus(convStatus.monitoredQuantities.asymptotic));
    
    fprintf('OVERALL STATUS:\n');
    if convStatus.overallConverged
        fprintf('  ? CONVERGED\n');
    else
        fprintf('  ? NOT CONVERGED\n');
    end
    
    fprintf('\n=== END OF REPORT ===\n');
end

function provideConvergenceGuidance(convStatus)
    % Provide guidance when convergence not achieved
    
    fprintf('\nConvergence guidance:\n\n');
    
    if ~convStatus.residuals.allConverged
        fprintf('  ? Residuals not converged:\n');
        fprintf('    - Continue iterations\n');
        fprintf('    - Check for numerical instabilities\n');
        fprintf('    - Consider reducing under-relaxation factors\n\n');
    end
    
    if ~convStatus.massConservation.withinTolerance
        fprintf('  ? Mass imbalance exceeds tolerance:\n');
        fprintf('    - Check mesh quality (skewness, aspect ratio)\n');
        fprintf('    - Verify boundary condition specification\n');
        fprintf('    - Inspect for mesh connectivity issues\n\n');
    end
    
    if ~convStatus.monitoredQuantities.asymptotic
        fprintf('  ? Monitored quantities not asymptotic:\n');
        fprintf('    - Solution may be genuinely unsteady\n');
        fprintf('    - Consider time-averaging for turbulent flows\n');
        fprintf('    - Check for periodic oscillations\n\n');
    end
end

function visualiseConvergenceHistory(residHist, monQty, massFlow)
    % Visualise convergence history
    
    figure('Name', 'Convergence History', 'Position', [100, 100, 1400, 900]);
    
    % Residual history (log scale)
    subplot(2, 3, 1);
    equations = fieldnames(residHist);
    hold on;
    
    for i = 1:length(equations)
        residuals = residHist.(equations{i});
        iterations = 1:length(residuals);
        semilogy(iterations, residuals, 'LineWidth', 1.5, ...
                 'DisplayName', strrep(equations{i}, '_', ' '));
    end
    
    xlabel('Iteration', 'Interpreter', 'latex');
    ylabel('Residual', 'Interpreter', 'latex');
    title('Residual History', 'Interpreter', 'latex');
    legend('Location', 'best', 'Interpreter', 'latex');
    grid on;
    
    % Mass flow history
    subplot(2, 3, 2);
    iterations = 1:length(massFlow.inletMassFlow);
    plot(iterations, massFlow.inletMassFlow, 'b-', 'LineWidth', 1.5, ...
         'DisplayName', 'Inlet');
    hold on;
    plot(iterations, massFlow.outletMassFlow, 'r--', 'LineWidth', 1.5, ...
         'DisplayName', 'Outlet');
    
    xlabel('Iteration', 'Interpreter', 'latex');
    ylabel('Mass flow rate (kg/s)', 'Interpreter', 'latex');
    title('Mass Flow Conservation', 'Interpreter', 'latex');
    legend('Location', 'best', 'Interpreter', 'latex');
    grid on;
    
    % Mass imbalance history
    subplot(2, 3, 3);
    imbalance = abs(massFlow.inletMassFlow - massFlow.outletMassFlow) ./ ...
                massFlow.inletMassFlow;
    semilogy(iterations, imbalance*100, 'k-', 'LineWidth', 1.5);
    
    xlabel('Iteration', 'Interpreter', 'latex');
    ylabel('Mass imbalance (\%)', 'Interpreter', 'latex');
    title('Mass Conservation Error', 'Interpreter', 'latex');
    grid on;
    
    % Monitored quantities
    quantities = fieldnames(monQty);
    numQty = length(quantities);
    
    for i = 1:min(numQty, 3)
        subplot(2, 3, 3+i);
        
        values = monQty.(quantities{i});
        iterations = 1:length(values);
        
        plot(iterations, values, 'LineWidth', 1.5);
        xlabel('Iteration', 'Interpreter', 'latex');
        ylabel(strrep(quantities{i}, '_', ' '), 'Interpreter', 'latex');
        title(['Monitored: ' strrep(quantities{i}, '_', ' ')], ...
              'Interpreter', 'latex');
        grid on;
    end
    
    sgtitle('Convergence Monitoring Dashboard', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
end

function statusStr = convergenceStatus(isConverged)
    % Convert boolean to convergence status string
    if isConverged
        statusStr = 'CONVERGED';
    else
        statusStr = 'NOT CONVERGED';
    end
end
