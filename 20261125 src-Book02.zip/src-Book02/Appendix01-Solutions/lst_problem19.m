%% lst_problem19.m
% CORLEO hybrid wheeled-legged rover: terrain-adaptive locomotion with mode transitions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:problem19
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% ========================================================================
%  Problem 19: CORLEO Hybrid Wheeled-Legged Vehicle Control
%  Quadrupedal Walking with Wheel Rolling and Obstacle Climbing
%  Author: Dr Yi Chen, Newcastle University
%  Purpose: Terrain classification, mode selection (wheel/leg/hybrid),
%           gait generation, IK, stability control, energy optimization
%  MATLAB Version: R2023b or later
%  Required Toolboxes: Robotics System Toolbox, Optimization Toolbox
%  Date: January 2024
%  Version: 3.1
%% ========================================================================

clear all; close all; clc;
format compact;

fprintf('========================================================================\n');
fprintf('  CORLEO Hybrid Wheeled-Legged Vehicle Control\n');
fprintf('  120 kg, 4 legs (3-DoF each), 4 wheels (0.3 m diameter)\n');
fprintf('  Terrain-Adaptive Locomotion: Flat Rolling + Obstacle Climbing\n');
fprintf('========================================================================\n\n');

%% Step 1: Vehicle parameters
fprintf('Step 1: Defining CORLEO vehicle parameters...\n');

vehicle = struct();
vehicle.mass = 120;             % kg (body + payload)
vehicle.g = 9.81;               % m/s^2 (Earth gravity; use 1.62 for Moon, 3.71 for Mars)

% Body dimensions
vehicle.body_length = 1.2;      % m
vehicle.body_width = 0.8;       % m
vehicle.body_height = 0.4;      % m
vehicle.CoM_height = 0.60;      % m (nominal, above ground)

% Leg geometry (each leg: hip-roll, hip-pitch, knee)
vehicle.hip_offset_x = 0.5;     % m (fore/aft distance from body center)
vehicle.hip_offset_y = 0.4;     % m (lateral distance from centerline)
vehicle.thigh_length = 0.30;    % m (hip to knee)
vehicle.shank_length = 0.35;    % m (knee to foot)
vehicle.leg_reach_max = 0.65;   % m (full extension)
vehicle.leg_reach_min = 0.20;   % m (fully retracted)

% Wheel parameters
vehicle.wheel_radius = 0.15;    % m
vehicle.wheel_width = 0.08;     % m
vehicle.mu_wheel = 0.7;         % Friction coefficient (wheel-ground, hard surface)
vehicle.mu_leg = 0.8;           % Friction coefficient (foot-ground)

% Actuator limits
vehicle.tau_hip_max = 150;      % Nm (hip-roll and hip-pitch)
vehicle.tau_knee_max = 120;     % Nm
vehicle.tau_wheel_max = 20;     % Nm (per wheel motor)

fprintf('  Vehicle mass: %.0f kg, body %.1f x %.1f x %.1f m\n', ...
        vehicle.mass, vehicle.body_length, vehicle.body_width, vehicle.body_height);
fprintf('  Legs: thigh %.2f m, shank %.2f m, total reach %.2f m\n', ...
        vehicle.thigh_length, vehicle.shank_length, vehicle.leg_reach_max);
fprintf('  Wheels: radius %.2f m, friction mu = %.1f\n\n', ...
        vehicle.wheel_radius, vehicle.mu_wheel);

%% Step 2: Terrain generation (heightmap)
fprintf('Step 2: Generating synthetic terrain heightmap...\n');

% Create 20 m x 20 m terrain with obstacles
terrain_size = 20;              % m (square terrain)
grid_res = 0.10;                % m (grid resolution: 10 cm cells)
x_terrain = 0:grid_res:terrain_size;
y_terrain = 0:grid_res:terrain_size;
[X_terrain, Y_terrain] = meshgrid(x_terrain, y_terrain);

% Base terrain: slight slope + random roughness
slope_angle = 5;                % degrees (gentle slope)
h_base = tand(slope_angle) * X_terrain + 0.1 * randn(size(X_terrain));

% Add obstacles (rocks)
n_obstacles = 15;
obstacles = [];
for i = 1:n_obstacles
    % Random obstacle location
    obs_x = terrain_size * rand();
    obs_y = terrain_size * rand();
    obs_height = 0.20 + 0.30 * rand();  % m (0.20 to 0.50 m tall)
    obs_radius = 0.3 + 0.3 * rand();    % m (0.3 to 0.6 m wide)
    
    % Add Gaussian bump to heightmap
    dist = sqrt((X_terrain - obs_x).^2 + (Y_terrain - obs_y).^2);
    h_base = h_base + obs_height * exp(-(dist / obs_radius).^2);
    
    obstacles = [obstacles; obs_x, obs_y, obs_height, obs_radius];
end

Z_terrain = h_base;

fprintf('  Terrain: %.0f x %.0f m, resolution %.2f m\n', terrain_size, terrain_size, grid_res);
fprintf('  Obstacles: %d rocks (height 0.20-0.50 m)\n', n_obstacles);
fprintf('  Base slope: %.1f degrees\n\n', slope_angle);

%% Step 3: Path planning (straight line with obstacle avoidance)
fprintf('Step 3: Planning path from start to goal...\n');

% Start and goal positions
start_pos = [2, 10];            % m [x, y]
goal_pos = [18, 10];            % m [x, y]

% Simple A* path planning (simplified: straight line if clear, detour around obstacles)
% For demonstration, use direct path
path = [linspace(start_pos(1), goal_pos(1), 50); ...
        linspace(start_pos(2), goal_pos(2), 50)]';

fprintf('  Path: start [%.1f, %.1f] to goal [%.1f, %.1f]\n', ...
        start_pos(1), start_pos(2), goal_pos(1), goal_pos(2));
fprintf('  Path length: %.1f m (straight line)\n', norm(goal_pos - start_pos));
fprintf('  Waypoints: %d\n\n', size(path, 1));

%% Step 4: Terrain classification and mode selection
fprintf('Step 4: Classifying terrain and selecting locomotion modes...\n');

% For each waypoint, evaluate local terrain
modes = cell(size(path, 1), 1);
terrain_slope = zeros(size(path, 1), 1);
terrain_roughness = zeros(size(path, 1), 1);

for i = 1:size(path, 1)
    x_pos = path(i, 1);
    y_pos = path(i, 2);
    
    % Find local terrain window (1 m x 1 m around position)
    idx_x = find(abs(x_terrain - x_pos) < 0.5);
    idx_y = find(abs(y_terrain - y_pos) < 0.5);
    
    if ~isempty(idx_x) && ~isempty(idx_y)
        local_h = Z_terrain(idx_y, idx_x);
        
        % Compute slope (gradient)
        [Gx, Gy] = gradient(local_h, grid_res);
        slope_mag = sqrt(mean(Gx(:).^2 + Gy(:).^2));
        terrain_slope(i) = atand(slope_mag);
        
        % Compute roughness (std dev of height)
        terrain_roughness(i) = std(local_h(:));
        
        % Mode selection rules
        if terrain_slope(i) < 10 && terrain_roughness(i) < 0.05
            modes{i} = 'wheeled';
        elseif terrain_slope(i) < 20 && terrain_roughness(i) < 0.12
            modes{i} = 'hybrid';
        else
            modes{i} = 'legged';
        end
    else
        modes{i} = 'wheeled';  % Default
    end
end

% Count modes
n_wheeled = sum(strcmp(modes, 'wheeled'));
n_hybrid = sum(strcmp(modes, 'hybrid'));
n_legged = sum(strcmp(modes, 'legged'));

fprintf('  Terrain analysis completed for %d waypoints.\n', size(path, 1));
fprintf('  Mode distribution: Wheeled %d%%, Hybrid %d%%, Legged %d%%\n', ...
        round(100*n_wheeled/length(modes)), ...
        round(100*n_hybrid/length(modes)), ...
        round(100*n_legged/length(modes)));
fprintf('  Average slope: %.1f deg, max: %.1f deg\n', ...
        mean(terrain_slope), max(terrain_slope));
fprintf('  Average roughness: %.3f m, max: %.3f m\n\n', ...
        mean(terrain_roughness), max(terrain_roughness));

%% Step 5: Gait generation (simplified crawl gait for legged mode)
fprintf('Step 5: Generating quadrupedal crawl gait...\n');

% Crawl gait parameters
gait = struct();
gait.cycle_time = 4.0;          % s (one full cycle: all 4 legs step)
gait.duty_factor = 0.75;        % Fraction of cycle each foot on ground
gait.step_length = 0.25;        % m (forward distance per step)
gait.step_height = 0.08;        % m (swing foot clearance)

% Phase offsets (sequential lifting: LF, RR, RF, LR)
gait.phases = [0, 0.25, 0.50, 0.75];  % Normalized phase [0, 1]

fprintf('  Crawl gait: cycle time %.1f s, duty factor %.2f\n', ...
        gait.cycle_time, gait.duty_factor);
fprintf('  Step length %.2f m, clearance %.2f m\n', ...
        gait.step_length, gait.step_height);
fprintf('  Walking speed: %.3f m/s (step_length / cycle_time)\n\n', ...
        gait.step_length / gait.cycle_time);

%% Step 6: Inverse kinematics (simplified 2D per leg)
fprintf('Step 6: Setting up inverse kinematics solver...\n');

% Function to compute leg IK (analytical, 2D sagittal plane)
% Inputs: foot_pos [x, z] relative to hip (forward, vertical)
% Outputs: [theta_hip_pitch, theta_knee] in radians
compute_leg_ik = @(foot_pos) compute_2D_leg_ik(foot_pos, ...
    vehicle.thigh_length, vehicle.shank_length);

% Test IK
test_foot = [0.4, -0.5];  % 0.4 m forward, 0.5 m below hip
[theta_hp, theta_k] = compute_leg_ik(test_foot);
fprintf('  IK test: foot [%.2f, %.2f] -> hip_pitch %.1f deg, knee %.1f deg\n', ...
        test_foot(1), test_foot(2), rad2deg(theta_hp), rad2deg(theta_k));

% Verify forward kinematics
L1 = vehicle.thigh_length;
L2 = vehicle.shank_length;
knee_pos = [L1*sin(theta_hp), -L1*cos(theta_hp)];
foot_calc = knee_pos + [L2*sin(theta_hp + theta_k), -L2*cos(theta_hp + theta_k)];
error = norm(foot_calc - test_foot);
fprintf('  FK verification: error %.4f m (should be near zero)\n\n', error);

%% Step 7: Simulate traverse with mode transitions
fprintf('Step 7: Simulating vehicle traverse along path...\n');

% Time simulation
dt = 0.1;                       % s (simulation timestep: 10 Hz)
speeds = struct('wheeled', 0.5, 'hybrid', 0.3, 'legged', 0.15);  % m/s

% Initialize state
pos_current = start_pos;
waypoint_idx = 1;
time_elapsed = 0;
positions = [];
times = [];
power_log = [];
mode_log = {};

fprintf('  Starting traverse simulation...\n');
tic;

while waypoint_idx <= size(path, 1)
    % Current waypoint and mode
    waypoint = path(waypoint_idx, :);
    mode = modes{waypoint_idx};
    speed = speeds.(mode);
    
    % Move towards waypoint
    direction = waypoint - pos_current;
    dist_to_waypoint = norm(direction);
    
    if dist_to_waypoint < 0.05  % Reached waypoint (5 cm threshold)
        waypoint_idx = waypoint_idx + 1;
        continue;
    end
    
    % Update position
    step_dist = min(speed * dt, dist_to_waypoint);
    pos_current = pos_current + step_dist * direction / dist_to_waypoint;
    
    % Estimate power consumption (simplified)
    if strcmp(mode, 'wheeled')
        power = 160;  % W (wheels + electronics)
    elseif strcmp(mode, 'hybrid')
        power = 200;  % W (wheels + leg suspension)
    else  % legged
        power = 260;  % W (leg actuation)
    end
    
    % Log state
    positions = [positions; pos_current];
    times = [times; time_elapsed];
    power_log = [power_log; power];
    mode_log{end+1} = mode;
    
    time_elapsed = time_elapsed + dt;
    
    if mod(waypoint_idx, 10) == 0
        fprintf('    Waypoint %d/%d, position [%.1f, %.1f], mode: %s\n', ...
                waypoint_idx, size(path,1), pos_current(1), pos_current(2), mode);
    end
end

sim_time_real = toc;
fprintf('  Simulation completed in %.2f seconds (real time).\n', sim_time_real);
fprintf('  Virtual time: %.1f s (%.1f minutes)\n', time_elapsed, time_elapsed/60);
fprintf('  Distance traveled: %.1f m\n', norm(goal_pos - start_pos));
fprintf('  Average speed: %.3f m/s\n\n', norm(goal_pos - start_pos) / time_elapsed);

%% Step 8: Energy consumption analysis
fprintf('Step 8: Analyzing energy consumption...\n');

% Total energy
energy_total = trapz(times, power_log) / 1000;  % kJ (integrate power over time)
distance_total = norm(goal_pos - start_pos);    % m
energy_per_meter = energy_total / distance_total;  % kJ/m

fprintf('  Total energy: %.2f kJ\n', energy_total);
fprintf('  Distance: %.1f m\n', distance_total);
fprintf('  Specific energy: %.3f kJ/m\n', energy_per_meter);
fprintf('  Average power: %.0f W\n', mean(power_log));

% Compare to pure modes
energy_wheeled_only = 160 * (distance_total / 0.5) / 1000;  % kJ (if all wheeled)
energy_legged_only = 260 * (distance_total / 0.15) / 1000;  % kJ (if all legged)

fprintf('  Comparison:\n');
fprintf('    Pure wheeled: %.2f kJ (if entire path at 0.5 m/s, 160 W)\n', energy_wheeled_only);
fprintf('    Pure legged: %.2f kJ (if entire path at 0.15 m/s, 260 W)\n', energy_legged_only);
fprintf('    Hybrid (actual): %.2f kJ (%.0f%% of pure legged)\n', ...
        energy_total, 100 * energy_total / energy_legged_only);

% Battery range estimation
battery_capacity = 4;           % kWh
range_estimate = battery_capacity * 3600 / (energy_per_meter * 1000);  % m
fprintf('  Estimated range: %.1f km (from 4 kWh battery)\n\n', range_estimate / 1000);

%% Step 9: Stability analysis (simplified)
fprintf('Step 9: Analyzing stability margins (simplified)...\n');

% For demonstration: assume rectangular support polygon
% Dimensions based on leg stance (simplified)
stance_length = 2 * vehicle.hip_offset_x;  % m (fore-aft)
stance_width = 2 * vehicle.hip_offset_y;   % m (lateral)

% CoM must stay within polygon
% Simplified: CoM at body center, margin is distance to edge
margin_x = vehicle.hip_offset_x;  % m (fore/aft margin)
margin_y = vehicle.hip_offset_y;  % m (lateral margin)
margin_min = min(margin_x, margin_y);

fprintf('  Support polygon: %.2f m (length) x %.2f m (width)\n', ...
        stance_length, stance_width);
fprintf('  CoM margins: X  %.2f m, Y  %.2f m\n', margin_x, margin_y);
fprintf('  Minimum margin: %.2f m\n', margin_min);

if margin_min > 0.05
    fprintf('  Status: STABLE (margin > 0.05 m safety threshold)\n\n');
else
    fprintf('  Status: MARGINAL (consider wider stance)\n\n');
end

%% Step 10: Visualizations
fprintf('Step 10: Generating visualizations...\n');

figure('Name', 'CORLEO Terrain and Path', 'Position', [50, 50, 1400, 600]);

% Subplot 1: 3D terrain with path
subplot(1, 2, 1);
surf(X_terrain, Y_terrain, Z_terrain, 'EdgeColor', 'none', 'FaceAlpha', 0.7);
hold on;
plot3(path(:,1), path(:,2), interp2(X_terrain, Y_terrain, Z_terrain, path(:,1), path(:,2)) + 0.1, ...
      'r-', 'LineWidth', 3);
plot3(start_pos(1), start_pos(2), interp2(X_terrain, Y_terrain, Z_terrain, start_pos(1), start_pos(2)) + 0.2, ...
      'go', 'MarkerSize', 12, 'MarkerFaceColor', 'g');
plot3(goal_pos(1), goal_pos(2), interp2(X_terrain, Y_terrain, Z_terrain, goal_pos(1), goal_pos(2)) + 0.2, ...
      'rs', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
xlabel('X (m)', 'Interpreter', 'latex');
ylabel('Y (m)', 'Interpreter', 'latex');
zlabel('Height (m)', 'Interpreter', 'latex');
title('Terrain Heightmap and Planned Path', 'Interpreter', 'latex');
legend({'Terrain', 'Path', 'Start', 'Goal'}, 'Interpreter', 'latex', 'Location', 'best');
colorbar;
colormap('terrain');
view([-30, 30]);
grid on;
axis equal;

% Subplot 2: Locomotion mode along path
subplot(1, 2, 2);
mode_numeric = zeros(size(path, 1), 1);
for i = 1:length(modes)
    switch modes{i}
        case 'wheeled'
            mode_numeric(i) = 1;
        case 'hybrid'
            mode_numeric(i) = 2;
        case 'legged'
            mode_numeric(i) = 3;
    end
end
distance_along_path = cumsum([0; sqrt(sum(diff(path).^2, 2))]);
plot(distance_along_path, mode_numeric, 'b-', 'LineWidth', 2);
hold on;
yline(1, 'g-', 'Wheeled');
yline(2, 'y-', 'Hybrid');
yline(3, 'r-', 'Legged');
xlabel('Distance along path (m)', 'Interpreter', 'latex');
ylabel('Locomotion Mode', 'Interpreter', 'latex');
title('Mode Selection vs. Distance', 'Interpreter', 'latex');
yticks([1, 2, 3]);
yticklabels({'Wheeled', 'Hybrid', 'Legged'});
grid on;
xlim([0, max(distance_along_path)]);
ylim([0.5, 3.5]);

sgtitle('\textbf{CORLEO Hybrid Vehicle: Terrain-Adaptive Locomotion}', 'Interpreter', 'latex', 'FontSize', 14);

% Additional figure: Power and energy
figure('Name', 'Energy Analysis', 'Position', [100, 100, 1200, 400]);

subplot(1, 2, 1);
plot(times, power_log, 'b-', 'LineWidth', 1.5);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Power (W)', 'Interpreter', 'latex');
title('Instantaneous Power Consumption', 'Interpreter', 'latex');
grid on;

subplot(1, 2, 2);
cumulative_energy = cumtrapz(times, power_log) / 1000;  % kJ
plot(times, cumulative_energy, 'r-', 'LineWidth', 1.5);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Cumulative Energy (kJ)', 'Interpreter', 'latex');
title('Energy Consumption Over Time', 'Interpreter', 'latex');
grid on;

fprintf('  Visualizations completed.\n\n');

%% Summary
fprintf('========================================================================\n');
fprintf('  SUMMARY - Problem 19: CORLEO Hybrid Vehicle Control\n');
fprintf('========================================================================\n');
fprintf('  Mission:\n');
fprintf('    Traverse: %.1f m from [%.1f, %.1f] to [%.1f, %.1f]\n', ...
        distance_total, start_pos(1), start_pos(2), goal_pos(1), goal_pos(2));
fprintf('    Duration: %.1f minutes (%.0f seconds)\n', time_elapsed/60, time_elapsed);
fprintf('    Average speed: %.3f m/s\n', distance_total / time_elapsed);
fprintf('\n');
fprintf('  Locomotion Modes:\n');
fprintf('    Wheeled: %d%% of path (flat terrain, 0.5 m/s, 160 W)\n', round(100*n_wheeled/length(modes)));
fprintf('    Hybrid: %d%% of path (moderate terrain, 0.3 m/s, 200 W)\n', round(100*n_hybrid/length(modes)));
fprintf('    Legged: %d%% of path (rough/obstacles, 0.15 m/s, 260 W)\n', round(100*n_legged/length(modes)));
fprintf('\n');
fprintf('  Energy Performance:\n');
fprintf('    Total energy: %.2f kJ (%.2f Wh)\n', energy_total, energy_total * 0.278);
fprintf('    Specific energy: %.3f kJ/m\n', energy_per_meter);
fprintf('    Efficiency vs. pure legged: %.0f%% energy savings\n', ...
        100 * (1 - energy_total / energy_legged_only));
fprintf('    Estimated range: %.1f km (4 kWh battery)\n', range_estimate / 1000);
fprintf('\n');
fprintf('  Stability:\n');
fprintf('    Support polygon: %.2f x %.2f m (static stance)\n', stance_length, stance_width);
fprintf('    Minimum CoM margin: %.2f m (target: >0.05 m)\n', margin_min);
fprintf('    Status: %s\n', char(margin_min > 0.05)*'STABLE' + char(margin_min <= 0.05)*'REVIEW');
fprintf('\n');
fprintf('Problem 19 completed successfully.\n');
fprintf('========================================================================\n');

%% Helper function: 2D leg inverse kinematics
function [theta_hip_pitch, theta_knee] = compute_2D_leg_ik(foot_pos, L1, L2)
    % Analytical IK for 2-link leg in sagittal plane
    % foot_pos: [x, z] (forward, vertical) relative to hip
    % L1: thigh length, L2: shank length
    % Returns: [theta_hip_pitch, theta_knee] in radians
    
    x = foot_pos(1);
    z = foot_pos(2);
    r = sqrt(x^2 + z^2);
    
    % Check reachability
    if r > (L1 + L2) || r < abs(L1 - L2)
        warning('IK: Target unreachable, clamping to workspace boundary');
        r = max(min(r, L1 + L2 - 0.01), abs(L1 - L2) + 0.01);
    end
    
    % Knee angle (law of cosines)
    cos_knee = (L1^2 + L2^2 - r^2) / (2 * L1 * L2);
    cos_knee = max(min(cos_knee, 1), -1);  % Clamp to [-1, 1]
    theta_knee = acos(cos_knee);  % Always positive (0 to pi)
    
    % Hip angle
    alpha = atan2(x, -z);  % Angle to target
    beta = asin(L2 * sin(theta_knee) / r);  % Offset due to knee
    theta_hip_pitch = alpha - beta;
end
