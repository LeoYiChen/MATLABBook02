%% listing_21.m
% Convergence rate analysis for numerical differentiation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : listing_21
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Convergence rate analysis for numerical differentiation


analyseDerivativeConvergence();

% Local functions (moved to end so this listing is a valid MATLAB script)
function analyseDerivativeConvergence()
    % ANALYSEDERIVATIVECONVERGENCE Study finite difference accuracy
    
    fprintf('\\textbf{Finite Difference Convergence Analysis}\n');
    fprintf('================================================\n\n');
    
    % Test function: f(x) = sin(x), f'(x) = cos(x)
    f = @(x) sin(x);
    fPrime = @(x) cos(x);
    
    x0 = pi/4;  % Evaluation point
    exactDerivative = fPrime(x0);
    
    % Test various step sizes
    hValues = 10.^(-1:-1:-15);
    numH = length(hValues);
    
    % Three finite difference schemes
    forwardErrors = zeros(numH, 1);
    centralErrors = zeros(numH, 1);
    complexErrors = zeros(numH, 1);
    
    for i = 1:numH
        h = hValues(i);
        
        % Forward difference: O(h)
        forwardDiff = (f(x0 + h) - f(x0)) / h;
        forwardErrors(i) = abs(forwardDiff - exactDerivative);
        
        % Central difference: O(h^2)
        centralDiff = (f(x0 + h) - f(x0 - h)) / (2*h);
        centralErrors(i) = abs(centralDiff - exactDerivative);
        
        % Complex step: O(h^2) without cancellation (1i, not loop index i)
        complexDiff = imag(f(x0 + 1i*h)) / h;
        complexErrors(i) = abs(complexDiff - exactDerivative);
    end
    
    % Find optimal step size for each method
    [minForward, idxForward] = min(forwardErrors);
    [minCentral, idxCentral] = min(centralErrors);
    [minComplex, idxComplex] = min(complexErrors);
    
    fprintf('Exact derivative at x = ¦Ð/4: %.15f\n\n', exactDerivative);
    
    fprintf('Forward Difference:\n');
    fprintf('  Minimum error: %.2e at h = %.2e\n', ...
        minForward, hValues(idxForward));
    
    fprintf('\nCentral Difference:\n');
    fprintf('  Minimum error: %.2e at h = %.2e\n', ...
        minCentral, hValues(idxCentral));
    
    fprintf('\nComplex Step:\n');
    fprintf('  Minimum error: %.2e at h = %.2e\n\n', ...
        minComplex, hValues(idxComplex));
    
    % Estimate convergence rates (where error decreases monotonically)
    idxRangeForward = 1:idxForward;
    if length(idxRangeForward) > 2
        pForward = polyfit(log10(hValues(idxRangeForward)), ...
            log10(forwardErrors(idxRangeForward)), 1);
        fprintf('Forward difference convergence rate: O(h^%.2f)\n', ...
            pForward(1));
    end
    
    idxRangeCentral = 1:idxCentral;
    if length(idxRangeCentral) > 2
        pCentral = polyfit(log10(hValues(idxRangeCentral)), ...
            log10(centralErrors(idxRangeCentral)), 1);
        fprintf('Central difference convergence rate: O(h^%.2f)\n', ...
            pCentral(1));
    end
    
    % Visualise convergence (loglog first, then hold; 1i not loop index i)
    figure('Position', [100, 100, 800, 600]);
    loglog(hValues, forwardErrors, 'b-o', 'LineWidth', 2, ...
        'DisplayName', 'Forward Difference');
    hold on;
    loglog(hValues, centralErrors, 'r-s', 'LineWidth', 2, ...
        'DisplayName', 'Central Difference');
    loglog(hValues, complexErrors, 'g-^', 'LineWidth', 2, ...
        'DisplayName', 'Complex Step');
    
    % Reference lines for convergence rates
    loglog(hValues, hValues, 'k-', 'DisplayName', 'O(h)');
    loglog(hValues, hValues.^2, 'k:', 'DisplayName', 'O(h^2)');
    
    xlabel('Step Size $h$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Absolute Error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Finite Difference Convergence', 'Interpreter', 'latex', ...
        'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest', ...
        'FontSize', 10);
    grid on;
    set(gca, 'FontSize', 10);
end
