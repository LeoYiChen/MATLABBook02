%% chapter_Math_lab14_plotting.m
% Advanced Plotting with Dual Y-Axes
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab14_plotting
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory
Lab14_AdvancedPlottingDualYAxes();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab14_AdvancedPlottingDualYAxes()
    % LAB14_ADVANCEDPLOTTINGDUALYAXES Master dual y-axis visualisation
    %   Professional multi-scale plotting techniques
    
    fprintf('\\textbf{Laboratory 14: Advanced Plotting with Dual Y-Axes}\n');
    fprintf('===========================================================\n\n');
    
    % Task 1: Basic dual y-axis plotting
    demonstrateBasicDualAxes();
    
    % Task 2: Real-world example - climate data
    plotClimateData();
    
    % Task 3: Financial data visualisation
    plotFinancialData();
    
    % Task 4: Scientific measurement with error bars
    plotScientificData();
    
    % Task 5: Multiple datasets with annotations
    createPublicationFigure();
end

function demonstrateBasicDualAxes()
    % DEMONSTRATEBASICDUALAXES Introduce yyaxis functionality
    
    fprintf('\\textbf{Task 1: Basic Dual Y-Axis Plotting}\n');
    fprintf('--------\n\n');
    
    % Generate sample data with different scales
    t = 0:0.1:10;
    
    % Signal 1: Small amplitude oscillation
    y1 = sin(2*pi*0.5*t);
    
    % Signal 2: Exponential growth (much larger scale)
    y2 = exp(0.3*t);
    
    fprintf('Dataset Properties:\n');
    fprintf('  Signal 1 (sine): Range = [%.2f, %.2f]\n', min(y1), max(y1));
    fprintf('  Signal 2 (exponential): Range = [%.2f, %.2f]\n', min(y2), max(y2));
    fprintf('  Scale ratio: %.2f:1\n\n', max(y2)/max(y1));
    
    % Create figure with dual axes
    figure('Position', [100, 100, 1200, 800], 'Name', 'Dual Y-Axes Basics');
    
    % Subplot 1: Single axis (poor visualisation)
    subplot(2, 2, 1);
    plot(t, y1, 'b-', 'LineWidth', 2, 'DisplayName', 'Signal 1');
    hold on;
    plot(t, y2, 'r-', 'LineWidth', 2, 'DisplayName', 'Signal 2');
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Single Y-Axis (Poor)', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'northwest');
    grid on;
    
    % Subplot 2: Dual y-axes (good visualisation)
    subplot(2, 2, 2);
    yyaxis left
    plot(t, y1, 'b-', 'LineWidth', 2);
    ylabel('Signal 1 (sine)', 'Interpreter', 'latex', 'FontSize', 12);
    ylim([-1.5, 1.5]);
    
    yyaxis right
    plot(t, y2, 'r-', 'LineWidth', 2);
    ylabel('Signal 2 (exponential)', 'Interpreter', 'latex', 'FontSize', 12);
    
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Dual Y-Axes (Good)', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 3: Customized styling
    subplot(2, 2, 3);
    yyaxis left
    plot(t, y1, 'b-', 'LineWidth', 2.5);
    ylabel('Oscillation [units]', 'Interpreter', 'latex', 'FontSize', 12, ...
        'Color', 'b', 'FontWeight', 'bold');
    ylim([-1.5, 1.5]);
    set(gca, 'YColor', 'b', 'FontSize', 11);
    
    yyaxis right
    plot(t, y2, 'r-', 'LineWidth', 2.5);
    ylabel('Growth [units]', 'Interpreter', 'latex', 'FontSize', 12, ...
        'Color', 'r', 'FontWeight', 'bold');
    set(gca, 'YColor', 'r', 'FontSize', 11);
    
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Custom Styling', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 4: With annotations
    subplot(2, 2, 4);
    yyaxis left
    h1 = plot(t, y1, 'b-', 'LineWidth', 2);
    ylabel('Signal 1', 'Interpreter', 'latex', 'FontSize', 12);
    ylim([-1.5, 1.5]);
    
    % Annotate peak
    [max_val, max_idx] = max(y1);
    plot(t(max_idx), max_val, 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
    text(t(max_idx), max_val + 0.2, sprintf('Peak: %.2f', max_val), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, 'Color', 'b');
    
    yyaxis right
    h2 = plot(t, y2, 'r-', 'LineWidth', 2);
    ylabel('Signal 2', 'Interpreter', 'latex', 'FontSize', 12);
    
    % Annotate crossing point (arbitrary)
    cross_idx = 60;
    plot(t(cross_idx), y2(cross_idx), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    text(t(cross_idx), y2(cross_idx) * 1.2, sprintf('t=%.1f s', t(cross_idx)), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, 'Color', 'r');
    
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('With Annotations', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    fprintf('Four visualisation approaches demonstrated:\n');
    fprintf('  1. Single axis - Signal 1 barely visible\n');
    fprintf('  2. Dual axes - Both signals clear\n');
    fprintf('  3. Custom styling - Enhanced readability\n');
    fprintf('  4. Annotations - Highlighted features\n\n');
end

function plotClimateData()
    % PLOTCLIMATEDATA Real-world climate data example
    
    fprintf('\\textbf{Task 2: Climate Data visualisation}\n');
    fprintf('--------\n\n');
    
    % Simulate monthly climate data for a year
    months = 1:12;
    month_names = {'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', ...
                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'};
    
    % Temperature (°C) - typical temperate climate
    temperature = [2, 4, 8, 13, 18, 22, 25, 24, 20, 14, 8, 3];
    
    % Precipitation (mm) - higher in winter/spring
    precipitation = [75, 60, 65, 55, 70, 45, 30, 35, 50, 80, 90, 85];
    
    fprintf('Climate Data Summary:\n');
    fprintf('  Temperature range: %.1f°C to %.1f°C\n', min(temperature), max(temperature));
    fprintf('  Annual mean temperature: %.1f°C\n', mean(temperature));
    fprintf('  Total annual precipitation: %d mm\n', sum(precipitation));
    fprintf('  Average monthly precipitation: %.1f mm\n\n', mean(precipitation));
    
    % Create comprehensive climate plot
    figure('Position', [150, 150, 1400, 600], 'Name', 'Climate Data Analysis');
    
    % Main plot
    subplot(1, 2, 1);
    yyaxis left
    
    % Temperature as line with markers
    h_temp = plot(months, temperature, 'r-o', 'LineWidth', 2.5, ...
        'MarkerSize', 8, 'MarkerFaceColor', 'r');
    ylabel('Temperature (°C)', 'Interpreter', 'latex', 'FontSize', 13, ...
        'Color', 'r', 'FontWeight', 'bold');
    ylim([0, 30]);
    set(gca, 'YColor', 'r');
    
    % Add temperature reference lines
    hold on;
    yline(mean(temperature), 'r-', 'Mean Temp', 'LineWidth', 1.5, ...
        'LabelHorizontalAlignment', 'left', 'FontSize', 10);
    
    yyaxis right
    
    % Precipitation as bars
    h_precip = bar(months, precipitation, 'FaceColor', [0.2, 0.4, 0.8], ...
        'EdgeColor', 'none', 'FaceAlpha', 0.7);
    ylabel('Precipitation (mm)', 'Interpreter', 'latex', 'FontSize', 13, ...
        'Color', 'b', 'FontWeight', 'bold');
    ylim([0, 120]);
    set(gca, 'YColor', 'b');
    
    % Formatting
    xlabel('Month', 'Interpreter', 'latex', 'FontSize', 13);
    set(gca, 'XTick', months, 'XTickLabel', month_names, 'FontSize', 11);
    title('Annual Climate Pattern', 'Interpreter', 'latex', 'FontSize', 14, ...
        'FontWeight', 'bold');
    grid on;
    
    % Add legend
    legend([h_temp, h_precip], {'Temperature', 'Precipitation'}, ...
        'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 11);
    
    % Statistical summary subplot
    subplot(1, 2, 2);
    
    % Compute seasonal averages
    seasons = {'Winter', 'Spring', 'Summer', 'Autumn'};
    season_months = {[12, 1, 2], [3, 4, 5], [6, 7, 8], [9, 10, 11]};
    
    season_temp = zeros(4, 1);
    season_precip = zeros(4, 1);
    
    for s = 1:4
        idx = season_months{s};
        idx(idx > 12) = idx(idx > 12) - 12;  % Wrap December
        season_temp(s) = mean(temperature(idx));
        season_precip(s) = mean(precipitation(idx));
    end
    
    yyaxis left
    bar(1:4, season_temp, 'FaceColor', [0.8, 0.3, 0.3], 'EdgeColor', 'k', ...
        'LineWidth', 1.5);
    ylabel('Avg Temperature (°C)', 'Interpreter', 'latex', 'FontSize', 12, 'Color', 'r');
    ylim([0, 25]);
    set(gca, 'YColor', 'r');
    
    yyaxis right
    plot(1:4, season_precip, 'b-o', 'LineWidth', 2.5, 'MarkerSize', 10, ...
        'MarkerFaceColor', 'b');
    ylabel('Avg Precipitation (mm)', 'Interpreter', 'latex', 'FontSize', 12, 'Color', 'b');
    ylim([0, 100]);
    set(gca, 'YColor', 'b');
    
    xlabel('Season', 'Interpreter', 'latex', 'FontSize', 12);
    set(gca, 'XTick', 1:4, 'XTickLabel', seasons, 'FontSize', 11);
    title('Seasonal Averages', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    fprintf('Seasonal Analysis:\n');
    for s = 1:4
        fprintf('  %s: %.1f°C, %.1f mm\n', seasons{s}, season_temp(s), season_precip(s));
    end
    fprintf('\n');
end

function plotFinancialData()
    % PLOTFINANCIALDATA Stock price and volume visualisation
    
    fprintf('\\textbf{Task 3: Financial Data visualisation}\n');
    fprintf('---------\n\n');
    
    % Simulate stock data over 6 months
    days = 1:120;
    
    % Stock price with trend and volatility
    trend = 100 + 0.2 * days;
    volatility = 5 * sin(2*pi*days/30) + 3*randn(size(days));
    price = trend + volatility;
    price(price < 0) = abs(price(price < 0));  % No negative prices
    
    % Trading volume (inversely correlated with price stability)
    base_volume = 1e6;
    volume = base_volume + 5e5 * abs(volatility) / max(abs(volatility)) + ...
        2e5 * randn(size(days));
    volume(volume < 0) = abs(volume(volume < 0));
    
    fprintf('Stock Data Summary:\n');
    fprintf('  Trading days: %d\n', length(days));
    fprintf('  Starting price: $%.2f\n', price(1));
    fprintf('  Ending price: $%.2f\n', price(end));
    fprintf('  Price change: %.2f%%\n', 100 * (price(end) - price(1)) / price(1));
    fprintf('  Average volume: %.2e shares\n', mean(volume));
    fprintf('  Volatility (std): $%.2f\n\n', std(price));
    
    % Create financial chart
    figure('Position', [200, 200, 1400, 700], 'Name', 'Financial Data');
    
    % Main chart
    subplot(2, 1, 1);
    yyaxis left
    
    % Plot price with moving average
    plot(days, price, 'b-', 'LineWidth', 1.5);
    hold on;
    
    % 20-day moving average
    ma_window = 20;
    price_ma = movmean(price, ma_window);
    plot(days, price_ma, 'r-', 'LineWidth', 2.5);
    
    ylabel('Stock Price (\$)', 'Interpreter', 'latex', 'FontSize', 13, 'Color', 'b');
    set(gca, 'YColor', 'b');
    ylim([min(price)*0.95, max(price)*1.05]);
    
    % Highlight max/min
    [max_price, max_idx] = max(price);
    [min_price, min_idx] = min(price);
    plot(days(max_idx), max_price, 'g^', 'MarkerSize', 12, 'MarkerFaceColor', 'g');
    plot(days(min_idx), min_price, 'rv', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
    
    text(days(max_idx), max_price * 1.02, sprintf('High: $%.2f', max_price), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, 'Color', 'g', 'FontWeight', 'bold');
    text(days(min_idx), min_price * 0.98, sprintf('Low: $%.2f', min_price), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, 'Color', 'r', 'FontWeight', 'bold');
    
    yyaxis right
    
    % Volume as bars
    bar(days, volume, 'FaceColor', [0.7, 0.7, 0.7], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
    ylabel('Volume (shares)', 'Interpreter', 'latex', 'FontSize', 13, 'Color', 'k');
    set(gca, 'YColor', 'k');
    
    xlabel('Trading Day', 'Interpreter', 'latex', 'FontSize', 13);
    title('Stock Price and Trading Volume', 'Interpreter', 'latex', ...
        'FontSize', 14, 'FontWeight', 'bold');
    legend({'Price', sprintf('%d-day MA', ma_window), 'High', 'Low', 'Volume'}, ...
        'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 10);
    grid on;
    
    % Returns analysis
    subplot(2, 1, 2);
    
    % Calculate daily returns
    returns = 100 * diff(price) ./ price(1:end-1);
    
    yyaxis left
    
    % Returns as bars
    colors = returns >= 0;
    bar(days(2:end), returns, 'FaceColor', 'flat', ...
        'CData', [colors, zeros(length(colors), 1), ~colors], 'EdgeColor', 'none');
    ylabel('Daily Return (\%)', 'Interpreter', 'latex', 'FontSize', 13);
    yline(0, 'k-', 'LineWidth', 1.5);
    set(gca, 'YColor', 'k');
    
    yyaxis right
    
    % Cumulative returns
    cumulative_returns = cumsum(returns);
    plot(days(2:end), cumulative_returns, 'b-', 'LineWidth', 2.5);
    ylabel('Cumulative Return (\%)', 'Interpreter', 'latex', 'FontSize', 13, 'Color', 'b');
    set(gca, 'YColor', 'b');
    
    xlabel('Trading Day', 'Interpreter', 'latex', 'FontSize', 13);
    title('Daily and Cumulative Returns', 'Interpreter', 'latex', 'FontSize', 13);
    legend({'Daily Return', 'Zero Line', 'Cumulative Return'}, ...
        'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 10);
    grid on;
    
    % Performance metrics
    fprintf('Performance Metrics:\n');
    fprintf('  Total return: %.2f%%\n', cumulative_returns(end));
    fprintf('  Average daily return: %.3f%%\n', mean(returns));
    fprintf('  Daily volatility (std): %.3f%%\n', std(returns));
    fprintf('  Sharpe ratio (approx): %.3f\n', mean(returns) / std(returns));
    fprintf('  Max drawdown: %.2f%%\n\n', min(cumulative_returns));
end

function plotScientificData()
    % PLOTSCIENTIFICDATA Measurement data with error bars
    
    fprintf('\\textbf{Task 4: Scientific Measurement Data}\n');
    fprintf('---------\n\n');
    
    % Simulate experimental data: reaction rate vs temperature and pH
    temperature = 20:5:80;  % Celsius
    n_points = length(temperature);
    
    % Reaction rate (arbitrary units) - increases with temperature
    rate_mean = 0.5 * exp(0.04 * temperature);
    rate_error = 0.1 * rate_mean + 0.5 * randn(size(rate_mean));
    
    % pH measurement (changes with temperature)
    pH_mean = 7.5 - 0.02 * temperature + 0.5 * sin(temperature / 10);
    pH_error = 0.1 + 0.05 * abs(randn(size(pH_mean)));
    
    fprintf('Experimental Setup:\n');
    fprintf('  Temperature range: %d°C to %d°C\n', min(temperature), max(temperature));
    fprintf('  Number of measurements: %d\n', n_points);
    fprintf('  Reaction rate range: %.2f to %.2f (a.u.)\n', ...
        min(rate_mean), max(rate_mean));
    fprintf('  pH range: %.2f to %.2f\n\n', min(pH_mean), max(pH_mean));
    
    % Create scientific plot
    figure('Position', [250, 250, 1200, 600], 'Name', 'Scientific Measurements');
    
    % Main plot with error bars
    subplot(1, 2, 1);
    yyaxis left
    
    % Reaction rate with error bars
    h_rate = errorbar(temperature, rate_mean, rate_error, 'bo-', ...
        'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'b', 'CapSize', 10);
    ylabel('Reaction Rate (a.u.)', 'Interpreter', 'latex', 'FontSize', 13, ...
        'Color', 'b', 'FontWeight', 'bold');
    set(gca, 'YColor', 'b');
    
    % Fit exponential model
    hold on;
    T_fit = linspace(min(temperature), max(temperature), 100);
    
    % Simple exponential fit: rate = a * exp(b * T)
    log_rate = log(rate_mean);
    p = polyfit(temperature, log_rate, 1);
    rate_fit = exp(p(2)) * exp(p(1) * T_fit);
    
    plot(T_fit, rate_fit, 'b-', 'LineWidth', 2);
    
    yyaxis right
    
    % pH with error bars
    h_pH = errorbar(temperature, pH_mean, pH_error, 'rs-', ...
        'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'r', 'CapSize', 10);
    ylabel('pH', 'Interpreter', 'latex', 'FontSize', 13, 'Color', 'r', ...
        'FontWeight', 'bold');
    set(gca, 'YColor', 'r');
    ylim([min(pH_mean) - max(pH_error)*2, max(pH_mean) + max(pH_error)*2]);
    
    % Add pH reference lines
    yline(7, 'r:', 'Neutral', 'LineWidth', 1.5, 'LabelHorizontalAlignment', 'right', ...
        'FontSize', 9);
    
    xlabel('Temperature (°C)', 'Interpreter', 'latex', 'FontSize', 13);
    title('Reaction Kinetics vs Temperature', 'Interpreter', 'latex', ...
        'FontSize', 14, 'FontWeight', 'bold');
    legend([h_rate, h_pH], {'Reaction Rate', 'pH'}, 'Interpreter', 'latex', ...
        'Location', 'northwest', 'FontSize', 11);
    grid on;
    
    % Residuals analysis
    subplot(1, 2, 2);
    
    % Compute residuals from fit
    rate_fitted = exp(p(2)) * exp(p(1) * temperature);
    residuals = rate_mean - rate_fitted;
    normalized_residuals = residuals ./ rate_error;
    
    yyaxis left
    stem(temperature, residuals, 'b', 'LineWidth', 1.5, 'MarkerFaceColor', 'b');
    hold on;
    yline(0, 'k-', 'LineWidth', 1.5);
    ylabel('Residuals (a.u.)', 'Interpreter', 'latex', 'FontSize', 12, 'Color', 'b');
    set(gca, 'YColor', 'b');
    
    yyaxis right
    plot(temperature, normalized_residuals, 'ro-', 'LineWidth', 2, ...
        'MarkerSize', 8, 'MarkerFaceColor', 'r');
    yline(2, 'r:', '+2σ', 'LineWidth', 1);
    yline(-2, 'r:', '-2σ', 'LineWidth', 1);
    ylabel('Normalized Residuals', 'Interpreter', 'latex', 'FontSize', 12, 'Color', 'r');
    set(gca, 'YColor', 'r');
    
    xlabel('Temperature (°C)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Residuals Analysis', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Statistical analysis
    fprintf('Statistical Analysis:\n');
    fprintf('  Exponential fit: rate = %.3f $\times$ exp(%.4f $\times$ T)\n', exp(p(2)), p(1));
    fprintf('  R-squared: %.4f\n', 1 - sum(residuals.^2) / sum((rate_mean - mean(rate_mean)).^2));
    fprintf('  Mean absolute error: %.3f\n', mean(abs(residuals)));
    fprintf('  Max normalized residual: %.2fσ\n', max(abs(normalized_residuals)));
    
    % Check for outliers
    outliers = abs(normalized_residuals) > 2;
    if any(outliers)
        fprintf('  Warning: %d potential outlier(s) detected\n', sum(outliers));
    else
        fprintf('  No outliers detected (all within 2σ)\n');
    end
    fprintf('\n');
end

function createPublicationFigure()
    % CREATEPUBLICATIONFIGURE Professional publication-ready plot
    
    fprintf('\\textbf{Task 5: Publication-Quality Figure}\n');
    fprintf('--------\n\n');
    
    % Generate complex multi-dataset scenario
    t = linspace(0, 24, 200);  % 24-hour period
    
    % Dataset 1: Temperature (°C)
    temp_base = 20;
    temp_amplitude = 8;
    temp = temp_base + temp_amplitude * sin(2*pi*(t - 6)/24);
    
    % Dataset 2: Relative Humidity (%)
    humidity_base = 60;
    humidity_amplitude = 25;
    humidity = humidity_base - humidity_amplitude * sin(2*pi*(t - 6)/24);
    
    % Dataset 3: Solar Radiation (W/m²)
    radiation = zeros(size(t));
    daytime = (t >= 6) & (t <= 18);
    radiation(daytime) = 800 * sin(pi*(t(daytime) - 6)/12).^2;
    
    % Dataset 4: Power Consumption (kW)
    power_base = 5;
    power_peak_morning = 8 + 4 * exp(-((t - 7).^2) / 2);
    power_peak_evening = 8 + 6 * exp(-((t - 19).^2) / 2);
    power = power_base + power_peak_morning + power_peak_evening;
    
    fprintf('Multi-Variable Time Series:\n');
    fprintf('  Duration: 24 hours\n');
    fprintf('  Variables: Temperature, Humidity, Solar Radiation, Power\n');
    fprintf('  Sampling points: %d\n\n', length(t));
    
    % Create publication figure
    fig = figure('Position', [100, 100, 1400, 900], 'Name', 'Publication Figure');
    set(fig, 'Color', 'w');  % White background
    
    % Main environmental data
    subplot(2, 1, 1);
    yyaxis left
    
    % Temperature
    h1 = plot(t, temp, 'r-', 'LineWidth', 2.5);
    hold on;
    
    % Shade comfort zone
    fill([t, fliplr(t)], [18*ones(size(t)), fliplr(26*ones(size(t)))], ...
        [1, 0.9, 0.9], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
    
    % Humidity
    h2 = plot(t, humidity, 'b-', 'LineWidth', 2.5);
    
    ylabel('Temperature (°C) / Humidity (\%)', 'Interpreter', 'latex', ...
        'FontSize', 13, 'FontWeight', 'bold');
    set(gca, 'YColor', 'k', 'FontSize', 11);
    ylim([0, 100]);
    
    % Add annotations
    [max_temp, max_temp_idx] = max(temp);
    plot(t(max_temp_idx), max_temp, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    text(t(max_temp_idx), max_temp + 5, sprintf('Peak: %.1f°C at %02.0*f:00', ...
        max_temp, t(max_temp_idx)), 'HorizontalAlignment', 'center', ...
        'FontSize', 10, 'FontWeight', 'bold', 'Color', 'r');
    
    yyaxis right
    
    % Solar radiation
    h3 = area(t, radiation, 'FaceColor', [1, 0.8, 0], 'EdgeColor', [0.8, 0.6, 0], ...
        'LineWidth', 1.5, 'FaceAlpha', 0.4);
    
    ylabel('Solar Radiation (W/m$^2$)', 'Interpreter', 'latex', 'FontSize', 13, ...
        'FontWeight', 'bold', 'Color', [0.8, 0.6, 0]);
    set(gca, 'YColor', [0.8, 0.6, 0], 'FontSize', 11);
    ylim([0, 1000]);
    
    % Formatting
    xlabel('Time of Day (hours)', 'Interpreter', 'latex', 'FontSize', 13);
    set(gca, 'XTick', 0:3:24, 'FontSize', 11);
    title('\\textbf{Environmental Conditions Over 24 Hours}', 'Interpreter', 'latex', ...
        'FontSize', 15);
    legend([h1, h2, h3], {'Temperature', 'Rel. Humidity', 'Solar Radiation'}, ...
        'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 11);
    grid on;
    box on;
    
    % Power consumption analysis
    subplot(2, 1, 2);
    yyaxis left
    
    % Power as line
    h4 = plot(t, power, 'g-', 'LineWidth', 3);
    hold on;
    
    % Highlight peak hours
    peak_threshold = mean(power) + std(power);
    peak_times = power > peak_threshold;
    scatter(t(peak_times), power(peak_times), 50, 'r', 'filled', 'MarkerFaceAlpha', 0.6);
    
    ylabel('Power Consumption (kW)', 'Interpreter', 'latex', 'FontSize', 13, ...
        'Color', 'g', 'FontWeight', 'bold');
    set(gca, 'YColor', 'g', 'FontSize', 11);
    
    % Add average line
    yline(mean(power), 'g-', sprintf('Mean: %.2f kW', mean(power)), ...
        'LineWidth', 2, 'LabelHorizontalAlignment', 'left', 'FontSize', 10);
    
    yyaxis right
    
    % Cumulative energy (integrate power)
    dt = t(2) - t(1);
    cumulative_energy = cumsum(power) * dt;
    
    h5 = plot(t, cumulative_energy, 'b-', 'LineWidth', 2.5);
    ylabel('Cumulative Energy (kWh)', 'Interpreter', 'latex', 'FontSize', 13, ...
        'Color', 'b', 'FontWeight', 'bold');
    set(gca, 'YColor', 'b', 'FontSize', 11);
    
    % Formatting
    xlabel('Time of Day (hours)', 'Interpreter', 'latex', 'FontSize', 13);
    set(gca, 'XTick', 0:3:24, 'FontSize', 11);
    title('\\textbf{Power Consumption and Energy Usage}', 'Interpreter', 'latex', ...
        'FontSize', 15);
    legend([h4, h5], {'Instantaneous Power', 'Cumulative Energy'}, ...
        'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 11);
    grid on;
    box on;
    
    % Add figure caption
    annotation('textbox', [0.1, 0.01, 0.8, 0.03], 'String', ...
        ['Figure 1: Diurnal variation of environmental parameters and power consumption. ', ...
         'Top: temperature (red), humidity (blue dashed), and solar radiation (yellow shaded). ', ...
         'Bottom: power consumption (green) with peak demand periods (red dots) and cumulative ', ...
         'energy usage (blue). Comfort zone shown as pink shaded region (18–26°C).'], ...
        'Interpreter', 'latex', 'FontSize', 10, 'EdgeColor', 'none', ...
        'HorizontalAlignment', 'justify');
    
    % Summary statistics
    fprintf('Summary Statistics:\n');
    fprintf('  Temperature: %.1f ± %.1f °C (range: %.1f to %.1f)\n', ...
        mean(temp), std(temp), min(temp), max(temp));
    fprintf('  Humidity: %.1f ± %.1f %% (range: %.1f to %.1f)\n', ...
        mean(humidity), std(humidity), min(humidity), max(humidity));
    fprintf('  Peak solar radiation: %.0f W/m²\n', max(radiation));
    fprintf('  Average power: %.2f kW\n', mean(power));
    fprintf('  Peak power: %.2f kW\n', max(power));
    fprintf('  Total energy: %.2f kWh\n', cumulative_energy(end));
    fprintf('  Peak demand hours: %d (%.1f%% of day)\n', ...
        sum(peak_times), 100*sum(peak_times)/length(t));
    fprintf('\n');
end
