%% chapter_DataVisualisation_treemap.m
% Treemap Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_treemap
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------

function createTreemap(sizes, labels, colours)
figure('Position', [100 100 800 600]);

% Normalize sizes to fit plot
total = sum(sizes);
norm_sizes = sizes/total;

% Calculate rectangle positions
pos = computeTreemapLayout(norm_sizes);

% Plot rectangles
hold on;
for i = 1:length(sizes)
    rectangle('Position', pos(i,:), ...
             'FaceColor', colours{i}, ...
             'EdgeColor', 'k');
    % Add labels
    text(pos(i,1) + pos(i,3)/2, ...
         pos(i,2) + pos(i,4)/2, ...
         labels{i}, ...
         'HorizontalAlignment', 'center');
end
axis equal tight off;
title('Hierarchical Data Structure');


% Export figure in multiple formats
exportFigure(gca, 'Treemap_plot');

end

function pos = computeTreemapLayout(sizes)
% Basic squarified treemap layout algorithm
pos = zeros(length(sizes), 4);
x = 0; y = 0; w = 1; h = 1;

for i = 1:length(sizes)
    pos(i,:) = [x, y, w*sizes(i), h];
    x = x + w*sizes(i);
end

end
