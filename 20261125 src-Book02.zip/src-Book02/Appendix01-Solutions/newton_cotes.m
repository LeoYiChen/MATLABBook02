%% newton_cotes.m
% Composite Newton-Cotes Rules
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : newton_cotes
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem2.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Function to integrate
f = @(x) 1./(1 + x.^2);
exact_value = pi/4; % Analytical solution

% Number of subintervals to test
intervals = 2.^(2:12);
h_values = 1./intervals; % Step sizes

% Arrays to store errors
trap_errors = zeros(size(intervals));
simp_errors = zeros(size(intervals));

% Implement composite rules and calculate errors
for i = 1:length(intervals)
n = intervals(i);
h = 1/n;

% Composite trapezoidal rule
x = linspace(0, 1, n+1);
fx = f(x);
trap_result = h * (sum(fx) - (fx(1) + fx(end))/2);
trap_errors(i) = abs(trap_result - exact_value);

% Composite Simpson's rule (requires even number of subintervals)
n_simp = 2 * floor(n/2);  % Ensure even number
if n_simp < 2
    n_simp = 2;
end
h_simp = 1/n_simp;
x_simp = linspace(0, 1, n_simp+1);
fx_simp = f(x_simp);

% Apply Simpson's 1/3 rule
simp_result = h_simp/3 * (fx_simp(1) + fx_simp(end) + ...
                 4*sum(fx_simp(2:2:end-1)) + ...
                 2*sum(fx_simp(3:2:end-2)));
simp_errors(i) = abs(simp_result - exact_value);

end

% Plot results on log-log scale
figure;
loglog(h_values, trap_errors, 'o-', 'LineWidth', 2, 'DisplayName', 'Trapezoidal Rule');
hold on;
loglog(h_values, simp_errors, 's-', 'LineWidth', 2, 'DisplayName', 'Simpson''s Rule');

% Add reference lines for O(h^2) and O(h^4)
h_ref = logspace(-3, 0, 100);
loglog(h_ref, h_ref.^2 / 10, 'k-', 'LineWidth', 1.5, 'DisplayName', 'O(h^2)');
loglog(h_ref, h_ref.^4 / 100, 'k:', 'LineWidth', 1.5, 'DisplayName', 'O(h^4)');

xlabel('Step Size (h) - log scale');
ylabel('Absolute Error - log scale');
title('Convergence Rates of Newton-Cotes Rules');
legend('show');
grid on;

% Calculate convergence rates using linear regression on log-log data
p_trap = polyfit(log(h_values), log(trap_errors), 1);
p_simp = polyfit(log(h_values), log(simp_errors), 1);

fprintf('Trapezoidal rule convergence rate: %.2f (expected: 2)\n', p_trap(1));
fprintf('Simpson''s rule convergence rate: %.2f (expected: 4)\n', p_simp(1));

% Display results for selected step sizes
fprintf('\nResults for selected step sizes:\n');
fprintf('%-10s %-20s %-20s %-20s\n', 'h', 'Trapezoidal Error', 'Simpson''s Error', 'Exact Value');
for i = 1:3:length(h_values)
fprintf('%-10g %-20.14f %-20.14f %-20.14f\n', h_values(i), trap_errors(i), simp_errors(i), exact_value);
end
