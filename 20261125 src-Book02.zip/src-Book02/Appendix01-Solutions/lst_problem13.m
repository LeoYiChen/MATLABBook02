%% lst_problem13.m
% AI-enhanced aircraft FEA with Gaussian process surrogates and UQ.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:problem13
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 13: AI-Driven Aircraft Structural FEA with Uncertainty Quantification
%  Author: Dr Yi Chen, Newcastle University
%  Purpose: GP surrogate for wing spar stress/deflection with reliability analysis
%  MATLAB R2023b+, Statistics and Machine Learning Toolbox, Global Optimisation Toolbox

clear; close all; clc;
fprintf('=== AI-Enhanced Aircraft Structural FEA with UQ ===\n\n');

%% Step 1: Define parameter space and generate training data
fprintf('Step 1: Generating high-fidelity FEA training dataset...\n');

% Design parameters (wing spar)
param_names = {'Flange_thick_mm', 'Web_thick_mm', 'Rib_spacing_m', ...
               'Youngs_mod_GPa', 'Load_factor'};
param_bounds = [5, 15;    % Flange thickness [mm]
                3, 10;    % Web thickness [mm]
                0.4, 0.8; % Rib spacing [m]
                68, 73;   % Young's modulus [GPa] (7075-T6 scatter)
                1.0, 2.5]; % Load factor (1.0 = cruise, 2.5 = gust)

N_train = 200;  % Training samples (production: 500-1000)
N_test = 50;    % Test samples

% Latin hypercube sampling
rng(42);
X_train_norm = lhsdesign(N_train, 5);
X_train = zeros(N_train, 5);
for i = 1:5
    X_train(:,i) = param_bounds(i,1) + X_train_norm(:,i) * diff(param_bounds(i,:));
end

X_test_norm = lhsdesign(N_test, 5);
X_test = zeros(N_test, 5);
for i = 1:5
    X_test(:,i) = param_bounds(i,1) + X_test_norm(:,i) * diff(param_bounds(i,:));
end

fprintf('  Parameter space: %d dimensions\n', size(X_train, 2));
fprintf('  Training samples: %d\n', N_train);
fprintf('  Test samples: %d\n', N_test);

%% Step 2: Run FEA simulations (or load pre-computed results)
fprintf('\nStep 2: Running high-fidelity FEA simulations...\n');
fprintf('  Note: Full ANSYS integration omitted using physics-based emulator\n\n');

% Emulator for wing spar FEA (represents hours of computation per sample)
Y_train = zeros(N_train, 4);  % [max_stress, tip_deflection, freq, buckling_load]
Y_test = zeros(N_test, 4);

for i = 1:N_train
    Y_train(i,:) = wingSparsparamFEA(X_train(i,:));
    if mod(i,20)==0, fprintf('  Training: %d/%d\n',i,N_train); end
end

for i = 1:N_test
    Y_test(i,:) = wingSparFEA(X_test(i,:));
end

fprintf('  FEA dataset generated. Avg stress: %.1f MPa, Avg deflection: %.2f mm\n', ...
    mean(Y_train(:,1)), mean(Y_train(:,2)));

%% Step 3: Train Gaussian process surrogates
fprintf('\nStep 3: Training GP surrogates for structural responses...\n');

response_names = {'Max_vonMises_MPa', 'Tip_deflection_mm', 'Freq_Hz', 'Buckling_load'};
gp_models = cell(4,1);

for j = 1:4
    fprintf('  Training GP for %s...\n', response_names{j});
    
    % GP with squared exponential kernel
    gp_models{j} = fitrgp(X_train, Y_train(:,j), ...
        'KernelFunction', 'squaredexponential', ...
        'OptimizeHyperparameters', 'auto', ...
        'HyperparameterOptimizationOptions', struct('Verbose',0, 'ShowPlots',false));
end

fprintf('  GP training completed.\n');

%% Step 4: Validation and accuracy metrics
fprintf('\nStep 4: Validating surrogate accuracy on test set...\n');

Y_pred = zeros(N_test, 4);
Y_std = zeros(N_test, 4);

for j = 1:4
    [Y_pred(:,j), Y_std(:,j)] = predict(gp_models{j}, X_test);
end

% Compute metrics
for j = 1:4
    R2 = 1 - sum((Y_test(:,j) - Y_pred(:,j)).^2) / sum((Y_test(:,j) - mean(Y_test(:,j))).^2);
    RMSE = sqrt(mean((Y_test(:,j) - Y_pred(:,j)).^2));
    MaxErr = max(abs(Y_test(:,j) - Y_pred(:,j)));
    
    % Coverage probability (95% CI)
    CI_lower = Y_pred(:,j) - 1.96*Y_std(:,j);
    CI_upper = Y_pred(:,j) + 1.96*Y_std(:,j);
    coverage = mean((Y_test(:,j) >= CI_lower) & (Y_test(:,j) <= CI_upper)) * 100;
    
    fprintf('  %s: R=%.4f, RMSE=%.3f, MaxErr=%.3f, Coverage=%.1f%%\n', ...
        response_names{j}, R2, RMSE, MaxErr, coverage);
end

%% Step 5: Monte Carlo reliability analysis
fprintf('\nStep 5: Monte Carlo reliability analysis with uncertainty propagation...\n');

N_MC = 100000;  % Monte Carlo samples

% Define uncertainty distributions
E_mean = 70;  % GPa
E_std = 2;
Load_mean = 1.5;
Load_std = 0.2;

% Sample uncertainties
E_samples = normrnd(E_mean, E_std, N_MC, 1);
Load_samples = normrnd(Load_mean, Load_std, N_MC, 1);

% Fixed nominal values for other parameters
t_f_nom = 10;
t_w_nom = 6;
s_r_nom = 0.6;

X_MC = [repmat(t_f_nom, N_MC, 1), repmat(t_w_nom, N_MC, 1), ...
        repmat(s_r_nom, N_MC, 1), E_samples, Load_samples];

% Predict using GP (fast!)
tic;
stress_MC = predict(gp_models{1}, X_MC);
MC_time = toc;

% Failure criterion
yield_stress = 503;  % MPa for 7075-T6
safety_factor = 1.5;
allowable_stress = yield_stress / safety_factor;

failures = stress_MC > allowable_stress;
P_f = sum(failures) / N_MC;

fprintf('  Monte Carlo samples: %d\n', N_MC);
fprintf('  GP evaluation time: %.2f seconds (vs %.1f hours for direct FEA)\n', ...
    MC_time, N_MC * 10 / 3600);
fprintf('  Probability of failure: %.2e\n', P_f);
fprintf('  Reliability: %.4f%% (target: 99.9%% for transport aircraft)\n', (1-P_f)*100);

%% Step 6: Sobol sensitivity analysis
fprintf('\nStep 6: Global sensitivity analysis (Sobol indices)...\n');

% Simplified Sobol using GP variance decomposition
variance_total = var(stress_MC);

for i = 1:5
    % Vary parameter i, fix others at nominal
    X_vary = repmat([t_f_nom, t_w_nom, s_r_nom, E_mean, Load_mean], 1000, 1);
    X_vary(:,i) = linspace(param_bounds(i,1), param_bounds(i,2), 1000)';
    
    stress_vary = predict(gp_models{1}, X_vary);
    variance_i = var(stress_vary);
    
    Sobol_i = variance_i / variance_total;
    fprintf('  S_%s = %.3f\n', param_names{i}, Sobol_i);
end

fprintf('\nProblem 13 completed successfully.\n');

%% Helper function: Wing spar FEA emulator
function y = wingSparFEA(x)
    % Physics-based emulator (replaces hours of ANSYS computation)
    t_f = x(1);  % mm
    t_w = x(2);
    s_r = x(3);  % m
    E = x(4);    % GPa
    LF = x(5);
    
    % Simplified beam bending + buckling
    L = 8;  % Wing span [m]
    b = 0.4;  % Flange width [m]
    h = 0.6;  % Web height [m]
    
    I = (b*(h+t_f)^3 - (b-t_w)*h^3)/12 * 1e-12;  % Second moment [m^4]
    A = (2*b*t_f + h*t_w) * 1e-6;  % Area [m^2]
    
    P = LF * 50000;  % Load [N]
    
    sigma_max = P * L / (2*I) * (h/2 + t_f) * 1e-3 * 1e6;  % [MPa]
    delta_tip = P * L^3 / (3 * E*1e9 * I) * 1e3;  % [mm]
    freq = (1/(2*pi)) * sqrt(3*E*1e9*I / (A*2700*(L^3))) ;  % [Hz]
    buckling = pi^2 * E*1e9 * I / (s_r^2);  % Critical load [N]
    
    y = [sigma_max, delta_tip, freq, buckling/1000];
end
