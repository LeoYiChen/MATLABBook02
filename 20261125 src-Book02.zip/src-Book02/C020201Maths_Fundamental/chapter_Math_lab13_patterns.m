%% chapter_Math_lab13_patterns.m
% Mathematical Patterns in 2025
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab13_patterns
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory
Lab13_MathematicalPatterns2025();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab13_MathematicalPatterns2025()
    % LAB13_MATHEMATICALPATTERNS2025 Explore number theory properties of 2025
    %   Analyzes factorization, divisibility, sequences, and patterns
    
    fprintf('\\textbf{Laboratory 13: Mathematical Patterns in 2025}\n');
    fprintf('======================================================\n\n');
    
    % The special number
    n = 2025;
    
    fprintf('Analyzing the year 2025...\n\n');
    
    % Task 1: Basic properties and factorization
    analyzeBasicProperties(n);
    
    % Task 2: Divisibility patterns
    analyzeDivisibilityPatterns(n);
    
    % Task 3: Sequences containing 2025
    findSequenceOccurrences(n);
    
    % Task 4: Digit patterns and properties
    analyzeDigitPatterns(n);
    
    % Task 5: Geometric and visual representations
    visualizeMathematicalProperties(n);
end

function analyzeBasicProperties(n)
    % ANALYZEBASICPROPERTIES Fundamental number-theoretic properties
    
    fprintf('\\textbf{Task 1: Basic Properties and Factorization}\n');
    fprintf('----------\n');
    
    fprintf('Number: %d\n\n', n);
    
    % Prime factorization
    fprintf('Prime Factorization:\n');
    factors = factor(n);
    unique_primes = unique(factors);
    
    fprintf('  %d = ', n);
    for i = 1:length(unique_primes)
        p = unique_primes(i);
        exponent = sum(factors == p);
        if i > 1
            fprintf(' $\times$ ');
        end
        if exponent == 1
            fprintf('%d', p);
        else
            fprintf('%d^%d', p, exponent);
        end
    end
    fprintf('\n\n');
    
    % Verify factorization
    product_check = prod(factors);
    fprintf('  Verification: ');
    for i = 1:length(factors)
        if i > 1
            fprintf(' $\times$ ');
        end
        fprintf('%d', factors(i));
    end
    fprintf(' = %d ✓\n\n', product_check);
    
    % Perfect square check
    sqrt_n = sqrt(n);
    if sqrt_n == floor(sqrt_n)
        fprintf('Perfect Square: %d = %d^2 ✓\n', n, sqrt_n);
        fprintf('  %d is the square of %d\n\n', n, sqrt_n);
    else
        fprintf('Not a perfect square\n\n');
    end
    
    % Divisor analysis
    fprintf('Divisor Analysis:\n');
    divisors = findDivisors(n);
    fprintf('  Number of divisors: %d\n', length(divisors));
    fprintf('  Divisors: ');
    fprintf('%d ', divisors);
    fprintf('\n\n');
    
    % Theoretical divisor count
    tau_theoretical = 1;
    for i = 1:length(unique_primes)
        exponent = sum(factors == unique_primes(i));
        tau_theoretical = tau_theoretical * (exponent + 1);
    end
    fprintf('  Theoretical τ(n) = ');
    for i = 1:length(unique_primes)
        exponent = sum(factors == unique_primes(i));
        if i > 1
            fprintf(' $\times$ ');
        end
        fprintf('(%d+1)', exponent);
    end
    fprintf(' = %d ✓\n\n', tau_theoretical);
    
    % Sum of divisors
    sigma_n = sum(divisors);
    fprintf('  Sum of divisors σ(n) = %d\n', sigma_n);
    
    % Check for perfect/abundant/deficient
    proper_divisors_sum = sigma_n - n;
    fprintf('  Sum of proper divisors = %d\n', proper_divisors_sum);
    
    if proper_divisors_sum == n
        classification = 'PERFECT';
    elseif proper_divisors_sum > n
        classification = 'ABUNDANT';
    else
        classification = 'DEFICIENT';
    end
    fprintf('  Classification: %s number\n\n', classification);
    
    % Euler's totient function
    phi_n = eulerPhi(n, unique_primes);
    fprintf('Euler\'s Totient Function:\n');
    fprintf('  φ(%d) = %d\n', n, phi_n);
    fprintf('  Meaning: %d integers ≤ %d are coprime to %d\n', phi_n, n, n);
    fprintf('  Percentage: %.2f%%\n\n', 100 * phi_n / n);
    
    % Binary and other representations
    fprintf('Alternative Representations:\n');
    fprintf('  Binary:      %s\n', dec2bin(n));
    fprintf('  Octal:       %s\n', dec2oct(n));
    fprintf('  Hexadecimal: %s\n', dec2hex(n));
    fprintf('  Roman:       %s\n\n', decimalToRoman(n));
end

function divisors = findDivisors(n)
    % FINDDIVISORS Find all divisors of n
    divisors = [];
    for i = 1:sqrt(n)
        if mod(n, i) == 0
            divisors = [divisors, i];
            if i ~= n/i
                divisors = [divisors, n/i];
            end
        end
    end
    divisors = sort(divisors);
end

function phi = eulerPhi(n, primes)
    % EULERPHI Compute Euler's totient function
    phi = n;
    for i = 1:length(primes)
        phi = phi * (1 - 1/primes(i));
    end
    phi = round(phi);
end

function roman = decimalToRoman(n)
    % DECIMALTOROMAN Convert decimal to Roman numerals (simplified)
    if n >= 4000
        roman = 'TOO LARGE';
        return;
    end
    
    values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
    numerals = {'M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I'};
    
    roman = '';
    for i = 1:length(values)
        while n >= values(i)
            roman = [roman, numerals{i}];
            n = n - values(i);
        end
    end
end

function analyzeDivisibilityPatterns(n)
    % ANALYZEDIVISIBILITYPATTERNS Test divisibility rules
    
    fprintf('\\textbf{Task 2: Divisibility Patterns}\n');
    fprintf('--------\n\n');
    
    % Digit sum for divisibility by 3 and 9
    digits = num2str(n) - '0';
    digit_sum = sum(digits);
    
    fprintf('Digit Analysis:\n');
    fprintf('  Digits: ');
    fprintf('%d ', digits);
    fprintf('\n');
    fprintf('  Digit sum: %d + %d + %d + %d = %d\n', ...
        digits(1), digits(2), digits(3), digits(4), digit_sum);
    
    % Divisibility by 3
    if mod(digit_sum, 3) == 0
        fprintf('  ✓ Divisible by 3 (digit sum %d is divisible by 3)\n', digit_sum);
    end
    
    % Divisibility by 9
    if mod(digit_sum, 9) == 0
        fprintf('  ✓ Divisible by 9 (digit sum %d is divisible by 9)\n', digit_sum);
    end
    fprintf('\n');
    
    % Test divisibility by various numbers
    fprintf('Divisibility Tests:\n');
    test_divisors = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 15, 25, 27, 45, 75, 81];
    
    for d = test_divisors
        if mod(n, d) == 0
            quotient = n / d;
            fprintf('  %d ÷ %2*d = %d ✓\n', n, d, quotient);
        end
    end
    fprintf('\n');
    
    % Modular arithmetic patterns
    fprintf('Modular Arithmetic:\n');
    moduli = [7, 11, 13, 17, 19];
    for m = moduli
        remainder = mod(n, m);
        fprintf('  %d ≡ %d (mod %d)\n', n, remainder, m);
    end
    fprintf('\n');
    
    % Powers of 2025
    fprintf('Powers of 2025:\n');
    for k = 2:4
        power_k = n^k;
        if power_k < 1e10  % Keep numbers manageable
            fprintf('  2025^%d = %d\n', k, power_k);
        else
            fprintf('  2025^%d ≈ %.6e\n', k, power_k);
        end
    end
    fprintf('\n');
end

function findSequenceOccurrences(n)
    % FINDSEQUENCEOCCURRENCES Find n in various mathematical sequences
    
    fprintf('\\textbf{Task 3: Sequences Containing 2025}\n');
    fprintf('--------\n\n');
    
    % Perfect squares
    fprintf('1. Perfect Squares: n^2\n');
    sqrt_n = sqrt(n);
    fprintf('   2025 = %d^2 (the %dth perfect square)\n\n', sqrt_n, sqrt_n);
    
    % Triangular numbers check
    fprintf('2. Triangular Numbers: T_n = n(n+1)/2\n');
    % Solve n(n+1)/2 = 2025 → n^2 + n - 4050 = 0
    discriminant = 1 + 4*4050;
    n_triangular = (-1 + sqrt(discriminant)) / 2;
    
    if abs(n_triangular - round(n_triangular)) < 1e-10
        fprintf('   2025 = T_%d (triangular number)\n\n', round(n_triangular));
    else
        fprintf('   2025 is NOT a triangular number\n');
        fprintf('   Closest: T_%d = %d, T_%d = %d\n\n', ...
            floor(n_triangular), floor(n_triangular)*(floor(n_triangular)+1)/2, ...
            ceil(n_triangular), ceil(n_triangular)*(ceil(n_triangular)+1)/2);
    end
    
    % Sum of consecutive odd numbers
    fprintf('3. Sum of Consecutive Odd Numbers:\n');
    fprintf('   2025 = 1 + 3 + 5 + ... + %d\n', 2*sqrt_n - 1);
    fprintf('   (sum of first %d odd numbers)\n\n', sqrt_n);
    
    % Fibonacci-like sequences
    fprintf('4. Fibonacci Sequence:\n');
    fib_limit = 5000;
    fib_seq = generateFibonacci(fib_limit);
    
    if any(fib_seq == n)
        idx = find(fib_seq == n, 1);
        fprintf('   2025 = F_%d (Fibonacci number)\n\n', idx);
    else
        % Find nearest Fibonacci numbers
        larger_idx = find(fib_seq > n, 1);
        if ~isempty(larger_idx) && larger_idx > 1
            fprintf('   2025 is NOT a Fibonacci number\n');
            fprintf('   F_%d = %d < 2025 < %d = F_%d\n\n', ...
                larger_idx-1, fib_seq(larger_idx-1), ...
                fib_seq(larger_idx), larger_idx);
        end
    end
    
    % Pythagorean triples containing 2025
    fprintf('5. Pythagorean Triples (a^2 + b^2 = c^2):\n');
    triples_found = 0;
    search_limit = 3000;
    
    % Since 2025 = 45^2, look for triples where 2025 is a leg
    for a = 1:min(n, search_limit)
        c_squared = a^2 + n^2;
        c = sqrt(c_squared);
        if c == floor(c) && c <= search_limit
            fprintf('   %d^2 + 2025^2 = %d^2\n', a, round(c));
            triples_found = triples_found + 1;
        end
    end
    
    if triples_found == 0
        fprintf('   No Pythagorean triples found with 2025 as a leg (search limit: %d)\n', ...
            search_limit);
    end
    fprintf('\n');
    
    % Arithmetic sequences
    fprintf('6. Arithmetic Sequences:\n');
    fprintf('   2025 appears in infinitely many arithmetic sequences\n');
    fprintf('   Examples:\n');
    fprintf('     • {45, 1035, 2025, 3015, ...} with d = 990\n');
    fprintf('     • {225, 1125, 2025, 2925, ...} with d = 900\n');
    fprintf('     • {405, 1215, 2025, 2835, ...} with d = 810\n\n');
end

function fib = generateFibonacci(limit)
    % GENERATEFIBONACCI Generate Fibonacci sequence up to limit
    fib = [1, 1];
    while fib(end) < limit
        fib = [fib, fib(end) + fib(end-1)];
    end
end

function analyzeDigitPatterns(n)
    % ANALYZEDIGITPATTERNS Explore patterns in digits
    
    fprintf('\\textbf{Task 4: Digit Patterns and Properties}\n');
    fprintf('--------\n\n');
    
    % Extract digits
    digits = num2str(n) - '0';
    
    fprintf('Digit Analysis for 2025:\n\n');
    
    % Palindrome check
    is_palindrome = all(digits == fliplr(digits));
    fprintf('Palindrome: %s\n', char(is_palindrome*'Yes' + ~is_palindrome*'No'));
    
    % Digit statistics
    fprintf('\nDigit Statistics:\n');
    fprintf('  Digits: [%s]\n', num2str(digits));
    fprintf('  Sum: %d\n', sum(digits));
    fprintf('  Product: %d\n', prod(digits));
    fprintf('  Mean: %.2f\n', mean(digits));
    fprintf('  Variance: %.2f\n\n', var(digits));
    
    % Digit permutations
    fprintf('Interesting Permutations:\n');
    perms_2025 = unique(perms(digits), 'rows');
    
    % Convert to numbers and sort
    perm_numbers = zeros(size(perms_2025, 1), 1);
    for i = 1:size(perms_2025, 1)
        perm_numbers(i) = str2double(num2str(perms_2025(i, :)));
    end
    perm_numbers = sort(perm_numbers);
    
    fprintf('  Total unique permutations: %d\n', length(perm_numbers));
    fprintf('  Smallest: %d\n', perm_numbers(1));
    fprintf('  Largest: %d\n', perm_numbers(end));
    fprintf('  Original position: %d of %d\n\n', ...
        find(perm_numbers == n), length(perm_numbers));
    
    % Digital root
    digital_root = n;
    steps = 0;
    fprintf('Digital Root (repeated digit sum until single digit):\n');
    fprintf('  %d', digital_root);
    
    while digital_root >= 10
        digital_root = sum(num2str(digital_root) - '0');
        steps = steps + 1;
        fprintf(' → %d', digital_root);
    end
    fprintf('\n  Final digital root: %d (after %d steps)\n\n', digital_root, steps);
    
    % Special digit properties
    fprintf('Special Properties:\n');
    
    % Sum of digits equals 9
    if sum(digits) == 9
        fprintf('  ✓ Digit sum = 9 (special in base 10)\n');
    end
    
    % Repeated digits
    if length(unique(digits)) < length(digits)
        fprintf('  ✓ Contains repeated digits\n');
    end
    
    % Pattern in digits
    fprintf('  • First two digits (20) match first two of 2000*s decade\n');
    fprintf('  • Last two digits (25) form a perfect square (5^2)\n');
    fprintf('  • Middle digit (0) is neutral element for addition\n\n');
end

function visualizeMathematicalProperties(n)
    % VISUALIZEMATHEMATICALPROPERTIES Create visual representations
    
    fprintf('\\textbf{Task 5: Geometric and Visual Representations}\n');
    fprintf('---------\n\n');
    
    fprintf('Creating visualisations...\n\n');
    
    % Figure 1: Divisor visualisation
    figure('Position', [100, 100, 1400, 900], 'Name', 'Mathematical Properties of 2025');
    
    % Subplot 1: Divisor diagram
    subplot(3, 3, 1);
    divisors = findDivisors(n);
    
    % Create divisor lattice
    x = 1:length(divisors);
    y = log10(divisors);
    
    stem(x, y, 'filled', 'MarkerSize', 8);
    set(gca, 'XTick', x, 'XTickLabel', divisors, 'XTickLabelRotation', 45);
    ylabel('$\log_{10}(\text{divisor})$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Divisors of 2025', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 2: Prime factorization tree
    subplot(3, 3, 2);
    axis off;
    text(0.5, 0.95, '2025', 'HorizontalAlignment', 'center', 'FontSize', 14, ...
        'FontWeight', 'bold');
    
    % Draw factorization tree
    line([0.5, 0.3], [0.9, 0.7], 'Color', 'k', 'LineWidth', 2);
    line([0.5, 0.7], [0.9, 0.7], 'Color', 'k', 'LineWidth', 2);
    
    text(0.3, 0.65, '45', 'HorizontalAlignment', 'center', 'FontSize', 12);
    text(0.7, 0.65, '45', 'HorizontalAlignment', 'center', 'FontSize', 12);
    
    line([0.3, 0.2], [0.6, 0.4], 'Color', 'k', 'LineWidth', 1.5);
    line([0.3, 0.4], [0.6, 0.4], 'Color', 'k', 'LineWidth', 1.5);
    line([0.7, 0.6], [0.6, 0.4], 'Color', 'k', 'LineWidth', 1.5);
    line([0.7, 0.8], [0.6, 0.4], 'Color', 'k', 'LineWidth', 1.5);
    
    text(0.2, 0.35, '9', 'HorizontalAlignment', 'center', 'FontSize', 11);
    text(0.4, 0.35, '5', 'HorizontalAlignment', 'center', 'FontSize', 11, 'Color', 'r');
    text(0.6, 0.35, '9', 'HorizontalAlignment', 'center', 'FontSize', 11);
    text(0.8, 0.35, '5', 'HorizontalAlignment', 'center', 'FontSize', 11, 'Color', 'r');
    
    line([0.2, 0.15], [0.3, 0.1], 'Color', 'k', 'LineWidth', 1.5);
    line([0.2, 0.25], [0.3, 0.1], 'Color', 'k', 'LineWidth', 1.5);
    line([0.6, 0.55], [0.3, 0.1], 'Color', 'k', 'LineWidth', 1.5);
    line([0.6, 0.65], [0.3, 0.1], 'Color', 'k', 'LineWidth', 1.5);
    
    text(0.15, 0.05, '3', 'HorizontalAlignment', 'center', 'FontSize', 10, 'Color', 'r');
    text(0.25, 0.05, '3', 'HorizontalAlignment', 'center', 'FontSize', 10, 'Color', 'r');
    text(0.55, 0.05, '3', 'HorizontalAlignment', 'center', 'FontSize', 10, 'Color', 'r');
    text(0.65, 0.05, '3', 'HorizontalAlignment', 'center', 'FontSize', 10, 'Color', 'r');
    
    title('Prime Factorization Tree', 'Interpreter', 'latex', 'FontSize', 13);
    
    % Subplot 3: Perfect square visualisation
    subplot(3, 3, 3);
    sqrt_n = sqrt(n);
    
    % Draw 45*x45 grid representation
    sample_size = 15;  % Show subset for clarity
    [X, Y] = meshgrid(1:sample_size, 1:sample_size);
    scatter(X(:), Y(:), 20, 'b', 'filled');
    
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title(sprintf('$2025 = 45^2$ (showing %d$\times$%d subset)', sample_size, sample_size), ...
        'Interpreter', 'latex', 'FontSize', 13);
    axis equal;
    grid on;
    xlim([0, sample_size+1]);
    ylim([0, sample_size+1]);
    
    % Subplot 4: Sum of odd numbers
    subplot(3, 3, 4);
    num_odds = sqrt_n;
    odd_numbers = 2*(1:num_odds) - 1;
    cumsum_odds = cumsum(odd_numbers);
    
    plot(1:num_odds, cumsum_odds, 'b-', 'LineWidth', 2);
    hold on;
    plot(num_odds, n, 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
    
    xlabel('$n$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\sum_{k=1}^{n}(2*k-1)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Sum of First $n$ Odd Numbers', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 5: Divisor pairs
    subplot(3, 3, 5);
    n_divisors = length(divisors);
    pairs = zeros(floor(n_divisors/2) + mod(n_divisors, 2), 2);
    
    for i = 1:floor(n_divisors/2)
        pairs(i, :) = [divisors(i), divisors(end-i+1)];
    end
    if mod(n_divisors, 2) == 1
        middle_idx = ceil(n_divisors/2);
        pairs(end, :) = [divisors(middle_idx), divisors(middle_idx)];
    end
    
    for i = 1:size(pairs, 1)
        plot([0, 1], [i, i], 'b-', 'LineWidth', 2);
        hold on;
        plot(0, i, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
        plot(1, i, 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
        text(-0.15, i, sprintf('%d', pairs(i, 1)), 'HorizontalAlignment', 'right');
        text(1.15, i, sprintf('%d', pairs(i, 2)), 'HorizontalAlignment', 'left');
        
        product = pairs(i, 1) * pairs(i, 2);
        text(0.5, i, sprintf('$\times$=%d', product), 'HorizontalAlignment', 'center', ...
            'FontSize', 9);
    end
    
    xlim([-0.3, 1.3]);
    ylim([0.5, size(pairs, 1) + 0.5]);
    axis off;
    title('Divisor Pairs (product = 2025)', 'Interpreter', 'latex', 'FontSize', 13);
    
    % Subplot 6: Modular arithmetic wheel
    subplot(3, 3, 6);
    modulus = 12;
    theta = linspace(0, 2*pi, modulus+1);
    
    % Draw circle
    plot(cos(theta), sin(theta), 'k-', 'LineWidth', 2);
    hold on;
    
    % Mark positions
    for i = 0:modulus-1
        angle = 2*pi * i / modulus - pi/2;
        x = cos(angle);
        y = sin(angle);
        plot(x, y, 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
        text(1.15*x, 1.15*y, sprintf('%d', i), 'HorizontalAlignment', 'center', ...
            'FontSize', 10);
    end
    
    % Highlight 2025 mod 12
    remainder = mod(n, modulus);
    angle_highlight = 2*pi * remainder / modulus - pi/2;
    x_highlight = cos(angle_highlight);
    y_highlight = sin(angle_highlight);
    plot(x_highlight, y_highlight, 'ro', 'MarkerSize', 15, 'MarkerFaceColor', 'r');
    
    axis equal;
    axis off;
    title(sprintf('$2025 \\equiv %d \\pmod{%d}$', remainder, modulus), ...
        'Interpreter', 'latex', 'FontSize', 13);
    
    % Subplot 7: Digit frequency in powers
    subplot(3, 3, 7);
    powers = 1:6;
    digit_counts = zeros(10, length(powers));
    
    for p = powers
        value = n^p;
        digits_str = num2str(value);
        for d = 0:9
            digit_counts(d+1, p) = sum(digits_str == char('0' + d));
        end
    end
    
    bar(digit_counts');
    xlabel('Power', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Digit Count', 'Interpreter', 'latex', 'FontSize', 12);
    title('Digit Distribution in Powers of 2025', 'Interpreter', 'latex', 'FontSize', 13);
    legend(arrayfun(@(x) sprintf('%d', x), 0:9, 'UniformOutput', false), ...
        'Location', 'bestoutside', 'NumColumns', 2);
    grid on;
    
    % Subplot 8: Collatz-like sequence starting from 2025
    subplot(3, 3, 8);
    collatz_seq = collatzSequence(n, 100);
    
    plot(0:length(collatz_seq)-1, collatz_seq, 'b-o', 'LineWidth', 1.5, ...
        'MarkerSize', 4);
    xlabel('Step', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Value', 'Interpreter', 'latex', 'FontSize', 12);
    title('Collatz Sequence from 2025', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 9: Factor wheel
    subplot(3, 3, 9);
    factors = factor(n);
    unique_factors = unique(factors);
    counts = histc(factors, unique_factors);
    
    pie(counts, arrayfun(@(p, c) sprintf('%d^%d', p, c), ...
        unique_factors, counts, 'UniformOutput', false));
    title('Prime Factor Composition', 'Interpreter', 'latex', 'FontSize', 13);
end

function seq = collatzSequence(n, max_steps)
    % COLLATZSEQUENCE Generate Collatz sequence
    seq = n;
    steps = 0;
    
    while seq(end) ~= 1 && steps < max_steps
        if mod(seq(end), 2) == 0
            seq = [seq, seq(end)/2];
        else
            seq = [seq, 3*seq(end) + 1];
        end
        steps = steps + 1;
    end
end
