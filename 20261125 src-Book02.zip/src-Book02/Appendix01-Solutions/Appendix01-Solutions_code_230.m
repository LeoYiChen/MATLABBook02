%% Appendix01-Solutions_code_230.m
% Problem 12: Machine Learning-Guided Enzyme Design via Fitness Landscape Navigation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% ========================================================================
%% Problem 12: Machine Learning-Guided Enzyme Design 
%%             via Fitness Landscape Navigation
%% ========================================================================
% Scientific Goal:
%   Develop a machine learning workflow to predict enzyme activity from
%   amino acid sequence, enabling rational design of improved biocatalysts.
%
% Approach:
%   - Parent enzyme: 120-residue fictional esterase (hydrolyzes esters)
%   - Generate 500 single-point mutants (each position mutated to 19 alternatives)
%   - Encode sequences: 20 amino acid frequencies, 5 physicochemical properties
%   - Ground truth activity: Nonlinear function of sequence features + noise
%   - Train Random Forest + Neural Network to predict activity (kcat/Km)
%   - Screen 10,000 virtual double mutants, identify top performers
%   - Analyze mutations: Which positions are "hot spots" for activity
%
% Demonstrates: Sequence-to-function mapping, feature engineering, model
%               comparison, virtual screening, interpretability (feature importance)
%% ------------------------------------

clear; clc; close all;
rng(123); % Reproducibility

fprintf('========================================\n');
fprintf('Problem 12: ML-Guided Enzyme Design\n');
fprintf('========================================\n\n');

%% Step 1: Define Parent Enzyme Sequence
fprintf('Step 1: Defining parent enzyme sequence...\n\n');

% Amino acid alphabet
AA = 'ACDEFGHIKLMNPQRSTVWY'; % 20 standard amino acids
numAA = length(AA);

% Parent sequence (120 residues, fictional esterase)
% Real enzymes: sequence from PDB, but we generate random for simplicity
parentLength = 120;
parentSeq = AA(randi(numAA, 1, parentLength)); % Random sequence

% Catalytic triad (hypothetical positions for esterase mechanism)
% Serine nucleophile (Ser-60), Histidine base (His-85), Aspartate (Asp-102)
catalyticPositions = [60, 85, 102];

fprintf('  Parent enzyme: %d residues\n', parentLength);
fprintf('  Sequence (first 20): %s...\n', parentSeq(1:20));
fprintf('  Catalytic triad: Ser-%d, His-%d, Asp-%d\n\n', catalyticPositions);

%% Step 2: Generate Single-Point Mutant Library
fprintf('Step 2: Generating single-point mutant library...\n\n');

% For computational efficiency, sample 500 random mutations (not all 120*19=2280)
numMutants = 500;
mutantSeqs = cell(numMutants, 1);
mutationDescriptions = cell(numMutants, 1);

for i = 1:numMutants
    % Random position to mutate
    pos = randi(parentLength);
    wtAA = parentSeq(pos); % Wild-type amino acid
    
    % Random mutation (exclude wild-type)
    mutAA = wtAA;
    while mutAA == wtAA
        mutAA = AA(randi(numAA));
    end
    
    % Create mutant sequence
    mutSeq = parentSeq;
    mutSeq(pos) = mutAA;
    mutantSeqs{i} = mutSeq;
    mutationDescriptions{i} = sprintf('%s%d%s', wtAA, pos, mutAA);
end

fprintf('  Generated %d single-point mutants\n', numMutants);
fprintf('  Example mutations: %s, %s, %s\n\n', ...
        mutationDescriptions{1}, mutationDescriptions{2}, mutationDescriptions{3});

%% Step 3: Encode Sequences as Feature Vectors
fprintf('Step 3: Encoding sequences as feature vectors...\n\n');

% Feature encoding for enzymes (simplified, real methods use ESM embeddings)
% Features: (1-20) Amino acid composition (fraction of each AA)
%           (21-25) Physicochemical properties (avg hydrophobicity, charge, 
%                   aromaticity, flexibility, molecular weight)

numFeatures = 25;

% Physicochemical scales (Kyte-Doolittle hydrophobicity, etc.)
% Simplified: assign random values for demonstration
hydrophobicity = containers.Map(num2cell(AA), 1.9 + 4.5*rand(1,numAA) - 2.5); % Range -2.5 to 4.5
charge = containers.Map(num2cell(AA), [-1*ones(1,2), zeros(1,15), +1*ones(1,3)]); % D,E=-1; K,R,H=+1
aromaticity = containers.Map(num2cell(AA), [zeros(1,17), ones(1,3)]); % F,W,Y=1
flexibility = containers.Map(num2cell(AA), rand(1,numAA)); % Random 0-1
molWeight = containers.Map(num2cell(AA), 75 + 130*rand(1,numAA)); % 75-205 Da

% Function to encode a sequence
encodeSeq = @(seq) [arrayfun(@(aa) sum(seq==aa)/length(seq), AA), ... % AA composition
                    mean(arrayfun(@(aa) hydrophobicity(aa), seq)), ...
                    mean(arrayfun(@(aa) charge(aa), seq)), ...
                    mean(arrayfun(@(aa) aromaticity(aa), seq)), ...
                    mean(arrayfun(@(aa) flexibility(aa), seq)), ...
                    mean(arrayfun(@(aa) molWeight(aa), seq))];

% Encode parent + mutants
XParent = encodeSeq(parentSeq);
XMutants = zeros(numMutants, numFeatures);
for i = 1:numMutants
    XMutants(i, :) = encodeSeq(mutantSeqs{i});
end

fprintf('  Sequences encoded into %d features\n', numFeatures);
fprintf('  Features: AA composition (1-20) + physicochemical (21-25)\n\n');

%% Step 4: Simulate Ground Truth Enzyme Activity
fprintf('Step 4: Simulating ground truth enzyme activity...\n\n');

% Activity metric: kcat/Km (catalytic efficiency, M^-1 s^-1)
% Ground truth function (unknown to ML model, used for simulation)
% High activity favours: moderate hydrophobicity, neutral charge near active site,
%                         low flexibility, specific AA at catalytic positions

% Parent activity (baseline)
activityParent = 1e5; % 10^5 M^-1 s^-1 (moderate activity)

% Mutant activities: perturb based on mutation position and amino acid change
activityMutants = zeros(numMutants, 1);

for i = 1:numMutants
    % Parse mutation (e.g., "S60A" -> position 60, Ser to Ala)
    mutDesc = mutationDescriptions{i};
    pos = str2double(mutDesc(2:end-1));
    wtAA = mutDesc(1);
    mutAA = mutDesc(end);
    
    % Base activity from parent
    activity = activityParent;
    
    % Penalty for mutations at catalytic positions (large effect)
    if ismember(pos, catalyticPositions)
        activity = activity * (0.1 + 0.3*rand()); % 10-40% of parent (severe loss)
    else
        % Mutation effects depend on physicochemical changes
        deltaHydro = hydrophobicity(mutAA) - hydrophobicity(wtAA);
        deltaCharge = charge(mutAA) - charge(wtAA);
        
        % Moderate hydrophobicity changes tolerated, large changes penalized
        hydroPenalty = exp(-0.5 * deltaHydro^2);
        
        % Charge changes near active site disfavored
        distToCatalytic = min(abs(pos - catalyticPositions));
        chargePenalty = 1 - 0.3 * abs(deltaCharge) / (1 + distToCatalytic/20);
        
        % Combined effect
        activity = activity * hydroPenalty * chargePenalty * (0.8 + 0.4*rand());
    end
    
    % Add experimental noise (20% std)
    activity = activity * (1 + 0.2*randn());
    activityMutants(i) = max(1e2, activity); % Floor at 100 M^-1 s^-1
end

fprintf('  Simulated activities for %d mutants\n', numMutants);
fprintf('  Parent activity: %.2e M^-1 s^-1\n', activityParent);
fprintf('  Mutant activity range: %.2e to %.2e M^-1 s^-1\n\n', ...
        min(activityMutants), max(activityMutants));

%% Step 5: Train Machine Learning Models
fprintf('Step 5: Training machine learning models...\n\n');

% Train/test split (80/20)
numTrain = round(0.8 * numMutants);
trainIdx = randperm(numMutants, numTrain);
testIdx = setdiff(1:numMutants, trainIdx);

XTrain = XMutants(trainIdx, :);
yTrain = log10(activityMutants(trainIdx)); % Log-transform for stability
XTest = XMutants(testIdx, :);
yTest = log10(activityMutants(testIdx));

fprintf('  Train/test split: %d/%d samples\n', numTrain, numMutants - numTrain);

% Model 1: Random Forest
fprintf('  Training Random Forest...\n');
tic;
numTrees = 100;
mdlRF = TreeBagger(numTrees, XTrain, yTrain, 'Method', 'regression', ...
                   'OOBPrediction', 'on', 'MinLeafSize', 5);
timeRF = toc;

yPredRF_Train = predict(mdlRF, XTrain);
yPredRF_Test = predict(mdlRF, XTest);

rmseRF_Train = sqrt(mean((yPredRF_Train - yTrain).^2));
rmseRF_Test = sqrt(mean((yPredRF_Test - yTest).^2));
r2RF_Test = 1 - sum((yTest - yPredRF_Test).^2) / sum((yTest - mean(yTest)).^2);

fprintf('    Random Forest: RMSE_train = %.3f, RMSE_test = %.3f, R2_test = %.3f\n', ...
        rmseRF_Train, rmseRF_Test, r2RF_Test);
fprintf('    Training time: %.2f seconds\n', timeRF);

% Model 2: Neural Network (shallow, 1 hidden layer)
fprintf('  Training Neural Network...\n');
tic;
hiddenSize = 50;
net = fitnet(hiddenSize, 'trainlm'); % Levenberg-Marquardt backpropagation
net.trainParam.showWindow = false;
net.trainParam.epochs = 200;
net.divideParam.trainRatio = 0.9;
net.divideParam.valRatio = 0.1;
net.divideParam.testRatio = 0.0;

[net, tr] = train(net, XTrain', yTrain');
timeNN = toc;

yPredNN_Train = net(XTrain')';
yPredNN_Test = net(XTest')';

rmseNN_Train = sqrt(mean((yPredNN_Train - yTrain).^2));
rmseNN_Test = sqrt(mean((yPredNN_Test - yTest).^2));
r2NN_Test = 1 - sum((yTest - yPredNN_Test).^2) / sum((yTest - mean(yTest)).^2);

fprintf('    Neural Network: RMSE_train = %.3f, RMSE_test = %.3f, R2_test = %.3f\n', ...
        rmseNN_Train, rmseNN_Test, r2NN_Test);
fprintf('    Training time: %.2f seconds\n\n', timeNN);

%% Step 6: Virtual Screening of Double Mutants
fprintf('Step 6: Virtual screening of double mutants...\n\n');

% Generate 10,000 random double mutants
numDoubleMutants = 10000;
doubleMutantSeqs = cell(numDoubleMutants, 1);
doubleMutantDesc = cell(numDoubleMutants, 1);

for i = 1:numDoubleMutants
    % Two random positions
    pos1 = randi(parentLength);
    pos2 = randi(parentLength);
    while pos2 == pos1
        pos2 = randi(parentLength);
    end
    
    % Mutate both
    mutSeq = parentSeq;
    mutSeq(pos1) = AA(randi(numAA));
    mutSeq(pos2) = AA(randi(numAA));
    
    doubleMutantSeqs{i} = mutSeq;
    doubleMutantDesc{i} = sprintf('%s%d%s/%s%d%s', parentSeq(pos1), pos1, mutSeq(pos1), ...
                                  parentSeq(pos2), pos2, mutSeq(pos2));
end

% Encode double mutants
XDoubleMutants = zeros(numDoubleMutants, numFeatures);
for i = 1:numDoubleMutants
    XDoubleMutants(i, :) = encodeSeq(doubleMutantSeqs{i});
end

fprintf('  Generated %d double mutants\n', numDoubleMutants);

% Predict using Random Forest (better performance)
fprintf('  Predicting activities using Random Forest...\n');
yPredDouble = predict(mdlRF, XDoubleMutants);

% Identify top 10 predicted performers
[~, topIdx] = sort(yPredDouble, 'descend');
top10Idx = topIdx(1:10);

fprintf('  Top 10 predicted double mutants:\n');
for i = 1:10
    fprintf('    %2d. %s (predicted log10(kcat/Km) = %.2f)\n', i, ...
            doubleMutantDesc{top10Idx(i)}, yPredDouble(top10Idx(i)));
end
fprintf('\n');

%% Step 7: Feature Importance Analysis
fprintf('Step 7: Analyzing feature importance...\n\n');

% Random Forest feature importance (out-of-bag permutation)
importance = mdlRF.OOBPermutedVarDeltaError;

% Top 10 most important features
[~, importanceIdx] = sort(importance, 'descend');
top10Features = importanceIdx(1:10);

fprintf('  Top 10 most important features:\n');
featureNames = [arrayfun(@(aa) ['Freq_' aa], AA, 'UniformOutput', false), ...
                {'Hydrophobicity', 'Charge', 'Aromaticity', 'Flexibility', 'MolWeight'}];
for i = 1:10
    fprintf('    %2d. %s (importance = %.3f)\n', i, featureNames{top10Features(i)}, ...
            importance(top10Features(i)));
end
fprintf('\n');

%% Step 8: Validation - Simulate Experimental Assays for Top Predictions
fprintf('Step 8: Validating top predictions with simulated experiments...\n\n');

% "Experimentally measure" top 10 double mutants using ground truth function
% (In reality, this would be wetlab assays)
activityTop10 = zeros(10, 1);

for i = 1:10
    idx = top10Idx(i);
    seq = doubleMutantSeqs{idx};
    
    % Simplified ground truth (similar logic as single mutants)
    % Find mutation positions
    mutations = find(seq ~= parentSeq);
    
    activity = activityParent;
    for pos = mutations
        if ismember(pos, catalyticPositions)
            activity = activity * (0.1 + 0.3*rand());
        else
            % Random perturbation based on AA change
            activity = activity * (0.7 + 0.6*rand());
        end
    end
    activity = activity * (1 + 0.2*randn());
    activityTop10(i) = max(1e2, activity);
end

activityTop10_log = log10(activityTop10);

fprintf('  Experimental validation results:\n');
fprintf('    Predicted vs. Measured (log10 scale):\n');
for i = 1:10
    fprintf('      %s: %.2f (pred) vs. %.2f (exp), error = %.2f\n', ...
            doubleMutantDesc{top10Idx(i)}, yPredDouble(top10Idx(i)), ...
            activityTop10_log(i), abs(yPredDouble(top10Idx(i)) - activityTop10_log(i)));
end

validationRMSE = sqrt(mean((yPredDouble(top10Idx) - activityTop10_log).^2));
fprintf('    Validation RMSE: %.3f\n\n', validationRMSE);

%% Step 9: Visualisation
fprintf('Step 9: Visualising results...\n\n');

figure('Name', 'Enzyme Design Results', 'Position', [100, 100, 1400, 900]);

% Subplot 1: Model performance comparison
subplot(2, 3, 1);
scatter(yTrain, yPredRF_Train, 30, [0.2, 0.6, 0.8], 'filled', 'DisplayName', 'RF Train');
hold on;
scatter(yTest, yPredRF_Test, 30, [0.9, 0.4, 0.2], 'filled', 'DisplayName', 'RF Test');
plot([min(yTrain), max(yTrain)], [min(yTrain), max(yTrain)], 'k-', 'LineWidth', 2);
hold off;
xlabel('True log10(kcat/Km)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Predicted log10(kcat/Km)', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Random Forest (R = %.3f)', r2RF_Test), 'Interpreter', 'latex', 'FontSize', 13);
legend('Location', 'northwest', 'Interpreter', 'latex');
grid on;

subplot(2, 3, 2);
scatter(yTrain, yPredNN_Train, 30, [0.2, 0.6, 0.8], 'filled', 'DisplayName', 'NN Train');
hold on;
scatter(yTest, yPredNN_Test, 30, [0.9, 0.4, 0.2], 'filled', 'DisplayName', 'NN Test');
plot([min(yTrain), max(yTrain)], [min(yTrain), max(yTrain)], 'k-', 'LineWidth', 2);
hold off;
xlabel('True log10(kcat/Km)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Predicted log10(kcat/Km)', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Neural Network (R = %.3f)', r2NN_Test), 'Interpreter', 'latex', 'FontSize', 13);
legend('Location', 'northwest', 'Interpreter', 'latex');
grid on;

% Subplot 3: Feature importance
subplot(2, 3, 3);
barh(importance(importanceIdx(10:-1:1)), 'FaceColor', [0.3, 0.7, 0.4], 'EdgeColor', 'k');
yticks(1:10);
yticklabels(featureNames(importanceIdx(10:-1:1)));
xlabel('Importance (OOB Permutation)', 'Interpreter', 'latex', 'FontSize', 12);
title('Top 10 Features (Random Forest)', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Subplot 4: Activity distribution
subplot(2, 3, 4);
histogram(log10(activityMutants), 30, 'Normalization', 'probability', ...
          'FaceColor', [0.6, 0.6, 0.9], 'EdgeColor', 'k', 'FaceAlpha', 0.7);
hold on;
xline(log10(activityParent), '-r', 'LineWidth', 2, 'DisplayName', 'Parent');
xline(mean(activityTop10_log), '-g', 'LineWidth', 2, 'DisplayName', 'Top 10 Mean');
hold off;
xlabel('log10(kcat/Km)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Probability', 'Interpreter', 'latex', 'FontSize', 12);
title('Activity Distribution', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex');
grid on;

% Subplot 5: Predicted vs. experimental for top 10
subplot(2, 3, 5);
scatter(yPredDouble(top10Idx), activityTop10_log, 100, [0.9, 0.4, 0.2], 'filled', ...
        'MarkerEdgeColor', 'k', 'LineWidth', 1.5);
hold on;
plot([min(yPredDouble(top10Idx)), max(yPredDouble(top10Idx))], ...
     [min(yPredDouble(top10Idx)), max(yPredDouble(top10Idx))], 'k-', 'LineWidth', 2);
hold off;
xlabel('Predicted log10(kcat/Km)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Experimental log10(kcat/Km)', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Top 10 Validation (RMSE = %.3f)', validationRMSE), 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Subplot 6: Residual analysis
subplot(2, 3, 6);
residualsTest = yTest - yPredRF_Test;
histogram(residualsTest, 20, 'Normalization', 'probability', ...
          'FaceColor', [0.9, 0.6, 0.3], 'EdgeColor', 'k', 'FaceAlpha', 0.7);
xlabel('Residual (True - Predicted)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Probability', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Test Set Residuals (Mean = %.3f)', mean(residualsTest)), ...
      'Interpreter', 'latex', 'FontSize', 13);
grid on;

saveas(gcf, 'Problem12_EnzymeDesign.fig');
saveas(gcf, 'Problem12_EnzymeDesign.eps', 'epsc');
saveas(gcf, 'Problem12_EnzymeDesign.jpg');

fprintf('  Visualisation saved\n\n');

%% Summary
fprintf('========================================\n');
fprintf('Problem 12 Complete: Summary\n');
fprintf('========================================\n\n');

fprintf('Dataset:\n');
fprintf('  Parent enzyme: %d residues\n', parentLength);
fprintf('  Single mutants: %d (train: %d, test: %d)\n', numMutants, numTrain, numMutants-numTrain);
fprintf('  Double mutants screened: %d\n\n', numDoubleMutants);

fprintf('Model Performance:\n');
fprintf('  Random Forest:  R = %.3f, RMSE = %.3f (test set)\n', r2RF_Test, rmseRF_Test);
fprintf('  Neural Network: R = %.3f, RMSE = %.3f (test set)\n\n', r2NN_Test, rmseNN_Test);

fprintf('Virtual Screening:\n');
fprintf('  Top predicted double mutant: %s (%.2f log10(kcat/Km))\n', ...
        doubleMutantDesc{top10Idx(1)}, yPredDouble(top10Idx(1)));
fprintf('  Best experimental (from top 10): %.2f log10(kcat/Km)\n', max(activityTop10_log));
fprintf('  Improvement over parent: %.1f-fold\n', 10^(max(activityTop10_log) - log10(activityParent)));
fprintf('  Validation RMSE (top 10): %.3f\n\n', validationRMSE);

fprintf('Key Insights:\n');
fprintf('  - Random Forest slightly outperforms Neural Network (R %.3f vs. %.3f)\n', r2RF_Test, r2NN_Test);
fprintf('  - Most important features: %s, %s, %s\n', featureNames{top10Features(1:3)});
fprintf('  - Virtual screening finds %.1f-fold improvement over parent\n', 10^(max(activityTop10_log) - log10(activityParent)));
fprintf('  - ML enables exploration of 10^4 variants vs. 10^2 experimental capacity\n\n');

fprintf('Figures saved:\n');
fprintf('  - Problem12_EnzymeDesign (.fig, .eps, .jpg)\n\n');

fprintf('========================================\n');
