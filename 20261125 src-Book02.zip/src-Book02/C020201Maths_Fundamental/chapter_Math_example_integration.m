%% chapter_Math_example_integration.m
% Anonymous functions with numerical integration.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_integration
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Integrate sin(x) from 0 to pi using anonymous function
area1 = integral(@(x) sin(x), 0, pi);  % Returns 2

% Integrate x^2 * exp(-x) from 0 to infinity
area2 = integral(@(x) x.^2 .* exp(-x), 0, Inf);  % Returns 2

% Define complex function and integrate
complexFunc = @(x) exp(-x.^2/2) .* sin(x);
area3 = integral(complexFunc, -5, 5);
