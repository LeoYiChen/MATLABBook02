%% chapter_AI_Mechanics_Problem3_hierarchical_syntax.m
% Hierarchical clustering syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem3_hierarchical_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Compute pairwise distances
distanceMatrix = pdist(dataStandardised, 'euclidean');

% Perform hierarchical clustering using Ward's method
linkageTree = linkage(distanceMatrix, 'ward');

% Visualise dendrogram
figure;
dendrogram(linkageTree, 0);  % 0 = show all leaf nodes
xlabel('Defect Index', 'Interpreter', 'latex');
ylabel('Distance', 'Interpreter', 'latex');
title('Hierarchical Clustering Dendrogram (Ward Linkage)', 'Interpreter', 'latex');

% Cut tree to obtain clusters
numClusters = 4;
clusterIndicesHier = cluster(linkageTree, 'MaxClust', numClusters);
