%% ch08_prob4_code.m
% PCA dimensionality reduction with animated 3-D plot (MATLABBook02_Chapter08_Problem4.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob4_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem4.m
% --------------------------------
% Purpose : PCA on high-dimensional big data with animation.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later recommended
% --------------------------------
clc; clear; close all;

%% Step 1 – Generate synthetic high-dimensional data
fprintf('=== Step 1: Generating synthetic data ===\n');
numObservations = 100000;   % Scalable; use 1e6 for full test
numFeatures     = 200;
rng(42, 'twister');         % Reproducibility

% Create latent structure: 5 latent factors drive correlations
numLatent   = 5;
latentData  = randn(numObservations, numLatent);
loadingMat  = randn(numLatent, numFeatures) * 0.8;
noiseLevel  = 0.3;
rawData     = latentData * loadingMat + ...
              noiseLevel * randn(numObservations, numFeatures);
fprintf('  Data matrix: %d x %d\n', size(rawData));

%% Step 2 – Standardise
fprintf('\n=== Step 2: Standardising data ===\n');
dataMean = mean(rawData, 1);
dataStd  = std(rawData, 0, 1);
standardisedData = (rawData - dataMean) ./ dataStd;
fprintf('  Standardisation complete.\n');

%% Step 3 – Apply PCA
fprintf('\n=== Step 3: Performing PCA ===\n');
[coefficients, scores, ~, ~, explainedVariance] = ...
    pca(standardisedData, 'Economy', true);
fprintf('  PCA complete. Components: %d\n', size(coefficients,2));

%% Step 4 – Scree plot and cumulative variance
cumulativeVariance = cumsum(explainedVariance);
numFor95 = find(cumulativeVariance >= 95, 1, 'first');
fprintf('  Components for 95%% variance: %d\n', numFor95);

figScree = figure('Name','Scree Plot','Position',[100 100 1000 450]);
subplot(1,2,1);
bar(explainedVariance(1:30), 'FaceColor', [0.3 0.5 0.9]);
xlabel('Principal Component', 'Interpreter','latex');
ylabel('Variance Explained (\%)', 'Interpreter','latex');
title('\textbf{Scree Plot (First 30 PCs)}', 'Interpreter','latex');
grid on;
subplot(1,2,2);
plot(cumulativeVariance, 'b-', 'LineWidth', 1.5); hold on;
yline(95, 'r-', 'LineWidth', 1.2);
xline(numFor95, 'k-', 'LineWidth', 1.2);
xlabel('Number of Components', 'Interpreter','latex');
ylabel('Cumulative Variance (\%)', 'Interpreter','latex');
title('\textbf{Cumulative Explained Variance}', 'Interpreter','latex');
legend({'Cumulative','95\% Threshold',sprintf('$k=%d$',numFor95)}, ...
    'Interpreter','latex', 'Location','southeast');
grid on;

savefig(figScree, 'Ch08_Problem4_ScreePlot.fig');
exportgraphics(figScree, 'Ch08_Problem4_ScreePlot.eps', ...
    'ContentType','vector');
exportgraphics(figScree, 'Ch08_Problem4_ScreePlot.jpg', ...
    'Resolution', 300);

%% Step 5 – 3-D scatter of first three PCs
figScatter = figure('Name','PCA 3-D Scatter', ...
    'Position',[100 100 800 700]);
scatter3(scores(:,1), scores(:,2), scores(:,3), 3, ...
    scores(:,1), 'filled', 'MarkerFaceAlpha', 0.3);
xlabel('$\mathrm{PC}_1$', 'Interpreter','latex');
ylabel('$\mathrm{PC}_2$', 'Interpreter','latex');
zlabel('$\mathrm{PC}_3$', 'Interpreter','latex');
title('\textbf{First Three Principal Components}', ...
    'Interpreter','latex', 'FontSize', 13);
colorbar; colormap(turbo);
grid on; axis tight;

savefig(figScatter, 'Ch08_Problem4_PCA3D.fig');
exportgraphics(figScatter, 'Ch08_Problem4_PCA3D.jpg', ...
    'Resolution', 300);

%% Step 6 – Animate rotation and save as MP4
fprintf('\n=== Step 6: Animating 3-D rotation ===\n');
videoFileName = 'Ch08_Problem4_PCA_Rotation.mp4';
vidWriter = VideoWriter(videoFileName, 'MPEG-4');
vidWriter.FrameRate = 30;
vidWriter.Quality   = 95;
open(vidWriter);

numFrames = 360;
for frameIdx = 1:numFrames
    view(frameIdx, 25);
    drawnow;
    currentFrame = getframe(figScatter);
    writeVideo(vidWriter, currentFrame);
end
close(vidWriter);
fprintf('  Video saved: %s\n', videoFileName);

fprintf('\n=== Problem 4 Complete ===\n');
% --------------------------------
% Computational Complexity:
% Standardisation is O(N * D). PCA via SVD (MATLAB's default for
% 'Economy' mode) is O(N * D * min(N,D)), which for N >> D reduces
% to O(N * D^2). With N = 100 000 and D = 200, this is tractable.
% For truly massive N, consider 'NumComponents' to limit SVD rank.
% The animation loop is O(numFrames) and I/O-bound. Space is
% O(N * D) for the score matrix-the dominant memory cost.
% --------------------------------
