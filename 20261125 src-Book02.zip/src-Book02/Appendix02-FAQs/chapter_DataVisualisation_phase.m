%% chapter_DataVisualisation_phase.m
% Phase Portrait Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_phase
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createPhasePortrait(system_func, xlim, ylim)
% Create figure
h = figure('Position', [100 100 1000 1000]);

% Generate grid points
[X,Y] = meshgrid(linspace(xlim(1), xlim(2), 20), ...
                 linspace(ylim(1), ylim(2), 20));

% Calculate vector field
U = zeros(size(X));
V = zeros(size(X));
for i = 1:numel(X)
    [U(i),V(i)] = system_func(X(i), Y(i));
end

% Normalize vectors
norm = sqrt(U.^2 + V.^2);
U = U./norm;
V = V./norm;

% Plot vector field
quiver(X, Y, U, V, 0.5, 'b');
hold on;

% Add trajectories from various initial conditions
initial_conditions = [
    -1 -1; 1 1; -1 1; 1 -1; 0 0;
    0.5 0.5; -0.5 -0.5
];

colors = lines(size(initial_conditions,1));
for i = 1:size(initial_conditions,1)
    [t,y] = ode45(@(t,y) system_func(y(1),y(2)), ...
                  [0 10], initial_conditions(i,:));
    plot(y(:,1), y(:,2), 'Color', colors(i,:));
end

% Customize appearance
grid on;
xlabel('x');
ylabel('y');
title('Phase Portrait Analysis');
axis equal;

% Export figure
exportFigure(h, 'phase_portrait');

end

% Example system function (Van der Pol oscillator)
function [dx,dy] = vanDerPol(x,y)
mu = 1;
dx = y;
dy = mu*(1-x^2)*y - x;
end
