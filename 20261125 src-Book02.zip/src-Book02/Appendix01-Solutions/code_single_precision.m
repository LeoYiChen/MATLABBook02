%% code_single_precision.m
% Single precision eigenvalue solver.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:single_precision
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [V, lambda] = singlePrecisionEigenSolver(A, k)
    % Compute eigenvalues using single precision arithmetic
    % Input:
    %   A - Sparse matrix (double precision)
    %   k - Number of eigenvalues to compute
    % Output:
    %   V - Eigenvectors (double precision for compatibility)
    %   lambda - Eigenvalues (double precision for compatibility)
    
    % Convert to single precision
    A_single = single(full(A));  % Note: eigs requires full for single
    
    % Compute eigenvalues in single precision
    opts.issym = 1;
    opts.isreal = 1;
    [V_single, D_single] = eigs(A_single, k, 'smallestabs', opts);
    
    % Convert back to double for consistency
    V = double(V_single);
    lambda = double(diag(D_single));
end
