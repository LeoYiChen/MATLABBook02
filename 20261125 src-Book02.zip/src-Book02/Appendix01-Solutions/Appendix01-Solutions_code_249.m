%% Appendix01-Solutions_code_249.m
% Q-Learning for Cart-Pole Control
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Reinforcement Learning for Control: Q-Learning
% Problem 16: Cart-Pole Balancing with Q-Learning
% Author: Control Systems Course
% Description: Complete RL implementation with multiple algorithms

clear all; close all; clc;
rng(42);

%% System Parameters

fprintf('=== Q-Learning for Cart-Pole Control ===\n\n');

% Physical parameters
params = struct();
params.M = 1.0;              % Cart mass (kg)
params.m = 0.1;              % Pole mass (kg)
params.l = 0.5;              % Pole half-length (m)
params.g = 9.81;             % Gravity (m/s^2)
params.dt = 0.02;            % Time step (20 ms)

% Control constraints
params.u_max = 10.0;         % Maximum force (N)
params.x_limit = 2.4;        % Cart position limit (m)
params.theta_limit = 12 * pi/180;  % Pole angle limit (rad)

% Episode parameters
params.max_steps = 500;      % Maximum steps per episode
params.success_threshold = 475;  % Steps to consider success

fprintf('Cart-Pole System:\n');
fprintf('  Cart mass: %.1f kg\n', params.M);
fprintf('  Pole mass: %.1f kg\n', params.m);
fprintf('  Pole length: %.2f m\n', 2*params.l);
fprintf('  Max force:  %.1f N\n', params.u_max);
fprintf('  Position limit:  %.1f m\n', params.x_limit);
fprintf('  Angle limit:  %.1f \n\n', params.theta_limit * 180/pi);

%% Discretization for Tabular Q-Learning

fprintf('=== Discretization Setup ===\n');

% State space discretization
discretization = struct();

% Number of bins for each state variable
discretization.n_x = 10;           % Cart position bins
discretization.n_xdot = 10;        % Cart velocity bins
discretization.n_theta = 15;       % Pole angle bins
discretization.n_thetadot = 15;    % Pole angular velocity bins

% State ranges
discretization.x_range = [-params.x_limit, params.x_limit];
discretization.xdot_range = [-3, 3];
discretization.theta_range = [-params.theta_limit, params.theta_limit];
discretization.thetadot_range = [-3, 3];

% Action discretization (3 actions: -F, 0, +F)
discretization.actions = [-params.u_max, 0, params.u_max];
discretization.n_actions = length(discretization.actions);

total_states = discretization.n_x * discretization.n_xdot * ...
               discretization.n_theta * discretization.n_thetadot;

fprintf('State Space Discretization:\n');
fprintf('  Position: %d bins in [%.1f, %.1f] m\n', ...
        discretization.n_x, discretization.x_range);
fprintf('  Velocity: %d bins in [%.1f, %.1f] m/s\n', ...
        discretization.n_xdot, discretization.xdot_range);
fprintf('  Angle: %d bins in [%.1f, %.1f] \n', ...
        discretization.n_theta, discretization.theta_range * 180/pi);
fprintf('  Angular vel: %d bins in [%.1f, %.1f] rad/s\n', ...
        discretization.n_thetadot, discretization.thetadot_range);
fprintf('  Total states: %d\n', total_states);
fprintf('  Actions: %d (forces: %s N)\n\n', ...
        discretization.n_actions, mat2str(discretization.actions));

%% Q-Learning Hyperparameters

fprintf('=== Q-Learning Configuration ===\n');

ql_params = struct();
ql_params.alpha = 0.1;           % Learning rate
ql_params.gamma = 0.99;          % Discount factor
ql_params.epsilon_start = 1.0;   % Initial exploration rate
ql_params.epsilon_end = 0.01;    % Final exploration rate
ql_params.epsilon_decay = 0.995; % Epsilon decay per episode
ql_params.n_episodes = 2000;     % Number of training episodes

fprintf('Hyperparameters:\n');
fprintf('  Learning rate ( ): %.3f\n', ql_params.alpha);
fprintf('  Discount factor ( ): %.3f\n', ql_params.gamma);
fprintf('  Exploration:     [%.3f, %.3f], decay=%.4f\n', ...
        ql_params.epsilon_end, ql_params.epsilon_start, ql_params.epsilon_decay);
fprintf('  Training episodes: %d\n\n', ql_params.n_episodes);

%% Initialize Q-Table

fprintf('Initializing Q-table...\n');

% Q-table dimensions: [n_x, n_xdot, n_theta, n_thetadot, n_actions]
Q_table = zeros(discretization.n_x, discretization.n_xdot, ...
                discretization.n_theta, discretization.n_thetadot, ...
                discretization.n_actions);

% Optimistic initialization (encourage exploration)
Q_table = Q_table + 1.0;

fprintf('Q-table initialized: %s\n', mat2str(size(Q_table)));
fprintf('Memory: %.2f MB\n\n', ...
        numel(Q_table) * 8 / 1024^2);  % 8 bytes per double

%% Training: Tabular Q-Learning

fprintf('=== Training Tabular Q-Learning ===\n\n');

% Training statistics
stats = struct();
stats.episode_rewards = zeros(ql_params.n_episodes, 1);
stats.episode_lengths = zeros(ql_params.n_episodes, 1);
stats.epsilon_history = zeros(ql_params.n_episodes, 1);
stats.td_errors = cell(ql_params.n_episodes, 1);

% Current exploration rate
epsilon = ql_params.epsilon_start;

% Training loop
tic;
for episode = 1:ql_params.n_episodes
    % Initialize state
    state = initialize_state(params);
    
    episode_reward = 0;
    td_errors_ep = [];
    
    for step = 1:params.max_steps
        % Discretize current state
        state_idx = discretize_state(state, discretization);
        
        % Choose action (epsilon-greedy)
        if rand < epsilon
            action_idx = randi(discretization.n_actions);
        else
            [~, action_idx] = max(squeeze(Q_table(state_idx(1), state_idx(2), ...
                                                   state_idx(3), state_idx(4), :)));
        end
        
        action = discretization.actions(action_idx);
        
        % Take action, observe next state and reward
        [next_state, reward, done] = step_environment(state, action, params);
        
        episode_reward = episode_reward + reward;
        
        if ~done
            % Discretize next state
            next_state_idx = discretize_state(next_state, discretization);
            
            % Q-learning update
            current_Q = Q_table(state_idx(1), state_idx(2), state_idx(3), ...
                               state_idx(4), action_idx);
            max_next_Q = max(squeeze(Q_table(next_state_idx(1), next_state_idx(2), ...
                                            next_state_idx(3), next_state_idx(4), :)));
            
            td_error = reward + ql_params.gamma * max_next_Q - current_Q;
            td_errors_ep = [td_errors_ep; td_error];
            
            Q_table(state_idx(1), state_idx(2), state_idx(3), state_idx(4), action_idx) = ...
                current_Q + ql_params.alpha * td_error;
        else
            % Terminal state
            current_Q = Q_table(state_idx(1), state_idx(2), state_idx(3), ...
                               state_idx(4), action_idx);
            td_error = reward - current_Q;
            td_errors_ep = [td_errors_ep; td_error];
            
            Q_table(state_idx(1), state_idx(2), state_idx(3), state_idx(4), action_idx) = ...
                current_Q + ql_params.alpha * td_error;
        end
        
        state = next_state;
        
        if done
            break;
        end
    end
    
    % Store statistics
    stats.episode_rewards(episode) = episode_reward;
    stats.episode_lengths(episode) = step;
    stats.epsilon_history(episode) = epsilon;
    stats.td_errors{episode} = td_errors_ep;
    
    % Decay epsilon
    epsilon = max(ql_params.epsilon_end, epsilon * ql_params.epsilon_decay);
    
    % Print progress
    if mod(episode, 100) == 0 || episode == 1
        avg_reward = mean(stats.episode_rewards(max(1,episode-99):episode));
        avg_length = mean(stats.episode_lengths(max(1,episode-99):episode));
        fprintf('Episode %4d: Avg Reward = %7.2f, Avg Length = %6.1f,   = %.4f\n', ...
                episode, avg_reward, avg_length, epsilon);
    end
end

training_time = toc;
fprintf('\nTraining completed in %.2f seconds\n', training_time);
fprintf('Average time per episode: %.3f ms\n\n', training_time/ql_params.n_episodes*1000);

%% Evaluate Learned Policy

fprintf('=== Evaluating Learned Policy ===\n\n');

n_eval_episodes = 100;
eval_rewards = zeros(n_eval_episodes, 1);
eval_lengths = zeros(n_eval_episodes, 1);
successful_episodes = 0;

for ep = 1:n_eval_episodes
    state = initialize_state(params);
    episode_reward = 0;
    
    for step = 1:params.max_steps
        state_idx = discretize_state(state, discretization);
        [~, action_idx] = max(squeeze(Q_table(state_idx(1), state_idx(2), ...
                                              state_idx(3), state_idx(4), :)));
        action = discretization.actions(action_idx);
        
        [state, reward, done] = step_environment(state, action, params);
        episode_reward = episode_reward + reward;
        
        if done
            break;
        end
    end
    
    eval_rewards(ep) = episode_reward;
    eval_lengths(ep) = step;
    
    if step >= params.success_threshold
        successful_episodes = successful_episodes + 1;
    end
end

fprintf('Evaluation Results (%d episodes):\n', n_eval_episodes);
fprintf('  Mean reward: %.2f   %.2f\n', mean(eval_rewards), std(eval_rewards));
fprintf('  Mean length: %.1f   %.1f steps\n', mean(eval_lengths), std(eval_lengths));
fprintf('  Success rate: %.1f%% (%d/%d episodes)\n', ...
        successful_episodes/n_eval_episodes*100, successful_episodes, n_eval_episodes);
fprintf('  Max length: %d steps\n\n', max(eval_lengths));

%% LQR Baseline

fprintf('=== LQR Baseline Controller ===\n');

% Linearized system matrices around upright equilibrium
A = [0, 1, 0, 0;
     0, 0, -params.m*params.g/params.M, 0;
     0, 0, 0, 1;
     0, 0, (params.M + params.m)*params.g/(params.M*params.l), 0];

B = [0; 1/params.M; 0; -1/(params.M*params.l)];

% LQR cost matrices
Q_lqr = diag([10, 1, 100, 1]);  % Penalize position and angle
R_lqr = 0.01;                    % Control effort penalty

% Compute LQR gain
[K_lqr, ~, ~] = lqr(A, B, Q_lqr, R_lqr);

fprintf('LQR gain matrix:\n');
fprintf('  K = [%.4f, %.4f, %.4f, %.4f]\n', K_lqr);

% Evaluate LQR
lqr_rewards = zeros(n_eval_episodes, 1);
lqr_lengths = zeros(n_eval_episodes, 1);
lqr_successful = 0;

for ep = 1:n_eval_episodes
    state = initialize_state(params);
    episode_reward = 0;
    
    for step = 1:params.max_steps
        % LQR control law
        u = -K_lqr * state;
        u = max(-params.u_max, min(params.u_max, u));  % Saturate
        
        [state, reward, done] = step_environment(state, u, params);
        episode_reward = episode_reward + reward;
        
        if done
            break;
        end
    end
    
    lqr_rewards(ep) = episode_reward;
    lqr_lengths(ep) = step;
    
    if step >= params.success_threshold
        lqr_successful = lqr_successful + 1;
    end
end

fprintf('\nLQR Evaluation:\n');
fprintf('  Mean reward: %.2f   %.2f\n', mean(lqr_rewards), std(lqr_rewards));
fprintf('  Mean length: %.1f   %.1f steps\n', mean(lqr_lengths), std(lqr_lengths));
fprintf('  Success rate: %.1f%% (%d/%d episodes)\n\n', ...
        lqr_successful/n_eval_episodes*100, lqr_successful, n_eval_episodes);

%% Double Q-Learning

fprintf('=== Training Double Q-Learning ===\n\n');

% Initialize two Q-tables
Q1 = zeros(size(Q_table)) + 1.0;
Q2 = zeros(size(Q_table)) + 1.0;

stats_dql = struct();
stats_dql.episode_rewards = zeros(ql_params.n_episodes, 1);
stats_dql.episode_lengths = zeros(ql_params.n_episodes, 1);

epsilon = ql_params.epsilon_start;

tic;
for episode = 1:ql_params.n_episodes
    state = initialize_state(params);
    episode_reward = 0;
    
    for step = 1:params.max_steps
        state_idx = discretize_state(state, discretization);
        
        % Choose action using sum of Q-values (epsilon-greedy)
        if rand < epsilon
            action_idx = randi(discretization.n_actions);
        else
            Q_sum = squeeze(Q1(state_idx(1), state_idx(2), state_idx(3), state_idx(4), :)) + ...
                    squeeze(Q2(state_idx(1), state_idx(2), state_idx(3), state_idx(4), :));
            [~, action_idx] = max(Q_sum);
        end
        
        action = discretization.actions(action_idx);
        [next_state, reward, done] = step_environment(state, action, params);
        episode_reward = episode_reward + reward;
        
        if ~done
            next_state_idx = discretize_state(next_state, discretization);
            
            % Randomly update Q1 or Q2
            if rand < 0.5
                % Update Q1
                Q1_current = Q1(state_idx(1), state_idx(2), state_idx(3), ...
                               state_idx(4), action_idx);
                Q1_next = squeeze(Q1(next_state_idx(1), next_state_idx(2), ...
                                    next_state_idx(3), next_state_idx(4), :));
                [~, best_action] = max(Q1_next);
                Q2_next_best = Q2(next_state_idx(1), next_state_idx(2), ...
                                 next_state_idx(3), next_state_idx(4), best_action);
                
                td_error = reward + ql_params.gamma * Q2_next_best - Q1_current;
                Q1(state_idx(1), state_idx(2), state_idx(3), state_idx(4), action_idx) = ...
                    Q1_current + ql_params.alpha * td_error;
            else
                % Update Q2
                Q2_current = Q2(state_idx(1), state_idx(2), state_idx(3), ...
                               state_idx(4), action_idx);
                Q2_next = squeeze(Q2(next_state_idx(1), next_state_idx(2), ...
                                    next_state_idx(3), next_state_idx(4), :));
                [~, best_action] = max(Q2_next);
                Q1_next_best = Q1(next_state_idx(1), next_state_idx(2), ...
                                 next_state_idx(3), next_state_idx(4), best_action);
                
                td_error = reward + ql_params.gamma * Q1_next_best - Q2_current;
                Q2(state_idx(1), state_idx(2), state_idx(3), state_idx(4), action_idx) = ...
                    Q2_current + ql_params.alpha * td_error;
            end
        else
            % Terminal state update (both Q-functions)
            if rand < 0.5
                Q1_current = Q1(state_idx(1), state_idx(2), state_idx(3), ...
                               state_idx(4), action_idx);
                Q1(state_idx(1), state_idx(2), state_idx(3), state_idx(4), action_idx) = ...
                    Q1_current + ql_params.alpha * (reward - Q1_current);
            else
                Q2_current = Q2(state_idx(1), state_idx(2), state_idx(3), ...
                               state_idx(4), action_idx);
                Q2(state_idx(1), state_idx(2), state_idx(3), state_idx(4), action_idx) = ...
                    Q2_current + ql_params.alpha * (reward - Q2_current);
            end
        end
        
        state = next_state;
        if done, break; end
    end
    
    stats_dql.episode_rewards(episode) = episode_reward;
    stats_dql.episode_lengths(episode) = step;
    epsilon = max(ql_params.epsilon_end, epsilon * ql_params.epsilon_decay);
    
    if mod(episode, 100) == 0 || episode == 1
        avg_reward = mean(stats_dql.episode_rewards(max(1,episode-99):episode));
        avg_length = mean(stats_dql.episode_lengths(max(1,episode-99):episode));
        fprintf('Episode %4d: Avg Reward = %7.2f, Avg Length = %6.1f\n', ...
                episode, avg_reward, avg_length);
    end
end

dql_time = toc;
fprintf('Double Q-Learning training completed in %.2f seconds\n\n', dql_time);

% Evaluate Double Q-Learning
Q_dql_avg = (Q1 + Q2) / 2;
dql_rewards = zeros(n_eval_episodes, 1);
dql_lengths = zeros(n_eval_episodes, 1);
dql_successful = 0;

for ep = 1:n_eval_episodes
    state = initialize_state(params);
    episode_reward = 0;
    
    for step = 1:params.max_steps
        state_idx = discretize_state(state, discretization);
        [~, action_idx] = max(squeeze(Q_dql_avg(state_idx(1), state_idx(2), ...
                                                 state_idx(3), state_idx(4), :)));
        action = discretization.actions(action_idx);
        
        [state, reward, done] = step_environment(state, action, params);
        episode_reward = episode_reward + reward;
        if done, break; end
    end
    
    dql_rewards(ep) = episode_reward;
    dql_lengths(ep) = step;
    if step >= params.success_threshold
        dql_successful = dql_successful + 1;
    end
end

fprintf('Double Q-Learning Evaluation:\n');
fprintf('  Mean reward: %.2f   %.2f\n', mean(dql_rewards), std(dql_rewards));
fprintf('  Mean length: %.1f   %.1f steps\n', mean(dql_lengths), std(dql_lengths));
fprintf('  Success rate: %.1f%%\n\n', dql_successful/n_eval_episodes*100);

%% Visualization: Learning Curves

fprintf('=== Generating Visualizations ===\n\n');

figure('Position', [50 50 1600 1000]);

% Plot 1: Episode rewards
subplot(3,3,1);
window = 50;
plot(movmean(stats.episode_rewards, window), 'b', 'LineWidth', 1.5);
hold on;
plot(movmean(stats_dql.episode_rewards, window), 'r', 'LineWidth', 1.5);
yline(mean(lqr_rewards), 'g-', 'LineWidth', 2);
grid on;
xlabel('Episode');
ylabel('Cumulative Reward');
title('Learning Progress (Rewards)');
legend('Q-Learning', 'Double Q-Learning', 'LQR Baseline', 'Location', 'southeast');

% Plot 2: Episode lengths
subplot(3,3,2);
plot(movmean(stats.episode_lengths, window), 'b', 'LineWidth', 1.5);
hold on;
plot(movmean(stats_dql.episode_lengths, window), 'r', 'LineWidth', 1.5);
yline(mean(lqr_lengths), 'g-', 'LineWidth', 2);
yline(params.success_threshold, 'k-', 'LineWidth', 1);
grid on;
xlabel('Episode');
ylabel('Steps');
title('Episode Length');
legend('Q-Learning', 'Double Q-Learning', 'LQR', 'Success Threshold', ...
       'Location', 'southeast');

% Plot 3: Exploration rate
subplot(3,3,3);
plot(stats.epsilon_history, 'b', 'LineWidth', 1.5);
grid on;
xlabel('Episode');
ylabel(' ');
title('Exploration Rate Decay');
ylim([0 1]);

% Plot 4: TD error evolution
subplot(3,3,4);
td_errors_flat = [];
episode_nums = [];
for ep = 1:100:ql_params.n_episodes
    td_errors_flat = [td_errors_flat; stats.td_errors{ep}];
    episode_nums = [episode_nums; ep * ones(length(stats.td_errors{ep}), 1)];
end
scatter(episode_nums, abs(td_errors_flat), 5, 'b', 'filled', 'MarkerFaceAlpha', 0.3);
set(gca, 'YScale', 'log');
grid on;
xlabel('Episode');
ylabel('|TD Error|');
title('TD Error Magnitude (sampled)');

% Plot 5: Performance comparison
subplot(3,3,5);
boxplot([eval_lengths, dql_lengths, lqr_lengths], ...
        'Labels', {'Q-Learning', 'Double QL', 'LQR'});
ylabel('Episode Length (steps)');
title('Performance Comparison');
grid on;

% Plot 6: Success rate over time
subplot(3,3,6);
success_window = 100;
success_ql = zeros(ql_params.n_episodes - success_window + 1, 1);
success_dql = zeros(ql_params.n_episodes - success_window + 1, 1);

for i = 1:length(success_ql)
    success_ql(i) = 100 * sum(stats.episode_lengths(i:i+success_window-1) >= ...
                              params.success_threshold) / success_window;
    success_dql(i) = 100 * sum(stats_dql.episode_lengths(i:i+success_window-1) >= ...
                               params.success_threshold) / success_window;
end

plot(success_ql, 'b', 'LineWidth', 1.5);
hold on;
plot(success_dql, 'r', 'LineWidth', 1.5);
yline(lqr_successful/n_eval_episodes*100, 'g-', 'LineWidth', 2);
grid on;
xlabel('Episode');
ylabel('Success Rate (%)');
title(sprintf('Success Rate (last %d episodes)', success_window));
legend('Q-Learning', 'Double QL', 'LQR', 'Location', 'southeast');
ylim([0 105]);

% Plot 7: Reward distribution
subplot(3,3,7);
histogram(eval_rewards, 20, 'FaceColor', 'b', 'FaceAlpha', 0.3, 'Normalization', 'pdf');
hold on;
histogram(dql_rewards, 20, 'FaceColor', 'r', 'FaceAlpha', 0.3, 'Normalization', 'pdf');
histogram(lqr_rewards, 20, 'FaceColor', 'g', 'FaceAlpha', 0.3, 'Normalization', 'pdf');
grid on;
xlabel('Cumulative Reward');
ylabel('Probability Density');
title('Reward Distribution (Evaluation)');
legend('Q-Learning', 'Double QL', 'LQR', 'Location', 'northwest');

% Plot 8: Learning rate analysis
subplot(3,3,8);
episodes_to_solve = find(movmean(stats.episode_lengths, window) >= params.success_threshold, 1);
episodes_to_solve_dql = find(movmean(stats_dql.episode_lengths, window) >= params.success_threshold, 1);

bar([episodes_to_solve, episodes_to_solve_dql, 0], 'FaceColor', 'flat', ...
    'CData', [0 0 1; 1 0 0; 0 1 0]);
set(gca, 'XTickLabel', {'Q-Learning', 'Double QL', 'LQR'});
ylabel('Episodes to Solve');
title('Learning Efficiency');
grid on;

% Plot 9: Value function visualization (slice)
subplot(3,3,9);
theta_idx = ceil(discretization.n_theta / 2);  %   = 0
thetadot_idx = ceil(discretization.n_thetadot / 2);  %  _dot = 0

V_slice = max(Q_table(:, :, theta_idx, thetadot_idx, :), [], 5);

x_bins = linspace(discretization.x_range(1), discretization.x_range(2), discretization.n_x);
xdot_bins = linspace(discretization.xdot_range(1), discretization.xdot_range(2), discretization.n_xdot);

imagesc(x_bins, xdot_bins, V_slice');
colorbar;
xlabel('Position x (m)');
ylabel('Velocity  (m/s)');
title('Value Function V(x,) at  =0,  =0');
axis xy;

sgtitle('Q-Learning Training Analysis', 'FontSize', 14, 'FontWeight', 'bold');

%% Simulation Visualization

% Run one episode with visualization
fprintf('Running visualization episode...\n');

state = [0; 0; 0.05; 0];  % Start with small angle
trajectory = zeros(params.max_steps, 4);
actions_taken = zeros(params.max_steps, 1);
rewards_viz = zeros(params.max_steps, 1);

for step = 1:params.max_steps
    trajectory(step, :) = state';
    
    state_idx = discretize_state(state, discretization);
    [~, action_idx] = max(squeeze(Q_table(state_idx(1), state_idx(2), ...
                                          state_idx(3), state_idx(4), :)));
    action = discretization.actions(action_idx);
    actions_taken(step) = action;
    
    [state, reward, done] = step_environment(state, action, params);
    rewards_viz(step) = reward;
    
    if done
        trajectory = trajectory(1:step, :);
        actions_taken = actions_taken(1:step);
        rewards_viz = rewards_viz(1:step);
        break;
    end
end

t_viz = (0:length(trajectory)-1) * params.dt;

figure('Position', [100 100 1400 900]);

subplot(3,2,1);
plot(t_viz, trajectory(:,1), 'b', 'LineWidth', 1.5);
hold on;
yline(params.x_limit, 'r-', 'LineWidth', 1);
yline(-params.x_limit, 'r-', 'LineWidth', 1);
grid on;
xlabel('Time (s)');
ylabel('Position x (m)');
title('Cart Position');
legend('x', ' Limit', 'Location', 'best');

subplot(3,2,2);
plot(t_viz, trajectory(:,3) * 180/pi, 'r', 'LineWidth', 1.5);
hold on;
yline(params.theta_limit * 180/pi, 'r-', 'LineWidth', 1);
yline(-params.theta_limit * 180/pi, 'r-', 'LineWidth', 1);
grid on;
xlabel('Time (s)');
ylabel('Angle   ( )');
title('Pole Angle');
legend(' ', ' Limit', 'Location', 'best');

subplot(3,2,3);
plot(t_viz, trajectory(:,2), 'b', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Velocity  (m/s)');
title('Cart Velocity');

subplot(3,2,4);
plot(t_viz, trajectory(:,4), 'r', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Angular Velocity   (rad/s)');
title('Pole Angular Velocity');

subplot(3,2,5);
stairs(t_viz, actions_taken, 'k', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Force u (N)');
title('Control Actions');

subplot(3,2,6);
plot(t_viz, cumsum(rewards_viz), 'g', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Cumulative Reward');
title(sprintf('Total Reward: %.2f', sum(rewards_viz)));

sgtitle(sprintf('Q-Learning Controller Performance (%d steps)', length(t_viz)), ...
        'FontSize', 14, 'FontWeight', 'bold');

%% Policy Visualization

fprintf('Generating policy visualization...\n');

figure('Position', [150 150 1400 800]);

% Fix theta and thetadot, show policy for x and xdot
theta_idx = ceil(discretization.n_theta / 2);
thetadot_idx = ceil(discretization.n_thetadot / 2);

policy_map = zeros(discretization.n_x, discretization.n_xdot);

for i = 1:discretization.n_x
    for j = 1:discretization.n_xdot
        Q_values = squeeze(Q_table(i, j, theta_idx, thetadot_idx, :));
        [~, best_action] = max(Q_values);
        policy_map(i, j) = discretization.actions(best_action);
    end
end

subplot(1,2,1);
imagesc(x_bins, xdot_bins, policy_map');
colorbar;
xlabel('Position x (m)');
ylabel('Velocity  (m/s)');
title('Learned Policy  (x,) at  =0,  =0');
axis xy;
caxis([-params.u_max, params.u_max]);

% LQR policy for comparison
lqr_policy_map = zeros(discretization.n_x, discretization.n_xdot);

for i = 1:discretization.n_x
    for j = 1:discretization.n_xdot
        x_val = discretization.x_range(1) + (i-0.5) * diff(discretization.x_range) / discretization.n_x;
        xdot_val = discretization.xdot_range(1) + (j-0.5) * diff(discretization.xdot_range) / discretization.n_xdot;
        
        state = [x_val; xdot_val; 0; 0];
        u_lqr = -K_lqr * state;
        lqr_policy_map(i, j) = max(-params.u_max, min(params.u_max, u_lqr));
    end
end

subplot(1,2,2);
imagesc(x_bins, xdot_bins, lqr_policy_map');
colorbar;
xlabel('Position x (m)');
ylabel('Velocity  (m/s)');
title('LQR Policy at  =0,  =0');
axis xy;
caxis([-params.u_max, params.u_max]);

sgtitle('Policy Comparison', 'FontSize', 14, 'FontWeight', 'bold');

%% Summary Statistics

fprintf('\n=== Summary ===\n\n');
fprintf('Algorithm Performance Comparison:\n');
fprintf('%-20s | %10s | %10s | %10s\n', 'Method', 'Avg Length', 'Success %%', 'Avg Reward');
fprintf('%s\n', repmat('-', 1, 60));
fprintf('%-20s | %10.1f | %10.1f | %10.2f\n', 'Q-Learning', mean(eval_lengths), ...
        successful_episodes/n_eval_episodes*100, mean(eval_rewards));
fprintf('%-20s | %10.1f | %10.1f | %10.2f\n', 'Double Q-Learning', mean(dql_lengths), ...
        dql_successful/n_eval_episodes*100, mean(dql_rewards));
fprintf('%-20s | %10.1f | %10.1f | %10.2f\n', 'LQR', mean(lqr_lengths), ...
        lqr_successful/n_eval_episodes*100, mean(lqr_rewards));

fprintf('\n');
fprintf('Learning Statistics:\n');
fprintf('  Episodes to solve (Q-Learning): %d\n', episodes_to_solve);
fprintf('  Episodes to solve (Double Q-Learning): %d\n', episodes_to_solve_dql);
fprintf('  Training time (Q-Learning): %.2f s\n', training_time);
fprintf('  Training time (Double Q-Learning): %.2f s\n', dql_time);

fprintf('\nKey Insights:\n');
fprintf('   Q-Learning successfully learned stabilizing controller\n');
fprintf('   Double Q-Learning reduces overestimation bias\n');
if mean(eval_lengths) > mean(lqr_lengths)
    fprintf('   RL outperforms LQR in this nonlinear regime\n');
else
    fprintf('   LQR performs comparably (linear approximation valid)\n');
end
fprintf('   Discretization introduces quantization in policy\n');
fprintf('   Exploration-exploitation tradeoff crucial for learning\n');

fprintf('\n=== Q-Learning for Control Complete ===\n');

%% Helper Functions

function state = initialize_state(params)
    % Initialize state with small random perturbations
    state = zeros(4, 1);
    state(1) = (rand - 0.5) * 0.1;  % Small random position
    state(3) = (rand - 0.5) * 0.1;  % Small random angle
end

function state_idx = discretize_state(state, disc)
    % Discretize continuous state to indices
    x_idx = discretize_value(state(1), disc.x_range, disc.n_x);
    xdot_idx = discretize_value(state(2), disc.xdot_range, disc.n_xdot);
    theta_idx = discretize_value(state(3), disc.theta_range, disc.n_theta);
    thetadot_idx = discretize_value(state(4), disc.thetadot_range, disc.n_thetadot);
    
    state_idx = [x_idx, xdot_idx, theta_idx, thetadot_idx];
end

function idx = discretize_value(value, range, n_bins)
    % Discretize single value
    value = max(range(1), min(range(2), value));  % Clip to range
    bin_width = (range(2) - range(1)) / n_bins;
    idx = floor((value - range(1)) / bin_width) + 1;
    idx = max(1, min(n_bins, idx));
end

function [next_state, reward, done] = step_environment(state, action, params)
    % Simulate one step of cart-pole dynamics
    
    % Current state
    x = state(1);
    xdot = state(2);
    theta = state(3);
    thetadot = state(4);
    
    % Equations of motion
    sin_theta = sin(theta);
    cos_theta = cos(theta);
    
    temp = (action + params.m * params.l * thetadot^2 * sin_theta) / (params.M + params.m);
    thetaacc = (params.g * sin_theta - cos_theta * temp) / ...
               (params.l * (4/3 - params.m * cos_theta^2 / (params.M + params.m)));
    xacc = temp - params.m * params.l * thetaacc * cos_theta / (params.M + params.m);
    
    % Euler integration
    x = x + params.dt * xdot;
    xdot = xdot + params.dt * xacc;
    theta = theta + params.dt * thetadot;
    thetadot = thetadot + params.dt * thetaacc;
    
    next_state = [x; xdot; theta; thetadot];
    
    % Check termination
    done = abs(x) > params.x_limit || abs(theta) > params.theta_limit;
    
    % Reward function (shaped reward)
    if ~done
        reward = 1.0 - abs(theta)/params.theta_limit - abs(x)/(2*params.x_limit);
    else
        reward = -10;  % Large penalty for falling
    end
end
