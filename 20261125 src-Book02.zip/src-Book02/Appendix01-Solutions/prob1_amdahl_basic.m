%% prob1_amdahl_basic.m
% Amdahl's Law speedup calculation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob1_amdahl_basic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function speedup = calculateAmdahlSpeedup(parallelFraction, numProcessors)
    % Computes theoretical speedup using Amdahl's Law
    serialFraction = 1 - parallelFraction;
    speedup = 1 / (serialFraction + parallelFraction / numProcessors);
end
