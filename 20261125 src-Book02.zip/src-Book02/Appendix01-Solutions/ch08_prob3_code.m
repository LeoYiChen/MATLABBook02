%% ch08_prob3_code.m
% MapReduce pipeline (MATLABBook02_Chapter08_Problem3.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob3_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem3.m
% --------------------------------
% Purpose : MapReduce workflow for global mean and variance.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later recommended
% --------------------------------
clc; clear; close all;

%% Step 1 – Create datastore
dataFolder      = fullfile(pwd, 'SyntheticSensorData');
sensorDatastore = tabularTextDatastore(dataFolder, ...
    'FileExtensions', '.csv', 'MissingValue', NaN);
featureNames    = sensorDatastore.SelectedVariableNames;
fprintf('=== Step 1: Datastore ready (%d files) ===\n', ...
    numel(sensorDatastore.Files));

%% Step 2 – Run MapReduce
fprintf('\n=== Step 2: Running mapreduce ===\n');
outputKeyValueStore = mapreduce(sensorDatastore, ...
    @meanVarianceMapper, @meanVarianceReducer);

%% Step 3 – Read results
resultTable = readall(outputKeyValueStore);
fprintf('\n=== Step 3: MapReduce Results ===\n');
for rowIdx = 1:height(resultTable)
    keyName = resultTable.Key{rowIdx};
    valStruct = resultTable.Value{rowIdx};
    fprintf('  Feature: %12s | Mean: %8.3f | Variance: %8.3f\n', ...
        keyName, valStruct.Mean, valStruct.Variance);
end

%% Step 4 – Validate with tall arrays
fprintf('\n=== Step 4: Validation with tall arrays ===\n');
tallData    = tall(sensorDatastore);
tallMeans   = gather(mean(tallData{:,:}, 'omitnan'));
tallVars    = gather(var(tallData{:,:}, 0, 'omitnan'));
for idx = 1:numel(featureNames)
    fprintf('  %12s | Tall Mean: %8.3f | Tall Var: %8.3f\n', ...
        featureNames{idx}, tallMeans(idx), tallVars(idx));
end

%% Step 5 – Visualise
meanValues = zeros(1, numel(featureNames));
varValues  = zeros(1, numel(featureNames));
for rowIdx = 1:height(resultTable)
    idx = find(strcmp(featureNames, resultTable.Key{rowIdx}));
    valStruct = resultTable.Value{rowIdx};
    meanValues(idx) = valStruct.Mean;
    varValues(idx)  = valStruct.Variance;
end

figMR = figure('Name','MapReduce Results','Position',[100 100 900 400]);
barData = [meanValues; varValues]';
bar(barData);
set(gca, 'XTickLabel', featureNames, 'TickLabelInterpreter','latex');
legend({'$\mu$ (Mean)','$\sigma^2$ (Variance)'}, ...
    'Interpreter','latex', 'Location','northwest');
title('\textbf{MapReduce: Per-Feature Mean and Variance}', ...
    'Interpreter','latex', 'FontSize', 13);
ylabel('Value', 'Interpreter','latex');
grid on;

savefig(figMR, 'Ch08_Problem3_MapReduce.fig');
exportgraphics(figMR, 'Ch08_Problem3_MapReduce.eps', ...
    'ContentType','vector');
exportgraphics(figMR, 'Ch08_Problem3_MapReduce.jpg', ...
    'Resolution', 300);
fprintf('\n=== Problem 3 Complete ===\n');
% --------------------------------
% Computational Complexity:
% The mapper visits every row once: O(N * D). The reducer combines
% F partial results (one per file) for each feature: O(F * D). The
% overall complexity is therefore O(N * D + F * D), dominated by
% the mapper pass, i.e. O(N * D). Space in the mapper is O(D) per
% chunk; in the reducer it is O(F) per key. This is equivalent to
% the tall-array approach but offers greater customisation.
% --------------------------------
