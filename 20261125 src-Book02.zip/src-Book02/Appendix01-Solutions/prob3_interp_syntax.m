%% prob3_interp_syntax.m
% Surface interpolation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob3_interp_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create interpolant object
F = scatteredInterpolant(x, y, z, 'natural');
% Evaluate on regular grid
[Xq, Yq] = meshgrid(xq, yq);
Zq = F(Xq, Yq);
% Create surface plot
surf(Xq, Yq, Zq);
