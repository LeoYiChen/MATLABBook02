%% C0201Introduction_code_008.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Implementation with clear section comments
    % ... function body ...
end

% Local functions (moved to end so this listing is a valid MATLAB script)
function [output1, output2] = myFunction(input1, input2, options)
    % MYFUNCTION Brief one-line description
    %   Detailed description explaining purpose, methodology, and context.
    %   Can span multiple lines and include mathematical notation.
    %
    %   Syntax:
    %     output1 = myFunction(input1, input2)
    %     [output1, output2] = myFunction(input1, input2, options)
    %
    %   Inputs:
    %     input1 - Description of first input (type, dimensions, constraints)
    %     input2 - Description of second input
    %     options - (Optional) Structure containing:
    %               .field1 - Description (default: value)
    %               .field2 - Description (default: value)
    %
    %   Outputs:
    %     output1 - Description of first output
    %     output2 - Description of second output (optional)
    %
    %   Example:
    %     % Basic usage
    %     result = myFunction(data, parameters);
    %
    %     % Advanced usage with options
    %     opts.field1 = value1;
    %     [result, metadata] = myFunction(data, parameters, opts);
    %
    %   See also: RELATEDFUNCTION1, RELATEDFUNCTION2
    %
    %   References:
    %     [1] Author (Year). "Title". Journal, vol(issue), pages.
    %
    %   Author: Your Name
    %   Email: your.email@institution.ac.uk
    %   Created: DD-Mon-YYYY
    %   Modified: DD-Mon-YYYY (description of changes)
    %   Version: 1.2.3
    %   MATLAB Version: R2023b
    
    % Input validation
    arguments
        input1 double {mustBeNumeric, mustBeFinite}
        input2 double {mustBePositive}
        options.field1 double = 1.0
        options.field2 char {mustBeMember(options.field2, ...
            {'option1', 'option2'})} = 'option1'
    end
