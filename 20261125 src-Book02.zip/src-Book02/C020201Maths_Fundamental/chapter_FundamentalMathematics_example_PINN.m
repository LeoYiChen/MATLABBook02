%% chapter_FundamentalMathematics_example_PINN.m
% Physics-informed loss function incorporating differential equations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_PINN
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Physics-Informed Neural Network Loss Function
% Demonstrates combining data loss with physics constraints

% Example: 1*D heat equation du/dt = alpha * d2u/dx2

% Simplified network evaluation (placeholder)

% Demonstrate loss calculation
demoParameters = randn(10, 1);
demoDataPoints = [0.5, 1.0, 1.5; 0.1, 0.2, 0.3];
demoDataValues = [0.8, 0.6, 0.4];
demoPhysicsDomain = rand(2, 50);
alpha = 0.01;

loss = pinnLossFunction(demoParameters, demoDataPoints, ...
    demoDataValues, demoPhysicsDomain, alpha);

fprintf('Physics-Informed Neural Network Loss: %.6f\n', loss);
fprintf('Combines data fitting with physics constraints\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function totalLoss = pinnLossFunction(networkParameters, ...
    dataPoints, dataValues, physicsDomain, thermalDiffusivity)
    
    % Data loss: how well network fits observations
    networkPredictions = evaluateNetwork(networkParameters, dataPoints);
    dataLoss = mean((networkPredictions - dataValues).^2);
    
    % Physics loss: how well network satisfies PDE
    numPhysicsPoints = size(physicsDomain, 2);
    physicsLoss = 0;
    
    for pointIdx = 1:numPhysicsPoints
        x = physicsDomain(1, pointIdx);
        t = physicsDomain(2, pointIdx);
        
        % Compute derivatives using automatic differentiation
        % (simplified for demonstration)
        delta*X = 1e-6;
        delta*T = 1e-6;
        
        u = evaluateNetwork(networkParameters, [x; t]);
        dudt = (evaluateNetwork(networkParameters, [x; t+delta*T]) - u) / delta*T;
        d2udx2 = (evaluateNetwork(networkParameters, [x+delta*X; t]) - ...
                  2*u + ...
                  evaluateNetwork(networkParameters, [x-delta*X; t])) / (delta*X^2);
        
        % PDE residual: du/dt - alpha * d2u/dx2 should be zero
        pdeResidual = dudt - thermalDiffusivity * d2udx2;
        physicsLoss = physicsLoss + pdeResidual^2;
    end
    
    physicsLoss = physicsLoss / numPhysicsPoints;
    
    % Combine losses with weighting factor
    lambda*Physics = 0.01;
    totalLoss = dataLoss + lambda*Physics * physicsLoss;
end

function output = evaluateNetwork(parameters, input)
    % This would normally evaluate neural network
    % Simplified for demonstration purposes
    output = sin(input(1)) * exp(-input(2));
end
