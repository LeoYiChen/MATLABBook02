%% ch08_prob3_reducer.m
% Reducer function (meanVarianceReducer.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob3_reducer
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function meanVarianceReducer(intermKey, intermValIter, outKVStore)
% meanVarianceReducer  Combine partial sums to global statistics.
% Author : Dr Yi Chen | Version 1.0 | 2026
    totalCount = 0;
    totalSum   = 0;
    totalSumSq = 0;
    while hasnext(intermValIter)
        partialResult = getnext(intermValIter);
        totalCount = totalCount + partialResult.Count;
        totalSum   = totalSum   + partialResult.Sum;
        totalSumSq = totalSumSq + partialResult.SumSq;
    end
    globalMean     = totalSum / totalCount;
    globalVariance = (totalSumSq / totalCount) - globalMean^2;
    result.Mean     = globalMean;
    result.Variance = globalVariance;
    add(outKVStore, intermKey, result);
end
% Complexity per key: O(F) where F = number of files.
