%% C0201Introduction_code_019.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Example: Unit tests for eigenvalue computation






% Run tests
results = run(testEigenvalueComputation);
disp(results);

% Local functions (moved to end so this listing is a valid MATLAB script)
function tests = testEigenvalueComputation
    % TESTEIGENVALUECOMPUTATION Test suite for eigenvalue algorithms
    
    tests = functiontests(localfunctions);
end

function testSymmetricMatrix(testCase)
    % Test symmetric matrix eigenvalues are real
    
    A = [4, 1, 2; 1, 3, 1; 2, 1, 5];  % Symmetric
    eigenvalues = eig(A);
    
    verifyTrue(testCase, isreal(eigenvalues), ...
        'Symmetric matrix must have real eigenvalues');
end

function testOrthogonalEigenvectors(testCase)
    % Test eigenvectors are orthogonal for symmetric matrices
    
    A = [2, -1, 0; -1, 2, -1; 0, -1, 2];  % Symmetric tridiagonal
    [V, D] = eig(A);
    
    % Check orthogonality: V'*V should be identity
    identity = V' * V;
    verifyLessThan(testCase, norm(identity - eye(3), 'fro'), 1e-10, ...
        'Eigenvectors must be orthogonal');
end

function testEigenvalueReconstruction(testCase)
    % Test A*v = lambda*v
    
    A = magic(5);
    [V, D] = eig(A);
    
    for i = 1:size(A, 1)
        v = V(:, i);
        lambda = D(i, i);
        
        lhs = A * v;
        rhs = lambda * v;
        
        relativeError = norm(lhs - rhs) / (norm(lhs) + eps);
        verifyLessThan(testCase, relativeError, 1e-10, ...
            sprintf('Eigenvalue equation failed for eigenvalue %d', i));
    end
end

function testDeterminantFromEigenvalues(testCase)
    % Test det(A) = product of eigenvalues
    
    A = randn(4, 4);
    detDirect = det(A);
    eigenvalues = eig(A);
    detFromEig = prod(eigenvalues);
    
    relativeError = abs(detDirect - detFromEig) / (abs(detDirect) + eps);
    verifyLessThan(testCase, relativeError, 1e-10, ...
        'Determinant must equal product of eigenvalues');
end
