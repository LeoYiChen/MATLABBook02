%% Appendix01-Solutions_code_245.m
% NSGA-II for Multi-Objective PID Optimization
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% NSGA-II for Multi-Objective PID Control Optimization
% Problem 12: Multi-Objective GA
% Author: Control Systems Course
% Description: Complete NSGA-II for Pareto-optimal PID design

clear all; close all; clc;

%% System Definition: Aircraft Pitch Control
fprintf('=== NSGA-II Multi-Objective PID Optimization ===\n');
fprintf('Application: Aircraft Pitch Control\n\n');

% Transfer function: G(s) = 160(s+2.5)/(s(s^2+5s+40))
num = 160 * [1, 2.5];
den = conv([1, 0], [1, 5, 40]);
G = tf(num, den);

fprintf('Aircraft Pitch Dynamics:\n');
fprintf('G(s) = 160(s+2.5) / [s(s^2 + 5s + 40)]\n\n');

% System analysis
poles_sys = pole(G);
zeros_sys = zero(G);
[Gm, Pm, Wcg, Wcp] = margin(G);

fprintf('Open-loop characteristics:\n');
fprintf('  Poles: '); disp(poles_sys');
fprintf('  Zero: %.2f\n', zeros_sys);
fprintf('  Unstable poles: %d\n', sum(real(poles_sys) > 0));

% Discretization
Ts = 0.01;  % 10ms sampling
Gz = c2d(G, Ts, 'zoh');
fprintf('  Sampling time: %.3f s\n\n', Ts);

%% NSGA-II Parameters
nsga_params = struct();

% Population
nsga_params.pop_size = 100;          % Larger for better Pareto front
nsga_params.n_generations = 150;     % More generations for convergence
nsga_params.archive_size = 50;       % Store best Pareto solutions

% Genetic operators
nsga_params.p_crossover = 0.9;
nsga_params.p_mutation = 0.1;
nsga_params.eta_c = 20;              % Crossover distribution index
nsga_params.eta_m = 20;              % Mutation distribution index

% Search space
nsga_params.Kp_min = 0;
nsga_params.Kp_max = 50;
nsga_params.Ki_min = 0;
nsga_params.Ki_max = 30;
nsga_params.Kd_min = 0;
nsga_params.Kd_max = 15;

fprintf('NSGA-II Configuration:\n');
fprintf('  Population: %d\n', nsga_params.pop_size);
fprintf('  Generations: %d\n', nsga_params.n_generations);
fprintf('  Crossover prob: %.2f\n', nsga_params.p_crossover);
fprintf('  Mutation prob: %.2f\n\n', nsga_params.p_mutation);

%% Objective Function Definitions
obj_params = struct();
obj_params.Ts = Ts;
obj_params.T_sim = 10;               % Longer simulation for robustness
obj_params.setpoint = 1;             % Unit step
obj_params.n_objectives = 3;         % ITAE, Control Effort, Robustness

% Constraint parameters
obj_params.max_overshoot = 20;       % 20% maximum
obj_params.max_control = 25;         % Elevator limit (degrees)
obj_params.min_GM = 6;               % 6 dB minimum
obj_params.min_PM = 45;              % 45 degrees minimum

fprintf('Optimization Objectives:\n');
fprintf('  1. Minimize ITAE (tracking performance)\n');
fprintf('  2. Minimize control effort (energy)\n');
fprintf('  3. Maximize stability margins (robustness)\n\n');

fprintf('Constraints:\n');
fprintf('  Max overshoot: %.0f%%\n', obj_params.max_overshoot);
fprintf('  Control limit: +/- %.0f deg\n', obj_params.max_control);
fprintf('  Min gain margin: %.0f dB\n', obj_params.min_GM);
fprintf('  Min phase margin: %.0f deg\n\n', obj_params.min_PM);

%% Initialize Population
fprintf('Initializing population...\n');

population = initialize_population(nsga_params);
fprintf('Population initialized with %d individuals.\n', nsga_params.pop_size);

%% Storage for Evolution
pareto_history = cell(nsga_params.n_generations, 1);
hypervolume_history = zeros(nsga_params.n_generations, 1);
n_pareto_history = zeros(nsga_params.n_generations, 1);

% Reference point for hypervolume (nadir point)
ref_point = [100, 1000, 100];  % Worst acceptable values

%% NSGA-II Main Loop
fprintf('\nStarting NSGA-II optimization...\n');
fprintf('Gen | Pareto Size | Hypervolume | Best ITAE | Best Effort | Best Robust\n');
fprintf('--|-------|-------|------|-------|------\n');

tic;
for gen = 1:nsga_params.n_generations
    
    % Evaluate objectives for population
    objectives = zeros(nsga_params.pop_size, obj_params.n_objectives);
    constraints_violated = false(nsga_params.pop_size, 1);
    
    for i = 1:nsga_params.pop_size
        Kp = population(i, 1);
        Ki = population(i, 2);
        Kd = population(i, 3);
        
        [obj, violated] = evaluate_multi_objectives(Kp, Ki, Kd, G, Gz, obj_params);
        objectives(i, :) = obj;
        constraints_violated(i) = violated;
    end
    
    % Create offspring
    offspring = create_offspring(population, objectives, nsga_params);
    
    % Evaluate offspring
    offspring_obj = zeros(nsga_params.pop_size, obj_params.n_objectives);
    offspring_violated = false(nsga_params.pop_size, 1);
    
    for i = 1:nsga_params.pop_size
        Kp = offspring(i, 1);
        Ki = offspring(i, 2);
        Kd = offspring(i, 3);
        
        [obj, violated] = evaluate_multi_objectives(Kp, Ki, Kd, G, Gz, obj_params);
        offspring_obj(i, :) = obj;
        offspring_violated(i) = violated;
    end
    
    % Combine parent and offspring
    combined_pop = [population; offspring];
    combined_obj = [objectives; offspring_obj];
    combined_violated = [constraints_violated; offspring_violated];
    
    % Constraint handling: penalize heavily
    penalty = 1e6;
    for i = 1:size(combined_pop, 1)
        if combined_violated(i)
            combined_obj(i, :) = combined_obj(i, :) + penalty;
        end
    end
    
    % Non-dominated sorting
    [fronts, ranks] = fast_nondominated_sort(combined_obj);
    
    % Calculate crowding distance
    crowding_dist = calculate_crowding_distance(combined_obj, fronts);
    
    % Select next generation
    [population, objectives] = select_next_generation(combined_pop, combined_obj, ...
                                                       ranks, crowding_dist, nsga_params.pop_size);
    
    % Store Pareto front (rank 1 solutions)
    pareto_indices = find(ranks(1:size(population,1)) == 1);
    pareto_pop = population(pareto_indices, :);
    pareto_obj = objectives(pareto_indices, :);
    
    pareto_history{gen}.population = pareto_pop;
    pareto_history{gen}.objectives = pareto_obj;
    n_pareto_history(gen) = length(pareto_indices);
    
    % Calculate hypervolume (quality metric)
    hypervolume_history(gen) = calculate_hypervolume(pareto_obj, ref_point);
    
    % Display progress
    if mod(gen, 15) == 0 || gen == 1
        fprintf('%3d | %11d | %11.2f | %9.3f | %11.3f | %11.3f\n', ...
                gen, n_pareto_history(gen), hypervolume_history(gen), ...
                min(pareto_obj(:,1)), min(pareto_obj(:,2)), min(pareto_obj(:,3)));
    end
end

elapsed_time = toc;
fprintf('\nNSGA-II completed in %.2f seconds.\n', elapsed_time);

%% Extract Final Pareto Front
final_pareto = pareto_history{end};
pareto_pop = final_pareto.population;
pareto_obj = final_pareto.objectives;

fprintf('\n=== Final Pareto Front ===\n');
fprintf('Number of Pareto-optimal solutions: %d\n\n', size(pareto_pop, 1));

% Display selected Pareto solutions
fprintf('Sample Pareto-optimal PID controllers:\n');
fprintf('%-4s | %-8s %-8s %-8s | %-10s %-12s %-10s\n', ...
        'ID', 'Kp', 'Ki', 'Kd', 'ITAE', 'Effort', 'Margins');
fprintf('---|-------------|------------------\n');

% Show extreme solutions and knee point
[~, idx_itae] = min(pareto_obj(:,1));      % Best tracking
[~, idx_effort] = min(pareto_obj(:,2));    % Least control effort
[~, idx_robust] = min(pareto_obj(:,3));    % Most robust
idx_knee = find_knee_point(pareto_obj);    % Balanced solution

indices = unique([idx_itae, idx_effort, idx_robust, idx_knee]);

for i = 1:length(indices)
    idx = indices(i);
    fprintf('%4d | %8.3f %8.3f %8.3f | %10.3f %12.3f %10.3f', ...
            idx, pareto_pop(idx,:), pareto_obj(idx,:));
    
    if idx == idx_itae
        fprintf(' <- Best tracking\n');
    elseif idx == idx_effort
        fprintf(' <- Min effort\n');
    elseif idx == idx_robust
        fprintf(' <- Most robust\n');
    elseif idx == idx_knee
        fprintf(' <- Knee point (balanced)\n');
    else
        fprintf('\n');
    end
end

%% Detailed Analysis of Selected Solutions
fprintf('\n=== Detailed Performance Analysis ===\n');

solutions_to_test = struct();
solutions_to_test(1).name = 'Best Tracking';
solutions_to_test(1).pid = pareto_pop(idx_itae, :);

solutions_to_test(2).name = 'Minimum Effort';
solutions_to_test(2).pid = pareto_pop(idx_effort, :);

solutions_to_test(3).name = 'Most Robust';
solutions_to_test(3).pid = pareto_pop(idx_robust, :);

solutions_to_test(4).name = 'Knee Point';
solutions_to_test(4).pid = pareto_pop(idx_knee, :);

% Simulate each solution
T_sim = 10;
time = 0:Ts:T_sim;
r = ones(1, length(time));

figure('Position', [100 100 1400 900]);

for i = 1:length(solutions_to_test)
    Kp = solutions_to_test(i).pid(1);
    Ki = solutions_to_test(i).pid(2);
    Kd = solutions_to_test(i).pid(3);
    
    % Simulate response
    [y, u, e] = simulate_pid_response(Gz, Kp, Ki, Kd, r, Ts);
    
    % Calculate metrics
    metrics = calculate_performance_metrics(y, u, e, r, Ts);
    
    % Stability margins
    C = pid(Kp, Ki, Kd, Ts);
    L = G * C;
    [Gm, Pm, ~, ~] = margin(L);
    
    fprintf('\n%s (Kp=%.2f, Ki=%.2f, Kd=%.2f):\n', ...
            solutions_to_test(i).name, Kp, Ki, Kd);
    fprintf('  Rise time: %.3f s\n', metrics.rise_time);
    fprintf('  Overshoot: %.2f%%\n', metrics.overshoot);
    fprintf('  Settling time: %.3f s\n', metrics.settling_time);
    fprintf('  ITAE: %.4f\n', metrics.ITAE);
    fprintf('  Control effort: %.4f\n', metrics.control_effort);
    fprintf('  Gain margin: %.2f dB\n', 20*log10(Gm));
    fprintf('  Phase margin: %.2f deg\n', Pm);
    
    % Store for plotting
    solutions_to_test(i).y = y;
    solutions_to_test(i).u = u;
    solutions_to_test(i).metrics = metrics;
    solutions_to_test(i).margins = [20*log10(Gm), Pm];
end

%% Visualization

% Plot 1: Step responses
colors = {'b', 'r', 'g', 'm'};
styles = {'-', '-', '-.', ':'};

subplot(3,2,1);
plot(time, r, 'k-', 'LineWidth', 1.5); hold on;
for i = 1:length(solutions_to_test)
    plot(time, solutions_to_test(i).y, [colors{i} styles{i}], 'LineWidth', 2);
end
grid on; ylabel('Pitch Angle (deg)');
title('Step Response Comparison');
legend(['Reference', {solutions_to_test.name}], 'Location', 'southeast');
ylim([0 1.5]);

subplot(3,2,3);
for i = 1:length(solutions_to_test)
    plot(time, solutions_to_test(i).u, [colors{i} styles{i}], 'LineWidth', 2); hold on;
end
yline(obj_params.max_control, 'k-', 'LineWidth', 1);
yline(-obj_params.max_control, 'k-', 'LineWidth', 1);
grid on; ylabel('Elevator (deg)');
title('Control Signal');
legend({solutions_to_test.name}, 'Location', 'northeast');

subplot(3,2,5);
bar_data = zeros(length(solutions_to_test), 3);
for i = 1:length(solutions_to_test)
    bar_data(i, 1) = solutions_to_test(i).metrics.ITAE;
    bar_data(i, 2) = solutions_to_test(i).metrics.control_effort / 10;  % Scale
    bar_data(i, 3) = (solutions_to_test(i).margins(1) + solutions_to_test(i).margins(2)) / 10;
end
bar(bar_data);
set(gca, 'XTickLabel', {solutions_to_test.name});
ylabel('Normalized Value');
xlabel('Controller Type');
title('Objective Comparison (normalized)');
legend('ITAE', 'Effort/10', 'Margins/10', 'Location', 'northwest');
grid on;

% Plot 2: Pareto front (3D)
subplot(3,2,[2,4]);
scatter3(pareto_obj(:,1), pareto_obj(:,2), pareto_obj(:,3), 50, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
hold on;

% Highlight special solutions
scatter3(pareto_obj(idx_itae,1), pareto_obj(idx_itae,2), pareto_obj(idx_itae,3), ...
         150, 'r', 'p', 'filled', 'LineWidth', 2);
scatter3(pareto_obj(idx_effort,1), pareto_obj(idx_effort,2), pareto_obj(idx_effort,3), ...
         150, 'g', 'd', 'filled', 'LineWidth', 2);
scatter3(pareto_obj(idx_robust,1), pareto_obj(idx_robust,2), pareto_obj(idx_robust,3), ...
         150, 'm', 's', 'filled', 'LineWidth', 2);
scatter3(pareto_obj(idx_knee,1), pareto_obj(idx_knee,2), pareto_obj(idx_knee,3), ...
         200, 'k', '^', 'filled', 'LineWidth', 2);

xlabel('f_1: ITAE');
ylabel('f_2: Control Effort');
zlabel('f_3: -Margins');
title('3D Pareto Front');
legend('Pareto Front', 'Best Tracking', 'Min Effort', 'Most Robust', 'Knee Point', ...
       'Location', 'best');
grid on; view(45, 25);

% Plot 3: Bode plots comparison
subplot(3,2,6);
hold on;
for i = 1:length(solutions_to_test)
    Kp = solutions_to_test(i).pid(1);
    Ki = solutions_to_test(i).pid(2);
    Kd = solutions_to_test(i).pid(3);
    
    C = pid(Kp, Ki, Kd, Ts);
    L = G * C;
    
    margin(L);
    set(findall(gcf, 'Type', 'Line'), 'LineWidth', 1.5);
end
legend({solutions_to_test.name}, 'Location', 'southwest');
title('Bode Plots of Loop Transfer Functions');
grid on;

sgtitle('NSGA-II Multi-Objective PID Optimization Results', ...
        'FontSize', 14, 'FontWeight', 'bold');

%% Figure 2: Evolution Analysis
figure('Position', [150 150 1200 700]);

subplot(2,3,1);
plot(1:nsga_params.n_generations, n_pareto_history, 'b-', 'LineWidth', 2);
grid on;
xlabel('Generation');
ylabel('Pareto Set Size');
title('Evolution of Pareto Front Size');

subplot(2,3,2);
plot(1:nsga_params.n_generations, hypervolume_history, 'r-', 'LineWidth', 2);
grid on;
xlabel('Generation');
ylabel('Hypervolume');
title('Hypervolume Indicator (Quality Metric)');

subplot(2,3,3);
% Extract best values per objective over generations
best_f1 = zeros(nsga_params.n_generations, 1);
best_f2 = zeros(nsga_params.n_generations, 1);
best_f3 = zeros(nsga_params.n_generations, 1);
for gen = 1:nsga_params.n_generations
    obj = pareto_history{gen}.objectives;
    best_f1(gen) = min(obj(:,1));
    best_f2(gen) = min(obj(:,2));
    best_f3(gen) = min(obj(:,3));
end
plot(1:nsga_params.n_generations, best_f1, 'r-', 'LineWidth', 2); hold on;
plot(1:nsga_params.n_generations, best_f2/10, 'g-', 'LineWidth', 2);
plot(1:nsga_params.n_generations, best_f3, 'b-', 'LineWidth', 2);
grid on;
xlabel('Generation');
ylabel('Best Objective Value');
title('Best Values per Objective');
legend('f_1 (ITAE)', 'f_2/10 (Effort)', 'f_3 (Margins)', 'Location', 'northeast');

% Pareto front projections (2D)
subplot(2,3,4);
scatter(pareto_obj(:,1), pareto_obj(:,2), 40, 'b', 'filled', 'MarkerFaceAlpha', 0.7);
hold on;
scatter(pareto_obj(idx_knee,1), pareto_obj(idx_knee,2), 100, 'r', '^', 'filled');
grid on;
xlabel('f_1: ITAE'); ylabel('f_2: Control Effort');
title('Pareto Front: f_1 vs f_2');

subplot(2,3,5);
scatter(pareto_obj(:,1), pareto_obj(:,3), 40, 'b', 'filled', 'MarkerFaceAlpha', 0.7);
hold on;
scatter(pareto_obj(idx_knee,1), pareto_obj(idx_knee,3), 100, 'r', '^', 'filled');
grid on;
xlabel('f_1: ITAE'); ylabel('f_3: -Margins');
title('Pareto Front: f_1 vs f_3');

subplot(2,3,6);
scatter(pareto_obj(:,2), pareto_obj(:,3), 40, 'b', 'filled', 'MarkerFaceAlpha', 0.7);
hold on;
scatter(pareto_obj(idx_knee,2), pareto_obj(idx_knee,3), 100, 'r', '^', 'filled');
grid on;
xlabel('f_2: Control Effort'); ylabel('f_3: -Margins');
title('Pareto Front: f_2 vs f_3');

sgtitle('NSGA-II Evolution and Pareto Front Analysis', ...
        'FontSize', 13, 'FontWeight', 'bold');

%% Figure 3: Decision Making - Trade-off Analysis
figure('Position', [200 200 1000 600]);

% Normalize objectives for comparison
norm_obj = pareto_obj;
for i = 1:size(pareto_obj, 2)
    norm_obj(:,i) = (pareto_obj(:,i) - min(pareto_obj(:,i))) / ...
                    (max(pareto_obj(:,i)) - min(pareto_obj(:,i)));
end

subplot(1,2,1);
plot(norm_obj(:,1), norm_obj(:,2), 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b'); hold on;
plot(norm_obj(idx_knee,1), norm_obj(idx_knee,2), 'r^', 'MarkerSize', 15, 'MarkerFaceColor', 'r');

% Draw diagonal (equal importance line)
plot([0 1], [0 1], 'k-', 'LineWidth', 1);

grid on;
xlabel('Normalized ITAE');
ylabel('Normalized Control Effort');
title('Trade-off: Performance vs Energy');
legend('Pareto Solutions', 'Knee Point', 'Equal Weight', 'Location', 'northwest');
axis equal; axis([0 1 0 1]);

subplot(1,2,2);
% Parallel coordinates plot
labels = {'ITAE', 'Effort', 'Margins'};
parallelcoords(norm_obj, 'Labels', labels, 'LineWidth', 1.5);
title('Parallel Coordinates of Pareto Solutions');
ylabel('Normalized Objective Value');

sgtitle('Decision Support: Trade-off Visualization', ...
        'FontSize', 13, 'FontWeight', 'bold');

fprintf('\n=== NSGA-II Optimization Complete ===\n');
fprintf('Total Pareto-optimal solutions found: %d\n', size(pareto_pop, 1));
fprintf('Recommended (Knee Point): Kp=%.2f, Ki=%.2f, Kd=%.2f\n', ...
        pareto_pop(idx_knee, :));

%% Helper Functions

function pop = initialize_population(params)
    % Initialize random population
    pop = zeros(params.pop_size, 3);
    for i = 1:params.pop_size
        pop(i,1) = params.Kp_min + rand()*(params.Kp_max - params.Kp_min);
        pop(i,2) = params.Ki_min + rand()*(params.Ki_max - params.Ki_min);
        pop(i,3) = params.Kd_min + rand()*(params.Kd_max - params.Kd_min);
    end
end

function [objectives, violated] = evaluate_multi_objectives(Kp, Ki, Kd, G, Gz, params)
    % Evaluate multiple objectives for PID controller
    
    Ts = params.Ts;
    T_sim = params.T_sim;
    time = 0:Ts:T_sim;
    r = params.setpoint * ones(1, length(time));
    
    % Simulate closed-loop
    [y, u, e] = simulate_pid_response(Gz, Kp, Ki, Kd, r, Ts);
    
    % Check for instability
    if any(isnan(y)) || any(isinf(y)) || max(abs(y)) > 1000
        objectives = [1e6, 1e6, 1e6];
        violated = true;
        return;
    end
    
    % Objective 1: ITAE (tracking performance)
    t_vec = time';
    f1 = Ts * sum(t_vec .* abs(e'));
    
    % Objective 2: Control effort
    f2 = Ts * sum(u.^2);
    
    % Objective 3: Robustness (negative of stability margins)
    try
        C = pid(Kp, Ki, Kd, Ts);
        L = G * C;
        [Gm, Pm, ~, ~] = margin(L);
        
        GM_dB = 20*log10(Gm);
        
        % We want to maximize margins, so minimize negative sum
        f3 = -(GM_dB + Pm);
    catch
        f3 = 1e6;  % Unstable or problematic
    end
    
    objectives = [f1, f2, f3];
    
    % Check constraints
    violated = false;
    
    % Overshoot constraint
    overshoot = max(0, (max(y) - r(end))/r(end) * 100);
    if overshoot > params.max_overshoot
        violated = true;
    end
    
    % Control saturation
    if any(abs(u) > params.max_control)
        violated = true;
    end
    
    % Stability margins
    if GM_dB < params.min_GM || Pm < params.min_PM
        violated = true;
    end
end

function [fronts, ranks] = fast_nondominated_sort(objectives)
    % Fast non-dominated sorting algorithm
    
    n = size(objectives, 1);
    domination_count = zeros(n, 1);
    dominated_solutions = cell(n, 1);
    
    % Calculate domination
    for i = 1:n
        for j = 1:n
            if i ~= j
                if dominates(objectives(i,:), objectives(j,:))
                    dominated_solutions{i} = [dominated_solutions{i}, j];
                elseif dominates(objectives(j,:), objectives(i,:))
                    domination_count(i) = domination_count(i) + 1;
                end
            end
        end
    end
    
    % Build fronts
    fronts = cell(0);
    ranks = zeros(n, 1);
    current_front = find(domination_count == 0);
    rank = 1;
    
    while ~isempty(current_front)
        fronts{rank} = current_front;
        ranks(current_front) = rank;
        
        next_front = [];
        for i = current_front'
            for j = dominated_solutions{i}
                domination_count(j) = domination_count(j) - 1;
                if domination_count(j) == 0
                    next_front = [next_front, j];
                end
            end
        end
        
        current_front = next_front;
        rank = rank + 1;
    end
end

function result = dominates(obj1, obj2)
    % Check if obj1 dominates obj2
    result = all(obj1 <= obj2) && any(obj1 < obj2);
end

function crowding_dist = calculate_crowding_distance(objectives, fronts)
    % Calculate crowding distance for diversity preservation
    
    n = size(objectives, 1);
    m = size(objectives, 2);
    crowding_dist = zeros(n, 1);
    
    for i = 1:length(fronts)
        front = fronts{i};
        n_front = length(front);
        
        if n_front <= 2
            crowding_dist(front) = inf;
            continue;
        end
        
        % For each objective
        for j = 1:m
            [sorted_obj, sorted_idx] = sort(objectives(front, j));
            
            % Boundary points get infinite distance
            crowding_dist(front(sorted_idx(1))) = inf;
            crowding_dist(front(sorted_idx(end))) = inf;
            
            % Normalize
            obj_range = sorted_obj(end) - sorted_obj(1);
            if obj_range == 0
                obj_range = 1;
            end
            
            % Middle points
            for k = 2:n_front-1
                idx = front(sorted_idx(k));
                crowding_dist(idx) = crowding_dist(idx) + ...
                    (sorted_obj(k+1) - sorted_obj(k-1)) / obj_range;
            end
        end
    end
end

function offspring = create_offspring(population, objectives, params)
    % Create offspring using tournament selection, SBX crossover, and polynomial mutation
    
    n_pop = size(population, 1);
    offspring = zeros(n_pop, 3);
    
    % Calculate ranks and crowding distance
    [fronts, ranks] = fast_nondominated_sort(objectives);
    crowding_dist = calculate_crowding_distance(objectives, fronts);
    
    for i = 1:2:n_pop
        % Tournament selection
        parent1 = tournament_selection(ranks, crowding_dist);
        parent2 = tournament_selection(ranks, crowding_dist);
        
        % Simulated Binary Crossover (SBX)
        if rand() < params.p_crossover
            [child1, child2] = sbx_crossover(population(parent1,:), population(parent2,:), params);
        else
            child1 = population(parent1,:);
            child2 = population(parent2,:);
        end
        
        % Polynomial mutation
        if rand() < params.p_mutation
            child1 = polynomial_mutation(child1, params);
        end
        if rand() < params.p_mutation
            child2 = polynomial_mutation(child2, params);
        end
        
        % Apply bounds
        child1 = apply_bounds(child1, params);
        child2 = apply_bounds(child2, params);
        
        offspring(i,:) = child1;
        if i+1 <= n_pop
            offspring(i+1,:) = child2;
        end
    end
end

function idx = tournament_selection(ranks, crowding_dist)
    % Binary tournament selection based on rank and crowding distance
    
    n = length(ranks);
    i1 = randi(n);
    i2 = randi(n);
    
    if ranks(i1) < ranks(i2)
        idx = i1;
    elseif ranks(i1) > ranks(i2)
        idx = i2;
    else
        % Same rank, use crowding distance
        if crowding_dist(i1) > crowding_dist(i2)
            idx = i1;
        else
            idx = i2;
        end
    end
end

function [child1, child2] = sbx_crossover(parent1, parent2, params)
    % Simulated Binary Crossover (SBX)
    
    eta_c = params.eta_c;
    child1 = zeros(size(parent1));
    child2 = zeros(size(parent2));
    
    for i = 1:length(parent1)
        if rand() <= 0.5
            if abs(parent1(i) - parent2(i)) > 1e-6
                y1 = min(parent1(i), parent2(i));
                y2 = max(parent1(i), parent2(i));
                
                u = rand();
                if u <= 0.5
                    beta = (2*u)^(1/(eta_c+1));
                else
                    beta = (1/(2*(1-u)))^(1/(eta_c+1));
                end
                
                child1(i) = 0.5*((y1 + y2) - beta*(y2 - y1));
                child2(i) = 0.5*((y1 + y2) + beta*(y2 - y1));
            else
                child1(i) = parent1(i);
                child2(i) = parent2(i);
            end
        else
            child1(i) = parent1(i);
            child2(i) = parent2(i);
        end
    end
end

function child = polynomial_mutation(individual, params)
    % Polynomial mutation
    
    eta_m = params.eta_m;
    child = individual;
    bounds = [params.Kp_min, params.Kp_max;
              params.Ki_min, params.Ki_max;
              params.Kd_min, params.Kd_max];
    
    for i = 1:length(individual)
        if rand() < 1/length(individual)
            y = individual(i);
            lb = bounds(i, 1);
            ub = bounds(i, 2);
            
            delta1 = (y - lb) / (ub - lb);
            delta2 = (ub - y) / (ub - lb);
            
            u = rand();
            if u <= 0.5
                deltaq = (2*u + (1-2*u)*(1-delta1)^(eta_m+1))^(1/(eta_m+1)) - 1;
            else
                deltaq = 1 - (2*(1-u) + 2*(u-0.5)*(1-delta2)^(eta_m+1))^(1/(eta_m+1));
            end
            
            child(i) = y + deltaq*(ub - lb);
        end
    end
end

function [next_pop, next_obj] = select_next_generation(combined_pop, combined_obj, ranks, crowding_dist, pop_size)
    % Select next generation based on rank and crowding distance
    
    [~, sorted_idx] = sortrows([ranks, -crowding_dist]);
    
    next_pop = combined_pop(sorted_idx(1:pop_size), :);
    next_obj = combined_obj(sorted_idx(1:pop_size), :);
end

function hv = calculate_hypervolume(pareto_obj, ref_point)
    % Calculate hypervolume indicator (2D/3D only)
    
    if size(pareto_obj, 2) == 2
        % Sort by first objective
        [~, sorted_idx] = sort(pareto_obj(:,1));
        sorted_obj = pareto_obj(sorted_idx, :);
        
        hv = 0;
        prev_x = 0;
        for i = 1:size(sorted_obj, 1)
            width = sorted_obj(i,1) - prev_x;
            height = ref_point(2) - sorted_obj(i,2);
            hv = hv + width * height;
            prev_x = sorted_obj(i,1);
        end
    else
        % Approximate for 3D (simplified)
        hv = 0;
        for i = 1:size(pareto_obj, 1)
            volume = prod(ref_point - pareto_obj(i,:));
            if volume > 0
                hv = hv + volume;
            end
        end
    end
end

function idx = find_knee_point(pareto_obj)
    % Find knee point (balanced solution) on Pareto front
    
    % Normalize objectives
    norm_obj = pareto_obj;
    for i = 1:size(pareto_obj, 2)
        norm_obj(:,i) = (pareto_obj(:,i) - min(pareto_obj(:,i))) / ...
                        (max(pareto_obj(:,i)) - min(pareto_obj(:,i)) + 1e-10);
    end
    
    % Find point closest to origin (equal weight)
    distances = sqrt(sum(norm_obj.^2, 2));
    [~, idx] = min(distances);
end

function [y, u, e] = simulate_pid_response(Gz, Kp, Ki, Kd, r, Ts)
    % Simulate PID response (same as Problem 11)
    
    N = length(r);
    y = zeros(1, N);
    u = zeros(1, N);
    e = zeros(1, N);
    
    integral = 0;
    prev_error = 0;
    prev_derivative = 0;
    
    N_filter = 10;
    tau_d = Kd / N_filter;
    
    x = zeros(size(Gz.A, 1), 1);
    
    for k = 1:N
        y(k) = Gz.C * x;
        e(k) = r(k) - y(k);
        
        proportional = Kp * e(k);
        integral = integral + Ki * Ts * e(k);
        integral = max(-100, min(100, integral));
        
        derivative = (tau_d / (tau_d + N_filter * Ts)) * prev_derivative + ...
                     (Kd * N_filter / (tau_d + N_filter * Ts)) * (e(k) - prev_error);
        
        u(k) = proportional + integral + derivative;
        u(k) = max(-100, min(100, u(k)));
        
        if k < N
            x = Gz.A * x + Gz.B * u(k);
        end
        
        prev_error = e(k);
        prev_derivative = derivative;
    end
end

function metrics = calculate_performance_metrics(y, u, e, r, Ts)
    % Calculate performance metrics (same as Problem 11)
    
    time = (0:length(y)-1) * Ts;
    final_value = y(end);
    
    % Rise time
    idx_10 = find(y >= 0.1*final_value, 1, 'first');
    idx_90 = find(y >= 0.9*final_value, 1, 'first');
    if ~isempty(idx_10) && ~isempty(idx_90)
        metrics.rise_time = time(idx_90) - time(idx_10);
    else
        metrics.rise_time = NaN;
    end
    
    % Overshoot
    metrics.overshoot = max(0, (max(y) - final_value) / final_value * 100);
    
    % Settling time
    settling_band = 0.02 * abs(final_value);
    settled = abs(y - final_value) <= settling_band;
    settling_idx = find(settled, 1, 'first');
    if ~isempty(settling_idx)
        metrics.settling_time = time(settling_idx);
    else
        metrics.settling_time = time(end);
    end
    
    % Performance indices
    metrics.ITAE = Ts * sum(time' .* abs(e'));
    metrics.control_effort = Ts * sum(u.^2);
end

function individual = apply_bounds(individual, params)
    % Apply bounds
    individual(1) = max(params.Kp_min, min(params.Kp_max, individual(1)));
    individual(2) = max(params.Ki_min, min(params.Ki_max, individual(2)));
    individual(3) = max(params.Kd_min, min(params.Kd_max, individual(3)));
end
