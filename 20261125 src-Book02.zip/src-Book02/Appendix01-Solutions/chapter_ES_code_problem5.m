%% chapter_ES_code_problem5.m
% Finite Element Analysis with Adaptive Mesh Refinement
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem5
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem5
    % MATLABBook_ChapterES_Problem5.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   2D Poisson equation solver using finite element method with
    %   adaptive mesh refinement. Implements residual-based error
    %   estimation and red refinement strategy for triangular elements.
    %
    % Dependencies: Partial Differential Equation Toolbox (optional)
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 5
    
    fprintf('\n=== Problem 5: Finite Element Analysis with AMR ===\n\n');
    
    %% Problem Definition
    
    % Domain: Unit square [0,1] x [0,1]
    domain_x = [0, 1];
    domain_y = [0, 1];
    
    % Manufactured solution for verification
    u_exact = @(x, y) sin(pi*x) .* sin(pi*y);
    f_source = @(x, y) 2*pi^2 * sin(pi*x) .* sin(pi*y);  % -Laplacian(u_exact)
    
    % Boundary condition (Dirichlet, u=0 on boundary)
    g_bc = @(x, y) 0 * x;
    
    fprintf('Problem: -Laplacian(u) = f in Omega = [0,1]^2\n');
    fprintf('Manufactured solution: u(x,y) = sin(pi*x)*sin(pi*y)\n');
    fprintf('Source term: f(x,y) = 2*pi^2*sin(pi*x)*sin(pi*y)\n');
    fprintf('Boundary: u = 0 on boundary\n\n');
    
    %% AMR Parameters
    
    max_refinements = 8;
    error_tolerance = 1e-4;
    marking_fraction = 0.3;  % Refine top 30% of elements by error
    
    fprintf('AMR parameters:\n');
    fprintf('  Max refinements: %d\n', max_refinements);
    fprintf('  Error tolerance: %.1e\n', error_tolerance);
    fprintf('  Marking fraction: %.1f%%\n\n', marking_fraction*100);
    
    %% Initial Mesh
    
    % Coarse triangular mesh (2x2 grid -> 8 triangles)
    nx_init = 3;
    ny_init = 3;
    
    [nodes, elements] = generateRectangularMesh(domain_x, domain_y, nx_init, ny_init);
    
    fprintf('=== Refinement Level 0 (Initial) ===\n');
    fprintf('Nodes: %d, Elements: %d\n', size(nodes,1), size(elements,1));
    
    %% AMR Loop
    
    refinement_data = struct('level', {}, 'n_nodes', {}, 'n_elements', {}, ...
                             'error_L2', {}, 'error_H1', {}, 'eta_estimate', {});
    
    for level = 0:max_refinements
        
        % Assemble and solve FEM system
        [K_global, f_global] = assembleFEM(nodes, elements, f_source);
        
        % Apply boundary conditions
        boundary_nodes = findBoundaryNodes(nodes, domain_x, domain_y);
        [K_global, f_global] = applyDirichletBC(K_global, f_global, boundary_nodes, nodes, g_bc);
        
        % Solve linear system
        u_h = K_global \ f_global;
        
        % Compute exact solution at nodes
        u_ex = u_exact(nodes(:,1), nodes(:,2));
        
        % Error norms
        [error_L2, error_H1] = computeErrorNorms(nodes, elements, u_h, u_exact);
        
        % A posteriori error estimator
        eta_elements = computeErrorEstimator(nodes, elements, u_h, f_source);
        eta_global = sqrt(sum(eta_elements.^2));
        
        % Store results
        refinement_data(level+1).level = level;
        refinement_data(level+1).n_nodes = size(nodes, 1);
        refinement_data(level+1).n_elements = size(elements, 1);
        refinement_data(level+1).error_L2 = error_L2;
        refinement_data(level+1).error_H1 = error_H1;
        refinement_data(level+1).eta_estimate = eta_global;
        
        fprintf('\n=== Refinement Level %d ===\n', level);
        fprintf('Nodes: %d, Elements: %d\n', size(nodes,1), size(elements,1));
        fprintf('L2 error:       %.6e\n', error_L2);
        fprintf('H1 seminorm error: %.6e\n', error_H1);
        fprintf('Estimated error:   %.6e\n', eta_global);
        fprintf('Effectivity index: %.3f\n', eta_global / error_H1);
        
        % Check convergence
        if eta_global < error_tolerance
            fprintf('\n*** Converged! Error below tolerance. ***\n');
            break;
        end
        
        if level == max_refinements
            fprintf('\n*** Maximum refinement level reached. ***\n');
            break;
        end
        
        % Mark elements for refinement (Drfler marking / bulk criterion)
        elements_to_refine = markElements(eta_elements, marking_fraction);
        
        fprintf('Marked %d elements (%.1f%%) for refinement\n', ...
                length(elements_to_refine), length(elements_to_refine)/size(elements,1)*100);
        
        % Refine mesh (red refinement)
        [nodes, elements] = refineMesh(nodes, elements, elements_to_refine);
    end
    
    %% Uniform Refinement Comparison
    
    fprintf('\n=== Uniform Refinement Comparison ===\n');
    
    uniform_levels = 0:min(5, max_refinements);
    uniform_data = struct('level', {}, 'n_nodes', {}, 'n_elements', {}, ...
                          'error_L2', {}, 'error_H1', {});
    
    for ulevel = uniform_levels
        % Generate uniform mesh
        nx_u = nx_init + ulevel * 2;
        ny_u = ny_init + ulevel * 2;
        [nodes_u, elements_u] = generateRectangularMesh(domain_x, domain_y, nx_u, ny_u);
        
        % Solve
        [K_u, f_u] = assembleFEM(nodes_u, elements_u, f_source);
        boundary_nodes_u = findBoundaryNodes(nodes_u, domain_x, domain_y);
        [K_u, f_u] = applyDirichletBC(K_u, f_u, boundary_nodes_u, nodes_u, g_bc);
        u_h_u = K_u \ f_u;
        
        % Errors
        [error_L2_u, error_H1_u] = computeErrorNorms(nodes_u, elements_u, u_h_u, u_exact);
        
        uniform_data(ulevel+1).level = ulevel;
        uniform_data(ulevel+1).n_nodes = size(nodes_u, 1);
        uniform_data(ulevel+1).n_elements = size(elements_u, 1);
        uniform_data(ulevel+1).error_L2 = error_L2_u;
        uniform_data(ulevel+1).error_H1 = error_H1_u;
        
        fprintf('Level %d: N=%5d, L2=%.2e, H1=%.2e\n', ulevel, ...
                size(nodes_u,1), error_L2_u, error_H1_u);
    end
    
    %% Convergence Rate Analysis
    
    fprintf('\n=== Convergence Rate Analysis ===\n');
    
    % AMR convergence
    N_amr = [refinement_data.n_nodes];
    h_amr = 1 ./ sqrt(N_amr);  % Characteristic mesh size
    err_H1_amr = [refinement_data.error_H1];
    
    % Fit: log(error) = alpha * log(h) + const
    p_amr = polyfit(log(h_amr), log(err_H1_amr), 1);
    rate_amr = p_amr(1);
    
    fprintf('AMR H1-error convergence rate: %.3f (theory: 1.0 for linear elements)\n', rate_amr);
    
    % Uniform convergence
    N_uniform = [uniform_data.n_nodes];
    h_uniform = 1 ./ sqrt(N_uniform);
    err_H1_uniform = [uniform_data.error_H1];
    
    p_uniform = polyfit(log(h_uniform), log(err_H1_uniform), 1);
    rate_uniform = p_uniform(1);
    
    fprintf('Uniform H1-error convergence rate: %.3f\n', rate_uniform);
    
    % Efficiency: error vs DOF
    for i = 2:length(refinement_data)
        dof_ratio = refinement_data(i).n_nodes / refinement_data(i-1).n_nodes;
        error_ratio = refinement_data(i).error_H1 / refinement_data(i-1).error_H1;
        efficiency = log(error_ratio) / log(dof_ratio);
        fprintf('Level %d %d: DOF %.2f, Error %.3f, Efficiency=%.3f\n', ...
                i-1, i, dof_ratio, error_ratio, efficiency);
    end
    
    %% Visualization
    
    figure('Position', [100 100 1400 900]);
    
    % Subplot 1: Initial mesh
    subplot(2, 4, 1);
    [nodes_0, elements_0] = generateRectangularMesh(domain_x, domain_y, nx_init, ny_init);
    triplot(elements_0, nodes_0(:,1), nodes_0(:,2), 'k-', 'LineWidth', 1);
    axis equal tight;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    title('Initial Mesh (Level 0)', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 2: Final adapted mesh
    subplot(2, 4, 2);
    triplot(elements, nodes(:,1), nodes(:,2), 'b-', 'LineWidth', 0.5);
    axis equal tight;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    title(sprintf('Adapted Mesh (Level %d)', level), 'Interpreter', 'latex');
    grid on;
    
    % Subplot 3: FEM solution
    subplot(2, 4, 3);
    trisurf(elements, nodes(:,1), nodes(:,2), u_h);
    shading interp;
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$u_h(x,y)$', 'Interpreter', 'latex');
    title('FEM Solution', 'Interpreter', 'latex');
    view(45, 30);
    
    % Subplot 4: Exact solution
    subplot(2, 4, 4);
    u_ex_plot = u_exact(nodes(:,1), nodes(:,2));
    trisurf(elements, nodes(:,1), nodes(:,2), u_ex_plot);
    shading interp;
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$u_{exact}(x,y)$', 'Interpreter', 'latex');
    title('Exact Solution', 'Interpreter', 'latex');
    view(45, 30);
    
    % Subplot 5: Error distribution
    subplot(2, 4, 5);
    error_nodal = abs(u_h - u_ex_plot);
    trisurf(elements, nodes(:,1), nodes(:,2), error_nodal);
    shading interp;
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$|u_h - u|$', 'Interpreter', 'latex');
    title('Pointwise Error', 'Interpreter', 'latex');
    view(45, 30);
    
    % Subplot 6: Element error indicators
    subplot(2, 4, 6);
    trisurf(elements, nodes(:,1), nodes(:,2), zeros(size(nodes,1),1), ...
            'FaceVertexCData', eta_elements, 'FaceColor', 'flat');
    colorbar;
    view(2);
    shading flat;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    title('Error Estimator $\eta_e$', 'Interpreter', 'latex');
    
    % Subplot 7: Convergence comparison
    subplot(2, 4, 7);
    loglog([refinement_data.n_nodes], [refinement_data.error_H1], ...
           'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', 'AMR');
    hold on;
    loglog([uniform_data.n_nodes], [uniform_data.error_H1], ...
           's-', 'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', 'Uniform');
    
    % Reference slope
    N_ref = [refinement_data(1).n_nodes, refinement_data(end).n_nodes];
    err_ref = refinement_data(1).error_H1 * (N_ref / refinement_data(1).n_nodes).^(-0.5);
    loglog(N_ref, err_ref, 'k-', 'LineWidth', 1, 'DisplayName', '$N^{-1/2}$');
    hold off;
    
    xlabel('Number of Nodes $N$', 'Interpreter', 'latex');
    ylabel('$H^1$ Seminorm Error', 'Interpreter', 'latex');
    title('Convergence Comparison', 'Interpreter', 'latex');
    legend('Location', 'southwest', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 8: Effectivity index
    subplot(2, 4, 8);
    effectivity = [refinement_data.eta_estimate] ./ [refinement_data.error_H1];
    plot(0:level, effectivity, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6);
    yline(1, 'k-', 'LineWidth', 1);
    xlabel('Refinement Level', 'Interpreter', 'latex');
    ylabel('Effectivity Index $\eta/\|e\|_{H^1}$', 'Interpreter', 'latex');
    title('Error Estimator Quality', 'Interpreter', 'latex');
    grid on;
    ylim([0 2]);
    
    sgtitle('Adaptive Finite Element Analysis', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('\nSimulation completed. Figures generated.\n\n');
end

%% Helper Functions

function [nodes, elements] = generateRectangularMesh(domain_x, domain_y, nx, ny)
    % Generate structured triangular mesh on rectangular domain
    
    x = linspace(domain_x(1), domain_x(2), nx);
    y = linspace(domain_y(1), domain_y(2), ny);
    
    [X, Y] = meshgrid(x, y);
    nodes = [X(:), Y(:)];
    
    % Connectivity (each rectangle -> 2 triangles)
    elements = [];
    for j = 1:ny-1
        for i = 1:nx-1
            n1 = (j-1)*nx + i;
            n2 = n1 + 1;
            n3 = j*nx + i;
            n4 = n3 + 1;
            
            % Triangle 1: n1-n2-n4
            elements = [elements; n1, n2, n4];
            % Triangle 2: n1-n4-n3
            elements = [elements; n1, n4, n3];
        end
    end
end

function [K, f] = assembleFEM(nodes, elements, f_source)
    % Assemble global stiffness matrix and load vector
    
    n_nodes = size(nodes, 1);
    n_elements = size(elements, 1);
    
    % Initialize sparse matrix
    K = sparse(n_nodes, n_nodes);
    f = zeros(n_nodes, 1);
    
    % Gauss quadrature points for triangles (3-point rule)
    gauss_points = [1/6, 1/6; 2/3, 1/6; 1/6, 2/3];
    gauss_weights = [1/6, 1/6, 1/6];
    
    for e = 1:n_elements
        % Element nodes
        elem_nodes = elements(e, :);
        coords = nodes(elem_nodes, :);
        
        % Element stiffness and load
        [K_e, f_e] = elementMatrices(coords, f_source, gauss_points, gauss_weights);
        
        % Assembly
        K(elem_nodes, elem_nodes) = K(elem_nodes, elem_nodes) + K_e;
        f(elem_nodes) = f(elem_nodes) + f_e;
    end
end

function [K_e, f_e] = elementMatrices(coords, f_source, gp, gw)
    % Compute element stiffness matrix and load vector
    
    % Linear basis functions on reference triangle
    % phi_1(xi,eta) = 1 - xi - eta
    % phi_2(xi,eta) = xi
    % phi_3(xi,eta) = eta
    
    x = coords(:, 1);
    y = coords(:, 2);
    
    % Jacobian of mapping (constant for linear triangles)
    J = [x(2)-x(1), x(3)-x(1); y(2)-y(1), y(3)-y(1)];
    detJ = abs(det(J));
    invJ = inv(J);
    
    % Gradient of basis functions in reference coordinates
    grad_phi_ref = [-1, 1, 0; -1, 0, 1];
    
    % Transform to physical coordinates
    grad_phi = invJ * grad_phi_ref;
    
    % Stiffness matrix (exact integration for linear elements)
    K_e = detJ * (grad_phi' * grad_phi) / 2;
    
    % Load vector (numerical integration)
    f_e = zeros(3, 1);
    for q = 1:length(gw)
        xi = gp(q, 1);
        eta = gp(q, 2);
        
        % Basis functions at quadrature point
        phi = [1 - xi - eta; xi; eta];
        
        % Physical coordinates
        x_q = coords(:, 1)' * phi;
        y_q = coords(:, 2)' * phi;
        
        % Source term at quadrature point
        f_q = f_source(x_q, y_q);
        
        f_e = f_e + gw(q) * detJ * f_q * phi;
    end
end

function boundary_nodes = findBoundaryNodes(nodes, domain_x, domain_y)
    % Find nodes on domain boundary
    
    tol = 1e-10;
    
    on_left = abs(nodes(:,1) - domain_x(1)) < tol;
    on_right = abs(nodes(:,1) - domain_x(2)) < tol;
    on_bottom = abs(nodes(:,2) - domain_y(1)) < tol;
    on_top = abs(nodes(:,2) - domain_y(2)) < tol;
    
    boundary_nodes = find(on_left | on_right | on_bottom | on_top);
end

function [K, f] = applyDirichletBC(K, f, bc_nodes, nodes, g_bc)
    % Apply Dirichlet boundary conditions
    
    for i = 1:length(bc_nodes)
        node = bc_nodes(i);
        x = nodes(node, 1);
        y = nodes(node, 2);
        g_val = g_bc(x, y);
        
        % Elimination method
        f = f - K(:, node) * g_val;
        K(node, :) = 0;
        K(:, node) = 0;
        K(node, node) = 1;
        f(node) = g_val;
    end
end

function [error_L2, error_H1] = computeErrorNorms(nodes, elements, u_h, u_exact)
    % Compute L2 and H1 seminorm errors
    
    error_L2_sq = 0;
    error_H1_sq = 0;
    
    % Gauss quadrature
    gp = [1/6, 1/6; 2/3, 1/6; 1/6, 2/3];
    gw = [1/6, 1/6, 1/6];
    
    for e = 1:size(elements, 1)
        elem_nodes = elements(e, :);
        coords = nodes(elem_nodes, :);
        u_e = u_h(elem_nodes);
        
        x = coords(:, 1);
        y = coords(:, 2);
        
        J = [x(2)-x(1), x(3)-x(1); y(2)-y(1), y(3)-y(1)];
        detJ = abs(det(J));
        invJ = inv(J);
        
        for q = 1:length(gw)
            xi = gp(q, 1);
            eta = gp(q, 2);
            
            phi = [1-xi-eta; xi; eta];
            grad_phi_ref = [-1, 1, 0; -1, 0, 1];
            grad_phi = invJ * grad_phi_ref;
            
            % Physical coordinates
            x_q = coords(:,1)' * phi;
            y_q = coords(:,2)' * phi;
            
            % FEM solution and gradient
            u_h_q = u_e' * phi;
            grad_u_h_q = grad_phi * u_e;
            
            % Exact solution and gradient
            u_ex_q = u_exact(x_q, y_q);
            grad_u_ex_q = [pi*cos(pi*x_q)*sin(pi*y_q); pi*sin(pi*x_q)*cos(pi*y_q)];
            
            % L2 error
            error_L2_sq = error_L2_sq + gw(q) * detJ * (u_h_q - u_ex_q)^2;
            
            % H1 seminorm error
            error_H1_sq = error_H1_sq + gw(q) * detJ * ...
                          norm(grad_u_h_q - grad_u_ex_q)^2;
        end
    end
    
    error_L2 = sqrt(error_L2_sq);
    error_H1 = sqrt(error_H1_sq);
end

function eta_elements = computeErrorEstimator(nodes, elements, u_h, f_source)
    % Residual-based a posteriori error estimator
    
    n_elements = size(elements, 1);
    eta_elements = zeros(n_elements, 1);
    
    for e = 1:n_elements
        elem_nodes = elements(e, :);
        coords = nodes(elem_nodes, :);
        u_e = u_h(elem_nodes);
        
        % Element size
        h_e = max(pdist(coords));
        
        % Element residual (interior residual: f + Laplacian(u_h))
        % For linear elements, Laplacian(u_h) = 0 in element interior
        
        % Centroid
        x_c = mean(coords(:,1));
        y_c = mean(coords(:,2));
        f_c = f_source(x_c, y_c);
        
        % Simplified estimator (for demonstration)
        eta_elements(e) = h_e * abs(f_c);
        
        % Add jump term (approximate)
        x = coords(:,1);
        y = coords(:,2);
        J = [x(2)-x(1), x(3)-x(1); y(2)-y(1), y(3)-y(1)];
        invJ = inv(J);
        grad_phi_ref = [-1, 1, 0; -1, 0, 1];
        grad_phi = invJ * grad_phi_ref;
        grad_u_h = grad_phi * u_e;
        
        eta_elements(e) = eta_elements(e) + sqrt(h_e) * norm(grad_u_h);
    end
end

function marked = markElements(eta_elements, theta)
    % Drfler marking strategy (bulk criterion)
    
    [eta_sorted, idx_sorted] = sort(eta_elements, 'descend');
    eta_total = sum(eta_elements.^2);
    
    cumsum_eta = cumsum(eta_sorted.^2);
    n_mark = find(cumsum_eta >= theta * eta_total, 1, 'first');
    
    marked = idx_sorted(1:n_mark);
end

function [nodes_new, elements_new] = refineMesh(nodes, elements, marked_elements)
    % Red refinement: subdivide each marked triangle into 4 triangles
    
    nodes_new = nodes;
    elements_new = [];
    
    % Edge midpoints storage
    edge_midpoints = containers.Map('KeyType', 'char', 'ValueType', 'double');
    
    for e = 1:size(elements, 1)
        elem = elements(e, :);
        
        if ismember(e, marked_elements)
            % Refine this element
            n1 = elem(1); n2 = elem(2); n3 = elem(3);
            
            % Get or create edge midpoints
            m12 = getEdgeMidpoint(n1, n2, nodes_new, edge_midpoints);
            m23 = getEdgeMidpoint(n2, n3, nodes_new, edge_midpoints);
            m31 = getEdgeMidpoint(n3, n1, nodes_new, edge_midpoints);
            
            % Create 4 new triangles
            elements_new = [elements_new; n1, m12, m31];
            elements_new = [elements_new; m12, n2, m23];
            elements_new = [elements_new; m31, m23, n3];
            elements_new = [elements_new; m12, m23, m31];
        else
            % Keep element unchanged
            elements_new = [elements_new; elem];
        end
    end
    
    function mid_idx = getEdgeMidpoint(n1, n2, nodes, midpoint_map)
        % Get or create edge midpoint
        
        % Canonical edge key
        key = sprintf('%d_%d', min(n1,n2), max(n1,n2));
        
        if isKey(midpoint_map, key)
            mid_idx = midpoint_map(key);
        else
            % Create new midpoint
            mid_coords = (nodes(n1,:) + nodes(n2,:)) / 2;
            nodes = [nodes; mid_coords];
            mid_idx = size(nodes, 1);
            midpoint_map(key) = mid_idx;
        end
    end
end
