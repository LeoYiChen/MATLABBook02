%% Appendix01-Solutions_code_247.m
% Fuzzy Logic Controller for Magnetic Levitation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Fuzzy Logic Controller Design
% Problem 14: Fuzzy Logic Controller for Magnetic Levitation System
% Author: Control Systems Course
% Description: Complete FLC implementation with Mamdani and TS fuzzy systems

clear all; close all; clc;

%% System Definition: Magnetic Levitation
fprintf('=== Fuzzy Logic Controller Design ===\n');
fprintf('Application: Magnetic Levitation System\n\n');

% System parameters
params = struct();
params.m = 0.05;              % Ball mass (kg)
params.g = 9.81;              % Gravity (m/s^2)
params.k = 1e-5;              % Electromagnetic constant (N*m^2/A^2)
params.x0 = 0.01;             % Desired gap (m) - 1 cm
params.i_max = 5;             % Maximum current (A)
params.i_min = 0;             % Minimum current (A)
params.x_max = 0.02;          % Maximum safe gap (m)
params.x_min = 0.005;         % Minimum safe gap (m)

% Equilibrium current
params.i0 = params.x0 * sqrt(params.m * params.g / params.k);

fprintf('System Parameters:\n');
fprintf('  Ball mass: %.3f kg\n', params.m);
fprintf('  Electromagnetic constant: %.2e N*m^2/A^2\n', params.k);
fprintf('  Desired gap: %.3f m (%.1f cm)\n', params.x0, params.x0*100);
fprintf('  Equilibrium current: %.3f A\n', params.i0);
fprintf('  Current range: [%.1f, %.1f] A\n', params.i_min, params.i_max);
fprintf('  Position range: [%.3f, %.3f] m\n\n', params.x_min, params.x_max);

% Linearized model (for comparison)
A_lin = -2*params.m*params.g / params.x0;
B_lin = 2*params.m*params.g / params.i0;

fprintf('Linearized Dynamics (around equilibrium):\n');
fprintf('  dx/dt = %.1f* x + %.1f* i\n', A_lin, B_lin);
fprintf('  Open-loop pole: s = %.2f rad/s (UNSTABLE)\n\n', sqrt(-A_lin));

% Simulation parameters
Ts = 0.001;                   % 1ms sampling (fast for unstable system)
T_sim = 5;                    % 5 second simulation
time = 0:Ts:T_sim;
N = length(time);

%% Design Fuzzy Logic Controller

fprintf('=== Designing Fuzzy Logic Controller ===\n\n');

% Create fuzzy inference system (Mamdani type)
fis_mamdani = mamfis('Name', 'MagLev_FLC');

% Input 1: Position Error (e = x_ref - x)
fis_mamdani = addInput(fis_mamdani, [-0.01 0.01], 'Name', 'error');

% Define membership functions for error
fis_mamdani = addMF(fis_mamdani, 'error', 'trapmf', [-0.01 -0.01 -0.008 -0.004], 'Name', 'NB');
fis_mamdani = addMF(fis_mamdani, 'error', 'trimf', [-0.008 -0.004 -0.001], 'Name', 'NM');
fis_mamdani = addMF(fis_mamdani, 'error', 'trimf', [-0.004 -0.001 0], 'Name', 'NS');
fis_mamdani = addMF(fis_mamdani, 'error', 'trimf', [-0.001 0 0.001], 'Name', 'ZE');
fis_mamdani = addMF(fis_mamdani, 'error', 'trimf', [0 0.001 0.004], 'Name', 'PS');
fis_mamdani = addMF(fis_mamdani, 'error', 'trimf', [0.001 0.004 0.008], 'Name', 'PM');
fis_mamdani = addMF(fis_mamdani, 'error', 'trapmf', [0.004 0.008 0.01 0.01], 'Name', 'PB');

% Input 2: Change in Error ( e   velocity error)
fis_mamdani = addInput(fis_mamdani, [-0.5 0.5], 'Name', 'delta_error');

fis_mamdani = addMF(fis_mamdani, 'delta_error', 'trapmf', [-0.5 -0.5 -0.3 -0.15], 'Name', 'NB');
fis_mamdani = addMF(fis_mamdani, 'delta_error', 'trimf', [-0.3 -0.15 -0.05], 'Name', 'NM');
fis_mamdani = addMF(fis_mamdani, 'delta_error', 'trimf', [-0.15 -0.05 0], 'Name', 'NS');
fis_mamdani = addMF(fis_mamdani, 'delta_error', 'trimf', [-0.05 0 0.05], 'Name', 'ZE');
fis_mamdani = addMF(fis_mamdani, 'delta_error', 'trimf', [0 0.05 0.15], 'Name', 'PS');
fis_mamdani = addMF(fis_mamdani, 'delta_error', 'trimf', [0.05 0.15 0.3], 'Name', 'PM');
fis_mamdani = addMF(fis_mamdani, 'delta_error', 'trapmf', [0.15 0.3 0.5 0.5], 'Name', 'PB');

% Output: Change in Current ( i)
fis_mamdani = addOutput(fis_mamdani, [-3 3], 'Name', 'delta_current');

fis_mamdani = addMF(fis_mamdani, 'delta_current', 'trapmf', [-3 -3 -2 -1], 'Name', 'NB');
fis_mamdani = addMF(fis_mamdani, 'delta_current', 'trimf', [-2 -1 -0.3], 'Name', 'NM');
fis_mamdani = addMF(fis_mamdani, 'delta_current', 'trimf', [-1 -0.3 0], 'Name', 'NS');
fis_mamdani = addMF(fis_mamdani, 'delta_current', 'trimf', [-0.3 0 0.3], 'Name', 'ZE');
fis_mamdani = addMF(fis_mamdani, 'delta_current', 'trimf', [0 0.3 1], 'Name', 'PS');
fis_mamdani = addMF(fis_mamdani, 'delta_current', 'trimf', [0.3 1 2], 'Name', 'PM');
fis_mamdani = addMF(fis_mamdani, 'delta_current', 'trapmf', [1 2 3 3], 'Name', 'PB');

fprintf('Fuzzy Inference System Structure:\n');
fprintf('  Type: Mamdani\n');
fprintf('  Inputs: 2 (error, delta_error)\n');
fprintf('  Output: 1 (delta_current)\n');
fprintf('  Membership functions per variable: 7\n');
fprintf('  Total possible rules: 7 7 = 49\n\n');

% Define fuzzy rules (49 rules for complete coverage)
% Rule table structure (simplified notation)
rule_table = {
    % e\ e   NB    NM    NS    ZE    PS    PM    PB
    'NB', {'NB', 'NB', 'NB', 'NB', 'NM', 'NS', 'ZE'};
    'NM', {'NB', 'NB', 'NM', 'NM', 'NS', 'ZE', 'PS'};
    'NS', {'NB', 'NM', 'NS', 'NS', 'ZE', 'PS', 'PM'};
    'ZE', {'NB', 'NM', 'NS', 'ZE', 'PS', 'PM', 'PB'};
    'PS', {'NM', 'NS', 'ZE', 'PS', 'PS', 'PM', 'PB'};
    'PM', {'NS', 'ZE', 'PS', 'PM', 'PM', 'PB', 'PB'};
    'PB', {'ZE', 'PS', 'PM', 'PB', 'PB', 'PB', 'PB'};
};

fprintf('Constructing fuzzy rule base...\n');

rule_list = [];
rule_count = 0;

for i = 1:7
    e_label = rule_table{i, 1};
    for j = 1:7
        de_labels = {'NB', 'NM', 'NS', 'ZE', 'PS', 'PM', 'PB'};
        de_label = de_labels{j};
        output_label = rule_table{i, 2}{j};
        
        % Convert labels to indices
        e_idx = i;
        de_idx = j;
        
        label_to_idx = containers.Map({'NB','NM','NS','ZE','PS','PM','PB'}, 1:7);
        out_idx = label_to_idx(output_label);
        
        % Create rule: [input1_mf, input2_mf, output_mf, weight, operator]
        rule_list = [rule_list; e_idx de_idx out_idx 1 1];
        rule_count = rule_count + 1;
    end
end

fis_mamdani = addRule(fis_mamdani, rule_list);

fprintf('  Added %d rules\n', rule_count);
fprintf('  AND operator: min\n');
fprintf('  OR operator: max\n');
fprintf('  Implication: min\n');
fprintf('  Aggregation: max\n');
fprintf('  Defuzzification: centroid\n\n');

% Create Takagi-Sugeno FIS for comparison
fis_ts = sugfis('Name', 'MagLev_TS');

% Same inputs as Mamdani
fis_ts = addInput(fis_ts, [-0.01 0.01], 'Name', 'error');
fis_ts = addMF(fis_ts, 'error', 'gaussmf', [0.002 -0.007], 'Name', 'NB');
fis_ts = addMF(fis_ts, 'error', 'gaussmf', [0.002 -0.004], 'Name', 'NM');
fis_ts = addMF(fis_ts, 'error', 'gaussmf', [0.002 -0.001], 'Name', 'NS');
fis_ts = addMF(fis_ts, 'error', 'gaussmf', [0.002 0], 'Name', 'ZE');
fis_ts = addMF(fis_ts, 'error', 'gaussmf', [0.002 0.001], 'Name', 'PS');
fis_ts = addMF(fis_ts, 'error', 'gaussmf', [0.002 0.004], 'Name', 'PM');
fis_ts = addMF(fis_ts, 'error', 'gaussmf', [0.002 0.007], 'Name', 'PB');

fis_ts = addInput(fis_ts, [-0.5 0.5], 'Name', 'delta_error');
fis_ts = addMF(fis_ts, 'delta_error', 'gaussmf', [0.1 -0.35], 'Name', 'NB');
fis_ts = addMF(fis_ts, 'delta_error', 'gaussmf', [0.1 -0.2], 'Name', 'NM');
fis_ts = addMF(fis_ts, 'delta_error', 'gaussmf', [0.1 -0.1], 'Name', 'NS');
fis_ts = addMF(fis_ts, 'delta_error', 'gaussmf', [0.1 0], 'Name', 'ZE');
fis_ts = addMF(fis_ts, 'delta_error', 'gaussmf', [0.1 0.1], 'Name', 'PS');
fis_ts = addMF(fis_ts, 'delta_error', 'gaussmf', [0.1 0.2], 'Name', 'PM');
fis_ts = addMF(fis_ts, 'delta_error', 'gaussmf', [0.1 0.35], 'Name', 'PB');

% TS output: constant values
fis_ts = addOutput(fis_ts, [-3 3], 'Name', 'delta_current');
output_values = [-2.5, -1.5, -0.5, 0, 0.5, 1.5, 2.5];
for i = 1:7
    fis_ts = addMF(fis_ts, 'delta_current', 'constant', output_values(i), ...
                   'Name', char('A' + i - 1));
end

% Add same rules to TS system
fis_ts = addRule(fis_ts, rule_list);

fprintf('Created Takagi-Sugeno FIS for comparison\n');
fprintf('  Gaussian membership functions\n');
fprintf('  Constant consequents\n');
fprintf('  Defuzzification: weighted average\n\n');

%% Visualization of Fuzzy Sets and Control Surface

figure('Position', [50 50 1400 1000]);

% Plot 1: Error membership functions
subplot(3,3,1);
x_e = linspace(-0.01, 0.01, 200);
hold on;
colors = lines(7);
for i = 1:7
    mf_values = evalmf(fis_mamdani, x_e, i, 1);
    plot(x_e*1000, mf_values, 'Color', colors(i,:), 'LineWidth', 2);
end
grid on;
xlabel('Error (mm)');
ylabel('Membership Degree');
title('Error Membership Functions');
legend({'NB','NM','NS','ZE','PS','PM','PB'}, 'Location', 'eastoutside');
ylim([0 1.1]);

% Plot 2: Delta error membership functions
subplot(3,3,2);
x_de = linspace(-0.5, 0.5, 200);
hold on;
for i = 1:7
    mf_values = evalmf(fis_mamdani, x_de, i, 2);
    plot(x_de, mf_values, 'Color', colors(i,:), 'LineWidth', 2);
end
grid on;
xlabel('  Error (m/s)');
ylabel('Membership Degree');
title('  Error Membership Functions');
ylim([0 1.1]);

% Plot 3: Output membership functions
subplot(3,3,3);
x_out = linspace(-3, 3, 200);
hold on;
for i = 1:7
    mf_values = evalmf(fis_mamdani, x_out, i, 3);
    plot(x_out, mf_values, 'Color', colors(i,:), 'LineWidth', 2);
end
grid on;
xlabel('  Current (A/s)');
ylabel('Membership Degree');
title('Output Membership Functions');
ylim([0 1.1]);

% Plot 4: Mamdani control surface
subplot(3,3,[4 5 7 8]);
[X, Y] = meshgrid(linspace(-0.01, 0.01, 50), linspace(-0.5, 0.5, 50));
Z = zeros(size(X));
for i = 1:size(X,1)
    for j = 1:size(X,2)
        Z(i,j) = evalfis(fis_mamdani, [X(i,j), Y(i,j)]);
    end
end
surf(X*1000, Y, Z);
shading interp;
colorbar;
xlabel('Error (mm)');
ylabel('  Error (m/s)');
zlabel('  Current (A/s)');
title('Mamdani FLC Control Surface');
view(45, 30);
grid on;

% Plot 5: TS control surface
subplot(3,3,[6 9]);
Z_ts = zeros(size(X));
for i = 1:size(X,1)
    for j = 1:size(X,2)
        Z_ts(i,j) = evalfis(fis_ts, [X(i,j), Y(i,j)]);
    end
end
surf(X*1000, Y, Z_ts);
shading interp;
colorbar;
xlabel('Error (mm)');
ylabel('  Error (m/s)');
zlabel('  Current (A/s)');
title('Takagi-Sugeno FLC Control Surface');
view(45, 30);
grid on;

sgtitle('Fuzzy Logic Controller Structure', 'FontSize', 14, 'FontWeight', 'bold');

%% Simulation with Different Controllers

fprintf('=== Simulating Controllers ===\n\n');

% Test scenarios
scenarios = {
    struct('name', 'Setpoint Tracking', 'x_ref', 0.01, 'x0_val', 0.015, 'dist', 0);
    struct('name', 'Large Disturbance', 'x_ref', 0.01, 'x0_val', 0.01, 'dist', -0.003);
    struct('name', 'Setpoint Change', 'x_ref', 0.012, 'x0_val', 0.01, 'dist', 0);
};

% Controllers to test
controllers = struct();

% 1. Mamdani FLC
controllers(1).name = 'Mamdani FLC';
controllers(1).type = 'fuzzy_mamdani';
controllers(1).fis = fis_mamdani;
controllers(1).Ke = 1.0;      % Error scaling
controllers(1).Kde = 1.0;     % Delta error scaling
controllers(1).Ku = 1.0;      % Output scaling

% 2. Takagi-Sugeno FLC
controllers(2).name = 'TS FLC';
controllers(2).type = 'fuzzy_ts';
controllers(2).fis = fis_ts;
controllers(2).Ke = 1.0;
controllers(2).Kde = 1.0;
controllers(2).Ku = 1.0;

% 3. PID Controller (linearized design)
% Design PID for linearized system
s = tf('s');
G_lin = B_lin / (s^2 - A_lin);

% Use pole placement for stable closed-loop
wn = 50;  % Desired natural frequency (rad/s)
zeta = 0.7;  % Desired damping
desired_poles = [-zeta*wn + 1i*wn*sqrt(1-zeta^2), -zeta*wn - 1i*wn*sqrt(1-zeta^2)];

% PD controller (no integral for unstable system)
Kp_pid = (wn^2 - A_lin) / B_lin;
Kd_pid = (2*zeta*wn) / B_lin;
Ki_pid = 0;  % No integral for this example

controllers(3).name = 'PID (Linearized)';
controllers(3).type = 'pid';
controllers(3).Kp = Kp_pid;
controllers(3).Ki = Ki_pid;
controllers(3).Kd = Kd_pid;

fprintf('Controller Configurations:\n');
fprintf('  1. Mamdani FLC: 49 rules, centroid defuzzification\n');
fprintf('  2. TS FLC: 49 rules, weighted average\n');
fprintf('  3. PID: Kp=%.2f, Kd=%.2f (linearized design)\n\n', Kp_pid, Kd_pid);

% Simulate each scenario
for scen_idx = 1:length(scenarios)
    scenario = scenarios{scen_idx};
    
    fprintf('Scenario %d: %s\n', scen_idx, scenario.name);
    fprintf('  Reference: %.3f m, Initial: %.3f m\n', scenario.x_ref, scenario.x0_val);
    
    % Initialize storage for this scenario
    for ctrl_idx = 1:length(controllers)
        x_hist = zeros(1, N);
        v_hist = zeros(1, N);
        i_hist = zeros(1, N);
        e_hist = zeros(1, N);
        
        % Initial conditions
        x_hist(1) = scenario.x0_val;
        v_hist(1) = 0;
        i_hist(1) = params.i0;
        e_prev = 0;
        
        % Apply disturbance at t=1s for disturbance scenario
        dist_start_idx = find(time >= 1, 1);
        
        % Simulation loop
        for k = 1:N-1
            % Current state
            x = x_hist(k);
            v = v_hist(k);
            i = i_hist(k);
            
            % Reference (with disturbance)
            if strcmp(scenario.name, 'Large Disturbance') && k >= dist_start_idx
                x_ref = scenario.x_ref + scenario.dist;
            else
                x_ref = scenario.x_ref;
            end
            
            % Error and delta error
            e = x_ref - x;
            de = (e - e_prev) / Ts;  % Approximation of derivative
            
            e_hist(k) = e;
            
            % Controller
            switch controllers(ctrl_idx).type
                case 'fuzzy_mamdani'
                    % Scale inputs
                    e_scaled = e * controllers(ctrl_idx).Ke;
                    de_scaled = de * controllers(ctrl_idx).Kde;
                    
                    % Evaluate fuzzy system
                    di_scaled = evalfis(controllers(ctrl_idx).fis, [e_scaled, de_scaled]);
                    
                    % Scale output
                    di = di_scaled * controllers(ctrl_idx).Ku * Ts;
                    
                case 'fuzzy_ts'
                    e_scaled = e * controllers(ctrl_idx).Ke;
                    de_scaled = de * controllers(ctrl_idx).Kde;
                    di_scaled = evalfis(controllers(ctrl_idx).fis, [e_scaled, de_scaled]);
                    di = di_scaled * controllers(ctrl_idx).Ku * Ts;
                    
                case 'pid'
                    % PD control (no integral)
                    u = controllers(ctrl_idx).Kp * e + controllers(ctrl_idx).Kd * de;
                    di = u - i;
            end
            
            % Update current with saturation
            i_new = i + di;
            i_new = max(params.i_min, min(params.i_max, i_new));
            
            % Nonlinear dynamics
            if x > 0.001  % Prevent division by zero
                F_mag = params.k * i_new^2 / (x^2);
            else
                F_mag = params.k * i_new^2 / (0.001^2);  % Clamp
            end
            
            F_grav = params.m * params.g;
            a = (F_grav - F_mag) / params.m;
            
            % Integrate (simple Euler - adequate for small Ts)
            v_new = v + a * Ts;
            x_new = x + v_new * Ts;
            
            % Safety limits
            x_new = max(params.x_min, min(params.x_max, x_new));
            
            % Store
            x_hist(k+1) = x_new;
            v_hist(k+1) = v_new;
            i_hist(k+1) = i_new;
            
            e_prev = e;
        end
        
        e_hist(N) = x_ref - x_hist(N);
        
        % Calculate metrics
        metrics = struct();
        metrics.IAE = Ts * sum(abs(e_hist));
        metrics.ITAE = Ts * sum(time' .* abs(e_hist'));
        metrics.ISE = Ts * sum(e_hist.^2);
        metrics.max_error = max(abs(e_hist));
        metrics.settling_time = calculate_settling_time(e_hist, time, 0.02*scenario.x_ref);
        metrics.overshoot = max(0, (max(x_hist) - scenario.x_ref) / scenario.x_ref * 100);
        metrics.control_effort = Ts * sum(diff(i_hist).^2);
        
        % Store results
        controllers(ctrl_idx).scenarios(scen_idx).x = x_hist;
        controllers(ctrl_idx).scenarios(scen_idx).v = v_hist;
        controllers(ctrl_idx).scenarios(scen_idx).i = i_hist;
        controllers(ctrl_idx).scenarios(scen_idx).e = e_hist;
        controllers(ctrl_idx).scenarios(scen_idx).metrics = metrics;
        
        fprintf('  %s: ITAE=%.4f, MaxErr=%.4f mm, Overshoot=%.2f%%\n', ...
                controllers(ctrl_idx).name, metrics.ITAE, metrics.max_error*1000, metrics.overshoot);
    end
    fprintf('\n');
end

%% Detailed Visualization

% Figure 2: Scenario 1 - Setpoint Tracking
figure('Position', [100 100 1400 900]);
scen_idx = 1;

subplot(3,2,1);
hold on;
plot(time, scenarios{scen_idx}.x_ref * ones(1,N) * 1000, 'k-', 'LineWidth', 1.5);
colors_ctrl = {'r', 'b', 'g'};
for i = 1:length(controllers)
    plot(time, controllers(i).scenarios(scen_idx).x * 1000, colors_ctrl{i}, 'LineWidth', 2);
end
grid on;
xlabel('Time (s)');
ylabel('Gap (mm)');
title('Position Response - Setpoint Tracking');
legend(['Reference', {controllers.name}], 'Location', 'southeast');

subplot(3,2,3);
hold on;
for i = 1:length(controllers)
    plot(time, controllers(i).scenarios(scen_idx).v, colors_ctrl{i}, 'LineWidth', 2);
end
grid on;
xlabel('Time (s)');
ylabel('Velocity (m/s)');
title('Velocity');
legend({controllers.name}, 'Location', 'northeast');

subplot(3,2,5);
hold on;
for i = 1:length(controllers)
    plot(time, controllers(i).scenarios(scen_idx).i, colors_ctrl{i}, 'LineWidth', 2);
end
yline(params.i0, 'k:', 'LineWidth', 1);
yline(params.i_max, 'r-', 'LineWidth', 1);
grid on;
xlabel('Time (s)');
ylabel('Current (A)');
title('Control Signal (Current)');
legend([{controllers.name}, 'Equilibrium', 'Limit'], 'Location', 'northeast');

subplot(3,2,2);
hold on;
for i = 1:length(controllers)
    plot(time, controllers(i).scenarios(scen_idx).e * 1000, colors_ctrl{i}, 'LineWidth', 1.5);
end
grid on;
xlabel('Time (s)');
ylabel('Error (mm)');
title('Tracking Error');
legend({controllers.name}, 'Location', 'northeast');

% Phase plane
subplot(3,2,4);
hold on;
for i = 1:length(controllers)
    plot(controllers(i).scenarios(scen_idx).x * 1000, ...
         controllers(i).scenarios(scen_idx).v, colors_ctrl{i}, 'LineWidth', 2);
    % Mark start and end
    plot(controllers(i).scenarios(scen_idx).x(1) * 1000, ...
         controllers(i).scenarios(scen_idx).v(1), [colors_ctrl{i} 'o'], 'MarkerSize', 10, 'LineWidth', 2);
    plot(controllers(i).scenarios(scen_idx).x(end) * 1000, ...
         controllers(i).scenarios(scen_idx).v(end), [colors_ctrl{i} 'x'], 'MarkerSize', 10, 'LineWidth', 2);
end
plot(scenarios{scen_idx}.x_ref * 1000, 0, 'kp', 'MarkerSize', 15, 'MarkerFaceColor', 'k');
grid on;
xlabel('Position (mm)');
ylabel('Velocity (m/s)');
title('Phase Plane Trajectory');
legend({controllers.name}, 'Location', 'best');

% Performance comparison
subplot(3,2,6);
metrics_data = zeros(length(controllers), 3);
for i = 1:length(controllers)
    metrics_data(i,1) = controllers(i).scenarios(scen_idx).metrics.ITAE;
    metrics_data(i,2) = controllers(i).scenarios(scen_idx).metrics.max_error * 1000;
    metrics_data(i,3) = controllers(i).scenarios(scen_idx).metrics.control_effort;
end
bar(metrics_data);
set(gca, 'XTickLabel', {controllers.name});
ylabel('Value');
title('Performance Metrics');
legend('ITAE', 'Max Error (mm)', 'Control Effort', 'Location', 'northwest');
grid on;

sgtitle(['Scenario 1: ' scenarios{scen_idx}.name], 'FontSize', 14, 'FontWeight', 'bold');

% Figure 3: Scenario 2 - Disturbance Rejection
figure('Position', [150 150 1400 900]);
scen_idx = 2;

subplot(2,2,1);
hold on;
ref_signal = scenarios{scen_idx}.x_ref * ones(1,N);
dist_start_idx = find(time >= 1, 1);
ref_signal(dist_start_idx:end) = ref_signal(dist_start_idx:end) + scenarios{scen_idx}.dist;
plot(time, ref_signal * 1000, 'k-', 'LineWidth', 1.5);
for i = 1:length(controllers)
    plot(time, controllers(i).scenarios(scen_idx).x * 1000, colors_ctrl{i}, 'LineWidth', 2);
end
xline(1, 'r-', 'Disturbance', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Gap (mm)');
title('Position Response - Disturbance Rejection');
legend(['Reference', {controllers.name}], 'Location', 'southeast');

subplot(2,2,2);
hold on;
for i = 1:length(controllers)
    plot(time, controllers(i).scenarios(scen_idx).i, colors_ctrl{i}, 'LineWidth', 2);
end
xline(1, 'r-', 'Disturbance', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Current (A)');
title('Control Signal');
legend({controllers.name}, 'Location', 'northeast');

subplot(2,2,3);
hold on;
for i = 1:length(controllers)
    plot(time, abs(controllers(i).scenarios(scen_idx).e) * 1000, colors_ctrl{i}, 'LineWidth', 1.5);
end
xline(1, 'r-', 'Disturbance', 'LineWidth', 1.5);
set(gca, 'YScale', 'log');
grid on;
xlabel('Time (s)');
ylabel('|Error| (mm, log scale)');
title('Absolute Error');
legend({controllers.name}, 'Location', 'northeast');

% Recovery time comparison
subplot(2,2,4);
recovery_times = zeros(1, length(controllers));
for i = 1:length(controllers)
    % Find when error returns below 2% of disturbance
    threshold = 0.02 * abs(scenarios{scen_idx}.dist);
    post_dist = controllers(i).scenarios(scen_idx).e(dist_start_idx:end);
    idx_recovered = find(abs(post_dist) < threshold, 1);
    if ~isempty(idx_recovered)
        recovery_times(i) = time(dist_start_idx + idx_recovered - 1) - 1;
    else
        recovery_times(i) = T_sim - 1;
    end
end
bar(recovery_times);
set(gca, 'XTickLabel', {controllers.name});
ylabel('Recovery Time (s)');
title('Disturbance Recovery Time');
grid on;

sgtitle(['Scenario 2: ' scenarios{scen_idx}.name], 'FontSize', 14, 'FontWeight', 'bold');

% Figure 4: Comparison across all scenarios
figure('Position', [200 200 1200 800]);

% ITAE comparison
subplot(2,3,1);
itae_matrix = zeros(length(controllers), length(scenarios));
for i = 1:length(controllers)
    for j = 1:length(scenarios)
        itae_matrix(i,j) = controllers(i).scenarios(j).metrics.ITAE;
    end
end
bar(itae_matrix');
set(gca, 'XTickLabel', {scenarios{:}.name});
ylabel('ITAE');
title('ITAE Comparison');
legend({controllers.name}, 'Location', 'northwest');
grid on;

% Max error comparison
subplot(2,3,2);
maxerr_matrix = zeros(length(controllers), length(scenarios));
for i = 1:length(controllers)
    for j = 1:length(scenarios)
        maxerr_matrix(i,j) = controllers(i).scenarios(j).metrics.max_error * 1000;
    end
end
bar(maxerr_matrix');
set(gca, 'XTickLabel', {scenarios{:}.name});
ylabel('Max Error (mm)');
title('Maximum Error');
grid on;

% Overshoot comparison
subplot(2,3,3);
overshoot_matrix = zeros(length(controllers), length(scenarios));
for i = 1:length(controllers)
    for j = 1:length(scenarios)
        overshoot_matrix(i,j) = controllers(i).scenarios(j).metrics.overshoot;
    end
end
bar(overshoot_matrix');
set(gca, 'XTickLabel', {scenarios{:}.name});
ylabel('Overshoot (%)');
title('Overshoot');
grid on;

% Control effort comparison
subplot(2,3,4);
effort_matrix = zeros(length(controllers), length(scenarios));
for i = 1:length(controllers)
    for j = 1:length(scenarios)
        effort_matrix(i,j) = controllers(i).scenarios(j).metrics.control_effort;
    end
end
bar(effort_matrix');
set(gca, 'XTickLabel', {scenarios{:}.name});
ylabel('Control Effort');
title('Control Effort');
grid on;

% Rule firing analysis (Scenario 1, Mamdani)
subplot(2,3,5);
scen_idx = 1;
e_data = controllers(1).scenarios(scen_idx).e;
de_data = diff(controllers(1).scenarios(scen_idx).x) / Ts;
de_data = [de_data(1), de_data];  % Match length

% Sample every 10 points
sample_idx = 1:10:length(e_data);
scatter(e_data(sample_idx)*1000, de_data(sample_idx), 30, time(sample_idx), 'filled');
colorbar;
xlabel('Error (mm)');
ylabel('  Error (m/s)');
title('Fuzzy Controller Operating Points');
grid on;

% Membership degree evolution
subplot(2,3,6);
time_sample = time(sample_idx);
mf_degrees = zeros(length(sample_idx), 7);
for i = 1:length(sample_idx)
    e_val = e_data(sample_idx(i));
    for j = 1:7
        mf_degrees(i,j) = evalmf(fis_mamdani, e_val, j, 1);
    end
end
area(time_sample, mf_degrees);
xlabel('Time (s)');
ylabel('Membership Degree');
title('Error MF Activation Over Time');
legend({'NB','NM','NS','ZE','PS','PM','PB'}, 'Location', 'eastoutside');
ylim([0 1]);

sgtitle('Comprehensive Controller Comparison', 'FontSize', 14, 'FontWeight', 'bold');

%% Robustness Analysis

fprintf('=== Robustness Analysis ===\n\n');

% Test with parameter variations
mass_variations = [0.8, 0.9, 1.0, 1.1, 1.2];  %  20%
k_variations = [0.8, 0.9, 1.0, 1.1, 1.2];     %  20%

robustness_results = zeros(length(controllers), length(mass_variations), length(k_variations));

fprintf('Testing robustness to parameter variations...\n');
fprintf('  Mass: %.0f%% to +%.0f%%\n', (mass_variations(1)-1)*100, (mass_variations(end)-1)*100);
fprintf('  EM constant: %.0f%% to +%.0f%%\n\n', (k_variations(1)-1)*100, (k_variations(end)-1)*100);

for ctrl_idx = 1:length(controllers)
    for m_idx = 1:length(mass_variations)
        for k_idx = 1:length(k_variations)
            
            % Modified parameters
            params_mod = params;
            params_mod.m = params.m * mass_variations(m_idx);
            params_mod.k = params.k * k_variations(k_idx);
            
            % Quick simulation (2 seconds)
            T_test = 2;
            time_test = 0:Ts:T_test;
            N_test = length(time_test);
            
            x_hist = zeros(1, N_test);
            v_hist = zeros(1, N_test);
            i_hist = zeros(1, N_test);
            
            x_hist(1) = 0.015;
            v_hist(1) = 0;
            i_hist(1) = params.i0;
            e_prev = 0;
            x_ref = params.x0;
            
            for k = 1:N_test-1
                x = x_hist(k);
                v = v_hist(k);
                i = i_hist(k);
                
                e = x_ref - x;
                de = (e - e_prev) / Ts;
                
                % Controller
                switch controllers(ctrl_idx).type
                    case {'fuzzy_mamdani', 'fuzzy_ts'}
                        di_scaled = evalfis(controllers(ctrl_idx).fis, [e, de]);
                        di = di_scaled * Ts;
                    case 'pid'
                        u = controllers(ctrl_idx).Kp * e + controllers(ctrl_idx).Kd * de;
                        di = u - i;
                end
                
                i_new = max(params.i_min, min(params.i_max, i + di));
                
                % Modified dynamics
                F_mag = params_mod.k * i_new^2 / max(x, 0.001)^2;
                F_grav = params_mod.m * params_mod.g;
                a = (F_grav - F_mag) / params_mod.m;
                
                v_new = v + a * Ts;
                x_new = max(params.x_min, min(params.x_max, x + v_new * Ts));
                
                x_hist(k+1) = x_new;
                v_hist(k+1) = v_new;
                i_hist(k+1) = i_new;
                
                e_prev = e;
            end
            
            % Calculate ITAE
            e_hist = x_ref - x_hist;
            if any(isnan(e_hist)) || any(isinf(e_hist))
                robustness_results(ctrl_idx, m_idx, k_idx) = 1e6;  % Unstable
            else
                robustness_results(ctrl_idx, m_idx, k_idx) = Ts * sum(time_test' .* abs(e_hist'));
            end
        end
    end
    fprintf('  %s: Complete\n', controllers(ctrl_idx).name);
end

fprintf('\n');

% Figure 5: Robustness visualization
figure('Position', [250 250 1200 900]);

for ctrl_idx = 1:length(controllers)
    subplot(2,2,ctrl_idx);
    
    data = squeeze(robustness_results(ctrl_idx, :, :));
    data(data > 100) = 100;  % Cap for visualization
    
    imagesc(k_variations*100, mass_variations*100, data);
    colorbar;
    xlabel('EM Constant Variation (%)');
    ylabel('Mass Variation (%)');
    title([controllers(ctrl_idx).name ' - ITAE']);
    set(gca, 'YDir', 'normal');
    
    % Mark nominal point
    hold on;
    plot(100, 100, 'r*', 'MarkerSize', 15, 'LineWidth', 3);
end

% Sensitivity comparison
subplot(2,2,4);
sensitivity_scores = zeros(1, length(controllers));
for i = 1:length(controllers)
    data = robustness_results(i, :, :);
    data(data > 100) = 100;
    sensitivity_scores(i) = std(data(:));  % Standard deviation as sensitivity measure
end
bar(sensitivity_scores);
set(gca, 'XTickLabel', {controllers.name});
ylabel('Performance Variability (std of ITAE)');
title('Robustness Comparison');
grid on;

sgtitle('Parameter Sensitivity Analysis', 'FontSize', 14, 'FontWeight', 'bold');

fprintf('=== Summary ===\n\n');

fprintf('Performance Summary (Scenario 1 - Setpoint Tracking):\n');
fprintf('%-20s | %8s | %8s | %8s | %8s\n', 'Controller', 'ITAE', 'MaxErr', 'Ovrsht', 'Effort');
fprintf('%s\n', repmat('-', 1, 70));
for i = 1:length(controllers)
    m = controllers(i).scenarios(1).metrics;
    fprintf('%-20s | %8.4f | %6.2f mm | %6.2f%% | %8.2f\n', ...
            controllers(i).name, m.ITAE, m.max_error*1000, m.overshoot, m.control_effort);
end

fprintf('\nRobustness (ITAE std under  20%% parameter variation):\n');
for i = 1:length(controllers)
    fprintf('  %s: %.4f\n', controllers(i).name, sensitivity_scores(i));
end

fprintf('\n=== Fuzzy Logic Controller Design Complete ===\n');

%% Helper Functions

function ts = calculate_settling_time(error, time, threshold)
    % Find settling time (2% criterion)
    settled = abs(error) <= threshold;
    outside_idx = find(~settled);
    if ~isempty(outside_idx)
        ts = time(outside_idx(end));
    else
        ts = 0;
    end
end
