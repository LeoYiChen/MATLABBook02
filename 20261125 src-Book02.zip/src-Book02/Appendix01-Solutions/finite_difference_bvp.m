%% finite_difference_bvp.m
% Finite Difference Method for BVP
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : finite_difference_bvp
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem10.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Define the analytical solution
u_analytical = @(x) sin(x)./x;

% Define the domain and boundary conditions
a = 1; % Left boundary
b = 5; % Right boundary
ua = 0; % u(1) = 0
ub = sin(5)/5; % u(5) = sin(5)/5

% Solve the BVP using finite difference method with different grid sizes
n_values = [10, 20, 50, 100, 200, 500];
errors = zeros(size(n_values));

for idx = 1:length(n_values)
n = n_values(idx); % Number of interior points

% Grid spacing
h = (b - a) / (n + 1);

% Grid points (including boundaries)
x = linspace(a, b, n + 2);
x_interior = x(2:end-1);  % Interior points

% Initialize the coefficient matrix A and the right-hand side vector f
A = zeros(n, n);
f = zeros(n, 1);

% Fill the matrix and the right-hand side using finite difference approximations
for i = 1:n
    xi = x_interior(i);
    
    % Central difference approximation for u''
    A(i, i) = -2 / h^2;
    
    if i > 1
        A(i, i-1) = 1 / h^2 - 1 / (2 * h * xi);
    end
    
    if i < n
        A(i, i+1) = 1 / h^2 + 1 / (2 * h * xi);
    end
    
    % Add the term (1 - 1/x^2)u
    A(i, i) = A(i, i) + (1 - 1 / xi^2);
end

% Incorporate boundary conditions
f(1) = f(1) - (1 / h^2 - 1 / (2 * h * x_interior(1))) * ua;
f(n) = f(n) - (1 / h^2 + 1 / (2 * h * x_interior(end))) * ub;

% Solve the linear system
u_interior = A \ f;

% Combine with boundary values to get the complete solution
u_numerical = [ua; u_interior; ub];

% Calculate the analytical solution at the grid points
u_exact = u_analytical(x);

% Calculate the maximum error
errors(idx) = max(abs(u_numerical - u_exact'));

% Plot the solution for selected grid sizes
if ismember(n, [10, 50, 200])
    figure;
    plot(x, u_numerical, 'b-o', 'LineWidth', 1.5, 'DisplayName', 'Numerical Solution');
    hold on;
    plot(x, u_exact, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Analytical Solution');
    xlabel('x');
    ylabel('u(x)');
    title(sprintf('Solution with n = %d interior points', n));
    legend('show');
    grid on;
    
    % Plot the error
    figure;
    plot(x, abs(u_numerical - u_exact'), 'k-', 'LineWidth', 1.5);
    xlabel('x');
    ylabel('Absolute Error');
    title(sprintf('Error with n = %d interior points', n));
    grid on;
end

end

% Plot the convergence of the error
figure;
loglog(1./(n_values+1), errors, 'bo-', 'LineWidth', 1.5);
hold on;
% Add a reference line for second-order convergence (O(h^2))
h_ref = logspace(-3, -1, 100);
err_ref = 0.5 * h_ref.^2;
loglog(h_ref, err_ref, 'r-', 'LineWidth', 1.5, 'DisplayName', 'O(h^2)');
xlabel('Grid Spacing (h)');
ylabel('Maximum Absolute Error');
title('Convergence of Finite Difference Method');
legend('Numerical Error', 'O(h^2)');
grid on;

% Create a more detailed plot with the final solution
n_fine = 500;
h_fine = (b - a) / (n_fine + 1);
x_fine = linspace(a, b, n_fine + 2);
x_interior_fine = x_fine(2:end-1);

% Set up the linear system
A_fine = zeros(n_fine, n_fine);
f_fine = zeros(n_fine, 1);

for i = 1:n_fine
xi = x_interior_fine(i);

A_fine(i, i) = -2 / h_fine^2;

if i > 1
    A_fine(i, i-1) = 1 / h_fine^2 - 1 / (2 * h_fine * xi);
end

A_fine(i, i-1) = 1 / h_fine^2 - 1 / (2 * h_fine * xi);
A_fine(i, i) = -2 / h_fine^2 - 1;
end

% Set boundary conditions for fine grid
A_fine(1, 1) = 1;
A_fine(1, 2:end) = 0;
A_fine(n_fine+1, n_fine+1) = 1;
A_fine(n_fine+1, 1:n_fine) = 0;
b_fine = zeros(n_fine+1, 1);
b_fine(1) = u_left;
b_fine(n_fine+1) = u_right;

% Solve the system on the fine grid for reference solution
u_fine = A_fine \ b_fine;

% Create initial guess on coarse grid (linear interpolation)
u_coarse = zeros(n_coarse+1, 1);
u_coarse(1) = u_left;
u_coarse(n_coarse+1) = u_right;
for i = 2:n_coarse
    u_coarse(i) = u_left + (i-1)*(u_right-u_left)/n_coarse;
end

% Implement multigrid V-cycle
max_iterations = 100;
tolerance = 1e-6;
residual_history = zeros(max_iterations, 1);

for iter = 1:max_iterations
    % 1. Pre-smoothing on coarse grid
    u_coarse = gaussSeidel(A_coarse, b_coarse, u_coarse, 5);
    
    % 2. Compute residual on coarse grid
    r_coarse = b_coarse - A_coarse * u_coarse;
    
    % 3. Restrict residual to coarser grid (not applicable in this two-grid method)
    
    % 4. Solve the residual equation on the coarsest grid
    % Here we're already on the coarsest grid in our two-grid method
    e_coarse = A_coarse \ r_coarse;
    
    % 5. Interpolate error to finer grid (not applicable in this two-grid method)
    
    % 6. Apply correction
    u_coarse = u_coarse + e_coarse;
    
    % 7. Post-smoothing
    u_coarse = gaussSeidel(A_coarse, b_coarse, u_coarse, 5);
    
    % Check convergence
    residual = norm(b_coarse - A_coarse * u_coarse, inf);
    residual_history(iter) = residual;
    
    if residual < tolerance
        break;
    end
end

% Interpolate solution from coarse to fine grid
u_mg = zeros(n_fine+1, 1);
u_mg(1) = u_coarse(1);
u_mg(n_fine+1) = u_coarse(n_coarse+1);

% Linear interpolation between coarse grid points
for i = 2:n_fine
    % Find the nearest coarse grid points
    coarse_idx_left = floor((i-1) * h_fine / h_coarse) + 1;
    coarse_idx_right = ceil((i-1) * h_fine / h_coarse) + 1;
    
    if coarse_idx_left == coarse_idx_right
        u_mg(i) = u_coarse(coarse_idx_left);
    else
        % Linear interpolation
        x_left = (coarse_idx_left-1) * h_coarse;
        x_right = (coarse_idx_right-1) * h_coarse;
        x_current = (i-1) * h_fine;
        
        weight_right = (x_current - x_left) / (x_right - x_left);
        weight_left = 1 - weight_right;
        
        u_mg(i) = weight_left * u_coarse(coarse_idx_left) + 
                 weight_right * u_coarse(coarse_idx_right);
    end
end

% Compute and display errors
error_mg = max(abs(u_fine - u_mg));
fprintf('Maximum error using multigrid: %e\n', error_mg);

% Plot results
x_fine = linspace(a, b, n_fine+1);
figure;
plot(x_fine, u_fine, 'k-', 'LineWidth', 2, 'DisplayName', 'Reference Solution');
hold on;
plot(x_fine, u_mg, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Multigrid Solution');
xlabel('x');
ylabel('u(x)');
title('BVP Solution using Multigrid Method');
legend('show');
grid on;

% Plot convergence history
figure;
semilogy(1:iter, residual_history(1:iter), 'o-', 'LineWidth', 1.5);
xlabel('Iteration');
ylabel('Residual (log scale)');
title('Multigrid Convergence History');
grid on;

% Gauss-Seidel smoother function
function u = gaussSeidel(A, b, u, num_iterations)
    n = length(b);
    for iter = 1:num_iterations
        for i = 1:n
            u(i) = (b(i) - A(i,[1:i-1,i+1:n]) * u([1:i-1,i+1:n])) / A(i,i);
        end
    end
end

