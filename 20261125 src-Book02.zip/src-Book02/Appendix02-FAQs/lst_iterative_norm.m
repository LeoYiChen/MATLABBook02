%% lst_iterative_norm.m
% Iterative Approach for Sum of Squares Computation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : lst:iterative_norm
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
sum_sq = 0;
for i = 1:length(x)
    sum_sq = sum_sq + x(i)^2;
end
