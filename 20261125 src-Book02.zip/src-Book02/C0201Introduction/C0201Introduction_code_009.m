%% C0201Introduction_code_009.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% UNSTABLE: Two-pass algorithm susceptible to cancellation
meanValue = mean(data);
variance_unstable = mean((data - meanValue).^2);

% STABLE: Welford's online algorithm
n = length(data);
M = 0;
S = 0;

for k = 1:n
    oldM = M;
    M = M + (data(k) - M) / k;
    S = S + (data(k) - M) * (data(k) - oldM);
end

variance_stable = S / (n - 1);

% MATLAB's built-in functions use numerically stable algorithms
variance_builtin = var(data);  % Preferred approach
