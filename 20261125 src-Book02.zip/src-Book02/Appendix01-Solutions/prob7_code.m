%% prob7_code.m
% Vector field visualisation for flow around cylinder.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob7_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Vector Field Visualisation: Flow Around Circular Cylinder
% File: MATLABBook02_Chapter07_Problem07.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Visualises 2D potential flow using quiver plots, streamlines,
%              and velocity contours with critical point identification
% =========================================================================

function MATLABBook02_Chapter07_Problem07()
    % Main function for Problem 7: Vector Field Visualisation
    
    clc; clear; close all;
    
    % Define flow parameters
    flowParams = defineFlowParameters();
    
    % Generate computational grid
    [X, Y] = generateFlowGrid(flowParams);
    
    % Compute velocity field
    [U, V, speed, psi] = computePotentialFlow(X, Y, flowParams);
    
    % Create quiver plot visualisation
    createQuiverPlot(X, Y, U, V, speed, flowParams);
    
    % Generate streamline visualisation
    createStreamlinePlot(X, Y, U, V, speed, flowParams);
    
    % Create combined visualisation
    createCombinedFlowVisualisation(X, Y, U, V, speed, psi, flowParams);
    
    % Identify and analyse critical points
    analyseStagnationPoints(X, Y, U, V, flowParams);
    
    % Create stream function contour plot
    createStreamFunctionPlot(X, Y, psi, flowParams);
end

function params = defineFlowParameters()
    % DEFINEFLOWPARAMETERS - Sets cylinder geometry and flow conditions
    
    params.cylinderRadius = 1.0;    % Cylinder radius (m)
    params.freeStreamVel = 10.0;    % Free-stream velocity (m/s)
    params.xMin = -3.0;             % Domain x minimum
    params.xMax = 3.0;              % Domain x maximum
    params.yMin = -3.0;             % Domain y minimum
    params.yMax = 3.0;              % Domain y maximum
    params.gridPoints = 40;         % Grid resolution
end

function [X, Y] = generateFlowGrid(params)
    % GENERATEFLOWGRID - Creates computational mesh
    
    x = linspace(params.xMin, params.xMax, params.gridPoints);
    y = linspace(params.yMin, params.yMax, params.gridPoints);
    [X, Y] = meshgrid(x, y);
end

function [U, V, speed, psi] = computePotentialFlow(X, Y, params)
    % COMPUTEPOTENTIALFLOW - Calculates velocity field for flow around cylinder
    %
    % Uses potential flow theory: uniform flow + doublet
    %
    % Inputs:
    %   X, Y - Meshgrid coordinates
    %   params - Flow parameters structure
    %
    % Outputs:
    %   U, V - Velocity components
    %   speed - Velocity magnitude
    %   psi - Stream function
    
    R = params.cylinderRadius;
    U_inf = params.freeStreamVel;
    
    % Convert to polar coordinates
    r = sqrt(X.^2 + Y.^2);
    theta = atan2(Y, X);
    
    % Velocity potential: phi = U_inf * r * (1 + R^2/r^2) * cos(theta)
    % Stream function: psi = U_inf * r * (1 - R^2/r^2) * sin(theta)
    
    % Radial and tangential velocities in polar coordinates
    Vr = U_inf * (1 - (R^2 ./ r.^2)) .* cos(theta);
    Vtheta = -U_inf * (1 + (R^2 ./ r.^2)) .* sin(theta);
    
    % Convert to Cartesian velocities
    U = Vr .* cos(theta) - Vtheta .* sin(theta);
    V = Vr .* sin(theta) + Vtheta .* cos(theta);
    
    % Stream function
    psi = U_inf * r .* (1 - (R^2 ./ r.^2)) .* sin(theta);
    
    % Set velocities to zero inside cylinder
    insideCylinder = (r < R);
    U(insideCylinder) = 0;
    V(insideCylinder) = 0;
    psi(insideCylinder) = NaN;
    
    % Compute velocity magnitude
    speed = sqrt(U.^2 + V.^2);
end

function createQuiverPlot(X, Y, U, V, speed, params)
    % CREATEQUIVERPLOT - Generates arrow diagram of velocity field
    
    figure('Name', 'Quiver Plot: Velocity Vectors', ...
           'Position', [50, 50, 900, 800]);
    
    % Subsample grid for clearer quiver display
    skip = 2;
    Xq = X(1:skip:end, 1:skip:end);
    Yq = Y(1:skip:end, 1:skip:end);
    Uq = U(1:skip:end, 1:skip:end);
    Vq = V(1:skip:end, 1:skip:end);
    speedq = speed(1:skip:end, 1:skip:end);
    
    % Create filled contour for velocity magnitude
    contourf(X, Y, speed, 20, 'LineStyle', 'none');
    hold on;
    
    % Overlay quiver plot
    quiver(Xq, Yq, Uq, Vq, 1.5, 'k', 'LineWidth', 1.2, 'AutoScale', 'on');
    
    % Draw cylinder
    theta_cyl = linspace(0, 2*pi, 100);
    xc = params.cylinderRadius * cos(theta_cyl);
    yc = params.cylinderRadius * sin(theta_cyl);
    fill(xc, yc, [0.3, 0.3, 0.3], 'EdgeColor', 'k', 'LineWidth', 2);
    
    % Formatting
    colormap(jet);
    cb = colorbar;
    ylabel(cb, 'Velocity Magnitude (m/s)', 'Interpreter', 'latex', 'FontSize', 11);
    caxis([0, max(speed(:))]);
    
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Quiver Plot: Flow Around Circular Cylinder', ...
          'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    
    axis equal;
    xlim([params.xMin, params.xMax]);
    ylim([params.yMin, params.yMax]);
    grid on;
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    hold off;
end

function createStreamlinePlot(X, Y, U, V, speed, params)
    % CREATESTREAMLINEPLOT - Generates streamline visualisation
    
    figure('Name', 'Streamline Plot', 'Position', [100, 100, 900, 800]);
    
    % Create velocity magnitude contours
    contourf(X, Y, speed, 15, 'LineStyle', 'none');
    hold on;
    
    % Define streamline starting points
    startY = linspace(-2.5, 2.5, 20);
    startX = params.xMin * ones(size(startY));
    
    % Compute and plot streamlines
    streamline(X, Y, U, V, startX, startY, [0.05, 10000]);
    
    % Draw cylinder
    theta_cyl = linspace(0, 2*pi, 100);
    xc = params.cylinderRadius * cos(theta_cyl);
    yc = params.cylinderRadius * sin(theta_cyl);
    fill(xc, yc, [0.3, 0.3, 0.3], 'EdgeColor', 'k', 'LineWidth', 2);
    
    % Mark stagnation points
    plot([-params.cylinderRadius, params.cylinderRadius], [0, 0], ...
         'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r', 'LineWidth', 2);
    
    % Formatting
    colormap(parula);
    cb = colorbar;
    ylabel(cb, 'Velocity Magnitude (m/s)', 'Interpreter', 'latex', 'FontSize', 11);
    
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Streamlines: Potential Flow Around Cylinder', ...
          'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    
    axis equal;
    xlim([params.xMin, params.xMax]);
    ylim([params.yMin, params.yMax]);
    grid on;
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    hold off;
end

function createCombinedFlowVisualisation(X, Y, U, V, speed, psi, params)
    % CREATECOMBINEDFLOWVISUALISATION - Multi-panel comprehensive view
    
    figure('Name', 'Combined Flow Visualisation', ...
           'Position', [50, 50, 1400, 1000]);
    
    % Panel 1: Velocity magnitude contours
    subplot(2, 2, 1);
    contourf(X, Y, speed, 20, 'LineStyle', 'none');
    hold on;
    drawCylinder(params);
    colormap(gca, jet);
    cb1 = colorbar;
    ylabel(cb1, 'Speed (m/s)', 'Interpreter', 'latex', 'FontSize', 9);
    title('(a) Velocity Magnitude', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
    axis equal; xlim([params.xMin, params.xMax]); ylim([params.yMin, params.yMax]);
    grid on; set(gca, 'FontSize', 9);
    hold off;
    
    % Panel 2: Streamlines
    subplot(2, 2, 2);
    contourf(X, Y, speed, 15, 'LineStyle', 'none', 'FaceAlpha', 0.6);
    hold on;
    startY = linspace(-2.5, 2.5, 15);
    startX = params.xMin * ones(size(startY));
    streamline(X, Y, U, V, startX, startY, [0.05, 10000]);
    drawCylinder(params);
    colormap(gca, parula);
    title('(b) Streamlines', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
    axis equal; xlim([params.xMin, params.xMax]); ylim([params.yMin, params.yMax]);
    grid on; set(gca, 'FontSize', 9);
    hold off;
    
    % Panel 3: Stream function contours
    subplot(2, 2, 3);
    contour(X, Y, psi, 30, 'LineWidth', 1.5);
    hold on;
    drawCylinder(params);
    colormap(gca, cool);
    cb3 = colorbar;
    ylabel(cb3, '$\psi$ (m$^2$/s)', 'Interpreter', 'latex', 'FontSize', 9);
    title('(c) Stream Function Contours', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
    axis equal; xlim([params.xMin, params.xMax]); ylim([params.yMin, params.yMax]);
    grid on; set(gca, 'FontSize', 9);
    hold off;
    
    % Panel 4: Quiver with velocity magnitude
    subplot(2, 2, 4);
    skip = 3;
    Xq = X(1:skip:end, 1:skip:end);
    Yq = Y(1:skip:end, 1:skip:end);
    Uq = U(1:skip:end, 1:skip:end);
    Vq = V(1:skip:end, 1:skip:end);
    contourf(X, Y, speed, 15, 'LineStyle', 'none');
    hold on;
    quiver(Xq, Yq, Uq, Vq, 1.5, 'k', 'LineWidth', 1);
    drawCylinder(params);
    plot([-params.cylinderRadius, params.cylinderRadius], [0, 0], ...
         'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    colormap(gca, jet);
    cb4 = colorbar;
    ylabel(cb4, 'Speed (m/s)', 'Interpreter', 'latex', 'FontSize', 9);
    title('(d) Velocity Vectors', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
    axis equal; xlim([params.xMin, params.xMax]); ylim([params.yMin, params.yMax]);
    grid on; set(gca, 'FontSize', 9);
    hold off;
    
    sgtitle('Comprehensive Flow Visualisation: Cylinder in Cross-Flow', ...
           'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
end

function drawCylinder(params)
    % DRAWCYLINDER - Helper function to plot cylinder
    theta_cyl = linspace(0, 2*pi, 100);
    xc = params.cylinderRadius * cos(theta_cyl);
    yc = params.cylinderRadius * sin(theta_cyl);
    fill(xc, yc, [0.3, 0.3, 0.3], 'EdgeColor', 'k', 'LineWidth', 1.5);
end

function createStreamFunctionPlot(X, Y, psi, params)
    % CREATESTREAMFUNCTIONPLOT - Dedicated stream function visualisation
    
    figure('Name', 'Stream Function Analysis', 'Position', [150, 150, 800, 700]);
    
    % Create contour plot
    [C, h] = contour(X, Y, psi, 40, 'LineWidth', 1.5);
    clabel(C, h, 'FontSize', 8, 'Color', 'k', 'Interpreter', 'latex');
    hold on;
    
    % Draw cylinder
    drawCylinder(params);
    
    % Highlight psi = 0 contour (dividing streamline)
    contour(X, Y, psi, [0, 0], 'r-', 'LineWidth', 3);
    
    % Formatting
    colormap(jet);
    cb = colorbar;
    ylabel(cb, 'Stream Function, $\psi$ (m$^2$/s)', ...
           'Interpreter', 'latex', 'FontSize', 11);
    
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Stream Function Contours ($\psi = $ constant)', ...
          'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    
    axis equal;
    xlim([params.xMin, params.xMax]);
    ylim([params.yMin, params.yMax]);
    grid on;
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    
    legend('Stream function', 'Cylinder', 'Dividing streamline ($\psi=0$)', ...
          'Location', 'northeast', 'Interpreter', 'latex', 'FontSize', 9);
    hold off;
end

function analyseStagnationPoints(X, Y, U, V, params)
    % ANALYSESTAGNATIONPOINTS - Identifies and characterises critical points
    
    fprintf('\n========================================\n');
    fprintf('   STAGNATION POINT ANALYSIS\n');
    fprintf('========================================\n');
    
    % Theoretical stagnation points for cylinder
    R = params.cylinderRadius;
    
    fprintf('Theoretical Stagnation Points:\n');
    fprintf('  Front:  x = %.3f m, y = 0 m\n', -R);
    fprintf('  Rear:   x = %.3f m, y = 0 m\n', R);
    
    % Find numerical stagnation points (where |V|   0)
    speed = sqrt(U.^2 + V.^2);
    r = sqrt(X.^2 + Y.^2);
    
    % Exclude interior of cylinder
    speed_exterior = speed;
    speed_exterior(r < R) = Inf;
    
    % Find local minima
    [minSpeed, idx] = min(speed_exterior(:));
    [row, col] = ind2sub(size(speed_exterior), idx);
    
    fprintf('\nNumerical Minimum Speed Location:\n');
    fprintf('  Position: x = %.3f m, y = %.3f m\n', X(row,col), Y(row,col));
    fprintf('  Speed: %.4f m/s\n', minSpeed);
    
    % Maximum velocity (at top/bottom of cylinder)
    maxSpeed = max(speed(:));
    [row_max, col_max] = find(speed == maxSpeed, 1);
    
    fprintf('\nMaximum Velocity:\n');
    fprintf('  Position: x = %.3f m, y = %.3f m\n', X(row_max,col_max), Y(row_max,col_max));
    fprintf('  Speed: %.2f m/s\n', maxSpeed);
    fprintf('  Theoretical max (2*U_inf): %.2f m/s\n', 2*params.freeStreamVel);
    
    % Pressure coefficient at stagnation (Cp = 1)
    fprintf('\n=== Flow Characteristics ===\n');
    fprintf('Free-stream velocity: %.2f m/s\n', params.freeStreamVel);
    fprintf('Maximum velocity ratio: %.2f\n', maxSpeed / params.freeStreamVel);
    fprintf('Cylinder diameter: %.2f m\n', 2*R);
    
    fprintf('========================================\n');
end
