%% C020201Maths_Fundamental_code_114.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Robust regression using iteratively reweighted least squares
robustModel = fitlm(predictors, response, 'RobustOpts', 'on');

% Or use robust fit directly
robustFit = robustfit(predictors, response);

% Compare OLS and robust estimates
fprintf('OLS slope: %.3f\n', standardModel.Coefficients.Estimate(2));
fprintf('Robust slope: %.3f\n', robustFit(2));
