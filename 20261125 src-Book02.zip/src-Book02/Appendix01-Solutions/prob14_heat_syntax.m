%% prob14_heat_syntax.m
% Heat diffusion equation for PCM thermal modelling.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob14_heat_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% 1D transient heat equation with phase change
% dT/dt = alpha * d2T/dx2 + Q_latent(T)
% where Q_latent accounts for phase transition energy
