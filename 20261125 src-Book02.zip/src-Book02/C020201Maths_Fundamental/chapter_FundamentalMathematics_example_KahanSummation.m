%% chapter_FundamentalMathematics_example_KahanSummation.m
% Comparison of standard summation versus Kahan compensated summation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_KahanSummation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Demonstrating Kahan Compensated Summation Algorithm
% Shows improved accuracy when summing floating-point numbers

% Create test data: sum many small numbers with one large number
numSmallValues = 10000;
smallValue = 1e-8;
largeValue = 1e8;

values = [largeValue, repmat(smallValue, 1, numSmallValues)];

% Standard summation
standardSum = sum(values);

% Kahan compensated summation

compensatedSum = kahanSummation(values);

% Exact answer for comparison
exactSum = largeValue + numSmallValues * smallValue;

% Display results showing precision improvement
fprintf('Exact sum:       %.10f\n', exactSum);
fprintf('Standard sum:    %.10f (error: %.2e)\n', ...
    standardSum, abs(standardSum - exactSum));
fprintf('Kahan sum:       %.10f (error: %.2e)\n', ...
    compensatedSum, abs(compensatedSum - exactSum));

% Local functions (moved to end so this listing is a valid MATLAB script)
function kahanSum = kahanSummation(values)
    kahanSum = 0.0;
    compensation = 0.0;
    
    for idx = 1:length(values)
        correctedValue = values(idx) - compensation;
        tempSum = kahanSum + correctedValue;
        compensation = (tempSum - kahanSum) - correctedValue;
        kahanSum = tempSum;
    end
end
