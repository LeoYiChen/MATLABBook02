%% listing_duplicate_detection.m
% Comprehensive duplicate detection framework with fuzzy matching capabilities.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : listing_duplicate_detection
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [unique_data, duplicate_indices, dedup_stats] = removeDuplicateRecords(data, method, options)
% removeDuplicateRecords - Advanced duplicate detection and removal
%
% Syntax: [unique_data, dup_idx, stats] = removeDuplicateRecords(data, method, options)
%
% Inputs:
%   data    - Input data (cell array, table, or numeric matrix)
%   method  - Detection method: 'exact', 'fuzzy', 'probabilistic'
%   options - Structure with method-specific parameters
%
% Outputs:
%   unique_data      - Data with duplicates removed
%   duplicate_indices - Logical array indicating duplicate records
%   dedup_stats      - Structure containing deduplication statistics

    % Input validation and default parameters
    if nargin < 2, method = 'exact'; end
    if nargin < 3, options = struct(); end
    
    % Set default parameters
    if ~isfield(options, 'similarity_threshold'), options.similarity_threshold = 0.8; end
    if ~isfield(options, 'key_fields'), options.key_fields = []; end
    if ~isfield(options, 'case_sensitive'), options.case_sensitive = false; end
    if ~isfield(options, 'trim_whitespace'), options.trim_whitespace = true; end
    
    % Convert input to consistent format
    [processed_data, original_format] = preprocessDataForDeduplication(data, options);
    [n_rows, n_cols] = size(processed_data);
    
    % Initialise outputs
    duplicate_indices = false(n_rows, 1);
    dedup_stats = struct();
    dedup_stats.method = method;
    dedup_stats.original_records = n_rows;
    dedup_stats.processing_time = tic;
    
    % Apply selected duplicate detection method
    switch lower(method)
        case 'exact'
            % Exact duplicate detection
            if istable(data)
                [~, unique_idx] = unique(data, 'rows', 'stable');
            else
                [~, unique_idx] = unique(processed_data, 'rows', 'stable');
            end
            duplicate_indices = true(n_rows, 1);
            duplicate_indices(unique_idx) = false;
            dedup_stats.detection_method = 'Exact matching';
            
        case 'fuzzy'
            % Fuzzy duplicate detection using string similarity
            similarity_matrix = calculateSimilarityMatrix(processed_data, options);
            duplicate_pairs = findDuplicatePairs(similarity_matrix, options.similarity_threshold);
            duplicate_indices = markDuplicatesFromPairs(duplicate_pairs, n_rows);
            dedup_stats.detection_method = 'Fuzzy string matching';
            dedup_stats.similarity_threshold = options.similarity_threshold;
            dedup_stats.similarity_matrix_size = size(similarity_matrix);
            
        case 'probabilistic'
            % Probabilistic record linkage
            match_scores = calculateProbabilisticScores(processed_data, options);
            duplicate_pairs = findDuplicatePairs(match_scores, options.similarity_threshold);
            duplicate_indices = markDuplicatesFromPairs(duplicate_pairs, n_rows);
            dedup_stats.detection_method = 'Probabilistic record linkage';
            dedup_stats.match_threshold = options.similarity_threshold;
            
        otherwise
            error('Unknown duplicate detection method: %s', method);
    end
    
    % Create output based on original format
    unique_data = extractUniqueRecords(data, duplicate_indices, original_format);
    
    % Calculate final statistics
    dedup_stats.duplicates_found = sum(duplicate_indices);
    dedup_stats.unique_records = dedup_stats.original_records - dedup_stats.duplicates_found;
    dedup_stats.duplicate_percentage = (dedup_stats.duplicates_found / dedup_stats.original_records) * 100;
    dedup_stats.processing_time = toc(dedup_stats.processing_time);
    dedup_stats.memory_reduction_mb = (dedup_stats.duplicates_found * n_cols * 8) / (1024^2); % Approximate
end

function [processed_data, format_info] = preprocessDataForDeduplication(data, options)
% Preprocess data for consistent duplicate detection
    
    format_info = struct();
    format_info.original_class = class(data);
    format_info.is_table = istable(data);
    format_info.is_cell = iscell(data);
    
    if istable(data)
        % Convert table to cell array for processing
        processed_data = table2cell(data);
        format_info.variable_names = data.Properties.VariableNames;
    elseif iscell(data)
        processed_data = data;
    elseif isnumeric(data)
        processed_data = num2cell(data);
    else
        processed_data = cellstr(data);
    end
    
    % Apply preprocessing options
    if options.trim_whitespace
        processed_data = cellfun(@(x) strtrim(char(x)), processed_data, 'UniformOutput', false);
    end
    
    if ~options.case_sensitive
        char_mask = cellfun(@ischar, processed_data) | cellfun(@isstring, processed_data);
        processed_data(char_mask) = cellfun(@lower, processed_data(char_mask), 'UniformOutput', false);
    end
end

function similarity_matrix = calculateSimilarityMatrix(data, options)
% Calculate pairwise similarity matrix for fuzzy matching
    
    [n_rows, n_cols] = size(data);
    similarity_matrix = zeros(n_rows, n_rows);
    
    % Calculate similarity for each pair of records
    for i = 1:n_rows
        for j = i+1:n_rows
            record_similarity = 0;
            valid_comparisons = 0;
            
            for k = 1:n_cols
                if ~isempty(options.key_fields) && ~ismember(k, options.key_fields)
                    continue; % Skip non-key fields if specified
                end
                
                field1 = data{i, k};
                field2 = data{j, k};
                
                if ~isempty(field1) && ~isempty(field2)
                    field_sim = calculateFieldSimilarity(field1, field2);
                    record_similarity = record_similarity + field_sim;
                    valid_comparisons = valid_comparisons + 1;
                end
            end
            
            if valid_comparisons > 0
                similarity_matrix(i, j) = record_similarity / valid_comparisons;
                similarity_matrix(j, i) = similarity_matrix(i, j); % Symmetric matrix
            end
        end
    end
end

function similarity = calculateFieldSimilarity(field1, field2)
% Calculate similarity between two fields using multiple metrics
    
    % Convert to strings for comparison
    str1 = char(field1);
    str2 = char(field2);
    
    % Exact match
    if strcmp(str1, str2)
        similarity = 1.0;
        return;
    end
    
    % Jaccard similarity based on character bigrams
    bigrams1 = extractNGrams(str1, 2);
    bigrams2 = extractNGrams(str2, 2);
    
    intersection_size = length(intersect(bigrams1, bigrams2));
    union_size = length(union(bigrams1, bigrams2));
    
    if union_size > 0
        jaccard_sim = intersection_size / union_size;
    else
        jaccard_sim = 0;
    end
    
    % Levenshtein similarity
    lev_distance = calculateLevenshteinDistance(str1, str2);
    max_length = max(length(str1), length(str2));
    
    if max_length > 0
        lev_sim = 1 - (lev_distance / max_length);
    else
        lev_sim = 1;
    end
    
    % Combined similarity (weighted average)
    similarity = 0.6 * jaccard_sim + 0.4 * lev_sim;
end

function ngrams = extractNGrams(text, n)
% Extract n-grams from text
    if length(text) < n
        ngrams = {text};
    else
        ngrams = cell(length(text) - n + 1, 1);
        for i = 1:length(text) - n + 1
            ngrams{i} = text(i:i+n-1);
        end
    end
end

function distance = calculateLevenshteinDistance(s1, s2)
% Calculate Levenshtein distance between two strings
    m = length(s1);
    n = length(s2);
    
    % Create distance matrix
    d = zeros(m + 1, n + 1);
    
    % Initialise base cases
    d(:, 1) = 0:m;
    d(1, :) = 0:n;
    
    % Fill distance matrix
    for i = 2:m+1
        for j = 2:n+1
            if s1(i-1) == s2(j-1)
                cost = 0;
            else
                cost = 1;
            end
            
            d(i, j) = min([
                d(i-1, j) + 1,     % Deletion
                d(i, j-1) + 1,     % Insertion
                d(i-1, j-1) + cost % Substitution
            ]);
        end
    end
    
    distance = d(m+1, n+1);
end

function duplicate_pairs = findDuplicatePairs(similarity_matrix, threshold)
% Find pairs of records above similarity threshold
    [rows, cols] = find(similarity_matrix >= threshold & similarity_matrix < 1);
    duplicate_pairs = [rows, cols];
    
    % Remove redundant pairs (keep only upper triangle)
    valid_pairs = rows < cols;
    duplicate_pairs = duplicate_pairs(valid_pairs, :);
end

function duplicate_indices = markDuplicatesFromPairs(duplicate_pairs, n_records)
% Mark duplicate records based on pairs, keeping first occurrence
    duplicate_indices = false(n_records, 1);
    
    if ~isempty(duplicate_pairs)
        % Group connected components to handle transitive duplicates
        components = findConnectedComponents(duplicate_pairs, n_records);
        
        % Mark all but the first record in each component as duplicates
        for i = 1:length(components)
            component = components{i};
            if length(component) > 1
                % Keep the first record, mark others as duplicates
                duplicate_indices(component(2:end)) = true;
            end
        end
    end
end

function components = findConnectedComponents(pairs, n_nodes)
% Find connected components in duplicate pairs graph
    % Create adjacency list
    adj_list = cell(n_nodes, 1);
    for i = 1:size(pairs, 1)
        node1 = pairs(i, 1);
        node2 = pairs(i, 2);
        adj_list{node1} = [adj_list{node1}, node2];
        adj_list{node2} = [adj_list{node2}, node1];
    end
    
    % Find connected components using DFS
    visited = false(n_nodes, 1);
    components = {};
    
    for i = 1:n_nodes
        if ~visited(i) && ~isempty(adj_list{i})
            component = depthFirstSearch(i, adj_list, visited);
            if ~isempty(component)
                components{end+1} = sort(component);
            end
        end
    end
end

function component = depthFirstSearch(start_node, adj_list, visited)
% Depth-first search to find connected component
    stack = start_node;
    component = [];
    
    while ~isempty(stack)
        current = stack(end);
        stack(end) = [];
        
        if ~visited(current)
            visited(current) = true;
            component = [component, current];
            
            % Add unvisited neighbours to stack
            neighbours = adj_list{current};
            for neighbour = neighbours
                if ~visited(neighbour)
                    stack = [stack, neighbour];
                end
            end
        end
    end
end

function unique_data = extractUniqueRecords(original_data, duplicate_indices, format_info)
% Extract unique records maintaining original format
    if format_info.is_table
        unique_data = original_data(~duplicate_indices, :);
    else
        unique_data = original_data(~duplicate_indices, :);
    end
end
