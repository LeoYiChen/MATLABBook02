%% prob7_vector_syntax.m
% Vector field visualisation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob7_vector_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create quiver plot
quiver(X, Y, U, V, 'AutoScale', 'on');
% Add streamlines
streamline(X, Y, U, V, startX, startY);
% Create stream slice
streamslice(X, Y, U, V, 'arrows');
