%% C020201Maths_Fundamental_code_115.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Power analysis for two-sample t-test
effectSize = 0.5;  % Cohen's d
alpha = 0.05;
power = 0.80;

% Approximate sample size calculation
zAlpha = norminv(1 - alpha/2);
zBeta = norminv(power);
nPerGroup = ceil(2 * ((zAlpha + zBeta) / effectSize)^2);

fprintf('Required sample size per group: %d\n', nPerGroup);
fprintf('Total sample size: %d\n', 2 * nPerGroup);

% Verify through simulation
numSimulations = 10000;
rejections = 0;

for sim = 1:numSimulations
    sample1 = randn(nPerGroup, 1);
    sample2 = effectSize + randn(nPerGroup, 1);
    [~, pVal] = ttest2(sample1, sample2);
    rejections = rejections + (pVal < alpha);
end

achievedPower = rejections / numSimulations;
fprintf('Achieved power (simulated): %.3f\n', achievedPower);
