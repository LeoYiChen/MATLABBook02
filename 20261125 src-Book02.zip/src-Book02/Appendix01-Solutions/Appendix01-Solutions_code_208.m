%% Appendix01-Solutions_code_208.m
% Physics-Informed Neural Network for 1D Diffusion
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import qmc

# ============================================================================
# PINN Architecture
# ============================================================================
class DiffusionPINN(nn.Module):
    """Physics-Informed Neural Network for 1D diffusion equation"""
    
    def __init__(self, layers):
        super(DiffusionPINN, self).__init__()
        self.activation = nn.Tanh()
        self.layers_list = nn.ModuleList()
        
        # Build network layers
        for i in range(len(layers) - 1):
            self.layers_list.append(nn.Linear(layers[i], layers[i+1]))
            
        # Xavier initialization for better convergence
        for layer in self.layers_list:
            nn.init.xavier_normal_(layer.weight)
            nn.init.zeros_(layer.bias)
    
    def forward(self, x, t):
        """Forward pass through network"""
        # Concatenate inputs
        inputs = torch.cat([x, t], dim=1)
        
        # Pass through hidden layers
        for i in range(len(self.layers_list) - 1):
            inputs = self.layers_list[i](inputs)
            inputs = self.activation(inputs)
        
        # Output layer (no activation)
        u = self.layers_list[-1](inputs)
        return u
    
    def pde_residual(self, x, t, D):
        """Compute PDE residual: du/dt - D * d2u/dx2"""
        x.requires_grad = True
        t.requires_grad = True
        
        u = self.forward(x, t)
        
        # First derivatives
        u_t = torch.autograd.grad(u, t, 
                                  grad_outputs=torch.ones_like(u),
                                  create_graph=True)[0]
        u_x = torch.autograd.grad(u, x,
                                  grad_outputs=torch.ones_like(u),
                                  create_graph=True)[0]
        
        # Second derivative
        u_xx = torch.autograd.grad(u_x, x,
                                   grad_outputs=torch.ones_like(u_x),
                                   create_graph=True)[0]
        
        # PDE residual
        residual = u_t - D * u_xx
        return residual


# ============================================================================
# Training Setup
# ============================================================================
# Physical parameters
D = 0.1          # Diffusion coefficient (m^2/s)
L = 1.0          # Domain length (m)
T_max = 2.0      # Final time (s)

# Network architecture
layers = [2, 20, 20, 20, 1]  # Input: (x,t), Output: u
model = DiffusionPINN(layers)

# Loss weights
lambda_IC = 10.0
lambda_BC = 10.0

# ============================================================================
# Generate Training Points
# ============================================================================
def generate_collocation_points(N_pde, N_ic, N_bc):
    """Generate training points using Latin Hypercube Sampling"""
    
    # Interior points (PDE)
    sampler = qmc.LatinHypercube(d=2)
    interior = sampler.random(n=N_pde)
    x_pde = torch.tensor(interior[:, 0:1] * L, dtype=torch.float32)
    t_pde = torch.tensor(interior[:, 1:2] * T_max, dtype=torch.float32)
    
    # Initial condition points (t=0)
    x_ic = torch.linspace(0, L, N_ic).reshape(-1, 1)
    t_ic = torch.zeros_like(x_ic)
    u_ic = torch.sin(np.pi * x_ic / L)  # True initial condition
    
    # Boundary condition points
    t_bc = torch.linspace(0, T_max, N_bc).reshape(-1, 1)
    x_bc_left = torch.zeros_like(t_bc)
    x_bc_right = torch.ones_like(t_bc) * L
    
    return (x_pde, t_pde), (x_ic, t_ic, u_ic), (x_bc_left, x_bc_right, t_bc)

# Generate points
N_pde, N_ic, N_bc = 2500, 50, 50
pde_points, ic_points, bc_points = generate_collocation_points(N_pde, N_ic, N_bc)

x_pde, t_pde = pde_points
x_ic, t_ic, u_ic = ic_points
x_bc_left, x_bc_right, t_bc = bc_points

# ============================================================================
# Loss Function
# ============================================================================
def compute_loss(model, x_pde, t_pde, x_ic, t_ic, u_ic, 
                 x_bc_left, x_bc_right, t_bc, D):
    """Compute composite PINN loss"""
    
    # PDE residual loss
    residual = model.pde_residual(x_pde, t_pde, D)
    loss_pde = torch.mean(residual ** 2)
    
    # Initial condition loss
    u_pred_ic = model(x_ic, t_ic)
    loss_ic = torch.mean((u_pred_ic - u_ic) ** 2)
    
    # Boundary condition loss
    u_pred_bc_left = model(x_bc_left, t_bc)
    u_pred_bc_right = model(x_bc_right, t_bc)
    loss_bc = torch.mean(u_pred_bc_left ** 2) + torch.mean(u_pred_bc_right ** 2)
    
    # Total loss
    total_loss = loss_pde + lambda_IC * loss_ic + lambda_BC * loss_bc
    
    return total_loss, loss_pde, loss_ic, loss_bc

# ============================================================================
# Training Loop
# ============================================================================
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

# Storage for loss history
loss_history = {'total': [], 'pde': [], 'ic': [], 'bc': []}

print("Starting ADAM optimization...")
for epoch in range(10000):
    optimizer.zero_grad()
    
    total_loss, loss_pde, loss_ic, loss_bc = compute_loss(
        model, x_pde, t_pde, x_ic, t_ic, u_ic,
        x_bc_left, x_bc_right, t_bc, D
    )
    
    total_loss.backward()
    optimizer.step()
    
    # Record losses
    loss_history['total'].append(total_loss.item())
    loss_history['pde'].append(loss_pde.item())
    loss_history['ic'].append(loss_ic.item())
    loss_history['bc'].append(loss_bc.item())
    
    if epoch % 1000 == 0:
        print(f"Epoch {epoch:5d} | Loss: {total_loss.item():.6e} | "
              f"PDE: {loss_pde.item():.6e} | IC: {loss_ic.item():.6e} | "
              f"BC: {loss_bc.item():.6e}")

# ============================================================================
# L-BFGS Refinement
# ============================================================================
print("\nSwitching to L-BFGS optimizer...")
optimizer_lbfgs = torch.optim.LBFGS(
    model.parameters(),
    lr=1.0,
    max_iter=20,
    history_size=50,
    line_search_fn='strong_wolfe'
)

def closure():
    optimizer_lbfgs.zero_grad()
    total_loss, _, _, _ = compute_loss(
        model, x_pde, t_pde, x_ic, t_ic, u_ic,
        x_bc_left, x_bc_right, t_bc, D
    )
    total_loss.backward()
    return total_loss

for epoch in range(250):  # L-BFGS iterations
    optimizer_lbfgs.step(closure)
    
    if epoch % 50 == 0:
        with torch.no_grad():
            total_loss, loss_pde, loss_ic, loss_bc = compute_loss(
                model, x_pde, t_pde, x_ic, t_ic, u_ic,
                x_bc_left, x_bc_right, t_bc, D
            )
        print(f"L-BFGS Iter {epoch:3d} | Loss: {total_loss.item():.6e}")

# ============================================================================
# Evaluation and Visualization
# ============================================================================
# Generate test grid
x_test = torch.linspace(0, L, 100).reshape(-1, 1)
t_test_values = [0.5, 1.0, 1.5]

# Analytical solution
def analytical_solution(x, t):
    return np.sin(np.pi * x / L) * np.exp(-np.pi**2 * D * t / L**2)

# Compute errors
model.eval()
with torch.no_grad():
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Plot 1: Snapshots at different times
    ax = axes[0, 0]
    for t_val in t_test_values:
        t_test = torch.ones_like(x_test) * t_val
        u_pred = model(x_test, t_test).numpy()
        u_exact = analytical_solution(x_test.numpy(), t_val)
        
        ax.plot(x_test.numpy(), u_exact, '-', 
                label=f't={t_val}s (Exact)', linewidth=2)
        ax.plot(x_test.numpy(), u_pred, 
                label=f't={t_val}s (PINN)', linewidth=2)
    
    ax.set_xlabel('Position x (m)', fontsize=12)
    ax.set_ylabel('Temperature u(x,t)', fontsize=12)
    ax.set_title('PINN vs Analytical Solution', fontsize=14)
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Plot 2: Spatiotemporal heatmap
    ax = axes[0, 1]
    x_grid = torch.linspace(0, L, 100)
    t_grid = torch.linspace(0, T_max, 100)
    X_mesh, T_mesh = torch.meshgrid(x_grid, t_grid, indexing='ij')
    
    XT_test = torch.cat([X_mesh.reshape(-1, 1), T_mesh.reshape(-1, 1)], dim=1)
    U_pred = model(XT_test[:, 0:1], XT_test[:, 1:2]).reshape(100, 100)
    
    c = ax.contourf(X_mesh.numpy(), T_mesh.numpy(), U_pred.numpy(), 
                    levels=20, cmap='hot')
    ax.set_xlabel('Position x (m)', fontsize=12)
    ax.set_ylabel('Time t (s)', fontsize=12)
    ax.set_title('Predicted Temperature Field u(x,t)', fontsize=14)
    plt.colorbar(c, ax=ax, label='Temperature')
    
    # Plot 3: Loss convergence
    ax = axes[1, 0]
    ax.semilogy(loss_history['total'], label='Total Loss', linewidth=2)
    ax.semilogy(loss_history['pde'], label='PDE Residual', alpha=0.7)
    ax.semilogy(loss_history['ic'], label='Initial Condition', alpha=0.7)
    ax.semilogy(loss_history['bc'], label='Boundary Condition', alpha=0.7)
    ax.set_xlabel('Iteration', fontsize=12)
    ax.set_ylabel('Loss', fontsize=12)
    ax.set_title('Training Loss History', fontsize=14)
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # Plot 4: Error distribution
    ax = axes[1, 1]
    t_val = 1.0
    t_test = torch.ones_like(x_test) * t_val
    u_pred = model(x_test, t_test).numpy()
    u_exact = analytical_solution(x_test.numpy(), t_val)
    error = np.abs(u_pred.flatten() - u_exact.flatten())
    
    ax.plot(x_test.numpy(), error, 'r-', linewidth=2)
    ax.set_xlabel('Position x (m)', fontsize=12)
    ax.set_ylabel('Absolute Error', fontsize=12)
    ax.set_title(f'Pointwise Error at t={t_val}s', fontsize=14)
    ax.grid(True, alpha=0.3)
    
    # Compute L2 error
    l2_error = np.sqrt(np.mean(error**2))
    l2_norm = np.sqrt(np.mean(u_exact**2))
    relative_l2 = l2_error / l2_norm
    
    ax.text(0.5, 0.95, f'Relative LError = {relative_l2:.4e}',
            transform=ax.transAxes, fontsize=12,
            verticalalignment='top', bbox=dict(boxstyle='round', 
            facecolor='wheat', alpha=0.5))
    
    plt.tight_layout()
    plt.savefig('pinn_diffusion_results.png', dpi=300, bbox_inches='tight')
    plt.show()

print("\n" + "="*70)
print("FINAL RESULTS")
print("="*70)
print(f"Relative L Error: {relative_l2:.6e}")
print(f"Final Total Loss: {loss_history['total'][-1]:.6e}")
print(f"Training completed successfully!")
