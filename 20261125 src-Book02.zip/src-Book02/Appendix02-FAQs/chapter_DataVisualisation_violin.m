%% chapter_DataVisualisation_violin.m
% Violin Plot Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_violin
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createViolinPlot(data, groups)
% Input validation
if ~isnumeric(data) || ~iscell(groups)
error('Invalid input types');
end

figure('Position', [100 100 800 600]);
hold on;

for i = 1:size(data,2)
    % Kernel density estimation
    [f,xi] = ksdensity(data(:,i));
    
    % Scale density
    f = f/max(f)*0.4;
    
    % Plot violin shape
    fill([f -fliplr(f)]+i, [xi fliplr(xi)], ...
         'blue', 'FaceAlpha', 0.3);
    
    % Add box plot elements
    quants = quantile(data(:,i), [0.25 0.5 0.75]);
    line([i-0.1 i+0.1], [quants(2) quants(2)], ...
         'Color', 'k', 'LineWidth', 2);
end

xlabel('Groups');
ylabel('Values');
title('Violin Plot with Quantile Markers');
set(gca, 'XTick', 1:length(groups), ...
    'XTickLabel', groups);
grid on;
end

% Export figure in multiple formats
exportFigure(gca, 'Violinplot_figures');

