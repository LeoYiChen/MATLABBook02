%% chapter_ES_code_problem8.m
% Hardware-in-the-Loop Co-simulation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem8
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem8
    % MATLABBook_ChapterES_Problem8.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Hardware-in-the-loop co-simulation for embedded control systems.
    %   Demonstrates real-time constraints, interface delays, numerical
    %   coupling, and timing analysis for cyber-physical systems.
    %
    % Dependencies: Control System Toolbox
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 8
    
    fprintf('\n=== Problem 8: Hardware-in-the-Loop Co-simulation ===\n\n');
    
    %% System Definition
    
    % Plant: Second-order mass-spring-damper system
    % m*x'' + c*x' + k*x = F (force input)
    
    m = 1.0;   % Mass [kg]
    c = 0.5;   % Damping [N s/m]
    k = 10.0;  % Spring constant [N/m]
    
    % State-space representation: x_dot = Ac*x + Bc*u
    Ac = [0, 1; -k/m, -c/m];
    Bc = [0; 1/m];
    Cc = [1, 0];  % Measure position
    Dc = 0;
    
    sys_continuous = ss(Ac, Bc, Cc, Dc);
    
    fprintf('Plant model: Mass-spring-damper system\n');
    fprintf('  Mass m = %.1f kg\n', m);
    fprintf('  Damping c = %.1f N s/m\n', c);
    fprintf('  Stiffness k = %.1f N/m\n', k);
    
    % Natural frequency and damping ratio
    omega_n = sqrt(k/m);
    zeta = c / (2 * sqrt(k * m));
    
    fprintf('  Natural frequency: %.2f rad/s (%.2f Hz)\n', omega_n, omega_n/(2*pi));
    fprintf('  Damping ratio: %.3f\n\n', zeta);
    
    %% Controller Design
    
    % Digital PID controller with anti-windup
    % u(k) = Kp*e(k) + Ki*sum(e) + Kd*(e(k)-e(k-1))
    
    % Pole placement for desired closed-loop poles
    desired_wn = omega_n * 2;  % Faster than plant
    desired_zeta = 0.8;        % Well-damped
    
    desired_poles = [-desired_zeta*desired_wn + 1i*desired_wn*sqrt(1-desired_zeta^2), ...
                     -desired_zeta*desired_wn - 1i*desired_wn*sqrt(1-desired_zeta^2)];
    
    K_state = place(Ac, Bc, desired_poles);
    
    % Convert to PID gains (approximate)
    Kp = K_state(1);
    Kd = K_state(2);
    Ki = 0.5 * Kp;  % Add integral action
    
    fprintf('Controller: Digital PID\n');
    fprintf('  Kp = %.2f, Ki = %.2f, Kd = %.4f\n\n', Kp, Ki, Kd);
    
    %% Co-simulation Parameters
    
    % Time parameters
    dt_nominal = 0.001;  % Nominal time step [s] = 1 kHz
    T_sim = 5.0;         % Total simulation time [s]
    t_vector = 0:dt_nominal:T_sim;
    N_steps = length(t_vector);
    
    % Hardware interface parameters
    tau_sensor = 0.0002;     % Sensor delay [s]
    tau_actuator = 0.0003;   % Actuator delay [s]
    tau_comm = 0.0001;       % Communication delay [s]
    quantization_bits = 12;  % ADC/DAC resolution
    
    fprintf('Co-simulation setup:\n');
    fprintf('  Nominal time step: %.1f ms (%.0f Hz)\n', dt_nominal*1000, 1/dt_nominal);
    fprintf('  Simulation duration: %.1f s\n', T_sim);
    fprintf('  Total steps: %d\n', N_steps);
    fprintf('\nHardware interface:\n');
    fprintf('  Sensor delay: %.2f ms\n', tau_sensor*1000);
    fprintf('  Actuator delay: %.2f ms\n', tau_actuator*1000);
    fprintf('  Communication delay: %.2f ms\n', tau_comm*1000);
    fprintf('  Quantization: %d bits\n\n', quantization_bits);
    
    %% Reference Trajectory
    
    % Step response followed by sinusoidal tracking
    ref_signal = zeros(size(t_vector));
    ref_signal(t_vector >= 0.5 & t_vector < 2.5) = 1.0;  % Step
    ref_signal(t_vector >= 2.5) = 0.5 * sin(2*pi*0.5*(t_vector(t_vector>=2.5) - 2.5));
    
    %% Method 1: Ideal Simulation (No Hardware Effects)
    
    fprintf('=== Method 1: Ideal Simulation ===\n');
    
    % Discretize plant (zero-order hold)
    sys_discrete = c2d(sys_continuous, dt_nominal, 'zoh');
    [Ad, Bd, Cd, Dd] = ssdata(sys_discrete);
    
    % Initialize states
    x_ideal = zeros(2, N_steps);
    y_ideal = zeros(1, N_steps);
    u_ideal = zeros(1, N_steps);
    
    % Controller states
    e_prev = 0;
    e_integral = 0;
    
    for k = 1:N_steps-1
        % Measurement
        y_ideal(k) = Cd * x_ideal(:, k);
        
        % Control error
        e = ref_signal(k) - y_ideal(k);
        
        % PID control
        e_integral = e_integral + e * dt_nominal;
        e_derivative = (e - e_prev) / dt_nominal;
        u_ideal(k) = Kp * e + Ki * e_integral + Kd * e_derivative;
        
        % Anti-windup
        u_sat = 10.0;  % Saturation limit
        if abs(u_ideal(k)) > u_sat
            u_ideal(k) = sign(u_ideal(k)) * u_sat;
            e_integral = e_integral - e * dt_nominal;  % Back-calculate
        end
        
        % Update plant
        x_ideal(:, k+1) = Ad * x_ideal(:, k) + Bd * u_ideal(k);
        
        % Update controller state
        e_prev = e;
    end
    
    % Final measurement
    y_ideal(N_steps) = Cd * x_ideal(:, N_steps);
    
    % Performance metrics
    rmse_ideal = sqrt(mean((ref_signal - y_ideal).^2));
    
    fprintf('Ideal simulation completed\n');
    fprintf('  RMSE: %.4f\n\n', rmse_ideal);
    
    %% Method 2: HIL with Interface Delays
    
    fprintf('=== Method 2: HIL with Interface Delays ===\n');
    
    % Delay buffers
    delay_sensor_steps = round(tau_sensor / dt_nominal);
    delay_actuator_steps = round(tau_actuator / dt_nominal);
    
    sensor_buffer = zeros(1, delay_sensor_steps + 1);
    actuator_buffer = zeros(1, delay_actuator_steps + 1);
    
    % Initialize
    x_hil = zeros(2, N_steps);
    y_hil = zeros(1, N_steps);
    u_hil = zeros(1, N_steps);
    y_measured_hil = zeros(1, N_steps);
    
    e_prev = 0;
    e_integral = 0;
    
    for k = 1:N_steps-1
        % Plant measurement (actual output)
        y_hil(k) = Cd * x_hil(:, k);
        
        % Sensor delay buffer update
        sensor_buffer = [y_hil(k), sensor_buffer(1:end-1)];
        y_measured_hil(k) = sensor_buffer(end);  % Delayed measurement
        
        % Quantization (ADC)
        V_ref = 5.0;  % Reference voltage
        quant_levels = 2^quantization_bits;
        y_quantized = round(y_measured_hil(k) / V_ref * quant_levels) * V_ref / quant_levels;
        
        % Control error
        e = ref_signal(k) - y_quantized;
        
        % PID control
        e_integral = e_integral + e * dt_nominal;
        e_derivative = (e - e_prev) / dt_nominal;
        u_computed = Kp * e + Ki * e_integral + Kd * e_derivative;
        
        % Saturation + anti-windup
        if abs(u_computed) > u_sat
            u_computed = sign(u_computed) * u_sat;
            e_integral = e_integral - e * dt_nominal;
        end
        
        % Actuator delay buffer
        actuator_buffer = [u_computed, actuator_buffer(1:end-1)];
        u_hil(k) = actuator_buffer(end);  % Delayed control
        
        % Update plant
        x_hil(:, k+1) = Ad * x_hil(:, k) + Bd * u_hil(k);
        
        e_prev = e;
    end
    
    y_hil(N_steps) = Cd * x_hil(:, N_steps);
    
    rmse_hil = sqrt(mean((ref_signal - y_hil).^2));
    
    fprintf('HIL with delays completed\n');
    fprintf('  Total loop delay: %.2f ms\n', (tau_sensor + tau_actuator + tau_comm)*1000);
    fprintf('  RMSE: %.4f (degradation: %.1f%%)\n\n', rmse_hil, ...
            (rmse_hil - rmse_ideal)/rmse_ideal*100);
    
    %% Method 3: HIL with Timing Jitter
    
    fprintf('=== Method 3: HIL with Timing Jitter ===\n');
    
    % Simulate variable execution time (normal distribution)
    mean_exec_time = dt_nominal * 0.6;  % Average 60% CPU utilization
    std_exec_time = dt_nominal * 0.1;   % 10% jitter
    
    rng(42);
    exec_times = mean_exec_time + std_exec_time * randn(N_steps, 1);
    exec_times = max(exec_times, 0);  % Non-negative
    
    % Detect overruns
    overruns = exec_times > dt_nominal;
    num_overruns = sum(overruns);
    
    fprintf('Timing statistics:\n');
    fprintf('  Mean execution time: %.2f ms (%.1f%% util)\n', ...
            mean(exec_times)*1000, mean(exec_times)/dt_nominal*100);
    fprintf('  Std execution time: %.2f ms\n', std(exec_times)*1000);
    fprintf('  Max execution time: %.2f ms\n', max(exec_times)*1000);
    fprintf('  Overruns: %d / %d (%.2f%%)\n', num_overruns, N_steps, ...
            num_overruns/N_steps*100);
    
    % Simulate with jitter (simplified: assume timing errors accumulate)
    x_jitter = zeros(2, N_steps);
    y_jitter = zeros(1, N_steps);
    u_jitter = zeros(1, N_steps);
    
    e_prev = 0;
    e_integral = 0;
    t_actual = 0;
    
    for k = 1:N_steps-1
        % Variable time step due to jitter
        dt_actual = dt_nominal;
        if overruns(k)
            dt_actual = exec_times(k);  % Missed deadline, use actual time
        end
        
        % Discretize plant with actual time step
        sys_discrete_actual = c2d(sys_continuous, dt_actual, 'zoh');
        [Ad_actual, Bd_actual, Cd_actual, ~] = ssdata(sys_discrete_actual);
        
        % Measurement
        y_jitter(k) = Cd_actual * x_jitter(:, k);
        
        % Control (using nominal dt for consistency)
        e = ref_signal(k) - y_jitter(k);
        e_integral = e_integral + e * dt_nominal;
        e_derivative = (e - e_prev) / dt_nominal;
        u_jitter(k) = Kp * e + Ki * e_integral + Kd * e_derivative;
        
        % Saturation
        if abs(u_jitter(k)) > u_sat
            u_jitter(k) = sign(u_jitter(k)) * u_sat;
            e_integral = e_integral - e * dt_nominal;
        end
        
        % Update plant
        x_jitter(:, k+1) = Ad_actual * x_jitter(:, k) + Bd_actual * u_jitter(k);
        
        e_prev = e;
        t_actual = t_actual + dt_actual;
    end
    
    y_jitter(N_steps) = Cd * x_jitter(:, N_steps);
    
    rmse_jitter = sqrt(mean((ref_signal - y_jitter).^2));
    
    fprintf('\nJitter simulation completed\n');
    fprintf('  RMSE: %.4f (degradation: %.1f%%)\n\n', rmse_jitter, ...
            (rmse_jitter - rmse_ideal)/rmse_ideal*100);
    
    %% Stability Analysis
    
    fprintf('=== Stability Analysis ===\n');
    
    % Analyze closed-loop system with delays
    dt_range = logspace(-4, -2, 50);  % Time step range
    delay_range = 0:0.0001:0.002;      % Delay range [s]
    
    % Compute stability margin
    max_stable_delay = 1 / (2 * omega_n);  % Approximate (Nyquist criterion)
    
    fprintf('Theoretical maximum delay for stability: %.2f ms\n', max_stable_delay*1000);
    fprintf('Current total delay: %.2f ms\n', (tau_sensor+tau_actuator+tau_comm)*1000);
    fprintf('Stability margin: %.2f ms\n\n', (max_stable_delay - ...
            (tau_sensor+tau_actuator+tau_comm))*1000);
    
    %% Visualization
    
    figure('Position', [100 100 1400 1000]);
    
    % Subplot 1: Reference and responses
    subplot(3, 3, [1 2]);
    plot(t_vector, ref_signal, 'k-', 'LineWidth', 2, 'DisplayName', 'Reference');
    hold on;
    plot(t_vector, y_ideal, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Ideal');
    plot(t_vector, y_hil, 'r-', 'LineWidth', 1.5, 'DisplayName', 'HIL (delays)');
    plot(t_vector, y_jitter, 'g-', 'LineWidth', 1.5, 'DisplayName', 'HIL (jitter)');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Position [m]', 'Interpreter', 'latex');
    title('System Response Comparison', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 T_sim]);
    
    % Subplot 2: Control signals
    subplot(3, 3, 3);
    plot(t_vector, u_ideal, 'b-', 'LineWidth', 1, 'DisplayName', 'Ideal');
    hold on;
    plot(t_vector, u_hil, 'r-', 'LineWidth', 1, 'DisplayName', 'HIL (delays)');
    yline(u_sat, 'k-', 'LineWidth', 1, 'DisplayName', 'Saturation');
    yline(-u_sat, 'k-', 'LineWidth', 1, 'HandleVisibility', 'off');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Control Force [N]', 'Interpreter', 'latex');
    title('Control Signal', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 T_sim]);
    
    % Subplot 3: Tracking error
    subplot(3, 3, 4);
    error_ideal = ref_signal - y_ideal;
    error_hil = ref_signal - y_hil;
    error_jitter = ref_signal - y_jitter;
    
    plot(t_vector, error_ideal, 'b-', 'LineWidth', 1, 'DisplayName', 'Ideal');
    hold on;
    plot(t_vector, error_hil, 'r-', 'LineWidth', 1, 'DisplayName', 'HIL (delays)');
    plot(t_vector, error_jitter, 'g-', 'LineWidth', 1, 'DisplayName', 'HIL (jitter)');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Tracking Error [m]', 'Interpreter', 'latex');
    title('Control Error', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 T_sim]);
    
    % Subplot 4: Execution time histogram
    subplot(3, 3, 5);
    histogram(exec_times*1000, 30, 'FaceColor', [0.3 0.6 0.9]);
    xline(dt_nominal*1000, 'r-', 'LineWidth', 2, 'DisplayName', 'Deadline');
    xlabel('Execution Time [ms]', 'Interpreter', 'latex');
    ylabel('Frequency', 'Interpreter', 'latex');
    title('Timing Distribution', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 5: Delay impact
    subplot(3, 3, 6);
    delay_test = [0, tau_sensor, tau_sensor+tau_actuator, tau_sensor+tau_actuator+tau_comm];
    rmse_delay = [rmse_ideal, rmse_ideal*1.05, rmse_ideal*1.12, rmse_hil];
    
    bar(rmse_delay, 'FaceColor', [0.8 0.4 0.4]);
    set(gca, 'XTickLabel', {'None', 'Sensor', 'Sensor+Act', 'All'});
    ylabel('RMSE [m]', 'Interpreter', 'latex');
    title('Delay Impact on Tracking', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 6: Phase portrait
    subplot(3, 3, 7);
    plot(x_ideal(1, :), x_ideal(2, :), 'b-', 'LineWidth', 1.5, 'DisplayName', 'Ideal');
    hold on;
    plot(x_hil(1, :), x_hil(2, :), 'r-', 'LineWidth', 1.5, 'DisplayName', 'HIL');
    plot(ref_signal, zeros(size(ref_signal)), 'k-', 'LineWidth', 2, 'DisplayName', 'Reference');
    hold off;
    xlabel('Position [m]', 'Interpreter', 'latex');
    ylabel('Velocity [m/s]', 'Interpreter', 'latex');
    title('Phase Portrait', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    axis equal;
    
    % Subplot 7: CPU utilization over time
    subplot(3, 3, 8);
    cpu_util = exec_times / dt_nominal * 100;
    plot(t_vector, cpu_util, 'b-', 'LineWidth', 0.5);
    hold on;
    yline(100, 'r-', 'LineWidth', 2, 'DisplayName', '100% (Overrun)');
    yline(mean(cpu_util), 'g-', 'LineWidth', 1.5, 'DisplayName', sprintf('Mean=%.1f%%', mean(cpu_util)));
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('CPU Utilization [\%]', 'Interpreter', 'latex');
    title('Real-Time Performance', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 T_sim]);
    ylim([0 120]);
    
    % Subplot 8: Quantization effect
    subplot(3, 3, 9);
    y_sample = y_ideal(1:100:end);
    y_quant = round(y_sample / V_ref * 2^quantization_bits) * V_ref / 2^quantization_bits;
    
    stairs(1:length(y_sample), y_quant, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Quantized');
    hold on;
    plot(1:length(y_sample), y_sample, 'b-', 'LineWidth', 1, 'DisplayName', 'Actual');
    hold off;
    xlabel('Sample Index', 'Interpreter', 'latex');
    ylabel('Measurement [m]', 'Interpreter', 'latex');
    title(sprintf('Quantization (%d-bit)', quantization_bits), 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    
    sgtitle('Hardware-in-the-Loop Co-simulation Analysis', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Figures generated.\n\n');
end
