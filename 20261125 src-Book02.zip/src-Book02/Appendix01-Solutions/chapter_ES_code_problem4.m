%% chapter_ES_code_problem4.m
% Monte Carlo Integration for Multi-Dimensional Functions
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem4
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem4
    % MATLABBook_ChapterES_Problem4.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Monte Carlo integration with variance reduction techniques.
    %   Compares standard MC, importance sampling, stratified sampling,
    %   and quasi-Monte Carlo methods for multi-dimensional integrals.
    %
    % Dependencies: Statistics and Machine Learning Toolbox
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 4
    
    fprintf('\n=== Problem 4: Monte Carlo Integration ===\n\n');
    
    %% Test Function 1: Gaussian Integral (d-dimensional)
    
    d = 5;  % Dimensionality
    mu = zeros(d, 1);
    Sigma = eye(d);
    
    % Analytical solution (product of 1D Gaussians over [-3, 3])
    I_exact_1 = (erf(3/sqrt(2)))^d;
    
    % Domain
    lower_1 = -3 * ones(d, 1);
    upper_1 = 3 * ones(d, 1);
    volume_1 = prod(upper_1 - lower_1);
    
    fprintf('=== Test Function 1: %dD Gaussian ===\n', d);
    fprintf('f(x) = (2 )^{-d/2} exp(-||x||^2/2)\n');
    fprintf('Domain: [%.0f, %.0f]^%d\n', lower_1(1), upper_1(1), d);
    fprintf('Exact integral: %.6f\n\n', I_exact_1);
    
    % Integrand function
    f1 = @(X) mvnpdf(X', mu', Sigma)';
    
    %% Standard Monte Carlo - Function 1
    
    fprintf('-- Method 1: Standard Monte Carlo --\n');
    
    N_samples = [1e2, 1e3, 1e4, 1e5, 1e6];
    errors_std = zeros(size(N_samples));
    std_errors = zeros(size(N_samples));
    times_std = zeros(size(N_samples));
    
    for i = 1:length(N_samples)
        N = N_samples(i);
        tic;
        [I_est, std_err] = standardMC(f1, lower_1, upper_1, N);
        times_std(i) = toc;
        
        errors_std(i) = abs(I_est - I_exact_1);
        std_errors(i) = std_err;
        
        fprintf('N=%8d: I=%.6f   %.6f, Error=%.2e, Time=%.3fs\n', ...
                N, I_est, std_err, errors_std(i), times_std(i));
    end
    fprintf('\n');
    
    %% Importance Sampling - Function 1
    
    fprintf('-- Method 2: Importance Sampling --\n');
    
    errors_is = zeros(size(N_samples));
    std_errors_is = zeros(size(N_samples));
    times_is = zeros(size(N_samples));
    
    % Importance distribution: use same Gaussian (optimal for this problem)
    for i = 1:length(N_samples)
        N = N_samples(i);
        tic;
        [I_est, std_err] = importanceSamplingMC(f1, mu, Sigma, lower_1, upper_1, N);
        times_is(i) = toc;
        
        errors_is(i) = abs(I_est - I_exact_1);
        std_errors_is(i) = std_err;
        
        fprintf('N=%8d: I=%.6f   %.6f, Error=%.2e, Time=%.3fs\n', ...
                N, I_est, std_err, errors_is(i), times_is(i));
    end
    fprintf('Variance reduction vs standard: %.1fx\n\n', ...
            mean(std_errors ./ std_errors_is));
    
    %% Stratified Sampling - Function 1
    
    fprintf('-- Method 3: Stratified Sampling --\n');
    
    errors_strat = zeros(size(N_samples));
    std_errors_strat = zeros(size(N_samples));
    times_strat = zeros(size(N_samples));
    
    for i = 1:length(N_samples)
        N = N_samples(i);
        tic;
        [I_est, std_err] = stratifiedMC(f1, lower_1, upper_1, N);
        times_strat(i) = toc;
        
        errors_strat(i) = abs(I_est - I_exact_1);
        std_errors_strat(i) = std_err;
        
        fprintf('N=%8d: I=%.6f   %.6f, Error=%.2e, Time=%.3fs\n', ...
                N, I_est, std_err, errors_strat(i), times_strat(i));
    end
    fprintf('Variance reduction vs standard: %.1fx\n\n', ...
            mean(std_errors ./ std_errors_strat));
    
    %% Quasi-Monte Carlo (Sobol) - Function 1
    
    fprintf('-- Method 4: Quasi-Monte Carlo (Sobol) --\n');
    
    errors_qmc = zeros(size(N_samples));
    times_qmc = zeros(size(N_samples));
    
    for i = 1:length(N_samples)
        N = N_samples(i);
        tic;
        I_est = quasiMC(f1, lower_1, upper_1, N);
        times_qmc(i) = toc;
        
        errors_qmc(i) = abs(I_est - I_exact_1);
        
        fprintf('N=%8d: I=%.6f, Error=%.2e, Time=%.3fs\n', ...
                N, I_est, errors_qmc(i), times_qmc(i));
    end
    fprintf('\n');
    
    %% Test Function 2: Sphere Volume (high-dimensional)
    
    fprintf('=== Test Function 2: Unit Sphere Volume ===\n');
    
    d2 = 10;  % Higher dimension
    r = 1.0;
    
    % Analytical solution
    I_exact_2 = pi^(d2/2) / gamma(d2/2 + 1) * r^d2;
    
    fprintf('Dimension: %d\n', d2);
    fprintf('Radius: %.1f\n', r);
    fprintf('Exact volume: %.6f\n\n', I_exact_2);
    
    % Domain: hypercube [-r, r]^d
    lower_2 = -r * ones(d2, 1);
    upper_2 = r * ones(d2, 1);
    
    % Indicator function: 1 if inside sphere, 0 otherwise
    f2 = @(X) double(sum(X.^2, 1) <= r^2);
    
    N_test = 1e6;
    
    % Standard MC
    fprintf('Standard MC (N=%d):\n', N_test);
    [I_std, err_std] = standardMC(f2, lower_2, upper_2, N_test);
    fprintf('  Volume estimate: %.6f   %.6f\n', I_std, err_std);
    fprintf('  Error: %.2e (%.2f%%)\n\n', abs(I_std - I_exact_2), ...
            abs(I_std - I_exact_2)/I_exact_2*100);
    
    % Quasi-MC
    fprintf('Quasi-MC (N=%d):\n', N_test);
    I_qmc2 = quasiMC(f2, lower_2, upper_2, N_test);
    fprintf('  Volume estimate: %.6f\n', I_qmc2);
    fprintf('  Error: %.2e (%.2f%%)\n\n', abs(I_qmc2 - I_exact_2), ...
            abs(I_qmc2 - I_exact_2)/I_exact_2*100);
    
    %% Convergence Analysis
    
    fprintf('=== Convergence Rate Analysis ===\n');
    
    % Fit power law: error ~ N^alpha
    log_N = log10(N_samples);
    
    % Standard MC
    p_std = polyfit(log_N, log10(errors_std), 1);
    fprintf('Standard MC:      Error ~ N^%.3f (theory: -0.5)\n', p_std(1));
    
    % Importance Sampling
    p_is = polyfit(log_N, log10(errors_is), 1);
    fprintf('Importance Samp:  Error ~ N^%.3f\n', p_is(1));
    
    % Stratified
    p_strat = polyfit(log_N, log10(errors_strat), 1);
    fprintf('Stratified:       Error ~ N^%.3f\n', p_strat(1));
    
    % Quasi-MC
    p_qmc = polyfit(log_N, log10(errors_qmc), 1);
    fprintf('Quasi-MC:         Error ~ N^%.3f (theory: ~-1.0)\n\n', p_qmc(1));
    
    %% Dimensionality Scaling Test
    
    fprintf('=== Dimensionality Scaling Test ===\n');
    fprintf('Testing standard MC convergence across dimensions\n\n');
    
    dimensions = [2, 5, 10, 20];
    N_fixed = 1e5;
    
    fprintf('%-6s %12s %12s %12s\n', 'Dim', 'Estimate', 'Exact', 'Rel Error');
    fprintf('%s\n', repmat('-', 1, 45));
    
    for d_test = dimensions
        % Gaussian integral
        I_exact_d = (erf(3/sqrt(2)))^d_test;
        lower_d = -3 * ones(d_test, 1);
        upper_d = 3 * ones(d_test, 1);
        
        mu_d = zeros(d_test, 1);
        Sigma_d = eye(d_test);
        f_d = @(X) mvnpdf(X', mu_d', Sigma_d)';
        
        I_est_d = standardMC(f_d, lower_d, upper_d, N_fixed);
        rel_err = abs(I_est_d - I_exact_d) / I_exact_d;
        
        fprintf('%-6d %12.6f %12.6f %11.2e\n', d_test, I_est_d, I_exact_d, rel_err);
    end
    fprintf('\n');
    
    %% Visualization
    
    figure('Position', [100 100 1400 900]);
    
    % Subplot 1: Convergence plot (log-log)
    subplot(2, 3, 1);
    loglog(N_samples, errors_std, 'o-', 'LineWidth', 1.5, 'DisplayName', 'Standard MC');
    hold on;
    loglog(N_samples, errors_is, 's-', 'LineWidth', 1.5, 'DisplayName', 'Importance Samp');
    loglog(N_samples, errors_strat, 'd-', 'LineWidth', 1.5, 'DisplayName', 'Stratified');
    loglog(N_samples, errors_qmc, '^-', 'LineWidth', 1.5, 'DisplayName', 'Quasi-MC');
    loglog(N_samples, N_samples.^(-0.5) * errors_std(1) * N_samples(1)^0.5, ...
           'k-', 'LineWidth', 1, 'DisplayName', '$N^{-1/2}$ ref');
    hold off;
    xlabel('Number of Samples $N$', 'Interpreter', 'latex');
    ylabel('Absolute Error', 'Interpreter', 'latex');
    title('Convergence Comparison', 'Interpreter', 'latex');
    legend('Location', 'southwest', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 2: Standard error bars
    subplot(2, 3, 2);
    errorbar(log10(N_samples), errors_std, std_errors, 'o-', 'LineWidth', 1.5);
    xlabel('$\log_{10}(N)$', 'Interpreter', 'latex');
    ylabel('Error $\pm$ Std Error', 'Interpreter', 'latex');
    title('Standard MC with Confidence Intervals', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 3: Variance reduction factor
    subplot(2, 3, 3);
    vrf_is = std_errors.^2 ./ std_errors_is.^2;
    vrf_strat = std_errors.^2 ./ std_errors_strat.^2;
    
    semilogx(N_samples, vrf_is, 's-', 'LineWidth', 1.5, 'DisplayName', 'IS vs Standard');
    hold on;
    semilogx(N_samples, vrf_strat, 'd-', 'LineWidth', 1.5, 'DisplayName', 'Strat vs Standard');
    hold off;
    xlabel('Number of Samples $N$', 'Interpreter', 'latex');
    ylabel('Variance Reduction Factor', 'Interpreter', 'latex');
    title('Variance Reduction Effectiveness', 'Interpreter', 'latex');
    legend('Location', 'best', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 4: Computational efficiency
    subplot(2, 3, 4);
    efficiency_std = 1 ./ (errors_std.^2 .* times_std);
    efficiency_is = 1 ./ (errors_is.^2 .* times_is);
    efficiency_strat = 1 ./ (errors_strat.^2 .* times_strat);
    efficiency_qmc = 1 ./ (errors_qmc.^2 .* times_qmc);
    
    semilogx(N_samples, efficiency_std, 'o-', 'LineWidth', 1.5, 'DisplayName', 'Standard');
    hold on;
    semilogx(N_samples, efficiency_is, 's-', 'LineWidth', 1.5, 'DisplayName', 'Importance');
    semilogx(N_samples, efficiency_strat, 'd-', 'LineWidth', 1.5, 'DisplayName', 'Stratified');
    semilogx(N_samples, efficiency_qmc, '^-', 'LineWidth', 1.5, 'DisplayName', 'Quasi-MC');
    hold off;
    xlabel('Number of Samples $N$', 'Interpreter', 'latex');
    ylabel('Efficiency $1/(error^2 \times time)$', 'Interpreter', 'latex');
    title('Computational Efficiency', 'Interpreter', 'latex');
    legend('Location', 'best', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 5: 2D sample distribution comparison
    subplot(2, 3, 5);
    d_vis = 2;
    N_vis = 500;
    
    % Standard MC samples
    X_std = bsxfun(@plus, lower_1(1:d_vis), ...
                   bsxfun(@times, upper_1(1:d_vis) - lower_1(1:d_vis), ...
                   rand(d_vis, N_vis)));
    
    plot(X_std(1,:), X_std(2,:), 'b.', 'MarkerSize', 4, 'DisplayName', 'Pseudo-random');
    hold on;
    
    % Quasi-MC samples (Sobol)
    p = sobolset(d_vis);
    p = scramble(p, 'MatousekAffineOwen');
    X_qmc = net(p, N_vis)';
    X_qmc = bsxfun(@plus, lower_1(1:d_vis), ...
                   bsxfun(@times, upper_1(1:d_vis) - lower_1(1:d_vis), X_qmc));
    
    plot(X_qmc(1,:), X_qmc(2,:), 'r.', 'MarkerSize', 4, 'DisplayName', 'Sobol');
    hold off;
    
    xlabel('$x_1$', 'Interpreter', 'latex');
    ylabel('$x_2$', 'Interpreter', 'latex');
    title('Sample Distribution (2D projection)', 'Interpreter', 'latex');
    legend('Location', 'best', 'Interpreter', 'latex');
    axis equal;
    grid on;
    
    % Subplot 6: Dimension scaling
    subplot(2, 3, 6);
    dim_test_range = 2:2:20;
    N_dim_test = 1e5;
    rel_errors_dim = zeros(size(dim_test_range));
    
    for i = 1:length(dim_test_range)
        d_t = dim_test_range(i);
        I_exact_t = (erf(3/sqrt(2)))^d_t;
        lower_t = -3 * ones(d_t, 1);
        upper_t = 3 * ones(d_t, 1);
        
        mu_t = zeros(d_t, 1);
        Sigma_t = eye(d_t);
        f_t = @(X) mvnpdf(X', mu_t', Sigma_t)';
        
        I_est_t = standardMC(f_t, lower_t, upper_t, N_dim_test);
        rel_errors_dim(i) = abs(I_est_t - I_exact_t) / I_exact_t;
    end
    
    semilogy(dim_test_range, rel_errors_dim, 'o-', 'LineWidth', 1.5);
    xlabel('Dimension $d$', 'Interpreter', 'latex');
    ylabel('Relative Error', 'Interpreter', 'latex');
    title('MC Error vs Dimension (Fixed $N$)', 'Interpreter', 'latex');
    grid on;
    
    sgtitle('Monte Carlo Integration Analysis', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Figures generated.\n\n');
end

%% Helper Functions

function [I_est, std_err] = standardMC(f, lower, upper, N)
    % Standard Monte Carlo integration with uniform sampling
    
    d = length(lower);
    volume = prod(upper - lower);
    
    % Generate uniform random samples
    X = bsxfun(@plus, lower, bsxfun(@times, upper - lower, rand(d, N)));
    
    % Evaluate function
    f_vals = f(X);
    
    % Monte Carlo estimate
    I_est = volume * mean(f_vals);
    
    % Standard error
    std_err = volume * std(f_vals) / sqrt(N);
end

function [I_est, std_err] = importanceSamplingMC(f, mu, Sigma, lower, upper, N)
    % Importance sampling using Gaussian proposal
    
    d = length(mu);
    
    % Sample from proposal distribution (truncated Gaussian)
    X = mvnrnd(mu', Sigma, N)';
    
    % Keep only samples within domain
    valid = all(bsxfun(@ge, X, lower) & bsxfun(@le, X, upper), 1);
    X = X(:, valid);
    N_valid = size(X, 2);
    
    if N_valid < N * 0.5
        warning('Low acceptance rate (%.1f%%). Consider adjusting proposal.', ...
                N_valid/N*100);
    end
    
    % Proposal density
    p_vals = mvnpdf(X', mu', Sigma)';
    
    % Evaluate function
    f_vals = f(X);
    
    % Importance sampling estimator
    weights = f_vals ./ p_vals;
    I_est = mean(weights);
    
    % Standard error
    std_err = std(weights) / sqrt(N_valid);
end

function [I_est, std_err] = stratifiedMC(f, lower, upper, N)
    % Stratified sampling (Latin hypercube)
    
    d = length(lower);
    
    % Number of strata per dimension
    m = ceil(N^(1/d));
    N_actual = m^d;
    
    % Generate stratified samples
    X = zeros(d, N_actual);
    idx = 0;
    
    % Create grid of strata
    edges = cell(d, 1);
    for j = 1:d
        edges{j} = linspace(lower(j), upper(j), m+1);
    end
    
    % Sample one point from each stratum
    [grids{1:d}] = ndgrid(1:m);
    strata_indices = reshape(cat(d+1, grids{:}), [], d);
    
    for i = 1:N_actual
        for j = 1:d
            idx_stratum = strata_indices(i, j);
            X(j, i) = edges{j}(idx_stratum) + ...
                      (edges{j}(idx_stratum+1) - edges{j}(idx_stratum)) * rand();
        end
    end
    
    % Use only requested number of samples
    X = X(:, 1:N);
    
    % Evaluate function
    f_vals = f(X);
    
    % Volume
    volume = prod(upper - lower);
    
    % Monte Carlo estimate
    I_est = volume * mean(f_vals);
    
    % Standard error
    std_err = volume * std(f_vals) / sqrt(N);
end

function I_est = quasiMC(f, lower, upper, N)
    % Quasi-Monte Carlo using Sobol sequence
    
    d = length(lower);
    volume = prod(upper - lower);
    
    % Generate Sobol sequence
    p = sobolset(d);
    p = scramble(p, 'MatousekAffineOwen');  % Randomized QMC
    
    % Get N points
    X_unit = net(p, N)';  % Points in [0,1]^d
    
    % Map to actual domain
    X = bsxfun(@plus, lower, bsxfun(@times, upper - lower, X_unit));
    
    % Evaluate function
    f_vals = f(X);
    
    % QMC estimate (no standard error for deterministic sequence)
    I_est = volume * mean(f_vals);
end
