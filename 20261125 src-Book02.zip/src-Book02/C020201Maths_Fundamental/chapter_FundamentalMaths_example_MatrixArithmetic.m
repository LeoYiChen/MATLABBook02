%% chapter_FundamentalMaths_example_MatrixArithmetic.m
% Matrix arithmetic operations and element-wise computations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_MatrixArithmetic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_LinearAlgebra_Example02.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates matrix arithmetic operations, highlighting
%              the distinction between matrix and element-wise operations.

function demonstrateMatrixArithmetic()
    fprintf('Matrix Arithmetic Operations\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic matrix operations
    demonstrateBasicOperations();
    
    % Part 2: Element-wise operations
    demonstrateElementWise();
    
    % Part 3: Matrix powers and functions
    demonstrateMatrixFunctions();
    
    % Part 4: Performance comparison
    demonstratePerformance();
end

function demonstrateBasicOperations()
    fprintf('Part 1: Basic Matrix Operations\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define matrices
    A = [1, 2, 3; 4, 5, 6];
    B = [7, 8, 9; 10, 11, 12];
    C = [1, 2; 3, 4; 5, 6];
    
    fprintf('Matrix A (2$\times$3):\n');
    disp(A);
    fprintf('Matrix B (2$\times$3):\n');
    disp(B);
    fprintf('Matrix C (3$\times$2):\n');
    disp(C);
    
    % Addition
    sumAB = A + B;
    fprintf('A + B (element-wise addition):\n');
    disp(sumAB);
    
    % Subtraction
    diffAB = A - B;
    fprintf('A - B (element-wise subtraction):\n');
    disp(diffAB);
    
    % Matrix multiplication
    productAC = A * C;
    fprintf('A * C (matrix multiplication, result 2$\times$2):\n');
    disp(productAC);
    
    % Transpose
    AT = A';
    fprintf('A'' (transpose, result 3$\times$2):\n');
    disp(AT);
    
    % Symmetric matrix product
    ATA = A' * A;
    fprintf('A''A (symmetric matrix, 3$\times$3):\n');
    disp(ATA);
    
    AAT = A * A';
    fprintf('AA'' (symmetric matrix, 2$\times$2):\n');
    disp(AAT);
    fprintf('\n');
end

function demonstrateElementWise()
    fprintf('Part 2: Element-wise Operations\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define matrices of same size
    A = [1, 2, 3; 4, 5, 6];
    B = [2, 2, 2; 3, 3, 3];
    
    fprintf('Matrix A:\n');
    disp(A);
    fprintf('Matrix B:\n');
    disp(B);
    
    % Element-wise multiplication
    productElem = A .* B;
    fprintf('A .* B (element-wise multiplication):\n');
    disp(productElem);
    
    % Element-wise division
    divisionElem = A ./ B;
    fprintf('A ./ B (element-wise division):\n');
    disp(divisionElem);
    
    % Element-wise power
    powerElem = A .^ 2;
    fprintf('A .^ 2 (element-wise squaring):\n');
    disp(powerElem);
    
    % Combined operations
    result = (A .* B) .^ 2 + A ./ B;
    fprintf('(A .* B).^2 + A ./ B:\n');
    disp(result);
    
    % Broadcasting (implicit expansion)
    v = [1; 2];
    expanded = A + v; % v automatically expands to match A
    fprintf('A + v (with broadcasting, v = [1; 2]):\n');
    disp(expanded);
    fprintf('\n');
end

function demonstrateMatrixFunctions()
    fprintf('Part 3: Matrix Powers and Functions\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define square matrix
    A = [1, 2; 3, 4];
    fprintf('Matrix A:\n');
    disp(A);
    
    % Matrix power (repeated matrix multiplication)
    A2 = A^2;
    fprintf('A^2 (matrix power, A*A):\n');
    disp(A2);
    
    % Verify equivalence
    A2_verify = A * A;
    fprintf('Verification A*A:\n');
    disp(A2_verify);
    fprintf('Difference: %e\n', norm(A2 - A2_verify));
    
    % Higher powers
    A3 = A^3;
    fprintf('A^3:\n');
    disp(A3);
    
    % Matrix exponential
    expA = expm(A);
    fprintf('expm(A) (matrix exponential):\n');
    disp(expA);
    
    fprintf('Note: expm(A) ≠ exp(A)\n');
    fprintf('exp(A) performs element-wise exponential:\n');
    disp(exp(A));
    
    % Matrix square root
    sqrtA = sqrtm(A);
    fprintf('sqrtm(A) (matrix square root):\n');
    disp(sqrtA);
    
    % Verify: sqrtm(A) * sqrtm(A) should equal A
    verification = sqrtA * sqrtA;
    fprintf('Verification sqrtm(A)^2:\n');
    disp(verification);
    fprintf('Error: %e\n', norm(A - verification));
    
    % Matrix logarithm
    logA = logm(A);
    fprintf('logm(A) (matrix logarithm):\n');
    disp(logA);
    
    % Verify: expm(logm(A)) should equal A
    verification2 = expm(logA);
    fprintf('Verification expm(logm(A)):\n');
    disp(verification2);
    fprintf('Error: %e\n\n', norm(A - verification2));
end

function demonstratePerformance()
    fprintf('Part 4: Performance Comparison\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create large matrices
    n = 1000;
    A = rand(n, n);
    B = rand(n, n);
    
    fprintf('Comparing performance for %d$\times$%d matrices:\n\n', n, n);
    
    % Matrix multiplication
    tic;
    C1 = A * B;
    time_matmul = toc;
    fprintf('Matrix multiplication (A * B): %.4f seconds\n', time_matmul);
    
    % Element-wise multiplication
    tic;
    C2 = A .* B;
    time_elem = toc;
    fprintf('Element-wise multiplication (A .* B): %.4f seconds\n', time_elem);
    
    fprintf('\nSpeedup ratio: %.2fx\n', time_matmul / time_elem);
    fprintf('Note: Element-wise operations are typically faster\n');
    fprintf('      as they avoid the O(n^3) complexity of matrix multiplication\n');
end
