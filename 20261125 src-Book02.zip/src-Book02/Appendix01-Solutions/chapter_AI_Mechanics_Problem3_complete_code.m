%% chapter_AI_Mechanics_Problem3_complete_code.m
% Complete defect classification using unsupervised clustering.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem3_complete_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 3: Unsupervised Defect Classification in Additive Manufacturing
% Author: Dr Yi Chen
% Date: 2024-01-20
% Version: 2.1
% MATLAB Version: R2023b
% Description: Implements k-means and hierarchical clustering for SLM defect
%              classification based on micro-CT morphological features

clear; clc; close all;

fprintf('=== Problem 3: Unsupervised Defect Classification in AM ===\n\n');

%% Generate Synthetic Defect Dataset

numDefects = 800;
rng(123);  % Reproducibility

% Define four defect classes with characteristic feature distributions
% Class 1: Gas porosity (spherical, isolated, random distribution)
% Class 2: Lack of fusion (irregular, elongated, layer-aligned)
% Class 3: Keyhole porosity (elongated, high aspect ratio, scan track aligned)
% Class 4: Crack initiation sites (small, surface-proximate, high stress regions)

numPerClass = numDefects / 4;

% Initialise feature matrix (800   12)
% Features: [Volume, Sphericity, AspectRatio, Elongation, Orientation, 
%            DistFromSurface, LocalPorosity, ThermalGradient, 
%            EquivDiameter, SurfaceArea, CompactnessIndex, PositionZ]

featureMatrix = zeros(numDefects, 12);
trueLabels = zeros(numDefects, 1);

%% Class 1: Gas Porosity
idx1 = 1:numPerClass;
featureMatrix(idx1, 1) = 5e-5 + 8e-5 * rand(numPerClass, 1);  % Volume (mm^3)
featureMatrix(idx1, 2) = 0.85 + 0.12 * rand(numPerClass, 1);  % Sphericity (high)
featureMatrix(idx1, 3) = 1.0 + 0.3 * rand(numPerClass, 1);    % Aspect ratio (near 1)
featureMatrix(idx1, 4) = 0.05 + 0.1 * rand(numPerClass, 1);   % Elongation (low)
featureMatrix(idx1, 5) = 180 * rand(numPerClass, 1);          % Orientation (random)
featureMatrix(idx1, 6) = 0.5 + 4.5 * rand(numPerClass, 1);    % Distance from surface (mm)
featureMatrix(idx1, 7) = 0.001 + 0.004 * rand(numPerClass, 1); % Local porosity
featureMatrix(idx1, 8) = 1e5 + 4e5 * rand(numPerClass, 1);    % Thermal gradient (K/m)
featureMatrix(idx1, 9) = (6 * featureMatrix(idx1, 1) / pi).^(1/3); % Equiv diameter
featureMatrix(idx1, 10) = 4 * pi * featureMatrix(idx1, 9).^2; % Surface area
featureMatrix(idx1, 11) = featureMatrix(idx1, 1).^(2/3) ./ featureMatrix(idx1, 10); % Compactness
featureMatrix(idx1, 12) = 10 * rand(numPerClass, 1);          % Z position (mm)
trueLabels(idx1) = 1;

%% Class 2: Lack of Fusion
idx2 = (numPerClass+1):(2*numPerClass);
featureMatrix(idx2, 1) = 2e-4 + 6e-4 * rand(numPerClass, 1);  % Volume (larger)
featureMatrix(idx2, 2) = 0.35 + 0.25 * rand(numPerClass, 1);  % Sphericity (low)
featureMatrix(idx2, 3) = 2.5 + 2.0 * rand(numPerClass, 1);    % Aspect ratio (high)
featureMatrix(idx2, 4) = 0.4 + 0.35 * rand(numPerClass, 1);   % Elongation (high)
featureMatrix(idx2, 5) = 5 + 10 * rand(numPerClass, 1);       % Orientation (layer-aligned)
featureMatrix(idx2, 6) = 1.0 + 3.0 * rand(numPerClass, 1);    % Distance from surface
featureMatrix(idx2, 7) = 0.008 + 0.015 * rand(numPerClass, 1); % Local porosity (high)
featureMatrix(idx2, 8) = 5e4 + 2e5 * rand(numPerClass, 1);    % Thermal gradient (lower)
featureMatrix(idx2, 9) = (6 * featureMatrix(idx2, 1) / pi).^(1/3);
featureMatrix(idx2, 10) = 4 * pi * featureMatrix(idx2, 9).^2 .* featureMatrix(idx2, 3);
featureMatrix(idx2, 11) = featureMatrix(idx2, 1).^(2/3) ./ featureMatrix(idx2, 10);
featureMatrix(idx2, 12) = 10 * rand(numPerClass, 1);
trueLabels(idx2) = 2;

%% Class 3: Keyhole Porosity
idx3 = (2*numPerClass+1):(3*numPerClass);
featureMatrix(idx3, 1) = 8e-5 + 3e-4 * rand(numPerClass, 1);  % Volume (moderate)
featureMatrix(idx3, 2) = 0.25 + 0.20 * rand(numPerClass, 1);  % Sphericity (very low)
featureMatrix(idx3, 3) = 4.0 + 3.0 * rand(numPerClass, 1);    % Aspect ratio (very high)
featureMatrix(idx3, 4) = 0.65 + 0.25 * rand(numPerClass, 1);  % Elongation (very high)
featureMatrix(idx3, 5) = 85 + 10 * rand(numPerClass, 1);      % Orientation (scan-aligned)
featureMatrix(idx3, 6) = 0.8 + 3.2 * rand(numPerClass, 1);    % Distance from surface
featureMatrix(idx3, 7) = 0.003 + 0.007 * rand(numPerClass, 1); % Local porosity
featureMatrix(idx3, 8) = 8e5 + 5e5 * rand(numPerClass, 1);    % Thermal gradient (very high)
featureMatrix(idx3, 9) = (6 * featureMatrix(idx3, 1) / pi).^(1/3);
featureMatrix(idx3, 10) = 4 * pi * featureMatrix(idx3, 9).^2 .* featureMatrix(idx3, 3);
featureMatrix(idx3, 11) = featureMatrix(idx3, 1).^(2/3) ./ featureMatrix(idx3, 10);
featureMatrix(idx3, 12) = 10 * rand(numPerClass, 1);
trueLabels(idx3) = 3;

%% Class 4: Crack Initiation Sites
idx4 = (3*numPerClass+1):numDefects;
featureMatrix(idx4, 1) = 1e-5 + 4e-5 * rand(numPerClass, 1);  % Volume (small)
featureMatrix(idx4, 2) = 0.15 + 0.25 * rand(numPerClass, 1);  % Sphericity (very low)
featureMatrix(idx4, 3) = 5.0 + 4.0 * rand(numPerClass, 1);    % Aspect ratio (extreme)
featureMatrix(idx4, 4) = 0.75 + 0.20 * rand(numPerClass, 1);  % Elongation (extreme)
featureMatrix(idx4, 5) = 45 + 90 * rand(numPerClass, 1);      % Orientation (varied)
featureMatrix(idx4, 6) = 0.1 + 0.8 * rand(numPerClass, 1);    % Distance (near surface)
featureMatrix(idx4, 7) = 0.001 + 0.003 * rand(numPerClass, 1); % Local porosity (low)
featureMatrix(idx4, 8) = 3e5 + 6e5 * rand(numPerClass, 1);    % Thermal gradient (high)
featureMatrix(idx4, 9) = (6 * featureMatrix(idx4, 1) / pi).^(1/3);
featureMatrix(idx4, 10) = 4 * pi * featureMatrix(idx4, 9).^2 .* featureMatrix(idx4, 3);
featureMatrix(idx4, 11) = featureMatrix(idx4, 1).^(2/3) ./ featureMatrix(idx4, 10);
featureMatrix(idx4, 12) = 0.5 + 2.0 * rand(numPerClass, 1);   % Z (near bottom)
trueLabels(idx4) = 4;

% Feature names
featureNames = {'Volume $(mm^3)$', 'Sphericity', 'Aspect Ratio', 'Elongation', ...
               'Orientation $(^\circ)$', 'Dist. from Surface $(mm)$', ...
               'Local Porosity', 'Thermal Gradient $(K/m)$', ...
               'Equiv. Diameter $(mm)$', 'Surface Area $(mm^2)$', ...
               'Compactness', 'Z Position $(mm)$'};

defectTypes = {'Gas Porosity', 'Lack of Fusion', 'Keyhole Porosity', 'Crack Initiation'};

fprintf('Synthetic defect dataset generated:\n');
fprintf('  Total defects: %d\n', numDefects);
fprintf('  Features per defect: %d\n', size(featureMatrix, 2));
fprintf('  True classes: %d\n', length(unique(trueLabels)));
for classIdx = 1:4
    fprintf('    Class %d (%s): %d defects\n', classIdx, ...
            defectTypes{classIdx}, sum(trueLabels == classIdx));
end
fprintf('\n');

%% Data Preprocessing

fprintf('-- Data Preprocessing --\n\n');

% Check for missing values
if any(isnan(featureMatrix(:)))
    warning('Missing values detected. Imputing with column means...');
    featureMatrix = fillmissing(featureMatrix, 'constant', mean(featureMatrix, 'omitnan'));
end

% Outlier detection using IQR method (per feature)
outlierMask = false(size(featureMatrix));
for featIdx = 1:size(featureMatrix, 2)
    Q1 = quantile(featureMatrix(:, featIdx), 0.25);
    Q3 = quantile(featureMatrix(:, featIdx), 0.75);
    IQR_val = Q3 - Q1;
    lowerBound = Q1 - 1.5 * IQR_val;
    upperBound = Q3 + 1.5 * IQR_val;
    outlierMask(:, featIdx) = featureMatrix(:, featIdx) < lowerBound | ...
                              featureMatrix(:, featIdx) > upperBound;
end

% Cap outliers instead of removing (preserve sample size)
for featIdx = 1:size(featureMatrix, 2)
    Q1 = quantile(featureMatrix(:, featIdx), 0.25);
    Q3 = quantile(featureMatrix(:, featIdx), 0.75);
    IQR_val = Q3 - Q1;
    lowerBound = Q1 - 1.5 * IQR_val;
    upperBound = Q3 + 1.5 * IQR_val;
    featureMatrix(featureMatrix(:, featIdx) < lowerBound, featIdx) = lowerBound;
    featureMatrix(featureMatrix(:, featIdx) > upperBound, featIdx) = upperBound;
end

fprintf('Outlier handling: Capped at 1.5 IQR bounds\n');
fprintf('  Total outlier values: %d (%.1f%%)\n', sum(outlierMask(:)), ...
        100 * sum(outlierMask(:)) / numel(featureMatrix));
fprintf('\n');

% Standardisation (z-score normalisation)
featureMean = mean(featureMatrix, 1);
featureStd = std(featureMatrix, 0, 1);
featuresStandardised = (featureMatrix - featureMean) ./ featureStd;

fprintf('Feature standardisation applied (z-score)\n');
fprintf('  Mean: %.2e   %.2e\n', mean(featureMean), std(featureMean));
fprintf('  Std: %.2f   %.2f\n\n', mean(featureStd), std(featureStd));

%% Elbow Method for Optimal K

fprintf('-- Elbow Method for Optimal Cluster Number --\n\n');

maxClusters = 10;
wcssValues = zeros(maxClusters, 1);

for k = 1:maxClusters
    [~, ~, sumDistances] = kmeans(featuresStandardised, k, ...
        'Distance', 'sqeuclidean', 'Start', 'plus', ...
        'Replicates', 10, 'MaxIter', 500, 'Display', 'off');
    wcssValues(k) = sum(sumDistances);
end

fprintf('Within-Cluster Sum of Squares (WCSS) for k = 1 to %d:\n', maxClusters);
for k = 1:maxClusters
    fprintf('  k = %2d: WCSS = %8.2f\n', k, wcssValues(k));
end

% Calculate rate of decrease (elbow detection)
wcssDecrease = -diff(wcssValues);
wcssDecreaseRate = wcssDecrease ./ wcssValues(1:end-1);

[~, elbowK] = max(wcssDecreaseRate(2:end-1)) + 1;  % Skip k=2 transition
fprintf('\nElbow detected at k = %d (maximum decrease rate)\n\n', elbowK);

%% Silhouette Analysis

fprintf('-- Silhouette Analysis --\n\n');

silhouetteScores = zeros(maxClusters - 1, 1);

for k = 2:maxClusters
    [clusterIdx, ~] = kmeans(featuresStandardised, k, ...
        'Distance', 'sqeuclidean', 'Start', 'plus', ...
        'Replicates', 10, 'MaxIter', 500, 'Display', 'off');
    
    silhouetteVals = silhouette(featuresStandardised, clusterIdx, 'sqeuclidean');
    silhouetteScores(k-1) = mean(silhouetteVals);
end

fprintf('Average Silhouette Scores:\n');
for k = 2:maxClusters
    fprintf('  k = %2d: Silhouette = %.4f\n', k, silhouetteScores(k-1));
end

[maxSilhouette, bestKSilhouette] = max(silhouetteScores);
bestKSilhouette = bestKSilhouette + 1;  % Adjust for k starting at 2
fprintf('\nBest k by silhouette: %d (score = %.4f)\n\n', bestKSilhouette, maxSilhouette);

%% Davies-Bouldin Index

fprintf('-- Davies-Bouldin Index Analysis --\n\n');

dbIndices = zeros(maxClusters - 1, 1);

for k = 2:maxClusters
    [clusterIdx, centroids] = kmeans(featuresStandardised, k, ...
        'Distance', 'sqeuclidean', 'Start', 'plus', ...
        'Replicates', 10, 'MaxIter', 500, 'Display', 'off');
    
    % Calculate DB index
    dbIndex = computeDaviesBouldinIndex(featuresStandardised, clusterIdx, centroids);
    dbIndices(k-1) = dbIndex;
end

fprintf('Davies-Bouldin Indices:\n');
for k = 2:maxClusters
    fprintf('  k = %2d: DB Index = %.4f\n', k, dbIndices(k-1));
end

[minDB, bestKDB] = min(dbIndices);
bestKDB = bestKDB + 1;  % Adjust for k starting at 2
fprintf('\nBest k by DB index: %d (DB = %.4f)\n\n', bestKDB, minDB);

%% Determine Optimal K

fprintf('-- Optimal Cluster Number Determination --\n\n');

% Consensus from three methods
fprintf('Method recommendations:\n');
fprintf('  Elbow method: k = %d\n', elbowK);
fprintf('  Silhouette analysis: k = %d\n', bestKSilhouette);
fprintf('  Davies-Bouldin index: k = %d\n', bestKDB);

% Use majority vote or default to true number of classes
optimalK = mode([elbowK, bestKSilhouette, bestKDB]);
fprintf('\nOptimal k selected: %d (consensus)\n', optimalK);
fprintf('Ground truth classes: 4\n\n');

% For demonstration, use true k = 4
optimalK = 4;
fprintf('Using k = 4 for detailed analysis (matches true defect types)\n\n');

%% K-Means Clustering

fprintf('-- K-Means Clustering (k = %d) --\n\n', optimalK);

% Perform k-means with optimal k
[kmeansLabels, kmeansCentroids, kmeansSumDist, kmeansDistances] = kmeans(...
    featuresStandardised, optimalK, ...
    'Distance', 'sqeuclidean', ...
    'Start', 'plus', ...  % k-means++ initialisation
    'Replicates', 50, ...  % 50 replications for robustness
    'MaxIter', 1000, ...
    'Display', 'final');

fprintf('K-means completed:\n');
fprintf('  Iterations: converged\n');
fprintf('  Final WCSS: %.2f\n', sum(kmeansSumDist));

% Cluster sizes
clusterSizes = histcounts(kmeansLabels, 1:(optimalK+1));
fprintf('  Cluster sizes:\n');
for clusterIdx = 1:optimalK
    fprintf('    Cluster %d: %d defects (%.1f%%)\n', clusterIdx, ...
            clusterSizes(clusterIdx), 100 * clusterSizes(clusterIdx) / numDefects);
end
fprintf('\n');

% Within-cluster average silhouette
kmeansStilhouetteVals = silhouette(featuresStandardised, kmeansLabels, 'sqeuclidean');
avgSilhouetteKmeans = mean(kmeansStilhouetteVals);
fprintf('  Average silhouette score: %.4f\n\n', avgSilhouetteKmeans);

%% Hierarchical Clustering

fprintf('-- Hierarchical Agglomerative Clustering --\n\n');

% Compute pairwise distances
distanceMatrix = pdist(featuresStandardised, 'euclidean');

% Perform hierarchical clustering using Ward's linkage
linkageTree = linkage(distanceMatrix, 'ward');

% Determine clusters by cutting tree
hierLabels = cluster(linkageTree, 'MaxClust', optimalK);

fprintf('Hierarchical clustering completed (Ward linkage):\n');

% Cluster sizes
hierClusterSizes = histcounts(hierLabels, 1:(optimalK+1));
fprintf('  Cluster sizes:\n');
for clusterIdx = 1:optimalK
    fprintf('    Cluster %d: %d defects (%.1f%%)\n', clusterIdx, ...
            hierClusterSizes(clusterIdx), 100 * hierClusterSizes(clusterIdx) / numDefects);
end
fprintf('\n');

% Silhouette score
hierSilhouetteVals = silhouette(featuresStandardised, hierLabels, 'sqeuclidean');
avgSilhouetteHier = mean(hierSilhouetteVals);
fprintf('  Average silhouette score: %.4f\n\n', avgSilhouetteHier);

%% Comparison of Clustering Methods

fprintf('-- Comparison of K-Means vs Hierarchical Clustering --\n\n');

% Adjusted Rand Index (ARI) between two clusterings
ariScore = computeAdjustedRandIndex(kmeansLabels, hierLabels);
fprintf('Adjusted Rand Index (ARI) between methods: %.4f\n', ariScore);
fprintf('  (1.0 = perfect agreement, 0.0 = random agreement)\n\n');

%% Validation Against Ground Truth

fprintf('-- Validation Against Ground Truth Labels --\n\n');

% Map cluster labels to true labels using Hungarian algorithm (maximum matching)
kmeansToTrue = mapClustersToGroundTruth(kmeansLabels, trueLabels, optimalK);
hierToTrue = mapClustersToGroundTruth(hierLabels, trueLabels, optimalK);

% Remap cluster labels
kmeansMapped = zeros(size(kmeansLabels));
hierMapped = zeros(size(hierLabels));
for clusterIdx = 1:optimalK
    kmeansMapped(kmeansLabels == clusterIdx) = kmeansToTrue(clusterIdx);
    hierMapped(hierLabels == clusterIdx) = hierToTrue(clusterIdx);
end

% Purity
purityKmeans = sum(kmeansMapped == trueLabels) / numDefects;
purityHier = sum(hierMapped == trueLabels) / numDefects;

fprintf('K-Means clustering:\n');
fprintf('  Purity: %.4f (%.1f%% correctly clustered)\n', purityKmeans, 100*purityKmeans);

fprintf('\nHierarchical clustering:\n');
fprintf('  Purity: %.4f (%.1f%% correctly clustered)\n\n', purityHier, 100*purityHier);

% Normalised Mutual Information (NMI)
nmiKmeans = computeNMI(trueLabels, kmeansLabels);
nmiHier = computeNMI(trueLabels, hierLabels);

fprintf('Normalised Mutual Information (NMI):\n');
fprintf('  K-Means: %.4f\n', nmiKmeans);
fprintf('  Hierarchical: %.4f\n\n', nmiHier);

% Confusion matrices
confMatKmeans = confusionmat(trueLabels, kmeansMapped);
confMatHier = confusionmat(trueLabels, hierMapped);

fprintf('K-Means Confusion Matrix:\n');
disp(confMatKmeans);
fprintf('\nHierarchical Confusion Matrix:\n');
disp(confMatHier);
fprintf('\n');

%% Feature Importance Analysis

fprintf('-- Feature Importance for K-Means Clusters --\n\n');

% Calculate between-cluster variance / within-cluster variance ratio
featureImportance = zeros(12, 1);

for featIdx = 1:12
    % Between-cluster variance
    overallMean = mean(featuresStandardised(:, featIdx));
    betweenVar = 0;
    for clusterIdx = 1:optimalK
        clusterMask = kmeansLabels == clusterIdx;
        clusterMean = mean(featuresStandardised(clusterMask, featIdx));
        clusterSize = sum(clusterMask);
        betweenVar = betweenVar + clusterSize * (clusterMean - overallMean)^2;
    end
    betweenVar = betweenVar / numDefects;
    
    % Within-cluster variance
    withinVar = 0;
    for clusterIdx = 1:optimalK
        clusterMask = kmeansLabels == clusterIdx;
        clusterMean = mean(featuresStandardised(clusterMask, featIdx));
        clusterVar = sum((featuresStandardised(clusterMask, featIdx) - clusterMean).^2);
        withinVar = withinVar + clusterVar;
    end
    withinVar = withinVar / numDefects;
    
    % F-ratio
    featureImportance(featIdx) = betweenVar / (withinVar + 1e-10);
end

% Normalise
featureImportance = featureImportance / sum(featureImportance);

[sortedImportance, sortIdx] = sort(featureImportance, 'descend');

fprintf('Feature Importance Rankings (Between/Within Variance Ratio):\n');
for rank = 1:12
    fprintf('  %2d. %-30s: %.4f\n', rank, featureNames{sortIdx(rank)}, ...
            sortedImportance(rank));
end
fprintf('\n');

%% Physical Interpretation

fprintf('-- Physical Interpretation of Clusters --\n\n');

fprintf('Cluster characteristics (mapped to defect types):\n\n');

for clusterIdx = 1:optimalK
    clusterMask = kmeansMapped == clusterIdx;
    fprintf('Cluster %d   %s (%d defects):\n', clusterIdx, ...
            defectTypes{clusterIdx}, sum(clusterMask));
    
    % Key discriminative features
    fprintf('  Mean sphericity: %.3f\n', mean(featureMatrix(clusterMask, 2)));
    fprintf('  Mean aspect ratio: %.2f\n', mean(featureMatrix(clusterMask, 3)));
    fprintf('  Mean elongation: %.3f\n', mean(featureMatrix(clusterMask, 4)));
    fprintf('  Mean dist. from surface: %.2f mm\n', mean(featureMatrix(clusterMask, 6)));
    fprintf('  Mean local porosity: %.4f\n', mean(featureMatrix(clusterMask, 7)));
    fprintf('\n');
end

%% Visualisation

figure('Position', [50, 50, 1600, 1200]);

% Subplot 1: Elbow Plot
subplot(3,3,1);
plot(1:maxClusters, wcssValues, 'b-o', 'LineWidth', 2, 'MarkerSize', 8, ...
     'MarkerFaceColor', 'b');
hold on;
xline(elbowK, 'r-', 'LineWidth', 2);
xlabel('Number of Clusters $k$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('WCSS', 'Interpreter', 'latex', 'FontSize', 12);
title('Elbow Method', 'Interpreter', 'latex', 'FontSize', 14);
grid on;
legend('WCSS', sprintf('Elbow at k=%d', elbowK), 'Interpreter', 'latex', 'Location', 'northeast');
hold off;

% Subplot 2: Silhouette Scores
subplot(3,3,2);
plot(2:maxClusters, silhouetteScores, 'r-s', 'LineWidth', 2, 'MarkerSize', 8, ...
     'MarkerFaceColor', 'r');
hold on;
xline(bestKSilhouette, 'b-', 'LineWidth', 2);
xlabel('Number of Clusters $k$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Average Silhouette Score', 'Interpreter', 'latex', 'FontSize', 12);
title('Silhouette Analysis', 'Interpreter', 'latex', 'FontSize', 14);
grid on;
legend('Silhouette', sprintf('Best k=%d', bestKSilhouette), 'Interpreter', 'latex');
hold off;

% Subplot 3: Davies-Bouldin Index
subplot(3,3,3);
plot(2:maxClusters, dbIndices, 'g-d', 'LineWidth', 2, 'MarkerSize', 8, ...
     'MarkerFaceColor', 'g');
hold on;
xline(bestKDB, 'm-', 'LineWidth', 2);
xlabel('Number of Clusters $k$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Davies-Bouldin Index', 'Interpreter', 'latex', 'FontSize', 12);
title('Davies-Bouldin Analysis', 'Interpreter', 'latex', 'FontSize', 14);
grid on;
legend('DB Index', sprintf('Best k=%d', bestKDB), 'Interpreter', 'latex');
hold off;

% Subplot 4: K-Means Clusters (2D projection: Sphericity vs Aspect Ratio)
subplot(3,3,4);
gscatter(featureMatrix(:,2), featureMatrix(:,3), kmeansLabels, [], 'o', 8, 'filled');
xlabel('Sphericity', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Aspect Ratio', 'Interpreter', 'latex', 'FontSize', 12);
title('K-Means Clusters (Sphericity vs Aspect Ratio)', 'Interpreter', 'latex', 'FontSize', 14);
legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Cluster 4', 'Interpreter', 'latex');
grid on;

% Subplot 5: Hierarchical Clusters (same projection)
subplot(3,3,5);
gscatter(featureMatrix(:,2), featureMatrix(:,3), hierLabels, [], 's', 8, 'filled');
xlabel('Sphericity', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Aspect Ratio', 'Interpreter', 'latex', 'FontSize', 12);
title('Hierarchical Clusters (Sphericity vs Aspect Ratio)', 'Interpreter', 'latex', 'FontSize', 14);
legend('Cluster 1', 'Cluster 2', 'Cluster 3', 'Cluster 4', 'Interpreter', 'latex');
grid on;

% Subplot 6: Ground Truth
subplot(3,3,6);
gscatter(featureMatrix(:,2), featureMatrix(:,3), trueLabels, [], 'd', 8, 'filled');
xlabel('Sphericity', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Aspect Ratio', 'Interpreter', 'latex', 'FontSize', 12);
title('Ground Truth Classes', 'Interpreter', 'latex', 'FontSize', 14);
legend(defectTypes, 'Interpreter', 'latex');
grid on;

% Subplot 7: Dendrogram
subplot(3,3,7);
dendrogram(linkageTree, 30, 'ColorThreshold', 'default');  % Show 30 leaves
xlabel('Defect Index', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Ward Distance', 'Interpreter', 'latex', 'FontSize', 12);
title('Hierarchical Clustering Dendrogram', 'Interpreter', 'latex', 'FontSize', 14);

% Subplot 8: Silhouette Plot for K-Means
subplot(3,3,8);
silhouette(featuresStandardised, kmeansLabels, 'sqeuclidean');
xlabel('Silhouette Value', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Cluster', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Silhouette Plot (K-Means, avg=%.3f)', avgSilhouetteKmeans), ...
      'Interpreter', 'latex', 'FontSize', 14);

% Subplot 9: Feature Importance
subplot(3,3,9);
barh(featureImportance(sortIdx), 'FaceColor', [0.2, 0.6, 0.8]);
set(gca, 'YTick', 1:12, 'YTickLabel', featureNames(sortIdx), ...
    'TickLabelInterpreter', 'latex', 'FontSize', 9);
xlabel('Normalised Importance', 'Interpreter', 'latex', 'FontSize', 12);
title('Feature Importance (F-ratio)', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

%% Helper Functions

function dbIndex = computeDaviesBouldinIndex(data, labels, centroids)
    % Compute Davies-Bouldin index for cluster quality assessment
    k = size(centroids, 1);
    sigma = zeros(k, 1);
    
    % Average within-cluster distance
    for clusterIdx = 1:k
        clusterMask = labels == clusterIdx;
        clusterData = data(clusterMask, :);
        distances = pdist2(clusterData, centroids(clusterIdx, :), 'euclidean');
        sigma(clusterIdx) = mean(distances);
    end
    
    % Inter-cluster distances
    delta = pdist2(centroids, centroids, 'euclidean');
    
    % DB index
    dbIndex = 0;
    for i = 1:k
        maxRatio = 0;
        for j = 1:k
            if i ~= j
                ratio = (sigma(i) + sigma(j)) / delta(i, j);
                if ratio > maxRatio
                    maxRatio = ratio;
                end
            end
        end
        dbIndex = dbIndex + maxRatio;
    end
    dbIndex = dbIndex / k;
end

function ari = computeAdjustedRandIndex(labels1, labels2)
    % Compute Adjusted Rand Index between two clusterings
    n = length(labels1);
    
    % Contingency table
    k1 = max(labels1);
    k2 = max(labels2);
    contingency = zeros(k1, k2);
    
    for i = 1:n
        contingency(labels1(i), labels2(i)) = contingency(labels1(i), labels2(i)) + 1;
    end
    
    % Marginals
    a = sum(contingency, 2);
    b = sum(contingency, 1);
    
    % Combinations
    sumComb_nij = sum(nchoosek_safe(contingency(:), 2));
    sumComb_ai = sum(nchoosek_safe(a, 2));
    sumComb_bj = sum(nchoosek_safe(b, 2));
    totalComb = nchoosek_safe(n, 2);
    
    % ARI formula
    expectedIndex = sumComb_ai * sumComb_bj / totalComb;
    maxIndex = (sumComb_ai + sumComb_bj) / 2;
    ari = (sumComb_nij - expectedIndex) / (maxIndex - expectedIndex);
end

function result = nchoosek_safe(n, k)
    % Safe computation of binomial coefficient for arrays
    if isscalar(n)
        if n >= k && n >= 0
            result = nchoosek(n, k);
        else
            result = 0;
        end
    else
        result = arrayfun(@(x) nchoosek_safe(x, k), n);
        result = sum(result);
    end
end

function mapping = mapClustersToGroundTruth(clusterLabels, trueLabels, numClusters)
    % Map cluster labels to ground truth using maximum overlap (greedy)
    mapping = zeros(numClusters, 1);
    usedTrueLabels = [];
    
    for clusterIdx = 1:numClusters
        clusterMask = clusterLabels == clusterIdx;
        
        % Find most common true label in this cluster (excluding used)
        trueLabelCounts = histcounts(trueLabels(clusterMask), 1:(max(trueLabels)+1));
        trueLabelCounts(usedTrueLabels) = 0;  % Exclude already mapped
        
        [~, bestTrueLabel] = max(trueLabelCounts);
        mapping(clusterIdx) = bestTrueLabel;
        usedTrueLabels = [usedTrueLabels, bestTrueLabel]; %#ok<AGROW>
    end
end

function nmi = computeNMI(labels1, labels2)
    % Compute Normalised Mutual Information
    n = length(labels1);
    k1 = max(labels1);
    k2 = max(labels2);
    
    % Contingency table
    contingency = zeros(k1, k2);
    for i = 1:n
        contingency(labels1(i), labels2(i)) = contingency(labels1(i), labels2(i)) + 1;
    end
    contingency = contingency / n;
    
    % Marginals
    p1 = sum(contingency, 2);
    p2 = sum(contingency, 1)';
    
    % Mutual information
    mi = 0;
    for i = 1:k1
        for j = 1:k2
            if contingency(i, j) > 0
                mi = mi + contingency(i, j) * log(contingency(i, j) / (p1(i) * p2(j)));
            end
        end
    end
    
    % Entropy
    h1 = -sum(p1(p1 > 0) .* log(p1(p1 > 0)));
    h2 = -sum(p2(p2 > 0) .* log(p2(p2 > 0)));
    
    % NMI
    nmi = 2 * mi / (h1 + h2);
end

fprintf('\n=== Problem 3 Complete ===\n\n');
