%% chapter_Math_problem9_solution.m
% Comprehensive Fourier analysis implementation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem9_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem9_FourierAnalysis()
    % PROBLEM9_FOURIERANALYSIS Comprehensive Fourier series and transform
    %
    % This function demonstrates:
    % - Fourier series computation and convergence
    % - Gibbs phenomenon at discontinuities
    % - Complex exponential form
    % - Parseval's theorem verification
    % - Discrete Fourier Transform (DFT)
    % - Fast Fourier Transform (FFT) algorithm
    % - Spectral analysis of signals
    % - Signal filtering (low-pass, high-pass, band-pass)
    % - Window functions for spectral analysis
    % - Time-frequency analysis
    % - Applications to differential equations
    % - 2D Fourier transform (image processing)
    %
    % Topics covered:
    % 1. Classical Fourier series (square wave, sawtooth)
    % 2. Convergence and Gibbs phenomenon
    % 3. FFT and computational efficiency
    % 4. Signal processing applications
    % 5. Filtering and noise removal
    % 6. Heat equation solution via Fourier
    % 7. Image compression
    %
    % References:
    % - Stein & Shakarchi, "Fourier Analysis" (2003)
    % - Bracewell, "The Fourier Transform and Its Applications" (1999)
    % - Oppenheim & Schafer, "Discrete-Time Signal Processing" (2009)
    % - Cooley & Tukey, "An Algorithm for Machine Calculation..." (1965)
    %
    % Author: Dr Yi Chen
    % Date: 2025
    
    fprintf('\n=== Problem 9: Fourier Series and Transform ===\n\n');
    
    % Part 1: Classical Fourier series
    fprintf('=== Part 1: Fourier Series - Square Wave ===\n\n');
    analyseSquareWave();
    
    % Part 2: Gibbs phenomenon
    fprintf('\n=== Part 2: Gibbs Phenomenon ===\n\n');
    demonstrateGibbs();
    
    % Part 3: Sawtooth wave
    fprintf('\n=== Part 3: Sawtooth Wave ===\n\n');
    analyseSawtoothWave();
    
    % Part 4: Parseval's theorem
    fprintf('\n=== Part 4: Parseval''s Theorem (Energy Conservation) ===\n\n');
    verifyParseval();
    
    % Part 5: FFT demonstration
    fprintf('\n=== Part 5: Fast Fourier Transform (FFT) ===\n\n');
    demonstrateFFT();
    
    % Part 6: Signal analysis
    fprintf('\n=== Part 6: Spectral Analysis of Composite Signal ===\n\n');
    analyseCompositeSignal();
    
    % Part 7: Filtering
    fprintf('\n=== Part 7: Signal Filtering ===\n\n');
    demonstrateFiltering();
    
    % Part 8: Window functions
    fprintf('\n=== Part 8: Window Functions ===\n\n');
    demonstrateWindows();
    
    % Part 9: Heat equation
    fprintf('\n=== Part 9: Solving Heat Equation via Fourier ===\n\n');
    solveHeatEquation();
    
    % Part 10: 2D Fourier (image)
    fprintf('\n=== Part 10: 2D Fourier Transform (Image Processing) ===\n\n');
    demonstrate2DFourier();
    
    fprintf('\nAnalysis complete!\n');
end

function analyseSquareWave()
    % ANALYSESQUAREWAVE Fourier series of square wave
    %
    % f(x) = { +1,  0 < x < 뿯ν
    %        { -1, -뿯ν < x < 0
    %
    % Fourier series: f(x) = (4/뿯ν) 뿯ν (sin(nx)/n) for n odd
    
    fprintf('Square wave: f(x) = sgn(sin(x))\n');
    fprintf('Period: 2뿯ν\n\n');
    
    fprintf('Fourier series:\n');
    fprintf('f(x) = (4/뿯ν)[sin(x) + sin(3x)/3 + sin(5x)/5 + ...]\n\n');
    
    % Set up
    L = pi;
    x = linspace(-L, L, 1000);
    
    % True function
    f_true = sign(sin(x));
    f_true(x == 0) = 0;  % Average at discontinuity
    
    % Compute partial sums
    N_values = [1, 3, 5, 10, 20, 50];
    
    fprintf('Computing Fourier approximations...\n');
    fprintf('%8s  %15s\n', 'N terms', 'RMS Error');
    fprintf('%s\n', repmat('-', 1, 30));
    
    % Create figure
    figure('Position', [100, 100, 1400, 900]);
    
    for idx = 1:length(N_values)
        N = N_values(idx);
        
        % Compute Fourier series
        f_approx = zeros(size(x));
        for n = 1:N
            if mod(n, 2) == 1  % Only odd terms
                f_approx = f_approx + (4/pi) * sin(n*x) / n;
            end
        end
        
        % Compute error
        rms_error = sqrt(mean((f_approx - f_true).^2));
        fprintf('%8d  %15.6f\n', N, rms_error);
        
        % Plot
        subplot(3, 2, idx);
        plot(x, f_true, 'k-', 'LineWidth', 2, 'DisplayName', 'True');
        hold on;
        plot(x, f_approx, 'b-', 'LineWidth', 1.5, ...
            'DisplayName', sprintf('N = %d', N));
        hold off;
        grid on;
        xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('$f(x)$', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('$N = %d$ terms', N), 'Interpreter', 'latex', ...
            'FontSize', 12);
        legend('Interpreter', 'latex', 'Location', 'southeast');
        ylim([-1.5, 1.5]);
    end
    
    fprintf('\nObservations:\n');
    fprintf('  • Series converges to square wave\n');
    fprintf('  • Overshoots near discontinuities (Gibbs phenomenon)\n');
    fprintf('  • Needs many terms for good approximation\n');
end

function demonstrateGibbs()
    % DEMONSTRATEGIBBS Show Gibbs phenomenon in detail
    %
    % At discontinuity, overshoot ≈ 9%% regardless of N!
    
    fprintf('Gibbs Phenomenon: Overshoot at discontinuities\n\n');
    
    L = pi;
    N_max = 100;
    
    % Focus near discontinuity at x = 0
    x = linspace(-0.5, 0.5, 2000);
    
    % True function (square wave)
    f_true = ones(size(x));
    f_true(x < 0) = -1;
    
    % Compute for various N
    overshoots = zeros(1, N_max);
    
    for N = 1:N_max
        f_N = zeros(size(x));
        for n = 1:N
            if mod(n, 2) == 1
                f_N = f_N + (4/pi) * sin(n*x) / n;
            end
        end
        
        % Find maximum overshoot
        overshoots(N) = max(f_N) - 1;
    end
    
    % Theoretical limit
    gibbs_constant = (2/pi) * ...
        integral(@(t) sin(t)./t, 0, pi) - 1;
    
    fprintf('Theoretical Gibbs overshoot: %.4f (≈ %.2f%%%%)\n', ...
        gibbs_constant, gibbs_constant * 100);
    fprintf('Numerical overshoot (N=100): %.4f (≈ %.2f%%%%)\n', ...
        overshoots(end), overshoots(end) * 100);
    
    % Create visualisation
    figure('Position', [100, 100, 1400, 600]);
    
    % Plot approximation
    subplot(1, 2, 1);
    N = 50;
    f_N = zeros(size(x));
    for n = 1:N
        if mod(n, 2) == 1
            f_N = f_N + (4/pi) * sin(n*x) / n;
        end
    end
    
    plot(x, f_true, 'k-', 'LineWidth', 2, 'DisplayName', 'True function');
    hold on;
    plot(x, f_N, 'b-', 'LineWidth', 1.5, ...
        'DisplayName', sprintf('Fourier (N=%d)', N));
    plot([0 0], [-1.5 1.5], 'r-', 'LineWidth', 1, ...
        'DisplayName', 'Discontinuity');
    yline(1 + gibbs_constant, 'g-', 'LineWidth', 1.5, ...
        'DisplayName', 'Gibbs overshoot');
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f(x)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Gibbs Phenomenon', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    ylim([-1.5, 1.5]);
    
    % Plot overshoot vs N
    subplot(1, 2, 2);
    plot(1:N_max, overshoots, 'b-', 'LineWidth', 2, ...
        'DisplayName', 'Numerical');
    hold on;
    yline(gibbs_constant, 'r-', 'LineWidth', 2, ...
        'DisplayName', 'Theoretical limit');
    hold off;
    grid on;
    xlabel('Number of terms $N$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Overshoot', 'Interpreter', 'latex', 'FontSize', 12);
    title('Overshoot vs Number of Terms', 'Interpreter', 'latex', ...
        'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    fprintf('\nKey insight: Overshoot cannot be eliminated by adding terms!\n');
    fprintf('This is fundamental property of Fourier series at jumps.\n');
end

function analyseSawtoothWave()
    % ANALYSESAWTOOTHWAVE Fourier series of sawtooth
    %
    % f(x) = x for -뿯ν < x < 뿯ν
    %
    % Fourier series: f(x) = (2/뿯ν) 뿯ν (-1)^(n+1) sin(nx)/n
    
    fprintf('Sawtooth wave: f(x) = x on [-뿯ν, 뿯ν]\n');
    fprintf('Fourier series: f(x) = 2뿯ν[(-1)^(n+1) sin(nx)/n]\n\n');
    
    L = pi;
    x = linspace(-L, L, 1000);
    f_true = x;
    
    % Fourier coefficients
    fprintf('Fourier coefficients:\n');
    fprintf('  a_0 = 0 (odd function)\n');
    fprintf('  a_n = 0 (odd function)\n');
    fprintf('  b_n = 2(-1)^(n+1)/n\n\n');
    
    % Compute approximations
    N_values = [5, 10, 20, 50];
    
    figure('Position', [100, 100, 1400, 1000]);
    
    for idx = 1:length(N_values)
        N = N_values(idx);
        
        % Fourier series
        f_approx = zeros(size(x));
        for n = 1:N
            b_n = 2 * (-1)^(n+1) / n;
            f_approx = f_approx + b_n * sin(n*x);
        end
        
        % Plot
        subplot(2, 2, idx);
        plot(x, f_true, 'k-', 'LineWidth', 2, 'DisplayName', 'True');
        hold on;
        plot(x, f_approx, 'b-', 'LineWidth', 1.5, ...
            'DisplayName', sprintf('N = %d', N));
        hold off;
        grid on;
        xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('$f(x)$', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('$N = %d$ terms', N), 'Interpreter', 'latex', ...
            'FontSize', 12);
        legend('Interpreter', 'latex', 'Location', 'northwest');
    end
    
    % Spectrum
    figure('Position', [100, 100, 800, 600]);
    n = 1:50;
    b_n = 2 * (-1).^(n+1) ./ n;
    
    stem(n, abs(b_n), 'b', 'LineWidth', 1.5, 'MarkerSize', 6);
    grid on;
    xlabel('Frequency index $n$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|b_n|$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Frequency Spectrum', 'Interpreter', 'latex', 'FontSize', 14);
    
    fprintf('Spectrum decays as 1/n (slower than square wave 1/n for odd n)\n');
end

function verifyParseval()
    % VERIFYPARSEVAL Verify Parseval's theorem
    %
    % ∫|f|뿯½ = 뿯ν|c_n|뿯½
    
    fprintf('Parseval''s Theorem: Energy conservation\n\n');
    
    L = pi;
    x = linspace(-L, L, 10000);
    
    % Test function: f(x) = x뿯½ on [-뿯ν, 뿯ν]
    f = x.^2;
    
    fprintf('Test function: f(x) = x뿯½\n\n');
    
    % Left side: integral of |f|뿯½
    energy_integral = (1/(2*L)) * trapz(x, f.^2);
    
    fprintf('Energy from integral:\n');
    fprintf('  (1/2L)∫|f|뿯½ dx = %.10f\n\n', energy_integral);
    
    % Right side: sum of |c_n|뿯½
    N_max = 100;
    
    % Fourier coefficients for f(x) = x뿯½
    % a_0 = (1/L)∫x뿯½ dx from -L to L = 2L뿯½/3
    a_0 = (2/3) * L^2;
    
    energy_series = (a_0^2) / 2;
    
    for n = 1:N_max
        % a_n = (1/L)∫x뿯½ cos(nx/L) dx
        % Integration by parts twice:
        a_n = (4*L^2 * (-1)^n) / (n^2 * pi^2);
        
        % b_n = 0 (even function)
        
        energy_series = energy_series + a_n^2;
    end
    
    fprintf('Energy from Fourier series (N=%d):\n', N_max);
    fprintf('  |a_0|뿯½/2 + 뿯ν|a_n|뿯½ = %.10f\n\n', energy_series);
    
    relative_error = abs(energy_integral - energy_series) / energy_integral;
    
    fprintf('Relative difference: %.2e\n', relative_error);
    fprintf('뿯↽ Excellent agreement! Energy conserved.\n\n');
    
    % Show convergence of series
    figure('Position', [100, 100, 800, 600]);
    
    N_vals = 1:N_max;
    partial_energy = (a_0^2) / 2 * ones(size(N_vals));
    
    for n = 1:N_max
        a_n = (4*L^2 * (-1)^n) / (n^2 * pi^2);
        partial_energy(n:end) = partial_energy(n:end) + a_n^2;
    end
    
    plot(N_vals, partial_energy, 'b-', 'LineWidth', 2, ...
        'DisplayName', 'Partial sum');
    hold on;
    yline(energy_integral, 'r-', 'LineWidth', 2, ...
        'DisplayName', 'True energy');
    hold off;
    grid on;
    xlabel('Number of terms $N$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Energy', 'Interpreter', 'latex', 'FontSize', 12);
    title('Parseval''s Theorem: Convergence', 'Interpreter', 'latex', ...
        'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'southeast');
    
    fprintf('Parseval''s theorem verified!\n');
    fprintf('Physical interpretation: Total signal energy = sum of energies at each frequency\n');
end

function demonstrateFFT()
    % DEMONSTRATEFFT Show FFT efficiency
    %
    % Compare DFT (O(N뿯½)) vs FFT (O(N log N))
    
    fprintf('Fast Fourier Transform (FFT) Algorithm\n\n');
    fprintf('DFT complexity: O(N뿯½)\n');
    fprintf('FFT complexity: O(N log N)\n\n');
    
    % Create test signal
    fprintf('Test signal: sum of sinusoids + noise\n\n');
    
    Fs = 1000;  % Sampling frequency
    T = 1;      % Duration
    N = Fs * T; % Number of samples
    
    t = (0:N-1) / Fs;
    
    % Composite signal
    f1 = 50;   % Hz
    f2 = 120;  % Hz
    f3 = 200;  % Hz
    
    signal = sin(2*pi*f1*t) + 0.5*sin(2*pi*f2*t) + 0.3*sin(2*pi*f3*t);
    signal = signal + 0.1*randn(size(t));  % Add noise
    
    % Timing comparison
    fprintf('=== Timing Comparison ===\n\n');
    
    N_values = 2.^(6:12);  % Powers of 2 for FFT efficiency
    time_dft = zeros(size(N_values));
    time_fft = zeros(size(N_values));
    
    fprintf('%10s  %15s  %15s  %10s\n', 'N', 'DFT (s)', 'FFT (s)', 'Speedup');
    fprintf('%s\n', repmat('-', 1, 60));
    
    for idx = 1:length(N_values)
        N_test = N_values(idx);
        x_test = signal(1:N_test);
        
        % DFT (naive implementation)
        tic;
        X_dft = naiveDFT(x_test);
        time_dft(idx) = toc;
        
        % FFT
        tic;
        X_fft = fft(x_test);
        time_fft(idx) = toc;
        
        speedup = time_dft(idx) / time_fft(idx);
        
        fprintf('%10d  %15.6f  %15.6f  %10.1f뿯½\n', ...
            N_test, time_dft(idx), time_fft(idx), speedup);
    end
    
    % Verify correctness
    X_dft = naiveDFT(signal);
    X_fft = fft(signal);
    max_diff = max(abs(X_dft - X_fft));
    
    fprintf('\nMaximum difference: %.2e\n', max_diff);
    fprintf('뿯↽ Results identical (within roundoff)\n\n');
    
    % Plot timing
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    loglog(N_values, time_dft, 'bo-', 'LineWidth', 2, 'MarkerSize', 8, ...
        'DisplayName', 'DFT');
    hold on;
    loglog(N_values, time_fft, 'rs-', 'LineWidth', 2, 'MarkerSize', 8, ...
        'DisplayName', 'FFT');
    
    % Reference lines
    loglog(N_values, N_values.^2 / N_values(1)^2 * time_dft(1), 'b-', ...
        'LineWidth', 1, 'DisplayName', '$O(N^2)$');
    loglog(N_values, (N_values .* log2(N_values)) / ...
        (N_values(1) * log2(N_values(1))) * time_fft(1), 'r-', ...
        'LineWidth', 1, 'DisplayName', '$O(N \log N)$');
    
    hold off;
    grid on;
    xlabel('Number of samples $N$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Computation time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('FFT vs DFT Timing', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest');
    
    subplot(1, 2, 2);
    semilogx(N_values, time_dft ./ time_fft, 'go-', 'LineWidth', 2, ...
        'MarkerSize', 8);
    grid on;
    xlabel('Number of samples $N$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Speedup factor', 'Interpreter', 'latex', 'FontSize', 12);
    title('FFT Speedup', 'Interpreter', 'latex', 'FontSize', 14);
    
    fprintf('FFT revolutionised signal processing!\n');
    fprintf('Essential for: audio, images, communications, radar, etc.\n');
end

function X = naiveDFT(x)
    % NAIVEDFT Direct DFT computation (O(N뿯½))
    
    N = length(x);
    X = zeros(1, N);
    
    for k = 0:N-1
        for n = 0:N-1
            X(k+1) = X(k+1) + x(n+1) * exp(-2i*pi*k*n/N);
        end
    end
end

function analyseCompositeSignal()
    % ANALYSECOMPOSITESIGNAL Spectral analysis of real signal
    
    fprintf('Spectral analysis: Identifying frequency components\n\n');
    
    % Create complex signal
    Fs = 1000;
    T = 2;
    t = 0:1/Fs:T-1/Fs;
    N = length(t);
    
    % Signal: mixture of frequencies
    f = [50, 75, 150, 200, 350];  % Hz
    A = [1.0, 0.7, 0.5, 0.8, 0.3]; % Amplitudes
    
    signal = zeros(size(t));
    for i = 1:length(f)
        signal = signal + A(i) * sin(2*pi*f(i)*t);
    end
    
    % Add noise
    signal = signal + 0.2*randn(size(t));
    
    fprintf('Signal contains %d frequencies:\n', length(f));
    for i = 1:length(f)
        fprintf('  f%d = %d Hz (amplitude %.1f)\n', i, f(i), A(i));
    end
    fprintf('\nAdded Gaussian noise (뿯ν = 0.2)\n\n');
    
    % Compute FFT
    X = fft(signal);
    
    % Frequency axis
    freq = (0:N-1) * (Fs/N);
    
    % Power spectral density
    PSD = abs(X).^2 / N;
    
    % Plot
    figure('Position', [100, 100, 1400, 900]);
    
    % Time domain
    subplot(3, 1, 1);
    plot(t(1:500), signal(1:500), 'b-', 'LineWidth', 1);
    grid on;
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 11);
    title('Time Domain Signal', 'Interpreter', 'latex', 'FontSize', 12);
    
    % Frequency domain (magnitude)
    subplot(3, 1, 2);
    plot(freq(1:N/2), abs(X(1:N/2)), 'b-', 'LineWidth', 1.5);
    hold on;
    for i = 1:length(f)
        xline(f(i), 'r-', sprintf('%d Hz', f(i)), 'LineWidth', 1.5, ...
            'LabelHorizontalAlignment', 'centre', 'FontSize', 10);
    end
    hold off;
    grid on;
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 11);
    title('Frequency Spectrum', 'Interpreter', 'latex', 'FontSize', 12);
    xlim([0 Fs/2]);
    
    % Power spectral density
    subplot(3, 1, 3);
    plot(freq(1:N/2), 10*log10(PSD(1:N/2)), 'b-', 'LineWidth', 1.5);
    grid on;
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Power (dB)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Power Spectral Density', 'Interpreter', 'latex', 'FontSize', 12);
    xlim([0 Fs/2]);
    
    % Find peaks
    [pks, locs] = findpeaks(abs(X(1:N/2)), 'MinPeakHeight', max(abs(X))*0.1);
    detected_freqs = freq(locs);
    
    fprintf('Detected frequencies:\n');
    for i = 1:length(detected_freqs)
        fprintf('  %.1f Hz\n', detected_freqs(i));
    end
    
    fprintf('\nAll signal frequencies successfully identified!\n');
end

function demonstrateFiltering()
    % DEMONSTRATEFILTERING Show low-pass, high-pass, band-pass filters
    
    fprintf('Signal Filtering in Frequency Domain\n\n');
    
    % Create noisy signal
    Fs = 1000;
    t = 0:1/Fs:1-1/Fs;
    N = length(t);
    
    % Clean signal: low frequency
    f_signal = 10;  % 10 Hz
    signal_clean = sin(2*pi*f_signal*t);
    
    % High-frequency noise
    noise = 0.5*sin(2*pi*150*t) + 0.3*sin(2*pi*250*t);
    
    signal_noisy = signal_clean + noise;
    
    fprintf('Signal: 10 Hz sine wave\n');
    fprintf('Noise: 150 Hz + 250 Hz components\n\n');
    
    % FFT
    X = fft(signal_noisy);
    freq = (0:N-1) * (Fs/N);
    
    % Low-pass filter (keep frequencies < 50 Hz)
    fprintf('Applying low-pass filter (cutoff = 50 Hz)...\n');
    X_lowpass = X;
    cutoff_low = 50;
    X_lowpass(freq > cutoff_low & freq < Fs - cutoff_low) = 0;
    signal_filtered_low = real(ifft(X_lowpass));
    
    % High-pass filter (keep frequencies > 100 Hz)
    fprintf('Applying high-pass filter (cutoff = 100 Hz)...\n');
    X_highpass = X;
    cutoff_high = 100;
    X_highpass(freq < cutoff_high | freq > Fs - cutoff_high) = 0;
    signal_filtered_high = real(ifft(X_highpass));
    
    % Band-pass filter (keep 140-160 Hz)
    fprintf('Applying band-pass filter (140-160 Hz)...\n\n');
    X_bandpass = X;
    band_low = 140;
    band_high = 160;
    mask = (freq < band_low | freq > band_high) & ...
           (freq < Fs - band_high | freq > Fs - band_low);
    X_bandpass(mask) = 0;
    signal_filtered_band = real(ifft(X_bandpass));
    
    % Plot results
    figure('Position', [100, 100, 1400, 1000]);
    
    % Original
    subplot(4, 2, 1);
    plot(t(1:200), signal_noisy(1:200), 'b-', 'LineWidth', 1);
    grid on;
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 10);
    title('Original (Noisy)', 'Interpreter', 'latex', 'FontSize', 11);
    
    subplot(4, 2, 2);
    plot(freq(1:N/2), abs(X(1:N/2)), 'b-', 'LineWidth', 1);
    grid on;
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 10);
    title('Spectrum', 'Interpreter', 'latex', 'FontSize', 11);
    xlim([0 300]);
    
    % Low-pass
    subplot(4, 2, 3);
    plot(t(1:200), signal_filtered_low(1:200), 'r-', 'LineWidth', 1);
    grid on;
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 10);
    title('Low-Pass Filtered', 'Interpreter', 'latex', 'FontSize', 11);
    
    subplot(4, 2, 4);
    plot(freq(1:N/2), abs(X_lowpass(1:N/2)), 'r-', 'LineWidth', 1);
    grid on;
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 10);
    title('Spectrum', 'Interpreter', 'latex', 'FontSize', 11);
    xlim([0 300]);
    
    % High-pass
    subplot(4, 2, 5);
    plot(t(1:200), signal_filtered_high(1:200), 'g-', 'LineWidth', 1);
    grid on;
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 10);
    title('High-Pass Filtered', 'Interpreter', 'latex', 'FontSize', 11);
    
    subplot(4, 2, 6);
    plot(freq(1:N/2), abs(X_highpass(1:N/2)), 'g-', 'LineWidth', 1);
    grid on;
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 10);
    title('Spectrum', 'Interpreter', 'latex', 'FontSize', 11);
    xlim([0 300]);
    
    % Band-pass
    subplot(4, 2, 7);
    plot(t(1:200), signal_filtered_band(1:200), 'm-', 'LineWidth', 1);
    grid on;
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 10);
    title('Band-Pass Filtered', 'Interpreter', 'latex', 'FontSize', 11);
    
    subplot(4, 2, 8);
    plot(freq(1:N/2), abs(X_bandpass(1:N/2)), 'm-', 'LineWidth', 1);
    grid on;
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 10);
    title('Spectrum', 'Interpreter', 'latex', 'FontSize', 11);
    xlim([0 300]);
    
    fprintf('Filtering complete!\n');
    fprintf('  • Low-pass: Removes high-frequency noise\n');
    fprintf('  • High-pass: Isolates high-frequency components\n');
    fprintf('  • Band-pass: Extracts specific frequency range\n');
end

function demonstrateWindows()
    % DEMONSTRATEWINDOWS Compare window functions
    
    fprintf('Window Functions for Spectral Analysis\n\n');
    
    N = 512;
    
    % Different windows
    w_rect = rectwin(N);
    w_hann = hann(N);
    w_hamming = hamming(N);
    w_blackman = blackman(N);
    
    % Plot windows
    figure('Position', [100, 100, 1400, 1000]);
    
    % Time domain
    subplot(2, 2, 1);
    n = 0:N-1;
    plot(n, w_rect, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Rectangular');
    hold on;
    plot(n, w_hann, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Hann');
    plot(n, w_hamming, 'g-', 'LineWidth', 1.5, 'DisplayName', 'Hamming');
    plot(n, w_blackman, 'm-', 'LineWidth', 1.5, 'DisplayName', 'Blackman');
    hold off;
    grid on;
    xlabel('Sample', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 11);
    title('Window Functions', 'Interpreter', 'latex', 'FontSize', 12);
    legend('Interpreter', 'latex', 'Location', 'south');
    
    % Frequency domain
    subplot(2, 2, 2);
    W_rect = 20*log10(abs(fft(w_rect, 4096)));
    W_hann = 20*log10(abs(fft(w_hann, 4096)));
    W_hamming = 20*log10(abs(fft(w_hamming, 4096)));
    W_blackman = 20*log10(abs(fft(w_blackman, 4096)));
    
    freq = linspace(0, 1, 2048);
    plot(freq, W_rect(1:2048) - max(W_rect), 'b-', 'LineWidth', 1.5);
    hold on;
    plot(freq, W_hann(1:2048) - max(W_hann), 'r-', 'LineWidth', 1.5);
    plot(freq, W_hamming(1:2048) - max(W_hamming), 'g-', 'LineWidth', 1.5);
    plot(freq, W_blackman(1:2048) - max(W_blackman), 'm-', 'LineWidth', 1.5);
    hold off;
    grid on;
    xlabel('Normalised frequency', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Magnitude (dB)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Frequency Response', 'Interpreter', 'latex', 'FontSize', 12);
    ylim([-100 5]);
    
    % Application example
    subplot(2, 1, 2);
    
    Fs = 1000;
    t = (0:N-1)/Fs;
    
    % Two close frequencies
    f1 = 100;
    f2 = 110;
    signal = sin(2*pi*f1*t) + sin(2*pi*f2*t);
    
    % Apply different windows
    X_rect = fft(signal .* w_rect');
    X_hann = fft(signal .* w_hann');
    
    freq_axis = (0:N/2-1) * (Fs/N);
    
    plot(freq_axis, abs(X_rect(1:N/2)), 'b-', 'LineWidth', 1.5, ...
        'DisplayName', 'Rectangular');
    hold on;
    plot(freq_axis, abs(X_hann(1:N/2)), 'r-', 'LineWidth', 1.5, ...
        'DisplayName', 'Hann');
    hold off;
    grid on;
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 11);
    title('Effect on Spectral Resolution (Two Close Frequencies)', ...
        'Interpreter', 'latex', 'FontSize', 12);
    legend('Interpreter', 'latex', 'Location', 'northeast');
    xlim([50 150]);
    
    fprintf('Window function properties:\n');
    fprintf('  • Rectangular: Narrowest main lobe, high sidelobes\n');
    fprintf('  • Hann: Good all-round performance\n');
    fprintf('  • Hamming: Lower first sidelobe than Hann\n');
    fprintf('  • Blackman: Lowest sidelobes, widest main lobe\n\n');
    
    fprintf('Trade-off: Frequency resolution vs spectral leakage\n');
end

function solveHeatEquation()
    % SOLVEHEATEQUATION Use Fourier series to solve heat PDE
    %
    % ∂u/∂t = 뿯ν ∂뿯½u/∂x뿯½
    % u(0,t) = u(L,t) = 0
    % u(x,0) = f(x)
    
    fprintf('Heat Equation via Fourier Series\n');
    fprintf('PDE: ∂u/∂t = 뿯ν ∂뿯½u/∂x뿯½\n');
    fprintf('Boundary: u(0,t) = u(L,t) = 0\n');
    fprintf('Initial: u(x,0) = sin(뿯νx/L) + 0.5sin(3뿯νx/L)\n\n');
    
    % Parameters
    L = 1;
    alpha = 0.01;
    
    % Fourier solution:
    % u(x,t) = 뿯ν b_n sin(n뿯νx/L) exp(-뿯ν(n뿯ν/L)뿯½ t)
    
    fprintf('Analytical solution (Fourier series):\n');
    fprintf('u(x,t) = 뿯ν b_n sin(n뿯νx/L) exp(-뿯ν(n뿯ν/L)뿯½ t)\n\n');
    
    % Initial coefficients
    b = [1, 0, 0.5, zeros(1, 47)];  % b_1 = 1, b_3 = 0.5
    
    % Spatial grid
    x = linspace(0, L, 200);
    
    % Time points
    times = [0, 0.5, 1, 2, 5, 10];
    
    fprintf('Computing solution at t = ');
    fprintf('%.1f ', times);
    fprintf('seconds\n\n');
    
    % Plot
    figure('Position', [100, 100, 1200, 800]);
    
    for idx = 1:length(times)
        t = times(idx);
        
        % Compute solution
        u = zeros(size(x));
        for n = 1:length(b)
            if b(n) ~= 0
                u = u + b(n) * sin(n*pi*x/L) * ...
                    exp(-alpha * (n*pi/L)^2 * t);
            end
        end
        
        subplot(2, 3, idx);
        plot(x, u, 'b-', 'LineWidth', 2);
        grid on;
        xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('$u(x,t)$', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('$t = %.1f$ s', t), 'Interpreter', 'latex', ...
            'FontSize', 12);
        ylim([-0.2, 1.6]);
    end
    
    fprintf('Observations:\n');
    fprintf('  • High-frequency modes decay faster (∝ exp(-n뿯½t))\n');
    fprintf('  • Solution smooths out over time\n');
    fprintf('  • Fourier method: analytical solution!\n');
end

function demonstrate2DFourier()
    % DEMONSTRATE2DFOURIER 2D FFT for image processing
    
    fprintf('2D Fourier Transform for Image Processing\n\n');
    
    % Create synthetic image
    N = 256;
    [X, Y] = meshgrid(linspace(-1, 1, N), linspace(-1, 1, N));
    
    % Image: sum of patterns
    img = sin(10*pi*X) + cos(15*pi*Y) + ...
          0.3*sin(20*pi*(X+Y)) + 0.2*randn(N);
    
    fprintf('Synthetic image: %d 뿯½ %d pixels\n', N, N);
    fprintf('Contains: periodic patterns + noise\n\n');
    
    % 2D FFT
    fprintf('Computing 2D FFT...\n');
    F = fft2(img);
    F_shifted = fftshift(F);  % Centre zero frequency
    
    % Magnitude spectrum
    magnitude = log(1 + abs(F_shifted));
    
    % Low-pass filter
    fprintf('Applying low-pass filter...\n');
    [U, V] = meshgrid(-N/2:N/2-1, -N/2:N/2-1);
    D = sqrt(U.^2 + V.^2);
    cutoff = 30;
    H_lowpass = double(D <= cutoff);
    
    F_filtered = F_shifted .* H_lowpass;
    img_filtered = real(ifft2(ifftshift(F_filtered)));
    
    % High-pass filter (edge detection)
    fprintf('Applying high-pass filter...\n');
    H_highpass = 1 - H_lowpass;
    F_highpass = F_shifted .* H_highpass;
    img_edges = real(ifft2(ifftshift(F_highpass)));
    
    % Plot
    figure('Position', [100, 100, 1400, 1000]);
    
    subplot(2, 3, 1);
    imagesc(img);
    colormap(gca, gray);
    colorbar;
    axis equal tight;
    title('Original Image', 'Interpreter', 'latex', 'FontSize', 12);
    
    subplot(2, 3, 2);
    imagesc(magnitude);
    colormap(gca, jet);
    colorbar;
    axis equal tight;
    title('Frequency Spectrum (log)', 'Interpreter', 'latex', 'FontSize', 12);
    
    subplot(2, 3, 3);
    imagesc(H_lowpass);
    colormap(gca, gray);
    colorbar;
    axis equal tight;
    title('Low-Pass Filter', 'Interpreter', 'latex', 'FontSize', 12);
    
    subplot(2, 3, 4);
    imagesc(img_filtered);
    colormap(gca, gray);
    colorbar;
    axis equal tight;
    title('Low-Pass Filtered (Smooth)', 'Interpreter', 'latex', 'FontSize', 12);
    
    subplot(2, 3, 5);
    imagesc(H_highpass);
    colormap(gca, gray);
    colorbar;
    axis equal tight;
    title('High-Pass Filter', 'Interpreter', 'latex', 'FontSize', 12);
    
    subplot(2, 3, 6);
    imagesc(img_edges);
    colormap(gca, gray);
    colorbar;
    axis equal tight;
    title('High-Pass Filtered (Edges)', 'Interpreter', 'latex', 'FontSize', 12);
    
    fprintf('\n2D Fourier analysis complete!\n');
    fprintf('Applications:\n');
    fprintf('  • Image compression (JPEG uses DCT)\n');
    fprintf('  • Noise removal\n');
    fprintf('  • Edge detection\n');
    fprintf('  • Pattern recognition\n');
end

% Execute
Problem9_FourierAnalysis();
