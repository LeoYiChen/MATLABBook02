%% chapter_AIforMechatronics_problem03_code.m
% Hyperparameter optimisation using Bayesian optimisation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem03_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 3: Hyperparameter Optimisation for Deep Neural Networks
% Author: Dr Yi Chen
% Purpose: Implement Bayesian optimisation for neural network hyperparameters
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox, Statistics and Machine Learning
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Generate synthetic robot manipulator dataset
fprintf('=== Hyperparameter Optimisation for Torque Prediction ===\n\n');
fprintf('Step 1: Generating synthetic manipulator dataset...\n');

% Robot parameters (3-DOF manipulator)
linkLengths = [0.5, 0.3, 0.2]; % metres
linkMasses = [2.0, 1.5, 1.0]; % kg
gravity = 9.81; % m/s^2

% Generate random trajectories
numSamples = 2000;
numJoints = 3;

% Joint positions, velocities, accelerations
jointPositions = 2 * pi * rand(numSamples, numJoints) - pi;
jointVelocities = 2 * rand(numSamples, numJoints) - 1;
jointAccelerations = rand(numSamples, numJoints) - 0.5;

% Compute joint torques using simplified dynamics
jointTorques = zeros(numSamples, numJoints);

for sampleIdx = 1:numSamples
    q = jointPositions(sampleIdx, :)';
    qDot = jointVelocities(sampleIdx, :)';
    qDDot = jointAccelerations(sampleIdx, :)';
    
    % Simplified inverse dynamics (gravity + inertia terms)
    for jointIdx = 1:numJoints
        % Inertia term
        inertia = linkMasses(jointIdx) * linkLengths(jointIdx)^2 / 3;
        inertiaTorque = inertia * qDDot(jointIdx);
        
        % Gravity term
        effectiveLength = sum(linkLengths(1:jointIdx)) / 2;
        gravityTorque = linkMasses(jointIdx) * gravity * ...
            effectiveLength * cos(sum(q(1:jointIdx)));
        
        % Coriolis/centrifugal (simplified)
        centripetalTorque = 0.1 * linkMasses(jointIdx) * ...
            qDot(jointIdx)^2 * linkLengths(jointIdx);
        
        jointTorques(sampleIdx, jointIdx) = inertiaTorque + ...
            gravityTorque + centripetalTorque;
    end
end

% Add measurement noise
jointTorques = jointTorques + 0.05 * randn(size(jointTorques));

% Create input features and targets
inputFeatures = [jointPositions, jointVelocities, jointAccelerations];
targetOutputs = jointTorques;

fprintf('  Generated %d samples\n', numSamples);
fprintf('  Input features: %d (positions, velocities, accelerations)\n', ...
    size(inputFeatures, 2));
fprintf('  Output targets: %d (joint torques)\n', size(targetOutputs, 2));

%% Step 2: Split dataset
fprintf('\nStep 2: Splitting dataset...\n');

trainRatio = 0.70;
valRatio = 0.15;
testRatio = 0.15;

[trainIdx, valIdx, testIdx] = dividerand(numSamples, ...
    trainRatio, valRatio, testRatio);

XTrain = inputFeatures(trainIdx, :);
YTrain = targetOutputs(trainIdx, :);
XVal = inputFeatures(valIdx, :);
YVal = targetOutputs(valIdx, :);
XTest = inputFeatures(testIdx, :);
YTest = targetOutputs(testIdx, :);

fprintf('  Training samples: %d\n', length(trainIdx));
fprintf('  Validation samples: %d\n', length(valIdx));
fprintf('  Test samples: %d\n', length(testIdx));

%% Step 3: Define hyperparameter search space
fprintf('\nStep 3: Defining hyperparameter search space...\n');

% Optimisable hyperparameters
learningRateRange = optimizableVariable('LearningRate', [1e-5, 1e-1], 'Transform', 'log');
l2RegularisationRange = optimizableVariable('L2Regularization', [1e-6, 1e-2], 'Transform', 'log');
numLayersRange = optimizableVariable('NumLayers', [1, 4], 'Type', 'integer');
neuronsPerLayerRange = optimizableVariable('NeuronsPerLayer', [16, 128], 'Type', 'integer');
batchSizeRange = optimizableVariable('BatchSize', [8, 64], 'Type', 'integer');

hyperparameters = [learningRateRange, l2RegularisationRange, ...
    numLayersRange, neuronsPerLayerRange, batchSizeRange];

fprintf('  Learning rate: [1e-5, 1e-1] (log scale)\n');
fprintf('  L2 regularisation: [1e-6, 1e-2] (log scale)\n');
fprintf('  Number of layers: [1, 4]\n');
fprintf('  Neurons per layer: [16, 128]\n');
fprintf('  Batch size: [8, 64]\n');

%% Step 4: Define objective function for optimisation
fprintf('\nStep 4: Defining objective function...\n');

objectiveFunction = @(hyperparams) trainAndEvaluateNetwork(hyperparams, ...
    XTrain, YTrain, XVal, YVal, numJoints);

fprintf('  Objective: Minimise validation RMSE\n');

%% Step 5: Run Bayesian optimisation
fprintf('\nStep 5: Running Bayesian optimisation...\n');
fprintf('  This may take several minutes...\n\n');

% Bayesian optimisation settings
bayesOptOptions = struct(...
    'MaxObjectiveEvaluations', 30, ...
    'IsObjectiveDeterministic', false, ...
    'UseParallel', false, ...
    'AcquisitionFunctionName', 'expected-improvement-plus', ...
    'Verbose', 1);

tic;
bayesOptResults = bayesopt(objectiveFunction, hyperparameters, ...
    'MaxObjectiveEvaluations', bayesOptOptions.MaxObjectiveEvaluations, ...
    'IsObjectiveDeterministic', bayesOptOptions.IsObjectiveDeterministic, ...
    'UseParallel', bayesOptOptions.UseParallel, ...
    'AcquisitionFunctionName', bayesOptOptions.AcquisitionFunctionName, ...
    'Verbose', bayesOptOptions.Verbose, ...
    'PlotFcn', []);
optimisationTime = toc;

fprintf('\nBayesian optimisation completed in %.2f seconds\n', optimisationTime);

%% Step 6: Extract best hyperparameters
bestHyperparams = bayesOptResults.XAtMinObjective;
bestValidationRMSE = bayesOptResults.MinObjective;

fprintf('\nBest hyperparameters found:\n');
fprintf('  Learning rate: %.6f\n', bestHyperparams.LearningRate);
fprintf('  L2 regularisation: %.6f\n', bestHyperparams.L2Regularization);
fprintf('  Number of layers: %d\n', bestHyperparams.NumLayers);
fprintf('  Neurons per layer: %d\n', bestHyperparams.NeuronsPerLayer);
fprintf('  Batch size: %d\n', bestHyperparams.BatchSize);
fprintf('  Best validation RMSE: %.4f Nm\n', bestValidationRMSE);

%% Step 7: Train final model with best hyperparameters
fprintf('\nStep 7: Training final model with optimal hyperparameters...\n');

% Build network with best architecture
layers = featureInputLayer(size(XTrain, 2), 'Name', 'input');

for layerIdx = 1:bestHyperparams.NumLayers
    layers = [layers
        fullyConnectedLayer(bestHyperparams.NeuronsPerLayer, ...
            'Name', sprintf('fc%d', layerIdx))
        reluLayer('Name', sprintf('relu%d', layerIdx))];
end

layers = [layers
    fullyConnectedLayer(numJoints, 'Name', 'output')
    regressionLayer('Name', 'regression')];

% Training options with best hyperparameters
trainingOptions = trainingOptions('adam', ...
    'InitialLearnRate', bestHyperparams.LearningRate, ...
    'L2Regularization', bestHyperparams.L2Regularization, ...
    'MiniBatchSize', bestHyperparams.BatchSize, ...
    'MaxEpochs', 100, ...
    'ValidationData', {XVal', YVal'}, ...
    'ValidationFrequency', 10, ...
    'Verbose', false, ...
    'Plots', 'none');

% Train final network
finalNetwork = trainNetwork(XTrain', YTrain', layers, trainingOptions);

fprintf('  Final model training completed\n');

%% Step 8: Evaluate on test set
fprintf('\nStep 8: Evaluating on test set...\n');

predictedTorques = predict(finalNetwork, XTest')';
testRMSE = sqrt(mean((predictedTorques - YTest).^2, 'all'));
testMAE = mean(abs(predictedTorques - YTest), 'all');
testR2 = 1 - sum((YTest - predictedTorques).^2, 'all') / ...
    sum((YTest - mean(YTest, 1)).^2, 'all');

fprintf('  Test RMSE: %.4f Nm\n', testRMSE);
fprintf('  Test MAE: %.4f Nm\n', testMAE);
fprintf('  Test R-squared: %.4f\n', testR2);

%% Step 9: Visualisation
fprintf('\nStep 9: Generating visualisations...\n');

% Plot optimisation progress
figure('Name', 'Bayesian Optimisation Results', ...
    'Position', [100, 100, 1200, 800]);

subplot(2, 2, 1);
plot(bayesOptResults.ObjectiveTrace, 'b-o', 'LineWidth', 1.5);
xlabel('Iteration', 'Interpreter', 'latex');
ylabel('Validation RMSE (Nm)', 'Interpreter', 'latex');
title('Optimisation Progress', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

% Plot predicted vs actual torques
subplot(2, 2, 2);
hold on;
for jointIdx = 1:numJoints
    scatter(YTest(:, jointIdx), predictedTorques(:, jointIdx), 30, ...
        'filled', 'DisplayName', sprintf('Joint %d', jointIdx));
end
plot([min(YTest(:)), max(YTest(:))], [min(YTest(:)), max(YTest(:))], ...
    'k-', 'LineWidth', 2, 'DisplayName', 'Perfect Prediction');
xlabel('Actual Torque (Nm)', 'Interpreter', 'latex');
ylabel('Predicted Torque (Nm)', 'Interpreter', 'latex');
title('Predicted vs Actual Torques', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Plot error distribution
subplot(2, 2, 3);
predictionErrors = YTest - predictedTorques;
histogram(predictionErrors(:), 30, 'FaceColor', [0.3, 0.6, 0.9]);
xlabel('Prediction Error (Nm)', 'Interpreter', 'latex');
ylabel('Frequency', 'Interpreter', 'latex');
title('Prediction Error Distribution', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

% Plot per-joint RMSE
subplot(2, 2, 4);
jointRMSE = sqrt(mean((predictedTorques - YTest).^2, 1));
bar(1:numJoints, jointRMSE, 'FaceColor', [0.8, 0.4, 0.4]);
xlabel('Joint Index', 'Interpreter', 'latex');
ylabel('RMSE (Nm)', 'Interpreter', 'latex');
title('Per-Joint Prediction Error', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

suptitle('Hyperparameter Optimisation Results', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 3 completed successfully.\n');

%% Helper function: Train and evaluate network
function validationRMSE = trainAndEvaluateNetwork(hyperparams, ...
    XTrain, YTrain, XVal, YVal, numOutputs)
    % Extract hyperparameters
    learningRate = hyperparams.LearningRate;
    l2Regularisation = hyperparams.L2Regularization;
    numLayers = hyperparams.NumLayers;
    neuronsPerLayer = hyperparams.NeuronsPerLayer;
    batchSize = hyperparams.BatchSize;
    
    % Build network architecture
    layers = featureInputLayer(size(XTrain, 2), 'Name', 'input');
    
    for layerIdx = 1:numLayers
        layers = [layers
            fullyConnectedLayer(neuronsPerLayer, ...
                'Name', sprintf('fc%d', layerIdx))
            reluLayer('Name', sprintf('relu%d', layerIdx))];
    end
    
    layers = [layers
        fullyConnectedLayer(numOutputs, 'Name', 'output')
        regressionLayer('Name', 'regression')];
    
    % Training options
    options = trainingOptions('adam', ...
        'InitialLearnRate', learningRate, ...
        'L2Regularization', l2Regularisation, ...
        'MiniBatchSize', batchSize, ...
        'MaxEpochs', 50, ...
        'Verbose', false, ...
        'Plots', 'none');
    
    % Train network
    try
        trainedNetwork = trainNetwork(XTrain', YTrain', layers, options);
        
        % Predict on validation set
        predictions = predict(trainedNetwork, XVal')';
        
        % Compute validation RMSE
        validationRMSE = sqrt(mean((predictions - YVal).^2, 'all'));
    catch
        % Return large error if training fails
        validationRMSE = 1e6;
    end
end
