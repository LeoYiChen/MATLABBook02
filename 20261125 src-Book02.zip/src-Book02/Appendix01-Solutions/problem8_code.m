%% problem8_code.m
% Privacy-Preserving Federated Learning for DER Forecasting
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem8_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Privacy-Preserving Federated Learning for DER Forecasting
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-17
% Description: Implements federated learning with differential privacy for
%              distributed energy resource forecasting preserving privacy

clear; close all; clc;

%% 1. Distributed Household Dataset Generation
fprintf('========================================\n');
fprintf('Privacy-Preserving Federated Learning - DER Forecasting\n');
fprintf('========================================\n\n');

fprintf('Step 1: Generating heterogeneous household consumption data...\n');

rng(147); % Reproducibility

numHouseholds = 50;
numHours = 720; % 30 days hourly data

% Household types (heterogeneous distributions)
householdTypes = randi([1, 3], numHouseholds, 1);
% 1-Residential (60%), 2-Commercial (30%), 3-Industrial (10%)
typeDistribution = [0.6, 0.3, 0.1];
householdTypes = randsample(1:3, numHouseholds, true, typeDistribution);

% Generate consumption patterns
householdData = cell(numHouseholds, 1);

for householdIdx = 1:numHouseholds
    householdType = householdTypes(householdIdx);
    
    % Time features
    hourOfDay = mod((1:numHours)' - 1, 24) + 1;
    dayOfWeek = mod(floor(((1:numHours)' - 1) / 24), 7) + 1;
    
    % Type-specific patterns
    switch householdType
        case 1 % Residential
            baseDemand = 2 + randn();
            peakHours = [8, 19]; % Morning and evening
            dailyPattern = 0.5 + 0.3 * exp(-((hourOfDay - peakHours(1)).^2) / 20) + ...
                          0.4 * exp(-((hourOfDay - peakHours(2)).^2) / 20);
            
        case 2 % Commercial
            baseDemand = 15 + 3 * randn();
            dailyPattern = zeros(numHours, 1);
            dailyPattern(hourOfDay >= 9 & hourOfDay <= 18) = 1; % Business hours
            dailyPattern(dayOfWeek >= 6) = 0.2; % Weekend reduction
            
        case 3 % Industrial
            baseDemand = 50 + 10 * randn();
            dailyPattern = 0.9 + 0.1 * randn(numHours, 1); % Relatively flat
    end
    
    % Generate consumption
    consumption = baseDemand * dailyPattern + 0.5 * randn(numHours, 1);
    consumption = max(consumption, 0);
    
    % Store with features
    householdData{householdIdx}.type = householdType;
    householdData{householdIdx}.consumption = consumption;
    householdData{householdIdx}.hourOfDay = hourOfDay;
end

fprintf('Generated data for %d households:\n', numHouseholds);
fprintf('  Residential: %d households\n', sum(householdTypes == 1));
fprintf('  Commercial: %d households\n', sum(householdTypes == 2));
fprintf('  Industrial: %d households\n', sum(householdTypes == 3));
fprintf('  Time series length: %d hours\n\n', numHours);

%% 2. Data Preparation for Forecasting
fprintf('Step 2: Preparing supervised learning datasets...\n');

% Create supervised learning problem: predict next hour from past 6 hours
numLags = 6;

for householdIdx = 1:numHouseholds
    consumption = householdData{householdIdx}.consumption;
    
    features = [];
    targets = [];
    
    for t = (numLags + 1):numHours
        featureVec = consumption(t-numLags:t-1)';
        features = [features; featureVec];
        targets = [targets; consumption(t)];
    end
    
    % Split: 80% train, 20% test
    trainSize = floor(0.8 * size(features, 1));
    
    householdData{householdIdx}.XTrain = features(1:trainSize, :);
    householdData{householdIdx}.YTrain = targets(1:trainSize);
    householdData{householdIdx}.XTest = features(trainSize+1:end, :);
    householdData{householdIdx}.YTest = targets(trainSize+1:end);
end

fprintf('Supervised dataset created: %d lags   next hour prediction\n', numLags);
fprintf('Train/test split: 80/20 per household\n\n');

%% 3. Centralised Training Baseline
fprintf('Step 3: Training centralised baseline model...\n');

% Pool all training data
XTrainCentral = [];
YTrainCentral = [];
XTestCentral = [];
YTestCentral = [];

for householdIdx = 1:numHouseholds
    XTrainCentral = [XTrainCentral; householdData{householdIdx}.XTrain];
    YTrainCentral = [YTrainCentral; householdData{householdIdx}.YTrain];
    XTestCentral = [XTestCentral; householdData{householdIdx}.XTest];
    YTestCentral = [YTestCentral; householdData{householdIdx}.YTest];
end

% Normalise
[XTrainCentralNorm, muCentral, sigmaCentral] = zscore(XTrainCentral);
YTrainCentralNorm = (YTrainCentral - mean(YTrainCentral)) / std(YTrainCentral);
XTestCentralNorm = (XTestCentral - muCentral) ./ sigmaCentral;
YTestCentralNorm = (YTestCentral - mean(YTrainCentral)) / std(YTrainCentral);

% Train linear regression (simplified)
betaCentral = XTrainCentralNorm \ YTrainCentralNorm;

% Predictions
YPredCentralNorm = XTestCentralNorm * betaCentral;
YPredCentral = YPredCentralNorm * std(YTrainCentral) + mean(YTrainCentral);

% Evaluate
rmseCentral = sqrt(mean((YTestCentral - YPredCentral).^2));

fprintf('Centralised model trained (linear regression)\n');
fprintf('  Training samples: %d (pooled from all households)\n', size(XTrainCentral, 1));
fprintf('  Test RMSE: %.3f kWh\n\n', rmseCentral);

%% 4. Federated Learning Implementation
fprintf('Step 4: Implementing federated learning (FedAvg)...\n');

numRounds = 20;
learningRate = 0.01;

% Initialise global model
betaGlobal = randn(numLags, 1) * 0.01;

% Storage for convergence tracking
federatedLosses = zeros(numRounds, 1);

fprintf('Federated learning: %d communication rounds\n', numRounds);

for round = 1:numRounds
    % Local updates from each household
    localBetas = zeros(numLags, numHouseholds);
    
    for householdIdx = 1:numHouseholds
        % Get local data
        XLocal = householdData{householdIdx}.XTrain;
        YLocal = householdData{householdIdx}.YTrain;
        
        % Normalise locally
        XLocalNorm = (XLocal - mean(XLocal)) ./ std(XLocal);
        YLocalNorm = (YLocal - mean(YLocal)) / std(YLocal);
        
        % Local gradient descent step (1 epoch)
        betaLocal = betaGlobal;
        
        % Compute gradient
        predictions = XLocalNorm * betaLocal;
        residuals = predictions - YLocalNorm;
        gradient = (XLocalNorm' * residuals) / size(XLocalNorm, 1);
        
        % Update
        betaLocal = betaLocal - learningRate * gradient;
        
        localBetas(:, householdIdx) = betaLocal;
    end
    
    % Aggregate: simple averaging (FedAvg)
    betaGlobal = mean(localBetas, 2);
    
    % Evaluate global model on test data
    YPredFedNorm = XTestCentralNorm * betaGlobal;
    YPredFed = YPredFedNorm * std(YTrainCentral) + mean(YTrainCentral);
    
    rmseFederated = sqrt(mean((YTestCentral - YPredFed).^2));
    federatedLosses(round) = rmseFederated;
    
    if mod(round, 5) == 0
        fprintf('  Round %d: Test RMSE = %.3f kWh\n', round, rmseFederated);
    end
end

fprintf('Federated learning completed\n');
fprintf('  Final test RMSE: %.3f kWh (vs %.3f centralised)\n\n', ...
        rmseFederated, rmseCentral);

%% 5. Privacy Leakage Analysis
fprintf('Step 5: Analysing privacy leakage in federated learning...\n');

% Compute gradient norms (proxy for information leakage)
gradientNorms = zeros(numHouseholds, 1);

for householdIdx = 1:numHouseholds
    XLocal = householdData{householdIdx}.XTrain;
    YLocal = householdData{householdIdx}.YTrain;
    
    XLocalNorm = (XLocal - mean(XLocal)) ./ std(XLocal);
    YLocalNorm = (YLocal - mean(YLocal)) / std(YLocal);
    
    predictions = XLocalNorm * betaGlobal;
    residuals = predictions - YLocalNorm;
    gradient = (XLocalNorm' * residuals) / size(XLocalNorm, 1);
    
    gradientNorms(householdIdx) = norm(gradient);
end

fprintf('Gradient Analysis:\n');
fprintf('  Mean gradient norm: %.4f\n', mean(gradientNorms));
fprintf('  Gradient norm range: [%.4f, %.4f]\n', min(gradientNorms), max(gradientNorms));
fprintf('  Privacy risk: Gradient magnitudes leak information about local data scale\n\n');

%% 6. Differentially Private Federated Learning
fprintf('Step 6: Implementing differential privacy for federated learning...\n');

% DP parameters
epsilonValues = [0.5, 1.0, 5.0, 10.0];
delta = 1e-5;
clipNorm = 0.5; % Gradient clipping threshold

numEpsilons = length(epsilonValues);
dpResults = struct();

for epsIdx = 1:numEpsilons
    epsilon = epsilonValues(epsIdx);
    
    % Reset global model
    betaGlobalDP = randn(numLags, 1) * 0.01;
    
    % Federated learning with DP
    for round = 1:numRounds
        localBetasDP = zeros(numLags, numHouseholds);
        
        for householdIdx = 1:numHouseholds
            XLocal = householdData{householdIdx}.XTrain;
            YLocal = householdData{householdIdx}.YTrain;
            
            XLocalNorm = (XLocal - mean(XLocal)) ./ std(XLocal);
            YLocalNorm = (YLocal - mean(YLocal)) / std(YLocal);
            
            betaLocal = betaGlobalDP;
            
            % Compute gradient
            predictions = XLocalNorm * betaLocal;
            residuals = predictions - YLocalNorm;
            gradient = (XLocalNorm' * residuals) / size(XLocalNorm, 1);
            
            % Gradient clipping
            gradNorm = norm(gradient);
            if gradNorm > clipNorm
                gradient = gradient * (clipNorm / gradNorm);
            end
            
            % Add Gaussian noise calibrated to privacy budget
            noiseScale = (clipNorm * sqrt(2 * log(1.25 / delta))) / epsilon;
            noisyGradient = gradient + noiseScale * randn(size(gradient));
            
            % Update
            betaLocal = betaLocal - learningRate * noisyGradient;
            
            localBetasDP(:, householdIdx) = betaLocal;
        end
        
        % Aggregate
        betaGlobalDP = mean(localBetasDP, 2);
    end
    
    % Evaluate DP model
    YPredDPNorm = XTestCentralNorm * betaGlobalDP;
    YPredDP = YPredDPNorm * std(YTrainCentral) + mean(YTrainCentral);
    
    rmseDPFederated = sqrt(mean((YTestCentral - YPredDP).^2));
    
    dpResults(epsIdx).epsilon = epsilon;
    dpResults(epsIdx).rmse = rmseDPFederated;
    dpResults(epsIdx).accuracyDegradation = rmseDPFederated - rmseFederated;
    
    fprintf('  DP-FL (epsilon=%.1f): RMSE=%.3f kWh, Degradation=+%.3f kWh\n', ...
            epsilon, rmseDPFederated, dpResults(epsIdx).accuracyDegradation);
end

fprintf('\n');

%% 7. Fairness Analysis Across Household Types
fprintf('Step 7: Evaluating fairness of DP noise across household types...\n');

% Evaluate per-type accuracy for centralised, federated, and DP-federated
typeNames = {'Residential', 'Commercial', 'Industrial'};

for typeIdx = 1:3
    typeMask = householdTypes == typeIdx;
    typeIndices = find(typeMask);
    
    % Collect test data for this type
    XTestType = [];
    YTestType = [];
    
    for householdIdx = typeIndices'
        XTestType = [XTestType; householdData{householdIdx}.XTest];
        YTestType = [YTestType; householdData{householdIdx}.YTest];
    end
    
    if isempty(XTestType)
        continue;
    end
    
    % Normalise
    XTestTypeNorm = (XTestType - muCentral) ./ sigmaCentral;
    
    % Centralised predictions
    YPredTypeNorm = XTestTypeNorm * betaCentral;
    YPredType = YPredTypeNorm * std(YTrainCentral) + mean(YTrainCentral);
    rmseCentralType = sqrt(mean((YTestType - YPredType).^2));
    
    % Federated predictions
    YPredFedTypeNorm = XTestTypeNorm * betaGlobal;
    YPredFedType = YPredFedTypeNorm * std(YTrainCentral) + mean(YTrainCentral);
    rmseFederatedType = sqrt(mean((YTestType - YPredFedType).^2));
    
    % DP-Federated predictions (epsilon=1.0)
    betaGlobalDP1 = betaGlobalDP; % From epsilon=1.0 training above (reuse)
    YPredDPTypeNorm = XTestTypeNorm * betaGlobalDP1;
    YPredDPType = YPredDPTypeNorm * std(YTrainCentral) + mean(YTrainCentral);
    rmseDPType = sqrt(mean((YTestType - YPredDPType).^2));
    
    fprintf('  %s (%d households):\n', typeNames{typeIdx}, sum(typeMask));
    fprintf('    Centralised: %.3f kWh\n', rmseCentralType);
    fprintf('    Federated: %.3f kWh\n', rmseFederatedType);
    fprintf('    DP-Federated (eps=1.0): %.3f kWh\n', rmseDPType);
    fprintf('    DP degradation: +%.3f kWh\n', rmseDPType - rmseFederatedType);
end

fprintf('\n');

%% 8. Visualisation
fprintf('Step 8: Generating visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: Federated Learning Convergence
fig1 = figure('Position', [100, 100, 1400, 500]);

subplot(1, 2, 1);
plot(1:numRounds, federatedLosses, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
yline(rmseCentral, 'r-', 'LineWidth', 2, 'DisplayName', 'Centralised Baseline');
xlabel('Communication Round', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Test RMSE (kWh)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Federated Learning Convergence}', 'Interpreter', 'latex', 'FontSize', 12);
legend('Federated', 'Centralised', 'Interpreter', 'latex', 'Location', 'best');
grid on;

subplot(1, 2, 2);
histogram(gradientNorms, 15, 'FaceColor', [0.4, 0.6, 0.8]);
xlabel('Gradient Norm', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Number of Households', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Gradient Leakage Analysis}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle('\textbf{Federated Learning Performance and Privacy}', ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig1, 'figures/Problem8_Federated_Convergence.fig');
saveas(fig1, 'figures/Problem8_Federated_Convergence.eps', 'epsc');
saveas(fig1, 'figures/Problem8_Federated_Convergence.jpg');
fprintf('Saved: Problem8_Federated_Convergence\n');

% Figure 2: Privacy-Utility Trade-off
fig2 = figure('Position', [150, 150, 1000, 500]);

epsilonPlot = [dpResults.epsilon];
rmsePlot = [dpResults.rmse];

semilogx(epsilonPlot, rmsePlot, 'ro-', 'LineWidth', 2, 'MarkerSize', 8);
hold on;
yline(rmseCentral, 'b-', 'LineWidth', 2, 'DisplayName', 'Centralised');
yline(rmseFederated, 'g-', 'LineWidth', 2, 'DisplayName', 'Federated (no DP)');

xlabel('Privacy Budget $\varepsilon$ (lower = more private)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Test RMSE (kWh)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Privacy-Utility Trade-off: DP-Federated Learning}', 'Interpreter', 'latex', 'FontSize', 12);
legend('DP-Federated', 'Centralised', 'Federated', 'Interpreter', 'latex', 'Location', 'best');
grid on;

saveas(fig2, 'figures/Problem8_Privacy_Utility_Tradeoff.fig');
saveas(fig2, 'figures/Problem8_Privacy_Utility_Tradeoff.eps', 'epsc');
saveas(fig2, 'figures/Problem8_Privacy_Utility_Tradeoff.jpg');
fprintf('Saved: Problem8_Privacy_Utility_Tradeoff\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');
