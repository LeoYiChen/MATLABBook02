%% chapter_CFDPrinciples_example_scheme_selection.m
% Discretisation scheme selection logic.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_scheme_selection
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function discretisationScheme = selectDiscretisationScheme(flowRegime, ...
    numericalPreferences, meshQuality)
    % SELECTDISCRETISATIONSCHEME Recommend numerical schemes
    % Selects spatial and temporal discretisation based on flow physics
    %
    % Inputs:
    %   flowRegime            - Struct from identifyFlowRegime()
    %   numericalPreferences  - Struct: accuracyPriority (bool), 
    %                           stabilityPriority (bool), speedPriority (bool)
    %   meshQuality           - Struct: cellPecletNumber, cellReynolds, 
    %                           aspectRatio, skewness
    %
    % Output:
    %   discretisationScheme  - Recommended discretisation configuration
    %
    % Author: Dr Leo Chen
    % Institution: University of Cambridge
    % Version: 3.0
    %
    % References:
    %   [1] Patankar (1980) Numerical Heat Transfer and Fluid Flow
    %   [2] Blazek (2015) Computational Fluid Dynamics
    
    fprintf('=== Discretisation Scheme Selection ===\n\n');
    
    discretisationScheme = struct();
    
    % Spatial scheme selection
    spatialScheme = selectSpatialScheme(flowRegime, numericalPreferences, ...
                                        meshQuality);
    discretisationScheme.spatial = spatialScheme;
    
    % Temporal scheme selection (if unsteady)
    if isfield(flowRegime, 'temporal') && strcmp(flowRegime.temporal, 'unsteady')
        temporalScheme = selectTemporalScheme(flowRegime, numericalPreferences);
        discretisationScheme.temporal = temporalScheme;
    else
        discretisationScheme.temporal = 'steady_state';
    end
    
    % Pressure-velocity coupling
    pressureVelocityCoupling = selectPressureCoupling(flowRegime, ...
                                                      numericalPreferences);
    discretisationScheme.pressureVelocity = pressureVelocityCoupling;
    
    % Gradient computation
    gradientScheme = selectGradientScheme(meshQuality);
    discretisationScheme.gradient = gradientScheme;
    
    % Display recommendations
    displaySchemeRecommendations(discretisationScheme);
    
    fprintf('\nDiscretisation scheme selection completed.\n');
end

function spatialScheme = selectSpatialScheme(regime, prefs, meshQuality)
    % Select spatial discretisation scheme
    
    spatialScheme = struct();
    
    % Convection scheme selection based on cell Peclet number
    if isfield(meshQuality, 'cellPecletNumber')
        Pe = meshQuality.cellPecletNumber;
        
        if Pe < 2
            % Diffusion-dominated: central differencing acceptable
            if prefs.accuracyPriority
                spatialScheme.convection = 'central_differencing_2nd_order';
            else
                spatialScheme.convection = 'central_differencing_2nd_order';
            end
            
        elseif Pe < 10
            % Moderate Peclet: hybrid or higher-order upwind
            if prefs.accuracyPriority
                spatialScheme.convection = 'QUICK_3rd_order';
            elseif prefs.stabilityPriority
                spatialScheme.convection = 'second_order_upwind';
            else
                spatialScheme.convection = 'hybrid_central_upwind';
            end
            
        else
            % Convection-dominated: upwind essential
            if prefs.accuracyPriority && ~contains(regime.compressibility, 'sonic')
                spatialScheme.convection = 'MUSCL_2nd_order_TVD';
            else
                spatialScheme.convection = 'second_order_upwind';
            end
        end
    else
        % Default recommendation
        spatialScheme.convection = 'second_order_upwind';
    end
    
    % Diffusion scheme (typically central differencing)
    spatialScheme.diffusion = 'central_differencing_2nd_order';
    
    % Shock capturing (if compressible with discontinuities)
    if contains(regime.compressibility, 'sonic') || ...
       strcmp(regime.compressibility, 'supersonic')
        spatialScheme.shockCapture = 'TVD_or_WENO_limiter';
    else
        spatialScheme.shockCapture = 'not_required';
    end
    
    % Interpolation scheme
    if prefs.accuracyPriority
        spatialScheme.interpolation = 'linear_or_quadratic';
    else
        spatialScheme.interpolation = 'linear';
    end
end

function temporalScheme = selectTemporalScheme(regime, prefs)
    % Select temporal discretisation scheme
    
    temporalScheme = struct();
    
    % Explicit vs implicit
    if prefs.stabilityPriority || strcmp(regime.turbulence, 'turbulent')
        % Implicit schemes for stability
        if prefs.accuracyPriority
            temporalScheme.timeIntegration = 'second_order_implicit_Crank_Nicolson';
        else
            temporalScheme.timeIntegration = 'first_order_implicit_Euler';
        end
        temporalScheme.CFLrestriction = 'relaxed_CFL_up_to_10';
        
    else
        % Explicit schemes for simplicity (if stable)
        if prefs.accuracyPriority
            temporalScheme.timeIntegration = 'Runge_Kutta_4th_order';
        else
            temporalScheme.timeIntegration = 'explicit_Euler_1st_order';
        end
        temporalScheme.CFLrestriction = 'strict_CFL_less_than_1';
    end
    
    % Time-step adaptivity
    if prefs.accuracyPriority
        temporalScheme.adaptiveTimeStep = true;
        temporalScheme.adaptivityCriterion = 'local_truncation_error_estimate';
    else
        temporalScheme.adaptiveTimeStep = false;
    end
end

function coupling = selectPressureCoupling(regime, prefs)
    % Select pressure-velocity coupling algorithm
    
    coupling = struct();
    
    if strcmp(regime.compressibility, 'incompressible')
        % Incompressible: segregated or coupled algorithms
        if prefs.speedPriority
            coupling.algorithm = 'SIMPLE_or_SIMPLEC';
            coupling.description = 'Semi-Implicit Method for Pressure-Linked Equations';
        elseif prefs.accuracyPriority
            coupling.algorithm = 'PISO';
            coupling.description = 'Pressure-Implicit Split-Operator';
        else
            coupling.algorithm = 'SIMPLE';
            coupling.description = 'Standard SIMPLE algorithm';
        end
        
    else
        % Compressible: density-based coupling
        coupling.algorithm = 'coupled_density_based';
        coupling.description = 'Density-based solver for compressible flows';
    end
    
    % Under-relaxation factors
    if strcmp(coupling.algorithm, 'SIMPLE_or_SIMPLEC') || ...
       strcmp(coupling.algorithm, 'SIMPLE')
        coupling.underRelaxation = struct();
        coupling.underRelaxation.pressure = 0.3;
        coupling.underRelaxation.momentum = 0.7;
        coupling.underRelaxation.energy = 0.8;
    end
end

function gradScheme = selectGradientScheme(meshQuality)
    % Select gradient computation method
    
    gradScheme = struct();
    
    if isfield(meshQuality, 'skewness') && meshQuality.skewness > 0.4
        % High skewness: least-squares or iterative correction
        gradScheme.method = 'least_squares_with_correction';
        gradScheme.iterations = 2;
    else
        % Low skewness: standard Green-Gauss
        gradScheme.method = 'Green_Gauss_cell_based';
    end
end

function displaySchemeRecommendations(scheme)
    % Display discretisation recommendations
    
    fprintf('Spatial Discretisation:\n');
    fprintf('  Convection: %s\n', scheme.spatial.convection);
    fprintf('  Diffusion: %s\n', scheme.spatial.diffusion);
    fprintf('  Gradient: %s\n', scheme.gradient.method);
    
    if ~strcmp(scheme.temporal, 'steady_state')
        fprintf('\nTemporal Discretisation:\n');
        fprintf('  Time integration: %s\n', scheme.temporal.timeIntegration);
        fprintf('  CFL restriction: %s\n', scheme.temporal.CFLrestriction);
    end
    
    fprintf('\nPressure-Velocity Coupling:\n');
    fprintf('  Algorithm: %s\n', scheme.pressureVelocity.algorithm);
    fprintf('  Description: %s\n', scheme.pressureVelocity.description);
end
