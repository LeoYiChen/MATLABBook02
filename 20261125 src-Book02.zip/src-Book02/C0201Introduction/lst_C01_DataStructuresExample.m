%% lst_C01_DataStructuresExample.m
% Basic data structures in MATLAB demonstrating arrays, cell arrays, structures, and tables
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : lst:C01_DataStructuresExample
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create a 3*x3 matrix - the fundamental MATLAB data type
A = [1 2 3; 4 5 6; 7 8 9];

% Cell array with mixed data types
C = {A, 'text', 3.14, @sin};  % Matrix, string, scalar, function handle

% Structure with hierarchical fields
experiment.data = A;
experiment.date = '2023-01-15';
experiment.parameters = struct('temperature', 295, 'pressure', 101.3);

% Table with named variables (modern approach for tabular data)
T = table(["Sample1"; "Sample2"; "Sample3"], ...
          [10; 15; 20], ...
          [true; false; true], ...
          'VariableNames', {'SampleID', 'Value', 'Passed'});

disp(T)
