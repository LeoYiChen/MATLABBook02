%% chapter_FundamentalMathematics_example_LinearSystems.m
% Solving linear systems in MATLAB using different methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_LinearSystems
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Solving Linear Systems: Multiple Approaches
% Demonstrates different methods for solving Ax = b

% Define a well-conditioned system
coefficientMatrix = [4, 1, 2; 1, 5, 1; 2, 1, 6];
rightHandSide = [10; 12; 14];

% Method 1: Backslash operator (recommended, automatic selection)
solutionBackslash = coefficientMatrix \ rightHandSide;

% Method 2: Matrix inverse (not recommended for large systems)
solutionInverse = inv(coefficientMatrix) * rightHandSide;

% Method 3: LU decomposition (explicit factorisation)
[lowerTriangular, upperTriangular, permutation] = ...
    lu(coefficientMatrix);
intermediateY = lowerTriangular \ (permutation * rightHandSide);
solutionLU = upperTriangular \ intermediateY;

% Method 4: Iterative methods for large sparse systems
% Using conjugate gradient method
solutionIterative = pcg(coefficientMatrix, rightHandSide, 1e-10, 100);

% Verify solutions by computing residuals
residualBackslash = norm(coefficientMatrix * solutionBackslash - rightHandSide);
residualInverse = norm(coefficientMatrix * solutionInverse - rightHandSide);
residualLU = norm(coefficientMatrix * solutionLU - rightHandSide);
residualIterative = norm(coefficientMatrix * solutionIterative - rightHandSide);

% Display results
fprintf('Solution using backslash operator:\n');
fprintf('x = [%.6f, %.6f, %.6f]^T\n', solutionBackslash);
fprintf('Residual: %.2e\n\n', residualBackslash);

fprintf('Solution using matrix inverse:\n');
fprintf('x = [%.6f, %.6f, %.6f]^T\n', solutionInverse);
fprintf('Residual: %.2e\n\n', residualInverse);

fprintf('Solution using LU decomposition:\n');
fprintf('x = [%.6f, %.6f, %.6f]^T\n', solutionLU);
fprintf('Residual: %.2e\n\n', residualLU);

fprintf('Solution using iterative method (PCG):\n');
fprintf('x = [%.6f, %.6f, %.6f]^T\n', solutionIterative);
fprintf('Residual: %.2e\n', residualIterative);

% Check condition number (measure of numerical stability)
conditionNumber = cond(coefficientMatrix);
fprintf('\nCondition number: %.2f\n', conditionNumber);
fprintf('(Lower is better; <100 is well-conditioned)\n');
