%% prob5_polar_syntax.m
% Polar plot syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob5_polar_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create polar plot
polarplot(theta, r, 'LineWidth', 2);
% Customise appearance
rlim([0, maxValue]);
thetaticks(0:30:330);
title('Polar Plot Title');
