%% chapter_CFDPrinciples_example_validation.m
% Systematic validation assessment framework.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_validation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function validationResults = performValidation(cfdData, experimentalData, ...
    uncertainties, validationMetrics)
    % PERFORMVALIDATION Systematic validation against experimental data
    % Implements ASME V&V 20-2009 validation methodology
    %
    % Inputs:
    %   cfdData          - Struct: CFD predictions for validation quantities
    %   experimentalData - Struct: experimental measurements
    %   uncertainties    - Struct: numerical, modelling, experimental uncertainties
    %   validationMetrics- Cell array: metrics to compute
    %
    % Output:
    %   validationResults - Comprehensive validation assessment
    %
    % Author: Dr Leo Chen
    % Institution: University of Oxford
    % Version: 3.0
    %
    % References:
    %   [1] ASME V&V 20-2009: Standard for V&V in CFD and Heat Transfer
    %   [2] Oberkampf & Roy (2010) Verification and Validation
    %   [3] Roache (1998) Verification and Validation in CFD
    
    fprintf('=== Validation Assessment ===\n\n');
    
    validationResults = struct();
    validationResults.timestamp = datetime('now');
    
    % Extract validation quantities
    quantities = fieldnames(experimentalData);
    numQuantities = length(quantities);
    
    fprintf('Number of validation quantities: %d\n\n', numQuantities);
    
    % Initialise results storage
    validationResults.quantities = cell(numQuantities, 1);
    
    % Process each validation quantity
    for i = 1:numQuantities
        qtyName = quantities{i};
        
        fprintf('Processing: %s\n', qtyName);
        
        % Extract data
        cfdValues = cfdData.(qtyName);
        expValues = experimentalData.(qtyName);
        
        % Extract uncertainties
        if isfield(uncertainties, qtyName)
            qtyUncert = uncertainties.(qtyName);
        else
            qtyUncert = struct('numerical', 0, 'modelling', 0, 'experimental', 0);
        end
        
        % Compute validation metrics
        qtyResults = computeValidationMetrics(cfdValues, expValues, ...
                                             qtyUncert, validationMetrics);
        
        qtyResults.name = qtyName;
        validationResults.quantities{i} = qtyResults;
        
        fprintf('  Complete\n\n');
    end
    
    % Overall validation assessment
    validationResults.overallAssessment = assessOverallValidation(validationResults);
    
    % Generate validation report
    generateValidationReport(validationResults);
    
    % Visualise validation results
    visualiseValidation(validationResults);
    
    fprintf('Validation assessment completed.\n');
end

function qtyResults = computeValidationMetrics(cfdVals, expVals, uncert, metrics)
    % Compute validation metrics for a single quantity
    
    qtyResults = struct();
    
    % Ensure arrays are column vectors
    cfdVals = cfdVals(:);
    expVals = expVals(:);
    
    numPoints = length(expVals);
    
    % Basic error measures
    errors = cfdVals - expVals;
    
    qtyResults.errors = errors;
    qtyResults.numPoints = numPoints;
    
    % Mean error (bias)
    meanError = mean(errors);
    qtyResults.meanError = meanError;
    
    % Root mean square error
    rmse = sqrt(mean(errors.^2));
    qtyResults.RMSE = rmse;
    
    % Mean absolute error
    mae = mean(abs(errors));
    qtyResults.MAE = mae;
    
    % Maximum absolute error
    maxError = max(abs(errors));
    qtyResults.maxError = maxError;
    
    % Normalised RMSE (by experimental range)
    expRange = max(expVals) - min(expVals);
    
    if expRange > 1e-12
        normRMSE = rmse / expRange;
        qtyResults.normRMSE = normRMSE;
    else
        qtyResults.normRMSE = NaN;
    end
    
    % Coefficient of determination (R?)
    expMean = mean(expVals);
    SS_tot = sum((expVals - expMean).^2);
    SS_res = sum(errors.^2);
    
    if SS_tot > 1e-12
        R2 = 1 - SS_res/SS_tot;
        qtyResults.R2 = R2;
    else
        qtyResults.R2 = NaN;
    end
    
    % Correlation coefficient
    if std(cfdVals) > 1e-12 && std(expVals) > 1e-12
        corrCoef = corr(cfdVals, expVals);
        qtyResults.correlationCoef = corrCoef;
    else
        qtyResults.correlationCoef = NaN;
    end
    
    % Validation metric (with uncertainties)
    % Following ASME V&V 20-2009
    U_num = uncert.numerical;      % Numerical uncertainty
    U_model = uncert.modelling;    % Modelling uncertainty
    U_exp = uncert.experimental;   % Experimental uncertainty
    
    % Combined simulation uncertainty
    U_sim = sqrt(U_num^2 + U_model^2);
    
    % Combined validation uncertainty
    U_val = sqrt(U_sim^2 + U_exp^2);
    
    qtyResults.U_numerical = U_num;
    qtyResults.U_modelling = U_model;
    qtyResults.U_experimental = U_exp;
    qtyResults.U_simulation = U_sim;
    qtyResults.U_validation = U_val;
    
    % Validation comparison error
    E = meanError;  % Could also use RMSE
    
    qtyResults.validationError = E;
    
    % Validation assessment
    if abs(E) < U_val
        qtyResults.validated = true;
        qtyResults.validationStatus = 'VALIDATED';
    else
        qtyResults.validated = false;
        qtyResults.validationStatus = 'NOT VALIDATED';
    end
    
    % Error factor (ratio of error to uncertainty)
    if U_val > 1e-12
        errorFactor = abs(E) / U_val;
        qtyResults.errorFactor = errorFactor;
    else
        qtyResults.errorFactor = Inf;
    end
    
    fprintf('  RMSE: %.6e\n', rmse);
    fprintf('  R?: %.4f\n', R2);
    fprintf('  Validation error: %.6e\n', E);
    fprintf('  Validation uncertainty: %.6e\n', U_val);
    fprintf('  Status: %s\n', qtyResults.validationStatus);
end

function overallAssess = assessOverallValidation(valResults)
    % Assess overall validation status
    
    numQuantities = length(valResults.quantities);
    
    validatedCount = 0;
    totalPoints = 0;
    
    avgR2 = 0;
    avgErrorFactor = 0;
    
    for i = 1:numQuantities
        qty = valResults.quantities{i};
        
        if qty.validated
            validatedCount = validatedCount + 1;
        end
        
        totalPoints = totalPoints + qty.numPoints;
        
        if ~isnan(qty.R2)
            avgR2 = avgR2 + qty.R2;
        end
        
        if ~isinf(qty.errorFactor)
            avgErrorFactor = avgErrorFactor + qty.errorFactor;
        end
    end
    
    avgR2 = avgR2 / numQuantities;
    avgErrorFactor = avgErrorFactor / numQuantities;
    
    overallAssess = struct();
    overallAssess.numQuantities = numQuantities;
    overallAssess.numValidated = validatedCount;
    overallAssess.validationRate = validatedCount / numQuantities;
    overallAssess.totalDataPoints = totalPoints;
    overallAssess.avgR2 = avgR2;
    overallAssess.avgErrorFactor = avgErrorFactor;
    
    % Overall verdict
    if validatedCount == numQuantities
        overallAssess.verdict = 'FULLY VALIDATED';
    elseif validatedCount >= 0.8 * numQuantities
        overallAssess.verdict = 'LARGELY VALIDATED';
    elseif validatedCount >= 0.5 * numQuantities
        overallAssess.verdict = 'PARTIALLY VALIDATED';
    else
        overallAssess.verdict = 'INSUFFICIENTLY VALIDATED';
    end
end

function generateValidationReport(valResults)
    % Generate comprehensive validation report
    
    fprintf('\n=== VALIDATION REPORT ===\n\n');
    
    fprintf('OVERALL ASSESSMENT:\n');
    fprintf('  Verdict: %s\n', valResults.overallAssessment.verdict);
    fprintf('  Validated quantities: %d/%d (%.1f%%)\n', ...
            valResults.overallAssessment.numValidated, ...
            valResults.overallAssessment.numQuantities, ...
            valResults.overallAssessment.validationRate * 100);
    fprintf('  Average R?: %.4f\n', valResults.overallAssessment.avgR2);
    fprintf('  Average error factor: %.2f\n\n', ...
            valResults.overallAssessment.avgErrorFactor);
    
    fprintf('DETAILED RESULTS:\n\n');
    
    for i = 1:length(valResults.quantities)
        qty = valResults.quantities{i};
        
        fprintf('  Quantity: %s\n', qty.name);
        fprintf('    Data points: %d\n', qty.numPoints);
        fprintf('    RMSE: %.6e\n', qty.RMSE);
        fprintf('    MAE: %.6e\n', qty.MAE);
        fprintf('    R?: %.4f\n', qty.R2);
        fprintf('    Correlation: %.4f\n', qty.correlationCoef);
        fprintf('    \n');
        fprintf('    Uncertainties:\n');
        fprintf('      Numerical: %.6e\n', qty.U_numerical);
        fprintf('      Modelling: %.6e\n', qty.U_modelling);
        fprintf('      Experimental: %.6e\n', qty.U_experimental);
        fprintf('      Validation: %.6e\n', qty.U_validation);
        fprintf('    \n');
        fprintf('    Validation error: %.6e\n', qty.validationError);
        fprintf('    Error factor: %.2f\n', qty.errorFactor);
        fprintf('    Status: %s\n\n', qty.validationStatus);
    end
    
    fprintf('=== END OF REPORT ===\n');
end

function visualiseValidation(valResults)
    % Visualise validation results
    
    numQuantities = length(valResults.quantities);
    
    figure('Name', 'Validation Assessment', 'Position', [100, 100, 1400, 900]);
    
    % Determine subplot layout
    numRows = ceil(sqrt(numQuantities));
    numCols = ceil(numQuantities / numRows);
    
    for i = 1:numQuantities
        qty = valResults.quantities{i};
        
        subplot(numRows, numCols, i);
        
        % Parity plot (CFD vs Experiment)
        if isfield(qty, 'errors')
            expVals = (1:qty.numPoints)';  % Placeholder - should be actual exp values
            cfdVals = expVals + qty.errors;
            
            % Plot data points
            plot(expVals, cfdVals, 'bo', 'MarkerSize', 6, 'MarkerFaceColor', 'b');
            hold on;
            
            % Perfect agreement line
            minVal = min([expVals; cfdVals]);
            maxVal = max([expVals; cfdVals]);
            plot([minVal, maxVal], [minVal, maxVal], 'k--', 'LineWidth', 1.5);
            
            % Uncertainty bands
            if isfield(qty, 'U_validation')
                U = qty.U_validation;
                
                plot([minVal, maxVal], [minVal+U, maxVal+U], 'r--', 'LineWidth', 1);
                plot([minVal, maxVal], [minVal-U, maxVal-U], 'r--', 'LineWidth', 1);
            end
            
            xlabel('Experimental', 'Interpreter', 'latex');
            ylabel('CFD', 'Interpreter', 'latex');
            title(sprintf('%s (R?=%.3f)', qty.name, qty.R2), 'Interpreter', 'latex');
            grid on;
            axis equal;
            
            % Add validation status
            if qty.validated
                text(0.05, 0.95, 'VALIDATED', 'Units', 'normalized', ...
                     'Color', 'g', 'FontWeight', 'bold', 'FontSize', 10);
            else
                text(0.05, 0.95, 'NOT VALIDATED', 'Units', 'normalized', ...
                     'Color', 'r', 'FontWeight', 'bold', 'FontSize', 10);
            end
        end
    end
    
    sgtitle('Validation: CFD vs Experimental Data', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
end
