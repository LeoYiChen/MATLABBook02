%% chapter_AIforMechatronics_problem11_code.m
% Bio-inspired wind turbine blade optimisation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem11_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 11: Bio-Inspired Wind Turbine Blade Optimisation
% Author: Dr Yi Chen
% Purpose: Optimise flexible wind turbine blades using bio-inspired principles
% MATLAB Version: R2023b or later
% Required Toolboxes: Global Optimization Toolbox, Statistics Toolbox
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Define blade geometry parameters
fprintf('=== Bio-Inspired Wind Turbine Blade Optimisation ===\n\n');
fprintf('Step 1: Defining blade geometry parameters...\n');

% Turbine specifications
rotorDiameter = 80; % metres
rotorRadius = rotorDiameter / 2;
numBlades = 3;
ratedPower = 2e6; % 2 MW
hubRadius = 1.5; % metres

% Spanwise discretisation
numSections = 20;
rSpan = linspace(hubRadius, rotorRadius, numSections)';

% Design variables (normalised 0-1, will be scaled)
% x = [chord_root, chord_mid, chord_tip, twist_root, twist_mid, twist_tip,
%      thickness_ratio, flexibility_factor]

fprintf('  Rotor diameter: %.1f m\n', rotorDiameter);
fprintf('  Rated power: %.2f MW\n', ratedPower / 1e6);
fprintf('  Number of blades: %d\n', numBlades);
fprintf('  Span sections: %d\n', numSections);

%% Step 2: Define aerodynamic model (BEM theory)
fprintf('\nStep 2: Implementing Blade Element Momentum theory...\n');

% Air properties
airDensity = 1.225; % kg/m
kinematicViscosity = 1.5e-5; % m/s

% Operating conditions
windSpeedRated = 12; % m/s
tipSpeedRatio = 7; % optimal TSR
rotorSpeed = windSpeedRated * tipSpeedRatio / rotorRadius; % rad/s
rotorRPM = rotorSpeed * 60 / (2 * pi);

fprintf('  Rated wind speed: %.1f m/s\n', windSpeedRated);
fprintf('  Tip speed ratio: %.1f\n', tipSpeedRatio);
fprintf('  Rotor speed: %.2f RPM\n', rotorRPM);

% Airfoil data (simplified NACA 4-digit series)
% In practice, use experimental Cl, Cd data
alphaRange = linspace(-10, 20, 100); % degrees
Cl = @(alpha) 2 * pi * alpha * pi/180 .* (alpha < 15) + ...
    (1.5 - 0.05 * (alpha - 15)) .* (alpha >= 15); % Simplified lift
Cd = @(alpha) 0.008 + 0.02 * (alpha * pi/180).^2; % Simplified drag

%% Step 3: Define objective functions
fprintf('\nStep 3: Defining multi-objective optimisation problem...\n');

% Objective 1: Maximise power coefficient C_P
% Objective 2: Minimise blade mass
% Objective 3: Minimise peak stress (for fatigue life)

% Design variable bounds
% [chord_root, chord_mid, chord_tip, twist_root, twist_mid, twist_tip,
%  thickness_ratio, flexibility_factor]
lb = [2.0, 1.5, 0.5, 10, 5, 0, 0.15, 0.5];
ub = [4.0, 3.0, 1.5, 20, 12, 5, 0.25, 1.5];

nvars = length(lb);

fprintf('  Design variables: %d\n', nvars);
fprintf('  Objectives: 3 (C_P, mass, stress)\n');

%% Step 4: Implement BEM analysis function
fprintf('\nStep 4: Implementing BEM analysis...\n');

% BEM analysis for given blade design
bemAnalysis = @(chordDist, twistDist, windSpeed) ...
    computeBEM(chordDist, twistDist, rSpan, windSpeed, rotorSpeed, ...
    airDensity, Cl, Cd, numBlades);

%% Step 5: Implement structural analysis
fprintf('\nStep 5: Implementing structural analysis...\n');

% Material properties (composite)
compositeDensity = 1600; % kg/m
compositeModulus = 40e9; % Pa (E-glass/epoxy)
compositeStrength = 500e6; % Pa

%% Step 6: Define multi-objective function
fprintf('\nStep 6: Setting up multi-objective optimisation...\n');

objectiveFunction = @(x) evaluateBladeDesign(x, rSpan, bemAnalysis, ...
    compositeDensity, compositeModulus, compositeStrength, windSpeedRated);

%% Step 7: Run baseline (conventional) design
fprintf('\nStep 7: Evaluating baseline conventional design...\n');

% Conventional design (linear taper, linear twist)
x_baseline = [3.0, 2.0, 1.0, 15, 8, 2, 0.20, 1.0];

[objectives_baseline, outputs_baseline] = objectiveFunction(x_baseline);

fprintf('  Baseline design:\n');
fprintf('    Power coefficient C_P: %.4f\n', -objectives_baseline(1));
fprintf('    Blade mass: %.1f kg\n', objectives_baseline(2));
fprintf('    Peak stress: %.2f MPa\n', objectives_baseline(3) / 1e6);
fprintf('    Annual energy: %.2f MWh\n', outputs_baseline.annualEnergy / 1e6);

%% Step 8: Multi-objective optimisation using GA
fprintf('\nStep 8: Running multi-objective genetic algorithm...\n');

% NSGA-II options
options = optimoptions('gamultiobj', ...
    'PopulationSize', 100, ...
    'MaxGenerations', 50, ...
    'Display', 'off', ...
    'PlotFcn', []);

fprintf('  Population size: %d\n', options.PopulationSize);
fprintf('  Max generations: %d\n', options.MaxGenerations);
fprintf('  Running optimisation (this may take several minutes)...\n');

tic;
[x_pareto, fval_pareto] = gamultiobj(objectiveFunction, nvars, ...
    [], [], [], [], lb, ub, options);
optimTime = toc;

numParetoSolutions = size(x_pareto, 1);

fprintf('  Optimisation completed in %.1f seconds\n', optimTime);
fprintf('  Pareto-optimal solutions found: %d\n', numParetoSolutions);

%% Step 9: Select best bio-inspired design
fprintf('\nStep 9: Selecting best bio-inspired design...\n');

% Find solution with maximum C_P subject to mass and stress constraints
massLimit = objectives_baseline(2) * 0.9; % 10% mass reduction target
stressLimit = objectives_baseline(3) * 1.1; % Allow 10% higher stress

feasibleIdx = (fval_pareto(:,2) <= massLimit) & ...
    (fval_pareto(:,3) <= stressLimit);

if sum(feasibleIdx) > 0
    feasibleSolutions = fval_pareto(feasibleIdx, :);
    feasibleDesigns = x_pareto(feasibleIdx, :);
    
    % Select design with maximum C_P
    [~, bestIdx] = min(feasibleSolutions(:, 1)); % Minimising -C_P
    x_optimal = feasibleDesigns(bestIdx, :);
    objectives_optimal = feasibleSolutions(bestIdx, :);
else
    % If no feasible solution, select best compromise
    fprintf('  Warning: No solution meets all constraints\n');
    fprintf('  Selecting best compromise...\n');
    
    % Normalise objectives and find minimum Euclidean distance
    fval_norm = (fval_pareto - min(fval_pareto)) ./ ...
        (max(fval_pareto) - min(fval_pareto));
    distances = sqrt(sum(fval_norm.^2, 2));
    [~, bestIdx] = min(distances);
    
    x_optimal = x_pareto(bestIdx, :);
    objectives_optimal = fval_pareto(bestIdx, :);
end

[~, outputs_optimal] = objectiveFunction(x_optimal);

fprintf('  Optimal bio-inspired design:\n');
fprintf('    Power coefficient C_P: %.4f\n', -objectives_optimal(1));
fprintf('    Blade mass: %.1f kg\n', objectives_optimal(2));
fprintf('    Peak stress: %.2f MPa\n', objectives_optimal(3) / 1e6);
fprintf('    Annual energy: %.2f MWh\n', outputs_optimal.annualEnergy / 1e6);

%% Step 10: Performance comparison
fprintf('\nStep 10: Comparing baseline vs bio-inspired design...\n');

% Improvements
cpImprovement = (-objectives_optimal(1) - (-objectives_baseline(1))) / ...
    (-objectives_baseline(1)) * 100;
massReduction = (objectives_baseline(2) - objectives_optimal(2)) / ...
    objectives_baseline(2) * 100;
energyGain = (outputs_optimal.annualEnergy - outputs_baseline.annualEnergy) / ...
    outputs_baseline.annualEnergy * 100;

fprintf('  Performance improvements:\n');
fprintf('    C_P increase: %.2f%%\n', cpImprovement);
fprintf('    Mass reduction: %.2f%%\n', massReduction);
fprintf('    Annual energy gain: %.2f%%\n', energyGain);

%% Step 11: Turbulence sensitivity analysis
fprintf('\nStep 11: Analysing turbulence robustness...\n');

% IEC turbulence categories
turbulenceIntensities = [0.12, 0.14, 0.16, 0.18]; % A, B, C, D
numTurbLevels = length(turbulenceIntensities);

cpBaseline_turb = zeros(numTurbLevels, 1);
cpOptimal_turb = zeros(numTurbLevels, 1);

for ti = 1:numTurbLevels
    TI = turbulenceIntensities(ti);
    
    % Simulate turbulent wind (simplified)
    windSpeeds = windSpeedRated * (1 + TI * randn(1000, 1));
    windSpeeds = max(0, windSpeeds); % No negative wind
    
    % Baseline performance
    [chordBase, twistBase] = designToGeometry(x_baseline, rSpan);
    cpValues_base = zeros(length(windSpeeds), 1);
    for wi = 1:length(windSpeeds)
        [cpValues_base(wi), ~, ~] = bemAnalysis(chordBase, twistBase, windSpeeds(wi));
    end
    cpBaseline_turb(ti) = mean(cpValues_base);
    
    % Optimal performance
    [chordOpt, twistOpt] = designToGeometry(x_optimal, rSpan);
    cpValues_opt = zeros(length(windSpeeds), 1);
    for wi = 1:length(windSpeeds)
        [cpValues_opt(wi), ~, ~] = bemAnalysis(chordOpt, twistOpt, windSpeeds(wi));
    end
    cpOptimal_turb(ti) = mean(cpValues_opt);
end

fprintf('  Turbulence robustness analysis completed\n');

%% Step 12: Visualisation
fprintf('\nStep 12: Generating visualisations...\n');

figure('Name', 'Bio-Inspired Blade Optimisation', ...
    'Position', [100, 100, 1400, 900]);

% Pareto front
subplot(2, 3, 1);
scatter3(-fval_pareto(:,1), fval_pareto(:,2), fval_pareto(:,3)/1e6, ...
    30, 'b', 'filled', 'MarkerFaceAlpha', 0.5);
hold on;
scatter3(-objectives_baseline(1), objectives_baseline(2), ...
    objectives_baseline(3)/1e6, 200, 'r', 'filled', 'MarkerEdgeColor', 'k');
scatter3(-objectives_optimal(1), objectives_optimal(2), ...
    objectives_optimal(3)/1e6, 200, 'g', 'filled', 'MarkerEdgeColor', 'k');
xlabel('Power Coefficient $C_P$', 'Interpreter', 'latex');
ylabel('Mass (kg)', 'Interpreter', 'latex');
zlabel('Peak Stress (MPa)', 'Interpreter', 'latex');
title('Pareto Front', 'Interpreter', 'latex');
legend({'Pareto Solutions', 'Baseline', 'Optimal'}, ...
    'Interpreter', 'latex', 'Location', 'best');
grid on;
view(45, 30);
hold off;

% Blade geometry comparison
subplot(2, 3, 2);
[chordBase, twistBase] = designToGeometry(x_baseline, rSpan);
[chordOpt, twistOpt] = designToGeometry(x_optimal, rSpan);

yyaxis left;
plot(rSpan, chordBase, 'r-', 'LineWidth', 2, 'DisplayName', 'Baseline Chord');
hold on;
plot(rSpan, chordOpt, 'g-', 'LineWidth', 2, 'DisplayName', 'Optimal Chord');
ylabel('Chord (m)', 'Interpreter', 'latex');

yyaxis right;
plot(rSpan, twistBase, 'r:', 'LineWidth', 2, 'DisplayName', 'Baseline Twist');
plot(rSpan, twistOpt, 'g-.', 'LineWidth', 2, 'DisplayName', 'Optimal Twist');
ylabel('Twist (deg)', 'Interpreter', 'latex');

xlabel('Span Position (m)', 'Interpreter', 'latex');
title('Blade Geometry Comparison', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Performance across wind speeds
subplot(2, 3, 3);
windSpeedRange = 4:0.5:25;
cpBase_wind = zeros(size(windSpeedRange));
cpOpt_wind = zeros(size(windSpeedRange));

for wi = 1:length(windSpeedRange)
    [cpBase_wind(wi), ~, ~] = bemAnalysis(chordBase, twistBase, windSpeedRange(wi));
    [cpOpt_wind(wi), ~, ~] = bemAnalysis(chordOpt, twistOpt, windSpeedRange(wi));
end

plot(windSpeedRange, cpBase_wind, 'r-', 'LineWidth', 2, 'DisplayName', 'Baseline');
hold on;
plot(windSpeedRange, cpOpt_wind, 'g-', 'LineWidth', 2, 'DisplayName', 'Bio-Inspired');
xline(windSpeedRated, 'k:', 'LineWidth', 1.5, 'DisplayName', 'Rated Wind');
xlabel('Wind Speed (m/s)', 'Interpreter', 'latex');
ylabel('Power Coefficient $C_P$', 'Interpreter', 'latex');
title('Performance vs Wind Speed', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Turbulence sensitivity
subplot(2, 3, 4);
bar([cpBaseline_turb, cpOptimal_turb]);
set(gca, 'XTickLabel', {'12%', '14%', '16%', '18%'});
xlabel('Turbulence Intensity', 'Interpreter', 'latex');
ylabel('Mean $C_P$', 'Interpreter', 'latex');
title('Turbulence Robustness', 'Interpreter', 'latex');
legend({'Baseline', 'Bio-Inspired'}, 'Interpreter', 'latex');
grid on;

% Stress distribution
subplot(2, 3, 5);
stressBase = outputs_baseline.stressDistribution / 1e6; % MPa
stressOpt = outputs_optimal.stressDistribution / 1e6;

plot(rSpan, stressBase, 'r-', 'LineWidth', 2, 'DisplayName', 'Baseline');
hold on;
plot(rSpan, stressOpt, 'g-', 'LineWidth', 2, 'DisplayName', 'Bio-Inspired');
yline(compositeStrength/1e6, 'k:', 'LineWidth', 1.5, 'DisplayName', 'Material Limit');
xlabel('Span Position (m)', 'Interpreter', 'latex');
ylabel('von Mises Stress (MPa)', 'Interpreter', 'latex');
title('Stress Distribution', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Annual energy production
subplot(2, 3, 6);
categories = {'Baseline', 'Bio-Inspired'};
energyValues = [outputs_baseline.annualEnergy, outputs_optimal.annualEnergy] / 1e9; % GWh
bar(energyValues);
set(gca, 'XTickLabel', categories);
ylabel('Annual Energy (GWh)', 'Interpreter', 'latex');
title('Annual Energy Production', 'Interpreter', 'latex');
grid on;

suptitle('Bio-Inspired Wind Turbine Blade Optimisation Results', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 11 completed successfully.\n');

%% Helper Functions

function [objectives, outputs] = evaluateBladeDesign(x, rSpan, bemAnalysis, ...
    density, modulus, strength, windSpeedRated)
    % Evaluate blade design objectives
    
    % Extract geometry
    [chord, twist] = designToGeometry(x, rSpan);
    
    % Aerodynamic performance
    [cp, thrust, power] = bemAnalysis(chord, twist, windSpeedRated);
    
    % Structural analysis
    thickness = x(7); % thickness ratio
    flexibilityFactor = x(8);
    
    % Mass calculation
    bladeVolume = sum(chord .* (chord * thickness) .* diff([rSpan; rSpan(end)+1]));
    bladeMass = bladeVolume * density;
    
    % Stress calculation (simplified beam bending)
    momentArm = rSpan - rSpan(1);
    bendingMoment = thrust * momentArm;
    sectionModulus = (chord .* (chord * thickness).^2) / 6;
    stress = bendingMoment ./ (sectionModulus + 1e-10);
    stress = stress / flexibilityFactor; % Flexibility reduces stress
    
    peakStress = max(stress);
    
    % Annual energy (simplified Weibull distribution)
    weibullK = 2;
    weibullA = windSpeedRated / 0.85;
    cutIn = 4;
    cutOut = 25;
    windSpeeds = linspace(cutIn, cutOut, 100);
    weibullPDF = (weibullK / weibullA) * (windSpeeds / weibullA).^(weibullK-1) .* ...
        exp(-(windSpeeds / weibullA).^weibullK);
    
    energyProduction = zeros(size(windSpeeds));
    for wi = 1:length(windSpeeds)
        [cpLocal, ~, ~] = bemAnalysis(chord, twist, windSpeeds(wi));
        energyProduction(wi) = cpLocal * power * weibullPDF(wi);
    end
    
    annualEnergy = trapz(windSpeeds, energyProduction) * 8760; % hours/year
    
    % Objectives: [minimize -C_P, minimize mass, minimize peak stress]
    objectives = [-cp, bladeMass, peakStress];
    
    % Additional outputs
    outputs.cp = cp;
    outputs.mass = bladeMass;
    outputs.peakStress = peakStress;
    outputs.stressDistribution = stress;
    outputs.annualEnergy = annualEnergy;
end

function [chord, twist] = designToGeometry(x, rSpan)
    % Convert design variables to geometry distributions
    
    chordRoot = x(1);
    chordMid = x(2);
    chordTip = x(3);
    
    twistRoot = x(4);
    twistMid = x(5);
    twistTip = x(6);
    
    % Piecewise linear interpolation
    rMid = (rSpan(1) + rSpan(end)) / 2;
    
    chord = zeros(size(rSpan));
    twist = zeros(size(rSpan));
    
    for i = 1:length(rSpan)
        if rSpan(i) <= rMid
            t = (rSpan(i) - rSpan(1)) / (rMid - rSpan(1));
            chord(i) = chordRoot * (1 - t) + chordMid * t;
            twist(i) = twistRoot * (1 - t) + twistMid * t;
        else
            t = (rSpan(i) - rMid) / (rSpan(end) - rMid);
            chord(i) = chordMid * (1 - t) + chordTip * t;
            twist(i) = twistMid * (1 - t) + twistTip * t;
        end
    end
end

function [cp, thrust, power] = computeBEM(chordDist, twistDist, rSpan, ...
    windSpeed, rotorSpeed, airDensity, Cl_func, Cd_func, numBlades)
    % Simplified BEM analysis
    
    dr = diff([rSpan; rSpan(end) + (rSpan(end) - rSpan(end-1))]);
    
    thrust = 0;
    power = 0;
    
    for i = 1:length(rSpan)
        r = rSpan(i);
        chord = chordDist(i);
        twist = twistDist(i);
        
        % Local velocity
        omega = rotorSpeed;
        Vrel = sqrt(windSpeed^2 + (omega * r)^2);
        phi = atan2(windSpeed, omega * r) * 180/pi;
        
        % Angle of attack
        alpha = phi - twist;
        
        % Lift and drag
        cl = Cl_func(alpha);
        cd = Cd_func(alpha);
        
        % Forces
        L = 0.5 * airDensity * Vrel^2 * chord * dr(i) * cl;
        D = 0.5 * airDensity * Vrel^2 * chord * dr(i) * cd;
        
        % Thrust and tangential force
        dThrust = numBlades * (L * cosd(phi) + D * sind(phi));
        dTangential = numBlades * (L * sind(phi) - D * cosd(phi));
        
        thrust = thrust + dThrust;
        power = power + dTangential * omega * r;
    end
    
    % Power coefficient
    rotorArea = pi * rSpan(end)^2;
    availablePower = 0.5 * airDensity * windSpeed^3 * rotorArea;
    cp = power / (availablePower + 1e-10);
    cp = min(cp, 0.593); % Betz limit
end
