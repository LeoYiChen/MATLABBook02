%% chapter_Math_lab8_stats.m
% Statistical Hypothesis Testing Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab8_stats
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory
Lab8_StatisticalTesting();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab8_StatisticalTesting()
    % LAB8_STATISTICALTESTING Apply hypothesis tests to sensor data
    %   Comprehensive analysis including normality, t-tests, ANOVA, bootstrap
    
    fprintf('\\textbf{Laboratory 8: Statistical Hypothesis Testing}\n');
    fprintf('===================================================\n\n');
    
    % Generate synthetic sensor data (or load real data)
    generateSensorData();
    
    % Load the generated data
    load('sensor_data.mat', 'sensor1', 'sensor2', 'sensor3', 'sensor4', 'timestamps');
    
    % Task 1: Test for normality
    testNormality(sensor1, 'Sensor 1');
    testNormality(sensor2, 'Sensor 2');
    
    % Task 2: Two-sample comparison (t-tests)
    compareTwoSensors(sensor1, sensor2, 'Sensor 1', 'Sensor 2');
    
    % Task 3: Multiple sensor comparison (ANOVA)
    compareMultipleSensors(sensor1, sensor2, sensor3, sensor4);
    
    % Task 4: Bootstrap confidence intervals
    bootstrapAnalysis(sensor1, 'Sensor 1');
end

function generateSensorData()
    % GENERATESENSORDATA Create realistic sensor time-series
    %   Simulates temperature sensors with different characteristics
    
    rng(42);  % Reproducibility
    
    n = 500;  % Number of observations
    timestamps = (1:n)';
    
    % Sensor 1: Normal distribution with slight trend
    trend1 = 0.01 * timestamps;
    sensor1 = 20 + trend1 + 2*randn(n, 1);
    
    % Sensor 2: Normal distribution, slightly different mean
    trend2 = 0.01 * timestamps;
    sensor2 = 21 + trend2 + 2*randn(n, 1);
    
    % Sensor 3: Normal with higher variance
    trend3 = 0.01 * timestamps;
    sensor3 = 20.5 + trend3 + 3*randn(n, 1);
    
    % Sensor 4: Non-normal (exponential noise)
    trend4 = 0.01 * timestamps;
    sensor4 = 19 + trend4 + exprnd(2, n, 1);
    
    % Save data
    save('sensor_data.mat', 'sensor1', 'sensor2', 'sensor3', ...
        'sensor4', 'timestamps');
    
    fprintf('Generated synthetic sensor data (%d observations)\n\n', n);
end

function testNormality(data, sensorName)
    % TESTNORMALITY Apply multiple normality tests
    %   Uses: 1) Shapiro-Wilk, 2) Kolmogorov-Smirnov, 3) Anderson-Darling, 4) QQ-plot
    
    fprintf('\\textbf{Normality Testing: %s}\n', sensorName);
    fprintf('-------\n');
    
    % Remove any NaN values
    data = data(~isnan(data));
    n = length(data);
    
    % Descriptive statistics
    data_mean = mean(data);
    data_std = std(data);
    data_skew = skewness(data);
    data_kurt = kurtosis(data);
    
    fprintf('Sample size: %d\n', n);
    fprintf('Mean: %.4f\n', data_mean);
    fprintf('Std Dev: %.4f\n', data_std);
    fprintf('Skewness: %.4f (normal: 0)\n', data_skew);
    fprintf('Kurtosis: %.4f (normal: 3)\n', data_kurt);
    
    % 1. Shapiro-Wilk test (most powerful for small samples)
    if n <= 5000  % Shapiro-Wilk limited to n <= 5000 in MATLAB
        [h_sw, p_sw] = swtest(data, 0.05);
        fprintf('\nShapiro-Wilk Test:\n');
        fprintf('  p-value: %.4f\n', p_sw);
        fprintf('  Result: %s (α = 0.05)\n', interpretTest(h_sw));
    end
    
    % 2. Kolmogorov-Smirnov test
    [h_ks, p_ks] = kstest(zscore(data));
    fprintf('\nKolmogorov-Smirnov Test:\n');
    fprintf('  p-value: %.4f\n', p_ks);
    fprintf('  Result: %s (α = 0.05)\n', interpretTest(h_ks));
    
    % 3. Anderson-Darling test
    [h_ad, p_ad] = adtest(data);
    fprintf('\nAnderson-Darling Test:\n');
    fprintf('  p-value: %.4f\n', p_ad);
    fprintf('  Result: %s (α = 0.05)\n', interpretTest(h_ad));
    
    % 4. Jarque-Bera test (based on skewness and kurtosis)
    [h_jb, p_jb] = jbtest(data);
    fprintf('\nJarque-Bera Test:\n');
    fprintf('  p-value: %.4f\n', p_jb);
    fprintf('  Result: %s (α = 0.05)\n\n', interpretTest(h_jb));
    
    % Visual assessment: Q-Q plot and histogram
    visualiseNormality(data, sensorName);
end

function result = interpretTest(h)
    % INTERPRETTEST Convert hypothesis test result to text
    if h == 0
        result = 'Fail to reject H₀ (data consistent with normality)';
    else
        result = 'Reject H₀ (significant deviation from normality)';
    end
end

function visualiseNormality(data, sensorName)
    % VISUALISENORMALITY Create diagnostic plots for normality
    
    figure('Position', [100, 100, 1200, 400], ...
        'Name', sprintf('Normality Assessment: %s', sensorName));
    
    % Histogram with normal overlay
    subplot(1, 3, 1);
    histogram(data, 30, 'Normalization', 'pdf', 'FaceColor', [0.2, 0.6, 0.8]);
    hold on;
    
    % Overlay theoretical normal distribution
    x_theory = linspace(min(data), max(data), 200);
    y_theory = normpdf(x_theory, mean(data), std(data));
    plot(x_theory, y_theory, 'r-', 'LineWidth', 2);
    
    xlabel('Value', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Probability Density', 'Interpreter', 'latex', 'FontSize', 12);
    title('Histogram vs. Normal Distribution', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Data', 'Normal Fit', 'Interpreter', 'latex');
    grid on;
    
    % Q-Q plot
    subplot(1, 3, 2);
    qqplot(data);
    title('Q-Q Plot', 'Interpreter', 'latex', 'FontSize', 13);
    xlabel('Theoretical Quantiles', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Sample Quantiles', 'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    
    % Box plot
    subplot(1, 3, 3);
    boxplot(data, 'Labels', {sensorName});
    ylabel('Value', 'Interpreter', 'latex', 'FontSize', 12);
    title('Box Plot (Outlier Detection)', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
end

function compareTwoSensors(data1, data2, name1, name2)
    % COMPARETWOSENSORS Perform two-sample t-test
    %   Tests whether two sensors have significantly different means
    
    fprintf('\\textbf{Two-Sample Comparison: %s vs %s}\n', name1, name2);
    fprintf('---------\n');
    
    % Remove NaN values
    data1 = data1(~isnan(data1));
    data2 = data2(~isnan(data2));
    
    % Descriptive statistics
    n1 = length(data1);
    n2 = length(data2);
    mean1 = mean(data1);
    mean2 = mean(data2);
    std1 = std(data1);
    std2 = std(data2);
    
    fprintf('%s: n=%d, mean=%.4f, std=%.4f\n', name1, n1, mean1, std1);
    fprintf('%s: n=%d, mean=%.4f, std=%.4f\n', name2, n2, mean2, std2);
    fprintf('Difference in means: %.4f\n', mean1 - mean2);
    
    % Test for equal variances (Levene's test)
    [h_var, p_var] = vartest2(data1, data2);
    fprintf('\nLevene''s Test for Equal Variances:\n');
    fprintf('  p-value: %.4f\n', p_var);
    
    % Two-sample t-test
    if h_var == 0
        % Equal variances assumed
        [h_t, p_t, ci_t, stats_t] = ttest2(data1, data2, 'Vartype', 'equal');
        fprintf('\nTwo-Sample t-test (equal variances):\n');
    else
        % Unequal variances (Welch's t-test)
        [h_t, p_t, ci_t, stats_t] = ttest2(data1, data2, 'Vartype', 'unequal');
        fprintf('\nWelch''s t-test (unequal variances):\n');
    end
    
    fprintf('  t-statistic: %.4f\n', stats_t.tstat);
    fprintf('  Degrees of freedom: %.1f\n', stats_t.df);
    fprintf('  p-value: %.4f\n', p_t);
    fprintf('  95%% CI for difference: [%.4f, %.4f]\n', ci_t(1), ci_t(2));
    fprintf('  Result: %s (α = 0.05)\n\n', interpretTest(h_t));
    
    % Effect size (Cohen's d)
    pooled_std = sqrt(((n1-1)*std1^2 + (n2-1)*std2^2) / (n1 + n2 - 2));
    cohens_d = (mean1 - mean2) / pooled_std;
    fprintf('Effect size (Cohen''s d): %.4f ', cohens_d);
    
    if abs(cohens_d) < 0.2
        fprintf('(negligible)\n\n');
    elseif abs(cohens_d) < 0.5
        fprintf('(small)\n\n');
    elseif abs(cohens_d) < 0.8
        fprintf('(medium)\n\n');
    else
        fprintf('(large)\n\n');
    end
    
    % Visualisation
    visualiseTwoSampleComparison(data1, data2, name1, name2);
end

function visualiseTwoSampleComparison(data1, data2, name1, name2)
    % VISUALISETWOSAMPLECOMPARISON Create comparison plots
    
    figure('Position', [150, 150, 1000, 400], ...
        'Name', sprintf('Comparison: %s vs %s', name1, name2));
    
    % Box plots
    subplot(1, 2, 1);
    boxplot([data1; data2], [ones(length(data1), 1); 2*ones(length(data2), 1)], ...
        'Labels', {name1, name2});
    ylabel('Value', 'Interpreter', 'latex', 'FontSize', 12);
    title('Box Plot Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Overlapping histograms
    subplot(1, 2, 2);
    histogram(data1, 30, 'Normalization', 'pdf', 'FaceAlpha', 0.5, ...
        'DisplayName', name1);
    hold on;
    histogram(data2, 30, 'Normalization', 'pdf', 'FaceAlpha', 0.5, ...
        'DisplayName', name2);
    xlabel('Value', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Probability Density', 'Interpreter', 'latex', 'FontSize', 12);
    title('Distribution Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex');
    grid on;
end

function compareMultipleSensors(sensor1, sensor2, sensor3, sensor4)
    % COMPAREMULTIPLESENSORS Perform one-way ANOVA
    %   Tests whether multiple sensors have significantly different means
    
    fprintf('\\textbf{Multiple Sensor Comparison (One-Way ANOVA)}\n');
    fprintf('----------\n');
    
    % Remove NaN values and concatenate
    sensor1 = sensor1(~isnan(sensor1));
    sensor2 = sensor2(~isnan(sensor2));
    sensor3 = sensor3(~isnan(sensor3));
    sensor4 = sensor4(~isnan(sensor4));
    
    % Create grouping variable
    data = [sensor1; sensor2; sensor3; sensor4];
    groups = [ones(length(sensor1), 1); 
              2*ones(length(sensor2), 1);
              3*ones(length(sensor3), 1);
              4*ones(length(sensor4), 1)];
    
    % Descriptive statistics by group
    fprintf('Group Statistics:\n');
    for g = 1:4
        group_data = data(groups == g);
        fprintf('  Sensor %d: n=%d, mean=%.4f, std=%.4f\n', ...
            g, length(group_data), mean(group_data), std(group_data));
    end
    
    % One-way ANOVA
    [p_anova, tbl_anova, stats_anova] = anova1(data, groups, 'off');
    
    fprintf('\nOne-Way ANOVA Results:\n');
    fprintf('  F-statistic: %.4f\n', tbl_anova{2,5});
    fprintf('  p-value: %.4f\n', p_anova);
    fprintf('  Result: %s (α = 0.05)\n', interpretTest(p_anova < 0.05));
    
    % Post-hoc analysis (if ANOVA significant)
    if p_anova < 0.05
        fprintf('\nPost-hoc Pairwise Comparisons (Tukey-Kramer):\n');
        [c, m, h, gnames] = multcompare(stats_anova, 'Display', 'off');
        
        for i = 1:size(c, 1)
            fprintf('  Sensor %d vs Sensor %d: p=%.4f ', ...
                c(i,1), c(i,2), c(i,6));
            if c(i,6) < 0.05
                fprintf('(significant)\n');
            else
                fprintf('(not significant)\n');
            end
        end
    end
    
    fprintf('\n');
    
    % Visualisation
    visualiseANOVA(data, groups);
end

function visualiseANOVA(data, groups)
    % VISUALISEANOVA Create ANOVA diagnostic plots
    
    figure('Position', [200, 200, 1200, 400], ...
        'Name', 'ANOVA Analysis');
    
    % Box plot by group
    subplot(1, 3, 1);
    boxplot(data, groups, 'Labels', {'S1', 'S2', 'S3', 'S4'});
    ylabel('Value', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Sensor', 'Interpreter', 'latex', 'FontSize', 12);
    title('Group Distributions', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Means with error bars
    subplot(1, 3, 2);
    means = grpstats(data, groups, 'mean');
    stds = grpstats(data, groups, 'std');
    sems = stds ./ sqrt(grpstats(data, groups, 'numel'));
    
    errorbar(1:4, means, sems, 'o-', 'LineWidth', 2, 'MarkerSize', 8, ...
        'MarkerFaceColor', 'b');
    xlim([0.5, 4.5]);
    xlabel('Sensor', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Mean $\pm$ SEM', 'Interpreter', 'latex', 'FontSize', 12);
    title('Group Means', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Residual plot
    subplot(1, 3, 3);
    group_means = means(groups);
    residuals = data - group_means;
    plot(group_means, residuals, 'o', 'MarkerSize', 4);
    yline(0, 'r-', 'LineWidth', 1.5);
    xlabel('Fitted Value', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Residual', 'Interpreter', 'latex', 'FontSize', 12);
    title('Residual Plot', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
end

function bootstrapAnalysis(data, sensorName)
    % BOOTSTRAPANALYSIS Compute bootstrap confidence intervals
    %   Uses percentile method for mean and median
    
    fprintf('\\textbf{Bootstrap Analysis: %s}\n', sensorName);
    fprintf('--------\n');
    
    % Remove NaN values
    data = data(~isnan(data));
    n = length(data);
    
    % Bootstrap parameters
    B = 10000;  % Number of bootstrap samples
    alpha = 0.05;  % Significance level
    
    fprintf('Sample size: %d\n', n);
    fprintf('Bootstrap samples: %d\n', B);
    fprintf('Confidence level: %.0f%%\n\n', 100*(1-alpha));
    
    % Bootstrap for mean
    fprintf('Statistic: Mean\n');
    sample_mean = mean(data);
    bootstrap_means = bootstrp(B, @mean, data);
    
    % Percentile confidence interval
    ci_mean = prctile(bootstrap_means, [100*alpha/2, 100*(1-alpha/2)]);
    
    % Standard error
    se_mean = std(bootstrap_means);
    
    % Bias
    bias_mean = mean(bootstrap_means) - sample_mean;
    
    fprintf('  Sample mean: %.4f\n', sample_mean);
    fprintf('  Bootstrap mean: %.4f\n', mean(bootstrap_means));
    fprintf('  Bootstrap SE: %.4f\n', se_mean);
    fprintf('  Bias: %.4f\n', bias_mean);
    fprintf('  %.0f%% CI: [%.4f, %.4f]\n\n', 100*(1-alpha), ci_mean(1), ci_mean(2));
    
    % Bootstrap for median
    fprintf('Statistic: Median\n');
    sample_median = median(data);
    bootstrap_medians = bootstrp(B, @median, data);
    
    ci_median = prctile(bootstrap_medians, [100*alpha/2, 100*(1-alpha/2)]);
    se_median = std(bootstrap_medians);
    bias_median = mean(bootstrap_medians) - sample_median;
    
    fprintf('  Sample median: %.4f\n', sample_median);
    fprintf('  Bootstrap median: %.4f\n', mean(bootstrap_medians));
    fprintf('  Bootstrap SE: %.4f\n', se_median);
    fprintf('  Bias: %.4f\n', bias_median);
    fprintf('  %.0f%% CI: [%.4f, %.4f]\n\n', 100*(1-alpha), ci_median(1), ci_median(2));
    
    % Visualisation
    visualiseBootstrap(data, bootstrap_means, bootstrap_medians, ...
        ci_mean, ci_median, sensorName);
end

function visualiseBootstrap(data, bootstrap_means, bootstrap_medians, ...
    ci_mean, ci_median, sensorName)
    % VISUALISEBOOTSTRAP Create bootstrap distribution plots
    
    figure('Position', [250, 250, 1200, 400], ...
        'Name', sprintf('Bootstrap Analysis: %s', sensorName));
    
    % Bootstrap distribution of mean
    subplot(1, 3, 1);
    histogram(bootstrap_means, 50, 'Normalization', 'pdf', ...
        'FaceColor', [0.2, 0.6, 0.8]);
    hold on;
    xline(mean(data), 'r-', 'LineWidth', 2, 'Label', 'Sample Mean');
    xline(ci_mean(1), 'g-', 'LineWidth', 1.5);
    xline(ci_mean(2), 'g-', 'LineWidth', 1.5);
    xlabel('Bootstrap Mean', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Density', 'Interpreter', 'latex', 'FontSize', 12);
    title('Bootstrap Distribution of Mean', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Bootstrap distribution of median
    subplot(1, 3, 2);
    histogram(bootstrap_medians, 50, 'Normalization', 'pdf', ...
        'FaceColor', [0.8, 0.4, 0.2]);
    hold on;
    xline(median(data), 'r-', 'LineWidth', 2, 'Label', 'Sample Median');
    xline(ci_median(1), 'g-', 'LineWidth', 1.5);
    xline(ci_median(2), 'g-', 'LineWidth', 1.5);
    xlabel('Bootstrap Median', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Density', 'Interpreter', 'latex', 'FontSize', 12);
    title('Bootstrap Distribution of Median', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Q-Q plot for bootstrap means (should be approximately normal)
    subplot(1, 3, 3);
    qqplot(bootstrap_means);
    title('Q-Q Plot: Bootstrap Means', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
end

% Added missing local function (book correction)
function qqplot(x, varargin)
x=sort(x(:)); n=numel(x); q=sqrt(2)*erfinv(2*((1:n)'-0.5)/n-1);
plot(q,x,'o'); grid on; xlabel('Theoretical quantiles'); ylabel('Sample quantiles');
end
