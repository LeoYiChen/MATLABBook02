%% chaotic_system.m
% Chaotic Dynamical System Simulation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chaotic_system
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem6.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Define Lorenz system parameters
sigma = 10;
rho = 28;
beta = 8/3;

% Define the Lorenz system
lorenz = @(t, x) [
sigma*(x(2) - x(1));
x(1)*(rho - x(3)) - x(2);
x(1)x(2) - betax(3)
];

% Initial conditions
x0 = [0; 1; 0];
% Slightly perturbed initial conditions for sensitivity analysis
x0_perturbed1 = x0 + [1e-4; 0; 0];
x0_perturbed2 = x0 + [0; 1e-4; 0];

% Time settings
tspan = [0 50];
dt = 0.01;
t = tspan(1):dt:tspan(2);
n = length(t);

% Implement 4th-order Runge-Kutta method
function x = rk4_solve(f, tspan, x0, dt)
t = tspan(1):dt:tspan(2);
n = length(t);
x = zeros(n, length(x0));
x(1,:) = x0';
for i = 1:n-1
    k1 = f(t(i), x(i,:)');
    k2 = f(t(i) + dt/2, x(i,:)' + dt*k1/2);
    k3 = f(t(i) + dt/2, x(i,:)' + dt*k2/2);
    k4 = f(t(i) + dt, x(i,:)' + dt*k3);
    
    x(i+1,:) = x(i,:) + (dt/6)*(k1 + 2*k2 + 2*k3 + k4)';
end

end

% Solve using RK4
fprintf('Solving Lorenz system using 4th-order Runge-Kutta method...\n');

tic;
x = rk4_solve(lorenz, tspan, x0, dt);
time_rk4 = toc;

fprintf('RK4 computation time: %.4f seconds\n', time_rk4);

% Solve perturbed systems
x_perturbed1 = rk4_solve(lorenz, tspan, x0_perturbed1, dt);
x_perturbed2 = rk4_solve(lorenz, tspan, x0_perturbed2, dt);

% Compute divergence over time
distance1 = sqrt(sum((x - x_perturbed1).^2, 2));
distance2 = sqrt(sum((x - x_perturbed2).^2, 2));

% Plot results
figure;
plot3(x(:,1), x(:,2), x(:,3), 'b-', 'LineWidth', 1.5);
hold on;
plot3(x(1,1), x(1,2), x(1,3), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
plot3(x(end,1), x(end,2), x(end,3), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
xlabel('x');
ylabel('y');
zlabel('z');
title('Lorenz Attractor Trajectory');
grid on;
view(30, 15);

% Plot a zoomed-in version of both trajectories to show divergence
figure;
plot3(x(1:500,1), x(1:500,2), x(1:500,3), 'b-', 'LineWidth', 1.5, 'DisplayName', 'Original');
hold on;
plot3(x_perturbed1(1:500,1), x_perturbed1(1:500,2), x_perturbed1(1:500,3), 'r-', 'LineWidth', 1.5, 'DisplayName', 'Perturbed 1');
plot3(x(1,1), x(1,2), x(1,3), 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g', 'DisplayName', 'Start');
xlabel('x');
ylabel('y');
zlabel('z');
title('Divergence of Trajectories (First 5 Time Units)');
legend('show');
grid on;
view(30, 15);

% Plot divergence over time
figure;
semilogy(t, distance1, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Perturbed in x');
hold on;
semilogy(t, distance2, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Perturbed in y');
xlabel('Time');
ylabel('Distance Between Trajectories (log scale)');
title('Sensitivity to Initial Conditions');
legend('show');
grid on;

% Calculate Lyapunov exponent (approximate)
% Use linear portion of the log-distance curve
linear_range = 50:200; % Choose time range where growth is approximately exponential
p1 = polyfit(t(linear_range), log(distance1(linear_range)), 1);
lyapunov_exponent = p1(1);
fprintf('Approximate maximum Lyapunov exponent: %.4f\n', lyapunov_exponent);

% Compare with MATLAB's ode45 solver
tic;
[t_ode45, x_ode45] = ode45(lorenz, tspan, x0);
time_ode45 = toc;
fprintf('ode45 computation time: %.4f seconds\n', time_ode45);

% Calculate maximum difference between RK4 and ode45
x_ode45_interp = interp1(t_ode45, x_ode45, t, 'spline');
max_diff = max(max(abs(x - x_ode45_interp)));
fprintf('Maximum difference between RK4 and ode45: %.2e\n', max_diff);

% Plot x component of both solutions for visual comparison
figure;
plot(t, x(:,1), 'b-', 'LineWidth', 1.5, 'DisplayName', 'RK4');
hold on;
plot(t_ode45, x_ode45(:,1), 'r-', 'LineWidth', 1.5, 'DisplayName', 'ode45');
xlabel('Time');
ylabel('x component');
title('Comparison of RK4 and ode45 Solutions');
legend('show');
grid on;
xlim([0 10]); % Focus on the first 10 time units

% Analyze the chaotic behaviour by plotting time series
figure;
subplot(3,1,1);
plot(t, x(:,1), 'b-', 'LineWidth', 1.5);
xlabel('Time');
ylabel('x');
title('Time Series of x Component');
grid on;

subplot(3,1,2);
plot(t, x(:,2), 'r-', 'LineWidth', 1.5);
xlabel('Time');
ylabel('y');
title('Time Series of y Component');
grid on;

subplot(3,1,3);
plot(t, x(:,3), 'g-', 'LineWidth', 1.5);
xlabel('Time');
ylabel('z');
title('Time Series of z Component');
grid on;

% Show the characteristic butterfly pattern in the x-z plane
figure;
plot(x(:,1), x(:,3), 'b-', 'LineWidth', 1, 'DisplayName', 'x-z projection');
xlabel('x');
ylabel('z');
title('Lorenz Attractor: x-z Projection (Butterfly Pattern)');
grid on;
