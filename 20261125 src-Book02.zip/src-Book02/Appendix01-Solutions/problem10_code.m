%% problem10_code.m
% Stakeholder-Informed Ethical Framework for Demand Response
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem10_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Stakeholder-Informed Ethical Framework for AI Demand Response
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-17
% Description: Implements participatory preference elicitation and voting
%              mechanisms for ethical demand response allocation

clear; close all; clc;

%% 1. Demand Response Scenario Setup
fprintf('========================================\n');
fprintf('Stakeholder-Informed Ethical Framework - Demand Response\n');
fprintf('========================================\n\n');

fprintf('Step 1: Setting up demand response scenario...\n');

rng(369); % Reproducibility

numHouseholds = 100;

% Household characteristics
householdIncome = randi([1, 3], numHouseholds, 1); % 1-Low, 2-Medium, 3-High
householdType = randi([1, 2], numHouseholds, 1);   % 1-Residential, 2-Commercial
vulnerabilityStatus = rand(numHouseholds, 1) < 0.15; % 15% vulnerable (elderly, disabled)

% Baseline load (kW)
baselineLoad = zeros(numHouseholds, 1);

for householdIdx = 1:numHouseholds
    if householdType(householdIdx) == 1 % Residential
        baselineLoad(householdIdx) = 2 + 0.5 * householdIncome(householdIdx) + ...
                                     0.5 * randn();
    else % Commercial
        baselineLoad(householdIdx) = 10 + 3 * randn();
    end
end

baselineLoad = max(baselineLoad, 0.5);
totalLoad = sum(baselineLoad);

% Required curtailment
curtailmentTarget = 0.20 * totalLoad; % 20% reduction

fprintf('Demand Response Scenario:\n');
fprintf('  Households: %d (Residential: %d, Commercial: %d)\n', ...
        numHouseholds, sum(householdType == 1), sum(householdType == 2));
fprintf('  Vulnerable households: %d (%.1f%%)\n', sum(vulnerabilityStatus), ...
        sum(vulnerabilityStatus) / numHouseholds * 100);
fprintf('  Total baseline load: %.2f kW\n', totalLoad);
fprintf('  Required curtailment: %.2f kW (20%%)\n\n', curtailmentTarget);

%% 2. Stakeholder Identification and Preferences
fprintf('Step 2: Defining stakeholder groups and preferences...\n');

stakeholders = struct();

% Stakeholder 1: Residential Customers
stakeholders(1).name = 'Residential Customers';
stakeholders(1).objective = 'Minimise individual curtailment burden';
stakeholders(1).weights = struct('equality', 0.7, 'efficiency', 0.2, 'vulnerability', 0.1);

% Stakeholder 2: Commercial Operators
stakeholders(2).name = 'Commercial Operators';
stakeholders(2).objective = 'Minimise revenue loss (curtailment)';
stakeholders(2).weights = struct('equality', 0.1, 'efficiency', 0.8, 'vulnerability', 0.1);

% Stakeholder 3: Grid Operator
stakeholders(3).name = 'Grid Operator';
stakeholders(3).objective = 'Maximise reliability and predictability';
stakeholders(3).weights = struct('equality', 0.3, 'efficiency', 0.6, 'vulnerability', 0.1);

% Stakeholder 4: Regulator
stakeholders(4).name = 'Regulator';
stakeholders(4).objective = 'Ensure fairness and equity';
stakeholders(4).weights = struct('equality', 0.6, 'efficiency', 0.2, 'vulnerability', 0.2);

% Stakeholder 5: Environmental Advocates
stakeholders(5).name = 'Environmental Advocates';
stakeholders(5).objective = 'Maximise renewable integration';
stakeholders(5).weights = struct('equality', 0.3, 'efficiency', 0.5, 'vulnerability', 0.2);

numStakeholders = length(stakeholders);

fprintf('Stakeholder Groups:\n');
for stakeholderIdx = 1:numStakeholders
    fprintf('  %d. %s: %s\n', stakeholderIdx, stakeholders(stakeholderIdx).name, ...
            stakeholders(stakeholderIdx).objective);
end
fprintf('\n');

%% 3. Generate Alternative Curtailment Allocations
fprintf('Step 3: Generating alternative curtailment allocation scenarios...\n');

numScenarios = 5;
scenarios = struct();

% Scenario 1: Proportional (equal percentage curtailment)
scenarios(1).name = 'Proportional';
scenarios(1).curtailment = (curtailmentTarget / totalLoad) * baselineLoad;

% Scenario 2: Uniform (equal absolute curtailment)
scenarios(2).name = 'Uniform';
scenarios(2).curtailment = (curtailmentTarget / numHouseholds) * ones(numHouseholds, 1);

% Scenario 3: Income-based (higher income bears more)
incomeWeights = householdIncome / sum(householdIncome);
scenarios(3).name = 'Income-based';
scenarios(3).curtailment = curtailmentTarget * incomeWeights;

% Scenario 4: Vulnerability-protected (exempt vulnerable)
nonVulnerableIndices = find(~vulnerabilityStatus);
scenarios(4).name = 'Vulnerability-protected';
scenarios(4).curtailment = zeros(numHouseholds, 1);
scenarios(4).curtailment(nonVulnerableIndices) = curtailmentTarget / length(nonVulnerableIndices);

% Scenario 5: Commercial-priority (curtail commercial first)
scenarios(5).name = 'Commercial-priority';
scenarios(5).curtailment = zeros(numHouseholds, 1);
commercialIndices = find(householdType == 2);
commercialCurtailment = min(curtailmentTarget, sum(baselineLoad(commercialIndices)));
scenarios(5).curtailment(commercialIndices) = (commercialCurtailment / sum(baselineLoad(commercialIndices))) * ...
                                              baselineLoad(commercialIndices);
if commercialCurtailment < curtailmentTarget
    % Remaining curtailment from residential
    residentialIndices = find(householdType == 1);
    remainingCurtailment = curtailmentTarget - commercialCurtailment;
    scenarios(5).curtailment(residentialIndices) = (remainingCurtailment / sum(baselineLoad(residentialIndices))) * ...
                                                   baselineLoad(residentialIndices);
end

fprintf('Curtailment Allocation Scenarios:\n');
for scenarioIdx = 1:numScenarios
    fprintf('  %d. %s\n', scenarioIdx, scenarios(scenarioIdx).name);
end
fprintf('\n');

%% 4. Stakeholder Utility Evaluation
fprintf('Step 4: Evaluating stakeholder utilities for each scenario...\n');

% Define utility components
for scenarioIdx = 1:numScenarios
    curtailment = scenarios(scenarioIdx).curtailment;
    
    % Equality metric (Gini coefficient)
    curtailmentSorted = sort(curtailment);
    n = length(curtailment);
    cumulativeShare = cumsum(curtailmentSorted) / sum(curtailmentSorted);
    giniCoefficient = 1 - 2 * sum(cumulativeShare) / n + 1 / n;
    scenarios(scenarioIdx).gini = giniCoefficient;
    
    % Efficiency metric (total curtailment deviation from target)
    efficiencyScore = 1 - abs(sum(curtailment) - curtailmentTarget) / curtailmentTarget;
    scenarios(scenarioIdx).efficiency = efficiencyScore;
    
    % Vulnerability protection (curtailment imposed on vulnerable)
    vulnerableCurtailment = sum(curtailment(vulnerabilityStatus));
    vulnerabilityScore = 1 - vulnerableCurtailment / curtailmentTarget;
    scenarios(scenarioIdx).vulnerability = vulnerabilityScore;
end

% Compute stakeholder-specific utilities
stakeholderUtilities = zeros(numStakeholders, numScenarios);

for stakeholderIdx = 1:numStakeholders
    weights = stakeholders(stakeholderIdx).weights;
    
    for scenarioIdx = 1:numScenarios
        utility = weights.equality * (1 - scenarios(scenarioIdx).gini) + ...
                  weights.efficiency * scenarios(scenarioIdx).efficiency + ...
                  weights.vulnerability * scenarios(scenarioIdx).vulnerability;
        
        stakeholderUtilities(stakeholderIdx, scenarioIdx) = utility;
    end
end

fprintf('Stakeholder Utilities (rows=stakeholders, columns=scenarios):\n');
disp(array2table(stakeholderUtilities, 'VariableNames', {scenarios.name}, ...
                 'RowNames', {stakeholders.name}));
fprintf('\n');

%% 5. Voting Mechanisms
fprintf('Step 5: Applying voting mechanisms for preference aggregation...\n');

% Plurality Voting (most preferred)
pluralityVotes = zeros(numScenarios, 1);

for stakeholderIdx = 1:numStakeholders
    [~, preferredScenario] = max(stakeholderUtilities(stakeholderIdx, :));
    pluralityVotes(preferredScenario) = pluralityVotes(preferredScenario) + 1;
end

[~, pluralityWinner] = max(pluralityVotes);

fprintf('Plurality Voting:\n');
for scenarioIdx = 1:numScenarios
    fprintf('  %s: %d votes\n', scenarios(scenarioIdx).name, pluralityVotes(scenarioIdx));
end
fprintf('  Winner: %s\n\n', scenarios(pluralityWinner).name);

% Borda Count (ranked preferences)
bordaScores = zeros(numScenarios, 1);

for stakeholderIdx = 1:numStakeholders
    [~, ranking] = sort(stakeholderUtilities(stakeholderIdx, :), 'descend');
    
    for rank = 1:numScenarios
        scenarioIdx = ranking(rank);
        bordaScores(scenarioIdx) = bordaScores(scenarioIdx) + (numScenarios - rank);
    end
end

[~, bordaWinner] = max(bordaScores);

fprintf('Borda Count:\n');
for scenarioIdx = 1:numScenarios
    fprintf('  %s: %d points\n', scenarios(scenarioIdx).name, bordaScores(scenarioIdx));
end
fprintf('  Winner: %s\n\n', scenarios(bordaWinner).name);

% Approval Voting (approve if utility > threshold)
approvalThreshold = 0.7; % Approve scenarios with utility > 0.7
approvalVotes = zeros(numScenarios, 1);

for stakeholderIdx = 1:numStakeholders
    approvedScenarios = stakeholderUtilities(stakeholderIdx, :) > approvalThreshold;
    approvalVotes = approvalVotes + approvedScenarios';
end

[maxApproval, approvalWinner] = max(approvalVotes);

fprintf('Approval Voting (threshold=%.2f):\n', approvalThreshold);
for scenarioIdx = 1:numScenarios
    fprintf('  %s: %d approvals\n', scenarios(scenarioIdx).name, approvalVotes(scenarioIdx));
end
fprintf('  Winner: %s\n\n', scenarios(approvalWinner).name);

%% 6. Consensus Analysis
fprintf('Step 6: Analysing consensus across voting mechanisms...\n');

winners = [pluralityWinner, bordaWinner, approvalWinner];
uniqueWinners = unique(winners);

if length(uniqueWinners) == 1
    fprintf('Consensus: All voting mechanisms select %s\n', scenarios(uniqueWinners).name);
else
    fprintf('No consensus: Different mechanisms select different scenarios\n');
    fprintf('  Plurality: %s\n', scenarios(pluralityWinner).name);
    fprintf('  Borda: %s\n', scenarios(bordaWinner).name);
    fprintf('  Approval: %s\n\n', scenarios(approvalWinner).name);
end

% Stakeholder disagreement (variance in utilities)
utilityVariance = var(stakeholderUtilities, [], 1);

fprintf('\nStakeholder Disagreement (utility variance):\n');
for scenarioIdx = 1:numScenarios
    fprintf('  %s: %.4f\n', scenarios(scenarioIdx).name, utilityVariance(scenarioIdx));
end
fprintf('\n');

%% 7. Visualisation
fprintf('Step 7: Generating visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: Stakeholder Utility Heatmap
fig1 = figure('Position', [100, 100, 1000, 600]);

imagesc(stakeholderUtilities);
colormap('hot');
colorbar;
caxis([0, 1]);

set(gca, 'XTick', 1:numScenarios, 'XTickLabel', {scenarios.name});
set(gca, 'YTick', 1:numStakeholders, 'YTickLabel', {stakeholders.name});
xlabel('Curtailment Scenario', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Stakeholder Group', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Stakeholder Utility Matrix}', 'Interpreter', 'latex', 'FontSize', 12);

saveas(fig1, 'figures/Problem10_Stakeholder_Utilities.fig');
saveas(fig1, 'figures/Problem10_Stakeholder_Utilities.eps', 'epsc');
saveas(fig1, 'figures/Problem10_Stakeholder_Utilities.jpg');
fprintf('Saved: Problem10_Stakeholder_Utilities\n');

% Figure 2: Voting Outcomes
fig2 = figure('Position', [150, 150, 1400, 500]);

subplot(1, 3, 1);
bar(categorical({scenarios.name}), pluralityVotes);
ylabel('Votes', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Plurality Voting}', 'Interpreter', 'latex', 'FontSize', 11);
grid on;

subplot(1, 3, 2);
bar(categorical({scenarios.name}), bordaScores);
ylabel('Borda Points', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Borda Count}', 'Interpreter', 'latex', 'FontSize', 11);
grid on;

subplot(1, 3, 3);
bar(categorical({scenarios.name}), approvalVotes);
ylabel('Approvals', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Approval Voting}', 'Interpreter', 'latex', 'FontSize', 11);
grid on;

sgtitle('\textbf{Voting Mechanism Comparison}', 'Interpreter', 'latex', 'FontSize', 13);

saveas(fig2, 'figures/Problem10_Voting_Mechanisms.fig');
saveas(fig2, 'figures/Problem10_Voting_Mechanisms.eps', 'epsc');
saveas(fig2, 'figures/Problem10_Voting_Mechanisms.jpg');
fprintf('Saved: Problem10_Voting_Mechanisms\n');

% Figure 3: Scenario Characteristics
fig3 = figure('Position', [200, 200, 1200, 500]);

scenarioNames = categorical({scenarios.name});
giniValues = [scenarios.gini];
efficiencyValues = [scenarios.efficiency];
vulnerabilityValues = [scenarios.vulnerability];

X = 1:numScenarios;
bar(X, [giniValues', efficiencyValues', vulnerabilityValues']);

set(gca, 'XTickLabel', scenarioNames);
ylabel('Score', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Scenario Ethical Characteristics}', 'Interpreter', 'latex', 'FontSize', 12);
legend('Inequality (Gini)', 'Efficiency', 'Vulnerability Protection', ...
       'Interpreter', 'latex', 'Location', 'best');
grid on;

saveas(fig3, 'figures/Problem10_Scenario_Characteristics.fig');
saveas(fig3, 'figures/Problem10_Scenario_Characteristics.eps', 'epsc');
saveas(fig3, 'figures/Problem10_Scenario_Characteristics.jpg');
fprintf('Saved: Problem10_Scenario_Characteristics\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');
