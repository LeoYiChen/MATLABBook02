%% prob14_code.m
% Bio-PCM thermal simulation for wearable thermal management.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob14_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Bio-based Sustainable PCM: Wearable Thermal Management Simulation
% File: MATLABBook02_Chapter07_Problem14.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Simulates transient heat transfer in bio-PCM textile
%              composite with phase change modeling for autonomous
%              thermal regulation in wearable applications
% =========================================================================

function MATLABBook02_Chapter07_Problem14()
    % Main function for Problem 14: Bio-PCM Thermal Simulation
    
    clc; clear; close all;
    
    fprintf('=== BIO-PCM WEARABLE THERMAL MANAGEMENT ===\n\n');
    
    % Define material properties
    params = defineMaterialProperties();
    
    % Define simulation domain and conditions
    [x, t, dx, dt] = defineSimulationDomain(params);
    
    % Run thermal simulation
    [T, heatStored] = simulateThermalBehavior(params, x, t, dx, dt);
    
    % Analyze performance
    analyzePerformance(T, t, params);
    
    % Visualize results
    visualizeResults(T, x, t, params, heatStored);
    
    % Sustainability assessment
    assessSustainability(params);
    
    fprintf('\n=== Simulation completed successfully ===\n');
end

function params = defineMaterialProperties()
    % DEFINEMATERIALPROPERTIES - Bio-PCM composite properties
    
    fprintf('Defining bio-PCM material properties...\n');
    
    % Bio-PCM properties (PEG-cellulose composite)
    params.k_solid = 0.25;        % Thermal conductivity (solid), W/m K
    params.k_liquid = 0.20;       % Thermal conductivity (liquid), W/m K
    params.rho = 950;             % Density, kg/m
    params.cp_solid = 2100;       % Specific heat (solid), J/kg K
    params.cp_liquid = 2400;      % Specific heat (liquid), J/kg K
    params.L = 180000;            % Latent heat of fusion, J/kg
    params.T_melt = 32;           % Melting temperature,  C
    params.T_range = 2;           % Phase change temperature range,  C
    
    % Geometric parameters
    params.thickness = 0.003;     % PCM layer thickness, m (3 mm)
    
    % Boundary conditions
    params.T_body = 37;           % Body temperature,  C
    params.T_ambient = 25;        % Ambient temperature,  C
    params.h_inner = 15;          % Heat transfer coefficient (body), W/m K
    params.h_outer = 10;          % Heat transfer coefficient (ambient), W/m K
    params.q_metabolic = 100;     % Metabolic heat flux, W/m
    
    fprintf('  PCM type: Bio-based PEG-cellulose composite\n');
    fprintf('  Melting point: %.1f C\n', params.T_melt);
    fprintf('  Latent heat: %.0f J/kg\n', params.L);
end

function [x, t, dx, dt] = defineSimulationDomain(params)
    % DEFINESIMULATIONDOMAIN - Spatial and temporal discretization
    
    fprintf('\nSetting up simulation domain...\n');
    
    % Spatial discretization
    nx = 50;                          % Number of spatial nodes
    x = linspace(0, params.thickness, nx);
    dx = x(2) - x(1);
    
    % Temporal discretization
    simTime = 3600;                   % Total simulation time, s (1 hour)
    dt = 1;                           % Time step, s
    t = 0:dt:simTime;
    
    % Stability check (CFL condition)
    alpha_max = params.k_liquid / (params.rho * params.cp_solid);
    CFL = alpha_max * dt / dx^2;
    
    fprintf('  Spatial nodes: %d\n', nx);
    fprintf('  Time steps: %d\n', length(t));
    fprintf('  CFL number: %.4f ', CFL);
    
    if CFL <= 0.5
        fprintf('(STABLE)\n');
    else
        fprintf('(WARNING: May be unstable!)\n');
    end
end

function [T, heatStored] = simulateThermalBehavior(params, x, t, dx, dt)
    % SIMULATETHERMALBEHAVIOR - Solves transient heat equation with PCM
    
    fprintf('\nRunning thermal simulation...\n');
    
    nx = length(x);
    nt = length(t);
    
    % Initialize temperature field
    T = zeros(nx, nt);
    T(:, 1) = params.T_ambient;  % Initial condition
    
    % Track heat storage
    heatStored = zeros(1, nt);
    
    % Time-stepping loop
    for n = 1:nt-1
        if mod(n, 600) == 0
            fprintf('  Progress: %.1f%% (t = %.0f s)\n', n/nt*100, t(n));
        end
        
        for i = 2:nx-1
            % Determine effective properties based on temperature
            [k_eff, cp_eff, dH_dt] = effectiveProperties(T(i,n), params, dt);
            
            % Thermal diffusivity
            alpha = k_eff / (params.rho * cp_eff);
            
            % Finite difference (explicit scheme)
            T(i, n+1) = T(i, n) + alpha * dt / dx^2 * ...
                       (T(i+1, n) - 2*T(i, n) + T(i-1, n)) + dH_dt;
        end
        
        % Boundary conditions
        % Inner boundary (body side): convective heat flux
        T(1, n+1) = T(2, n+1) + (params.q_metabolic + ...
                    params.h_inner * (params.T_body - T(1, n))) * dx / params.k_solid;
        
        % Outer boundary (ambient side): convective cooling
        T(nx, n+1) = T(nx-1, n+1) - params.h_outer * ...
                     (T(nx, n) - params.T_ambient) * dx / params.k_solid;
        
        % Calculate total heat stored in PCM
        heatStored(n+1) = sum(params.rho * params.cp_solid * ...
                          (T(:, n+1) - params.T_ambient)) * dx;
    end
    
    fprintf('  Simulation completed.\n');
end

function [k_eff, cp_eff, dH_dt] = effectiveProperties(T_local, params, dt)
    % EFFECTIVEPROPERTIES - Phase-dependent thermal properties
    
    T_melt_low = params.T_melt - params.T_range/2;
    T_melt_high = params.T_melt + params.T_range/2;
    
    if T_local < T_melt_low
        % Solid phase
        k_eff = params.k_solid;
        cp_eff = params.cp_solid;
        dH_dt = 0;
    elseif T_local > T_melt_high
        % Liquid phase
        k_eff = params.k_liquid;
        cp_eff = params.cp_liquid;
        dH_dt = 0;
    else
        % Mushy zone (phase transition)
        k_eff = 0.5 * (params.k_solid + params.k_liquid);
        cp_eff = 0.5 * (params.cp_solid + params.cp_liquid);
        
        % Latent heat contribution (simplified enthalpy method)
        liquid_fraction = (T_local - T_melt_low) / params.T_range;
        dH_dt = params.L * (liquid_fraction / params.T_range) / dt;
    end
end

function analyzePerformance(T, t, params)
    % ANALYZEPERFORMANCE - Evaluates thermal regulation effectiveness
    
    fprintf('\n=== PERFORMANCE ANALYSIS ===\n');
    
    % Surface temperatures
    T_inner = T(1, :);
    T_outer = T(end, :);
    
    % Time-averaged surface temperature
    T_inner_avg = mean(T_inner);
    T_outer_avg = mean(T_outer);
    
    % Temperature stability (standard deviation)
    T_inner_std = std(T_inner);
    
    % Time in comfort zone (28-34 C)
    comfortZone = (T_inner >= 28) & (T_inner <= 34);
    comfortDuration = sum(comfortZone) * (t(2) - t(1)) / 60;  % minutes
    
    fprintf('Inner surface temperature (avg): %.2f C\n', T_inner_avg);
    fprintf('Outer surface temperature (avg): %.2f C\n', T_outer_avg);
    fprintf('Temperature stability (std dev): %.2f C\n', T_inner_std);
    fprintf('Time in thermal comfort zone: %.1f minutes\n', comfortDuration);
    fprintf('=============================\n');
end

function visualizeResults(T, x, t, params, heatStored)
    % VISUALIZERESULTS - Creates comprehensive visualization
    
    fprintf('\nGenerating visualizations...\n');
    
    figure('Name', 'Bio-PCM Thermal Performance', 'Position', [100, 100, 1400, 900]);
    
    % Subplot 1: Spatiotemporal temperature evolution
    subplot(2, 2, 1);
    [X, Time] = meshgrid(x*1000, t/60);  % Convert to mm and minutes
    surf(X, Time, T', 'EdgeColor', 'none');
    xlabel('Position (mm)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Time (minutes)', 'Interpreter', 'latex', 'FontSize', 11);
    zlabel('Temperature ( C)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Temperature Evolution in Bio-PCM Layer', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    colorbar;
    colormap(jet);
    view(45, 30);
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    
    % Subplot 2: Surface temperature time series
    subplot(2, 2, 2);
    plot(t/60, T(1,:), 'r-', 'LineWidth', 2, 'DisplayName', 'Inner Surface (body side)');
    hold on;
    plot(t/60, T(end,:), 'b-', 'LineWidth', 2, 'DisplayName', 'Outer Surface (ambient side)');
    yline(params.T_melt, 'k-', 'LineWidth', 1.5, 'DisplayName', 'PCM Melting Point');
    yline(28, 'g:', 'LineWidth', 1, 'DisplayName', 'Comfort Zone');
    yline(34, 'g:', 'LineWidth', 1);
    xlabel('Time (minutes)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Temperature ( C)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Surface Temperature Dynamics', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    legend('Location', 'best', 'FontSize', 9);
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 3: Temperature profiles at key time points
    subplot(2, 2, 3);
    timePoints = [1, 300, 900, 1800, 3600];  % seconds
    timeIdx = round(timePoints / (t(2) - t(1))) + 1;
    colors = lines(length(timePoints));
    
    for i = 1:length(timePoints)
        plot(x*1000, T(:, timeIdx(i)), '-', 'LineWidth', 2, 'Color', colors(i,:), ...
             'DisplayName', sprintf('t = %.1f min', timePoints(i)/60));
        hold on;
    end
    xlabel('Position (mm)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Temperature ( C)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Temperature Profiles at Different Times', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    legend('Location', 'best', 'FontSize', 9);
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 4: Heat storage capacity
    subplot(2, 2, 4);
    plot(t/60, heatStored/1000, 'k-', 'LineWidth', 2);
    xlabel('Time (minutes)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Heat Stored (kJ/m$^2$)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Thermal Energy Storage in Bio-PCM', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
end

function assessSustainability(params)
    % ASSESSSUSTAINABILITY - Life-cycle environmental impact
    
    fprintf('\n=== SUSTAINABILITY ASSESSMENT ===\n');
    
    % Bio-PCM environmental metrics
    embodiedCarbon_bioPCM = 2.5;     % kg CO2-eq/kg
    biodegradabilityIndex = 0.85;    % 0-1 scale (1 = fully biodegradable)
    renewableContent = 0.75;         % 75% bio-based content
    
    % Conventional PCM comparison
    embodiedCarbon_conventional = 8.2;  % kg CO2-eq/kg
    biodegradabilityIndex_conv = 0.05;
    renewableContent_conv = 0.0;
    
    % Calculate metrics per m
    mass_per_m2 = params.rho * params.thickness;  % kg/m
    
    carbonSavings = (embodiedCarbon_conventional - embodiedCarbon_bioPCM) * mass_per_m2;
    
    fprintf('\nBio-PCM Environmental Performance:\n');
    fprintf('  Embodied carbon: %.2f kg CO2-eq/m\n', embodiedCarbon_bioPCM * mass_per_m2);
    fprintf('  Biodegradability index: %.2f (85%% biodegradable)\n', biodegradabilityIndex);
    fprintf('  Renewable content: %.0f%%\n', renewableContent * 100);
    fprintf('\nComparison vs. Conventional PCM:\n');
    fprintf('  Carbon savings: %.2f kg CO2-eq/m (%.0f%% reduction)\n', ...
            carbonSavings, (1 - embodiedCarbon_bioPCM/embodiedCarbon_conventional)*100);
    fprintf('  Biodegradability improvement: %.0fx\n', biodegradabilityIndex/biodegradabilityIndex_conv);
    fprintf('=================================\n');
end
