% MATLABBook02_Chapter01_Lab01.m
% This script demonstrates basic MATLAB operations while preparing
% data for an AI application context

% Create a sample dataset representing sensor readings
time = 0:0.01:5;
signal1 = sin(2*pi*time) + 0.2*randn(size(time));
signal2 = cos(2*pi*time) + 0.2*randn(size(time));

% Data preprocessing - a critical step in AI workflows
normalized_signal1 = (signal1 - mean(signal1))/std(signal1);
normalized_signal2 = (signal2 - mean(signal2))/std(signal2);

% Feature extraction (simple example)
features = [max(normalized_signal1), min(normalized_signal1), std(normalized_signal1);
            max(normalized_signal2), min(normalized_signal2), std(normalized_signal2)];

% Visualising the data
figure;
subplot(2,1,1);
plot(time, signal1, 'b-', time, normalized_signal1, 'r--');
legend('Original Signal 1', 'Normalised Signal 1');
xlabel('Time (s)');
ylabel('Amplitude');
title('Signal Preprocessing Example');

subplot(2,1,2);
plot(time, signal2, 'b-', time, normalized_signal2, 'r--');
legend('Original Signal 2', 'Normalised Signal 2');
xlabel('Time (s)');
ylabel('Amplitude');
title('Signal Preprocessing Example');

% Display extracted features
disp('Extracted features:');
disp(features);

% Feature importance analysis (simulated)
feature_importance = [0.7, 0.2, 0.1; 0.6, 0.3, 0.1];
feature_names = {'Maximum', 'Minimum', 'Standard Deviation'};

figure;
bar(feature_importance);
title('Feature Importance Analysis');
xlabel('Feature');
ylabel('Importance Score');
legend('Signal 1', 'Signal 2');
set(gca, 'XTickLabel', feature_names);