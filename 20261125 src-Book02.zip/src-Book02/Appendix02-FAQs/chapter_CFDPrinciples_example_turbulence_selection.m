%% chapter_CFDPrinciples_example_turbulence_selection.m
% Turbulence model selection framework.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_turbulence_selection
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function turbModel = selectTurbulenceModel(flowCharacteristics, ...
    computationalResources, accuracyRequirements)
    % SELECTTURBULENCEMODEL Recommend appropriate turbulence model
    % Decision framework based on flow physics and computational constraints
    %
    % Inputs:
    %   flowCharacteristics   - Struct: Re, flowType, separation, swirl,
    %                           unsteadiness, curvature
    %   computationalResources- Struct: availableCores, timeLimit, memoryGB
    %   accuracyRequirements  - Struct: targetAccuracy, criticalFeatures
    %
    % Output:
    %   turbModel            - Recommended turbulence modelling strategy
    %
    % Author: Dr Leo Chen
    % Institution: University of Cambridge
    % Version: 3.0
    %
    % References:
    %   [1] Wilcox (2006) Turbulence Modeling for CFD
    %   [2] Pope (2000) Turbulent Flows
    %   [3] Menter (1994) k-omega SST model
    
    fprintf('=== Turbulence Model Selection ===\n\n');
    
    turbModel = struct();
    
    % Extract flow characteristics
    Re = flowCharacteristics.Re;
    hasStrongSeparation = flowCharacteristics.separation;
    hasSwirl = flowCharacteristics.swirl;
    isUnsteady = flowCharacteristics.unsteadiness;
    hasCurvature = flowCharacteristics.curvature;
    
    fprintf('Flow characteristics:\n');
    fprintf('  Reynolds number: %.2e\n', Re);
    fprintf('  Strong separation: %s\n', booleanToYesNo(hasStrongSeparation));
    fprintf('  Swirling flow: %s\n', booleanToYesNo(hasSwirl));
    fprintf('  Unsteady features: %s\n', booleanToYesNo(isUnsteady));
    fprintf('  Streamline curvature: %s\n\n', booleanToYesNo(hasCurvature));
    
    % Assess computational resources
    canAffordLES = assessLESfeasibility(Re, computationalResources);
    canAffordRSM = assessRSMfeasibility(computationalResources);
    
    % Decision tree for model selection
    if canAffordLES && (isUnsteady || hasStrongSeparation) && ...
       strcmp(accuracyRequirements.targetAccuracy, 'high')
        % LES recommended for high-fidelity unsteady simulations
        turbModel.approach = 'Large_Eddy_Simulation';
        turbModel.specificModel = selectLESmodel(flowCharacteristics);
        turbModel.wallTreatment = selectLESwallTreatment(Re, computationalResources);
        turbModel.justification = 'High-fidelity resolution of unsteady turbulent structures';
        
    elseif hasStrongSeparation && canAffordLES
        % DES for massively separated flows
        turbModel.approach = 'Detached_Eddy_Simulation';
        turbModel.specificModel = 'SST_based_DES';
        turbModel.justification = 'Hybrid RANS-LES for efficient separation prediction';
        
    elseif (hasSwirl || hasCurvature) && canAffordRSM
        % Reynolds Stress Model for complex strain fields
        turbModel.approach = 'Reynolds_Stress_Model';
        turbModel.specificModel = 'LRR_omega_based_RSM';
        turbModel.justification = 'Anisotropic turbulence in swirl/curvature';
        
    elseif hasStrongSeparation
        % k-omega SST for separation with RANS budget
        turbModel.approach = 'Two_Equation_RANS';
        turbModel.specificModel = 'k_omega_SST';
        turbModel.justification = 'Superior adverse pressure gradient performance';
        
    elseif strcmp(flowCharacteristics.flowType, 'external_aerodynamics')
        % Spalart-Allmaras for attached aerodynamic flows
        turbModel.approach = 'One_Equation_RANS';
        turbModel.specificModel = 'Spalart_Allmaras';
        turbModel.justification = 'Efficient, robust for attached boundary layers';
        
    else
        % Standard k-epsilon for general industrial flows
        turbModel.approach = 'Two_Equation_RANS';
        turbModel.specificModel = 'k_epsilon_standard';
        turbModel.justification = 'Robust, well-validated for industrial flows';
    end
    
    % Model constants and settings
    turbModel.constants = getModelConstants(turbModel.specificModel);
    
    % Near-wall treatment
    turbModel.wallTreatment = selectWallTreatment(turbModel.approach, Re);
    
    % Numerical schemes
    turbModel.numericalSchemes = recommendTurbulenceSchemes(turbModel.approach);
    
    % Computational cost estimate
    turbModel.costEstimate = estimateComputationalCost(turbModel.approach, Re);
    
    % Display recommendation
    displayTurbulenceRecommendation(turbModel);
    
    fprintf('\nTurbulence model selection completed.\n');
end

function feasible = assessLESfeasibility(Re, resources)
    % Assess if LES is computationally feasible
    
    % LES grid requirement scales as Re^(9/4) for wall-resolved
    requiredCells_LES = Re^(9/4) / 1e6;  % Rough estimate in millions
    
    % Check available memory (assume 1GB per million cells)
    availableCells = resources.memoryGB * 0.8;  % 80% utilisation
    
    % Check time constraint (LES requires ~10 flow-through times)
    requiredCoreHours = requiredCells * 100;  % Rough estimate
    availableCoreHours = resources.availableCores * resources.timeLimit;
    
    feasible = (requiredCells < availableCells) && ...
               (requiredCoreHours < availableCoreHours * 2);
    
    if feasible
        fprintf('LES feasibility: YES\n');
        fprintf('  Estimated cells: %.1f million\n', requiredCells);
    else
        fprintf('LES feasibility: NO\n');
        fprintf('  Would require: %.1f million cells\n', requiredCells);
        fprintf('  Available resources: %.1f million cells\n\n', availableCells);
    end
end

function feasible = assessRSMfeasibility(resources)
    % Assess if Reynolds Stress Model is feasible
    % RSM requires ~50% more computational time than two-equation models
    
    % Simple heuristic: if >16 cores available, RSM is feasible
    feasible = resources.availableCores >= 16;
    
    fprintf('RSM feasibility: %s\n\n', booleanToYesNo(feasible));
end

function lesModel = selectLESmodel(flowChar)
    % Select specific LES subgrid-scale model
    
    if isfield(flowChar, 'complexGeometry') && flowChar.complexGeometry
        lesModel = 'dynamic_Smagorinsky';
    else
        lesModel = 'Smagorinsky_standard';
    end
end

function wallTreat = selectLESwallTreatment(Re, resources)
    % Select LES wall treatment
    
    % Wall-resolved LES requires first cell y+ < 1
    if Re < 1e4 && resources.memoryGB > 64
        wallTreat = 'wall_resolved';
    else
        wallTreat = 'wall_modelled_WMLES';
    end
end

function wallTreat = selectWallTreatment(approach, Re)
    % Select near-wall treatment for RANS models
    
    if strcmp(approach, 'Large_Eddy_Simulation')
        % Already handled in selectLESwallTreatment
        wallTreat = 'see_LES_specific';
        
    elseif Re < 1e5
        % Low Re: resolve to wall
        wallTreat = 'low_Reynolds_number_formulation';
        
    else
        % High Re: use wall functions
        wallTreat = 'logarithmic_wall_functions';
    end
end

function constants = getModelConstants(modelName)
    % Return model constants for specified turbulence model
    
    constants = struct();
    
    switch modelName
        case 'k_epsilon_standard'
            constants.C_mu = 0.09;
            constants.C_1epsilon = 1.44;
            constants.C_2epsilon = 1.92;
            constants.sigma_k = 1.0;
            constants.sigma_epsilon = 1.3;
            
        case 'k_omega_SST'
            constants.alpha_1 = 5/9;
            constants.beta_1 = 0.075;
            constants.beta_star = 0.09;
            constants.sigma_k1 = 0.85;
            constants.sigma_omega1 = 0.5;
            
        case 'Spalart_Allmaras'
            constants.C_b1 = 0.1355;
            constants.C_b2 = 0.622;
            constants.sigma_SA = 2/3;
            constants.kappa = 0.41;
            
        case 'Smagorinsky_standard'
            constants.C_s = 0.17;
            
        case 'dynamic_Smagorinsky'
            constants.C_s = 'computed_dynamically';
            
        otherwise
            constants.note = 'Model-specific constants to be specified';
    end
end

function schemes = recommendTurbulenceSchemes(approach)
    % Recommend numerical schemes for turbulence equations
    
    schemes = struct();
    
    if strcmp(approach, 'Large_Eddy_Simulation')
        schemes.temporal = 'second_order_implicit';
        schemes.convection = 'central_differencing_or_bounded_central';
        schemes.diffusion = 'central_differencing';
        schemes.timeStep = 'CFL_less_than_1';
        
    else
        % RANS models
        schemes.temporal = 'first_order_implicit';
        schemes.convection = 'second_order_upwind';
        schemes.diffusion = 'central_differencing';
        schemes.timeStep = 'steady_or_large_timestep';
    end
end

function cost = estimateComputationalCost(approach, Re)
    % Estimate relative computational cost
    
    cost = struct();
    
    switch approach
        case 'One_Equation_RANS'
            cost.relative = 1.0;
            cost.coreHours = Re / 1e6;
            cost.description = 'Baseline cost';
            
        case 'Two_Equation_RANS'
            cost.relative = 1.3;
            cost.coreHours = 1.3 * Re / 1e6;
            cost.description = 'Moderate increase over one-equation';
            
        case 'Reynolds_Stress_Model'
            cost.relative = 2.0;
            cost.coreHours = 2.0 * Re / 1e6;
            cost.description = 'Double two-equation cost';
            
        case 'Detached_Eddy_Simulation'
            cost.relative = 50;
            cost.coreHours = 50 * Re / 1e6;
            cost.description = 'Hybrid RANS-LES cost';
            
        case 'Large_Eddy_Simulation'
            cost.relative = 500;
            cost.coreHours = 500 * Re / 1e6;
            cost.description = 'High-fidelity LES cost';
            
        otherwise
            cost.relative = NaN;
            cost.coreHours = NaN;
            cost.description = 'Unknown';
    end
end

function displayTurbulenceRecommendation(turbModel)
    % Display turbulence model recommendation
    
    fprintf('\n=== Turbulence Model Recommendation ===\n\n');
    
    fprintf('Recommended approach: %s\n', turbModel.approach);
    fprintf('Specific model: %s\n', turbModel.specificModel);
    fprintf('Justification: %s\n\n', turbModel.justification);
    
    fprintf('Wall treatment: %s\n\n', turbModel.wallTreatment);
    
    fprintf('Numerical schemes:\n');
    fields = fieldnames(turbModel.numericalSchemes);
    for i = 1:length(fields)
        fprintf('  %s: %s\n', fields{i}, turbModel.numericalSchemes.(fields{i}));
    end
    
    fprintf('\nComputational cost estimate:\n');
    fprintf('  Relative cost: %.1fx baseline\n', turbModel.costEstimate.relative);
    fprintf('  Estimated core-hours: %.1f\n', turbModel.costEstimate.coreHours);
    fprintf('  Description: %s\n', turbModel.costEstimate.description);
    
    fprintf('\n=== End of Recommendation ===\n');
end

function yesno = booleanToYesNo(boolValue)
    % Convert boolean to Yes/No string
    if boolValue
        yesno = 'Yes';
    else
        yesno = 'No';
    end
end
