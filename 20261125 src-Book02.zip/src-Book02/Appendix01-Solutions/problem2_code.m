%% problem2_code.m
% Fairness Analysis in EV Charging Infrastructure Allocation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem2_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Demographic Fairness Analysis in EV Charging Infrastructure
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-16
% Description: Comprehensive algorithmic fairness assessment for EV charging
%              station placement predictions across neighbourhood income levels

clear; close all; clc;

%% 1. Synthetic Dataset Generation
fprintf('========================================\n');
fprintf('EV Charging Infrastructure - Fairness Analysis\n');
fprintf('========================================\n\n');

fprintf('Step 1: Generating synthetic neighbourhood dataset...\n');

rng(123); % Reproducibility

numNeighbourhoods = 500;

% Income quintile (protected attribute): 1-Q1 (lowest), 5-Q5 (highest)
incomeQuintile = randi([1, 5], numNeighbourhoods, 1);

% Generate features with income-correlated patterns
% Feature 1: EV ownership rate (%) - positively correlated with income
evOwnership = 5 + 10 * incomeQuintile + 15 * randn(numNeighbourhoods, 1);
evOwnership = max(0, min(100, evOwnership)); % Clamp to [0, 100]

% Feature 2: Daily traffic volume (thousands) - weakly correlated
trafficVolume = 20 + 5 * incomeQuintile + 10 * randn(numNeighbourhoods, 1);
trafficVolume = max(5, trafficVolume);

% Feature 3: Population density (per km^2, thousands)
popDensity = 8 - 0.5 * incomeQuintile + 3 * randn(numNeighbourhoods, 1);
popDensity = max(1, popDensity);

% Feature 4: Existing charger proximity (km) - inversely correlated
existingProximity = 5 - 0.8 * incomeQuintile + 2 * randn(numNeighbourhoods, 1);
existingProximity = max(0.5, existingProximity);

% Combine features
X = [evOwnership, trafficVolume, popDensity, existingProximity];

% Generate labels with bias: higher income areas more likely recommended
% True optimal allocation should depend on EV ownership and traffic primarily
utilityScore = 0.4 * evOwnership + 0.3 * trafficVolume + ...
               0.2 * (10 - existingProximity) + 0.1 * popDensity;

% Add income bias to recommendations
biasedScore = utilityScore + 8 * incomeQuintile;

% Binary labels: top 40% get charging stations
scoreThreshold = quantile(biasedScore, 0.6);
Y = double(biasedScore > scoreThreshold);

fprintf('Generated %d neighbourhoods across 5 income quintiles\n', numNeighbourhoods);
fprintf('Positive recommendation rate: %.1f%%\n\n', mean(Y) * 100);

% Display income distribution
for qIdx = 1:5
    mask = incomeQuintile == qIdx;
    fprintf('Q%d: n=%d, positive rate=%.1f%%\n', qIdx, sum(mask), ...
            mean(Y(mask)) * 100);
end
fprintf('\n');

%% 2. Train-Test Split
fprintf('Step 2: Splitting dataset...\n');

cv = cvpartition(Y, 'HoldOut', 0.3);
trainIdx = training(cv);
testIdx = test(cv);

XTrain = X(trainIdx, :);
YTrain = Y(trainIdx);
incomeTrain = incomeQuintile(trainIdx);

XTest = X(testIdx, :);
YTest = Y(testIdx);
incomeTest = incomeQuintile(testIdx);

fprintf('Training: %d samples, Test: %d samples\n\n', ...
        sum(trainIdx), sum(testIdx));

%% 3. Baseline Logistic Regression
fprintf('Step 3: Training baseline logistic regression...\n');

mdlBaseline = fitclinear(XTrain, YTrain, 'Learner', 'logistic');

[YPredBaseline, scoresBaseline] = predict(mdlBaseline, XTest);
baselineAccuracy = mean(YPredBaseline == YTest);

fprintf('Baseline test accuracy: %.2f%%\n\n', baselineAccuracy * 100);

%% 4. Fairness Metrics - Baseline
fprintf('Step 4: Computing baseline fairness metrics...\n');

fairnessBaseline = computeFairnessMetrics(YTest, YPredBaseline, incomeTest);

fprintf('Baseline Fairness Metrics:\n');
displayFairnessMetrics(fairnessBaseline);

%% 5. Pre-Processing: Sample Reweighting
fprintf('\nStep 5: Applying pre-processing bias mitigation (reweighting)...\n');

% Compute class weights inversely proportional to group representation
weights = ones(size(YTrain));
for qIdx = 1:5
    mask = incomeTrain == qIdx;
    groupSize = sum(mask);
    weights(mask) = numNeighbourhoods / (5 * groupSize);
end

% Normalise weights
weights = weights / mean(weights);

% Train weighted model
mdlReweighted = fitclinear(XTrain, YTrain, 'Learner', 'logistic', ...
                           'Weights', weights);

[YPredReweighted, ~] = predict(mdlReweighted, XTest);
reweightedAccuracy = mean(YPredReweighted == YTest);

fairnessReweighted = computeFairnessMetrics(YTest, YPredReweighted, incomeTest);

fprintf('Reweighted model accuracy: %.2f%%\n', reweightedAccuracy * 100);
fprintf('Fairness Metrics:\n');
displayFairnessMetrics(fairnessReweighted);

%% 6. In-Processing: Fairness-Constrained Optimisation
fprintf('\nStep 6: Applying in-processing bias mitigation...\n');
fprintf('(Using demographic parity penalty in objective function)\n');

% Simple implementation: train model with penalty on prediction rate differences
% We approximate through iterative reweighting based on prediction disparities

lambdaFair = 0.3; % Fairness penalty weight
maxIter = 10;

weightsInProcess = ones(size(YTrain));

for iter = 1:maxIter
    % Train model
    mdlTemp = fitclinear(XTrain, YTrain, 'Learner', 'logistic', ...
                         'Weights', weightsInProcess);
    
    % Predict on training set
    YPredTrain = predict(mdlTemp, XTrain);
    
    % Compute prediction rates per group
    groupRates = zeros(5, 1);
    for qIdx = 1:5
        mask = incomeTrain == qIdx;
        groupRates(qIdx) = mean(YPredTrain(mask));
    end
    
    % Adjust weights to penalise over-represented groups
    overallRate = mean(YPredTrain);
    for qIdx = 1:5
        mask = incomeTrain == qIdx;
        if groupRates(qIdx) > overallRate
            weightsInProcess(mask) = weightsInProcess(mask) * (1 - lambdaFair);
        else
            weightsInProcess(mask) = weightsInProcess(mask) * (1 + lambdaFair);
        end
    end
    
    % Normalise
    weightsInProcess = weightsInProcess / mean(weightsInProcess);
end

mdlInProcess = mdlTemp;

[YPredInProcess, ~] = predict(mdlInProcess, XTest);
inProcessAccuracy = mean(YPredInProcess == YTest);

fairnessInProcess = computeFairnessMetrics(YTest, YPredInProcess, incomeTest);

fprintf('In-process model accuracy: %.2f%%\n', inProcessAccuracy * 100);
fprintf('Fairness Metrics:\n');
displayFairnessMetrics(fairnessInProcess);

%% 7. Post-Processing: Threshold Adjustment
fprintf('\nStep 7: Applying post-processing bias mitigation (threshold adjustment)...\n');

% Use baseline model scores but adjust thresholds per group
% Goal: achieve statistical parity

% Compute group-specific thresholds
thresholds = zeros(5, 1);
targetRate = mean(YTest); % Overall positive rate

for qIdx = 1:5
    mask = incomeTest == qIdx;
    groupScores = scoresBaseline(mask, 2); % Positive class scores
    
    % Find threshold achieving target rate for this group
    if sum(mask) > 0
        sortedScores = sort(groupScores, 'descend');
        numPositive = round(sum(mask) * targetRate);
        if numPositive > 0 && numPositive <= length(sortedScores)
            thresholds(qIdx) = sortedScores(numPositive);
        else
            thresholds(qIdx) = 0.5;
        end
    else
        thresholds(qIdx) = 0.5;
    end
end

% Apply group-specific thresholds
YPredPostProcess = zeros(size(YTest));
for qIdx = 1:5
    mask = incomeTest == qIdx;
    YPredPostProcess(mask) = double(scoresBaseline(mask, 2) >= thresholds(qIdx));
end

postProcessAccuracy = mean(YPredPostProcess == YTest);

fairnessPostProcess = computeFairnessMetrics(YTest, YPredPostProcess, incomeTest);

fprintf('Post-process model accuracy: %.2f%%\n', postProcessAccuracy * 100);
fprintf('Group-specific thresholds: [%.3f, %.3f, %.3f, %.3f, %.3f]\n', thresholds);
fprintf('Fairness Metrics:\n');
displayFairnessMetrics(fairnessPostProcess);

%% 8. Comparative Visualisation
fprintf('\nStep 8: Generating comparative visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: Fairness Metrics Comparison
fig1 = figure('Position', [100, 100, 1400, 800]);

models = {'Baseline', 'Reweighted', 'In-Process', 'Post-Process'};
fairnessResults = {fairnessBaseline, fairnessReweighted, ...
                   fairnessInProcess, fairnessPostProcess};

% Statistical Parity Difference
subplot(2, 3, 1);
spd = cellfun(@(x) max(abs(x.statisticalParity - mean(x.statisticalParity))), ...
              fairnessResults);
bar(spd, 'FaceColor', [0.8, 0.3, 0.3]);
set(gca, 'XTickLabel', models, 'TickLabelInterpreter', 'latex');
ylabel('Max Deviation from Mean (\%)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Statistical Parity Disparity}', 'Interpreter', 'latex');
grid on;

% Equalised Odds (TPR Disparity)
subplot(2, 3, 2);
tprDisp = cellfun(@(x) max(x.truePositiveRate) - min(x.truePositiveRate), ...
                  fairnessResults);
bar(tprDisp * 100, 'FaceColor', [0.3, 0.6, 0.8]);
set(gca, 'XTickLabel', models, 'TickLabelInterpreter', 'latex');
ylabel('TPR Range (\%)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{True Positive Rate Disparity}', 'Interpreter', 'latex');
grid on;

% Predictive Parity Disparity
subplot(2, 3, 3);
ppvDisp = cellfun(@(x) max(x.positivePredictiveValue) - min(x.positivePredictiveValue), ...
                  fairnessResults);
bar(ppvDisp * 100, 'FaceColor', [0.3, 0.8, 0.3]);
set(gca, 'XTickLabel', models, 'TickLabelInterpreter', 'latex');
ylabel('PPV Range (\%)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Predictive Parity Disparity}', 'Interpreter', 'latex');
grid on;

% Accuracy Comparison
subplot(2, 3, 4);
accuracies = [baselineAccuracy, reweightedAccuracy, inProcessAccuracy, ...
              postProcessAccuracy] * 100;
bar(accuracies, 'FaceColor', [0.5, 0.5, 0.5]);
set(gca, 'XTickLabel', models, 'TickLabelInterpreter', 'latex');
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Overall Accuracy}', 'Interpreter', 'latex');
ylim([70, 90]);
grid on;

% Per-Group Positive Rates
subplot(2, 3, 5);
hold on;
for modelIdx = 1:4
    plot(1:5, fairnessResults{modelIdx}.statisticalParity, 'o-', ...
         'LineWidth', 2, 'MarkerSize', 7, 'DisplayName', models{modelIdx});
end
xlabel('Income Quintile', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Positive Prediction Rate (\%)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Statistical Parity Across Groups}', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;

% Fairness-Accuracy Trade-off
subplot(2, 3, 6);
fairnessScore = 1 ./ (spd + 0.01); % Inverse of disparity
scatter(accuracies, fairnessScore, 100, 'filled');
for modelIdx = 1:4
    text(accuracies(modelIdx) + 0.3, fairnessScore(modelIdx), models{modelIdx}, ...
         'Interpreter', 'latex', 'FontSize', 9);
end
xlabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Fairness Score (1/Disparity)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Fairness-Accuracy Trade-off}', 'Interpreter', 'latex');
grid on;

sgtitle('\textbf{Algorithmic Fairness Analysis - EV Charging Infrastructure}', ...
        'Interpreter', 'latex', 'FontSize', 14);

saveas(fig1, 'figures/Problem2_Fairness_Comparison.fig');
saveas(fig1, 'figures/Problem2_Fairness_Comparison.eps', 'epsc');
saveas(fig1, 'figures/Problem2_Fairness_Comparison.jpg');
fprintf('Saved: Problem2_Fairness_Comparison\n');

% Figure 2: Impossibility of Simultaneous Satisfaction
fig2 = figure('Position', [150, 150, 900, 600]);

% Demonstrate that achieving statistical parity violates equalised odds
subplot(1, 2, 1);
models_subset = {'Baseline', 'Post-Process'};
data_sp = [fairnessBaseline.statisticalParity; fairnessPostProcess.statisticalParity]';
bar(data_sp);
set(gca, 'XTickLabel', {'Q1', 'Q2', 'Q3', 'Q4', 'Q5'}, ...
    'TickLabelInterpreter', 'latex');
xlabel('Income Quintile', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Positive Rate (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Statistical Parity}', 'Interpreter', 'latex', 'FontSize', 12);
legend(models_subset, 'Interpreter', 'latex', 'Location', 'best');
grid on;

subplot(1, 2, 2);
data_tpr = [fairnessBaseline.truePositiveRate; fairnessPostProcess.truePositiveRate]';
bar(data_tpr * 100);
set(gca, 'XTickLabel', {'Q1', 'Q2', 'Q3', 'Q4', 'Q5'}, ...
    'TickLabelInterpreter', 'latex');
xlabel('Income Quintile', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('True Positive Rate (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Equalised Odds (TPR)}', 'Interpreter', 'latex', 'FontSize', 12);
legend(models_subset, 'Interpreter', 'latex', 'Location', 'best');
grid on;

sgtitle({'\textbf{Fairness Impossibility Result}', ...
         'Achieving Statistical Parity Violates Equalised Odds'}, ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig2, 'figures/Problem2_Impossibility_Demonstration.fig');
saveas(fig2, 'figures/Problem2_Impossibility_Demonstration.eps', 'epsc');
saveas(fig2, 'figures/Problem2_Impossibility_Demonstration.jpg');
fprintf('Saved: Problem2_Impossibility_Demonstration\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');

%% Helper Functions
function metrics = computeFairnessMetrics(YTrue, YPred, protectedAttr)
    % Compute fairness metrics stratified by protected attribute
    
    uniqueGroups = unique(protectedAttr);
    numGroups = length(uniqueGroups);
    
    metrics.statisticalParity = zeros(numGroups, 1);
    metrics.truePositiveRate = zeros(numGroups, 1);
    metrics.falsePositiveRate = zeros(numGroups, 1);
    metrics.positivePredictiveValue = zeros(numGroups, 1);
    metrics.accuracy = zeros(numGroups, 1);
    
    for groupIdx = 1:numGroups
        mask = protectedAttr == uniqueGroups(groupIdx);
        
        YTrueGroup = YTrue(mask);
        YPredGroup = YPred(mask);
        
        % Statistical Parity (positive prediction rate)
        metrics.statisticalParity(groupIdx) = mean(YPredGroup) * 100;
        
        % True Positive Rate (Sensitivity)
        tp = sum(YTrueGroup == 1 & YPredGroup == 1);
        fn = sum(YTrueGroup == 1 & YPredGroup == 0);
        if (tp + fn) > 0
            metrics.truePositiveRate(groupIdx) = tp / (tp + fn);
        else
            metrics.truePositiveRate(groupIdx) = 0;
        end
        
        % False Positive Rate
        fp = sum(YTrueGroup == 0 & YPredGroup == 1);
        tn = sum(YTrueGroup == 0 & YPredGroup == 0);
        if (fp + tn) > 0
            metrics.falsePositiveRate(groupIdx) = fp / (fp + tn);
        else
            metrics.falsePositiveRate(groupIdx) = 0;
        end
        
        % Positive Predictive Value (Precision)
        if (tp + fp) > 0
            metrics.positivePredictiveValue(groupIdx) = tp / (tp + fp);
        else
            metrics.positivePredictiveValue(groupIdx) = 0;
        end
        
        % Accuracy
        metrics.accuracy(groupIdx) = mean(YTrueGroup == YPredGroup);
    end
end

function displayFairnessMetrics(metrics)
    fprintf('  Statistical Parity (Positive Rate): [');
    fprintf('%.1f%%, ', metrics.statisticalParity);
    fprintf(']\n');
    
    fprintf('  True Positive Rate: [');
    fprintf('%.1f%%, ', metrics.truePositiveRate * 100);
    fprintf(']\n');
    
    fprintf('  Positive Predictive Value: [');
    fprintf('%.1f%%, ', metrics.positivePredictiveValue * 100);
    fprintf(']\n');
    
    fprintf('  Per-Group Accuracy: [');
    fprintf('%.1f%%, ', metrics.accuracy * 100);
    fprintf(']\n\n');
end
