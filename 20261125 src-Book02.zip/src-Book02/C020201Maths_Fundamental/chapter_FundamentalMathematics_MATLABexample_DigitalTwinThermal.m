%% chapter_FundamentalMathematics_MATLABexample_DigitalTwinThermal.m
% Digital twin thermal analysis using finite difference methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_DigitalTwinThermal
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_2_4_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Digital twin thermal analysis implementation using
%              finite difference discretisation of heat equation.

function digitalTwinThermalAnalysisSystem()
    % Physical domain parameters
    domainLength = 1.0;          % metres
    numNodes = 1000;             % discretisation nodes
    delta*X = domainLength / (numNodes - 1);
    
    % Material and process parameters
    thermalConductivity = 50.0;  % W/(m·K)
    heatGenerationRate = 1000.0; % W/m³
    
    % Boundary conditions (Dirichlet type)
    leftBoundaryTemp = 100.0;    % °C
    rightBoundaryTemp = 50.0;    % °C
    
    fprintf('Digital Twin: Steady-State Thermal Analysis\n');
    fprintf('%s\n', repmat('=', 1, 60));
    fprintf('Physical Parameters:\n');
    fprintf('  Domain Length: %.2f m\n', domainLength);
    fprintf('  Number of Nodes: %d\n', numNodes);
    fprintf('  Grid Spacing: %.6f m\n', delta*X);
    fprintf('  Thermal Conductivity: %.1f W/(m·K)\n', thermalConductivity);
    fprintf('  Heat Generation: %.1f W/m³\n', heatGenerationRate);
    fprintf('\nBoundary Conditions:\n');
    fprintf('  Left (x=0): %.1f °C\n', leftBoundaryTemp);
    fprintf('  Right (x=L): %.1f °C\n', rightBoundaryTemp);
    fprintf('%s\n\n', repmat('-', 1, 60));
    
    % Construct finite difference system
    [systemMatrix, rhsVector] = constructThermalFiniteDifferenceSystem(...
        numNodes, delta*X, thermalConductivity, heatGenerationRate, ...
        leftBoundaryTemp, rightBoundaryTemp);
    
    % Analyse system properties
    fprintf('Linear System Properties:\n');
    fprintf('  Matrix Dimension: %d $\times$ %d\n', size(systemMatrix));
    fprintf('  Matrix Sparsity: %.2f%%\n', ...
            100 * (1 - nnz(systemMatrix) / numel(systemMatrix)));
    fprintf('  Number of Non-zeros: %d\n', nnz(systemMatrix));
    
    % Solve the linear system
    fprintf('\nSolving linear system...\n');
    tic;
    temperatureDistribution = systemMatrix \ rhsVector;
    solutionTime = toc;
    
    fprintf('System solved in %.4f seconds\n', solutionTime);
    
    % Analyse results
    fprintf('\nThermal Analysis Results:\n');
    fprintf('  Maximum Temperature: %.2f °C\n', max(temperatureDistribution));
    fprintf('  Minimum Temperature: %.2f °C\n', min(temperatureDistribution));
    fprintf('  Average Temperature: %.2f °C\n', mean(temperatureDistribution));
    
    % Find location of maximum temperature
    [maxTemp, maxIdx] = max(temperatureDistribution);
    maxLocation = (maxIdx - 1) * delta*X;
    fprintf('  Max Temperature Location: x = %.4f m\n', maxLocation);
    
    % Visualise results
    visualiseThermalDistribution(delta*X, temperatureDistribution, numNodes);
    
    % Compute and visualise thermal gradient
    computeThermalGradient(delta*X, temperatureDistribution, numNodes);
    
    % Verify solution accuracy
    verifySolutionAccuracy(systemMatrix, temperatureDistribution, rhsVector);
end

function [A, b] = constructThermalFiniteDifferenceSystem(n, dx, k, Q, ...
                                                         T_left, T_right)
    % Construct finite difference system for 1*D steady-state heat equation
    % Governing equation: -k * d²T/dx² = Q
    % 
    % Discretisation using central differences:
    % -k * (T(i-1) - 2*T(i) + T(i+1)) / dx² = Q
    
    % Initialise sparse system matrix and right-hand side vector
    A = spalloc(n, n, 3*n); % Pre-allocate for tridiagonal structure
    b = zeros(n, 1);
    
    % Apply boundary conditions at first node (Dirichlet)
    A(1, 1) = 1.0;
    b(1) = T_left;
    
    % Apply boundary conditions at last node (Dirichlet)
    A(n, n) = 1.0;
    b(n) = T_right;
    
    % Fill interior nodes using finite difference stencil
    % Second derivative approximation: d²T/dx² ≈ (T(i-1) - 2*T(i) + T(i+1))/dx²
    for nodeIdx = 2:(n-1)
        A(nodeIdx, nodeIdx-1) = k / dx^2;
        A(nodeIdx, nodeIdx)   = -2 * k / dx^2;
        A(nodeIdx, nodeIdx+1) = k / dx^2;
        b(nodeIdx) = -Q;
    end
end

function visualiseThermalDistribution(dx, temperature, numNodes)
    % Visualise temperature distribution along domain
    
    % Create spatial position vector
    xPositions = (0:(numNodes-1)) * dx;
    
    figure('Position', [100, 100, 900, 600]);
    
    % Plot temperature distribution
    plot(xPositions, temperature, 'b-', 'LineWidth', 2);
    xlabel('Position $x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Temperature $T$ (°C)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Digital Twin: Steady-State Temperature Distribution', ...
          'Interpreter', 'latex', 'FontSize', 14);
    grid on;
    set(gca, 'FontSize', 11);
    
    % Add annotations for key features
    [maxTemp, maxIdx] = max(temperature);
    [minTemp, minIdx] = min(temperature);
    
    hold on;
    plot(xPositions(maxIdx), maxTemp, 'ro', 'MarkerSize', 10, ...
         'MarkerFaceColor', 'r');
    text(xPositions(maxIdx), maxTemp, ...
         sprintf('  Max: %.1f°C', maxTemp), ...
         'FontSize', 10, 'Color', 'red');
    hold off;
end

function computeThermalGradient(dx, temperature, numNodes)
    % Compute and visualise thermal gradient (heat flux indicator)
    
    % Compute gradient using central differences (interior points)
    thermalGradient = gradient(temperature, dx);
    
    % Create spatial position vector
    xPositions = (0:(numNodes-1)) * dx;
    
    figure('Position', [100, 100, 900, 800]);
    
    % Temperature distribution subplot
    subplot(2, 1, 1);
    plot(xPositions, temperature, 'b-', 'LineWidth', 2);
    ylabel('Temperature $T$ (°C)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Temperature Distribution', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    set(gca, 'FontSize', 11);
    
    % Thermal gradient subplot
    subplot(2, 1, 2);
    plot(xPositions, thermalGradient, 'r-', 'LineWidth', 2);
    xlabel('Position $x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Temperature Gradient $\frac{dT}{dx}$ (°C/m)', ...
           'Interpreter', 'latex', 'FontSize', 12);
    title('Thermal Gradient (Heat Flux Indicator)', 'Interpreter', 'latex', ...
          'FontSize', 13);
    grid on;
    set(gca, 'FontSize', 11);
    
    % Analyse gradient characteristics
    fprintf('\nThermal Gradient Analysis:\n');
    fprintf('  Maximum Gradient: %.2f °C/m\n', max(abs(thermalGradient)));
    fprintf('  Mean Absolute Gradient: %.2f °C/m\n', ...
            mean(abs(thermalGradient)));
end

function verifySolutionAccuracy(A, x, b)
    % Verify numerical solution accuracy through residual analysis
    
    fprintf('\nSolution Verification:\n');
    
    % Compute residual: r = Ax - b
    residual = A * x - b;
    
    % Various residual norms
    residualL2 = norm(residual, 2);
    residualInf = norm(residual, inf);
    relativeResidual = residualL2 / norm(b, 2);
    
    fprintf('  Residual L2-norm: %.6e\n', residualL2);
    fprintf('  Residual Infinity-norm: %.6e\n', residualInf);
    fprintf('  Relative Residual: %.6e\n', relativeResidual);
    
    % Check solution quality
    if relativeResidual < 1e-10
        fprintf('  Solution Quality: Excellent\n');
    elseif relativeResidual < 1e-6
        fprintf('  Solution Quality: Good\n');
    else
        warning('Solution may be inaccurate (high relative residual)');
    end
end
