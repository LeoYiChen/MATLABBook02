%% lst_C01_Lab03.m
% MATLAB--Python signal filtering with a SciPy Butterworth low-pass
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : lst:C01_Lab03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab03.m
% MATLAB synthesises a vibration record; Python SciPy filters it.

fs = 250;
t  = (0:1/fs:4)';
rng(7);
x = sin(2*pi*5*t) + 0.38*sin(2*pi*18*t) + 0.10*randn(size(t));

py.importlib.import_module('scipy_lowpass');
y = double(py.scipy_lowpass.lowpass_filter(py.numpy.array(x), fs, 10.0, 4));

figure('Color', 'w');
tiledlayout(1, 2, 'TileSpacing', 'compact', 'Padding', 'compact');

nexttile
plot(t(t<=2), x(t<=2)); hold on
plot(t(t<=2), y(t<=2), 'LineWidth', 1.6)
xlabel('Time (s)'); ylabel('Amplitude'); xlim([0 2]); grid on
legend({'Raw signal', 'Python-filtered'}, 'Location', 'northeast')
title('(a) Time-domain response')

nexttile
nfft = 4096;
f = (0:nfft-1)*(fs/nfft);
X = 2*abs(fft(x, nfft))/numel(x);
Y = 2*abs(fft(y, nfft))/numel(y);
keep = f <= 30;
plot(f(keep), X(keep)); hold on
plot(f(keep), Y(keep), 'LineWidth', 1.6)
xlabel('Frequency (Hz)'); ylabel('Magnitude'); xlim([0 30]); grid on
legend({'Raw spectrum', 'Filtered spectrum'}, 'Location', 'northeast')
title('(b) Frequency spectrum')
