%% chapter_Problems_sol6.m
% Interactive data visualisation app - key components
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Problems_sol6
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% This is not a complete executable script but demonstrates key components
% to implement in MATLAB's App Designer

% 1. Create the basic app structure
% Open App Designer and create a new app with a suitable layout:
% - Left panel for controls
% - Main area for visualizations
% - Status bar at bottom
% - Menu bar at top

% 2. Component Creation
% Add these components to your app:
% - "Load Data" button
% - Dataset dropdown (for sample datasets)
% - Variable selection lists (for X and Y variables)
% - Plot type dropdown (scatter, histogram, boxplot, etc.)
% - Color scheme selector
% - Statistical analysis options
% - Export buttons

% 3. Key Callbacks to Implement

% 3.1. Load Data Button Callback
function LoadDataButtonPushed(app, event)
% Open file dialog to select a data file
[file, path] = uigetfile({'.csv;.xlsx;.mat', 'Data Files (.csv, .xlsx, .mat)'; ...
'.', 'All Files (.)'}, ...
'Select a data file');
if isequal(file, 0)
% User cancelled
return;
end

% Load the selected file
fullPath = fullfile(path, file);
[~, ~, ext] = fileparts(fullPath);

try
    switch lower(ext)
        case '.csv'
            app.Data = readtable(fullPath);
        case '.xlsx'
            app.Data = readtable(fullPath);
        case '.mat'
            loaded = load(fullPath);
            % Try to find a table in the loaded data
            varNames = fieldnames(loaded);
            found = false;
            for i = 1:length(varNames)
                if istable(loaded.(varNames{i}))
                    app.Data = loaded.(varNames{i});
                    found = true;
                    break;
                end
            end
            if ~found
                % If no table found, try to create one from arrays
                if isfield(loaded, 'X') && isfield(loaded, 'y')
                    app.Data = array2table([loaded.X, loaded.y]);
                    % Generate default variable names
                    varNames = cell(1, size(app.Data, 2));
                    for i = 1:size(loaded.X, 2)
                        varNames{i} = sprintf('X%d', i);
                    end
                    varNames{end} = 'y';
                    app.Data.Properties.VariableNames = varNames;
                else
                    error('No table or recognizable data format found in MAT file');
                end
            end
        otherwise
            error('Unsupported file format');
    end
    
    % Update UI with the loaded data
    updateDataInfo(app);
    updateVariableLists(app);
    
    % Display success message
    app.StatusLabel.Text = sprintf('Data loaded successfully: %s', file);
catch ME
    % Display error message
    app.StatusLabel.Text = sprintf('Error loading data: %s', ME.message);
end

end

% 3.2. Sample Dataset Selection Callback
function SampleDatasetSelected(app, event)
% Get selected dataset
selectedDataset = app.DatasetDropDown.Value;

try
    switch selectedDataset
        case 'Iris'
            load fisheriris;
            app.Data = array2table([meas, grp2idx(species)], ...
                'VariableNames', {'SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth', 'Species'});
            app.Data.Species = nominal(species);
            
        case 'Patients'
            load patients;
            app.Data = patients;
            
        case 'Boston Housing'
            load boston;
            app.Data = array2table([boston.data, boston.medv], ...
                'VariableNames', [boston.colnames, {'MEDV'}]);
            
        case 'Random Data'
            % Generate random multivariate data
            n = 100;
            x1 = randn(n, 1);
            x2 = x1 + 0.5*randn(n, 1);
            x3 = x1 - 0.3*x2 + 0.2*randn(n, 1);
            y = 2*x1 - 1.5*x2 + 0.5*x3 + 0.5*randn(n, 1);
            app.Data = array2table([x1, x2, x3, y], ...
                'VariableNames', {'X1', 'X2', 'X3', 'Y'});
    end
    
    % Update UI with the loaded data
    updateDataInfo(app);
    updateVariableLists(app);
    
    % Display success message
    app.StatusLabel.Text = sprintf('Sample dataset loaded: %s', selectedDataset);
catch ME
    % Display error message
    app.StatusLabel.Text = sprintf('Error loading sample dataset: %s', ME.message);
end

end

% 3.3. Update Variable Lists
function updateVariableLists(app)
if ~isempty(app.Data) && istable(app.Data)
% Get variable names
varNames = app.Data.Properties.VariableNames;

% Update variable selection dropdowns
    app.XVariableDropDown.Items = varNames;
    app.YVariableDropDown.Items = varNames;
    app.ColorVariableDropDown.Items = ['None', varNames];
    app.GroupVariableDropDown.Items = ['None', varNames];
    
    % Set default selections
    if ~isempty(varNames)
        app.XVariableDropDown.Value = varNames{1};
        if length(varNames) > 1
            app.YVariableDropDown.Value = varNames{2};
        else
            app.YVariableDropDown.Value = varNames{1};
        end
        app.ColorVariableDropDown.Value = 'None';
        app.GroupVariableDropDown.Value = 'None';
    end
end

end

% 3.4. Update Data Info
function updateDataInfo(app)
if ~isempty(app.Data) && istable(app.Data)
% Display basic information about the data
[rows, cols] = size(app.Data);
app.DataInfoLabel.Text = sprintf('Data size: %d rows   %d columns', rows, cols);

% Display variable names and types in the data info panel
    infoText = 'Variables:';
    varNames = app.Data.Properties.VariableNames;
    varTypes = varfun(@class, app.Data, 'OutputFormat', 'cell');
    
    for i = 1:length(varNames)
        infoText = [infoText, sprintf('\n  %s (%s)', varNames{i}, varTypes{i})];
    end
    
    app.DataInfoTextArea.Value = infoText;
end

end

% 3.5. Create Visualization
function createVisualization(app)
% Clear previous plot
cla(app.VisualizationAxes);

if isempty(app.Data)
    % No data loaded
    app.StatusLabel.Text = 'No data loaded. Please load data first.';
    return;
end

try
    % Get selected variables
    xVar = app.XVariableDropDown.Value;
    yVar = app.YVariableDropDown.Value;
    colorVar = app.ColorVariableDropDown.Value;
    groupVar = app.GroupVariableDropDown.Value;
    
    % Get plot type
    plotType = app.PlotTypeDropDown.Value;
    
    % Extract data
    x = app.Data.(xVar);
    
    % Create visualization based on plot type
    switch plotType
        case 'Scatter Plot'
            y = app.Data.(yVar);
            
            if strcmp(colorVar, 'None')
                scatter(app.VisualizationAxes, x, y, 36, 'filled');
            else
                c = app.Data.(colorVar);
                scatter(app.VisualizationAxes, x, y, 36, c, 'filled');
                colorbar(app.VisualizationAxes);
                if isnumeric(c)
                    colormap(app.VisualizationAxes, app.ColorMapDropDown.Value);
                end
            end
            
            xlabel(app.VisualizationAxes, xVar);
            ylabel(app.VisualizationAxes, yVar);
            title(app.VisualizationAxes, sprintf('%s vs %s', xVar, yVar));
            grid(app.VisualizationAxes, 'on');
            
            % Add trend line if enabled
            if app.TrendLineCheckBox.Value
                hold(app.VisualizationAxes, 'on');
                p = polyfit(x, y, 1);
                x_fit = linspace(min(x), max(x), 100);
                y_fit = polyval(p, x_fit);
                plot(app.VisualizationAxes, x_fit, y_fit, 'r-', 'LineWidth', 2);
                
                % Add equation to plot
                if p(2) >= 0
                    eqn = sprintf('y = %.4fx + %.4f', p(1), p(2));
                else
                    eqn = sprintf('y = %.4fx - %.4f', p(1), -p(2));
                end
                legend(app.VisualizationAxes, {'Data', eqn}, 'Location', 'best');
                
                % Calculate and display correlation
                r = corr(x, y);
                text(app.VisualizationAxes, min(x) + 0.1*(max(x)-min(x)), ...
                     max(y) - 0.1*(max(y)-min(y)), ...
                     sprintf('r = %.4f', r), 'FontSize', 10);
                
                hold(app.VisualizationAxes, 'off');
            end
            
        case 'Histogram'
            % Determine number of bins
            numBins = app.NumBinsSlider.Value;
            
            % Create histogram
            histogram(app.VisualizationAxes, x, numBins);
            
            xlabel(app.VisualizationAxes, xVar);
            ylabel(app.VisualizationAxes, 'Frequency');
            title(app.VisualizationAxes, sprintf('Histogram of %s', xVar));
            grid(app.VisualizationAxes, 'on');
            
            % Add normal distribution curve if enabled
            if app.NormalCurveCheckBox.Value
                hold(app.VisualizationAxes, 'on');
                
                % Get histogram data
                h = histogram(app.VisualizationAxes, x, numBins);
                
                % Calculate normal distribution
                mu = mean(x);
                sigma = std(x);
                x_range = linspace(min(x), max(x), 100);
                y_norm = normpdf(x_range, mu, sigma);
                
                % Scale to match histogram
                bin_width = (max(x) - min(x)) / numBins;
                scale_factor = sum(h.Values) * bin_width;
                y_norm = y_norm * scale_factor;
                
                % Plot normal curve
                plot(app.VisualizationAxes, x_range, y_norm, 'r-', 'LineWidth', 2);
                
                % Add summary statistics
                stats_text = sprintf('\\mu = %.4f\n\\sigma = %.4f', mu, sigma);
                text(app.VisualizationAxes, min(x) + 0.7*(max(x)-min(x)), ...
                     0.9*max(h.Values), stats_text, 'FontSize', 10);
                
                hold(app.VisualizationAxes, 'off');
            end
            
        case 'Box Plot'
            if strcmp(groupVar, 'None')
                % Simple box plot for one variable
                boxplot(app.VisualizationAxes, x);
                title(app.VisualizationAxes, sprintf('Box Plot of %s', xVar));
            else
                % Grouped box plot
                g = app.Data.(groupVar);
                boxplot(app.VisualizationAxes, x, g);
                title(app.VisualizationAxes, sprintf('Box Plot of %s by %s', xVar, groupVar));
                
                % Rotate x labels if needed
                if length(unique(g)) > 4
                    xtickangle(app.VisualizationAxes, 45);
                end
            end
            
            ylabel(app.VisualizationAxes, xVar);
            grid(app.VisualizationAxes, 'on');
            
        case 'Bar Chart'
            if strcmp(groupVar, 'None')
                % Simple bar chart
                bar(app.VisualizationAxes, x);
                title(app.VisualizationAxes, sprintf('Bar Chart of %s', xVar));
            else
                % Grouped bar chart
                g = app.Data.(groupVar);
                
                % Calculate mean values for each group
                groups = unique(g);
                meanValues = zeros(length(groups), 1);
                
                for i = 1:length(groups)
                    meanValues(i) = mean(x(g == groups(i)));
                end
                
                % Create bar chart
                bar(app.VisualizationAxes, meanValues);
                title(app.VisualizationAxes, sprintf('Mean %s by %s', xVar, groupVar));
                
                % Set x-tick labels
                set(app.VisualizationAxes, 'XTickLabel', groups);
                
                % Rotate x labels if needed
                if length(groups) > 4
                    xtickangle(app.VisualizationAxes, 45);
                end
            end
            
            ylabel(app.VisualizationAxes, xVar);
            grid(app.VisualizationAxes, 'on');
            
        case 'Heatmap'
            % Need both X and Y variables
            y = app.Data.(yVar);
            
            % Create 2D histogram (heatmap)
            histogram2(app.VisualizationAxes, x, y, 'DisplayStyle', 'tile');
            
            % Set colormap
            colormap(app.VisualizationAxes, app.ColorMapDropDown.Value);
            colorbar(app.VisualizationAxes);
            
            xlabel(app.VisualizationAxes, xVar);
            ylabel(app.VisualizationAxes, yVar);
            title(app.VisualizationAxes, sprintf('2D Histogram of %s vs %s', xVar, yVar));
            grid(app.VisualizationAxes, 'on');
    end
    
    % Apply plot style customizations
    if app.GridCheckBox.Value
        grid(app.VisualizationAxes, 'on');
    else
        grid(app.VisualizationAxes, 'off');
    end
    
    if app.LogXCheckBox.Value
        set(app.VisualizationAxes, 'XScale', 'log');
    else
        set(app.VisualizationAxes, 'XScale', 'linear');
    end
    
    if app.LogYCheckBox.Value
        set(app.VisualizationAxes, 'YScale', 'log');
    else
        set(app.VisualizationAxes, 'YScale', 'linear');
    end
    
    % Update status
    app.StatusLabel.Text = 'Visualization created successfully.';
    
catch ME
    % Display error message
    app.StatusLabel.Text = sprintf('Error creating visualization: %s', ME.message);
end

end

% 3.6. Calculate Statistics
function calculateStatistics(app)
if isempty(app.Data)
app.StatusLabel.Text = 'No data loaded. Please load data first.';
return;
end

try
    % Get selected variable
    xVar = app.XVariableDropDown.Value;
    x = app.Data.(xVar);
    
    % Calculate basic statistics
    stats = struct();
    stats.mean = mean(x);
    stats.median = median(x);
    stats.std = std(x);
    stats.min = min(x);
    stats.max = max(x);
    stats.range = stats.max - stats.min;
    stats.q1 = quantile(x, 0.25);
    stats.q3 = quantile(x, 0.75);
    stats.iqr = stats.q3 - stats.q1;
    
    % Display statistics in the app
    statsText = sprintf('Statistics for %s:\n\n', xVar);
    statsText = [statsText, sprintf('Mean: %.4f\n', stats.mean)];
    statsText = [statsText, sprintf('Median: %.4f\n', stats.median)];
    statsText = [statsText, sprintf('Standard Deviation: %.4f\n', stats.std)];
    statsText = [statsText, sprintf('Minimum: %.4f\n', stats.min)];
    statsText = [statsText, sprintf('Maximum: %.4f\n', stats.max)];
    statsText = [statsText, sprintf('Range: %.4f\n', stats.range)];
    statsText = [statsText, sprintf('25th Percentile: %.4f\n', stats.q1)];
    statsText = [statsText, sprintf('75th Percentile: %.4f\n', stats.q3)];
    statsText = [statsText, sprintf('Interquartile Range: %.4f\n', stats.iqr)];
    
    % If both X and Y variables are selected, calculate correlation
    if ~strcmp(app.YVariableDropDown.Value, app.XVariableDropDown.Value)
        yVar = app.YVariableDropDown.Value;
        y = app.Data.(yVar);
        
        % Calculate correlation if both are numeric
        if isnumeric(x) && isnumeric(y)
            r = corr(x, y);
            r2 = r^2;
            statsText = [statsText, sprintf('\nCorrelation with %s:\n', yVar)];
            statsText = [statsText, sprintf('Pearson''s r: %.4f\n', r)];
            statsText = [statsText, sprintf('R: %.4f\n', r2)];
        end
    end
    
    % Display the statistics
    app.StatisticsTextArea.Value = statsText;
    
    % Update status
    app.StatusLabel.Text = 'Statistics calculated successfully.';
catch ME
    % Display error message
    app.StatusLabel.Text = sprintf('Error calculating statistics: %s', ME.message);
end

end

% 3.7. Export Results
function exportFigureButtonPushed(app, event)
if isempty(app.VisualizationAxes.Children)
app.StatusLabel.Text = 'No visualization to export.';
return;
end

try
    % Configure export dialog
    [file, path] = uiputfile({'*.png', 'PNG Image (*.png)'; ...
                              '*.jpg', 'JPEG Image (*.jpg)'; ...
                              '*.pdf', 'PDF Document (*.pdf)'; ...
                              '*.fig', 'MATLAB Figure (*.fig)'}, ...
                             'Export visualization as');
    if isequal(file, 0)
        % User cancelled
        return;
    end
    
    % Get full path
    fullPath = fullfile(path, file);
    [~, ~, ext] = fileparts(fullPath);
    
    % Create a new figure with the visualization
    fig = figure('Visible', 'off');
    ax = axes(fig);
    
    % Copy properties from app.VisualizationAxes to the new axes
    copyAxes(app.VisualizationAxes, ax);
    
    % Export the figure
    switch lower(ext)
        case '.png'
            exportgraphics(ax, fullPath, 'Resolution', 300);
        case '.jpg'
            exportgraphics(ax, fullPath, 'Resolution', 300);
        case '.pdf'
            exportgraphics(ax, fullPath);
        case '.fig'
            savefig(fig, fullPath);
    end
    
    % Close the temporary figure
    close(fig);
    
    % Update status
    app.StatusLabel.Text = sprintf('Visualization exported to %s', fullPath);
catch ME
    % Display error message
    app.StatusLabel.Text = sprintf('Error exporting visualization: %s', ME.message);
end

end

% Helper function to copy axes properties
function copyAxes(source, target)
% Copy all children
copyobj(source.Children, target);

% Copy axes properties
target.XLabel.String = source.XLabel.String;
target.YLabel.String = source.YLabel.String;
target.Title.String = source.Title.String;
target.XLim = source.XLim;
target.YLim = source.YLim;
target.XScale = source.XScale;
target.YScale = source.YScale;
target.XGrid = source.XGrid;
target.YGrid = source.YGrid;

% Copy colormap if applicable
if ~isempty(source.Colormap)
    colormap(target, source.Colormap);
end

% Copy any existing colorbars
if ~isempty(findobj(source.Parent, 'Type', 'ColorBar'))
    colorbar(target);
end

end

% 3.8. Export Data Button Callback
function exportDataButtonPushed(app, event)
if isempty(app.Data)
app.StatusLabel.Text = 'No data to export.';
return;
end

try
    % Configure export dialog
    [file, path] = uiputfile({'*.csv', 'CSV File (*.csv)'; ...
                              '*.xlsx', 'Excel Spreadsheet (*.xlsx)'; ...
                              '*.mat', 'MATLAB Data File (*.mat)'}, ...
                             'Export data as');
    if isequal(file, 0)
        % User cancelled
        return;
    end
    
    % Get full path
    fullPath = fullfile(path, file);
    [~, ~, ext] = fileparts(fullPath);
    
    % Export the data
    switch lower(ext)
        case '.csv'
            writetable(app.Data, fullPath);
        case '.xlsx'
            writetable(app.Data, fullPath);
        case '.mat'
            data = app.Data;
            save(fullPath, 'data');
    end
    
    % Update status
    app.StatusLabel.Text = sprintf('Data exported to %s', fullPath);
catch ME
    % Display error message
    app.StatusLabel.Text = sprintf('Error exporting data: %s', ME.message);
end

end

% 4. Complete App Creation
% Once you've implemented all the above callbacks and components,
% connect them to the appropriate UI elements. Make sure to:
% - Initialize app properties (e.g., app.Data = table())
% - Set default values for all UI components
% - Create StartupFcn to initialize the app
% - Implement necessary helper functions

% 5. Sample Datasets
% Include code to generate/load sample datasets in your app's StartupFcn
function startupFcn(app)
% Initialize data property
app.Data = table();

% Set default values for UI components
app.DatasetDropDown.Items = {'Iris', 'Patients', 'Boston Housing', 'Random Data'};
app.DatasetDropDown.Value = 'Iris';

app.PlotTypeDropDown.Items = {'Scatter Plot', 'Histogram', 'Box Plot', 'Bar Chart', 'Heatmap'};
app.PlotTypeDropDown.Value = 'Scatter Plot';

app.ColorMapDropDown.Items = {'parula', 'jet', 'hsv', 'hot', 'cool', 'spring', 'summer', 'autumn', 'winter', 'gray', 'bone', 'copper', 'pink', 'lines'};
app.ColorMapDropDown.Value = 'parula';

% Load initial dataset (Iris)
SampleDatasetSelected(app, []);

end
