%% chapter_AIforMechatronics_problem07_code.m
% Object detection algorithm comparison and selection.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem07_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 7: Object Detection Algorithm Comparison and Selection
% Author: Dr Yi Chen
% Purpose: Compare object detection algorithms for mechatronic applications
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox, Computer Vision Toolbox
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Generate synthetic object detection dataset
fprintf('=== Object Detection Algorithm Comparison ===\n\n');
fprintf('Step 1: Generating synthetic detection dataset...\n');

% Dataset parameters
imageSize = [256, 256, 3];
numClasses = 3;
classNames = {'Circle', 'Rectangle', 'Triangle'};
numImages = 600;
maxObjectsPerImage = 5;
minObjectSize = 20;
maxObjectSize = 60;

% Preallocate storage
allImages = uint8(zeros([imageSize, numImages]));
allBoundingBoxes = cell(numImages, 1);
allLabels = cell(numImages, 1);

% Generate synthetic images
for imgIdx = 1:numImages
    % Create blank image with textured background
    currentImage = uint8(200 * ones(imageSize(1), imageSize(2), imageSize(3)));
    
    % Add random texture
    backgroundTexture = uint8(30 * randn(imageSize(1), imageSize(2)));
    for c = 1:3
        currentImage(:, :, c) = currentImage(:, :, c) + backgroundTexture;
    end
    
    % Determine number of objects
    numObjects = randi([1, maxObjectsPerImage]);
    bboxes = zeros(numObjects, 4);
    labels = cell(numObjects, 1);
    
    for objIdx = 1:numObjects
        % Random object class
        classIdx = randi([1, numClasses]);
        
        % Random size and position
        objectSize = randi([minObjectSize, maxObjectSize]);
        margin = maxObjectSize;
        xCentre = randi([margin, imageSize(2) - margin]);
        yCentre = randi([margin, imageSize(1) - margin]);
        
        % Random colour
        objectColour = uint8([randi([50, 255]), randi([50, 255]), randi([50, 255])]);
        
        % Draw object based on class
        switch classIdx
            case 1 % Circle
                currentImage = insertShape(currentImage, 'FilledCircle', ...
                    [xCentre, yCentre, objectSize/2], ...
                    'Color', double(objectColour), 'Opacity', 1);
                labels{objIdx} = 'Circle';
                
            case 2 % Rectangle
                width = objectSize + randi([-10, 10]);
                height = objectSize + randi([-10, 10]);
                currentImage = insertShape(currentImage, 'FilledRectangle', ...
                    [xCentre - width/2, yCentre - height/2, width, height], ...
                    'Color', double(objectColour), 'Opacity', 1);
                labels{objIdx} = 'Rectangle';
                objectSize = max(width, height);
                
            case 3 % Triangle
                x1 = xCentre;
                y1 = yCentre - objectSize/2;
                x2 = xCentre - objectSize/2;
                y2 = yCentre + objectSize/2;
                x3 = xCentre + objectSize/2;
                y3 = yCentre + objectSize/2;
                
                currentImage = insertShape(currentImage, 'FilledPolygon', ...
                    [x1, y1, x2, y2, x3, y3], ...
                    'Color', double(objectColour), 'Opacity', 1);
                labels{objIdx} = 'Triangle';
        end
        
        % Store bounding box [xmin, ymin, width, height]
        bboxes(objIdx, :) = [xCentre - objectSize/2, ...
            yCentre - objectSize/2, objectSize, objectSize];
    end
    
    % Store image and annotations
    allImages(:, :, :, imgIdx) = currentImage;
    allBoundingBoxes{imgIdx} = bboxes;
    allLabels{imgIdx} = categorical(labels);
end

fprintf('  Generated %d images\n', numImages);
fprintf('  Object classes: %d\n', numClasses);
fprintf('  Average objects per image: %.2f\n', ...
    mean(cellfun(@length, allLabels)));

%% Step 2: Split dataset
fprintf('\nStep 2: Splitting dataset...\n');

trainRatio = 0.70;
valRatio = 0.15;
testRatio = 0.15;

[trainIdx, valIdx, testIdx] = dividerand(numImages, ...
    trainRatio, valRatio, testRatio);

trainImages = allImages(:, :, :, trainIdx);
trainBoxes = allBoundingBoxes(trainIdx);
trainLabels = allLabels(trainIdx);

testImages = allImages(:, :, :, testIdx);
testBoxes = allBoundingBoxes(testIdx);
testLabels = allLabels(testIdx);

fprintf('  Training images: %d\n', length(trainIdx));
fprintf('  Validation images: %d\n', length(valIdx));
fprintf('  Test images: %d\n', length(testIdx));

%% Step 3: Implement simplified anchor-based detector (YOLO-style)
fprintf('\nStep 3: Implementing anchor-based detector...\n');

% For simplicity, we'll use a classification + regression approach
% Real YOLO uses grid-based anchor predictions

% Define network architecture
layersYOLO = [
    imageInputLayer(imageSize, 'Name', 'input', 'Normalization', 'none')
    
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
    
    convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv4')
    batchNormalizationLayer('Name', 'bn4')
    reluLayer('Name', 'relu4')
    globalAveragePooling2dLayer('Name', 'gap')
    
    fullyConnectedLayer(128, 'Name', 'fc1')
    reluLayer('Name', 'relu_fc1')
    dropoutLayer(0.5, 'Name', 'dropout')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc_class')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

fprintf('  YOLO-style detector architecture defined\n');

%% Step 4: Train anchor-based detector
fprintf('\nStep 4: Training anchor-based detector...\n');

% Simplify to classification (for demonstration)
trainLabelsSimple = categorical(zeros(length(trainIdx), 1));
for imgIdx = 1:length(trainIdx)
    if ~isempty(trainLabels{imgIdx})
        trainLabelsSimple(imgIdx) = trainLabels{imgIdx}(1);
    else
        trainLabelsSimple(imgIdx) = categorical({'Circle'});
    end
end

testLabelsSimple = categorical(zeros(length(testIdx), 1));
for imgIdx = 1:length(testIdx)
    if ~isempty(testLabels{imgIdx})
        testLabelsSimple(imgIdx) = testLabels{imgIdx}(1);
    else
        testLabelsSimple(imgIdx) = categorical({'Circle'});
    end
end

% Training options
trainingOptionsYOLO = trainingOptions('adam', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 15, ...
    'MiniBatchSize', 16, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
networkYOLO = trainNetwork(trainImages, trainLabelsSimple, ...
    layersYOLO, trainingOptionsYOLO);
trainingTimeYOLO = toc;

fprintf('  Anchor-based detector trained in %.2f seconds\n', trainingTimeYOLO);

%% Step 5: Implement lightweight detector
fprintf('\nStep 5: Implementing lightweight detector...\n');

% Simplified, faster architecture
layersLight = [
    imageInputLayer(imageSize, 'Name', 'input', 'Normalization', 'none')
    
    convolution2dLayer(3, 16, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    globalAveragePooling2dLayer('Name', 'gap')
    
    fullyConnectedLayer(64, 'Name', 'fc1')
    reluLayer('Name', 'relu_fc1')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc_class')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

fprintf('  Lightweight detector architecture defined\n');

%% Step 6: Train lightweight detector
fprintf('\nStep 6: Training lightweight detector...\n');

trainingOptionsLight = trainingOptions('adam', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 15, ...
    'MiniBatchSize', 16, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
networkLight = trainNetwork(trainImages, trainLabelsSimple, ...
    layersLight, trainingOptionsLight);
trainingTimeLight = toc;

fprintf('  Lightweight detector trained in %.2f seconds\n', trainingTimeLight);

%% Step 7: Evaluate detection performance
fprintf('\nStep 7: Evaluating detection performance...\n');

% Test accuracy
predictedYOLO = classify(networkYOLO, testImages);
accuracyYOLO = sum(predictedYOLO == testLabelsSimple) / numel(testLabelsSimple);

predictedLight = classify(networkLight, testImages);
accuracyLight = sum(predictedLight == testLabelsSimple) / numel(testLabelsSimple);

fprintf('  YOLO-style accuracy: %.2f%%\n', accuracyYOLO * 100);
fprintf('  Lightweight accuracy: %.2f%%\n', accuracyLight * 100);

%% Step 8: Inference speed benchmarking
fprintf('\nStep 8: Benchmarking inference speed...\n');

numTimingRuns = 100;

% YOLO-style inference timing
inferenceTimesYOLO = zeros(numTimingRuns, 1);
for runIdx = 1:numTimingRuns
    sampleImage = testImages(:, :, :, randi(length(testIdx)));
    tic;
    classify(networkYOLO, sampleImage);
    inferenceTimesYOLO(runIdx) = toc * 1000; % ms
end

avgInferenceYOLO = mean(inferenceTimesYOLO);
fpsYOLO = 1000 / avgInferenceYOLO;

% Lightweight inference timing
inferenceTimesLight = zeros(numTimingRuns, 1);
for runIdx = 1:numTimingRuns
    sampleImage = testImages(:, :, :, randi(length(testIdx)));
    tic;
    classify(networkLight, sampleImage);
    inferenceTimesLight(runIdx) = toc * 1000; % ms
end

avgInferenceLight = mean(inferenceTimesLight);
fpsLight = 1000 / avgInferenceLight;

fprintf('  YOLO-style: %.2f ms (%.1f FPS)\n', avgInferenceYOLO, fpsYOLO);
fprintf('  Lightweight: %.2f ms (%.1f FPS)\n', avgInferenceLight, fpsLight);

%% Step 9: Compute precision-recall curves
fprintf('\nStep 9: Computing precision-recall curves...\n');

% Get prediction scores for PR curve
[~, scoresYOLO] = classify(networkYOLO, testImages);
[~, scoresLight] = classify(networkLight, testImages);

% Compute precision-recall for each class
numThresholds = 100;
thresholds = linspace(0, 1, numThresholds);

precisionYOLO = zeros(numClasses, numThresholds);
recallYOLO = zeros(numClasses, numThresholds);
precisionLight = zeros(numClasses, numThresholds);
recallLight = zeros(numClasses, numThresholds);

for classIdx = 1:numClasses
    className = classNames{classIdx};
    
    % Ground truth binary labels for this class
    gtBinary = (testLabelsSimple == className);
    
    % Prediction scores for this class
    scoresYOLOClass = scoresYOLO(:, classIdx);
    scoresLightClass = scoresLight(:, classIdx);
    
    % Compute PR curve for YOLO
    for thIdx = 1:numThresholds
        threshold = thresholds(thIdx);
        
        % YOLO predictions
        predBinaryYOLO = scoresYOLOClass >= threshold;
        TP_YOLO = sum(predBinaryYOLO & gtBinary);
        FP_YOLO = sum(predBinaryYOLO & ~gtBinary);
        FN_YOLO = sum(~predBinaryYOLO & gtBinary);
        
        if (TP_YOLO + FP_YOLO) > 0
            precisionYOLO(classIdx, thIdx) = TP_YOLO / (TP_YOLO + FP_YOLO);
        else
            precisionYOLO(classIdx, thIdx) = 0;
        end
        
        if (TP_YOLO + FN_YOLO) > 0
            recallYOLO(classIdx, thIdx) = TP_YOLO / (TP_YOLO + FN_YOLO);
        else
            recallYOLO(classIdx, thIdx) = 0;
        end
        
        % Lightweight predictions
        predBinaryLight = scoresLightClass >= threshold;
        TP_Light = sum(predBinaryLight & gtBinary);
        FP_Light = sum(predBinaryLight & ~gtBinary);
        FN_Light = sum(~predBinaryLight & gtBinary);
        
        if (TP_Light + FP_Light) > 0
            precisionLight(classIdx, thIdx) = TP_Light / (TP_Light + FP_Light);
        else
            precisionLight(classIdx, thIdx) = 0;
        end
        
        if (TP_Light + FN_Light) > 0
            recallLight(classIdx, thIdx) = TP_Light / (TP_Light + FN_Light);
        else
            recallLight(classIdx, thIdx) = 0;
        end
    end
end

fprintf('  Precision-recall curves computed for all classes\n');

%% Step 10: Visualisation and comparison
fprintf('\nStep 10: Generating comparison visualisations...\n');

figure('Name', 'Object Detection Algorithm Comparison', ...
    'Position', [100, 100, 1400, 900]);

% Precision-Recall curves
subplot(2, 3, 1);
hold on;
colours = {'r', 'g', 'b'};
for classIdx = 1:numClasses
    plot(recallYOLO(classIdx, :), precisionYOLO(classIdx, :), ...
        [colours{classIdx}, '-'], 'LineWidth', 1.5, ...
        'DisplayName', ['YOLO: ', classNames{classIdx}]);
    plot(recallLight(classIdx, :), precisionLight(classIdx, :), ...
        [colours{classIdx}, '-'], 'LineWidth', 1.5, ...
        'DisplayName', ['Light: ', classNames{classIdx}]);
end
xlabel('Recall', 'Interpreter', 'latex');
ylabel('Precision', 'Interpreter', 'latex');
title('Precision-Recall Curves', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'southwest');
grid on;
xlim([0, 1]);
ylim([0, 1]);
hold off;

% Accuracy comparison
subplot(2, 3, 2);
accuracies = [accuracyYOLO, accuracyLight] * 100;
bar(accuracies);
set(gca, 'XTickLabel', {'YOLO-style', 'Lightweight'});
ylabel('Accuracy (\%)', 'Interpreter', 'latex');
title('Classification Accuracy', 'Interpreter', 'latex');
grid on;

% Inference speed comparison
subplot(2, 3, 3);
inferenceTimes = [avgInferenceYOLO, avgInferenceLight];
bar(inferenceTimes);
set(gca, 'XTickLabel', {'YOLO-style', 'Lightweight'});
ylabel('Inference Time (ms)', 'Interpreter', 'latex');
title('Inference Speed', 'Interpreter', 'latex');
grid on;

% FPS comparison
subplot(2, 3, 4);
fpsValues = [fpsYOLO, fpsLight];
bar(fpsValues);
set(gca, 'XTickLabel', {'YOLO-style', 'Lightweight'});
ylabel('Frames Per Second', 'Interpreter', 'latex');
title('Real-Time Performance', 'Interpreter', 'latex');
grid on;

% Accuracy vs Speed trade-off
subplot(2, 3, 5);
scatter(inferenceTimes, accuracies, 200, 'filled');
for modelIdx = 1:2
    modelNames = {'YOLO', 'Light'};
    text(inferenceTimes(modelIdx) + 0.5, accuracies(modelIdx), ...
        modelNames{modelIdx}, 'Interpreter', 'latex', 'FontSize', 10);
end
xlabel('Inference Time (ms)', 'Interpreter', 'latex');
ylabel('Accuracy (\%)', 'Interpreter', 'latex');
title('Accuracy-Speed Trade-off', 'Interpreter', 'latex');
grid on;

% Sample detection visualisation
subplot(2, 3, 6);
sampleIdx = randi(length(testIdx));
sampleImage = testImages(:, :, :, sampleIdx);
imshow(sampleImage);
title(sprintf('Sample Detection: %s', ...
    char(testLabelsSimple(sampleIdx))), 'Interpreter', 'latex');

suptitle('Object Detection Performance Analysis', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 7 completed successfully.\n');
