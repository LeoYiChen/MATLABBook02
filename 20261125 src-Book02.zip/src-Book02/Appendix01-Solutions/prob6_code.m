%% prob6_code.m
% Animation of cantilever beam vibration.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob6_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Animation: Cantilever Beam Vibration Analysis
% File: MATLABBook02_Chapter07_Problem06.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Creates animated visualisations of beam vibration including
%              deflection shape evolution and frequency domain analysis
% =========================================================================

function MATLABBook02_Chapter07_Problem06()
    % Main function for Problem 6: Animation and Dynamic Visualisation
    
    clc; clear; close all;
    
    % Define beam and vibration parameters
    beamParams = defineBeamParameters();
    
    % Generate vibration data
    [x, t, displacement, velocity] = generateBeamVibrationData(beamParams);
    
    % Create static snapshot visualisation
    createSnapshotPlots(x, t, displacement);
    
    % Generate animated beam deflection
    animateBeamDeflection(x, t, displacement, beamParams);
    
    % Create comet plot for tip displacement
    createCometPlotTipMotion(t, displacement, x);
    
    % Animate phase space
    animatePhaseSpace(displacement, velocity, x);
    
    % Display summary statistics
    displayVibrationStatistics(displacement, velocity, t, x);
end

function params = defineBeamParameters()
    % DEFINEBEAMPARAMETERS - Sets beam geometry and vibration properties
    
    params.length = 1.0;           % Beam length (m)
    params.frequency_1 = 5.0;      % First mode frequency (Hz)
    params.frequency_2 = 31.2;     % Second mode frequency (Hz)
    params.amplitude_1 = 0.05;     % First mode amplitude (m)
    params.amplitude_2 = 0.01;     % Second mode amplitude (m)
    params.phase_1 = 0;            % First mode phase (rad)
    params.phase_2 = pi/4;         % Second mode phase (rad)
    params.damping = 0.02;         % Damping ratio
end

function [x, t, u, v] = generateBeamVibrationData(params)
    % GENERATEBEAMVIBRATIONDATA - Simulates cantilever vibration
    %
    % Uses modal superposition with first two modes
    
    % Spatial discretisation
    numPoints = 20;
    x = linspace(0, params.length, numPoints);
    
    % Time discretisation (2 complete cycles of fundamental)
    period_1 = 1 / params.frequency_1;
    numTimeSteps = 100;
    t = linspace(0, 2*period_1, numTimeSteps);
    
    % Angular frequencies
    omega_1 = 2 * pi * params.frequency_1;
    omega_2 = 2 * pi * params.frequency_2;
    
    % Damped angular frequencies
    omega_d1 = omega_1 * sqrt(1 - params.damping^2);
    omega_d2 = omega_2 * sqrt(1 - params.damping^2);
    
    % Initialise displacement and velocity matrices
    u = zeros(numTimeSteps, numPoints);
    v = zeros(numTimeSteps, numPoints);
    
    % Calculate mode shapes (cantilever beam)
    beta_1 = 1.875;  % First mode eigenvalue
    beta_2 = 4.694;  % Second mode eigenvalue
    
    for i = 1:numPoints
        xi = x(i) / params.length;  % Normalised position
        
        % First mode shape
        phi_1 = (cosh(beta_1*xi) - cos(beta_1*xi)) - ...
               ((cosh(beta_1) + cos(beta_1)) / (sinh(beta_1) + sin(beta_1))) * ...
               (sinh(beta_1*xi) - sin(beta_1*xi));
        
        % Second mode shape
        phi_2 = (cosh(beta_2*xi) - cos(beta_2*xi)) - ...
               ((cosh(beta_2) + cos(beta_2)) / (sinh(beta_2) + sin(beta_2))) * ...
               (sinh(beta_2*xi) - sin(beta_2*xi));
        
        for j = 1:numTimeSteps
            % Damped harmonic response
            exp_decay_1 = exp(-params.damping * omega_1 * t(j));
            exp_decay_2 = exp(-params.damping * omega_2 * t(j));
            
            q_1 = params.amplitude_1 * exp_decay_1 * ...
                 cos(omega_d1 * t(j) + params.phase_1);
            q_2 = params.amplitude_2 * exp_decay_2 * ...
                 cos(omega_d2 * t(j) + params.phase_2);
            
            % Modal velocities
            q_dot_1 = -params.amplitude_1 * exp_decay_1 * ...
                     (params.damping * omega_1 * cos(omega_d1*t(j) + params.phase_1) + ...
                      omega_d1 * sin(omega_d1*t(j) + params.phase_1));
            q_dot_2 = -params.amplitude_2 * exp_decay_2 * ...
                     (params.damping * omega_2 * cos(omega_d2*t(j) + params.phase_2) + ...
                      omega_d2 * sin(omega_d2*t(j) + params.phase_2));
            
            % Superposition
            u(j,i) = phi_1 * q_1 + phi_2 * q_2;
            v(j,i) = phi_1 * q_dot_1 + phi_2 * q_dot_2;
        end
    end
end

function createSnapshotPlots(x, t, u)
    % CREATESNAPSHOTPLOTS - Shows deflection at key time instants
    
    figure('Name', 'Snapshot Visualisation', 'Position', [50, 50, 1200, 800]);
    
    % Select 9 equally-spaced time instants
    snapshotIndices = round(linspace(1, length(t), 9));
    
    for i = 1:9
        subplot(3, 3, i);
        
        idx = snapshotIndices(i);
        plot(x, u(idx,:), 'b-', 'LineWidth', 2);
        hold on;
        plot(x, zeros(size(x)), 'k-', 'LineWidth', 1);
        scatter(x, u(idx,:), 40, 'filled', 'MarkerFaceColor', 'r');
        
        xlabel('Position, $x$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
        ylabel('Displacement, $u$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
        title(sprintf('$t = %.3f$ s', t(idx)), 'Interpreter', 'latex', ...
              'FontSize', 11, 'FontWeight', 'bold');
        
        ylim([min(u(:))*1.2, max(u(:))*1.2]);
        grid on;
        set(gca, 'LineWidth', 1.2);
        hold off;
    end
    
    sgtitle('Cantilever Beam Deflection Snapshots', 'Interpreter', 'latex', ...
           'FontSize', 13, 'FontWeight', 'bold');
end

function animateBeamDeflection(x, t, u, params)
    % ANIMATEBEAMDEFLECTION - Creates smooth animation of beam vibration
    
    fprintf('\n=== Generating Beam Deflection Animation ===\n');
    fprintf('Animation duration: %.2f seconds\n', max(t));
    fprintf('Number of frames: %d\n', length(t));
    
    fig = figure('Name', 'Animated Beam Deflection', ...
                'Position', [100, 100, 1000, 400]);
    
    % Prepare video writer
    videoFile = 'beam_vibration_animation.avi';
    vidObj = VideoWriter(videoFile);
    vidObj.FrameRate = 20;
    open(vidObj);
    
    for i = 1:length(t)
        % Clear previous plot
        clf;
        
        % Plot beam deflection
        plot(x, u(i,:), 'b-', 'LineWidth', 3);
        hold on;
        
        % Plot undeformed position
        plot(x, zeros(size(x)), 'k-', 'LineWidth', 1.5);
        
        % Highlight tip displacement
        scatter(x(end), u(i,end), 100, 'r', 'filled', 'MarkerEdgeColor', 'k');
        
        % Add grid and labels
        xlabel('Beam Length, $x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('Displacement, $u(x,t)$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('Cantilever Beam Vibration: $t = %.3f$ s (Frame %d/%d)', ...
              t(i), i, length(t)), 'Interpreter', 'latex', ...
              'FontSize', 13, 'FontWeight', 'bold');
        
        ylim([min(u(:))*1.3, max(u(:))*1.3]);
        xlim([0, params.length]);
        grid on;
        set(gca, 'LineWidth', 1.2, 'FontSize', 11);
        
        % Add time indicator
        text(0.05, 0.9*max(u(:)), sprintf('$f_1 = %.1f$ Hz, $f_2 = %.1f$ Hz', ...
            params.frequency_1, params.frequency_2), 'Interpreter', 'latex', ...
            'FontSize', 10, 'BackgroundColor', 'w', 'EdgeColor', 'k');
        
        hold off;
        
        % Capture frame
        drawnow;
        frame = getframe(fig);
        writeVideo(vidObj, frame);
    end
    
    close(vidObj);
    fprintf('Animation saved to: %s\n', videoFile);
    
    % Display final message
    msgbox(sprintf('Animation created successfully!\n\nFile: %s\nFrames: %d', ...
           videoFile, length(t)), 'Animation Complete');
end

function createCometPlotTipMotion(t, u, x)
    % CREATECOMETPLOTTIPMOTION - Shows tip displacement time-history
    
    figure('Name', 'Comet Plot: Tip Displacement', ...
           'Position', [150, 150, 900, 500]);
    
    tipDisplacement = u(:, end);
    
    % Create comet plot with tail length of 30 points
    comet(t, tipDisplacement, 0.3);
    
    xlabel('Time, $t$ (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Tip Displacement, $u(L,t)$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Comet Plot: Cantilever Tip Displacement History', ...
          'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    
    grid on;
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    
    fprintf('\nTip Displacement Statistics:\n');
    fprintf('Maximum: %.4f m\n', max(tipDisplacement));
    fprintf('Minimum: %.4f m\n', min(tipDisplacement));
    fprintf('Range: %.4f m\n', max(tipDisplacement) - min(tipDisplacement));
end

function animatePhaseSpace(u, v, x)
    % ANIMATEPHASESPACE - Creates phase portrait animation
    
    fprintf('\n=== Generating Phase Space Animation ===\n');
    
    % Use tip motion for phase space
    tipU = u(:, end);
    tipV = v(:, end);
    
    figure('Name', 'Phase Space Animation', 'Position', [200, 200, 700, 700]);
    
    % Plot complete trajectory (faded)
    plot(tipU, tipV, 'Color', [0.7, 0.7, 0.7], 'LineWidth', 1);
    hold on;
    
    % Animated point
    h = plot(tipU(1), tipV(1), 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
    
    % Plot formatting
    xlabel('Displacement, $u$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Velocity, $\dot{u}$ (m/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Phase Space Portrait: Tip Motion', 'Interpreter', 'latex', ...
          'FontSize', 13, 'FontWeight', 'bold');
    
    grid on;
    axis equal;
    xlim([min(tipU)*1.2, max(tipU)*1.2]);
    ylim([min(tipV)*1.2, max(tipV)*1.2]);
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    
    % Animate moving point
    for i = 1:length(tipU)
        set(h, 'XData', tipU(i), 'YData', tipV(i));
        drawnow;
        pause(0.02);
    end
    
    hold off;
    fprintf('Phase space animation complete.\n');
end

function displayVibrationStatistics(u, v, t, x)
    % DISPLAYVIBRATIONSTATISTICS - Summarises vibration characteristics
    
    fprintf('\n========================================\n');
    fprintf('   VIBRATION ANALYSIS SUMMARY\n');
    fprintf('========================================\n');
    
    % Calculate energy metrics
    tipU = u(:, end);
    tipV = v(:, end);
    
    % Peak displacement and velocity
    maxDisp = max(abs(tipU));
    maxVel = max(abs(tipV));
    
    fprintf('Tip Motion Characteristics:\n');
    fprintf('  Maximum Displacement: %.4f m\n', maxDisp);
    fprintf('  Maximum Velocity: %.4f m/s\n', maxVel);
    
    % Estimate dominant frequency using zero-crossings
    zeroCrossings = find(diff(sign(tipU)));
    if length(zeroCrossings) >= 2
        period = 2 * mean(diff(t(zeroCrossings)));
        frequency = 1 / period;
        fprintf('  Dominant Frequency: %.2f Hz\n', frequency);
    end
    
    % RMS values
    rmsDisp = sqrt(mean(tipU.^2));
    rmsVel = sqrt(mean(tipV.^2));
    
    fprintf('\nRMS Values:\n');
    fprintf('  RMS Displacement: %.4f m\n', rmsDisp);
    fprintf('  RMS Velocity: %.4f m/s\n', rmsVel);
    
    fprintf('========================================\n');
end
