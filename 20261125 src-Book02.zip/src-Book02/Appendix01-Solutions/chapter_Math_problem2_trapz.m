%% chapter_Math_problem2_trapz.m
% Trapezoidal rule syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem2_trapz
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Trapezoidal rule for equally-spaced data
x = linspace(a, b, n+1);  % n intervals, n+1 points
y = f(x);
W = trapz(x, y);  % Built-in trapezoidal integration
