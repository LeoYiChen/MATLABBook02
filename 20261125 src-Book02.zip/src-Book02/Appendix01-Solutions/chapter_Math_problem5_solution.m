%% chapter_Math_problem5_solution.m
% Eigenvalue and eigenvector computation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem5_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem5_Eigenvalues()
    % PROBLEM5_EIGENVALUES Comprehensive eigenvalue/eigenvector analysis
    %
    % This function demonstrates:
    % - Characteristic equation method (manual)
    % - MATLAB's built-in eig() function
    % - Power iteration for dominant eigenvalue
    % - Inverse iteration for smallest eigenvalue
    % - QR algorithm visualization
    % - Diagonalization and matrix powers
    % - Geometric interpretation and visualization
    % - Spectral analysis (trace, determinant, condition number)
    % - Applications: PageRank, vibration analysis, PCA
    %
    % References:
    % - Golub & Van Loan, "Matrix Computations" (2013)
    % - Strang, "Linear Algebra and Its Applications" (2016)
    % - Trefethen & Bau, "Numerical Linear Algebra" (1997)
    %
    % Author: Dr Yi Chen
    % Date: 2025
    % MATLAB Version: R2023b or later
    
    fprintf('\n=== Problem 5: Eigenvalues and Eigenvectors ===\n\n');
    
    % Define matrix
    A = [4, -2; 
         1,  1];
    
    fprintf('Matrix A:\n');
    disp(A);
    
    % Analyze matrix properties
    fprintf('=== Matrix Analysis ===\n\n');
    analyzeMatrix(A);
    
    % Method 1: Characteristic equation (manual)
    fprintf('\n=== Method 1: Characteristic Equation ===\n\n');
    [lambda_char, V_char] = characteristicMethod(A);
    
    % Method 2: MATLAB built-in
    fprintf('\n=== Method 2: MATLAB Built-in eig() ===\n\n');
    [V_matlab, D_matlab] = eig(A);
    lambda_matlab = diag(D_matlab);
    
    fprintf('MATLAB eigenvalues:\n');
    fprintf('  뿯ν뿯₽ = %.10f\n', lambda_matlab(1));
    fprintf('  뿯ν뿯₽ = %.10f\n\n', lambda_matlab(2));
    
    fprintf('MATLAB eigenvectors (columns of V):\n');
    disp(V_matlab);
    
    % Verify eigenvalue equation
    fprintf('Verification: Av = 뿯νv\n');
    for i = 1:2
        Av = A * V_matlab(:,i);
        lambda_v = lambda_matlab(i) * V_matlab(:,i);
        error = norm(Av - lambda_v);
        fprintf('  Eigenvalue %d: ||Av - 뿯νv|| = %.2e ', i, error);
        if error < 1e-10
            fprintf('✓\n');
        else
            fprintf('✗\n');
        end
    end
    
    % Method 3: Power iteration
    fprintf('\n=== Method 3: Power Iteration ===\n\n');
    [lambda_power, v_power, history_power] = powerIteration(A, 50);
    
    % Method 4: Inverse iteration (smallest eigenvalue)
    fprintf('\n=== Method 4: Inverse Iteration ===\n\n');
    [lambda_inv, v_inv, history_inv] = inverseIteration(A, 50);
    
    % Plot convergence
    plotConvergence(history_power, history_inv, lambda_matlab);
    
    % Diagonalization
    fprintf('\n=== Diagonalization ===\n\n');
    demonstrateDiagonalization(A, V_matlab, D_matlab);
    
    % Matrix powers
    fprintf('\n=== Matrix Powers using Diagonalization ===\n\n');
    demonstrateMatrixPowers(A, V_matlab, D_matlab);
    
    % Spectral properties
    fprintf('\n=== Spectral Properties ===\n\n');
    spectralAnalysis(A, lambda_matlab);
    
    % Geometric interpretation
    fprintf('\n=== Geometric Interpretation ===\n\n');
    visualizeTransformation(A, V_matlab, lambda_matlab);
    
    % QR algorithm demonstration
    fprintf('\n=== QR Algorithm Demonstration ===\n\n');
    demonstrateQR(A);
    
    % Applications
    fprintf('\n=== Real-World Applications ===\n\n');
    demonstrateApplications(A, V_matlab, lambda_matlab);
    
    fprintf('\nAnalysis complete!\n');
end

function analyzeMatrix(A)
    % ANALYZEMATRIX Comprehensive matrix property analysis
    
    n = size(A, 1);
    
    fprintf('Matrix properties:\n');
    fprintf('  Size: %d 뿯½ %d\n', size(A,1), size(A,2));
    fprintf('  Trace: tr(A) = %.6f\n', trace(A));
    fprintf('  Determinant: det(A) = %.6f\n', det(A));
    fprintf('  Rank: %d\n', rank(A));
    fprintf('  Condition number: 뿯ν(A) = %.6f\n', cond(A));
    
    fprintf('\nMatrix structure:\n');
    fprintf('  Symmetric: %s\n', yesno(isequal(A, A')));
    fprintf('  Diagonal: %s\n', yesno(all(all(A == diag(diag(A))))));
    fprintf('  Upper triangular: %s\n', yesno(all(all(tril(A,-1) == 0))));
    fprintf('  Lower triangular: %s\n', yesno(all(all(triu(A,1) == 0))));
    fprintf('  Positive definite: %s\n', yesno(all(eig(A) > 0)));
    
    fprintf('\nExpected eigenvalue properties:\n');
    fprintf('  Number of eigenvalues: %d (counting multiplicities)\n', n);
    fprintf('  Sum of eigenvalues = tr(A) = %.6f\n', trace(A));
    fprintf('  Product of eigenvalues = det(A) = %.6f\n', det(A));
end

function [eigenvalues, eigenvectors] = characteristicMethod(A)
    % CHARACTERISTICMETHOD Manual solution via characteristic equation
    %
    % For 2뿯½2 matrix: det(A - 뿯νI) = 0
    % 뿯ν뿯½ - tr(A)뿯ν + det(A) = 0
    
    fprintf('Solving characteristic equation: det(A - 뿯νI) = 0\n\n');
    
    % Extract coefficients
    a11 = A(1,1); a12 = A(1,2);
    a21 = A(2,1); a22 = A(2,2);
    
    fprintf('A - 뿯νI = \n');
    fprintf('  [%d-뿯ν    %d  ]\n', a11, a12);
    fprintf('  [%d      %d-뿯ν]\n\n', a21, a22);
    
    fprintf('det(A - 뿯νI) = (%d-뿯ν)(%d-뿯ν) - (%d)(%d)\n', a11, a22, a12, a21);
    fprintf('            = %d - %d뿯ν - %d뿯ν + 뿯ν뿯½ - %d\n', ...
        a11*a22, a11, a22, a12*a21);
    
    % Characteristic polynomial: 뿯ν뿯½ - (a11+a22)뿯ν + (a11*a22 - a12*a21) = 0
    c = a11*a22 - a12*a21;  % Constant term = det(A)
    b = -(a11 + a22);        % Linear coefficient = -tr(A)
    
    sum_term = a11*a22 + (-a12*a21);
    fprintf('            = 뿯ν뿯½ %+d뿯ν %+d = 0\n\n', b, c);
    
    fprintf('This is a quadratic equation: 뿯ν뿯½ %+d뿯ν %+d = 0\n', b, c);
    
    % Solve using quadratic formula
    discriminant = b^2 - 4*c;
    fprintf('Discriminant: 뿯ν = b뿯½ - 4c = %d뿯½ - 4(%d) = %d\n\n', b, c, discriminant);
    
    if discriminant < 0
        fprintf('뿯ν < 0: Complex eigenvalues\n');
        real_part = -b/2;
        imag_part = sqrt(-discriminant)/2;
        lambda1 = real_part + 1i*imag_part;
        lambda2 = real_part - 1i*imag_part;
    else
        fprintf('뿯ν ≥ 0: Real eigenvalues\n');
        lambda1 = (-b + sqrt(discriminant)) / 2;
        lambda2 = (-b - sqrt(discriminant)) / 2;
    end
    
    fprintf('Using quadratic formula: 뿯ν = (-b 뿯½ √뿯ν) / 2\n');
    fprintf('  뿯ν뿯₽ = (%.0f + %.0f) / 2 = %.10f\n', -b, sqrt(discriminant), lambda1);
    fprintf('  뿯ν뿯₽ = (%.0f - %.0f) / 2 = %.10f\n\n', -b, sqrt(discriminant), lambda2);
    
    eigenvalues = [lambda1; lambda2];
    
    % Find eigenvectors
    fprintf('Finding eigenvectors by solving (A - 뿯νᵢI)v = 0:\n\n');
    
    eigenvectors = zeros(2, 2);
    
    for i = 1:2
        fprintf('For 뿯ν%d = %.6f:\n', i, eigenvalues(i));
        
        A_lambda = A - eigenvalues(i) * eye(2);
        fprintf('  A - 뿯ν%dI = \n', i);
        fprintf('    [%8.4f  %8.4f]\n', A_lambda(1,1), A_lambda(1,2));
        fprintf('    [%8.4f  %8.4f]\n\n', A_lambda(2,1), A_lambda(2,2));
        
        % Solve (A - 뿯νI)v = 0
        % For 2뿯½2, if first row is [a, b], then v = [b; -a] (perpendicular)
        % Or use null space
        v = null(A_lambda);
        
        if isempty(v)
            % Degenerate case: use simple solution
            if abs(A_lambda(1,1)) > eps
                v = [A_lambda(1,2); -A_lambda(1,1)];
            else
                v = [A_lambda(2,2); -A_lambda(2,1)];
            end
            v = v / norm(v);
        end
        
        eigenvectors(:,i) = v;
        
        fprintf('  Eigenvector: v%d = [%.6f, %.6f]ᵀ\n', i, v(1), v(2));
        
        % Verify
        Av = A * v;
        lambda_v = eigenvalues(i) * v;
        error = norm(Av - lambda_v);
        fprintf('  Verification: ||Av - 뿯νv|| = %.2e ', error);
        if error < 1e-10
            fprintf('✓\n\n');
        else
            fprintf('✗ WARNING: Verification failed!\n\n');
        end
    end
end

function [lambda, v, history] = powerIteration(A, max_iter)
    % POWERITERATION Find dominant eigenvalue using power iteration
    %
    % Algorithm:
    %   1. Start with random vector x뿯₽
    %   2. Iterate: x_{k+1} = A x_k / ||A x_k||
    %   3. 뿯ν ≈ x_k^T A x_k / x_k^T x_k (Rayleigh quotient)
    
    fprintf('Computing dominant eigenvalue via power iteration...\n\n');
    
    n = size(A, 1);
    
    % Initialize with random vector
    rng(42);  % For reproducibility
    v = randn(n, 1);
    v = v / norm(v);
    
    fprintf('Initial vector: v뿯₽ = [%.6f, %.6f]ᵀ\n', v);
    fprintf('||v뿯₽|| = %.6f\n\n', norm(v));
    
    fprintf('%4s  %15s  %15s  %15s\n', 'Iter', '뿯ν (Rayleigh)', 'Change', '||Av - 뿯νv||');
    fprintf('%s\n', repmat('-', 1, 70));
    
    history = zeros(max_iter, 1);
    lambda_old = 0;
    
    for k = 1:max_iter
        % Power iteration step
        v_new = A * v;
        v_new = v_new / norm(v_new);
        
        % Rayleigh quotient: 뿯ν ≈ v^T A v / v^T v
        lambda = (v_new' * A * v_new) / (v_new' * v_new);
        
        % Check convergence
        change = abs(lambda - lambda_old);
        residual = norm(A * v_new - lambda * v_new);
        
        history(k) = residual;
        
        if mod(k, 5) == 0 || k == 1 || k == max_iter || change < 1e-12
            fprintf('%4d  %15.10f  %15.2e  %15.2e\n', k, lambda, change, residual);
        end
        
        if change < 1e-12 && residual < 1e-12
            fprintf('\nConverged in %d iterations!\n', k);
            history = history(1:k);
            break;
        end
        
        v = v_new;
        lambda_old = lambda;
    end
    
    fprintf('\nDominant eigenvalue: 뿯ν = %.10f\n', lambda);
    fprintf('Corresponding eigenvector: v = [%.10f, %.10f]ᵀ\n', v);
    fprintf('||v|| = %.10f\n\n', norm(v));
    
    % Final verification
    Av = A * v;
    lambda_v = lambda * v;
    error = norm(Av - lambda_v);
    fprintf('Final verification: ||Av - 뿯νv|| = %.2e\n', error);
end

function [lambda, v, history] = inverseIteration(A, max_iter)
    % INVERSEITERATION Find smallest eigenvalue using inverse iteration
    %
    % Algorithm:
    %   1. Start with random vector x뿯₽
    %   2. Iterate: x_{k+1} = A^{-1} x_k / ||A^{-1} x_k||
    %   3. This finds largest eigenvalue of A^{-1}, which corresponds
    %      to smallest eigenvalue of A
    
    fprintf('Computing smallest eigenvalue via inverse iteration...\n\n');
    
    n = size(A, 1);
    
    % Initialize with random vector
    rng(123);
    v = randn(n, 1);
    v = v / norm(v);
    
    fprintf('Initial vector: v뿯₽ = [%.6f, %.6f]ᵀ\n\n', v);
    
    fprintf('%4s  %15s  %15s  %15s\n', 'Iter', '뿯ν (Rayleigh)', 'Change', '||Av - 뿯νv||');
    fprintf('%s\n', repmat('-', 1, 70));
    
    history = zeros(max_iter, 1);
    lambda_old = 0;
    
    % Pre-compute LU factorization for efficiency
    [L, U, P] = lu(A);
    
    for k = 1:max_iter
        % Inverse iteration: solve A v_new = v
        % Using LU: PA v_new = Pv, so LU v_new = Pv
        y = L \ (P * v);
        v_new = U \ y;
        v_new = v_new / norm(v_new);
        
        % Rayleigh quotient
        lambda = (v_new' * A * v_new) / (v_new' * v_new);
        
        % Check convergence
        change = abs(lambda - lambda_old);
        residual = norm(A * v_new - lambda * v_new);
        
        history(k) = residual;
        
        if mod(k, 5) == 0 || k == 1 || k == max_iter || change < 1e-12
            fprintf('%4d  %15.10f  %15.2e  %15.2e\n', k, lambda, change, residual);
        end
        
        if change < 1e-12 && residual < 1e-12
            fprintf('\nConverged in %d iterations!\n', k);
            history = history(1:k);
            break;
        end
        
        v = v_new;
        lambda_old = lambda;
    end
    
    fprintf('\nSmallest eigenvalue: 뿯ν = %.10f\n', lambda);
    fprintf('Corresponding eigenvector: v = [%.10f, %.10f]ᵀ\n', v);
end

function plotConvergence(history_power, history_inv, true_eigenvalues)
    % PLOTCONVERGENCE Visualize convergence of iterative methods
    
    figure('Position', [100, 100, 1000, 400], 'Name', 'Eigenvalue Convergence');
    
    subplot(1, 2, 1);
    semilogy(1:length(history_power), history_power, 'b-o', 'LineWidth', 2, ...
        'MarkerSize', 6, 'MarkerFaceColor', 'b');
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Residual $||\mathbf{A}\mathbf{v} - \lambda\mathbf{v}||$', ...
        'Interpreter', 'latex', 'FontSize', 12);
    title('Power Iteration (Dominant $\lambda$)', 'Interpreter', 'latex', 'FontSize', 14);
    
    subplot(1, 2, 2);
    semilogy(1:length(history_inv), history_inv, 'r-s', 'LineWidth', 2, ...
        'MarkerSize', 6, 'MarkerFaceColor', 'r');
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Residual $||\mathbf{A}\mathbf{v} - \lambda\mathbf{v}||$', ...
        'Interpreter', 'latex', 'FontSize', 12);
    title('Inverse Iteration (Smallest $\lambda$)', 'Interpreter', 'latex', 'FontSize', 14);
end

function demonstrateDiagonalization(A, V, D)
    % DEMONSTRATEDIAGONALIZATION Show matrix diagonalization
    
    fprintf('Matrix diagonalization: A = V D V⁻뿯½\n\n');
    
    fprintf('Eigenvector matrix V (columns are eigenvectors):\n');
    disp(V);
    
    fprintf('Diagonal matrix D (eigenvalues on diagonal):\n');
    disp(D);
    
    % Compute V^{-1}
    V_inv = inv(V);
    fprintf('Inverse V⁻뿯½:\n');
    disp(V_inv);
    
    % Verify A = V D V^{-1}
    A_reconstructed = V * D * V_inv;
    fprintf('Reconstruction: V D V⁻뿯½ =\n');
    disp(A_reconstructed);
    
    error_recon = norm(A - A_reconstructed, 'fro');
    fprintf('Reconstruction error: ||A - VDV⁻뿯½||_F = %.2e\n', error_recon);
    
    if error_recon < 1e-10
        fprintf('✓ Diagonalization verified!\n');
    else
        fprintf('✗ WARNING: Large reconstruction error!\n');
    end
end

function demonstrateMatrixPowers(A, V, D)
    % DEMONSTRATEMATRIXPOWERS Compute matrix powers efficiently
    
    fprintf('Computing matrix powers using diagonalization:\n');
    fprintf('A^n = V D^n V⁻뿯½\n\n');
    
    V_inv = inv(V);
    
    powers = [2, 5, 10, 20];
    
    fprintf('%-8s  %20s  %20s\n', 'Power n', 'Direct (A^n)', 'Diagonal (VD^nV⁻뿯½)');
    fprintf('%s\n', repmat('-', 1, 60));
    
    for n = powers
        % Method 1: Direct computation
        tic;
        A_n_direct = A^n;
        time_direct = toc;
        
        % Method 2: Via diagonalization
        tic;
        D_n = D^n;
        A_n_diag = V * D_n * V_inv;
        time_diag = toc;
        
        error = norm(A_n_direct - A_n_diag, 'fro');
        
        fprintf('%-8d  %20.2e s  %20.2e s\n', n, time_direct, time_diag);
    end
    
    fprintf('\nNote: For small matrices, timing differences are negligible.\n');
    fprintf('      For large matrices and many repeated powers, diagonalization wins!\n\n');
    
    % Show specific example
    n = 10;
    D_n = D^n;
    A_n = V * D_n * V_inv;
    
    fprintf('Example: A^%d =\n', n);
    disp(A_n);
    
    % Verify
    A_n_direct = A^n;
    error = norm(A_n - A_n_direct, 'fro');
    fprintf('Verification: ||A^%d(direct) - A^%d(diag)|| = %.2e\n', n, n, error);
end

function spectralAnalysis(A, eigenvalues)
    % SPECTRALANALYSIS Analyze spectral properties
    
    fprintf('Spectral analysis:\n\n');
    
    % Basic properties
    trace_A = trace(A);
    det_A = det(A);
    
    sum_eigenvalues = sum(eigenvalues);
    prod_eigenvalues = prod(eigenvalues);
    
    fprintf('Fundamental relationships:\n');
    fprintf('  tr(A) = %.6f,  뿯ν뿯νᵢ = %.6f  (should match!)\n', ...
        trace_A, sum_eigenvalues);
    fprintf('  det(A) = %.6f,  뿯ν뿯νᵢ = %.6f  (should match!)\n', ...
        det_A, prod_eigenvalues);
    
    fprintf('\nSpectral radius:\n');
    spectral_radius = max(abs(eigenvalues));
    fprintf('  뿯ν(A) = max|뿯νᵢ| = %.6f\n', spectral_radius);
    fprintf('  (Controls asymptotic behavior of A^n)\n');
    
    fprintf('\nCondition number (spectral):\n');
    if all(real(eigenvalues) > 0)
        kappa_spectral = max(abs(eigenvalues)) / min(abs(eigenvalues));
        fprintf('  뿯ν(A) ≈ 뿯ν_max/뿯ν_min = %.6f\n', kappa_spectral);
    else
        fprintf('  (Not applicable for indefinite matrices)\n');
    end
    
    fprintf('\nMatrix norm estimates:\n');
    fprintf('  ||A||뿯₽ ≤ 뿯ν(A) = %.6f\n', spectral_radius);
    fprintf('  Actual ||A||뿯₽ = %.6f\n', norm(A, 2));
    
    fprintf('\nEigenvalue classification:\n');
    for i = 1:length(eigenvalues)
        lambda = eigenvalues(i);
        fprintf('  뿯ν%d = %.6f: ', i, lambda);
        
        if imag(lambda) ~= 0
            fprintf('COMPLEX');
        elseif lambda > 0
            fprintf('POSITIVE REAL');
        elseif lambda < 0
            fprintf('NEGATIVE REAL');
        else
            fprintf('ZERO');
        end
        
        if abs(lambda) > 1
            fprintf(' (expanding)');
        elseif abs(lambda) < 1
            fprintf(' (contracting)');
        else
            fprintf(' (preserving)');
        end
        
        fprintf('\n');
    end
end

function visualizeTransformation(A, V, lambda)
    % VISUALIZETRANSFORMATION Show geometric meaning of eigenvalues
    
    fprintf('Creating geometric visualization...\n');
    fprintf('Eigenvectors show DIRECTIONS preserved under transformation\n');
    fprintf('Eigenvalues show SCALING in those directions\n\n');
    
    figure('Position', [100, 100, 1200, 400], 'Name', 'Eigenvalue Geometry');
    
    % Create unit circle
    theta = linspace(0, 2*pi, 100);
    unit_circle = [cos(theta); sin(theta)];
    
    % Transform circle
    transformed = A * unit_circle;
    
    % Subplot 1: Original space with eigenvectors
    subplot(1, 3, 1);
    hold on;
    plot(unit_circle(1,:), unit_circle(2,:), 'b-', 'LineWidth', 2);
    
    % Draw eigenvectors
    colors = ['r', 'g'];
    for i = 1:2
        v = V(:,i);
        quiver(0, 0, v(1), v(2), 'Color', colors(i), 'LineWidth', 3, ...
            'MaxHeadSize', 0.5, 'DisplayName', sprintf('v_%d', i));
        quiver(0, 0, -v(1), -v(2), 'Color', colors(i), 'LineWidth', 3, ...
            'MaxHeadSize', 0.5, 'HandleVisibility', 'off');
    end
    
    hold off;
    axis equal;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Space', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Unit circle', 'Eigenvector 1', 'Eigenvector 2', ...
        'Location', 'best', 'Interpreter', 'latex');
    
    % Subplot 2: Transformed space
    subplot(1, 3, 2);
    hold on;
    plot(transformed(1,:), transformed(2,:), 'b-', 'LineWidth', 2);
    
    % Draw transformed eigenvectors
    for i = 1:2
        v_trans = A * V(:,i);
        quiver(0, 0, v_trans(1), v_trans(2), 'Color', colors(i), ...
            'LineWidth', 3, 'MaxHeadSize', 0.5, ...
            'DisplayName', sprintf('$\\lambda_%d v_%d$', i, i));
        quiver(0, 0, -v_trans(1), -v_trans(2), 'Color', colors(i), ...
            'LineWidth', 3, 'MaxHeadSize', 0.5, 'HandleVisibility', 'off');
    end
    
    hold off;
    axis equal;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('After Transformation $\mathbf{A}$', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Transformed circle', 'Location', 'best', 'Interpreter', 'latex');
    
    % Subplot 3: Overlay comparison
    subplot(1, 3, 3);
    hold on;
    plot(unit_circle(1,:), unit_circle(2,:), 'b-', 'LineWidth', 1.5, ...
        'DisplayName', 'Original');
    plot(transformed(1,:), transformed(2,:), 'r-', 'LineWidth', 2, ...
        'DisplayName', 'Transformed');
    
    % Show both eigenvector sets
    for i = 1:2
        v = V(:,i);
        v_trans = A * V(:,i);
        quiver(0, 0, v(1), v(2), 'b', 'LineWidth', 2, ...
            'MaxHeadSize', 0.5, 'HandleVisibility', 'off');
        quiver(0, 0, v_trans(1), v_trans(2), 'r', 'LineWidth', 2, ...
            'MaxHeadSize', 0.5, 'HandleVisibility', 'off');
        
        % Add text labels
        text(v(1)*1.2, v(2)*1.2, sprintf('v_%d', i), 'Color', 'b', ...
            'FontSize', 12, 'FontWeight', 'bold');
        text(v_trans(1)*1.1, v_trans(2)*1.1, ...
            sprintf('%.1fv_%d', lambda(i), i), ...
            'Color', 'r', 'FontSize', 12, 'FontWeight', 'bold');
    end
    
    hold off;
    axis equal;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Comparison', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Location', 'best', 'Interpreter', 'latex');
    
    fprintf('Key observations:\n');
    fprintf('  • Unit circle 뿯↽ Ellipse (general transformation)\n');
    fprintf('  • Eigenvector directions are PRESERVED\n');
    fprintf('  • Scaling: v뿯₽ scaled by 뿯ν뿯₽ = %.2f, v뿯₽ scaled by 뿯ν뿯₽ = %.2f\n', ...
        lambda(1), lambda(2));
    fprintf('  • Ellipse axes align with eigenvectors!\n');
end

function demonstrateQR(A)
    % DEMONSTRATEQR Show QR algorithm for eigenvalue computation
    
    fprintf('QR Algorithm: The gold standard for eigenvalue computation\n\n');
    
    fprintf('Algorithm:\n');
    fprintf('  1. Start: A뿯₽ = A\n');
    fprintf('  2. Iterate: A뿯₽ = Q뿯₽R뿯₽ (QR factorization)\n');
    fprintf('              A뿯₽뿯₽뿯₽ = R뿯₽Q뿯₽ (reverse multiplication)\n');
    fprintf('  3. A뿯₽ converges to triangular/diagonal form\n');
    fprintf('  4. Eigenvalues appear on diagonal\n\n');
    
    max_iter = 20;
    A_k = A;
    
    fprintf('%4s  %15s  %15s  %15s\n', 'Iter', 'Off-diag norm', '뿯ν뿯₽ estimate', '뿯ν뿯₽ estimate');
    fprintf('%s\n', repmat('-', 1, 70));
    
    for k = 1:max_iter
        % QR factorization
        [Q, R] = qr(A_k);
        
        % Form next iterate
        A_k = R * Q;
        
        % Measure convergence (off-diagonal elements 뿯↽ 0)
        off_diag_norm = abs(A_k(2,1)) + abs(A_k(1,2));
        
        % Eigenvalue estimates (diagonal elements)
        lambda_est = diag(A_k);
        
        if mod(k, 2) == 0 || k == 1 || k == max_iter
            fprintf('%4d  %15.2e  %15.10f  %15.10f\n', ...
                k, off_diag_norm, lambda_est(1), lambda_est(2));
        end
        
        if off_diag_norm < 1e-12
            fprintf('\nConverged in %d iterations!\n', k);
            break;
        end
    end
    
    fprintf('\nFinal quasi-diagonal form:\n');
    disp(A_k);
    
    fprintf('Eigenvalues from QR: [%.10f, %.10f]\n', lambda_est);
    
    % Compare with MATLAB's eig
    lambda_matlab = sort(eig(A), 'descend');
    error = norm(sort(lambda_est, 'descend') - lambda_matlab);
    fprintf('Error vs MATLAB eig(): %.2e\n', error);
    
    fprintf('\nNote: QR algorithm is extremely robust and efficient!\n');
    fprintf('      Modern implementations use shifts, deflation, and Hessenberg reduction.\n');
end

function demonstrateApplications(A, V, lambda)
    % DEMONSTRATEAPPLICATIONS Show real-world eigenvalue applications
    
    fprintf('=== Application 1: Markov Chain / PageRank ===\n\n');
    
    % Convert A to a stochastic matrix (for demo purposes)
    % Normalize columns to sum to 1
    P = abs(A) ./ sum(abs(A), 1);
    
    fprintf('Stochastic matrix P (column-normalized):\n');
    disp(P);
    
    % Find steady-state distribution
    [V_markov, D_markov] = eig(P);
    [~, idx] = max(abs(diag(D_markov)));
    steady_state = abs(V_markov(:, idx));
    steady_state = steady_state / sum(steady_state);
    
    fprintf('Steady-state distribution (normalized eigenvector for 뿯ν=1):\n');
    fprintf('  뿯ν = [%.6f, %.6f]ᵀ\n', steady_state);
    fprintf('  Sum = %.6f (should be 1.0)\n\n', sum(steady_state));
    
    fprintf('Interpretation: In the long run, the system spends:\n');
    fprintf('  %.1f%% of time in state 1\n', 100*steady_state(1));
    fprintf('  %.1f%% of time in state 2\n\n', 100*steady_state(2));
    
    fprintf('=== Application 2: Vibration Analysis ===\n\n');
    
    % Interpret eigenvalues as natural frequencies
    omega_1 = sqrt(abs(lambda(1)));
    omega_2 = sqrt(abs(lambda(2)));
    
    fprintf('Natural frequencies (뿯ν = √뿯ν):\n');
    fprintf('  뿯ν뿯₽ = %.6f rad/s  (f뿯₽ = %.6f Hz)\n', omega_1, omega_1/(2*pi));
    fprintf('  뿯ν뿯₽ = %.6f rad/s  (f뿯₽ = %.6f Hz)\n\n', omega_2, omega_2/(2*pi));
    
    fprintf('Mode shapes (eigenvectors):\n');
    fprintf('  Mode 1: [%.6f, %.6f]ᵀ\n', V(:,1));
    fprintf('  Mode 2: [%.6f, %.6f]ᵀ\n\n', V(:,2));
    
    fprintf('Physical meaning:\n');
    fprintf('  • Mode 1: Primary vibration pattern at %.2f Hz\n', omega_1/(2*pi));
    fprintf('  • Mode 2: Secondary vibration pattern at %.2f Hz\n', omega_2/(2*pi));
    fprintf('  • Any vibration is a superposition of these modes\n\n');
    
    fprintf('=== Application 3: Principal Component Analysis ===\n\n');
    
    % Treat A as a covariance matrix
    fprintf('If A were a data covariance matrix:\n');
    fprintf('  • Eigenvectors point in directions of maximum variance\n');
    fprintf('  • Eigenvalues measure variance along those directions\n');
    fprintf('  • Total variance = tr(A) = 뿯ν뿯νᵢ = %.6f\n\n', sum(lambda));
    
    fprintf('Variance explained:\n');
    total_var = sum(lambda);
    for i = 1:length(lambda)
        pct = 100 * lambda(i) / total_var;
        fprintf('  PC%d: %.1f%% of variance\n', i, pct);
    end
    
    cumulative = 100 * cumsum(lambda) / total_var;
    fprintf('  First PC captures %.1f%% of variance\n', cumulative(1));
    fprintf('  First 2 PCs capture %.1f%% of variance\n\n', cumulative(end));
    
    fprintf('=== Application 4: Stability Analysis ===\n\n');
    
    fprintf('For dynamical system dx/dt = Ax:\n');
    fprintf('  • 뿯ν < 0: Stable (decays to zero)\n');
    fprintf('  • 뿯ν = 0: Marginally stable (constant)\n');
    fprintf('  • 뿯ν > 0: Unstable (grows exponentially)\n\n');
    
    for i = 1:length(lambda)
        fprintf('  뿯ν%d = %.6f: ', i, lambda(i));
        if real(lambda(i)) < 0
            fprintf('STABLE (solution decays)\n');
        elseif real(lambda(i)) > 0
            fprintf('UNSTABLE (solution grows)\n');
        else
            fprintf('MARGINALLY STABLE\n');
        end
    end
    
    if all(real(lambda) < 0)
        fprintf('\nSystem is GLOBALLY ASYMPTOTICALLY STABLE\n');
    elseif any(real(lambda) > 0)
        fprintf('\nSystem is UNSTABLE\n');
    else
        fprintf('\nSystem is MARGINALLY STABLE\n');
    end
end

function str = yesno(condition)
    % YESNO Helper function
    if condition
        str = 'Yes';
    else
        str = 'No';
    end
end

% Execute problem
Problem5_Eigenvalues();
