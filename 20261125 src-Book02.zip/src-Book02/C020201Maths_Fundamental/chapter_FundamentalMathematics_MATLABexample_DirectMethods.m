%% chapter_FundamentalMathematics_MATLABexample_DirectMethods.m
% Direct methods for solving linear systems.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_DirectMethods
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_4_1_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates direct methods for solving linear systems,
%              including LU and Cholesky decompositions with performance
%              comparison and numerical stability analysis.

function demonstrateDirectMethods()
    fprintf('Direct Methods for Solving Linear Systems\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic system solution
    demonstrateBasicSolution();
    
    % Part 2: LU decomposition
    demonstrateLUDecomposition();
    
    % Part 3: Cholesky decomposition
    demonstrateCholeskyDecomposition();
    
    % Part 4: Efficiency comparison
    compareMethodEfficiency();
    
    % Part 5: Numerical stability considerations
    demonstrateNumericalStability();
end

function demonstrateBasicSolution()
    % Demonstrate basic linear system solution
    
    fprintf('Part 1: Basic Linear System Solution\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define a simple 3$\times$3 system
    A = [2, 1, -1; -3, -1, 2; -2, 1, 2];
    b = [8; -11; -3];
    
    fprintf('System: Ax = b where\n');
    fprintf('A =\n');
    disp(A);
    fprintf('b =\n');
    disp(b);
    
    % Solve using backslash operator (recommended)
    x_backslash = A \ b;
    
    fprintf('Solution using backslash operator (x = A \\ b):\n');
    fprintf('x = [%.6f; %.6f; %.6f]\n', x_backslash);
    
    % Verify solution
    residual = A * x_backslash - b;
    fprintf('\nVerification: ||Ax - b|| = %.10e\n', norm(residual));
    
    % Alternative: explicit inverse (NOT RECOMMENDED)
    x_inverse = inv(A) * b;
    fprintf('\nSolution using inv(A)*b (NOT recommended):\n');
    fprintf('x = [%.6f; %.6f; %.6f]\n', x_inverse);
    
    % Compare solutions
    difference = norm(x_backslash - x_inverse);
    fprintf('\nDifference between methods: %.10e\n', difference);
    fprintf('Note: Both give similar results for well-conditioned systems,\n');
    fprintf('      but backslash is more stable and efficient.\n\n');
end

function demonstrateLUDecomposition()
    % Demonstrate LU decomposition and its application
    
    fprintf('Part 2: LU Decomposition\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define matrix
    A = [4, 3, 0; 3, 3, -1; 0, -1, 4];
    b1 = [24; 11; 8];
    b2 = [1; 2; 3];
    
    fprintf('Matrix A:\n');
    disp(A);
    
    % Perform LU decomposition with partial pivoting
    [L, U, P] = lu(A);
    
    fprintf('LU Decomposition: PA = LU\n\n');
    fprintf('Permutation matrix P:\n');
    disp(P);
    fprintf('Lower triangular L:\n');
    disp(L);
    fprintf('Upper triangular U:\n');
    disp(U);
    
    % Verify decomposition
    reconstructedA = P * A;
    computedLU = L * U;
    decompositionError = norm(reconstructedA - computedLU, 'fro');
    fprintf('Verification: ||PA - LU||_F = %.10e\n\n', decompositionError);
    
    % Solve first system using LU decomposition
    fprintf('Solving Ax = b1 using LU decomposition:\n');
    fprintf('b1 = [%d; %d; %d]\n', b1);
    
    % Forward substitution: Ly = Pb
    y1 = L \ (P * b1);
    % Backward substitution: Ux = y
    x1 = U \ y1;
    
    fprintf('Solution: x1 = [%.6f; %.6f; %.6f]\n', x1);
    
    % Verify
    residual1 = A * x1 - b1;
    fprintf('Residual: ||Ax1 - b1|| = %.10e\n\n', norm(residual1));
    
    % Solve second system (reusing LU decomposition)
    fprintf('Solving Ax = b2 using SAME LU decomposition:\n');
    fprintf('b2 = [%d; %d; %d]\n', b2);
    
    y2 = L \ (P * b2);
    x2 = U \ y2;
    
    fprintf('Solution: x2 = [%.6f; %.6f; %.6f]\n', x2);
    
    residual2 = A * x2 - b2;
    fprintf('Residual: ||Ax2 - b2|| = %.10e\n\n', norm(residual2));
    
    fprintf('Key advantage: LU decomposition computed once,\n');
    fprintf('               then reused for multiple right-hand sides.\n\n');
end

function demonstrateCholeskyDecomposition()
    % Demonstrate Cholesky decomposition for symmetric positive definite matrices
    
    fprintf('Part 3: Cholesky Decomposition\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create symmetric positive definite matrix
    % Method: A = B'*B where B is arbitrary
    B = randn(4, 4);
    A = B' * B + 0.1 * eye(4); % Add small diagonal to ensure positive definiteness
    
    fprintf('Symmetric Positive Definite Matrix A (4$\times$4):\n');
    fprintf('%.6f  %.6f  %.6f  %.6f\n', A');
    
    % Verify symmetry
    symmetryError = norm(A - A', 'fro');
    fprintf('\nSymmetry check: ||A - A''||_F = %.10e\n', symmetryError);
    
    % Verify positive definiteness (all eigenvalues positive)
    eigenvalues = eig(A);
    fprintf('Eigenvalues: ');
    fprintf('%.6f  ', eigenvalues);
    fprintf('\nMinimum eigenvalue: %.6f (positive → matrix is positive definite)\n\n', ...
            min(eigenvalues));
    
    % Perform Cholesky decomposition
    L = chol(A, 'lower');
    
    fprintf('Cholesky Decomposition: A = LL''\n\n');
    fprintf('Lower triangular L:\n');
    fprintf('%.6f  %.6f  %.6f  %.6f\n', L');
    
    % Verify decomposition
    reconstructedA = L * L';
    choleskyError = norm(A - reconstructedA, 'fro');
    fprintf('\nVerification: ||A - LL''||_F = %.10e\n\n', choleskyError);
    
    % Solve system using Cholesky decomposition
    b = randn(4, 1);
    fprintf('Solving Ax = b where b = [%.4f; %.4f; %.4f; %.4f]\n', b);
    
    % Forward substitution: Ly = b
    y = L \ b;
    % Backward substitution: L'x = y
    x = L' \ y;
    
    fprintf('\nSolution: x = [%.6f; %.6f; %.6f; %.6f]\n', x);
    
    % Verify solution
    residual = A * x - b;
    fprintf('Residual: ||Ax - b|| = %.10e\n\n', norm(residual));
    
    fprintf('Cholesky advantages:\n');
    fprintf('  - Requires ~50%% of operations compared to LU\n');
    fprintf('  - Numerically stable (no pivoting needed)\n');
    fprintf('  - Applicable only to symmetric positive definite matrices\n\n');
end

function compareMethodEfficiency()
    % Compare computational efficiency of different methods
    
    fprintf('Part 4: Computational Efficiency Comparison\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    sizes = [50, 100, 200, 400];
    numTrials = 5;
    
    fprintf('Solving systems of increasing size (average over %d trials):\n\n', ...
            numTrials);
    fprintf('%8*s %15*s %15*s %15*s\n', 'Size', 'Backslash', 'LU', 'Cholesky*');
    fprintf('%s\n', repmat('-', 1, 60));
    
    for matrixSize = sizes
        % Generate random symmetric positive definite matrix
        B = randn(matrixSize, matrixSize);
        A_general = randn(matrixSize, matrixSize);
        A_spd = B' * B + 0.1 * eye(matrixSize);
        b = randn(matrixSize, 1);
        
        % Time backslash operator
        timeBackslash = 0;
        for trial = 1:numTrials
            tic;
            x_backslash = A_general \ b;
            timeBackslash = timeBackslash + toc;
        end
        timeBackslash = timeBackslash / numTrials;
        
        % Time LU decomposition approach
        timeLU = 0;
        for trial = 1:numTrials
            tic;
            [L, U, P] = lu(A_general);
            x_lu = U \ (L \ (P * b));
            timeLU = timeLU + toc;
        end
        timeLU = timeLU / numTrials;
        
        % Time Cholesky decomposition (on symmetric positive definite matrix)
        timeCholesky = 0;
        for trial = 1:numTrials
            tic;
            L_chol = chol(A_spd, 'lower');
            x_chol = L_chol' \ (L_chol \ b);
            timeCholesky = timeCholesky + toc;
        end
        timeCholesky = timeCholesky / numTrials;
        
        fprintf('%8*d %12.6*f ms %12.6*f ms %12.6*f ms\n', ...
                matrixSize, timeBackslash*1000, timeLU*1000, ...
                timeCholesky*1000);
    end
    
    fprintf('\n* Cholesky applicable only to symmetric positive definite matrices\n');
    fprintf('Note: Backslash operator automatically selects optimal method\n');
    fprintf('      based on matrix properties (triangular, symmetric, etc.)\n\n');
end

function demonstrateNumericalStability()
    % Demonstrate numerical stability considerations
    
    fprintf('Part 5: Numerical Stability and Condition Number\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create well-conditioned matrix
    wellConditioned = randn(5, 5);
    wellConditioned = wellConditioned * wellConditioned' + 10 * eye(5);
    condWell = cond(wellConditioned);
    
    fprintf('Well-conditioned matrix:\n');
    fprintf('Condition number: %.2e\n', condWell);
    
    % Solve system
    b_exact = randn(5, 1);
    x_exact = wellConditioned \ b_exact;
    
    % Add small perturbation to right-hand side
    perturbation = 1e-6 * randn(5, 1);
    b_perturbed = b_exact + perturbation;
    x_perturbed = wellConditioned \ b_perturbed;
    
    % Measure error amplification
    relativeInputError = norm(perturbation) / norm(b_exact);
    relativeOutputError = norm(x_perturbed - x_exact) / norm(x_exact);
    
    fprintf('Relative input perturbation:  %.6e\n', relativeInputError);
    fprintf('Relative output error:        %.6e\n', relativeOutputError);
    fprintf('Error amplification factor:   %.2f\n', ...
            relativeOutputError / relativeInputError);
    fprintf('Theoretical bound (κ):        %.2f\n\n', condWell);
    
    % Create ill-conditioned matrix (Hilbert matrix)
    fprintf('Ill-conditioned matrix (Hilbert matrix):\n');
    illConditioned = hilb(8);
    condIll = cond(illConditioned);
    fprintf('Condition number: %.2e (VERY LARGE!)\n', condIll);
    
    % Solve system
    b_exact_ill = randn(8, 1);
    x_exact_ill = illConditioned \ b_exact_ill;
    
    % Add same relative perturbation
    perturbation_ill = relativeInputError * norm(b_exact_ill) * ...
                       randn(8, 1) / norm(randn(8, 1));
    b_perturbed_ill = b_exact_ill + perturbation_ill;
    x_perturbed_ill = illConditioned \ b_perturbed_ill;
    
    relativeOutputError_ill = norm(x_perturbed_ill - x_exact_ill) / ...
                              norm(x_exact_ill);
    
    fprintf('Relative input perturbation:  %.6e\n', relativeInputError);
    fprintf('Relative output error:        %.6e\n', relativeOutputError_ill);
    fprintf('Error amplification factor:   %.2e\n', ...
            relativeOutputError_ill / relativeInputError);
    fprintf('Theoretical bound (κ):        %.2e\n\n', condIll);
    
    fprintf('Key insight: Large condition numbers indicate ill-conditioning.\n');
    fprintf('Solutions become highly sensitive to input perturbations,\n');
    fprintf('including round-off errors in floating-point arithmetic.\n');
end
