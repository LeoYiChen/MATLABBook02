%% prob7_complete.m
% Problem 7: Data Augmentation Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob7_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 7: Data Augmentation Strategies and Effectiveness
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Comprehensive analysis of data augmentation techniques,
%              their impact on generalization, and cost-benefit trade-offs

%% Initialization
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 7: Data Augmentation Strategies\n');
fprintf('================================================================\n\n');

%% Dataset Configuration
datasetName = 'CIFAR-10';
numTrainingSamples = 50000;
numClasses = 10;
imageSize = [32, 32, 3];

fprintf('Dataset Configuration:\n');
fprintf('  Dataset: %s\n', datasetName);
fprintf('  Training samples: %d\n', numTrainingSamples);
fprintf('  Image size: %dx%dx%d\n', imageSize);
fprintf('  Number of classes: %d\n\n', numClasses);

%% Augmentation Strategies

augmentationTypes = {'Baseline (No Aug)', 'Horizontal Flip', ...
                     'Random Crop', 'Rotation ( 15 )', ...
                     'Color Jitter', 'Gaussian Noise', ...
                     'Cutout', 'Mixup ( =1.0)', ...
                     'RandAugment', 'All Combined'};

% Simulated experimental results
validationAccuracy = [88.5, 90.2, 91.5, 90.8, 91.2, 89.8, ...
                      92.3, 93.1, 94.5, 95.8];
trainingTime_minutes = [45, 48, 52, 50, 49, 47, 51, 55, 58, 62];
effectiveDatasetSize = [1.0, 2.0, 4.0, 8.0, 3.0, 2.0, ...
                        2.0, numTrainingSamples, 10.0, 15.0];
computationalOverhead_percent = [0, 5, 15, 12, 10, 8, 10, 20, 25, 35];

fprintf('========================================\n');
fprintf('Augmentation Strategy Performance\n');
fprintf('========================================\n');
fprintf('%-20s %-15s %-18s %-20s %-15s\n', 'Strategy', 'Val Acc (%%)', ...
        'Training Time', 'Effective Dataset', 'CPU Overhead');
fprintf('%s\n', repmat('-', 1, 92));

for i = 1:length(augmentationTypes)
    fprintf('%-20s %-15.1f %-18.0f min %-20.1fx %-15.0f%%\n', ...
            augmentationTypes{i}, validationAccuracy(i), ...
            trainingTime_minutes(i), effectiveDatasetSize(i), ...
            computationalOverhead_percent(i));
end
fprintf('\n');

%% Best Single vs Combined Analysis

[bestSingleAcc, bestSingleIdx] = max(validationAccuracy(1:end-1));
combinedAcc = validationAccuracy(end);

fprintf('PERFORMANCE ANALYSIS:\n');
fprintf('  Best single augmentation: %s (%.1f%% acc)\n', ...
        augmentationTypes{bestSingleIdx}, bestSingleAcc);
fprintf('  Combined augmentations: %.1f%% acc\n', combinedAcc);
fprintf('  Synergistic improvement: +%.1f%%\n\n', ...
        combinedAcc - bestSingleAcc);

%% Cost-Benefit Analysis

accuracyGain = validationAccuracy - validationAccuracy(1);
timeIncrease = trainingTime_minutes - trainingTime_minutes(1);
efficiency = accuracyGain ./ (timeIncrease + 0.1);  % Avoid division by zero

fprintf('========================================\n');
fprintf('Cost-Benefit Analysis\n');
fprintf('========================================\n');
fprintf('%-20s %-18s %-18s %-20s\n', 'Strategy', 'Accuracy Gain', ...
        'Time Increase', 'Efficiency Ratio');
fprintf('%s\n', repmat('-', 1, 80));

for i = 1:length(augmentationTypes)
    fprintf('%-20s %-18.2f%% %-18.0f min ', ...
            augmentationTypes{i}, accuracyGain(i), timeIncrease(i));
    
    if i == 1
        fprintf('%-20s\n', 'Baseline');
    else
        fprintf('%-20.3f\n', efficiency(i));
    end
end
fprintf('\n');

[~, mostEfficientIdx] = max(efficiency(2:end));
mostEfficientIdx = mostEfficientIdx + 1;  % Adjust for skipped baseline

fprintf('MOST EFFICIENT: %s\n', augmentationTypes{mostEfficientIdx});
fprintf('  Accuracy gain: +%.1f%%\n', accuracyGain(mostEfficientIdx));
fprintf('  Time overhead: only +%.0f minutes\n', ...
        timeIncrease(mostEfficientIdx));
fprintf('  Efficiency ratio: %.3f %%/min\n\n', efficiency(mostEfficientIdx));

%% Test-Time Augmentation (TTA) Analysis

numTTAAugmentations = [1, 3, 5, 7, 10];
ttaAccuracy = [95.8, 96.3, 96.7, 96.9, 97.0];
ttaInferenceTime = [1.0, 3.2, 5.5, 7.8, 11.0];  % Relative to no TTA

fprintf('========================================\n');
fprintf('Test-Time Augmentation (TTA)\n');
fprintf('========================================\n');
fprintf('%-20s %-20s %-25s %-20s\n', 'TTA Augments', 'Accuracy (%%)', ...
        'Inference Time (rel.)', 'Accuracy Gain');
fprintf('%s\n', repmat('-', 1, 88));

for i = 1:length(numTTAAugmentations)
    accGain = ttaAccuracy(i) - ttaAccuracy(1);
    
    fprintf('%-20d %-20.1f %-25.1fx %-20.2f%%\n', ...
            numTTAAugmentations(i), ttaAccuracy(i), ...
            ttaInferenceTime(i), accGain);
end
fprintf('\n');

fprintf('TTA RECOMMENDATION:\n');
fprintf('  Optimal TTA count: 5 augmentations\n');
fprintf('  Accuracy improvement: +%.1f%%\n', ttaAccuracy(3) - ttaAccuracy(1));
fprintf('  Acceptable inference slowdown: %.1fx\n', ttaInferenceTime(3));
fprintf('  Diminishing returns beyond 7 augmentations\n\n');

%% Advanced Augmentation Techniques

advancedMethods = {'AutoAugment', 'RandAugment', 'TrivialAugment', ...
                   'AugMax', 'Fast AutoAugment'};
searchCost_hours = [15000, 0, 0, 100, 4];
achievedAccuracy = [98.5, 98.3, 98.1, 98.7, 98.4];
implementationComplexity = {'Very High', 'Low', 'Very Low', 'High', 'Medium'};

fprintf('========================================\n');
fprintf('Advanced Augmentation Methods\n');
fprintf('========================================\n');
fprintf('%-20s %-20s %-22s %-20s\n', 'Method', 'Accuracy (%%)', ...
        'Search Cost (hrs)', 'Complexity');
fprintf('%s\n', repmat('-', 1, 85));

for i = 1:length(advancedMethods)
    fprintf('%-20s %-20.1f %-22.0f %-20s\n', ...
            advancedMethods{i}, achievedAccuracy(i), ...
            searchCost_hours(i), implementationComplexity{i});
end
fprintf('\n');

fprintf('PRACTICAL RECOMMENDATION:\n');
fprintf('  For research: AutoAugment or AugMax (best accuracy)\n');
fprintf('  For production: RandAugment (best accuracy/cost ratio)\n');
fprintf('  For quick experiments: TrivialAugment (zero-cost, simple)\n\n');

%% Visualization

figure('Position', [50, 50, 1600, 900], 'Color', 'w');

% Panel 1: Validation Accuracy Comparison
subplot(2, 3, 1);
bar(validationAccuracy, 'FaceColor', [0.2, 0.5, 0.8], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);
ylabel('Validation Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(a) Augmentation Performance}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', {'Base', 'HFlip', 'Crop', 'Rot', 'Color', ...
                         'Noise', 'Cut', 'Mix', 'Rand', 'All'}, ...
         'FontSize', 10, 'XTickLabelRotation', 45);
grid on; box on;
ylim([85, 100]);

% Panel 2: Training Time vs Accuracy
subplot(2, 3, 2);
scatter(trainingTime_minutes, validationAccuracy, 200, ...
        computationalOverhead_percent, 'filled', 'MarkerEdgeColor', 'k');
colorbar;
colormap('hot');

xlabel('Training Time (minutes)', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Validation Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(b) Time-Accuracy Trade-off}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 3: Cost-Benefit Efficiency
subplot(2, 3, 3);
bar(efficiency(2:end), 'FaceColor', [0.3, 0.7, 0.3], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);

ylabel('Efficiency (Acc Gain / Time)', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(c) Augmentation Efficiency}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', augmentationTypes(2:end), 'FontSize', 10, ...
         'XTickLabelRotation', 45);
grid on; box on;

% Panel 4: Effective Dataset Expansion
subplot(2, 3, 4);
semilogy(1:length(augmentationTypes), effectiveDatasetSize, 'b-o', ...
         'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', 'b');

ylabel('Effective Dataset Size (log scale)', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(d) Dataset Expansion}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', {'Base', 'HF', 'Crop', 'Rot', 'Col', ...
                         'Noi', 'Cut', 'Mix', 'Rand', 'All'}, ...
         'FontSize', 11);
grid on; box on;

% Panel 5: Test-Time Augmentation
subplot(2, 3, 5);
yyaxis left
plot(numTTAAugmentations, ttaAccuracy, 'b-o', 'LineWidth', 2.5, ...
     'MarkerSize', 12, 'MarkerFaceColor', 'b');
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);

yyaxis right
plot(numTTAAugmentations, ttaInferenceTime, 'r-s', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'MarkerFaceColor', 'r');
ylabel('Inference Time (relative)', 'Interpreter', 'latex', 'FontSize', 13);

xlabel('Number of TTA Augmentations', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(e) Test-Time Augmentation}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 6: Advanced Methods
subplot(2, 3, 6);
yyaxis left
bar(achievedAccuracy, 'FaceColor', [0.5, 0.3, 0.7], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
ylim([97, 99]);

yyaxis right
semilogy(1:length(advancedMethods), searchCost_hours, 'ro-', ...
         'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'r');
ylabel('Search Cost (hrs, log)', 'Interpreter', 'latex', 'FontSize', 13);

title('\textbf{(f) Advanced Methods}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', {'Auto', 'Rand', 'Triv', 'Max', 'Fast'}, ...
         'FontSize', 11);
grid on; box on;

fprintf('========================================\n');
fprintf('SUMMARY AND RECOMMENDATIONS\n');
fprintf('========================================\n\n');

fprintf('FOR SMALL DATASETS:\n');
fprintf('  Priority: Maximum augmentation diversity\n');
fprintf('  Recommended: RandAugment + Cutout + Mixup\n');
fprintf('  Expected gain: +7-10%% validation accuracy\n\n');

fprintf('FOR LARGE DATASETS:\n');
fprintf('  Priority: Computational efficiency\n');
fprintf('  Recommended: Horizontal Flip + Random Crop\n');
fprintf('  Expected gain: +3-5%% with minimal overhead\n\n');

fprintf('FOR PRODUCTION DEPLOYMENT:\n');
fprintf('  Training: Combined augmentations\n');
fprintf('  Inference: TTA with 5 augmentations\n');
fprintf('  Total accuracy: 97.0%% (from 88.5%% baseline)\n');
fprintf('  Net improvement: +8.5%% absolute\n\n');
