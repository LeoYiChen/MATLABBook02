%% C0201Introduction_code_010.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Check matrix conditioning
conditionNumber = cond(A);

if conditionNumber > 1e12
    warning(['Matrix is ill-conditioned (cond = %.2e).\n', ...
        'Results may be unreliable. Consider:\n', ...
        '  1. Rescaling variables\n', ...
        '  2. Regularisation (Ridge/Tikhonov)\n', ...
        '  3. Singular value decomposition\n', ...
        '  4. Iterative refinement'], conditionNumber);
end

% Use appropriate solver based on matrix properties
if issymmetric(A) && all(eig(A) > 0)
    % Symmetric positive definite: Cholesky decomposition
    x = A \ b;  % MATLAB automatically uses Cholesky
    fprintf('Using Cholesky decomposition (SPD matrix)\n');
elseif issparse(A)
    % Sparse system: iterative methods
    [x, flag, relres] = pcg(A, b, 1e-10, 1000);
    fprintf('Using conjugate gradients (sparse)\n');
else
    % General case: LU decomposition with partial pivoting
    x = A \ b;
    fprintf('Using LU decomposition\n');
end
