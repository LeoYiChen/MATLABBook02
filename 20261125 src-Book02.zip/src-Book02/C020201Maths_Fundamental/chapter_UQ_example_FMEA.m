%% chapter_UQ_example_FMEA.m
% Failure mode analysis: FMEA with a critique of RPN ranking, exhaustive minimal cut set enumeration, exact importance measures, and the quantified benefit of a dual hydraulic circuit.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_UQ_example_FMEA
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Failure mode analysis for an automotive hydraulic braking system
%  Requires: base MATLAB, R2016b or later. No toolboxes required.

clearvars; close all; clc;
rng(11, 'twister');

fmeaTable = buildBrakeSystemFmea();
critiqueRiskPriorityNumber(fmeaTable);
faultTreeAnalysis();

%% --------- local functions -----------
function fmeaTable = buildBrakeSystemFmea()

    componentName = { 'Master cylinder'; 'Brake lines'; 'Brake caliper'; ...
        'Brake pads'; 'Brake fluid'; 'ABS module'; 'Pedal linkage' };

    failureMode = { 'Seal extrusion, fluid bypass'; ...
        'Corrosion-induced rupture'; 'Piston seizure'; ...
        'Friction material exhausted'; 'Moisture ingress, vapour lock'; ...
        'Solenoid or sensor fault'; 'Pushrod fatigue fracture' };

    failureEffect = { 'Total loss of hydraulic pressure'; ...
        'Loss of one circuit'; 'No braking on one wheel'; ...
        'Extended stopping distance'; 'Pedal travel to floor'; ...
        'Loss of anti-lock function only'; 'No pedal authority' };

    severityRating   = [10; 9; 7; 8; 9; 5; 10];
    occurrenceRating = [ 3; 2; 2; 6; 4; 3;  1];
    detectionRating  = [ 4; 5; 6; 2; 3; 2;  3];

    riskPriorityNumber = severityRating .* occurrenceRating .* ...
        detectionRating;

    fmeaTable = table(componentName, failureMode, failureEffect, ...
        severityRating, occurrenceRating, detectionRating, ...
        riskPriorityNumber, 'VariableNames', {'Component', 'FailureMode', ...
        'Effect', 'Severity', 'Occurrence', 'Detection', 'RPN'});

    fprintf('FMEA: automotive hydraulic braking system\n');
    fprintf('=========================================\n\n');
    disp(fmeaTable(:, {'Component', 'Severity', 'Occurrence', ...
        'Detection', 'RPN'}));
end

function critiqueRiskPriorityNumber(fmeaTable)

    fprintf('\nRanking comparison: RPN versus severity-first ordering\n');
    fprintf('-------------------\n');

    rpnOrder = sortrows(fmeaTable, 'RPN', 'descend');
    severityOrder = sortrows(fmeaTable, ...
        {'Severity', 'Occurrence', 'Detection'}, ...
        {'descend', 'descend', 'descend'});

    fprintf('%-5s %-20s %-20s\n', 'Rank', 'By RPN', 'By severity first');
    for rankIndex = 1:height(fmeaTable)
        fprintf('%-5d %-20s %-20s\n', rankIndex, ...
            rpnOrder.Component{rankIndex}, ...
            severityOrder.Component{rankIndex});
    end

    disagreementCount = sum(~strcmp(rpnOrder.Component, ...
        severityOrder.Component));
    fprintf('\nThe two orderings disagree in %d of %d positions.\n', ...
        disagreementCount, height(fmeaTable));
    fprintf('RPN multiplies ORDINAL ratings, so equal products can conceal\n');
    fprintf('very unequal severities. IEC 60812:2018 therefore recommends\n');
    fprintf('severity-led prioritisation over raw RPN thresholds.\n');

    % Demonstrate the non-injectivity of the RPN scale
    allProducts = unique(reshape((1:10)' * (1:10), [], 1) * (1:10));
    fprintf('\nOf 1000 rating triples, only %d distinct RPN values exist,\n', ...
        numel(unique(allProducts)));
    fprintf('so the scale is coarse and unevenly spaced by construction.\n\n');

    visualiseFmea(fmeaTable, rpnOrder);
end

function faultTreeAnalysis()

    fprintf('Fault tree analysis: loss of braking function\n');
    fprintf('============================================\n\n');

    basicEventName = {'Seal bypass', 'Cylinder crack', 'Line rupture', ...
        'Caliper leak', 'Low fluid', 'Pedal linkage'};
    basicEventProbability = [50e-6, 10e-6, 20e-6, 30e-6, 100e-6, 5e-6];

    singleCircuitTop = brakeFailureProbability(basicEventProbability, false);
    dualCircuitTop   = brakeFailureProbability(basicEventProbability, true);

    fprintf('Basic event probabilities per driving cycle:\n');
    for eventIndex = 1:numel(basicEventName)
        fprintf('  %-16s %.2e\n', basicEventName{eventIndex}, ...
            basicEventProbability(eventIndex));
    end

    fprintf('\nTop event probability:\n');
    fprintf('  Single hydraulic circuit : %.4e\n', singleCircuitTop);
    fprintf('  Dual independent circuits: %.4e\n', dualCircuitTop);
    fprintf('  Improvement factor       : %.1f\n', ...
        singleCircuitTop / dualCircuitTop);
    fprintf('  Residual risk is now dominated by the pedal linkage,\n');
    fprintf('  which no amount of hydraulic redundancy can address.\n\n');

    % -- Exhaustive minimal cut set enumeration (2^6 = 64 states) ---
    minimalCutSets = enumerateMinimalCutSets(numel(basicEventName));
    fprintf('Minimal cut sets, single-circuit design:\n');
    cutSetProbability = zeros(size(minimalCutSets, 1), 1);
    for cutSetIndex = 1:size(minimalCutSets, 1)
        memberIndices = find(minimalCutSets(cutSetIndex, :));
        cutSetProbability(cutSetIndex) = ...
            prod(basicEventProbability(memberIndices));
        fprintf('  {%s} : %.2e\n', ...
            strjoin(basicEventName(memberIndices), ' AND '), ...
            cutSetProbability(cutSetIndex));
    end
    fprintf('  All %d cut sets are singletons, so this design has %d\n', ...
        size(minimalCutSets, 1), size(minimalCutSets, 1));
    fprintf('  single points of failure. Dual-circuit braking has been\n');
    fprintf('  mandatory on passenger cars for precisely this reason.\n\n');

    % -- Exact importance measures --------------
    structureFun = @(q) brakeFailureProbability(q, false);
    importance = componentImportance(structureFun, basicEventProbability);

    fprintf('Importance measures, single-circuit design:\n');
    fprintf('%-16s %11s %11s %8s %8s\n', 'Component', 'Birnbaum', ...
        'Fussell-V', 'RAW', 'RRW');
    for eventIndex = 1:numel(basicEventName)
        fprintf('%-16s %11.4f %11.4f %8.1f %8.3f\n', ...
            basicEventName{eventIndex}, ...
            importance.birnbaum(eventIndex), ...
            importance.fussellVesely(eventIndex), ...
            importance.riskAchievement(eventIndex), ...
            importance.riskReduction(eventIndex));
    end
    fprintf('Fussell-Vesely values sum to %.4f, close to unity because\n', ...
        sum(importance.fussellVesely));
    fprintf('all cut sets are singletons and probabilities are small.\n\n');

    % -- Monte Carlo validation with an honest interval ------
    numTrials = 2e6;
    failureFlags = simulateBrakeFailures(basicEventProbability, ...
        numTrials, false);
    observedFailures = sum(failureFlags);
    monteCarloEstimate = observedFailures / numTrials;
    [wilsonLow, wilsonHigh] = wilsonScoreInterval(observedFailures, ...
        numTrials, 1.959964);

    fprintf('Monte Carlo validation (%d trials):\n', numTrials);
    fprintf('  Observed failures : %d\n', observedFailures);
    fprintf('  Estimate          : %.4e\n', monteCarloEstimate);
    fprintf('  95%% Wilson interval: [%.4e, %.4e]\n', wilsonLow, wilsonHigh);
    fprintf('  Analytical value  : %.4e\n', singleCircuitTop);
    fprintf('  Relative error    : %.2f%%\n', ...
        100*abs(monteCarloEstimate - singleCircuitTop)/singleCircuitTop);
    fprintf('\n  Crude Monte Carlo needs N proportional to 1/p, so the dual\n');
    fprintf('  circuit design at p = %.1e would demand roughly %.0e trials\n', ...
        dualCircuitTop, 100/dualCircuitTop);
    fprintf('  for comparable precision. Importance sampling or subset\n');
    fprintf('  simulation becomes essential in that regime.\n\n');

    visualiseFaultTree(basicEventName, importance, cutSetProbability, ...
        singleCircuitTop, dualCircuitTop);
end

function topProbability = brakeFailureProbability(q, isDualCircuit)
    % q = [seal, cylinder crack, line, caliper, low fluid, pedal linkage]
    masterCylinder = orGate([q(1), q(2)]);
    fluidLoss      = orGate([q(3), q(4), q(5)]);
    oneCircuit     = orGate([masterCylinder, fluidLoss]);

    if isDualCircuit
        hydraulicLoss = oneCircuit^2;      % two independent circuits
    else
        hydraulicLoss = oneCircuit;
    end
    topProbability = orGate([hydraulicLoss, q(6)]);
end

function gateProbability = orGate(inputProbabilities)
    gateProbability = 1 - prod(1 - inputProbabilities);
end

function hasFailed = brakeFailureBoolean(eventFlags)
    masterCylinder = eventFlags(1) || eventFlags(2);
    fluidLoss      = eventFlags(3) || eventFlags(4) || eventFlags(5);
    hasFailed      = masterCylinder || fluidLoss || eventFlags(6);
end

function minimalCutSets = enumerateMinimalCutSets(numEvents)
    % Exhaustive enumeration; tractable for numEvents up to about 20.
    allStates = logical(dec2bin(0:2^numEvents-1, numEvents) - '0');
    minimalCutSets = false(0, numEvents);
    for stateIndex = 1:size(allStates, 1)
        candidateState = allStates(stateIndex, :);
        if ~brakeFailureBoolean(candidateState)
            continue;
        end
        isMinimal = true;
        for memberIndex = find(candidateState)
            reducedState = candidateState;
            reducedState(memberIndex) = false;
            if brakeFailureBoolean(reducedState)
                isMinimal = false;
                break;
            end
        end
        if isMinimal
            minimalCutSets = [minimalCutSets; candidateState];  %#ok<AGROW>
        end
    end
end

function importance = componentImportance(structureFun, q)
    % Exact measures by conditioning, avoiding numerical differentiation.
    topProbability = structureFun(q);
    numComponents  = numel(q);

    importance.birnbaum        = zeros(1, numComponents);
    importance.fussellVesely   = zeros(1, numComponents);
    importance.riskAchievement = zeros(1, numComponents);
    importance.riskReduction   = zeros(1, numComponents);

    for componentIndex = 1:numComponents
        failedCase = q;  failedCase(componentIndex) = 1;
        workingCase = q; workingCase(componentIndex) = 0;

        probabilityGivenFailed  = structureFun(failedCase);
        probabilityGivenWorking = structureFun(workingCase);

        importance.birnbaum(componentIndex) = ...
            probabilityGivenFailed - probabilityGivenWorking;
        importance.fussellVesely(componentIndex) = ...
            q(componentIndex) * probabilityGivenFailed / topProbability;
        importance.riskAchievement(componentIndex) = ...
            probabilityGivenFailed / topProbability;
        importance.riskReduction(componentIndex) = ...
            topProbability / probabilityGivenWorking;
    end
end

function failureFlags = simulateBrakeFailures(q, numTrials, isDualCircuit)
    eventOccurred = rand(numTrials, numel(q)) < q;
    masterCylinder = eventOccurred(:,1) | eventOccurred(:,2);
    fluidLoss      = eventOccurred(:,3) | eventOccurred(:,4) | ...
                     eventOccurred(:,5);
    oneCircuit     = masterCylinder | fluidLoss;
    if isDualCircuit
        secondCircuit = rand(numTrials, 1) < ...
            brakeFailureProbability([q(1:5), 0], false);
        hydraulicLoss = oneCircuit & secondCircuit;
    else
        hydraulicLoss = oneCircuit;
    end
    failureFlags = hydraulicLoss | eventOccurred(:,6);
end

function [lowerBound, upperBound] = wilsonScoreInterval(numSuccess, ...
    numTrials, criticalValue)
    proportion  = numSuccess / numTrials;
    denominator = 1 + criticalValue^2 / numTrials;
    centre      = (proportion + criticalValue^2/(2*numTrials)) / denominator;
    halfWidth   = (criticalValue / denominator) * ...
        sqrt(proportion*(1-proportion)/numTrials + ...
             criticalValue^2/(4*numTrials^2));
    lowerBound  = max(0, centre - halfWidth);
    upperBound  = min(1, centre + halfWidth);
end

function visualiseFmea(fmeaTable, rpnOrder)

    figure('Position', [100, 100, 1300, 400], 'Name', 'FMEA');

    subplot(1, 3, 1);
    scatter(fmeaTable.Occurrence, fmeaTable.Severity, ...
        20*sqrt(fmeaTable.RPN), fmeaTable.RPN, 'filled'); hold on;
    colorbar; xlabel('Occurrence rating'); ylabel('Severity rating');
    title('(a) Risk matrix, area \propto RPN');
    axis([0.5 10.5 0.5 10.5]); grid on;
    for rowIndex = 1:height(fmeaTable)
        text(fmeaTable.Occurrence(rowIndex) + 0.25, ...
            fmeaTable.Severity(rowIndex), ...
            fmeaTable.Component{rowIndex}(1:min(6, end)), 'FontSize', 8);
    end

    subplot(1, 3, 2);
    barh(flipud(rpnOrder.RPN));
    set(gca, 'YTick', 1:height(rpnOrder), 'YTickLabel', ...
        flipud(rpnOrder.Component));
    xlabel('Risk priority number'); title('(b) RPN ranking'); grid on;

    subplot(1, 3, 3);
    sortedRpn = sort(fmeaTable.RPN, 'descend');
    cumulativeShare = 100 * cumsum(sortedRpn) / sum(sortedRpn);
    yyaxis left;  bar(sortedRpn); ylabel('RPN');
    yyaxis right; plot(cumulativeShare, '-o', 'LineWidth', 1.8);
    ylabel('Cumulative share [%]'); ylim([0 105]);
    yline(80, 'k--');
    xlabel('Rank'); title('(c) Pareto view'); grid on;
end

function visualiseFaultTree(basicEventName, importance, ...
    cutSetProbability, singleCircuitTop, dualCircuitTop)

    figure('Position', [100, 100, 1300, 400], 'Name', 'Fault tree');

    subplot(1, 3, 1);
    barh([importance.birnbaum(:), importance.fussellVesely(:)]);
    set(gca, 'YTick', 1:numel(basicEventName), 'YTickLabel', basicEventName);
    xlabel('Importance'); title('(a) Importance measures');
    legend('Birnbaum', 'Fussell-Vesely', 'Location', 'southeast'); grid on;

    subplot(1, 3, 2);
    pie(cutSetProbability, basicEventName);
    title('(b) Cut set contributions');

    subplot(1, 3, 3);
    bar([singleCircuitTop, dualCircuitTop]);
    set(gca, 'XTickLabel', {'Single circuit', 'Dual circuit'}, ...
        'YScale', 'log');
    ylabel('Top event probability'); title('(c) Architectural benefit');
    grid on;
end

% -----------------------
% Computational complexity. The structure function evaluates in O(n) for
% n basic events, so all four importance measures cost O(n^2) arithmetic
% with no sampling at all. Exhaustive minimal cut set enumeration is
% O(2^n * n^2) and therefore practical only to roughly twenty events;
% beyond that, MOCUS or binary decision diagrams are required. Monte
% Carlo validation costs O(N n) and, critically, needs N proportional to
% the reciprocal of the top event probability, which is why rare-event
% designs demand importance sampling rather than larger budgets.
% -----------------------
