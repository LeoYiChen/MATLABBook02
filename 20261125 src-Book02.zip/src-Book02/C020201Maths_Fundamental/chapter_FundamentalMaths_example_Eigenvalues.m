%% chapter_FundamentalMaths_example_Eigenvalues.m
% Computing and interpreting eigenvalues and eigenvectors.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_Eigenvalues
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_LinearAlgebra_Example03.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Comprehensive demonstration of eigenvalue and eigenvector
%              computation, including geometric interpretation and applications.

function demonstrateEigenvalues()
    fprintf('Eigenvalues and Eigenvectors in MATLAB\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic eigenvalue computation
    demonstrateBasicEigenvalues();
    
    % Part 2: Symmetric matrices
    demonstrateSymmetricEigenvalues();
    
    % Part 3: Geometric interpretation
    demonstrateGeometricInterpretation();
    
    % Part 4: Applications - Principal Component Analysis
    demonstratePCA();
    
    % Part 5: Power iteration method
    demonstratePowerIteration();
end

function demonstrateBasicEigenvalues()
    fprintf('Part 1: Basic Eigenvalue Computation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define a simple matrix
    A = [4, 1; 2, 3];
    
    fprintf('Matrix A:\n');
    disp(A);
    
    % Compute eigenvalues and eigenvectors
    [V, D] = eig(A);
    
    fprintf('Eigenvalue matrix D:\n');
    disp(D);
    
    fprintf('Eigenvector matrix V:\n');
    disp(V);
    
    % Extract eigenvalues
    eigenvalues = diag(D);
    fprintf('\nEigenvalues:\n');
    for k = 1:length(eigenvalues)
        fprintf('  λ_%d = %.6f\n', k, eigenvalues(k));
    end
    
    % Verify eigenvalue equation for each eigenpair
    fprintf('\nVerification of Av = λv:\n');
    for k = 1:size(V, 2)
        v = V(:, k);
        lambda = D(k, k);
        
        Av = A * v;
        lambda*V = lambda * v;
        
        error = norm(Av - lambda*V);
        fprintf('  Eigenpair %d: ||Av - λv|| = %.10e\n', k, error);
    end
    
    % Demonstrate eigenvalue decomposition
    fprintf('\nEigenvalue decomposition: A = VDV^(-1)\n');
    A_reconstructed = V * D * inv(V);
    fprintf('Reconstructed A:\n');
    disp(A_reconstructed);
    
    reconstruction_error = norm(A - A_reconstructed, 'fro');
    fprintf('Reconstruction error: %.10e\n\n', reconstruction_error);
end

function demonstrateSymmetricEigenvalues()
    fprintf('Part 2: Symmetric Matrices\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create symmetric matrix
    A = [4, 2, 1; 2, 5, 3; 1, 3, 6];
    
    fprintf('Symmetric matrix A:\n');
    disp(A);
    
    fprintf('Verify symmetry: A = A''? %s\n', mat2str(isequal(A, A')));
    
    % Compute eigenvalues and eigenvectors
    [V, D] = eig(A);
    
    fprintf('\nEigenvalues (guaranteed real for symmetric matrices):\n');
    eigenvalues = diag(D);
    for k = 1:length(eigenvalues)
        fprintf('  λ_%d = %.6f\n', k, eigenvalues(k));
    end
    
    fprintf('\nEigenvector matrix V:\n');
    disp(V);
    
    % Verify orthogonality of eigenvectors
    fprintf('Verify orthogonality: V''V\n');
    VTV = V' * V;
    disp(VTV);
    
    orthogonality_error = norm(VTV - eye(size(V, 2)), 'fro');
    fprintf('Orthogonality error: %.10e\n', orthogonality_error);
    
    % For symmetric matrices: A = VDV'
    fprintf('\nFor symmetric A: A = VDV'' (note transpose, not inverse)\n');
    A_reconstructed = V * D * V';
    reconstruction_error = norm(A - A_reconstructed, 'fro');
    fprintf('Reconstruction error: %.10e\n\n', reconstruction_error);
    
    % Demonstrate spectral theorem
    fprintf('Spectral theorem: A = Σ λᵢ vᵢvᵢ''\n');
    A_spectral = zeros(size(A));
    for k = 1:length(eigenvalues)
        lambda = eigenvalues(k);
        v = V(:, k);
        A_spectral = A_spectral + lambda * (v * v');
    end
    
    spectral_error = norm(A - A_spectral, 'fro');
    fprintf('Spectral decomposition error: %.10e\n\n', spectral_error);
end

function demonstrateGeometricInterpretation()
    fprintf('Part 3: Geometric Interpretation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define transformation matrix
    theta = pi/6; % 30 degrees rotation
    scale1 = 2;
    scale2 = 0.5;
    
    % Rotation matrix
    R = [cos(theta), -sin(theta); sin(theta), cos(theta)];
    
    % Diagonal scaling matrix
    S = diag([scale1, scale2]);
    
    % Combined transformation
    A = R * S * R';
    
    fprintf('Transformation matrix A (rotation + scaling + rotation back):\n');
    disp(A);
    
    % Compute eigenvalues and eigenvectors
    [V, D] = eig(A);
    
    fprintf('Eigenvalues (principal stretching factors):\n');
    disp(diag(D));
    
    fprintf('Eigenvectors (principal directions):\n');
    disp(V);
    
    % Visualise transformation effect
    figure('Position', [100, 100, 1200, 500]);
    
    % Create unit circle
    theta_circle = linspace(0, 2*pi, 100);
    circle = [cos(theta_circle); sin(theta_circle)];
    
    % Transform circle
    ellipse = A * circle;
    
    % Subplot 1: Original and transformed shapes
    subplot(1, 2, 1);
    plot(circle(1, :), circle(2, :), 'b-', 'LineWidth', 2, ...
         'DisplayName', 'Unit Circle');
    hold on;
    plot(ellipse(1, :), ellipse(2, :), 'r-', 'LineWidth', 2, ...
         'DisplayName', 'Transformed Ellipse');
    
    % Plot eigenvectors
    eigenvalues = diag(D);
    for k = 1:2
        v = V(:, k);
        lambda = eigenvalues(k);
        quiver(0, 0, lambda*v(1), lambda*v(2), 0, 'k-', ...
               'LineWidth', 2, 'MaxHeadSize', 0.5, ...
               'DisplayName', sprintf('λ_%d v_%d', k, k));
    end
    
    axis equal;
    grid on;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Geometric Effect of Transformation', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 10);
    
    % Subplot 2: Eigenvector directions
    subplot(1, 2, 2);
    
    % Sample points along eigenvector directions
    t = linspace(-2, 2, 50);
    for k = 1:2
        v = V(:, k);
        lambda = eigenvalues(k);
        
        % Points along eigenvector
        points = v * t;
        
        % Transformed points
        transformed = A * points;
        
        plot(points(1, :), points(2, :), 'b--', 'LineWidth', 1.5);
        hold on;
        plot(transformed(1, :), transformed(2, :), 'r-', 'LineWidth', 2);
        
        % Mark eigenvector
        quiver(0, 0, v(1), v(2), 0, 'k-', 'LineWidth', 2.5, ...
               'MaxHeadSize', 0.8);
        text(1.3*v(1), 1.3*v(2), sprintf('v_%d', k), ...
             'FontSize', 12, 'Interpreter', 'latex');
    end
    
    axis equal;
    grid on;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Eigenvectors: Invariant Directions', 'Interpreter', 'latex', ...
          'FontSize', 13);
    
    fprintf('Visualisation shows eigenvectors as principal axes of ellipse\n');
    fprintf('Eigenvalues determine stretching along these directions\n\n');
end

function demonstratePCA()
    fprintf('Part 4: Application - Principal Component Analysis\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Generate correlated 2*D data
    rng(42);
    n = 200;
    
    % True covariance structure
    mean_true = [2; 3];
    cov_true = [2, 1.5; 1.5, 1];
    
    % Generate data
    data = mvnrnd(mean_true, cov_true, n)';
    
    fprintf('Generated %d data points with correlation\n', n);
    
    % Centre the data
    data_centred = data - mean(data, 2);
    
    % Compute sample covariance matrix
    C = cov(data_centred');
    
    fprintf('\nSample covariance matrix:\n');
    disp(C);
    
    % Compute eigenvalues and eigenvectors
    [V, D] = eig(C);
    
    % Sort by eigenvalue magnitude (descending)
    [eigenvalues, idx] = sort(diag(D), 'descend');
    V = V(:, idx);
    
    fprintf('Principal component eigenvalues:\n');
    for k = 1:length(eigenvalues)
        variance_explained = eigenvalues(k) / sum(eigenvalues) * 100;
        fprintf('  PC%d: λ = %.4f (%.2f%% variance)\n', ...
                k, eigenvalues(k), variance_explained);
    end
    
    % Project data onto principal components
    data_pca = V' * data_centred;
    
    % Visualise
    figure('Position', [100, 100, 1200, 500]);
    
    % Original data
    subplot(1, 2, 1);
    scatter(data(1, :), data(2, :), 20, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    
    % Plot principal components
    for k = 1:2
        v = V(:, k);
        scale = 2 * sqrt(eigenvalues(k));
        quiver(mean_true(1), mean_true(2), scale*v(1), scale*v(2), 0, ...
               'r-', 'LineWidth', 2.5, 'MaxHeadSize', 0.5);
        text(mean_true(1) + 1.2*scale*v(1), ...
             mean_true(2) + 1.2*scale*v(2), ...
             sprintf('PC%d', k), 'FontSize', 12, 'Color', 'r', ...
             'Interpreter', 'latex');
    end
    
    axis equal;
    grid on;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Data with Principal Components', ...
          'Interpreter', 'latex', 'FontSize', 13);
    
    % Transformed data
    subplot(1, 2, 2);
    scatter(data_pca(1, :), data_pca(2, :), 20, 'b', ...
            'filled', 'MarkerFaceAlpha', 0.6);
    axis equal;
    grid on;
    xlabel('PC1', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('PC2', 'Interpreter', 'latex', 'FontSize', 12);
    title('Data in Principal Component Space', ...
          'Interpreter', 'latex', 'FontSize', 13);
    
    fprintf('\nPCA transforms data to uncorrelated coordinates\n');
    fprintf('Principal components are eigenvectors of covariance matrix\n\n');
end

function demonstratePowerIteration()
    fprintf('Part 5: Power Iteration Method\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create matrix with dominant eigenvalue
    A = [4, 1, 0; 1, 3, 1; 0, 1, 2];
    
    fprintf('Matrix A:\n');
    disp(A);
    
    % True eigenvalues
    eigenvalues_true = sort(eig(A), 'descend');
    fprintf('\nTrue eigenvalues (sorted): ');
    fprintf('%.6f ', eigenvalues_true);
    fprintf('\n\n');
    
    % Power iteration
    fprintf('Power iteration to find dominant eigenvalue:\n');
    
    % Initial random vector
    rng(42);
    v = rand(size(A, 1), 1);
    v = v / norm(v);
    
    maxIter = 20;
    lambda_estimates = zeros(maxIter, 1);
    
    fprintf('%5*s %15*s %15*s\n', 'Iter', 'λ estimate', 'Error');
    fprintf('%s\n', repmat('-', 1, 40));
    
    for k = 1:maxIter
        % Power iteration step
        v_new = A * v;
        lambda_est = v' * v_new; % Rayleigh quotient
        v = v_new / norm(v_new);
        
        lambda_estimates(k) = lambda_est;
        error = abs(lambda_est - eigenvalues_true(1));
        
        fprintf('%5*d %15.10*f %15.10*e\n', k, lambda_est, error);
    end
    
    fprintf('\nPower iteration converges to dominant eigenvalue\n');
    fprintf('Final estimate: %.10f\n', lambda_estimates(end));
    fprintf('True value:     %.10f\n', eigenvalues_true(1));
    fprintf('Final error:    %.10e\n\n', ...
            abs(lambda_estimates(end) - eigenvalues_true(1)));
    
    % Plot convergence
    figure('Position', [100, 100, 800, 500]);
    semilogy(1:maxIter, abs(lambda_estimates - eigenvalues_true(1)), ...
             'b-o', 'LineWidth', 2, 'MarkerSize', 6);
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Absolute Error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Power Iteration Convergence', 'Interpreter', 'latex', ...
          'FontSize', 13);
    set(gca, 'FontSize', 11);
end
