%% chapter_DataVisualisation_density.m
% Density Plot Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_density
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Generate sample data
data = randn(1000,1);

% Create density plot
figure('Position', [100 100 800 600]);
[f,xi] = ksdensity(data);
plot(xi,f,'LineWidth',2);
hold on;
histogram(data,'Normalization','pdf','FaceAlpha',0.3);
xlabel('Values');
ylabel('Density');
title('Probability Density Estimation');
grid on;
legend('KDE','Histogram');

% Export figure in multiple formats
exportFigure(gca, 'density_plot');
