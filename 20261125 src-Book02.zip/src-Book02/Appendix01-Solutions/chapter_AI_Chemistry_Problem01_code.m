%% chapter_AI_Chemistry_Problem01_code.m
% Problem 1: QSAR Modelling for Aqueous Solubility Prediction
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Chemistry_Problem01_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Script: Problem 1 - QSAR Aqueous Solubility Prediction
% Chapter: AI in Chemistry Research and Education
% Author: Dr Yi Chen (IEEE Fellow, IET Fellow, IMechE Fellow)
% Affiliation: Newcastle University, United Kingdom
% Date: January 2025
% MATLAB Version: R2023b or later
% Required Toolboxes: Statistics and Machine Learning Toolbox
% Description: Develop and compare machine learning QSAR models for
%              predicting aqueous solubility of organic molecules
% Version Control: v1.0 - Initial implementation
%                  Tested on MATLAB R2023b, Windows 11 Pro, 16GB RAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialisation and Environment Setup
clear all; close all; clc;

fprintf('========================================\n');
fprintf('Problem 1: QSAR Aqueous Solubility Prediction\n');
fprintf('Machine Learning Models for Molecular Property Prediction\n');
fprintf('========================================\n\n');

% Set random seed for reproducibility
rng(2025, 'twister');

%% Step 1: Generate Synthetic Molecular Dataset
fprintf('Step 1: Generating synthetic molecular descriptor dataset...\n');

numMolecules = 500;

% Molecular descriptors (realistic ranges for drug-like molecules)
molecularWeight = 150 + 350 * rand(numMolecules, 1); % 150-500 Da
logP = -2 + 7 * rand(numMolecules, 1); % -2 to 5 (hydrophobicity)
hydrogenBondDonors = randi([0, 5], numMolecules, 1); % 0-5 HBD
hydrogenBondAcceptors = randi([0, 10], numMolecules, 1); % 0-10 HBA
polarSurfaceArea = 20 + 120 * rand(numMolecules, 1); % 20-140 Angstrom^2
rotatableBonds = randi([0, 12], numMolecules, 1); % 0-12 rotatable bonds

% Combine into descriptor matrix
descriptorMatrix = [molecularWeight, logP, hydrogenBondDonors, ...
                   hydrogenBondAcceptors, polarSurfaceArea, rotatableBonds];

descriptorNames = {'Molecular Weight (Da)', 'LogP', 'H-Bond Donors', ...
                  'H-Bond Acceptors', 'Polar Surface Area ($\AA^2$)', ...
                  'Rotatable Bonds'};

% Generate aqueous solubility (log S) using known QSAR relationship
% General equation: log S = a - b*LogP - c*MW/100 + d*HBA + noise
% Negative correlation with LogP and MW; positive with HBA

coeffLogP = -0.8; % More hydrophobic -> less soluble
coeffMW = -0.006; % Larger molecules -> less soluble
coeffHBA = 0.15; % More H-bond acceptors -> more soluble
interceptTerm = 0.5;

logSolubility = interceptTerm + coeffLogP * logP + coeffMW * molecularWeight + ...
               coeffHBA * hydrogenBondAcceptors + 0.5 * randn(numMolecules, 1);

fprintf('  Generated %d molecules with 6 descriptors\n', numMolecules);
fprintf('  Solubility range: %.2f to %.2f log S units\n', ...
        min(logSolubility), max(logSolubility));
fprintf('  Mean solubility: %.2f log S\n\n', mean(logSolubility));

%% Step 2: Exploratory Data Analysis
fprintf('Step 2: Performing exploratory data analysis...\n');

% Figure 1: Descriptor distributions and correlations
figure('Name', 'Exploratory Data Analysis', 'Position', [100, 100, 1600, 1000]);

% Histogram of solubility
subplot(3, 3, 1);
histogram(logSolubility, 30, 'FaceColor', [0.3, 0.6, 0.9], 'EdgeColor', 'k');
xlabel('Log Solubility (log S)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
title('Target Variable Distribution', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

% Descriptor distributions (selected)
descriptorIndices = [2, 5]; % LogP and PSA
for plotIdx = 1:length(descriptorIndices)
    descIdx = descriptorIndices(plotIdx);
    subplot(3, 3, plotIdx + 1);
    histogram(descriptorMatrix(:, descIdx), 25, 'FaceColor', [0.9, 0.5, 0.3], ...
             'EdgeColor', 'k');
    xlabel(descriptorNames{descIdx}, 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
    title(sprintf('Descriptor: %s', strrep(descriptorNames{descIdx}, '$', '')), ...
          'Interpreter', 'latex', 'FontSize', 11);
    grid on;
end

% Correlation matrix
subplot(3, 3, [4, 5, 6, 7, 8, 9]);
correlationMatrix = corr([descriptorMatrix, logSolubility]);
imagesc(correlationMatrix);
colorbar;
colormap('redblue');
caxis([-1, 1]);
xticks(1:7);
yticks(1:7);
xticklabels([descriptorNames, {'Log Solubility'}]);
yticklabels([descriptorNames, {'Log Solubility'}]);
xtickangle(45);
title('Descriptor Correlation Matrix', 'Interpreter', 'latex', 'FontSize', 13);

% Annotate correlation values
[xGrid, yGrid] = meshgrid(1:7);
for idx = 1:numel(correlationMatrix)
    text(xGrid(idx), yGrid(idx), sprintf('%.2f', correlationMatrix(idx)), ...
         'HorizontalAlignment', 'center', 'Color', 'white', ...
         'FontWeight', 'bold', 'FontSize', 9);
end

saveas(gcf, 'Problem01_ExploratoryAnalysis.fig');
saveas(gcf, 'Problem01_ExploratoryAnalysis.eps', 'epsc');
saveas(gcf, 'Problem01_ExploratoryAnalysis.jpg');

fprintf('  Exploratory analysis complete\n');
fprintf('  Figures saved: .fig, .eps, .jpg formats\n\n');

%% Step 3: Data Preprocessing and Train-Test Split
fprintf('Step 3: Preprocessing data and creating train-test split...\n');

% Standardise descriptors (zero mean, unit variance)
descriptorMean = mean(descriptorMatrix);
descriptorStd = std(descriptorMatrix);
descriptorMatrixStandardised = (descriptorMatrix - descriptorMean) ./ descriptorStd;

fprintf('  Descriptors standardised (z-score normalisation)\n');

% Train-test split (80-20)
trainFraction = 0.8;
numTrain = round(trainFraction * numMolecules);
trainIndices = randperm(numMolecules, numTrain);
testIndices = setdiff(1:numMolecules, trainIndices);

descriptorsTrain = descriptorMatrixStandardised(trainIndices, :);
solubilityTrain = logSolubility(trainIndices);

descriptorsTest = descriptorMatrixStandardised(testIndices, :);
solubilityTest = logSolubility(testIndices);

fprintf('  Training set: %d molecules\n', length(trainIndices));
fprintf('  Test set: %d molecules\n\n', length(testIndices));

%% Step 4: Model 1 - Linear Regression (Baseline)
fprintf('Step 4: Training Linear Regression model (baseline)...\n');

modelLinear = fitlm(descriptorsTrain, solubilityTrain, 'VarNames', ...
                   [descriptorNames, {'LogSolubility'}]);

% Predictions
predictionsLinearTrain = predict(modelLinear, descriptorsTrain);
predictionsLinearTest = predict(modelLinear, descriptorsTest);

% Performance metrics
rmseLinearTrain = sqrt(mean((predictionsLinearTrain - solubilityTrain).^2));
r2LinearTrain = 1 - sum((solubilityTrain - predictionsLinearTrain).^2) / ...
               sum((solubilityTrain - mean(solubilityTrain)).^2);

rmseLinearTest = sqrt(mean((predictionsLinearTest - solubilityTest).^2));
r2LinearTest = 1 - sum((solubilityTest - predictionsLinearTest).^2) / ...
              sum((solubilityTest - mean(solubilityTest)).^2);

fprintf('  Linear Regression Performance:\n');
fprintf('    Training: RMSE = %.4f, R = %.4f\n', rmseLinearTrain, r2LinearTrain);
fprintf('    Test: RMSE = %.4f, R = %.4f\n\n', rmseLinearTest, r2LinearTest);

%% Step 5: Model 2 - Gaussian Process Regression
fprintf('Step 5: Training Gaussian Process Regression model...\n');

% GP with squared exponential kernel
modelGP = fitrgp(descriptorsTrain, solubilityTrain, 'KernelFunction', 'squaredexponential', ...
                'Standardize', false, 'Verbose', 0);

% Predictions (with uncertainty)
[predictionsGPTrain, ~, predictionsGPTrainCI] = predict(modelGP, descriptorsTrain);
[predictionsGPTest, ~, predictionsGPTestCI] = predict(modelGP, descriptorsTest);

% Performance metrics
rmseGPTrain = sqrt(mean((predictionsGPTrain - solubilityTrain).^2));
r2GPTrain = 1 - sum((solubilityTrain - predictionsGPTrain).^2) / ...
           sum((solubilityTrain - mean(solubilityTrain)).^2);

rmseGPTest = sqrt(mean((predictionsGPTest - solubilityTest).^2));
r2GPTest = 1 - sum((solubilityTest - predictionsGPTest).^2) / ...
          sum((solubilityTest - mean(solubilityTest)).^2);

fprintf('  Gaussian Process Regression Performance:\n');
fprintf('    Training: RMSE = %.4f, R = %.4f\n', rmseGPTrain, r2GPTrain);
fprintf('    Test: RMSE = %.4f, R = %.4f\n\n', rmseGPTest, r2GPTest);

%% Step 6: Model 3 - Gradient Boosting Trees (Ensemble)
fprintf('Step 6: Training Gradient Boosting Regression Trees...\n');

modelGBT = fitrensemble(descriptorsTrain, solubilityTrain, 'Method', 'LSBoost', ...
                       'NumLearningCycles', 100, 'LearnRate', 0.1, ...
                       'Learners', templateTree('MinLeafSize', 5));

% Predictions
predictionsGBTTrain = predict(modelGBT, descriptorsTrain);
predictionsGBTTest = predict(modelGBT, descriptorsTest);

% Performance metrics
rmseGBTTrain = sqrt(mean((predictionsGBTTrain - solubilityTrain).^2));
r2GBTTrain = 1 - sum((solubilityTrain - predictionsGBTTrain).^2) / ...
            sum((solubilityTrain - mean(solubilityTrain)).^2);

rmseGBTTest = sqrt(mean((predictionsGBTTest - solubilityTest).^2));
r2GBTTest = 1 - sum((solubilityTest - predictionsGBTTest).^2) / ...
           sum((solubilityTest - mean(solubilityTest)).^2);

fprintf('  Gradient Boosting Trees Performance:\n');
fprintf('    Training: RMSE = %.4f, R = %.4f\n', rmseGBTTrain, r2GBTTrain);
fprintf('    Test: RMSE = %.4f, R = %.4f\n\n', rmseGBTTest, r2GBTTest);

%% Step 7: Model Comparison and Visualisation
fprintf('Step 7: Comparing models and generating visualisations...\n');

% Figure 2: Predicted vs Actual for all models
figure('Name', 'Model Performance Comparison', 'Position', [100, 100, 1800, 600]);

modelNames = {'Linear Regression', 'Gaussian Process', 'Gradient Boosting'};
predictionsTestAll = {predictionsLinearTest, predictionsGPTest, predictionsGBTTest};
r2TestAll = [r2LinearTest, r2GPTest, r2GBTTest];
rmseTestAll = [rmseLinearTest, rmseGPTest, rmseGBTTest];

for modelIdx = 1:3
    subplot(1, 3, modelIdx);
    
    % Scatter plot: predicted vs actual
    scatter(solubilityTest, predictionsTestAll{modelIdx}, 60, 'filled', ...
           'MarkerFaceColor', [0.2, 0.4, 0.8], 'MarkerEdgeColor', 'k', ...
           'MarkerFaceAlpha', 0.6);
    hold on;
    
    % Perfect prediction line
    minVal = min([solubilityTest; predictionsTestAll{modelIdx}]);
    maxVal = max([solubilityTest; predictionsTestAll{modelIdx}]);
    plot([minVal, maxVal], [minVal, maxVal], 'r-', 'LineWidth', 2);
    
    hold off;
    xlabel('Actual Log Solubility', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Predicted Log Solubility', 'Interpreter', 'latex', 'FontSize', 12);
    title(sprintf('%s\n$R^2 = %.3f$, RMSE $= %.3f$', modelNames{modelIdx}, ...
                 r2TestAll(modelIdx), rmseTestAll(modelIdx)), ...
          'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    axis equal;
    xlim([minVal - 0.5, maxVal + 0.5]);
    ylim([minVal - 0.5, maxVal + 0.5]);
    legend({'Test Data', 'Perfect Prediction'}, 'Location', 'northwest', ...
           'Interpreter', 'latex', 'FontSize', 10);
end

saveas(gcf, 'Problem01_ModelComparison.fig');
saveas(gcf, 'Problem01_ModelComparison.eps', 'epsc');
saveas(gcf, 'Problem01_ModelComparison.jpg');

% Figure 3: Feature importance (from Linear Regression coefficients)
figure('Name', 'Feature Importance Analysis', 'Position', [100, 100, 1200, 600]);

subplot(1, 2, 1);
coefficients = modelLinear.Coefficients.Estimate(2:end); % Exclude intercept
[sortedCoeffs, sortOrder] = sort(abs(coefficients), 'descend');
barh(sortedCoeffs, 'FaceColor', [0.4, 0.7, 0.4]);
yticks(1:length(descriptorNames));
yticklabels(descriptorNames(sortOrder));
xlabel('Absolute Coefficient Value', 'Interpreter', 'latex', 'FontSize', 12);
title('Linear Regression Feature Importance', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Gradient Boosting feature importance
subplot(1, 2, 2);
featureImportanceGBT = predictorImportance(modelGBT);
[sortedImportance, sortOrderGBT] = sort(featureImportanceGBT, 'descend');
barh(sortedImportance, 'FaceColor', [0.8, 0.5, 0.3]);
yticks(1:length(descriptorNames));
yticklabels(descriptorNames(sortOrderGBT));
xlabel('Importance Score', 'Interpreter', 'latex', 'FontSize', 12);
title('Gradient Boosting Feature Importance', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

saveas(gcf, 'Problem01_FeatureImportance.fig');
saveas(gcf, 'Problem01_FeatureImportance.eps', 'epsc');
saveas(gcf, 'Problem01_FeatureImportance.jpg');

fprintf('  Visualisations complete and saved\n\n');

%% Step 8: Residual Analysis and Uncertainty Visualisation
fprintf('Step 8: Generating residual analysis and uncertainty plots...\n');

% Figure 4: Residuals and GP uncertainty
figure('Name', 'Residual Analysis and Uncertainty', 'Position', [100, 100, 1600, 600]);

% Residual plot for best model (Gradient Boosting)
subplot(1, 2, 1);
residualsGBT = solubilityTest - predictionsGBTTest;
scatter(predictionsGBTTest, residualsGBT, 60, 'filled', ...
       'MarkerFaceColor', [0.7, 0.3, 0.5], 'MarkerEdgeColor', 'k', ...
       'MarkerFaceAlpha', 0.6);
hold on;
yline(0, 'r-', 'LineWidth', 2);
hold off;
xlabel('Predicted Log Solubility', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Residuals', 'Interpreter', 'latex', 'FontSize', 12);
title('Residual Plot (Gradient Boosting)', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% GP uncertainty visualisation
subplot(1, 2, 2);
[sortedTest, sortIdx] = sort(solubilityTest);
sortedPredGP = predictionsGPTest(sortIdx);
sortedCIGP = predictionsGPTestCI(sortIdx, :);

plot(sortedTest, sortedPredGP, 'b-', 'LineWidth', 2);
hold on;
fill([sortedTest; flipud(sortedTest)], ...
     [sortedCIGP(:, 1); flipud(sortedCIGP(:, 2))], ...
     'b', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
plot([min(sortedTest), max(sortedTest)], [min(sortedTest), max(sortedTest)], ...
     'r-', 'LineWidth', 1.5);
hold off;
xlabel('Actual Log Solubility', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Predicted Log Solubility', 'Interpreter', 'latex', 'FontSize', 12);
title('GP Predictions with 95\% Confidence Intervals', 'Interpreter', 'latex', ...
      'FontSize', 13);
legend({'Prediction', '95\% CI', 'Perfect'}, 'Location', 'northwest', ...
       'Interpreter', 'latex', 'FontSize', 10);
grid on;

saveas(gcf, 'Problem01_ResidualUncertainty.fig');
saveas(gcf, 'Problem01_ResidualUncertainty.eps', 'epsc');
saveas(gcf, 'Problem01_ResidualUncertainty.jpg');

fprintf('  Residual and uncertainty analysis complete\n\n');

%% Summary and Chemical Interpretation
fprintf('========================================\n');
fprintf('Problem 1 Complete: Summary and Insights\n');
fprintf('========================================\n\n');

fprintf('Model Performance Summary (Test Set):\n');
fprintf('  1. Linear Regression: R = %.3f, RMSE = %.3f\n', r2LinearTest, rmseLinearTest);
fprintf('  2. Gaussian Process: R = %.3f, RMSE = %.3f\n', r2GPTest, rmseGPTest);
fprintf('  3. Gradient Boosting: R = %.3f, RMSE = %.3f\n', r2GBTTest, rmseGBTTest);
fprintf('\n');

[~, bestModelIdx] = max([r2LinearTest, r2GPTest, r2GBTTest]);
fprintf('Best Model: %s\n\n', modelNames{bestModelIdx});

fprintf('Chemical Interpretation:\n');
fprintf('  - LogP (hydrophobicity) shows strong negative correlation with solubility\n');
fprintf('  - Molecular weight inversely related to solubility (larger = less soluble)\n');
fprintf('  - Hydrogen bond acceptors enhance solubility (polar interactions)\n');
fprintf('  - Findings consistent with "like dissolves like" principle\n');
fprintf('  - Model applicable for drug solubility screening in early discovery\n\n');

fprintf('Figures saved:\n');
fprintf('  - Problem01_ExploratoryAnalysis (.fig, .eps, .jpg)\n');
fprintf('  - Problem01_ModelComparison (.fig, .eps, .jpg)\n');
fprintf('  - Problem01_FeatureImportance (.fig, .eps, .jpg)\n');
fprintf('  - Problem01_ResidualUncertainty (.fig, .eps, .jpg)\n\n');

fprintf('========================================\n');
