%% chapter_AI_Chemistry_Problem03_code.m
% Problem 3: Molecular Similarity Searching with Fingerprints
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Chemistry_Problem03_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Script: Problem 3 - Molecular Similarity Searching
% Chapter: AI in Chemistry Research and Education
% Author: Dr Yi Chen (IEEE Fellow, IET Fellow, IMechE Fellow)
% Affiliation: Newcastle University, United Kingdom
% Date: January 2025
% MATLAB Version: R2023b or later
% Required Toolboxes: Statistics and Machine Learning Toolbox,
%                     Bioinformatics Toolbox (optional for dendrogram)
% Description: Implement molecular fingerprint generation and similarity
%              searching for virtual screening applications
% Version Control: v1.0 - Initial implementation
%                  Tested on MATLAB R2023b, Windows 11 Pro, 16GB RAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialisation and Environment Setup
clear all; close all; clc;

fprintf('========================================\n');
fprintf('Problem 3: Molecular Similarity Searching\n');
fprintf('Fingerprint-Based Virtual Screening Pipeline\n');
fprintf('========================================\n\n');

% Set random seed for reproducibility
rng(2025, 'twister');

%% Step 1: Generate Molecular Library with Diverse Scaffolds
fprintf('Step 1: Generating molecular library with diverse scaffolds...\n');

numMolecules = 200;
fingerprintLength = 1024; % Standard ECFP fingerprint length
fingerprintRadius = 2; % ECFP4 (radius 2)

% Simulate molecular structures as graphs (adjacency matrices)
% Each molecule represented by: [numAtoms, atomTypes, bondMatrix, functionalGroups]
moleculeLibrary = cell(numMolecules, 1);
moleculeNames = cell(numMolecules, 1);
moleculeScaffolds = zeros(numMolecules, 1); % Scaffold type (1-10)

% Define 10 core scaffolds (simplified representations)
scaffoldTypes = {'Benzene', 'Naphthalene', 'Quinoline', 'Indole', ...
                'Pyridine', 'Piperidine', 'Morpholine', 'Thiophene', ...
                'Furan', 'Imidazole'};

% Atom types: C=1, N=2, O=3, S=4, F=5, Cl=6
for molIdx = 1:numMolecules
    scaffoldID = randi([1, 10]);
    moleculeScaffolds(molIdx) = scaffoldID;
    
    % Generate molecule based on scaffold
    numAtoms = 10 + randi([5, 20]); % 15-30 atoms
    atomTypes = ones(numAtoms, 1); % Start with all carbon
    
    % Add heteroatoms based on scaffold
    heteroatomPositions = randperm(numAtoms, min(5, numAtoms));
    atomTypes(heteroatomPositions(1:min(3, length(heteroatomPositions)))) = ...
        randi([2, 4], min(3, length(heteroatomPositions)), 1);
    
    % Generate connectivity (simplified - random sparse graph)
    bondMatrix = rand(numAtoms) < 0.15;
    bondMatrix = triu(bondMatrix, 1); % Upper triangular
    bondMatrix = bondMatrix + bondMatrix'; % Symmetric
    
    % Ensure connected graph
    bondMatrix(1, 2:min(3, numAtoms)) = 1;
    bondMatrix(2:min(3, numAtoms), 1) = 1;
    
    % Store molecule
    moleculeLibrary{molIdx} = struct('numAtoms', numAtoms, ...
                                    'atomTypes', atomTypes, ...
                                    'bondMatrix', bondMatrix, ...
                                    'scaffoldID', scaffoldID);
    moleculeNames{molIdx} = sprintf('Mol_%03d_%s', molIdx, scaffoldTypes{scaffoldID});
end

fprintf('  Generated %d molecules across %d scaffold types\n', ...
        numMolecules, length(unique(moleculeScaffolds)));
fprintf('  Molecules range from %d to %d atoms\n', ...
        min(cellfun(@(x) x.numAtoms, moleculeLibrary)), ...
        max(cellfun(@(x) x.numAtoms, moleculeLibrary)));
fprintf('\n');

%% Step 2: Generate Circular Fingerprints (ECFP-like)
fprintf('Step 2: Generating circular fingerprints (ECFP%d)...\n', fingerprintRadius*2);

fingerprintMatrix = zeros(numMolecules, fingerprintLength);

for molIdx = 1:numMolecules
    mol = moleculeLibrary{molIdx};
    fingerprint = generateCircularFingerprint(mol, fingerprintRadius, fingerprintLength);
    fingerprintMatrix(molIdx, :) = fingerprint;
end

% Calculate fingerprint density (percentage of bits set to 1)
fpDensity = sum(fingerprintMatrix, 2) / fingerprintLength * 100;

fprintf('  Fingerprints generated: %d molecules   %d bits\n', ...
        numMolecules, fingerprintLength);
fprintf('  Average fingerprint density: %.2f%% (%.0f bits set)\n', ...
        mean(fpDensity), mean(sum(fingerprintMatrix, 2)));
fprintf('  Density range: %.2f%% to %.2f%%\n', min(fpDensity), max(fpDensity));
fprintf('\n');

%% Step 3: Calculate Pairwise Tanimoto Similarity Matrix
fprintf('Step 3: Computing pairwise Tanimoto similarity matrix...\n');

tic;
similarityMatrix = zeros(numMolecules, numMolecules);

for idx1 = 1:numMolecules
    for idx2 = idx1:numMolecules
        fp1 = fingerprintMatrix(idx1, :);
        fp2 = fingerprintMatrix(idx2, :);
        
        % Tanimoto coefficient calculation
        intersection = sum(fp1 & fp2);
        union = sum(fp1 | fp2);
        
        if union > 0
            tanimoto = intersection / union;
        else
            tanimoto = 0;
        end
        
        similarityMatrix(idx1, idx2) = tanimoto;
        similarityMatrix(idx2, idx1) = tanimoto; % Symmetric
    end
end

computationTime = toc;

% Statistics on similarity distribution
offDiagonalSimilarities = similarityMatrix(triu(true(numMolecules), 1));

fprintf('  Similarity matrix computed in %.2f seconds\n', computationTime);
fprintf('  Average pairwise similarity: %.3f\n', mean(offDiagonalSimilarities));
fprintf('  Similarity range: %.3f to %.3f\n', ...
        min(offDiagonalSimilarities), max(offDiagonalSimilarities));
fprintf('  Median similarity: %.3f\n', median(offDiagonalSimilarities));
fprintf('\n');

%% Step 4: Similarity Heatmap Visualisation
fprintf('Step 4: Generating similarity heatmap and clustering...\n');

% Sort molecules by scaffold type for visualisation
[~, sortIdx] = sort(moleculeScaffolds);
sortedSimilarityMatrix = similarityMatrix(sortIdx, sortIdx);
sortedScaffolds = moleculeScaffolds(sortIdx);

figure('Name', 'Molecular Similarity Heatmap', 'Position', [100, 100, 1200, 1000]);

% Main heatmap
subplot('Position', [0.1, 0.15, 0.7, 0.75]);
imagesc(sortedSimilarityMatrix);
colormap('hot');
colorbar('Position', [0.82, 0.15, 0.03, 0.75]);
caxis([0, 1]);
xlabel('Molecule Index (Sorted by Scaffold)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Molecule Index (Sorted by Scaffold)', 'Interpreter', 'latex', 'FontSize', 12);
title('Tanimoto Similarity Matrix', 'Interpreter', 'latex', 'FontSize', 14);
axis square;

% Scaffold colour bar on side
subplot('Position', [0.87, 0.15, 0.03, 0.75]);
imagesc(sortedScaffolds');
colormap(gca, 'jet');
yticks([]);
xticks([]);
ylabel('Scaffold Type', 'Interpreter', 'latex', 'FontSize', 11);
caxis([1, 10]);

% Similarity distribution histogram
subplot('Position', [0.1, 0.05, 0.7, 0.08]);
histogram(offDiagonalSimilarities, 50, 'FaceColor', [0.3, 0.6, 0.9], ...
         'EdgeColor', 'k', 'Normalization', 'probability');
xlabel('Tanimoto Similarity', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Probability', 'Interpreter', 'latex', 'FontSize', 11);
title('Similarity Distribution', 'Interpreter', 'latex', 'FontSize', 12);
grid on;
xlim([0, 1]);

saveas(gcf, 'Problem03_SimilarityHeatmap.fig');
saveas(gcf, 'Problem03_SimilarityHeatmap.eps', 'epsc');
saveas(gcf, 'Problem03_SimilarityHeatmap.jpg');

fprintf('  Heatmap visualisation complete and saved\n\n');

%% Step 5: Hierarchical Clustering Analysis
fprintf('Step 5: Performing hierarchical clustering...\n');

% Convert similarity to distance (dissimilarity)
distanceMatrix = 1 - similarityMatrix;
distanceVector = squareform(distanceMatrix, 'tovector');

% Hierarchical clustering
linkageTree = linkage(distanceVector, 'average');

% Generate dendrogram
figure('Name', 'Molecular Similarity Dendrogram', 'Position', [100, 100, 1600, 800]);

subplot(1, 2, 1);
dendrogram(linkageTree, 0, 'ColorThreshold', 0.5);
xlabel('Molecule Index', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Distance (1 - Tanimoto)', 'Interpreter', 'latex', 'FontSize', 12);
title('Hierarchical Clustering Dendrogram', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Cluster assignments at threshold
distanceThreshold = 0.5;
clusterAssignments = cluster(linkageTree, 'Cutoff', distanceThreshold, 'Criterion', 'distance');
numClusters = max(clusterAssignments);

fprintf('  Hierarchical clustering complete\n');
fprintf('  Number of clusters (distance threshold %.2f): %d\n', ...
        distanceThreshold, numClusters);

% Cluster size distribution
subplot(1, 2, 2);
clusterSizes = histcounts(clusterAssignments, 1:(numClusters+1));
bar(1:numClusters, clusterSizes, 'FaceColor', [0.4, 0.7, 0.4], 'EdgeColor', 'k');
xlabel('Cluster ID', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Number of Molecules', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Cluster Size Distribution (%d Clusters)', numClusters), ...
      'Interpreter', 'latex', 'FontSize', 13);
grid on;

saveas(gcf, 'Problem03_ClusteringAnalysis.fig');
saveas(gcf, 'Problem03_ClusteringAnalysis.eps', 'epsc');
saveas(gcf, 'Problem03_ClusteringAnalysis.jpg');

fprintf('  Clustering analysis complete\n\n');

%% Step 6: Similarity Search - Query Molecule Retrieval
fprintf('Step 6: Performing similarity search for query molecules...\n');

% Select 3 random query molecules
numQueries = 3;
queryIndices = randperm(numMolecules, numQueries);
topK = 10; % Retrieve top 10 most similar

figure('Name', 'Similarity Search Results', 'Position', [100, 100, 1600, 1000]);

for queryIdx = 1:numQueries
    queryMoleculeID = queryIndices(queryIdx);
    querySimilarities = similarityMatrix(queryMoleculeID, :);
    
    % Sort by similarity (descending)
    [sortedSimilarities, sortedIndices] = sort(querySimilarities, 'descend');
    
    % Exclude query itself (similarity = 1)
    topKIndices = sortedIndices(2:(topK+1));
    topKSimilarities = sortedSimilarities(2:(topK+1));
    
    fprintf('  Query %d: %s (Scaffold: %s)\n', queryIdx, ...
            moleculeNames{queryMoleculeID}, scaffoldTypes{moleculeScaffolds(queryMoleculeID)});
    fprintf('    Top %d similar molecules:\n', topK);
    for rank = 1:5 % Print top 5
        fprintf('      %d. %s (Tanimoto: %.3f, Scaffold: %s)\n', rank, ...
                moleculeNames{topKIndices(rank)}, topKSimilarities(rank), ...
                scaffoldTypes{moleculeScaffolds(topKIndices(rank))});
    end
    fprintf('\n');
    
    % Visualisation
    subplot(2, numQueries, queryIdx);
    bar(1:topK, topKSimilarities, 'FaceColor', [0.2, 0.4, 0.8], 'EdgeColor', 'k');
    xlabel('Rank', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Tanimoto Similarity', 'Interpreter', 'latex', 'FontSize', 11);
    title(sprintf('Query %d: %s', queryIdx, ...
                 strrep(moleculeNames{queryMoleculeID}, '_', '\_')), ...
          'Interpreter', 'latex', 'FontSize', 12);
    ylim([0, 1]);
    grid on;
    
    % Scaffold distribution in top K
    subplot(2, numQueries, numQueries + queryIdx);
    topKScaffolds = moleculeScaffolds(topKIndices);
    scaffoldCounts = histcounts(topKScaffolds, 0.5:10.5);
    bar(1:10, scaffoldCounts, 'FaceColor', [0.9, 0.5, 0.3], 'EdgeColor', 'k');
    xlabel('Scaffold Type', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Count in Top 10', 'Interpreter', 'latex', 'FontSize', 11);
    title('Scaffold Diversity in Results', 'Interpreter', 'latex', 'FontSize', 12);
    xticks(1:10);
    xticklabels(scaffoldTypes);
    xtickangle(45);
    grid on;
end

saveas(gcf, 'Problem03_SimilaritySearch.fig');
saveas(gcf, 'Problem03_SimilaritySearch.eps', 'epsc');
saveas(gcf, 'Problem03_SimilaritySearch.jpg');

fprintf('  Similarity search visualisations complete\n\n');

%% Step 7: Dimensionality Reduction - Chemical Space Visualisation
fprintf('Step 7: Visualising chemical space via dimensionality reduction...\n');

% Principal Component Analysis
[coeff, score, ~, ~, explained] = pca(fingerprintMatrix);

fprintf('  PCA complete: First 3 PCs explain %.2f%% variance\n', sum(explained(1:3)));

% t-SNE for non-linear projection
tsneCoords = tsne(fingerprintMatrix, 'NumDimensions', 2, 'Perplexity', 30, 'Verbose', 0);

fprintf('  t-SNE embedding computed\n');

% Visualisation
figure('Name', 'Chemical Space Projection', 'Position', [100, 100, 1600, 700]);

% PCA projection
subplot(1, 2, 1);
scatter3(score(:, 1), score(:, 2), score(:, 3), 50, moleculeScaffolds, 'filled', ...
        'MarkerEdgeColor', 'k', 'MarkerFaceAlpha', 0.7);
colormap('jet');
colorbar('Ticks', 1:10, 'TickLabels', scaffoldTypes, 'FontSize', 9);
xlabel(sprintf('PC1 (%.1f\\%% var)', explained(1)), 'Interpreter', 'latex', 'FontSize', 11);
ylabel(sprintf('PC2 (%.1f\\%% var)', explained(2)), 'Interpreter', 'latex', 'FontSize', 11);
zlabel(sprintf('PC3 (%.1f\\%% var)', explained(3)), 'Interpreter', 'latex', 'FontSize', 11);
title('PCA Projection of Chemical Space', 'Interpreter', 'latex', 'FontSize', 13);
grid on;
view(45, 30);

% t-SNE projection
subplot(1, 2, 2);
scatter(tsneCoords(:, 1), tsneCoords(:, 2), 60, moleculeScaffolds, 'filled', ...
       'MarkerEdgeColor', 'k', 'MarkerFaceAlpha', 0.7);
colormap('jet');
colorbar('Ticks', 1:10, 'TickLabels', scaffoldTypes, 'FontSize', 9);
xlabel('t-SNE Dimension 1', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('t-SNE Dimension 2', 'Interpreter', 'latex', 'FontSize', 11);
title('t-SNE Projection of Chemical Space', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

saveas(gcf, 'Problem03_ChemicalSpaceProjection.fig');
saveas(gcf, 'Problem03_ChemicalSpaceProjection.eps', 'epsc');
saveas(gcf, 'Problem03_ChemicalSpaceProjection.jpg');

fprintf('  Chemical space visualisations complete\n\n');

%% Step 8: Activity Cliff Analysis (Simulated Bioactivity)
fprintf('Step 8: Detecting activity cliffs (simulated bioactivity data)...\n');

% Simulate bioactivity (pIC50) with some correlation to structure
% but including deliberate activity cliffs
bioactivity = 5 + 3 * rand(numMolecules, 1); % Random baseline 5-8 pIC50

% Create activity cliffs: similar molecules with very different activity
numActivityCliffs = 10;
for cliffIdx = 1:numActivityCliffs
    % Select a pair with high similarity
    highSimPairs = find(triu(similarityMatrix > 0.7, 1));
    if ~isempty(highSimPairs)
        pairIdx = highSimPairs(randi(length(highSimPairs)));
        [mol1, mol2] = ind2sub([numMolecules, numMolecules], pairIdx);
        
        % Make their activities divergent
        bioactivity(mol1) = 8 + rand();
        bioactivity(mol2) = 4 + rand();
    end
end

fprintf('  Simulated bioactivity data (pIC50 values)\n');
fprintf('  Activity range: %.2f to %.2f\n', min(bioactivity), max(bioactivity));

% Detect activity cliffs
activityCliffs = [];
similarityThreshold = 0.7;
activityDifferenceThreshold = 2.0;

for idx1 = 1:numMolecules
    for idx2 = (idx1+1):numMolecules
        if similarityMatrix(idx1, idx2) > similarityThreshold && ...
           abs(bioactivity(idx1) - bioactivity(idx2)) > activityDifferenceThreshold
            activityCliffs = [activityCliffs; idx1, idx2, ...
                            similarityMatrix(idx1, idx2), ...
                            abs(bioactivity(idx1) - bioactivity(idx2))];
        end
    end
end

fprintf('  Detected %d activity cliffs (Similarity > %.2f,  pIC50 > %.1f)\n', ...
        size(activityCliffs, 1), similarityThreshold, activityDifferenceThreshold);

% Visualisation
figure('Name', 'Activity Cliff Analysis', 'Position', [100, 100, 1400, 600]);

subplot(1, 2, 1);
scatter(offDiagonalSimilarities, pdist(bioactivity'), 30, 'filled', ...
       'MarkerFaceColor', [0.3, 0.3, 0.3], 'MarkerFaceAlpha', 0.3);
hold on;
if ~isempty(activityCliffs)
    scatter(activityCliffs(:, 3), activityCliffs(:, 4), 120, 'r', 'filled', ...
           'MarkerEdgeColor', 'k', 'LineWidth', 1.5);
end
hold off;
xlabel('Tanimoto Similarity', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$\Delta$pIC50 (Activity Difference)', 'Interpreter', 'latex', 'FontSize', 12);
title('Activity Landscape', 'Interpreter', 'latex', 'FontSize', 13);
legend({'All Pairs', 'Activity Cliffs'}, 'Location', 'northeast', ...
       'Interpreter', 'latex', 'FontSize', 11);
grid on;

subplot(1, 2, 2);
scatter(score(:, 1), score(:, 2), 60, bioactivity, 'filled', ...
       'MarkerEdgeColor', 'k', 'MarkerFaceAlpha', 0.7);
colormap('jet');
colorbar;
xlabel(sprintf('PC1 (%.1f\\%% var)', explained(1)), 'Interpreter', 'latex', 'FontSize', 11);
ylabel(sprintf('PC2 (%.1f\\%% var)', explained(2)), 'Interpreter', 'latex', 'FontSize', 11);
title('Bioactivity in Chemical Space', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

saveas(gcf, 'Problem03_ActivityCliffs.fig');
saveas(gcf, 'Problem03_ActivityCliffs.eps', 'epsc');
saveas(gcf, 'Problem03_ActivityCliffs.jpg');

fprintf('  Activity cliff analysis complete\n\n');

%% Step 9: Diversity Selection for Library Design
fprintf('Step 9: Performing diversity selection using MaxMin algorithm...\n');

% MaxMin diversity selection: iteratively select most dissimilar molecules
numDiverseSelected = 20;
selectedIndices = zeros(numDiverseSelected, 1);

% Start with random molecule
selectedIndices(1) = randi(numMolecules);

for selectIdx = 2:numDiverseSelected
    % For each unselected molecule, find minimum similarity to selected set
    minSimilarities = ones(numMolecules, 1);
    for molIdx = 1:numMolecules
        if ~ismember(molIdx, selectedIndices(1:selectIdx-1))
            minSimilarities(molIdx) = min(similarityMatrix(molIdx, selectedIndices(1:selectIdx-1)));
        else
            minSimilarities(molIdx) = -1; % Already selected
        end
    end
    
    % Select molecule with maximum of these minimum similarities
    [~, nextSelection] = max(minSimilarities);
    selectedIndices(selectIdx) = nextSelection;
end

fprintf('  Selected %d diverse molecules using MaxMin algorithm\n', numDiverseSelected);
fprintf('  Scaffold coverage: %d/%d scaffold types represented\n', ...
        length(unique(moleculeScaffolds(selectedIndices))), length(scaffoldTypes));

% Analyse diversity improvement
selectedSimilarityMatrix = similarityMatrix(selectedIndices, selectedIndices);
selectedPairwiseSim = selectedSimilarityMatrix(triu(true(numDiverseSelected), 1));

fprintf('  Average pairwise similarity in diverse set: %.3f\n', mean(selectedPairwiseSim));
fprintf('  Compared to random selection baseline: %.3f\n', mean(offDiagonalSimilarities));
fprintf('\n');

% Visualisation
figure('Name', 'Diversity Selection Analysis', 'Position', [100, 100, 1400, 600]);

subplot(1, 2, 1);
histogram(offDiagonalSimilarities, 30, 'FaceColor', [0.7, 0.7, 0.7], ...
         'EdgeColor', 'k', 'Normalization', 'probability');
hold on;
histogram(selectedPairwiseSim, 30, 'FaceColor', [0.9, 0.3, 0.3], ...
         'EdgeColor', 'k', 'Normalization', 'probability', 'FaceAlpha', 0.7);
hold off;
xlabel('Tanimoto Similarity', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Probability', 'Interpreter', 'latex', 'FontSize', 12);
title('Similarity Distribution: Full Library vs. Diverse Subset', ...
      'Interpreter', 'latex', 'FontSize', 13);
legend({'Full Library', 'Diverse Subset'}, 'Location', 'northwest', ...
       'Interpreter', 'latex', 'FontSize', 11);
grid on;

subplot(1, 2, 2);
scatter(tsneCoords(:, 1), tsneCoords(:, 2), 30, [0.8, 0.8, 0.8], 'filled', ...
       'MarkerEdgeColor', 'none', 'MarkerFaceAlpha', 0.3);
hold on;
scatter(tsneCoords(selectedIndices, 1), tsneCoords(selectedIndices, 2), ...
       120, moleculeScaffolds(selectedIndices), 'filled', ...
       'MarkerEdgeColor', 'k', 'LineWidth', 2);
hold off;
colormap('jet');
colorbar('Ticks', 1:10, 'TickLabels', scaffoldTypes, 'FontSize', 8);
xlabel('t-SNE Dimension 1', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('t-SNE Dimension 2', 'Interpreter', 'latex', 'FontSize', 11);
title('Diverse Subset in Chemical Space', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

saveas(gcf, 'Problem03_DiversitySelection.fig');
saveas(gcf, 'Problem03_DiversitySelection.eps', 'epsc');
saveas(gcf, 'Problem03_DiversitySelection.jpg');

fprintf('  Diversity selection analysis complete\n\n');

%% Summary and Chemical Interpretation
fprintf('========================================\n');
fprintf('Problem 3 Complete: Summary and Insights\n');
fprintf('========================================\n\n');

fprintf('Library Statistics:\n');
fprintf('  Total molecules: %d\n', numMolecules);
fprintf('  Scaffold types: %d\n', length(scaffoldTypes));
fprintf('  Average pairwise similarity: %.3f\n', mean(offDiagonalSimilarities));
fprintf('  Similarity range: %.3f to %.3f\n', ...
        min(offDiagonalSimilarities), max(offDiagonalSimilarities));
fprintf('\n');

fprintf('Clustering Results:\n');
fprintf('  Number of clusters (threshold %.2f): %d\n', distanceThreshold, numClusters);
fprintf('  Largest cluster size: %d molecules\n', max(clusterSizes));
fprintf('  Singleton clusters: %d\n', sum(clusterSizes == 1));
fprintf('\n');

fprintf('Activity Cliff Detection:\n');
fprintf('  Total activity cliffs identified: %d\n', size(activityCliffs, 1));
fprintf('  These represent SAR discontinuities requiring investigation\n');
fprintf('\n');

fprintf('Diversity Selection:\n');
fprintf('  Diverse subset size: %d molecules\n', numDiverseSelected);
fprintf('  Average similarity reduction: %.3f   %.3f\n', ...
        mean(offDiagonalSimilarities), mean(selectedPairwiseSim));
fprintf('  Scaffold coverage: %d/%d types\n', ...
        length(unique(moleculeScaffolds(selectedIndices))), length(scaffoldTypes));
fprintf('\n');

fprintf('Chemical Insights:\n');
fprintf('  - Fingerprint-based similarity enables rapid virtual screening\n');
fprintf('  - Activity cliffs highlight importance of subtle structural changes\n');
fprintf('  - Diversity selection ensures efficient chemical space coverage\n');
fprintf('  - t-SNE reveals non-linear relationships in molecular space\n');
fprintf('  - Applications: lead optimisation, library design, patent searching\n\n');

fprintf('Figures saved:\n');
fprintf('  - Problem03_SimilarityHeatmap (.fig, .eps, .jpg)\n');
fprintf('  - Problem03_ClusteringAnalysis (.fig, .eps, .jpg)\n');
fprintf('  - Problem03_SimilaritySearch (.fig, .eps, .jpg)\n');
fprintf('  - Problem03_ChemicalSpaceProjection (.fig, .eps, .jpg)\n');
fprintf('  - Problem03_ActivityCliffs (.fig, .eps, .jpg)\n');
fprintf('  - Problem03_DiversitySelection (.fig, .eps, .jpg)\n\n');

fprintf('========================================\n');

%% Helper Function: Generate Circular Fingerprint
function fingerprint = generateCircularFingerprint(molecule, radius, fpLength)
    % Simplified ECFP-like circular fingerprint generation
    % In reality, uses sophisticated hashing of atom environments
    
    numAtoms = molecule.numAtoms;
    atomTypes = molecule.atomTypes;
    bondMatrix = molecule.bondMatrix;
    
    fingerprint = zeros(1, fpLength);
    
    % For each atom, generate environment at each radius
    for atomIdx = 1:numAtoms
        for r = 0:radius
            % Get atoms within radius r (simplified BFS)
            if r == 0
                environment = atomIdx;
            else
                % Find neighbours up to radius r
                connectedAtoms = find(bondMatrix(atomIdx, :));
                environment = unique([atomIdx, connectedAtoms]);
            end
            
            % Hash environment to bit position
            % Simple hash: sum of atom types weighted by connectivity
            hashValue = sum(atomTypes(environment) .* (1:length(environment))');
            bitPosition = mod(hashValue, fpLength) + 1;
            
            fingerprint(bitPosition) = 1;
            
            % Add additional bits based on environment features
            if r > 0 && ~isempty(connectedAtoms)
                for neighbourIdx = connectedAtoms
                    hashValue2 = atomTypes(atomIdx) * 100 + atomTypes(neighbourIdx) * r;
                    bitPosition2 = mod(hashValue2, fpLength) + 1;
                    fingerprint(bitPosition2) = 1;
                end
            end
        end
    end
end
