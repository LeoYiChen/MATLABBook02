%% prob4_complete.m
% Problem 4: Batch Size Impact Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob4_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 4: Batch Size Impact on Training Dynamics
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Analyses the impact of batch size on training throughput,
%              convergence speed, and generalisation performance
%
% Revision History:
%   v1.0 (15-Jan-2025): Initial implementation with visualisation
%   v1.1 (15-Jan-2025): Added linear scaling rule analysis

%% Initialisation
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 4: Batch Size Impact on Training Dynamics\n');
fprintf('================================================================\n\n');

%% Empirical Training Data
batchSizes = [32, 64, 128, 256, 512];
timePerIteration_sec = [0.15, 0.25, 0.40, 0.70, 1.20];
iterationsTo80Accuracy = [8000, 6500, 4000, 2800, 2000];
finalTestAccuracy = [82.5, 82.3, 81.8, 80.9, 79.2];

% Dataset and baseline configuration
totalTrainingSamples = 50000;  % CIFAR-10 or similar
baselineLearningRate = 0.001;
baselineBatchSize = 32;

fprintf('Empirical Training Configuration:\n');
fprintf('  Dataset size: %d samples\n', totalTrainingSamples);
fprintf('  Baseline learning rate: %.4f (for batch size %d)\n', ...
        baselineLearningRate, baselineBatchSize);
fprintf('  Target validation accuracy: 80%%\n');
fprintf('  Number of batch sizes tested: %d\n\n', length(batchSizes));

%% Part (a): Calculate Throughput (Samples per Second)

samplesPerSecond = batchSizes ./ timePerIteration_sec;

fprintf('========================================\n');
fprintf('(a) Training Throughput Analysis\n');
fprintf('========================================\n');
fprintf('%-12s %-18s %-22s %-20s\n', 'Batch Size', 'Time/Iter (sec)', ...
        'Samples/Second', 'Speedup vs B=32');
fprintf('%s\n', repmat('-', 1, 75));

for i = 1:length(batchSizes)
    speedup = samplesPerSecond(i) / samplesPerSecond(1);
    fprintf('%-12d %-18.2f %-22.1f %-20.2fx\n', ...
            batchSizes(i), timePerIteration_sec(i), ...
            samplesPerSecond(i), speedup);
end
fprintf('\n');

%% Part (b): Total Training Time to Reach 80%% Accuracy

totalTrainingTime_sec = iterationsTo80Accuracy .* timePerIteration_sec;
totalTrainingTime_min = totalTrainingTime_sec / 60;

% Calculate total samples processed
totalSamplesProcessed = iterationsTo80Accuracy .* batchSizes;

fprintf('========================================\n');
fprintf('(b) Training Time to 80%% Validation Accuracy\n');
fprintf('========================================\n');
fprintf('%-12s %-18s %-20s %-22s\n', 'Batch Size', 'Iterations', ...
        'Training Time (min)', 'Total Samples');
fprintf('%s\n', repmat('-', 1, 75));

for i = 1:length(batchSizes)
    fprintf('%-12d %-18d %-20.2f %-22.2e\n', ...
            batchSizes(i), iterationsTo80Accuracy(i), ...
            totalTrainingTime_min(i), totalSamplesProcessed(i));
end
fprintf('\n');

% Identify optimal batch size (minimum training time)
[minTime, optimalIdx] = min(totalTrainingTime_min);
optimalBatchSize = batchSizes(optimalIdx);

fprintf('OPTIMAL CONFIGURATION:\n');
fprintf('  Batch size: %d\n', optimalBatchSize);
fprintf('  Training time: %.2f minutes\n', minTime);
fprintf('  Iterations required: %d\n', iterationsTo80Accuracy(optimalIdx));
fprintf('  Final test accuracy: %.1f%%\n\n', finalTestAccuracy(optimalIdx));

%% Part (c): Computational Efficiency Analysis

% Efficiency relative to optimal configuration
minSamplesProcessed = min(totalSamplesProcessed);
computationalEfficiency = (minSamplesProcessed ./ totalSamplesProcessed) * 100;

fprintf('========================================\n');
fprintf('(c) Computational Efficiency\n');
fprintf('========================================\n');
fprintf('%-12s %-22s %-25s %-20s\n', 'Batch Size', 'Total Samples', ...
        'Efficiency (%%)', 'Waste Factor');
fprintf('%s\n', repmat('-', 1, 82));

for i = 1:length(batchSizes)
    wasteFactor = totalSamplesProcessed(i) / minSamplesProcessed;
    fprintf('%-12d %-22.2e %-25.1f %-20.2fx\n', ...
            batchSizes(i), totalSamplesProcessed(i), ...
            computationalEfficiency(i), wasteFactor);
end
fprintf('\n');

fprintf('INSIGHT: Batch size %d requires %.2fx more samples than optimal\n', ...
        batchSizes(1), totalSamplesProcessed(1) / minSamplesProcessed);
fprintf('         to reach the same validation accuracy.\n\n');

%% Part (d): Generalisation Gap Analysis

bestTestAccuracy = max(finalTestAccuracy);
generalisationGap = bestTestAccuracy - finalTestAccuracy;

fprintf('========================================\n');
fprintf('(d) Generalisation Performance\n');
fprintf('========================================\n');
fprintf('%-12s %-22s %-25s\n', 'Batch Size', 'Test Accuracy (%%)', ...
        'Generalisation Gap');
fprintf('%s\n', repmat('-', 1, 62));

for i = 1:length(batchSizes)
    fprintf('%-12d %-22.2f %-25.2f%%\n', ...
            batchSizes(i), finalTestAccuracy(i), generalisationGap(i));
end
fprintf('\n');

fprintf('OBSERVATION: Increasing batch size from %d to %d results in:\n', ...
        batchSizes(1), batchSizes(end));
fprintf('  - Test accuracy drop: %.1f%%   %.1f%% (%.1f%% degradation)\n', ...
        finalTestAccuracy(1), finalTestAccuracy(end), ...
        finalTestAccuracy(1) - finalTestAccuracy(end));
fprintf('  - Generalisation gap increase: %.1f%%\n\n', ...
        generalisationGap(end));

%% Part (e): Linear Scaling Rule Application

scaledLearningRates = baselineLearningRate * (batchSizes / baselineBatchSize);

fprintf('========================================\n');
fprintf('(e) Linear Scaling Rule for Learning Rate\n');
fprintf('========================================\n');
fprintf('Formula: lr_new = lr_base   (B_new / B_base)\n');
fprintf('Base configuration: lr = %.4f, B = %d\n\n', ...
        baselineLearningRate, baselineBatchSize);

fprintf('%-12s %-18s %-22s\n', 'Batch Size', 'Scaled LR', 'Scaling Factor');
fprintf('%s\n', repmat('-', 1, 55));

for i = 1:length(batchSizes)
    scalingFactor = batchSizes(i) / baselineBatchSize;
    fprintf('%-12d %-18.4f %-22.2fx\n', ...
            batchSizes(i), scaledLearningRates(i), scalingFactor);
end
fprintf('\n');

fprintf('RECOMMENDATION for B=%d:\n', batchSizes(end));
fprintf('  Scaled learning rate: %.4f\n', scaledLearningRates(end));
fprintf('  May require warmup: %d iterations\n', ...
        round(iterationsTo80Accuracy(end) * 0.05));
fprintf('  Suggested warmup schedule: Linear from %.4f to %.4f\n\n', ...
        baselineLearningRate, scaledLearningRates(end));

%% Visualisation: Four-Panel Analysis

figure('Position', [50, 50, 1600, 900], 'Color', 'w');

% Panel 1: Throughput vs Batch Size
subplot(2, 2, 1);
yyaxis left
bar(batchSizes, samplesPerSecond, 'FaceColor', [0.2, 0.6, 0.8], ...
    'EdgeColor', 'k', 'LineWidth', 1.5);
ylabel('Samples per Second', 'Interpreter', 'latex', 'FontSize', 13);
ylim([0, max(samplesPerSecond) * 1.2]);

yyaxis right
plot(batchSizes, timePerIteration_sec, 'r-o', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'MarkerFaceColor', 'r');
ylabel('Time per Iteration (sec)', 'Interpreter', 'latex', 'FontSize', 13);

xlabel('Batch Size', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(a) Training Throughput}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12, 'XScale', 'log', 'XTick', batchSizes);
legend({'Throughput', 'Time/Iteration'}, 'Interpreter', 'latex', ...
       'Location', 'northwest', 'FontSize', 11);

% Panel 2: Training Time vs Batch Size
subplot(2, 2, 2);
plot(batchSizes, totalTrainingTime_min, 'b-o', 'LineWidth', 2.5, ...
     'MarkerSize', 12, 'MarkerFaceColor', 'b');
hold on;
plot(optimalBatchSize, minTime, 'r*', 'MarkerSize', 20, 'LineWidth', 3);

xlabel('Batch Size', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Training Time to 80\% Accuracy (min)', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(b) Convergence Time}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12, 'XScale', 'log', 'XTick', batchSizes);
legend({'Training Time', sprintf('Optimal: B=%d', optimalBatchSize)}, ...
       'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 11);

% Panel 3: Computational Efficiency
subplot(2, 2, 3);
bar(batchSizes, computationalEfficiency, 'FaceColor', [0.3, 0.7, 0.3], ...
    'EdgeColor', 'k', 'LineWidth', 1.5);
hold on;
yline(100, 'r-', 'LineWidth', 2, 'Label', 'Perfect Efficiency', ...
      'Interpreter', 'latex', 'FontSize', 11);

xlabel('Batch Size', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Computational Efficiency (\%)', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(c) Sample Efficiency}', 'Interpreter', 'latex', ...
      'FontSize', 15);
ylim([0, 110]);
grid on; box on;
set(gca, 'FontSize', 12, 'XScale', 'log', 'XTick', batchSizes);

% Panel 4: Generalisation Performance
subplot(2, 2, 4);
yyaxis left
plot(batchSizes, finalTestAccuracy, 'b-o', 'LineWidth', 2.5, ...
     'MarkerSize', 12, 'MarkerFaceColor', 'b');
ylabel('Test Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
ylim([78, 83]);

yyaxis right
plot(batchSizes, generalisationGap, 'r-s', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'MarkerFaceColor', 'r');
ylabel('Generalisation Gap (\%)', 'Interpreter', 'latex', 'FontSize', 13);
ylim([0, max(generalisationGap) * 1.3]);

xlabel('Batch Size', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(d) Generalisation Trade-off}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12, 'XScale', 'log', 'XTick', batchSizes);
legend({'Test Accuracy', 'Gen. Gap'}, 'Interpreter', 'latex', ...
       'Location', 'east', 'FontSize', 11);

%% Summary Statistics and Recommendations

fprintf('========================================\n');
fprintf('COMPREHENSIVE SUMMARY\n');
fprintf('========================================\n\n');

fprintf('PERFORMANCE METRICS:\n');
fprintf('  Fastest convergence: B=%d (%.1f min)\n', ...
        optimalBatchSize, minTime);
fprintf('  Highest throughput: B=%d (%.1f samples/sec)\n', ...
        batchSizes(end), samplesPerSecond(end));
fprintf('  Best test accuracy: B=%d (%.1f%%)\n', ...
        batchSizes(1), finalTestAccuracy(1));
fprintf('  Most efficient: B=%d (100%% sample efficiency)\n\n', ...
        batchSizes(optimalIdx));

fprintf('TRADE-OFF ANALYSIS:\n');
fprintf('  B=%d: Fast training (%.1f min) but poor accuracy (%.1f%%)\n', ...
        batchSizes(end), totalTrainingTime_min(end), finalTestAccuracy(end));
fprintf('  B=%d: Best accuracy (%.1f%%) but slow training (%.1f min)\n', ...
        batchSizes(1), finalTestAccuracy(1), totalTrainingTime_min(1));
fprintf('  B=%d: BALANCED - Good speed (%.1f min) + accuracy (%.1f%%)\n\n', ...
        optimalBatchSize, minTime, finalTestAccuracy(optimalIdx));

fprintf('RECOMMENDATIONS:\n');
fprintf('  1. For PRODUCTION (accuracy priority): Use B=%d\n', batchSizes(1));
fprintf('     - Apply learning rate: %.4f\n', scaledLearningRates(1));
fprintf('     - Expected accuracy: %.1f%%\n', finalTestAccuracy(1));
fprintf('\n');
fprintf('  2. For RESEARCH (speed priority): Use B=%d\n', optimalBatchSize);
fprintf('     - Apply learning rate: %.4f\n', ...
        scaledLearningRates(optimalIdx));
fprintf('     - Expected time: %.1f min (%.1fx faster)\n', ...
        minTime, totalTrainingTime_min(1) / minTime);
fprintf('\n');
fprintf('  3. For DISTRIBUTED (multi-GPU): Scale to B=%d\n', ...
        batchSizes(end));
fprintf('     - Use warmup: Linear LR schedule for first 5%% iterations\n');
fprintf('     - Monitor generalisation gap carefully\n');
fprintf('     - Consider gradient accumulation if accuracy drops\n\n');
