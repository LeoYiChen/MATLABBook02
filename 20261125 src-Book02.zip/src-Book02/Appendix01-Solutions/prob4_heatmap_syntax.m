%% prob4_heatmap_syntax.m
% Heat map generation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob4_heatmap_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Compute correlation matrix
correlationMatrix = corr(data);
% Create heat map
imagesc(correlationMatrix);
colorbar;
colormap(jet);
% Add axis labels
set(gca, 'XTick', 1:n, 'XTickLabel', labels);
set(gca, 'YTick', 1:n, 'YTickLabel', labels);
