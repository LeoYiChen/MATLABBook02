%% chapter_Math_example_elementary.m
% Elementary mathematical functions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_elementary
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Trigonometric functions
x = pi/4;
y1 = sin(x);          % Sine
y2 = cos(x);          % Cosine
y3 = tan(x);          % Tangent
y4 = asin(0.5);       % Arcsine (inverse sine)
y5 = atan2(1, 1);     % Four-quadrant arctangent

% Hyperbolic functions
y6 = sinh(x);         % Hyperbolic sine
y7 = cosh(x);         % Hyperbolic cosine
y8 = tanh(x);         % Hyperbolic tangent

% Exponential and logarithmic functions
y9 = exp(x);          % Natural exponential e^x
y10 = log(x);         % Natural logarithm ln(x)
y11 = log10(x);       % Base-10 logarithm
y12 = log2(x);        % Base-2 logarithm
y13 = sqrt(x);        % Square root
y14 = nthroot(8, 3);  % Cube root (and nth root generally)

% Power and root functions
y15 = x^2;            % Power (scalar)
y16 = x.^2;           % Element-wise power (array)
y17 = abs(-5);        % Absolute value
y18 = sign(-3.7);     % Sign function

% Rounding functions
y19 = round(3.7);     % Round to nearest integer
y20 = floor(3.7);     % Round towardss negative infinity
y21 = ceil(3.2);      % Round towardss positive infinity
y22 = fix(3.7);       % Round towardss zero

% Complex number functions
z = 3 + 4*i;
y23 = abs(z);         % Magnitude
y24 = angle(z);       % Phase angle
y25 = real(z);        % Real part
y26 = imag(z);        % Imaginary part
y27 = conj(z);        % Complex conjugate
