%% problem9_code.m
% Certified Adversarial Robustness for Power System Security
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem9_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Certified Adversarial Robustness for Power System Security Assessment
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-17
% Description: Implements randomised smoothing for certified robustness
%              guarantees in power system security classification

clear; close all; clc;

%% 1. Synthetic Power System Operating State Dataset
fprintf('========================================\n');
fprintf('Certified Adversarial Robustness - Power System Security\n');
fprintf('========================================\n\n');

fprintf('Step 1: Generating synthetic power system operating states...\n');

rng(258); % Reproducibility

numSamples = 500;
numBuses = 10; % Simplified power system
numFeatures = numBuses + 5; % Bus voltages + aggregate features

% Generate operating states
% Features: [bus voltages (10), total generation, total load, reserve margin, 
%            voltage stability margin, frequency]

operatingStates = zeros(numSamples, numFeatures);

for sampleIdx = 1:numSamples
    % Bus voltages (per unit): nominal 1.0   variation
    busVoltages = 1.0 + 0.1 * randn(1, numBuses);
    busVoltages = max(min(busVoltages, 1.1), 0.9); % Constraint: [0.9, 1.1] pu
    
    % Total generation (MW)
    totalGeneration = 1000 + 200 * randn();
    totalGeneration = max(totalGeneration, 800);
    
    % Total load (MW)
    totalLoad = totalGeneration * (0.85 + 0.1 * rand()); % Load < generation
    
    % Reserve margin (%)
    reserveMargin = (totalGeneration - totalLoad) / totalLoad * 100;
    
    % Voltage stability margin (proxy: minimum bus voltage)
    voltageMargin = min(busVoltages) - 0.9; % Distance to lower limit
    
    % Frequency (Hz)
    frequency = 50 + 0.2 * randn();
    
    operatingStates(sampleIdx, :) = [busVoltages, totalGeneration, totalLoad, ...
                                     reserveMargin, voltageMargin, frequency];
end

% Security labels (N-1 contingency analysis simulation)
% Secure if: reserve margin > 5%, voltage margin > 0.05 pu, frequency within [49.8, 50.2]
securityLabels = zeros(numSamples, 1);

for sampleIdx = 1:numSamples
    reserveMargin = operatingStates(sampleIdx, end-2);
    voltageMargin = operatingStates(sampleIdx, end-1);
    frequency = operatingStates(sampleIdx, end);
    
    if reserveMargin > 5 && voltageMargin > 0.05 && frequency >= 49.8 && frequency <= 50.2
        securityLabels(sampleIdx) = 1; % Secure
    else
        securityLabels(sampleIdx) = 0; % Insecure
    end
end

numSecure = sum(securityLabels);
numInsecure = numSamples - numSecure;

fprintf('Power system dataset generated:\n');
fprintf('  Samples: %d\n', numSamples);
fprintf('  Features: %d (bus voltages + system-level metrics)\n', numFeatures);
fprintf('  Secure states: %d (%.1f%%)\n', numSecure, numSecure / numSamples * 100);
fprintf('  Insecure states: %d (%.1f%%)\n\n', numInsecure, numInsecure / numSamples * 100);

%% 2. Data Partitioning and Baseline Classifier
fprintf('Step 2: Training baseline security classifier...\n');

% Split: 70% train, 30% test
cv = cvpartition(securityLabels, 'HoldOut', 0.3);
trainIdx = training(cv);
testIdx = test(cv);

XTrain = operatingStates(trainIdx, :);
YTrain = securityLabels(trainIdx);
XTest = operatingStates(testIdx, :);
YTest = securityLabels(testIdx);

% Normalise
[XTrainNorm, mu, sigma] = zscore(XTrain);
XTestNorm = (XTest - mu) ./ sigma;

% Train neural network classifier
hiddenLayerSize = 20;
net = feedforwardnet(hiddenLayerSize, 'trainscg');
net.trainParam.showWindow = false;
net.trainParam.epochs = 150;
net.divideParam.trainRatio = 0.85;
net.divideParam.valRatio = 0.15;
net.divideParam.testRatio = 0;

% Convert labels to binary outputs
YTrainBinary = full(ind2vec(YTrain' + 1)); % +1 for 1-indexing
[net, tr] = train(net, XTrainNorm', YTrainBinary);

% Evaluate baseline
YTestPred = net(XTestNorm');
[~, YTestPredClass] = max(YTestPred, [], 1);
YTestPredClass = (YTestPredClass - 1)'; % Convert back to 0/1

baselineAccuracy = sum(YTestPredClass == YTest) / length(YTest);

fprintf('Baseline classifier trained:\n');
fprintf('  Architecture: 2-layer MLP, %d hidden units\n', hiddenLayerSize);
fprintf('  Clean test accuracy: %.2f%%\n\n', baselineAccuracy * 100);

%% 3. Empirical Adversarial Robustness (PGD Attack)
fprintf('Step 3: Evaluating empirical adversarial robustness...\n');

% PGD attack parameters
epsilonPGD = 0.1; % L2 perturbation budget
alphaPGD = 0.02;
numIterPGD = 20;

% Attack subset of test samples for efficiency
numAttackSamples = 50;
attackIndices = randsample(find(testIdx), numAttackSamples);

empiricalRobustness = zeros(numAttackSamples, 1);

fprintf('Running PGD attacks on %d test samples...\n', numAttackSamples);

for attackIdx = 1:numAttackSamples
    sampleIdx = attackIndices(attackIdx);
    x = XTestNorm(find(testIdx) == sampleIdx, :)';
    yTrue = YTest(find(testIdx) == sampleIdx);
    
    % Initialize adversarial example
    xAdv = x + epsilonPGD * randn(size(x)) / sqrt(numFeatures);
    
    for iteration = 1:numIterPGD
        % Predict
        yPred = net(xAdv);
        
        % Compute gradient (numerical approximation)
        delta = 1e-5;
        gradient = zeros(size(xAdv));
        
        yTarget = zeros(2, 1);
        yTarget(yTrue + 1) = 1; % True class
        
        for featureIdx = 1:length(xAdv)
            xPerturbed = xAdv;
            xPerturbed(featureIdx) = xPerturbed(featureIdx) + delta;
            yPertPlus = net(xPerturbed);
            
            lossPlus = -sum(yTarget .* log(yPertPlus + 1e-8));
            
            xPerturbed = xAdv;
            xPerturbed(featureIdx) = xPerturbed(featureIdx) - delta;
            yPertMinus = net(xPerturbed);
            
            lossMinus = -sum(yTarget .* log(yPertMinus + 1e-8));
            
            gradient(featureIdx) = (lossPlus - lossMinus) / (2 * delta);
        end
        
        % Update
        xAdv = xAdv + alphaPGD * sign(gradient);
        
        % Project to L2 ball
        perturbation = xAdv - x;
        pertNorm = norm(perturbation);
        if pertNorm > epsilonPGD
            xAdv = x + perturbation * (epsilonPGD / pertNorm);
        end
    end
    
    % Check if attack succeeded
    yAdvPred = net(xAdv);
    [~, yAdvClass] = max(yAdvPred);
    yAdvClass = yAdvClass - 1;
    
    if yAdvClass ~= yTrue
        % Attack succeeded: find minimum perturbation
        empiricalRobustness(attackIdx) = norm(xAdv - x);
    else
        % Attack failed: robustness at least epsilon
        empiricalRobustness(attackIdx) = epsilonPGD;
    end
    
    if mod(attackIdx, 10) == 0
        fprintf('  Processed %d/%d samples\n', attackIdx, numAttackSamples);
    end
end

meanEmpiricalRobustness = mean(empiricalRobustness);

fprintf('Empirical robustness analysis:\n');
fprintf('  Mean empirical robustness: %.4f (L2 norm)\n', meanEmpiricalRobustness);
fprintf('  Attack success rate: %.2f%%\n\n', ...
        sum(empiricalRobustness < epsilonPGD) / numAttackSamples * 100);

%% 4. Randomised Smoothing Implementation
fprintf('Step 4: Implementing randomised smoothing for certified robustness...\n');

% Smoothing parameters
sigmaSmooth = 0.1; % Gaussian noise standard deviation
numSamplesSmooth = 1000; % Monte Carlo samples for smoothing
alpha = 0.001; % Confidence level

fprintf('Randomised smoothing parameters:\n');
fprintf('  Noise std: %.3f\n', sigmaSmooth);
fprintf('  MC samples: %d\n', numSamplesSmooth);
fprintf('  Confidence: %.3f\n\n', alpha);

%% 5. Certified Radius Computation
fprintf('Step 5: Computing certified robustness radii...\n');

% Certify subset of test samples
numCertifySamples = 50;
certifyIndices = randsample(find(testIdx), numCertifySamples);

certifiedRadii = zeros(numCertifySamples, 1);
smoothedPredictions = zeros(numCertifySamples, 1);

fprintf('Computing certified radii for %d samples...\n', numCertifySamples);

for certifyIdx = 1:numCertifySamples
    sampleIdx = certifyIndices(certifyIdx);
    x = XTestNorm(find(testIdx) == sampleIdx, :)';
    yTrue = YTest(find(testIdx) == sampleIdx);
    
    % Randomised smoothing: sample predictions
    classCounts = zeros(2, 1);
    
    for sampleMC = 1:numSamplesSmooth
        % Add Gaussian noise
        xNoisy = x + sigmaSmooth * randn(size(x));
        
        % Predict
        yPred = net(xNoisy);
        [~, yClass] = max(yPred);
        
        classCounts(yClass) = classCounts(yClass) + 1;
    end
    
    % Smoothed classifier prediction (majority vote)
    [maxCount, smoothedClass] = max(classCounts);
    smoothedPredictions(certifyIdx) = smoothedClass - 1;
    
    % Compute certified radius using Neyman-Pearson bound
    pA = maxCount / numSamplesSmooth; % Probability of predicted class
    
    if pA >= 0.5
        % Lower confidence bound on pA
        pALower = pA - norminv(1 - alpha/2) * sqrt(pA * (1 - pA) / numSamplesSmooth);
        
        % Certified radius
        if pALower > 0.5
            certifiedRadius = sigmaSmooth * (norminv(pALower) - norminv(1 - pALower)) / 2;
            certifiedRadii(certifyIdx) = certifiedRadius;
        else
            certifiedRadii(certifyIdx) = 0; % No certification possible
        end
    else
        certifiedRadii(certifyIdx) = 0;
    end
    
    if mod(certifyIdx, 10) == 0
        fprintf('  Certified %d/%d samples\n', certifyIdx, numCertifySamples);
    end
end

% Evaluate certification
meanCertifiedRadius = mean(certifiedRadii(certifiedRadii > 0));
certificationRate = sum(certifiedRadii > 0) / numCertifySamples;

% Certified accuracy
certifiedCorrect = sum((smoothedPredictions == YTest(find(testIdx)(certifyIndices))) & ...
                       (certifiedRadii > 0));
certifiedAccuracy = certifiedCorrect / numCertifySamples;

fprintf('\nCertified robustness results:\n');
fprintf('  Certification rate: %.2f%% (samples with non-zero certified radius)\n', ...
        certificationRate * 100);
fprintf('  Mean certified radius: %.4f (L2 norm)\n', meanCertifiedRadius);
fprintf('  Certified accuracy: %.2f%%\n\n', certifiedAccuracy * 100);

%% 6. Robustness Stratification Analysis
fprintf('Step 6: Analysing certified robustness across operating conditions...\n');

% Stratify by security label
secureIndices = certifyIndices(YTest(find(testIdx)(certifyIndices)) == 1);
insecureIndices = certifyIndices(YTest(find(testIdx)(certifyIndices)) == 0);

secureRadii = certifiedRadii(YTest(find(testIdx)(certifyIndices)) == 1);
insecureRadii = certifiedRadii(YTest(find(testIdx)(certifyIndices)) == 0);

meanSecureRadius = mean(secureRadii(secureRadii > 0));
meanInsecureRadius = mean(insecureRadii(insecureRadii > 0));

fprintf('Robustness by operating condition:\n');
fprintf('  Secure states: Mean certified radius = %.4f\n', meanSecureRadius);
fprintf('  Insecure states: Mean certified radius = %.4f\n', meanInsecureRadius);
fprintf('  Robustness ratio (secure/insecure): %.2f\n\n', ...
        meanSecureRadius / meanInsecureRadius);

%% 7. Conservatism Analysis
fprintf('Step 7: Comparing certified vs empirical robustness...\n');

% Find overlap samples between attack and certification
overlapIndices = intersect(attackIndices, certifyIndices);
numOverlap = length(overlapIndices);

if numOverlap > 0
    overlapEmpiricalIdx = arrayfun(@(x) find(attackIndices == x), overlapIndices);
    overlapCertifiedIdx = arrayfun(@(x) find(certifyIndices == x), overlapIndices);
    
    overlapEmpirical = empiricalRobustness(overlapEmpiricalIdx);
    overlapCertified = certifiedRadii(overlapCertifiedIdx);
    
    conservatismRatio = mean(overlapEmpirical ./ (overlapCertified + 1e-8));
    
    fprintf('Conservatism analysis (%d overlapping samples):\n', numOverlap);
    fprintf('  Mean empirical robustness: %.4f\n', mean(overlapEmpirical));
    fprintf('  Mean certified robustness: %.4f\n', mean(overlapCertified(overlapCertified > 0)));
    fprintf('  Conservatism ratio: %.2f (empirical/certified)\n\n', conservatismRatio);
else
    fprintf('No overlapping samples for conservatism analysis\n\n');
end

%% 8. Visualisation
fprintf('Step 8: Generating visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: Certified Radius Distribution
fig1 = figure('Position', [100, 100, 1400, 500]);

subplot(1, 2, 1);
histogram(certifiedRadii, 20, 'FaceColor', [0.4, 0.6, 0.8]);
xlabel('Certified Radius (L$_2$ norm)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Number of Samples', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Certified Robustness Distribution}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

subplot(1, 2, 2);
categories = categorical({'Secure States', 'Insecure States'});
radiiMeans = [meanSecureRadius, meanInsecureRadius];

bar(categories, radiiMeans, 'FaceColor', [0.6, 0.8, 0.4]);
ylabel('Mean Certified Radius', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Robustness by Operating Condition}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle('\textbf{Certified Adversarial Robustness Analysis}', ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig1, 'figures/Problem9_Certified_Robustness.fig');
saveas(fig1, 'figures/Problem9_Certified_Robustness.eps', 'epsc');
saveas(fig1, 'figures/Problem9_Certified_Robustness.jpg');
fprintf('Saved: Problem9_Certified_Robustness\n');

% Figure 2: Certified vs Empirical Comparison
if numOverlap > 0
    fig2 = figure('Position', [150, 150, 800, 600]);
    
    scatter(overlapCertified, overlapEmpirical, 80, 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    plot([0, max(overlapEmpirical)], [0, max(overlapEmpirical)], 'r-', 'LineWidth', 2);
    
    xlabel('Certified Radius', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Empirical Robustness', 'Interpreter', 'latex', 'FontSize', 11);
    title('\textbf{Certification Conservatism}', 'Interpreter', 'latex', 'FontSize', 12);
    legend('Samples', 'Perfect Calibration', 'Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    saveas(fig2, 'figures/Problem9_Conservatism_Analysis.fig');
    saveas(fig2, 'figures/Problem9_Conservatism_Analysis.eps', 'epsc');
    saveas(fig2, 'figures/Problem9_Conservatism_Analysis.jpg');
    fprintf('Saved: Problem9_Conservatism_Analysis\n');
end

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');
