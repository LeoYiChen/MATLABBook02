%% chapter_Numerical_syntax_ode.m
% ODE solver syntax structure.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Numerical_syntax_ode
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define ODE system as function handle
odefun = @(t, y) [y(2); -y(1)];  % Simple harmonic oscillator

% Set initial conditions and time span
y0 = [1; 0];  % Initial position and velocity
tspan = [0 10];  % Time interval

% Solve using ode45
[t, y] = ode45(odefun, tspan, y0);

% Optional: specify solver options
options = odeset('RelTol', 1e-6, 'AbsTol', 1e-8);
[t, y] = ode45(odefun, tspan, y0, options);
