%% nonlinear_systems.m
% Newton's Method for Systems of Nonlinear Equations
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : nonlinear_systems
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem4.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Define system of nonlinear equations
% F(x,y,z) = [(x-2)^2 + (y-3)^2 + (z-1)^2 - 4;
% (x+1)^2 + (y-1)^2 + (z+2)^2 - 9;
% (x-3)^2 + (y+2)^2 + (z-3)^2 - 16]

F = @(X) [
(X(1)-2)^2 + (X(2)-3)^2 + (X(3)-1)^2 - 4;
(X(1)+1)^2 + (X(2)-1)^2 + (X(3)+2)^2 - 9;
(X(1)-3)^2 + (X(2)+2)^2 + (X(3)-3)^2 - 16
];

% Jacobian matrix of F
J = @(X) [
2*(X(1)-2), 2*(X(2)-3), 2*(X(3)-1);
2*(X(1)+1), 2*(X(2)-1), 2*(X(3)+2);
2*(X(1)-3), 2*(X(2)+2), 2*(X(3)-3)
];

% Newton's method parameters
tol = 1e-10;
max_iter = 100;

% Initial guesses (grid of points)
[x0_grid, y0_grid, z0_grid] = ndgrid([-3:2:3], [-3:2:3], [-3:2:3]);
initial_guesses = [x0_grid(:), y0_grid(:), z0_grid(:)];

% Store found solutions
solutions = [];
function_values = [];

% Apply Newton's method with multiple initial guesses
fprintf('Applying Newton''s method with multiple initial points...\n');

for i = 1:size(initial_guesses, 1)
x0 = initial_guesses(i, :)';
[x, converged, iter, func_val] = newton_system(F, J, x0, tol, max_iter);

if converged
    % Check if this is a new solution
    is_new = true;
    for j = 1:size(solutions, 1)
        if norm(x - solutions(j,:)') < tol * 10
            is_new = false;
            break;
        end
    end
    
    if is_new
        solutions = [solutions; x'];
        function_values = [function_values; func_val'];
        fprintf('Solution %d from initial point [%.1f, %.1f, %.1f]: [%.10f, %.10f, %.10f] (iterations: %d)\n', ...
            size(solutions, 1), x0(1), x0(2), x0(3), x(1), x(2), x(3), iter);
    end
end

end

% Verify solutions
fprintf('\nVerification of solutions:\n');
fprintf('%-5s %-15s %-15s %-15s %-15s %-15s %-15s\n', ...
'Sol#', 'x', 'y', 'z', 'Eq1 Value', 'Eq2 Value', 'Eq3 Value');

for i = 1:size(solutions, 1)
fprintf('%-5d %-15.10f %-15.10f %-15.10f %-15.2e %-15.2e %-15.2e\n', ...
i, solutions(i,1), solutions(i,2), solutions(i,3), ...
function_values(i,1), function_values(i,2), function_values(i,3));
end

% Visualize the spheres and intersection points
[X,Y,Z] = sphere(50);

figure;
% Sphere 1: (x-2)^2 + (y-3)^2 + (z-1)^2 = 4
r1 = 2; % Radius = sqrt(4)
surf(r1X+2, r1Y+3, r1*Z+1, 'FaceAlpha', 0.3, 'EdgeAlpha', 0.1, 'FaceColor', 'r');
hold on;

% Sphere 2: (x+1)^2 + (y-1)^2 + (z+2)^2 = 9
r2 = 3; % Radius = sqrt(9)
surf(r2X-1, r2Y+1, r2*Z-2, 'FaceAlpha', 0.3, 'EdgeAlpha', 0.1, 'FaceColor', 'g');

% Sphere 3: (x-3)^2 + (y+2)^2 + (z-3)^2 = 16
r3 = 4; % Radius = sqrt(16)
surf(r3X+3, r3Y-2, r3*Z+3, 'FaceAlpha', 0.3, 'EdgeAlpha', 0.1, 'FaceColor', 'b');

% Plot intersection points
for i = 1:size(solutions, 1)
plot3(solutions(i,1), solutions(i,2), solutions(i,3), 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'k');
text(solutions(i,1)+0.2, solutions(i,2)+0.2, solutions(i,3)+0.2, ['Sol ', num2str(i)]);
end

xlabel('x');
ylabel('y');
zlabel('z');
title('Intersection of Three Spheres');
legend('Sphere 1', 'Sphere 2', 'Sphere 3', 'Intersection Points');
grid on;
axis equal;
view(30, 30);

% Newton's method for systems of nonlinear equations
function [x, converged, iter, func_val] = newton_system(F, J, x0, tol, max_iter)
x = x0;
converged = false;

for iter = 1:max_iter
    % Calculate function value and Jacobian
    f = F(x);
    jac = J(x);
    
    % Check for convergence
    if norm(f) < tol
        converged = true;
        break;
    end
    
    % Solve linear system J(x) * dx = -F(x)
    dx = jac \ (-f);
    
    % Update x
    x = x + dx;
    
    % Check for convergence based on step size
    if norm(dx) < tol
        converged = true;
        break;
    end
end

% Final function value
func_val = F(x);

end
