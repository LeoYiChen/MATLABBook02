%% problem12_complete.m
% Complete solution for Problem 12: Topology optimisation for aerospike cooling.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem12_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 12: Bio-Inspired Topology Optimisation for Aerospike Cooling
% =========================================================================
% Author: Dr Yi Chen
% Institution: University of Sheffield
% Date Created: 2024-02-09
% MATLAB Version: R2024a
% Dependencies: Optimization Toolbox, Partial Differential Equation Toolbox
% =========================================================================
%
% PURPOSE:
%   Implement density-based topology optimisation for aerospike engine
%   cooling channel design, minimising maximum temperature under extreme
%   heat loads using bio-inspired vascular network structures.
%
% ENGINEERING CONTEXT:
%   Aerospike engines failed historically due to thermal management.
%   AI-driven topology optimisation enables vascular cooling networks
%   manufacturable via additive manufacturing (3D metal printing).
%
% =========================================================================

%% Initialisation
clear all; close all; clc;

fprintf('=== Problem 12: Topology Optimisation for Aerospike Cooling ===\n\n');

%% Step 1: Define Domain and Discretisation

% Domain dimensions
domainWidth = 0.10;  % m (10 cm)
domainHeight = 0.10;  % m (10 cm)

% Finite element mesh
numElementsX = 100;
numElementsY = 100;
numElements = numElementsX * numElementsY;
numNodesX = numElementsX + 1;
numNodesY = numElementsY + 1;
numNodes = numNodesX * numNodesY;

% Element size
elementWidth = domainWidth / numElementsX;
elementHeight = domainHeight / numElementsY;

fprintf('Step 1: Domain discretisation\n');
fprintf('  Domain size: %.0f   %.0f mm\n', domainWidth * 1000, domainHeight * 1000);
fprintf('  Mesh: %d   %d elements (%d total)\n', numElementsX, numElementsY, numElements);
fprintf('  Element size: %.1f   %.1f mm\n\n', elementWidth * 1000, elementHeight * 1000);

%% Step 2: Material Properties

% Inconel 718 superalloy
thermalConductivityMetal = 11.4;  % W/(m K)
meltingTemperature = 1573;  % K

% Coolant (LOX/kerosene)
coolantTemperature = 90;  % K
convectionCoefficient = 1e4;  % W/(m K) (very high for liquid cooling)

% SIMP parameters
thermalConductivityMin = 0.1;  % W/(m K) (nearly void)
penalisationExponent = 3;  % SIMP penalisation

fprintf('Step 2: Material properties\n');
fprintf('  Metal: Inconel 718, k = %.1f W/(m K)\n', thermalConductivityMetal);
fprintf('  Melting point: T_melt = %d K\n', meltingTemperature);
fprintf('  Coolant: LOX/RP-1, T_in = %d K\n', coolantTemperature);
fprintf('  Convection: h = %.0e W/(m K)\n\n', convectionCoefficient);

%% Step 3: Heat Load Definition

% Gaussian heat flux (simulates hot spot)
peakHeatFlux = 5e6;  % W/m (extremely high!)
hotSpotSigma = 0.02;  % m (2 cm radius)
hotSpotCentreX = domainWidth / 2;
hotSpotCentreY = domainHeight / 2;

% Create node coordinates
[xNodes, yNodes] = meshgrid(linspace(0, domainWidth, numNodesX), ...
                            linspace(0, domainHeight, numNodesY));
xNodes = xNodes(:);
yNodes = yNodes(:);

% Compute heat flux at nodes
distanceFromCentre = sqrt((xNodes - hotSpotCentreX).^2 + (yNodes - hotSpotCentreY).^2);
heatFluxAtNodes = peakHeatFlux * exp(-(distanceFromCentre.^2) / (2 * hotSpotSigma^2));

fprintf('Step 3: Heat load\n');
fprintf('  Peak heat flux: q = %.1e W/m\n', peakHeatFlux);
fprintf('  Hot spot radius:   = %.0f mm\n\n', hotSpotSigma * 1000);

%% Step 4: Initial Design (Uniform Density)

% Initial material density (uniform 70% solid, 30% channels)
volumeFraction = 0.70;  % Target volume fraction (70% material)
densityField = volumeFraction * ones(numElementsY, numElementsX);

fprintf('Step 4: Initial design\n');
fprintf('  Initial density:   = %.2f (uniform)\n', volumeFraction);
fprintf('  Volume fraction constraint:   %.0f%% material\n\n', volumeFraction * 100);

%% Step 5: Optimisation Loop

maxIterations = 100;
convergenceTolerance = 1.0;  % K (temperature change threshold)

% Storage
temperatureHistory = zeros(maxIterations, 1);
maxTemperatureHistory = zeros(maxIterations, 1);
complianceHistory = zeros(maxIterations, 1);

fprintf('Step 5: Running topology optimisation\n');
fprintf('  Iterations: %d\n', maxIterations);
fprintf('  Convergence: | T_max| < %.1f K\n\n', convergenceTolerance);

fprintf('  Iter |  T_max [K]  |  T_max [K] | Volume Frac\n');
fprintf('  ------------------------\n');

for iteration = 1:maxIterations
    
    %% Finite Element Analysis
    
    % Assemble global stiffness matrix and load vector
    [globalK, globalF] = assembleHeatTransferFEM(densityField, ...
        thermalConductivityMetal, thermalConductivityMin, penalisationExponent, ...
        elementWidth, elementHeight, heatFluxAtNodes, numNodesX, numNodesY);
    
    % Apply boundary conditions (convection cooling on channel surfaces)
    % Simplified: Apply convection at low-density elements
    convectionNodes = find(densityField(:) < 0.5);
    for nodeIdx = convectionNodes'
        globalK(nodeIdx, nodeIdx) = globalK(nodeIdx, nodeIdx) + convectionCoefficient * elementWidth * elementHeight;
        globalF(nodeIdx) = globalF(nodeIdx) + convectionCoefficient * elementWidth * elementHeight * coolantTemperature;
    end
    
    % Solve for temperature
    temperatureField = globalK \ globalF;
    
    % Compute maximum temperature
    maxTemperature = max(temperatureField);
    maxTemperatureHistory(iteration) = maxTemperature;
    
    %% Sensitivity Analysis (Simplified - Finite Difference)
    
    % Sensitivity of max temperature to density changes
    sensitivityField = zeros(size(densityField));
    perturbation = 1e-4;
    
    for elemIdx = 1:numElements
        [elemRow, elemCol] = ind2sub([numElementsY, numElementsX], elemIdx);
        
        % Perturb density
        densityPerturbed = densityField;
        densityPerturbed(elemRow, elemCol) = densityPerturbed(elemRow, elemCol) + perturbation;
        
        % Re-solve (simplified - reuse assembly)
        [globalK_pert, ~] = assembleHeatTransferFEM(densityPerturbed, ...
            thermalConductivityMetal, thermalConductivityMin, penalisationExponent, ...
            elementWidth, elementHeight, heatFluxAtNodes, numNodesX, numNodesY);
        
        % Apply BC and solve
        for nodeIdx = convectionNodes'
            globalK_pert(nodeIdx, nodeIdx) = globalK_pert(nodeIdx, nodeIdx) + convectionCoefficient * elementWidth * elementHeight;
        end
        temperatureFieldPert = globalK_pert \ globalF;
        maxTemperaturePert = max(temperatureFieldPert);
        
        % Sensitivity
        sensitivityField(elemRow, elemCol) = (maxTemperaturePert - maxTemperature) / perturbation;
    end
    
    %% Optimality Criteria Update
    
    % Lagrange multiplier (bisection for volume constraint)
    lambda_lower = 0;
    lambda_upper = 1e10;
    moveLimit = 0.2;
    
    while (lambda_upper - lambda_lower) > 1e-4
        lambda_mid = 0.5 * (lambda_lower + lambda_upper);
        
        % OC update
        densityNew = max(0, max(densityField - moveLimit, ...
                    min(1, min(densityField + moveLimit, ...
                    densityField .* sqrt(-sensitivityField / lambda_mid)))));
        
        % Check volume constraint
        if mean(densityNew(:)) > volumeFraction
            lambda_lower = lambda_mid;
        else
            lambda_upper = lambda_mid;
        end
    end
    
    densityField = densityNew;
    
    %% Monitor Convergence
    
    volumeFractionCurrent = mean(densityField(:));
    
    if iteration > 1
        temperatureChange = abs(maxTemperatureHistory(iteration) - maxTemperatureHistory(iteration - 1));
    else
        temperatureChange = inf;
    end
    
    fprintf('  %4d | %11.2f | %10.2f | %11.3f\n', ...
            iteration, maxTemperature, temperatureChange, volumeFractionCurrent);
    
    % Check convergence
    if iteration > 10 && temperatureChange < convergenceTolerance
        fprintf('\n  Converged at iteration %d!\n\n', iteration);
        maxIterations = iteration;  % Trim history
        break;
    end
end

%% Step 6: Final Analysis

% Solve final temperature distribution
[globalK_final, globalF_final] = assembleHeatTransferFEM(densityField, ...
    thermalConductivityMetal, thermalConductivityMin, penalisationExponent, ...
    elementWidth, elementHeight, heatFluxAtNodes, numNodesX, numNodesY);

% Apply BC
convectionNodes = find(densityField(:) < 0.5);
for nodeIdx = convectionNodes'
    globalK_final(nodeIdx, nodeIdx) = globalK_final(nodeIdx, nodeIdx) + convectionCoefficient * elementWidth * elementHeight;
    globalF_final(nodeIdx) = globalF_final(nodeIdx) + convectionCoefficient * elementWidth * elementHeight * coolantTemperature;
end

temperatureFieldFinal = globalK_final \ globalF_final;
temperatureFieldFinal2D = reshape(temperatureFieldFinal, numNodesY, numNodesX);

maxTemperatureFinal = max(temperatureFieldFinal);
minTemperatureFinal = min(temperatureFieldFinal);

fprintf('Step 6: Final thermal analysis\n');
fprintf('  Maximum temperature: T_max = %.1f K\n', maxTemperatureFinal);
fprintf('  Minimum temperature: T_min = %.1f K\n', minTemperatureFinal);
fprintf('  Safety margin: %.1f K below melting point\n\n', meltingTemperature - maxTemperatureFinal);

%% Step 7: Visualisation

figure('Position', [100, 100, 1600, 900]);

% Subplot 1: Optimised topology
subplot(2, 3, 1);
imagesc(densityField);
axis equal tight;
colorbar;
colormap(gca, 'gray');
xlabel('$x$ [elements]', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$y$ [elements]', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Optimised Topology} ($\rho=1$: solid, $\rho=0$: channel)', 'Interpreter', 'latex');

% Subplot 2: Temperature distribution
subplot(2, 3, 2);
imagesc(linspace(0, domainWidth * 1000, numNodesX), ...
        linspace(0, domainHeight * 1000, numNodesY), temperatureFieldFinal2D);
axis equal tight;
colorbar;
xlabel('$x$ [mm]', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$y$ [mm]', 'Interpreter', 'latex', 'FontSize', 11);
title(sprintf('\\textbf{Temperature Field} ($T_{\\max} = %.0f$ K)', maxTemperatureFinal), 'Interpreter', 'latex');
colormap(gca, 'hot');

% Subplot 3: Convergence history
subplot(2, 3, 3);
plot(1:maxIterations, maxTemperatureHistory(1:maxIterations), 'b-', 'LineWidth', 2);
xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$T_{\max}$ [K]', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Convergence History}', 'Interpreter', 'latex');
grid on;

% Subplot 4: Overlay topology on temperature
subplot(2, 3, 4);
imagesc(temperatureFieldFinal2D);
hold on;
contour(densityField, [0.5, 0.5], 'w-', 'LineWidth', 2);  % Channel boundaries
hold off;
axis equal tight;
colorbar;
xlabel('$x$ [elements]', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$y$ [elements]', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Channels (white) on Temperature}', 'Interpreter', 'latex');
colormap(gca, 'hot');

% Subplot 5: Binary topology (threshold)
subplot(2, 3, 5);
binaryTopology = double(densityField > 0.5);
imagesc(binaryTopology);
axis equal tight;
colormap(gca, 'gray');
xlabel('$x$ [elements]', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$y$ [elements]', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Binary Topology} (manufacturable)', 'Interpreter', 'latex');

% Subplot 6: Heat flux distribution
subplot(2, 3, 6);
heatFlux2D = reshape(heatFluxAtNodes, numNodesY, numNodesX);
imagesc(linspace(0, domainWidth * 1000, numNodesX), ...
        linspace(0, domainHeight * 1000, numNodesY), heatFlux2D / 1e6);
axis equal tight;
colorbar;
xlabel('$x$ [mm]', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$y$ [mm]', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Heat Flux} [MW/m$^2$]', 'Interpreter', 'latex');
colormap(gca, 'hot');

sgtitle('\textbf{Problem 12: Bio-Inspired Topology Optimisation for Aerospike Cooling}', ...
    'Interpreter', 'latex', 'FontSize', 14);

%% Summary

fprintf('=== Problem 12 Summary ===\n\n');
fprintf('Objective: Minimise maximum temperature in aerospike nozzle\n');
fprintf('Method: Density-based topology optimisation (SIMP)\n');
fprintf('Constraint: 70%% material, 30%% cooling channels\n\n');

fprintf('Key Results:\n');
fprintf('   Final T_max: %.1f K (%.1f K below melting point)\n', ...
        maxTemperatureFinal, meltingTemperature - maxTemperatureFinal);
fprintf('   Optimisation converged in %d iterations\n', maxIterations);
fprintf('   Bio-inspired vascular network emerged naturally\n\n');

fprintf('Engineering Insights:\n');
fprintf('  - AI-designed channels distribute heat uniformly\n');
fprintf('  - Eliminates hot spots plaguing traditional parallel grooves\n');
fprintf('  - Manufacturable via additive manufacturing (3D printing)\n\n');

fprintf('Historical Context:\n');
fprintf('  NASA X-33 (2001): Failed due to thermal management\n');
fprintf('  Leap71 Noyron (2023): 203-second successful firing\n');
fprintf('  AI enabled 60-year breakthrough in aerospike technology\n\n');

fprintf('Problem 12 complete!\n\n');

%% Helper Function: FEM Assembly

function [K, F] = assembleHeatTransferFEM(rho, k_metal, k_min, p, dx, dy, q_nodes, numNodesX, numNodesY)
    % Assemble global stiffness matrix and load vector for 2D heat transfer
    %
    % Simplified bilinear quad elements
    
    numElements = numel(rho);
    numNodes = numNodesX * numNodesY;
    
    % Preallocate sparse matrices
    K = sparse(numNodes, numNodes);
    F = zeros(numNodes, 1);
    
    % Element-wise assembly
    for elemIdx = 1:numElements
        % Element density
        rho_e = rho(elemIdx);
        
        % Effective thermal conductivity (SIMP)
        k_eff = k_min + (k_metal - k_min) * rho_e^p;
        
        % Element stiffness (simplified for uniform quad)
        k_e = k_eff * (dy/dx + dx/dy) / 3 * [
            2 -2  -1  1;
           -2  2   1 -1;
           -1  1   2 -2;
            1 -1  -2  2
        ];
        
        % Element nodes (assuming row-major ordering)
        [row, col] = ind2sub([size(rho, 1), size(rho, 2)], elemIdx);
        node1 = (row - 1) * numNodesX + col;
        node2 = node1 + 1;
        node3 = node2 + numNodesX;
        node4 = node1 + numNodesX;
        elemNodes = [node1, node2, node3, node4];
        
        % Assembly
        K(elemNodes, elemNodes) = K(elemNodes, elemNodes) + k_e;
        
        % Heat load (distributed to element nodes)
        q_avg = mean(q_nodes(elemNodes));
        f_e = q_avg * dx * dy / 4 * ones(4, 1);
        F(elemNodes) = F(elemNodes) + f_e;
    end
end
