%% lst_adv_prob06.m
% Optimal cylindrical tank design.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob06
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem06.m
%  Optimal Design of a Cylindrical Storage Tank
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. Objective and Constraints --
surfaceArea = @(designVars) 2*pi*designVars(1)*designVars(2) ...
              + 4*pi*designVars(1)^2;

targetVolume = 50;  % m^3
lowerBounds = [1; 2];  % r >= 1, h >= 2
upperBounds = [];

%% -- 2. Nonlinear Constraint Function --
    % Embedded below as nested function for fmincon

%% -- 3. Optimisation --
initialGuess = [2; 5];
optimiserOptions = optimoptions('fmincon', ...
    'Algorithm', 'sqp', ...
    'Display', 'iter', ...
    'OptimalityTolerance', 1e-12, ...
    'StepTolerance', 1e-12);

[optimalDesign, optimalArea, exitFlag, outputInfo, lagrangeMultipliers] = ...
    fmincon(surfaceArea, initialGuess, ...
    [], [], [], [], lowerBounds, upperBounds, ...
    @volumeConstraint, optimiserOptions);

optimalRadius = optimalDesign(1);
optimalHeight = optimalDesign(2);

fprintf('\n-- Optimal Tank Design --\n');
fprintf('  Radius       r* = %.6f m\n', optimalRadius);
fprintf('  Height       h* = %.6f m\n', optimalHeight);
fprintf('  Surface area A* = %.6f m^2\n', optimalArea);
fprintf('  Volume check V* = %.6f m^3\n', ...
    pi*optimalRadius^2*optimalHeight ...
    + (4/3)*pi*optimalRadius^3);
fprintf('  Exit flag       = %d\n', exitFlag);

%% -- 4. KKT Verification --
fprintf('\n-- KKT Condition Verification --\n');
fprintf('  Lambda (equality): %.6f\n', ...
    lagrangeMultipliers.eqnonlin);
fprintf('  Mu (lower bound r): %.6f\n', ...
    lagrangeMultipliers.lower(1));
fprintf('  Mu (lower bound h): %.6f\n', ...
    lagrangeMultipliers.lower(2));

if lagrangeMultipliers.lower(2) > 1e-6
    fprintf('  h constraint is ACTIVE (h* = h_min = 2 m)\n');
else
    fprintf('  h constraint is INACTIVE\n');
end

%% -- 5. Visualisation --
figHandle = figure('Position', [100 100 1000 450]);
radiusRange = linspace(1, 3.5, 100);

% Compute h from volume constraint for each r
heightFromVolume = (targetVolume - (4/3)*pi*radiusRange.^3) ...
                   ./ (pi*radiusRange.^2);
validIndices = heightFromVolume >= 2;

areaFeasible = 2*pi*radiusRange(validIndices) ...
    .* heightFromVolume(validIndices) ...
    + 4*pi*radiusRange(validIndices).^2;

subplot(1,2,1);
plot(radiusRange(validIndices), areaFeasible, 'b-', ...
     'LineWidth', 1.5); hold on;
plot(optimalRadius, optimalArea, 'r*', 'MarkerSize', 15, ...
     'LineWidth', 2);
xlabel('$r$ (m)', 'Interpreter', 'latex');
ylabel('Surface area $A$ (m$^2$)', 'Interpreter', 'latex');
title('Surface Area vs Radius (Feasible Region)', ...
      'Interpreter', 'latex');
legend({'$A(r)$ on constraint', 'Optimum'}, ...
       'Interpreter', 'latex');
grid on;

subplot(1,2,2);
[rGrid, hGrid] = meshgrid(linspace(0.5, 4, 100), ...
                           linspace(0, 10, 100));
areaGrid = 2*pi*rGrid.*hGrid + 4*pi*rGrid.^2;
contourf(rGrid, hGrid, areaGrid, 20);
colorbar; hold on;
% Volume constraint curve
fimplicit(@(r, h) pi*r.^2.*h + (4/3)*pi*r.^3 - targetVolume, ...
    [0.5 4 0 10], 'r-', 'LineWidth', 2);
plot(optimalRadius, optimalHeight, 'w*', 'MarkerSize', 15, ...
     'LineWidth', 2);
xlabel('$r$ (m)', 'Interpreter', 'latex');
ylabel('$h$ (m)', 'Interpreter', 'latex');
title('Contour Plot with Volume Constraint', ...
      'Interpreter', 'latex');
grid on;

savefig(figHandle, 'Problem06_TankOptimisation.fig');
exportgraphics(figHandle, 'Problem06_TankOptimisation.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem06_TankOptimisation.jpg', ...
               'Resolution', 300);

fprintf('\n-- Problem 6 Complete --\n');

%% -- Local Function --
function [inequalityConstraint, equalityConstraint] = ...
         volumeConstraint(designVars)
    % Nonlinear constraint: volume = 50 m^3
    currentRadius = designVars(1);
    currentHeight = designVars(2);
    inequalityConstraint = [];  % no inequality constraints
    equalityConstraint = pi*currentRadius^2*currentHeight ...
        + (4/3)*pi*currentRadius^3 - 50;
end
% Computational Complexity:
% fmincon with the SQP algorithm solves a quadratic programming
% subproblem at each iteration, costing O(n^3) for n=2 design
% variables.  Typically 10-30 iterations are needed, each
% requiring one objective and one constraint evaluation plus
% gradient estimation by finite differences (O(n) function
% evaluations per gradient).  Total cost is approximately
% O(k * n * f_eval), where k~20 and f_eval is the cost of one
% objective evaluation.  Space is O(n^2) for Hessian storage.
