%% chapter_AIforMechatronics_problem06_code.m
% Multi-sensor fusion architecture comparison.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem06_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 6: Multi-Sensor Fusion Architecture Comparison
% Author: Dr Yi Chen
% Purpose: Compare sensor fusion architectures for robot localisation
% MATLAB Version: R2023b or later
% Required Toolboxes: Statistics and Machine Learning Toolbox
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Define simulation parameters
fprintf('=== Multi-Sensor Fusion Architecture Comparison ===\n\n');
fprintf('Step 1: Defining simulation parameters...\n');

% Time parameters
dt = 0.1; % Time step (seconds)
T = 60; % Total simulation time (seconds)
timeSteps = 0:dt:T;
numSteps = length(timeSteps);

% Robot motion model parameters (unicycle model)
v = 1.0; % Linear velocity (m/s)
omega = 0.1; % Angular velocity (rad/s)

% Initial state [x, y, theta]
x0 = [0; 0; 0];

fprintf('  Simulation duration: %.1f seconds\n', T);
fprintf('  Time step: %.2f seconds\n', dt);
fprintf('  Number of time steps: %d\n', numSteps);

%% Step 2: Generate ground truth trajectory
fprintf('\nStep 2: Generating ground truth trajectory...\n');

% Preallocate ground truth trajectory
xTrue = zeros(3, numSteps);
xTrue(:, 1) = x0;

% Generate circular trajectory
for k = 2:numSteps
    % Unicycle motion model: x_k+1 = f(x_k, u_k)
    theta = xTrue(3, k-1);
    xTrue(1, k) = xTrue(1, k-1) + v * cos(theta) * dt;
    xTrue(2, k) = xTrue(2, k-1) + v * sin(theta) * dt;
    xTrue(3, k) = xTrue(3, k-1) + omega * dt;
    
    % Keep theta in [-pi, pi]
    xTrue(3, k) = wrapToPi(xTrue(3, k));
end

fprintf('  Ground truth trajectory generated\n');
fprintf('  Trajectory type: Circular motion\n');
fprintf('  Final position: [%.2f, %.2f] m\n', xTrue(1, end), xTrue(2, end));

%% Step 3: Simulate sensor measurements
fprintf('\nStep 3: Simulating sensor measurements...\n');

% GPS sensor parameters
gpsFrequency = 1; % Hz (1 measurement per second)
gpsInterval = round(1 / (gpsFrequency * dt));
gpsNoiseStd = 0.5; % Standard deviation (metres)

% Odometry sensor parameters
odoNoiseStd = [0.05; 0.05; 0.02]; % [v_noise, omega_noise, drift]

% IMU sensor parameters (orientation measurements)
imuNoiseStd = 0.05; % Standard deviation (radians)

% Generate GPS measurements (sparse, noisy position)
gpsMeasurements = [];
gpsTimes = [];

for k = 1:gpsInterval:numSteps
    % Add Gaussian noise to true position
    noisyPosition = xTrue(1:2, k) + gpsNoiseStd * randn(2, 1);
    gpsMeasurements = [gpsMeasurements, noisyPosition];
    gpsTimes = [gpsTimes, k];
end

% Generate odometry measurements (velocity commands with noise)
odoMeasurements = zeros(2, numSteps);
for k = 1:numSteps
    odoMeasurements(1, k) = v + odoNoiseStd(1) * randn();
    odoMeasurements(2, k) = omega + odoNoiseStd(2) * randn();
end

% Generate IMU measurements (noisy orientation)
imuMeasurements = xTrue(3, :) + imuNoiseStd * randn(1, numSteps);

fprintf('  GPS measurements: %d\n', size(gpsMeasurements, 2));
fprintf('  GPS noise std: %.2f m\n', gpsNoiseStd);
fprintf('  Odometry noise std: [%.3f, %.3f] m/s, rad/s\n', ...
    odoNoiseStd(1), odoNoiseStd(2));
fprintf('  IMU noise std: %.3f rad\n', imuNoiseStd);

%% Step 4: Implement Extended Kalman Filter
fprintf('\nStep 4: Implementing Extended Kalman Filter...\n');

% EKF initialisation
xEKF = zeros(3, numSteps);
xEKF(:, 1) = x0 + [0.5; 0.5; 0.1] .* randn(3, 1); % Initial estimate with error
PEKF = diag([1.0, 1.0, 0.5]); % Initial covariance

% Process noise covariance
Q = diag([0.01, 0.01, 0.005]);

% Measurement noise covariances
R_gps = gpsNoiseStd^2 * eye(2);
R_imu = imuNoiseStd^2;

% EKF storage
PEKF_history = zeros(3, 3, numSteps);
PEKF_history(:, :, 1) = PEKF;

gpsIdx = 1;

tic;
for k = 2:numSteps
    % Prediction step
    theta = xEKF(3, k-1);
    v_odo = odoMeasurements(1, k-1);
    omega_odo = odoMeasurements(2, k-1);
    
    % State prediction
    xEKF(1, k) = xEKF(1, k-1) + v_odo * cos(theta) * dt;
    xEKF(2, k) = xEKF(2, k-1) + v_odo * sin(theta) * dt;
    xEKF(3, k) = xEKF(3, k-1) + omega_odo * dt;
    xEKF(3, k) = wrapToPi(xEKF(3, k));
    
    % Jacobian of motion model
    F = [1, 0, -v_odo * sin(theta) * dt;
         0, 1,  v_odo * cos(theta) * dt;
         0, 0,  1];
    
    % Covariance prediction
    PEKF = F * PEKF * F' + Q;
    
    % Update step with GPS (if available)
    if gpsIdx <= length(gpsTimes) && gpsTimes(gpsIdx) == k
        % GPS measurement
        z_gps = gpsMeasurements(:, gpsIdx);
        
        % Measurement Jacobian
        H_gps = [1, 0, 0;
                 0, 1, 0];
        
        % Innovation
        y = z_gps - xEKF(1:2, k);
        
        % Innovation covariance
        S = H_gps * PEKF * H_gps' + R_gps;
        
        % Kalman gain
        K = PEKF * H_gps' / S;
        
        % State update
        xEKF(:, k) = xEKF(:, k) + K * y;
        xEKF(3, k) = wrapToPi(xEKF(3, k));
        
        % Covariance update
        PEKF = (eye(3) - K * H_gps) * PEKF;
        
        gpsIdx = gpsIdx + 1;
    end
    
    % Update with IMU
    z_imu = imuMeasurements(k);
    H_imu = [0, 0, 1];
    
    % Innovation
    y_imu = wrapToPi(z_imu - xEKF(3, k));
    
    % Innovation covariance
    S_imu = H_imu * PEKF * H_imu' + R_imu;
    
    % Kalman gain
    K_imu = PEKF * H_imu' / S_imu;
    
    % State update
    xEKF(:, k) = xEKF(:, k) + K_imu * y_imu;
    xEKF(3, k) = wrapToPi(xEKF(3, k));
    
    % Covariance update
    PEKF = (eye(3) - K_imu * H_imu) * PEKF;
    
    PEKF_history(:, :, k) = PEKF;
end
ekfTime = toc;

fprintf('  EKF implementation completed\n');
fprintf('  Processing time: %.4f seconds\n', ekfTime);

%% Step 5: Implement Unscented Kalman Filter
fprintf('\nStep 5: Implementing Unscented Kalman Filter...\n');

% UKF initialisation
xUKF = zeros(3, numSteps);
xUKF(:, 1) = x0 + [0.5; 0.5; 0.1] .* randn(3, 1);
PUKF = diag([1.0, 1.0, 0.5]);

% UKF parameters
n = 3; % State dimension
alpha = 1e-3;
kappa = 0;
beta = 2;
lambda = alpha^2 * (n + kappa) - n;

% Sigma point weights
Wm = [lambda / (n + lambda), repmat(1 / (2 * (n + lambda)), 1, 2 * n)];
Wc = Wm;
Wc(1) = Wc(1) + (1 - alpha^2 + beta);

% UKF storage
PUKF_history = zeros(3, 3, numSteps);
PUKF_history(:, :, 1) = PUKF;

gpsIdx = 1;

tic;
for k = 2:numSteps
    % Generate sigma points
    sqrtP = chol(PUKF + 1e-9 * eye(n), 'lower');
    sigmaPoints = [xUKF(:, k-1), ...
                   xUKF(:, k-1) + sqrt(n + lambda) * sqrtP, ...
                   xUKF(:, k-1) - sqrt(n + lambda) * sqrtP];
    
    % Propagate sigma points through motion model
    v_odo = odoMeasurements(1, k-1);
    omega_odo = odoMeasurements(2, k-1);
    
    sigmaPointsProp = zeros(3, 2 * n + 1);
    for i = 1:(2 * n + 1)
        theta = sigmaPoints(3, i);
        sigmaPointsProp(1, i) = sigmaPoints(1, i) + v_odo * cos(theta) * dt;
        sigmaPointsProp(2, i) = sigmaPoints(2, i) + v_odo * sin(theta) * dt;
        sigmaPointsProp(3, i) = sigmaPoints(3, i) + omega_odo * dt;
        sigmaPointsProp(3, i) = wrapToPi(sigmaPointsProp(3, i));
    end
    
    % Predicted mean
    xUKF(:, k) = sum(Wm .* sigmaPointsProp, 2);
    xUKF(3, k) = wrapToPi(xUKF(3, k));
    
    % Predicted covariance
    PUKF = Q;
    for i = 1:(2 * n + 1)
        diff = sigmaPointsProp(:, i) - xUKF(:, k);
        diff(3) = wrapToPi(diff(3));
        PUKF = PUKF + Wc(i) * (diff * diff');
    end
    
    % Update with GPS (if available)
    if gpsIdx <= length(gpsTimes) && gpsTimes(gpsIdx) == k
        % Regenerate sigma points
        sqrtP = chol(PUKF + 1e-9 * eye(n), 'lower');
        sigmaPoints = [xUKF(:, k), ...
                       xUKF(:, k) + sqrt(n + lambda) * sqrtP, ...
                       xUKF(:, k) - sqrt(n + lambda) * sqrtP];
        
        % Propagate through measurement model
        sigmaMeas = sigmaPoints(1:2, :);
        
        % Predicted measurement
        z_pred = sum(Wm .* sigmaMeas, 2);
        
        % Innovation covariance
        Pzz = R_gps;
        Pxz = zeros(3, 2);
        for i = 1:(2 * n + 1)
            diffMeas = sigmaMeas(:, i) - z_pred;
            diffState = sigmaPoints(:, i) - xUKF(:, k);
            diffState(3) = wrapToPi(diffState(3));
            
            Pzz = Pzz + Wc(i) * (diffMeas * diffMeas');
            Pxz = Pxz + Wc(i) * (diffState * diffMeas');
        end
        
        % Kalman gain
        K = Pxz / Pzz;
        
        % State update
        z_gps = gpsMeasurements(:, gpsIdx);
        innovation = z_gps - z_pred;
        xUKF(:, k) = xUKF(:, k) + K * innovation;
        xUKF(3, k) = wrapToPi(xUKF(3, k));
        
        % Covariance update
        PUKF = PUKF - K * Pzz * K';
        
        gpsIdx = gpsIdx + 1;
    end
    
    % Update with IMU (simplified for brevity)
    % Similar sigma point approach for IMU measurement update
    
    PUKF_history(:, :, k) = PUKF;
end
ukfTime = toc;

fprintf('  UKF implementation completed\n');
fprintf('  Processing time: %.4f seconds\n', ukfTime);

%% Step 6: Implement Particle Filter
fprintf('\nStep 6: Implementing Particle Filter...\n');

% Particle filter initialisation
numParticles = 1000;
particles = repmat(x0, 1, numParticles) + ...
    [1.0; 1.0; 0.5] .* randn(3, numParticles);
weights = ones(1, numParticles) / numParticles;

% PF storage
xPF = zeros(3, numSteps);
xPF(:, 1) = sum(particles .* weights, 2);

gpsIdx = 1;

tic;
for k = 2:numSteps
    % Prediction: propagate particles through motion model
    v_odo = odoMeasurements(1, k-1);
    omega_odo = odoMeasurements(2, k-1);
    
    for p = 1:numParticles
        theta = particles(3, p);
        
        % Add process noise
        processNoise = mvnrnd([0; 0; 0], Q)';
        
        particles(1, p) = particles(1, p) + v_odo * cos(theta) * dt + processNoise(1);
        particles(2, p) = particles(2, p) + v_odo * sin(theta) * dt + processNoise(2);
        particles(3, p) = particles(3, p) + omega_odo * dt + processNoise(3);
        particles(3, p) = wrapToPi(particles(3, p));
    end
    
    % Update: weight particles based on GPS measurement
    if gpsIdx <= length(gpsTimes) && gpsTimes(gpsIdx) == k
        z_gps = gpsMeasurements(:, gpsIdx);
        
        for p = 1:numParticles
            % Measurement likelihood
            diff = z_gps - particles(1:2, p);
            weights(p) = weights(p) * mvnpdf(diff', [0, 0], R_gps);
        end
        
        % Normalise weights
        weights = weights / sum(weights);
        
        % Effective sample size
        Neff = 1 / sum(weights.^2);
        
        % Resample if needed
        if Neff < numParticles / 2
            % Systematic resampling
            cumulativeSum = cumsum(weights);
            u = ([0:(numParticles-1)] + rand()) / numParticles;
            
            newParticles = zeros(3, numParticles);
            j = 1;
            for i = 1:numParticles
                while u(i) > cumulativeSum(j)
                    j = j + 1;
                end
                newParticles(:, i) = particles(:, j);
            end
            
            particles = newParticles;
            weights = ones(1, numParticles) / numParticles;
        end
        
        gpsIdx = gpsIdx + 1;
    end
    
    % Estimate state as weighted mean
    xPF(:, k) = sum(particles .* weights, 2);
    xPF(3, k) = wrapToPi(xPF(3, k));
end
pfTime = toc;

fprintf('  Particle Filter implementation completed\n');
fprintf('  Processing time: %.4f seconds\n', pfTime);
fprintf('  Number of particles: %d\n', numParticles);

%% Step 7: Compute performance metrics
fprintf('\nStep 7: Computing performance metrics...\n');

% Position RMSE
errorEKF = xTrue - xEKF;
errorUKF = xTrue - xUKF;
errorPF = xTrue - xPF;

% Wrap angle errors
errorEKF(3, :) = wrapToPi(errorEKF(3, :));
errorUKF(3, :) = wrapToPi(errorUKF(3, :));
errorPF(3, :) = wrapToPi(errorPF(3, :));

% Position RMSE (x, y)
rmseEKF_pos = sqrt(mean(errorEKF(1, :).^2 + errorEKF(2, :).^2));
rmseUKF_pos = sqrt(mean(errorUKF(1, :).^2 + errorUKF(2, :).^2));
rmsePF_pos = sqrt(mean(errorPF(1, :).^2 + errorPF(2, :).^2));

% Orientation RMSE
rmseEKF_theta = sqrt(mean(errorEKF(3, :).^2));
rmseUKF_theta = sqrt(mean(errorUKF(3, :).^2));
rmsePF_theta = sqrt(mean(errorPF(3, :).^2));

fprintf('  EKF Position RMSE: %.4f m\n', rmseEKF_pos);
fprintf('  UKF Position RMSE: %.4f m\n', rmseUKF_pos);
fprintf('  PF Position RMSE: %.4f m\n', rmsePF_pos);

fprintf('  EKF Orientation RMSE: %.4f rad\n', rmseEKF_theta);
fprintf('  UKF Orientation RMSE: %.4f rad\n', rmseUKF_theta);
fprintf('  PF Orientation RMSE: %.4f rad\n', rmsePF_theta);

%% Step 8: Visualisation
fprintf('\nStep 8: Generating visualisations...\n');

figure('Name', 'Multi-Sensor Fusion Comparison', ...
    'Position', [100, 100, 1400, 900]);

% Trajectory comparison
subplot(2, 3, 1);
plot(xTrue(1, :), xTrue(2, :), 'k-', 'LineWidth', 2, 'DisplayName', 'Ground Truth');
hold on;
plot(xEKF(1, :), xEKF(2, :), 'r-', 'LineWidth', 1.5, 'DisplayName', 'EKF');
plot(xUKF(1, :), xUKF(2, :), 'b-', 'LineWidth', 1.5, 'DisplayName', 'UKF');
plot(xPF(1, :), xPF(2, :), 'g-', 'LineWidth', 1.5, 'DisplayName', 'PF');
plot(gpsMeasurements(1, :), gpsMeasurements(2, :), 'm.', ...
    'MarkerSize', 8, 'DisplayName', 'GPS');
xlabel('X Position (m)', 'Interpreter', 'latex');
ylabel('Y Position (m)', 'Interpreter', 'latex');
title('Trajectory Comparison', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
axis equal;
hold off;

% Position error over time
subplot(2, 3, 2);
posErrorEKF = sqrt(errorEKF(1, :).^2 + errorEKF(2, :).^2);
posErrorUKF = sqrt(errorUKF(1, :).^2 + errorUKF(2, :).^2);
posErrorPF = sqrt(errorPF(1, :).^2 + errorPF(2, :).^2);

plot(timeSteps, posErrorEKF, 'r-', 'LineWidth', 1.5, 'DisplayName', 'EKF');
hold on;
plot(timeSteps, posErrorUKF, 'b-', 'LineWidth', 1.5, 'DisplayName', 'UKF');
plot(timeSteps, posErrorPF, 'g-', 'LineWidth', 1.5, 'DisplayName', 'PF');
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Position Error (m)', 'Interpreter', 'latex');
title('Position Error Over Time', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Orientation error over time
subplot(2, 3, 3);
plot(timeSteps, abs(errorEKF(3, :)), 'r-', 'LineWidth', 1.5, 'DisplayName', 'EKF');
hold on;
plot(timeSteps, abs(errorUKF(3, :)), 'b-', 'LineWidth', 1.5, 'DisplayName', 'UKF');
plot(timeSteps, abs(errorPF(3, :)), 'g-', 'LineWidth', 1.5, 'DisplayName', 'PF');
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Orientation Error (rad)', 'Interpreter', 'latex');
title('Orientation Error Over Time', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% RMSE comparison
subplot(2, 3, 4);
methods = {'EKF', 'UKF', 'PF'};
rmsePos = [rmseEKF_pos, rmseUKF_pos, rmsePF_pos];
bar(rmsePos);
set(gca, 'XTickLabel', methods);
ylabel('Position RMSE (m)', 'Interpreter', 'latex');
title('Position Estimation Accuracy', 'Interpreter', 'latex');
grid on;

% Computational time comparison
subplot(2, 3, 5);
compTimes = [ekfTime, ukfTime, pfTime];
bar(compTimes);
set(gca, 'XTickLabel', methods);
ylabel('Processing Time (s)', 'Interpreter', 'latex');
title('Computational Efficiency', 'Interpreter', 'latex');
grid on;

% EKF uncertainty ellipses (at selected time steps)
subplot(2, 3, 6);
plot(xTrue(1, :), xTrue(2, :), 'k-', 'LineWidth', 1.5, 'DisplayName', 'Ground Truth');
hold on;
plot(xEKF(1, :), xEKF(2, :), 'r-', 'LineWidth', 1.2, 'DisplayName', 'EKF Estimate');

% Draw uncertainty ellipses at regular intervals
ellipseSteps = 1:100:numSteps;
for idx = ellipseSteps
    P = PEKF_history(1:2, 1:2, idx);
    plotUncertaintyEllipse(xEKF(1:2, idx), P, 'r', 0.2);
end

xlabel('X Position (m)', 'Interpreter', 'latex');
ylabel('Y Position (m)', 'Interpreter', 'latex');
title('EKF Uncertainty Propagation', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
axis equal;
hold off;

suptitle('Sensor Fusion Architecture Comparison', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 6 completed successfully.\n');

%% Helper Functions

function plotUncertaintyEllipse(mu, Sigma, color, alpha)
    % Plot 2-sigma uncertainty ellipse
    
    [eigVec, eigVal] = eig(Sigma);
    
    % 95% confidence (2-sigma)
    chiSquared = 5.991;
    
    angle = 0:0.1:2*pi;
    circle = [cos(angle); sin(angle)];
    
    ellipse = eigVec * sqrt(eigVal * chiSquared) * circle + mu;
    
    fill(ellipse(1, :), ellipse(2, :), color, 'FaceAlpha', alpha, ...
        'EdgeColor', 'none', 'HandleVisibility', 'off');
end
