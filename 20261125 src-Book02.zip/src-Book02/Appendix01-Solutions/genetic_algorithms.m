%% genetic_algorithms.m
% Global Optimisation with Genetic Algorithms
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : genetic_algorithms
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem8.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Define Rastrigin function
rastrigin = @(x) 20 + x(1)^2 + x(2)^2 - 10*(cos(2pix(1)) + cos(2pix(2)));

% Visualise the function landscape
[X, Y] = meshgrid(linspace(-5.12, 5.12, 200), linspace(-5.12, 5.12, 200));
Z = zeros(size(X));

for i = 1:size(X, 1)
for j = 1:size(X, 2)
Z(i, j) = 20 + X(i,j)^2 + Y(i,j)^2 - 10*(cos(2piX(i,j)) + cos(2piY(i,j)));
end
end

figure;
surf(X, Y, Z);
colormap('jet');
xlabel('x_1');
ylabel('x_2');
zlabel('f(x_1, x_2)');
title('Rastrigin Function');

figure;
contour(X, Y, Z, 50);
colormap('jet');
colorbar;
xlabel('x_1');
ylabel('x_2');
title('Rastrigin Function Contour Plot');
hold on;

% Domain bounds
lb = [-5.12; -5.12];
ub = [5.12; 5.12];

% Global optimisation using Genetic Algorithm
fprintf('Applying Genetic Algorithm to find global minimum...\n');

options_ga = optimoptions('ga', ...
'Display', 'iter', ...
'PopulationSize', 100, ...
'MaxGenerations', 100, ...
'PlotFcn', @gaplotbestf, ...
'FunctionTolerance', 1e-6);

tic;
[x_ga, fval_ga, exitflag_ga, output_ga] = ga(rastrigin, 2, [], [], [], [], lb, ub, [], options_ga);
time_ga = toc;

fprintf('\nGenetic Algorithm Results:\n');
fprintf('Minimum found at x = [%.10f, %.10f]\n', x_ga(1), x_ga(2));
fprintf('Function value = %.10f\n', fval_ga);
fprintf('Generations = %d\n', output_ga.generations);
fprintf('Function evaluations = %d\n', output_ga.funccount);
fprintf('Computation time = %.4f seconds\n', time_ga);

% Mark the GA solution on the contour plot
plot(x_ga(1), x_ga(2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r', 'DisplayName', 'GA Solution');

% Use gradient-based optimisation (fminunc) with multiple starting points
fprintf('\nApplying gradient-based optimisation with multiple starting points...\n');

options_fminunc = optimoptions('fminunc', ...
'Display', 'off', ...
'Algorithm', 'quasi-newton', ...
'OptimalityTolerance', 1e-6);

% Generate a grid of starting points
[X0, Y0] = meshgrid(linspace(-5, 5, 5), linspace(-5, 5, 5));
starting_points = [X0(:), Y0(:)];
n_points = size(starting_points, 1);

fminunc_results = zeros(n_points, 3); % [x1, x2, fval]
func_evals_total = 0;

tic;
for i = 1:n_points
x0 = starting_points(i, :)';
[x_fminunc, fval_fminunc, ~, output_fminunc] = fminunc(rastrigin, x0, options_fminunc);

fminunc_results(i, :) = [x_fminunc', fval_fminunc];
func_evals_total = func_evals_total + output_fminunc.funcCount;

% Plot the local minima found
plot(x_fminunc(1), x_fminunc(2), 'go', 'MarkerSize', 5, 'DisplayName', 'Local Minimum');

end
time_fminunc = toc;

% Find the best local minimum
[min_fval, min_idx] = min(fminunc_results(:, 3));
best_local_min = fminunc_results(min_idx, 1:2);

fprintf('\nGradient-Based Optimisation Results:\n');
fprintf('Best local minimum found at x = [%.10f, %.10f]\n', best_local_min(1), best_local_min(2));
fprintf('Function value = %.10f\n', min_fval);
fprintf('Starting points = %d\n', n_points);
fprintf('Total function evaluations = %d\n', func_evals_total);
fprintf('Average evaluations per start = %.1f\n', func_evals_total / n_points);
fprintf('Computation time = %.4f seconds\n', time_fminunc);

% Highlight the best local minimum
plot(best_local_min(1), best_local_min(2), 'mo', 'MarkerSize', 10, 'MarkerFaceColor', 'm', 'DisplayName', 'Best Local Min');

% Plot the true global minimum
plot(0, 0, 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'k', 'DisplayName', 'True Global Min');

% Add starting points to the plot
plot(starting_points(:, 1), starting_points(:, 2), 'bx', 'MarkerSize', 8, 'DisplayName', 'Starting Points');

legend('show', 'Location', 'northeastoutside');
grid on;

% Compare results with known global minimum
fprintf('\nComparison with Known Global Minimum:\n');
fprintf('True global minimum: x = [0, 0], f(x) = 0\n');
fprintf('GA accuracy: %.10f\n', norm([x_ga(1), x_ga(2)]));
fprintf('Best local min accuracy: %.10f\n', norm([best_local_min(1), best_local_min(2)]));

% GA Parameter Exploration
fprintf('\nExploring the effect of GA parameters...\n');

population_sizes = [20, 50, 100, 200];
results_vs_popsize = zeros(length(population_sizes), 5); % [popsize, fval, generations, funcevals, time]

for i = 1:length(population_sizes)
pop_size = population_sizes(i);
options = optimoptions('ga', ...
'Display', 'off', ...
'PopulationSize', pop_size, ...
'MaxGenerations', 100, ...
'FunctionTolerance', 1e-6);

tic;
[x_tmp, fval_tmp, ~, output_tmp] = ga(rastrigin, 2, [], [], [], [], lb, ub, [], options);
time_tmp = toc;

results_vs_popsize(i, :) = [pop_size, fval_tmp, output_tmp.generations, output_tmp.funccount, time_tmp];

fprintf('Population size = %d: fval = %.10f, generations = %d, evaluations = %d, time = %.4f s\n', ...
    pop_size, fval_tmp, output_tmp.generations, output_tmp.funccount, time_tmp);
    
    end

% Plot the effect of population size
figure;
subplot(2,2,1);
plot(results_vs_popsize(:,1), results_vs_popsize(:,2), 'o-', 'LineWidth', 1.5);
xlabel('Population Size');
ylabel('Best Function Value');
title('Effect of Population Size on Solution Quality');
grid on;

subplot(2,2,2);
plot(results_vs_popsize(:,1), results_vs_popsize(:,3), 'o-', 'LineWidth', 1.5);
xlabel('Population Size');
ylabel('Generations');
title('Effect of Population Size on Convergence Speed');
grid on;

subplot(2,2,3);
plot(results_vs_popsize(:,1), results_vs_popsize(:,4), 'o-', 'LineWidth', 1.5);
xlabel('Population Size');
ylabel('Function Evaluations');
title('Effect of Population Size on Computational Cost');
grid on;

subplot(2,2,4);
plot(results_vs_popsize(:,1), results_vs_popsize(:,5), 'o-', 'LineWidth', 1.5);
xlabel('Population Size');
ylabel('Computation Time (s)');
title('Effect of Population Size on Runtime');
grid on;

% Run multiple trials to assess reliability
fprintf('\nAssessing reliability with multiple trials...\n');

n_trials = 10;
ga_results = zeros(n_trials, 3); % [norm of x, fval, time]
fminunc_results_multi = zeros(n_trials, 3); % [norm of best x, best fval, time]

options_ga_trials = optimoptions('ga', 'Display', 'off', 'PopulationSize', 100, 'MaxGenerations', 100);

for i = 1:n_trials
% GA trial
tic;
[x_ga_trial, fval_ga_trial] = ga(rastrigin, 2, [], [], [], [], lb, ub, [], options_ga_trials);
time_ga_trial = toc;
ga_results(i, :) = [norm(x_ga_trial), fval_ga_trial, time_ga_trial];

% Gradient-based with multiple starts trial
tic;
fvals = zeros(n_points, 1);
x_results = zeros(n_points, 2);

for j = 1:n_points
    x0 = starting_points(j, :)';
    [x_tmp, fval_tmp] = fminunc(rastrigin, x0, options_fminunc);
    fvals(j) = fval_tmp;
    x_results(j, :) = x_tmp';
end

[best_fval, best_idx] = min(fvals);
best_x = x_results(best_idx, :);
time_fminunc_trial = toc;

fminunc_results_multi(i, :) = [norm(best_x), best_fval, time_fminunc_trial];

end

% Display reliability statistics
fprintf('\nReliability Statistics Over %d Trials:\n', n_trials);
fprintf(' Mean Std Dev Min Max\n');
fprintf('GA Solution Error: %.6f %.6f %.6f %.6f\n', ...
mean(ga_results(:,1)), std(ga_results(:,1)), min(ga_results(:,1)), max(ga_results(:,1)));
fprintf('GA Function Value: %.6f %.6f %.6f %.6f\n', ...
mean(ga_results(:,2)), std(ga_results(:,2)), min(ga_results(:,2)), max(ga_results(:,2)));
fprintf('GA Time (s): %.6f %.6f %.6f %.6f\n', ...
mean(ga_results(:,3)), std(ga_results(:,3)), min(ga_results(:,3)), max(ga_results(:,3)));

fprintf('\n');
fprintf('fminunc Error: %.6f %.6f %.6f %.6f\n', ...
mean(fminunc_results_multi(:,1)), std(fminunc_results_multi(:,1)), ...
min(fminunc_results_multi(:,1)), max(fminunc_results_multi(:,1)));
fprintf('fminunc Func Value: %.6f %.6f %.6f %.6f\n', ...
mean(fminunc_results_multi(:,2)), std(fminunc_results_multi(:,2)), ...
min(fminunc_results_multi(:,2)), max(fminunc_results_multi(:,2)));
fprintf('fminunc Time (s): %.6f %.6f %.6f %.6f\n', ...
mean(fminunc_results_multi(:,3)), std(fminunc_results_multi(:,3)), ...
min(fminunc_results_multi(:,3)), max(fminunc_results_multi(:,3)));
