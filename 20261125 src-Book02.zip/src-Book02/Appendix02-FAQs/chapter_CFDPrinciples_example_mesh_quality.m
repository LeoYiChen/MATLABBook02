%% chapter_CFDPrinciples_example_mesh_quality.m
% Comprehensive mesh quality analysis and reporting.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_mesh_quality
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function meshQualityReport = assessMeshQuality(meshCoordinates, ...
    meshConnectivity, boundaryInfo, qualityThresholds)
    % ASSESSMESHQUALITY Comprehensive mesh quality evaluation
    % Computes orthogonality, aspect ratio, skewness, and boundary layer metrics
    %
    % Inputs:
    %   meshCoordinates  - N뿯½뿯½3 matrix of node coordinates [x,y,z]
    %   meshConnectivity - Cell array defining element connectivity
    %   boundaryInfo     - Struct with boundary node identification
    %   qualityThresholds- Struct defining acceptable quality ranges
    %
    % Output:
    %   meshQualityReport - Comprehensive quality assessment
    %
    % Author: Dr Leo Chen
    % Institution: University of Oxford
    % Version: 3.0
    %
    % References:
    %   [1] Ferziger & Peric (2002) Computational Methods for Fluid Dynamics
    %   [2] Blazek (2015) CFD: Principles and Applications
    
    fprintf('=== Mesh Quality Assessment ===\n\n');
    
    % Initialise quality report structure
    meshQualityReport = struct();
    meshQualityReport.timestamp = datetime('now');
    meshQualityReport.numNodes = size(meshCoordinates, 1);
    meshQualityReport.numElements = length(meshConnectivity);
    
    % Compute element-wise quality metrics
    fprintf('Computing element-wise quality metrics...\n');
    orthogonality = computeOrthogonality(meshCoordinates, meshConnectivity);
    aspectRatio = computeAspectRatio(meshCoordinates, meshConnectivity);
    skewness = computeSkewness(meshCoordinates, meshConnectivity);
    
    meshQualityReport.orthogonality = orthogonality;
    meshQualityReport.aspectRatio = aspectRatio;
    meshQualityReport.skewness = skewness;
    
    % Statistical summary
    meshQualityReport.statistics = struct();
    meshQualityReport.statistics.orthogonality = computeStatistics(orthogonality);
    meshQualityReport.statistics.aspectRatio = computeStatistics(aspectRatio);
    meshQualityReport.statistics.skewness = computeStatistics(skewness);
    
    % Quality classification
    [classification, passRate] = classifyMeshQuality(meshQualityReport.statistics, ...
                                                     qualityThresholds);
    meshQualityReport.classification = classification;
    meshQualityReport.passRate = passRate;
    
    % Boundary layer assessment
    if isfield(boundaryInfo, 'wallBoundaryNodes')
        fprintf('Assessing boundary layer resolution...\n');
        boundaryLayerMetrics = assessBoundaryLayer(meshCoordinates, ...
                                                    meshConnectivity, ...
                                                    boundaryInfo);
        meshQualityReport.boundaryLayer = boundaryLayerMetrics;
    end
    
    % Identify problem regions
    problemElements = identifyProblemElements(meshQualityReport, qualityThresholds);
    meshQualityReport.problemElements = problemElements;
    
    % Generate quality visualisations
    visualiseMeshQuality(meshQualityReport, meshCoordinates, meshConnectivity);
    
    % Display summary report
    displayQualitySummary(meshQualityReport);
    
    fprintf('\nMesh quality assessment completed.\n');
end

function ortho = computeOrthogonality(coords, connectivity)
    % Compute orthogonality for each element
    
    numElements = length(connectivity);
    ortho = zeros(numElements, 1);
    
    for elemIdx = 1:numElements
        % Get element nodes
        elemNodes = connectivity{elemIdx};
        elemCoords = coords(elemNodes, :);
        
        % Compute element centroid
        centroid = mean(elemCoords, 1);
        
        % For each face, compute orthogonality
        numFaces = size(elemCoords, 1);
        faceOrtho = zeros(numFaces, 1);
        
        for faceIdx = 1:numFaces
            % Face nodes (cycling)
            nextIdx = mod(faceIdx, numFaces) + 1;
            faceNodes = [faceIdx, nextIdx];
            faceCentroid = mean(elemCoords(faceNodes, :), 1);
            
            % Distance vector from element centroid to face centroid
            d_f = faceCentroid - centroid;
            
            % Face area vector (normal)
            if size(elemCoords, 2) == 2  % 2D case
                edge = elemCoords(nextIdx, :) - elemCoords(faceIdx, :);
                S_f = [-edge(2), edge(1)];  % Perpendicular in 2D
            else  % 3D case (simplified for demonstration)
                S_f = [0, 0, 1];  % Would require proper normal computation
            end
            
            % Orthogonality measure
            if norm(d_f) > 0 && norm(S_f) > 0
                faceOrtho(faceIdx) = abs(dot(d_f, S_f)) / (norm(d_f) * norm(S_f));
            else
                faceOrtho(faceIdx) = 1;
            end
        end
        
        % Minimum orthogonality for element
        ortho(elemIdx) = min(faceOrtho);
    end
end

function AR = computeAspectRatio(coords, connectivity)
    % Compute aspect ratio for each element
    
    numElements = length(connectivity);
    AR = zeros(numElements, 1);
    
    for elemIdx = 1:numElements
        elemNodes = connectivity{elemIdx};
        elemCoords = coords(elemNodes, :);
        
        % Compute all edge lengths
        numNodes = length(elemNodes);
        edgeLengths = zeros(numNodes, 1);
        
        for i = 1:numNodes
            nextIdx = mod(i, numNodes) + 1;
            edgeVector = elemCoords(nextIdx, :) - elemCoords(i, :);
            edgeLengths(i) = norm(edgeVector);
        end
        
        % Aspect ratio = max length / min length
        AR(elemIdx) = max(edgeLengths) / min(edgeLengths);
    end
end

function skew = computeSkewness(coords, connectivity)
    % Compute skewness for each element
    
    numElements = length(connectivity);
    skew = zeros(numElements, 1);
    
    for elemIdx = 1:numElements
        elemNodes = connectivity{elemIdx};
        elemCoords = coords(elemNodes, :);
        numNodes = length(elemNodes);
        
        % Compute angles at each vertex
        angles = zeros(numNodes, 1);
        
        for i = 1:numNodes
            prevIdx = mod(i - 2, numNodes) + 1;
            nextIdx = mod(i, numNodes) + 1;
            
            % Vectors from current node to previous and next
            v1 = elemCoords(prevIdx, :) - elemCoords(i, :);
            v2 = elemCoords(nextIdx, :) - elemCoords(i, :);
            
            % Angle between vectors
            cosAngle = dot(v1, v2) / (norm(v1) * norm(v2));
            cosAngle = max(-1, min(1, cosAngle));  % Clamp to valid range
            angles(i) = acosd(cosAngle);
        end
        
        % Equiangular value for polygon
        theta_equi = (numNodes - 2) * 180 / numNodes;
        
        % Equiangle skew
        maxDev = max((angles - theta_equi) / (180 - theta_equi));
        minDev = max((theta_equi - angles) / theta_equi);
        
        skew(elemIdx) = max(maxDev, minDev);
    end
end

function stats = computeStatistics(values)
    % Compute statistical summary of quality metric
    
    stats = struct();
    stats.min = min(values);
    stats.max = max(values);
    stats.mean = mean(values);
    stats.median = median(values);
    stats.std = std(values);
    stats.p05 = prctile(values, 5);
    stats.p95 = prctile(values, 95);
end

function [classification, passRate] = classifyMeshQuality(statistics, thresholds)
    % Classify overall mesh quality
    
    classification = struct();
    
    % Orthogonality assessment
    if statistics.orthogonality.min >= thresholds.orthogonality.excellent
        classification.orthogonality = 'Excellent';
    elseif statistics.orthogonality.min >= thresholds.orthogonality.good
        classification.orthogonality = 'Good';
    elseif statistics.orthogonality.min >= thresholds.orthogonality.acceptable
        classification.orthogonality = 'Acceptable';
    else
        classification.orthogonality = 'Poor';
    end
    
    % Aspect ratio assessment
    if statistics.aspectRatio.max <= thresholds.aspectRatio.excellent
        classification.aspectRatio = 'Excellent';
    elseif statistics.aspectRatio.max <= thresholds.aspectRatio.good
        classification.aspectRatio = 'Good';
    elseif statistics.aspectRatio.max <= thresholds.aspectRatio.acceptable
        classification.aspectRatio = 'Acceptable';
    else
        classification.aspectRatio = 'Poor';
    end
    
    % Skewness assessment
    if statistics.skewness.max <= thresholds.skewness.excellent
        classification.skewness = 'Excellent';
    elseif statistics.skewness.max <= thresholds.skewness.good
        classification.skewness = 'Good';
    elseif statistics.skewness.max <= thresholds.skewness.acceptable
        classification.skewness = 'Acceptable';
    else
        classification.skewness = 'Poor';
    end
    
    % Overall pass rate (percentage of metrics meeting acceptable threshold)
    passCount = 0;
    if strcmp(classification.orthogonality, 'Excellent') || ...
       strcmp(classification.orthogonality, 'Good') || ...
       strcmp(classification.orthogonality, 'Acceptable')
        passCount = passCount + 1;
    end
    
    if strcmp(classification.aspectRatio, 'Excellent') || ...
       strcmp(classification.aspectRatio, 'Good') || ...
       strcmp(classification.aspectRatio, 'Acceptable')
        passCount = passCount + 1;
    end
    
    if strcmp(classification.skewness, 'Excellent') || ...
       strcmp(classification.skewness, 'Good') || ...
       strcmp(classification.skewness, 'Acceptable')
        passCount = passCount + 1;
    end
    
    passRate = 100 * passCount / 3;
end

function problemElems = identifyProblemElements(qualityReport, thresholds)
    % Identify elements failing quality criteria
    
    problemElems = struct();
    
    % Poor orthogonality elements
    orthoFail = find(qualityReport.orthogonality < thresholds.orthogonality.acceptable);
    problemElems.poorOrthogonality = orthoFail;
    problemElems.numPoorOrthogonality = length(orthoFail);
    
    % High aspect ratio elements
    ARfail = find(qualityReport.aspectRatio > thresholds.aspectRatio.acceptable);
    problemElems.highAspectRatio = ARfail;
    problemElems.numHighAspectRatio = length(ARfail);
    
    % High skewness elements
    skewFail = find(qualityReport.skewness > thresholds.skewness.acceptable);
    problemElems.highSkewness = skewFail;
    problemElems.numHighSkewness = length(skewFail);
    
    % Total problem elements (union)
    allProblemElems = unique([orthoFail; ARfail; skewFail]);
    problemElems.totalProblemElements = length(allProblemElems);
    problemElems.percentageProblem = 100 * length(allProblemElems) / ...
                                     qualityReport.numElements;
end

function visualiseMeshQuality(qualityReport, coords, connectivity)
    % Generate mesh quality visualisations
    
    figure('Name', 'Mesh Quality Assessment', 'Position', [100, 100, 1400, 900]);
    
    % Orthogonality distribution
    subplot(2, 3, 1);
    histogram(qualityReport.orthogonality, 50, 'FaceAlpha', 0.7);
    xlabel('Orthogonality', 'Interpreter', 'latex');
    ylabel('Frequency', 'Interpreter', 'latex');
    title('Orthogonality Distribution', 'Interpreter', 'latex');
    grid on;
    
    % Aspect ratio distribution (log scale)
    subplot(2, 3, 2);
    histogram(log10(qualityReport.aspectRatio), 50, 'FaceAlpha', 0.7);
    xlabel('$\log_{10}$(Aspect Ratio)', 'Interpreter', 'latex');
    ylabel('Frequency', 'Interpreter', 'latex');
    title('Aspect Ratio Distribution', 'Interpreter', 'latex');
    grid on;
    
    % Skewness distribution
    subplot(2, 3, 3);
    histogram(qualityReport.skewness, 50, 'FaceAlpha', 0.7);
    xlabel('Skewness', 'Interpreter', 'latex');
    ylabel('Frequency', 'Interpreter', 'latex');
    title('Skewness Distribution', 'Interpreter', 'latex');
    grid on;
    
    % Box plots for comparison
    subplot(2, 3, 4);
    boxplot([qualityReport.orthogonality, qualityReport.aspectRatio/100, ...
             qualityReport.skewness], ...
            'Labels', {'Ortho.', 'AR/100', 'Skew'});
    ylabel('Normalised Value', 'Interpreter', 'latex');
    title('Quality Metrics Comparison', 'Interpreter', 'latex');
    grid on;
    
    % Spatial distribution of poor elements (if 2D coordinates provided)
    if size(coords, 2) >= 2
        subplot(2, 3, 5);
        scatter(coords(:, 1), coords(:, 2), 10, qualityReport.skewness, 'filled');
        colorbar;
        xlabel('x', 'Interpreter', 'latex');
        ylabel('y', 'Interpreter', 'latex');
        title('Skewness Spatial Distribution', 'Interpreter', 'latex');
        axis equal tight;
    end
    
    % Summary statistics table (as text)
    subplot(2, 3, 6);
    axis off;
    summaryText = sprintf('Mesh Quality Summary\n\n');
    summaryText = [summaryText sprintf('Elements: %d\n', qualityReport.numElements)];
    summaryText = [summaryText sprintf('Classification: %s\n', ...
                                       qualityReport.classification.orthogonality)];
    summaryText = [summaryText sprintf('Pass Rate: %.1f%%\n', qualityReport.passRate)];
    text(0.1, 0.5, summaryText, 'FontSize', 11, 'VerticalAlignment', 'middle');
    
    sgtitle('Mesh Quality Assessment Report', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
end

function displayQualitySummary(qualityReport)
    % Display mesh quality summary
    
    fprintf('\n=== Mesh Quality Summary ===\n');
    fprintf('Elements: %d\n', qualityReport.numElements);
    fprintf('Nodes: %d\n\n', qualityReport.numNodes);
    
    fprintf('Orthogonality:\n');
    fprintf('  Min: %.4f\n', qualityReport.statistics.orthogonality.min);
    fprintf('  Mean: %.4f\n', qualityReport.statistics.orthogonality.mean);
    fprintf('  Classification: %s\n\n', qualityReport.classification.orthogonality);
    
    fprintf('Aspect Ratio:\n');
    fprintf('  Max: %.2f\n', qualityReport.statistics.aspectRatio.max);
    fprintf('  Mean: %.2f\n', qualityReport.statistics.aspectRatio.mean);
    fprintf('  Classification: %s\n\n', qualityReport.classification.aspectRatio);
    
    fprintf('Skewness:\n');
    fprintf('  Max: %.4f\n', qualityReport.statistics.skewness.max);
    fprintf('  Mean: %.4f\n', qualityReport.statistics.skewness.mean);
    fprintf('  Classification: %s\n\n', qualityReport.classification.skewness);
    
    fprintf('Problem Elements: %d (%.2f%%)\n', ...
            qualityReport.problemElements.totalProblemElements, ...
            qualityReport.problemElements.percentageProblem);
    
    fprintf('\nOverall Pass Rate: %.1f%%\n', qualityReport.passRate);
end

function blMetrics = assessBoundaryLayer(coords, connectivity, boundaryInfo)
    % Assess boundary layer mesh resolution
    % This is a simplified placeholder demonstration
    
    blMetrics = struct();
    blMetrics.estimatedYplus = NaN;  % Would require flow solution
    blMetrics.firstCellHeight = NaN;  % Would require wall-normal distance
    blMetrics.growthRate = NaN;       % Would require layer-by-layer analysis
    
    % In production code, this would compute actual boundary layer metrics
    fprintf('  Note: Boundary layer assessment requires flow solution.\n');
end
