%% chapter_AI_Mechanics_Problem9_mcmc_syntax.m
% Metropolis-Hastings MCMC implementation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem9_mcmc_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Metropolis-Hastings MCMC for Bayesian parameter identification
% logPosterior: function handle returning log p(theta | data)
% theta0: initial parameter vector [C10; C01]
% numSamples: total MCMC iterations
% proposalStd: standard deviation for Gaussian random walk proposal

function [samples, acceptRate] = metropolisHastings(logPosterior, theta0, ...
                                                     numSamples, proposalStd)
    numParams = length(theta0);
    samples = zeros(numSamples, numParams);
    samples(1, :) = theta0;
    
    numAccepted = 0;
    currentLogPost = logPosterior(theta0);
    
    for i = 2:numSamples
        % Propose new parameters (random walk)
        thetaProposed = samples(i-1, :)' + proposalStd * randn(numParams, 1);
        
        % Enforce positivity (log-transform alternative: sample in log-space)
        if any(thetaProposed <= 0)
            samples(i, :) = samples(i-1, :);
            continue;
        end
        
        % Compute log-posterior at proposed point
        proposedLogPost = logPosterior(thetaProposed);
        
        % Acceptance ratio (in log-space for numerical stability)
        logAlpha = proposedLogPost - currentLogPost;
        
        % Accept/reject
        if log(rand()) < logAlpha
            samples(i, :) = thetaProposed';
            currentLogPost = proposedLogPost;
            numAccepted = numAccepted + 1;
        else
            samples(i, :) = samples(i-1, :);
        end
        
        % Progress indicator
        if mod(i, numSamples/10) == 0
            fprintf('  MCMC progress: %d/%d (%.1f%%)\n', i, numSamples, 100*i/numSamples);
        end
    end
    
    acceptRate = numAccepted / numSamples;
end
