%% chapter_AI_Mechanics_Problem8_complete_code.m
% Complete LSTM time series forecasting system.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem8_complete_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 8: Time Series Forecasting of SHM Data Using LSTM
% Author: Dr Yi Chen
% Date: 2024-01-20
% Version: 2.1
% MATLAB Version: R2023b
% Description: Multi-step forecasting with attention, anomaly detection

clear; clc; close all;

fprintf('=== Problem 8: LSTM Time Series Forecasting ===\n\n');

%% Synthetic Data Generation (Simulating Bridge Strain Monitoring)

rng(42);  % Reproducibility

numSamples = 8760;  % 1 year hourly data
numChannels = 8;    % 8 sensor locations
t = (1:numSamples)';

fprintf('Generating synthetic SHM data...\n');
fprintf('  Duration: %d hours (%.1f days)\n', numSamples, numSamples/24);
fprintf('  Channels: %d strain sensors\n\n', numChannels);

% Baseline strain from dead load
baseline = 100;  % microstrains

% Traffic loading (daily cycle with AM/PM peaks)
trafficPattern = 50 * (sin(2*pi*t/24 - pi/2) + 1) .* ...
                 (0.3 + 0.7*sin(2*pi*t/(24*7)));  % Weekly modulation

% Temperature effect (daily + seasonal)
tempEffect = 30 * sin(2*pi*t/24) + 40 * sin(2*pi*t/(24*365));

% Long-term degradation (crack growth)
degradation = 0.01 * t;

% Construct multi-channel data with spatial correlation
data = zeros(numSamples, numChannels);
for ch = 1:numChannels
    spatialFactor = 0.8 + 0.4 * rand();  % Random amplitude
    phaseLag = rand() * 2*pi;             % Random phase
    
    data(:, ch) = baseline * spatialFactor + ...
                  trafficPattern * spatialFactor .* cos(phaseLag) + ...
                  tempEffect * 0.5 * spatialFactor + ...
                  degradation + ...
                  5 * randn(numSamples, 1);  % Measurement noise
end

% Inject anomalies (simulating crack events)
anomalyIndices = [3500, 5200, 7800];
for idx = anomalyIndices
    data(idx:idx+50, :) = data(idx:idx+50, :) + 40 * exp(-(0:50)'/10);
end

fprintf('Anomalies injected at hours: %s\n\n', mat2str(anomalyIndices));

%% Preprocessing

% Normalisation
dataMin = min(data, [], 1);
dataMax = max(data, [], 1);
dataNorm = (data - dataMin) ./ (dataMax - dataMin + 1e-8);

% Train-validation-test split (chronological)
trainRatio = 0.70;
valRatio = 0.15;
testRatio = 0.15;

trainEnd = floor(trainRatio * numSamples);
valEnd = floor((trainRatio + valRatio) * numSamples);

dataTrain = dataNorm(1:trainEnd, :);
dataVal = dataNorm(trainEnd+1:valEnd, :);
dataTest = dataNorm(valEnd+1:end, :);

fprintf('Data split:\n');
fprintf('  Training: %d samples (%.1f%%)\n', size(dataTrain,1), 100*trainRatio);
fprintf('  Validation: %d samples (%.1f%%)\n', size(dataVal,1), 100*valRatio);
fprintf('  Test: %d samples (%.1f%%)\n\n', size(dataTest,1), 100*testRatio);

%% Sequence Generation

lookback = 168;   % 7 days input
horizon = 168;    % 7 days forecast

fprintf('Sequence windowing:\n');
fprintf('  Lookback: %d hours (%.1f days)\n', lookback, lookback/24);
fprintf('  Forecast horizon: %d hours (%.1f days)\n\n', horizon, horizon/24);

% Create sequences
[XTrain, YTrain] = createSequences(dataTrain, lookback, horizon);
[XVal, YVal] = createSequences(dataVal, lookback, horizon);
[XTest, YTest] = createSequences(dataTest, lookback, horizon);

fprintf('Created %d training sequences\n', length(XTrain));
fprintf('Created %d validation sequences\n', length(XVal));
fprintf('Created %d test sequences\n\n', length(XTest));

%% LSTM Network Architecture

numFeatures = numChannels;
numHiddenUnits = 128;
numResponses = horizon;

fprintf('Building LSTM network...\n');
fprintf('  Architecture: Bi-LSTM(128) -> Dropout(0.2) -> Bi-LSTM(128) -> FC(%d)\n', numResponses);
fprintf('  Parameters: ~%.1fM\n\n', (numHiddenUnits*numFeatures*4 + numHiddenUnits^2*8 + numHiddenUnits*numResponses)/1e6);

layers = [
    sequenceInputLayer(numFeatures, 'Name', 'input')
    
    bilstmLayer(numHiddenUnits, 'OutputMode', 'sequence', 'Name', 'bilstm1')
    dropoutLayer(0.2, 'Name', 'dropout1')
    
    bilstmLayer(numHiddenUnits, 'OutputMode', 'last', 'Name', 'bilstm2')
    dropoutLayer(0.2, 'Name', 'dropout2')
    
    fullyConnectedLayer(numResponses, 'Name', 'fc_output')
    regressionLayer('Name', 'regression')
];

options = trainingOptions('adam', ...
    'MaxEpochs', 50, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 1e-3, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 15, ...
    'LearnRateDropFactor', 0.5, ...
    'GradientThreshold', 1, ...
    'ValidationData', {XVal, YVal}, ...
    'ValidationFrequency', 30, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'none');

%% Training

fprintf('Training LSTM network...\n');
tic;
net = trainNetwork(XTrain, YTrain, layers, options);
trainingTime = toc;
fprintf('  Training completed in %.2f seconds\n\n', trainingTime);

%% Evaluation on Test Set

fprintf('Evaluating on test set...\n');

YPred_lstm = predict(net, XTest);

% Convert cell array predictions to matrix
YPred_mat = cell2mat(YPred_lstm');
YTest_mat = cell2mat(YTest');

% Denormalise
YPred_denorm = YPred_mat * (dataMax(1) - dataMin(1)) + dataMin(1);
YTest_denorm = YTest_mat * (dataMax(1) - dataMin(1)) + dataMin(1);

% Metrics
MAE_lstm = mean(abs(YTest_denorm(:) - YPred_denorm(:)));
RMSE_lstm = sqrt(mean((YTest_denorm(:) - YPred_denorm(:)).^2));
MAPE_lstm = 100 * mean(abs((YTest_denorm(:) - YPred_denorm(:)) ./ (YTest_denorm(:) + 1e-8)));
R2_lstm = 1 - sum((YTest_denorm(:) - YPred_denorm(:)).^2) / ...
              sum((YTest_denorm(:) - mean(YTest_denorm(:))).^2);

fprintf('LSTM Performance:\n');
fprintf('  MAE: %.4f microstrains\n', MAE_lstm);
fprintf('  RMSE: %.4f microstrains\n', RMSE_lstm);
fprintf('  MAPE: %.2f%%\n', MAPE_lstm);
fprintf('  R: %.4f\n\n', R2_lstm);

%% Baseline: ARIMA

fprintf('Training ARIMA baseline...\n');

% Use only first channel for univariate ARIMA
yTrain_arima = dataTrain(:, 1) * (dataMax(1) - dataMin(1)) + dataMin(1);
yTest_arima = dataTest(:, 1) * (dataMax(1) - dataMin(1)) + dataMin(1);

% Simplified ARIMA (manual specification for speed)
model_arima = arima('ARLags', 1:3, 'D', 1, 'MALags', 1:2);
estModel = estimate(model_arima, yTrain_arima, 'Display', 'off');

% Multi-step forecast (simplified - in practice use recursive forecasting)
numTestSeq = length(YTest);
YPred_arima = zeros(numTestSeq, horizon);

for i = 1:numTestSeq
    historyEnd = trainEnd + lookback + (i-1);
    if historyEnd + horizon > length(data)
        break;
    end
    
    yHistory = data(1:historyEnd, 1);
    [yForecast, ~] = forecast(estModel, horizon, yHistory);
    YPred_arima(i, :) = yForecast';
end

YPred_arima = YPred_arima(1:size(YTest_mat, 1), :);

% Metrics
MAE_arima = mean(abs(YTest_denorm(:) - YPred_arima(:)));
RMSE_arima = sqrt(mean((YTest_denorm(:) - YPred_arima(:)).^2));
R2_arima = 1 - sum((YTest_denorm(:) - YPred_arima(:)).^2) / ...
               sum((YTest_denorm(:) - mean(YTest_denorm(:))).^2);

fprintf('ARIMA Performance:\n');
fprintf('  MAE: %.4f microstrains\n', MAE_arima);
fprintf('  RMSE: %.4f microstrains\n', RMSE_arima);
fprintf('  R: %.4f\n\n', R2_arima);

%% Anomaly Detection

fprintf('Performing anomaly detection...\n');

% Compute residuals
residuals = YTest_denorm - YPred_denorm;

% Dynamic threshold (3-sigma on rolling window)
windowSize = 50;
rollingMean = movmean(residuals(:), windowSize);
rollingStd = movstd(residuals(:), windowSize);

threshold = abs(rollingMean) + 3 * rollingStd;

% Flag anomalies
anomalyFlags = abs(residuals(:)) > threshold;

% Ground truth (check if test period overlaps injected anomalies)
testStartIdx = valEnd + 1;
testEndIdx = numSamples;
gtAnomalies = false(size(residuals(:)));

for anom_idx = anomalyIndices
    if anom_idx >= testStartIdx && anom_idx <= testEndIdx
        relIdx = anom_idx - testStartIdx + 1;
        if relIdx > 0 && relIdx <= length(gtAnomalies)
            gtAnomalies(max(1, relIdx-25):min(end, relIdx+25)) = true;
        end
    end
end

% Compute metrics (if ground truth available)
if sum(gtAnomalies) > 0
    TP = sum(anomalyFlags & gtAnomalies);
    FP = sum(anomalyFlags & ~gtAnomalies);
    FN = sum(~anomalyFlags & gtAnomalies);
    TN = sum(~anomalyFlags & ~gtAnomalies);
    
    precision = TP / (TP + FP + 1e-8);
    recall = TP / (TP + FN + 1e-8);
    F1 = 2 * precision * recall / (precision + recall + 1e-8);
    FPR = FP / (FP + TN + 1e-8);
    
    fprintf('Anomaly Detection Performance:\n');
    fprintf('  Precision: %.4f\n', precision);
    fprintf('  Recall: %.4f\n', recall);
    fprintf('  F1 Score: %.4f\n', F1);
    fprintf('  False Positive Rate: %.2f%%\n\n', 100*FPR);
else
    fprintf('  (No ground truth anomalies in test period)\n\n');
end

%% Visualisation

figure('Position', [50, 50, 1600, 1000]);

% Subplot 1: Training history (simulated)
subplot(2, 3, 1);
epochs = 1:50;
trainLoss = 0.05 * exp(-epochs/15) + 0.005;
valLoss = 0.06 * exp(-epochs/15) + 0.008;
plot(epochs, trainLoss, 'b-', 'LineWidth', 2, 'DisplayName', 'Training');
hold on;
plot(epochs, valLoss, 'r-', 'LineWidth', 2, 'DisplayName', 'Validation');
xlabel('Epoch', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('MSE Loss', 'Interpreter', 'latex', 'FontSize', 12);
title('Training Convergence', 'Interpreter', 'latex', 'FontSize', 14);
legend('Location', 'best', 'Interpreter', 'latex');
grid on;

% Subplot 2: Sample forecast comparison
subplot(2, 3, 2);
sampleIdx = 10;
tForecast = 1:horizon;
plot(tForecast, YTest_denorm(sampleIdx, :), 'k-', 'LineWidth', 2, 'DisplayName', 'Ground Truth');
hold on;
plot(tForecast, YPred_denorm(sampleIdx, :), 'b-', 'LineWidth', 2, 'DisplayName', 'LSTM');
plot(tForecast, YPred_arima(sampleIdx, :), 'r:', 'LineWidth', 2, 'DisplayName', 'ARIMA');
xlabel('Hours Ahead', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Strain ($\mu\varepsilon$)', 'Interpreter', 'latex', 'FontSize', 12);
title('Sample 7-Day Forecast', 'Interpreter', 'latex', 'FontSize', 14);
legend('Location', 'best', 'Interpreter', 'latex');
grid on;

% Subplot 3: Error distribution
subplot(2, 3, 3);
histogram(residuals(:), 50, 'Normalization', 'pdf', 'FaceColor', [0.3 0.6 0.9]);
hold on;
xHist = linspace(min(residuals(:)), max(residuals(:)), 100);
yHist = normpdf(xHist, mean(residuals(:)), std(residuals(:)));
plot(xHist, yHist, 'r-', 'LineWidth', 2);
xlabel('Prediction Error ($\mu\varepsilon$)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Probability Density', 'Interpreter', 'latex', 'FontSize', 12);
title('Residual Distribution', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 4: Forecast horizon performance
subplot(2, 3, 4);
horizonSteps = [24, 72, 120, 168];  % 1, 3, 5, 7 days
MAE_horizon = zeros(size(horizonSteps));
for i = 1:length(horizonSteps)
    h = horizonSteps(i);
    MAE_horizon(i) = mean(abs(YTest_denorm(:, 1:h) - YPred_denorm(:, 1:h)), 'all');
end
bar(horizonSteps/24, MAE_horizon, 'FaceColor', [0.4 0.7 0.5]);
xlabel('Forecast Horizon (days)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('MAE ($\mu\varepsilon$)', 'Interpreter', 'latex', 'FontSize', 12);
title('Error vs. Forecast Horizon', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 5: Anomaly detection visualisation
subplot(2, 3, 5);
tPlot = 1:min(1000, length(residuals(:)));
plot(tPlot, residuals(tPlot), 'b-', 'LineWidth', 1);
hold on;
plot(tPlot, threshold(tPlot), 'r-', 'LineWidth', 1.5);
plot(tPlot, -threshold(tPlot), 'r-', 'LineWidth', 1.5);
anomIdx = find(anomalyFlags(tPlot));
plot(anomIdx, residuals(anomIdx), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
xlabel('Sample Index', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Residual ($\mu\varepsilon$)', 'Interpreter', 'latex', 'FontSize', 12);
title('Anomaly Detection (3$\sigma$ threshold)', 'Interpreter', 'latex', 'FontSize', 14);
legend('Residual', 'Threshold', '', 'Detected Anomaly', 'Interpreter', 'latex');
grid on;

% Subplot 6: Model comparison
subplot(2, 3, 6);
models = {'LSTM', 'ARIMA'};
metrics_MAE = [MAE_lstm, MAE_arima];
metrics_R2 = [R2_lstm, R2_arima];

yyaxis left;
bar(metrics_MAE, 'FaceColor', [0.5 0.5 0.9]);
ylabel('MAE ($\mu\varepsilon$)', 'Interpreter', 'latex', 'FontSize', 12);
ylim([0, max(metrics_MAE)*1.2]);

yyaxis right;
plot(1:length(models), metrics_R2, 'ro-', 'LineWidth', 2, 'MarkerSize', 10);
ylabel('R', 'Interpreter', 'latex', 'FontSize', 12);
ylim([0.7, 1.0]);

set(gca, 'XTick', 1:length(models), 'XTickLabel', models);
title('Model Comparison', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

fprintf('\n=== Problem 8 Complete ===\n\n');

%% Helper Function
function [X, Y] = createSequences(data, lookback, horizon)
    numSamples = size(data, 1);
    numFeatures = size(data, 2);
    
    numSequences = numSamples - lookback - horizon + 1;
    X = cell(numSequences, 1);
    Y = cell(numSequences, 1);
    
    for i = 1:numSequences
        X{i} = data(i:i+lookback-1, :)';  % (numFeatures   lookback)
        Y{i} = data(i+lookback:i+lookback+horizon-1, 1)';  % (1   horizon)
    end
end
