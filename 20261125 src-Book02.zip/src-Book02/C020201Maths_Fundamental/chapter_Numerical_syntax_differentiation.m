%% chapter_Numerical_syntax_differentiation.m
% Numerical differentiation syntax structure.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Numerical_syntax_differentiation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Using diff for derivative approximation
dY_dx = diff(Y) ./ diff(X);  % Derivative at midpoints

% Using gradient for central differences
dY_dx_gradient = gradient(Y, X);  % Derivative at grid points

% Custom central difference implementation
h = X(2) - X(1);  % Assumes uniform spacing
dY_dx_central = (Y(3:end) - Y(1:end-2)) / (2*h);  % Interior points
