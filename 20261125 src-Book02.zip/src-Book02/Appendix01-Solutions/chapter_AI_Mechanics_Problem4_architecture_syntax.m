%% chapter_AI_Mechanics_Problem4_architecture_syntax.m
% PINN architecture definition for beam vibration.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem4_architecture_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define neural network layers
numHiddenLayers = 5;
numNeuronsPerLayer = 50;

layers = [
    featureInputLayer(2, 'Name', 'input', 'Normalization', 'none')  % [x, t]
    fullyConnectedLayer(numNeuronsPerLayer, 'Name', 'fc1')
    tanhLayer('Name', 'tanh1')
];

for layerIdx = 2:numHiddenLayers
    layers = [layers
              fullyConnectedLayer(numNeuronsPerLayer, 'Name', sprintf('fc%d', layerIdx))
              tanhLayer('Name', sprintf('tanh%d', layerIdx))]; %#ok<AGROW>
end

layers = [layers
          fullyConnectedLayer(1, 'Name', 'output')];  % Displacement w(x,t)

% Create dlnetwork for automatic differentiation
dlnet = dlnetwork(layers);
