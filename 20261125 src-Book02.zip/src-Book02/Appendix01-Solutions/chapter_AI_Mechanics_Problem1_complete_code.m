%% chapter_AI_Mechanics_Problem1_complete_code.m
% Complete ensemble learning for fatigue life prediction.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem1_complete_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 1: Fatigue Life Prediction Using Ensemble Learning
% Author: Dr Yi Chen
% Date: 2024-01-20
% Version: 2.1
% MATLAB Version: R2023b
% Description: Implements stacking ensemble with polynomial regression, SVR,
%              and neural network for aluminium alloy fatigue life prediction

clear; clc; close all;

fprintf('=== Problem 1: Fatigue Life Prediction Using Ensemble Learning ===\n\n');

%% Generate Synthetic Fatigue Dataset

numSamples = 500;
rng(42);  % Reproducibility

% Features:
% 1. Stress amplitude (MPa)
% 2. Mean stress (MPa)
% 3. Stress ratio R = sigma_min / sigma_max
% 4. Surface roughness (Ra, microns)
% 5. Grain size (microns)
% 6. Temperature (Celsius)

% Realistic ranges for 7075-T6 aluminium alloy
stressAmplitude = 80 + 200 * rand(numSamples, 1);     % 80-280 MPa
meanStress = -50 + 150 * rand(numSamples, 1);         % -50 to 100 MPa
stressRatio = meanStress ./ (meanStress + stressAmplitude);
surfaceRoughness = 0.2 + 2.8 * rand(numSamples, 1);   % 0.2-3.0 microns
grainSize = 10 + 40 * rand(numSamples, 1);            % 10-50 microns
temperature = 20 + 80 * rand(numSamples, 1);          % 20-100 Celsius

% Assemble feature matrix
features = [stressAmplitude, meanStress, stressRatio, ...
            surfaceRoughness, grainSize, temperature];

featureNames = {'Stress Amplitude $(MPa)$', 'Mean Stress $(MPa)$', ...
                'Stress Ratio $R$', 'Surface Roughness $(\\mu m)$', ...
                'Grain Size $(\\mu m)$', 'Temperature $(^\\circ C)$'};

% Generate fatigue life based on physics-informed synthetic model
% Combines Basquin relationship with microstructural and environmental effects

% Material parameters for 7075-T6
sigmaPrimeF = 650;  % MPa (fatigue strength coefficient)
bExponent = -0.085; % Fatigue strength exponent

% Base Basquin prediction
logNfBase = (log10(stressAmplitude) - log10(sigmaPrimeF)) / bExponent;

% Correction factors
meanStressEffect = 1 - 0.003 * meanStress;  % Mean stress reduces life
roughnessEffect = exp(-0.15 * (surfaceRoughness - 0.5));  % Roughness reduces life
grainSizeEffect = (grainSize / 30).^0.2;  % Hall-Petch strengthening
temperatureEffect = exp(-0.008 * (temperature - 20));  % Temperature reduces life

% Combined model with noise
logNfTrue = logNfBase + log10(meanStressEffect .* roughnessEffect .* ...
                              grainSizeEffect .* temperatureEffect) + ...
            0.15 * randn(numSamples, 1);  % 15% noise (log scale)

% Convert to cycles
NfTrue = 10.^logNfTrue;

% Clip to realistic range [1e3, 1e7]
NfTrue = max(1e3, min(1e7, NfTrue));
logNfTrue = log10(NfTrue);

fprintf('Synthetic fatigue dataset generated:\n');
fprintf('  Total specimens: %d\n', numSamples);
fprintf('  Features: %d\n', size(features, 2));
fprintf('  Fatigue life range: [%.2e, %.2e] cycles\n', min(NfTrue), max(NfTrue));
fprintf('  Mean log(Nf): %.2f   %.2f\n', mean(logNfTrue), std(logNfTrue));
fprintf('\n');

%% Data Splitting

% 70% training, 15% validation, 15% test
cvPartition = cvpartition(numSamples, 'HoldOut', 0.3);
idxTrain = training(cvPartition);
idxRemaining = test(cvPartition);

% Further split remaining into validation and test
cvPartition2 = cvpartition(sum(idxRemaining), 'HoldOut', 0.5);
idxRemainingArray = find(idxRemaining);
idxVal = false(numSamples, 1);
idxTest = false(numSamples, 1);
idxVal(idxRemainingArray(training(cvPartition2))) = true;
idxTest(idxRemainingArray(test(cvPartition2))) = true;

featuresTrain = features(idxTrain, :);
logNfTrain = logNfTrue(idxTrain);
featuresVal = features(idxVal, :);
logNfVal = logNfTrue(idxVal);
featuresTest = features(idxTest, :);
logNfTest = logNfTrue(idxTest);

fprintf('Data partitioning:\n');
fprintf('  Training: %d samples (%.0f%%)\n', sum(idxTrain), 100*mean(idxTrain));
fprintf('  Validation: %d samples (%.0f%%)\n', sum(idxVal), 100*mean(idxVal));
fprintf('  Test: %d samples (%.0f%%)\n\n', sum(idxTest), 100*mean(idxTest));

%% Feature Standardisation

featureMean = mean(featuresTrain, 1);
featureStd = std(featuresTrain, 0, 1);

featuresTrainStd = (featuresTrain - featureMean) ./ featureStd;
featuresValStd = (featuresVal - featureMean) ./ featureStd;
featuresTestStd = (featuresTest - featureMean) ./ featureStd;

fprintf('Features standardised (z-score normalisation)\n\n');

%% Base Learner 1: Polynomial Regression

fprintf('-- Training Base Learner 1: Polynomial Regression --\n\n');

polyDegree = 3;
polyModel = fitlm(featuresTrainStd, logNfTrain, ...
    'poly' + string(polyDegree), 'RobustOpts', 'off');

predPolyTrain = predict(polyModel, featuresTrainStd);
predPolyVal = predict(polyModel, featuresValStd);
predPolyTest = predict(polyModel, featuresTestStd);

rmsePoly = sqrt(mean((predPolyTest - logNfTest).^2));
maePoly = mean(abs(predPolyTest - logNfTest));
r2Poly = 1 - sum((predPolyTest - logNfTest).^2) / sum((logNfTest - mean(logNfTest)).^2);

fprintf('Polynomial Regression (degree %d):\n', polyDegree);
fprintf('  RMSE: %.4f (log cycles)\n', rmsePoly);
fprintf('  MAE: %.4f (log cycles)\n', maePoly);
fprintf('  R: %.4f\n', r2Poly);
fprintf('  Coefficients: %d\n\n', length(polyModel.Coefficients.Estimate));

%% Base Learner 2: Support Vector Regression

fprintf('-- Training Base Learner 2: Support Vector Regression --\n\n');

% Hyperparameter optimisation using Bayesian optimisation
svrModel = fitrsvm(featuresTrainStd, logNfTrain, ...
    'KernelFunction', 'rbf', ...
    'OptimizeHyperparameters', {'BoxConstraint', 'KernelScale', 'Epsilon'}, ...
    'HyperparameterOptimizationOptions', struct(...
        'AcquisitionFunctionName', 'expected-improvement-plus', ...
        'MaxObjectiveEvaluations', 30, ...
        'ShowPlots', false, ...
        'Verbose', 0));

predSVRTrain = predict(svrModel, featuresTrainStd);
predSVRVal = predict(svrModel, featuresValStd);
predSVRTest = predict(svrModel, featuresTestStd);

rmseSVR = sqrt(mean((predSVRTest - logNfTest).^2));
maeSVR = mean(abs(predSVRTest - logNfTest));
r2SVR = 1 - sum((predSVRTest - logNfTest).^2) / sum((logNfTest - mean(logNfTest)).^2);

fprintf('Support Vector Regression:\n');
fprintf('  RMSE: %.4f (log cycles)\n', rmseSVR);
fprintf('  MAE: %.4f (log cycles)\n', maeSVR);
fprintf('  R: %.4f\n', r2SVR);
fprintf('  Kernel: RBF, BoxConstraint: %.2f, KernelScale: %.4f\n\n', ...
        svrModel.BoxConstraints(1), svrModel.KernelParameters.Scale);

%% Base Learner 3: Neural Network

fprintf('-- Training Base Learner 3: Neural Network --\n\n');

numFeatures = size(featuresTrainStd, 2);

layers = [
    featureInputLayer(numFeatures, 'Name', 'input')
    fullyConnectedLayer(64, 'Name', 'fc1')
    reluLayer('Name', 'relu1')
    dropoutLayer(0.2, 'Name', 'dropout1')
    fullyConnectedLayer(32, 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    dropoutLayer(0.2, 'Name', 'dropout2')
    fullyConnectedLayer(1, 'Name', 'output')
    regressionLayer('Name', 'regression')
];

options = trainingOptions('adam', ...
    'MaxEpochs', 300, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 80, ...
    'ValidationData', {featuresValStd', logNfVal'}, ...
    'ValidationFrequency', 10, ...
    'Plots', 'none', ...
    'Verbose', false);

nnModel = trainNetwork(featuresTrainStd', logNfTrain', layers, options);

predNNTrain = predict(nnModel, featuresTrainStd')';
predNNVal = predict(nnModel, featuresValStd')';
predNNTest = predict(nnModel, featuresTestStd')';

rmseNN = sqrt(mean((predNNTest - logNfTest).^2));
maeNN = mean(abs(predNNTest - logNfTest));
r2NN = 1 - sum((predNNTest - logNfTest).^2) / sum((logNfTest - mean(logNfTest)).^2);

fprintf('Neural Network:\n');
fprintf('  RMSE: %.4f (log cycles)\n', rmseNN);
fprintf('  MAE: %.4f (log cycles)\n', maeNN);
fprintf('  R: %.4f\n', r2NN);
fprintf('  Architecture: [%d, 64, 32, 1]\n\n', numFeatures);

%% Meta-Learner: Ridge Regression

fprintf('-- Training Meta-Learner: Ridge Regression --\n\n');

% Stack validation predictions as meta-features
metaFeaturesVal = [predPolyVal, predSVRVal, predNNVal];

% Train ridge regression on validation set
lambdaRidge = 0.1;
metaModel = ridge(logNfVal, metaFeaturesVal, lambdaRidge, 0);

% Meta-learner weights
metaWeights = metaModel(2:end);
metaBias = metaModel(1);

fprintf('Meta-learner (Ridge Regression) weights:\n');
fprintf('  Polynomial: %.4f\n', metaWeights(1));
fprintf('  SVR: %.4f\n', metaWeights(2));
fprintf('  Neural Network: %.4f\n', metaWeights(3));
fprintf('  Bias: %.4f\n', metaBias);
fprintf('  L2 regularisation:   = %.2f\n\n', lambdaRidge);

%% Ensemble Prediction

% Stack test predictions
metaFeaturesTest = [predPolyTest, predSVRTest, predNNTest];

% Ensemble prediction
predEnsemble = metaBias + metaFeaturesTest * metaWeights;

rmseEnsemble = sqrt(mean((predEnsemble - logNfTest).^2));
maeEnsemble = mean(abs(predEnsemble - logNfTest));
r2Ensemble = 1 - sum((predEnsemble - logNfTest).^2) / sum((logNfTest - mean(logNfTest)).^2);

fprintf('-- Ensemble Performance --\n\n');
fprintf('Ensemble (Stacking):\n');
fprintf('  RMSE: %.4f (log cycles)\n', rmseEnsemble);
fprintf('  MAE: %.4f (log cycles)\n', maeEnsemble);
fprintf('  R: %.4f\n\n', r2Ensemble);

%% Empirical Model Comparison

fprintf('-- Empirical Model Validation --\n\n');

% Basquin model: sigma_a = sigma'_f * (2*Nf)^b
% Fit on training data
stressAmpTrain = featuresTrain(:, 1);
NfTrain = 10.^logNfTrain;

% Log-log linear fit
logStressAmpTrain = log10(stressAmpTrain);
logNfTrain2 = log10(2 * NfTrain);

basquinFit = polyfit(logNfTrain2, logStressAmpTrain, 1);
bBasquin = basquinFit(1);
logSigmaPrimeF = basquinFit(2);
sigmaPrimeFBasquin = 10^logSigmaPrimeF;

% Predict using Basquin
stressAmpTest = featuresTest(:, 1);
logNfBasquin = (log10(stressAmpTest) - logSigmaPrimeF) / bBasquin - log10(2);

rmseBasquin = sqrt(mean((logNfBasquin - logNfTest).^2));
maeBasquin = mean(abs(logNfBasquin - logNfTest));
r2Basquin = 1 - sum((logNfBasquin - logNfTest).^2) / sum((logNfTest - mean(logNfTest)).^2);

fprintf('Basquin Empirical Model:\n');
fprintf('   ''_f = %.1f MPa\n', sigmaPrimeFBasquin);
fprintf('  b = %.4f\n', bBasquin);
fprintf('  RMSE: %.4f (log cycles)\n', rmseBasquin);
fprintf('  MAE: %.4f (log cycles)\n', maeBasquin);
fprintf('  R: %.4f\n\n', r2Basquin);

%% Feature Importance Analysis

fprintf('-- Feature Importance Analysis --\n\n');

% Permutation importance for ensemble
numPermutations = 50;
importanceScores = zeros(numFeatures, 1);

baselineRMSE = rmseEnsemble;

for featIdx = 1:numFeatures
    permutedRMSEs = zeros(numPermutations, 1);
    
    for permIdx = 1:numPermutations
        % Permute feature
        featuresTestPermuted = featuresTestStd;
        featuresTestPermuted(:, featIdx) = featuresTestPermuted(randperm(size(featuresTestPermuted, 1)), featIdx);
        
        % Re-predict with permuted feature
        predPolyPerm = predict(polyModel, featuresTestPermuted);
        predSVRPerm = predict(svrModel, featuresTestPermuted);
        predNNPerm = predict(nnModel, featuresTestPermuted')';
        
        metaFeaturesPerm = [predPolyPerm, predSVRPerm, predNNPerm];
        predEnsemblePerm = metaBias + metaFeaturesPerm * metaWeights;
        
        permutedRMSEs(permIdx) = sqrt(mean((predEnsemblePerm - logNfTest).^2));
    end
    
    importanceScores(featIdx) = mean(permutedRMSEs) - baselineRMSE;
end

% Normalise
importanceScores = importanceScores / sum(importanceScores);

[sortedImportance, sortIdx] = sort(importanceScores, 'descend');

fprintf('Feature Importance (Permutation Method):\n');
for rank = 1:numFeatures
    fprintf('  %d. %-40s: %.4f\n', rank, featureNames{sortIdx(rank)}, sortedImportance(rank));
end
fprintf('\n');

%% Visualisation

figure('Position', [50, 50, 1600, 1000]);

% Subplot 1: Predictions vs True (Ensemble)
subplot(2, 3, 1);
scatter(logNfTest, predEnsemble, 50, 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot([min(logNfTest), max(logNfTest)], [min(logNfTest), max(logNfTest)], 'r-', 'LineWidth', 2);
xlabel('True $\log_{10}(N_f)$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Predicted $\log_{10}(N_f)$', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Ensemble: R = %.3f', r2Ensemble), 'Interpreter', 'latex', 'FontSize', 14);
grid on;
axis equal;
hold off;

% Subplot 2: Model Comparison (RMSE)
subplot(2, 3, 2);
modelNames = {'Polynomial', 'SVR', 'Neural Net', 'Ensemble', 'Basquin'};
rmseValues = [rmsePoly, rmseSVR, rmseNN, rmseEnsemble, rmseBasquin];
bar(rmseValues, 'FaceColor', [0.2, 0.6, 0.8]);
set(gca, 'XTickLabel', modelNames, 'TickLabelInterpreter', 'latex', 'FontSize', 11);
ylabel('RMSE $(\log_{10}$ cycles$)$', 'Interpreter', 'latex', 'FontSize', 12);
title('Model Comparison (Test Set)', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 3: R Comparison
subplot(2, 3, 3);
r2Values = [r2Poly, r2SVR, r2NN, r2Ensemble, r2Basquin];
bar(r2Values, 'FaceColor', [0.8, 0.4, 0.2]);
set(gca, 'XTickLabel', modelNames, 'TickLabelInterpreter', 'latex', 'FontSize', 11);
ylabel('$R^2$ Score', 'Interpreter', 'latex', 'FontSize', 12);
ylim([0, 1]);
title('R Coefficient of Determination', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 4: Residuals
subplot(2, 3, 4);
residuals = predEnsemble - logNfTest;
histogram(residuals, 20, 'FaceColor', [0.4, 0.7, 0.4], 'EdgeColor', 'k');
xlabel('Residual $(\log_{10}$ cycles$)$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Residual Distribution (mean=%.3f)', mean(residuals)), ...
      'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 5: Feature Importance
subplot(2, 3, 5);
barh(importanceScores(sortIdx), 'FaceColor', [0.6, 0.3, 0.7]);
set(gca, 'YTick', 1:numFeatures, 'YTickLabel', featureNames(sortIdx), ...
    'TickLabelInterpreter', 'latex', 'FontSize', 10);
xlabel('Normalised Importance', 'Interpreter', 'latex', 'FontSize', 12);
title('Feature Importance (Permutation)', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 6: Meta-learner Weights
subplot(2, 3, 6);
bar([metaWeights; metaBias], 'FaceColor', [0.9, 0.6, 0.2]);
set(gca, 'XTickLabel', {'Polynomial', 'SVR', 'Neural Net', 'Bias'}, ...
    'TickLabelInterpreter', 'latex', 'FontSize', 11);
ylabel('Weight', 'Interpreter', 'latex', 'FontSize', 12);
title('Meta-Learner Weights (Ridge)', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

fprintf('\n=== Problem 1 Complete ===\n\n');
