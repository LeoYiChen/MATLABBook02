%% chapter_CFDPrinciples_example_conservation_checks.m
% Global conservation verification system.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_conservation_checks
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function conservationResults = verifyConservation(solutionData, ...
    boundaryData, domainData, fluidProperties)
    % VERIFYCONSERVATION Comprehensive conservation law verification
    % Checks mass, momentum, and energy conservation
    %
    % Inputs:
    %   solutionData    - Struct: velocity, pressure, temperature fields
    %   boundaryData    - Struct: inlet, outlet, wall boundary information
    %   domainData      - Struct: volume, bodyForces
    %   fluidProperties - Struct: density, viscosity, specificHeat, Cp, Cv
    %
    % Output:
    %   conservationResults - Comprehensive conservation assessment
    %
    % Author: Dr Leo Chen
    % Institution: University of Oxford
    % Version: 3.0
    %
    % References:
    %   [1] White (2011) Fluid Mechanics
    %   [2] Versteeg & Malalasekera (2007) Introduction to CFD
    %   [3] Patankar (1980) Numerical Heat Transfer and Fluid Flow
    
    fprintf('=== Conservation Law Verification ===\n\n');
    
    conservationResults = struct();
    
    % Mass conservation check
    massResults = verifyMassConservation(solutionData, boundaryData, ...
                                        fluidProperties);
    conservationResults.mass = massResults;
    
    % Momentum conservation check
    momentumResults = verifyMomentumConservation(solutionData, boundaryData, ...
                                                 domainData, fluidProperties);
    conservationResults.momentum = momentumResults;
    
    % Energy conservation check (if thermal problem)
    if isfield(solutionData, 'temperature')
        energyResults = verifyEnergyConservation(solutionData, boundaryData, ...
                                                domainData, fluidProperties);
        conservationResults.energy = energyResults;
    else
        conservationResults.energy = struct('applicable', false);
    end
    
    % Overall assessment
    conservationResults.overallValid = assessOverallConservation(conservationResults);
    
    % Generate comprehensive report
    generateConservationReport(conservationResults);
    
    fprintf('\nConservation verification completed.\n');
end

function massRes = verifyMassConservation(solData, bdryData, fluidProps)
    % Verify global mass conservation
    
    fprintf('Mass Conservation Verification:\n\n');
    
    massRes = struct();
    
    rho = fluidProps.density;
    
    % Calculate inlet mass flow
    inletMassFlow = 0;
    
    if isfield(bdryData, 'inlet')
        inlets = bdryData.inlet;
        
        if ~iscell(inlets)
            inlets = {inlets};
        end
        
        for i = 1:length(inlets)
            inlet = inlets{i};
            
            % Integrate rho * u * n over inlet area
            massFlux = rho * inlet.velocity * inlet.area;
            inletMassFlow = inletMassFlow + massFlux;
        end
    end
    
    massRes.inletMassFlow = inletMassFlow;
    
    % Calculate outlet mass flow
    outletMassFlow = 0;
    
    if isfield(bdryData, 'outlet')
        outlets = bdryData.outlet;
        
        if ~iscell(outlets)
            outlets = {outlets};
        end
        
        for i = 1:length(outlets)
            outlet = outlets{i};
            
            % Integrate rho * u * n over outlet area
            if isfield(outlet, 'massFlow')
                massFlux = outlet.massFlow;
            else
                massFlux = rho * outlet.velocity * outlet.area;
            end
            
            outletMassFlow = outletMassFlow + massFlux;
        end
    end
    
    massRes.outletMassFlow = outletMassFlow;
    
    % Compute imbalance
    if abs(inletMassFlow) > 1e-12
        imbalance = (inletMassFlow - outletMassFlow) / inletMassFlow;
    else
        imbalance = inletMassFlow - outletMassFlow;
    end
    
    massRes.imbalance = imbalance;
    massRes.imbalancePercent = abs(imbalance) * 100;
    
    % Assessment
    tolerance = 1e-4;  % 0.01%
    massRes.conserved = abs(imbalance) < tolerance;
    
    fprintf('  Inlet mass flow: %.8f kg/s\n', inletMassFlow);
    fprintf('  Outlet mass flow: %.8f kg/s\n', outletMassFlow);
    fprintf('  Net imbalance: %.6e kg/s (%.6f%%)\n', ...
            inletMassFlow - outletMassFlow, massRes.imbalancePercent);
    fprintf('  Status: %s\n\n', conservationStatus(massRes.conserved));
end

function momRes = verifyMomentumConservation(solData, bdryData, ...
                                             domData, fluidProps)
    % Verify global momentum conservation
    
    fprintf('Momentum Conservation Verification:\n\n');
    
    momRes = struct();
    
    rho = fluidProps.density;
    
    % Calculate momentum flux (advection term)
    momentumFlux = calculateMomentumFlux(solData, bdryData, rho);
    
    momRes.momentumFlux = momentumFlux;
    
    % Calculate pressure forces
    pressureForce = calculatePressureForce(solData, bdryData);
    
    momRes.pressureForce = pressureForce;
    
    % Calculate viscous forces
    viscousForce = calculateViscousForce(solData, bdryData, fluidProps);
    
    momRes.viscousForce = viscousForce;
    
    % Calculate body forces (if present)
    if isfield(domData, 'bodyForces')
        bodyForce = domData.bodyForces * domData.volume * rho;
    else
        bodyForce = [0; 0; 0];
    end
    
    momRes.bodyForce = bodyForce;
    
    % Total force balance
    totalForce = pressureForce + viscousForce + bodyForce;
    
    momRes.totalForce = totalForce;
    
    % Check balance
    residual = momentumFlux - totalForce;
    
    momRes.residual = residual;
    momRes.residualMagnitude = norm(residual);
    
    % Relative residual
    forceScale = max(norm(totalForce), norm(momentumFlux));
    
    if forceScale > 1e-12
        relativeResidual = norm(residual) / forceScale;
    else
        relativeResidual = norm(residual);
    end
    
    momRes.relativeResidual = relativeResidual;
    
    % Assessment
    tolerance = 0.01;  % 1%
    momRes.conserved = relativeResidual < tolerance;
    
    fprintf('  Momentum flux: [%.6e, %.6e, %.6e] N\n', ...
            momentumFlux(1), momentumFlux(2), momentumFlux(3));
    fprintf('  Pressure force: [%.6e, %.6e, %.6e] N\n', ...
            pressureForce(1), pressureForce(2), pressureForce(3));
    fprintf('  Viscous force: [%.6e, %.6e, %.6e] N\n', ...
            viscousForce(1), viscousForce(2), viscousForce(3));
    fprintf('  Body force: [%.6e, %.6e, %.6e] N\n', ...
            bodyForce(1), bodyForce(2), bodyForce(3));
    fprintf('  Residual: %.6e N (%.4f%% relative)\n', ...
            momRes.residualMagnitude, relativeResidual*100);
    fprintf('  Status: %s\n\n', conservationStatus(momRes.conserved));
end

function energyRes = verifyEnergyConservation(solData, bdryData, ...
                                              domData, fluidProps)
    % Verify global energy conservation
    
    fprintf('Energy Conservation Verification:\n\n');
    
    energyRes = struct();
    
    rho = fluidProps.density;
    cp = fluidProps.specificHeat;
    
    % Calculate enthalpy flux
    enthalpyFlux = calculateEnthalpyFlux(solData, bdryData, rho, cp);
    
    energyRes.enthalpyFlux = enthalpyFlux;
    
    % Calculate heat transfer
    heatTransfer = calculateHeatTransfer(solData, bdryData, fluidProps);
    
    energyRes.heatTransfer = heatTransfer;
    
    % Calculate work (pressure work, viscous dissipation)
    work = calculateWork(solData, bdryData, fluidProps);
    
    energyRes.work = work;
    
    % Energy balance: Q - W = Net enthalpy flux
    energyBalance = heatTransfer - work;
    
    residual = enthalpyFlux - energyBalance;
    
    energyRes.residual = residual;
    
    % Relative residual
    energyScale = max(abs(energyBalance), abs(enthalpyFlux));
    
    if energyScale > 1e-12
        relativeResidual = abs(residual) / energyScale;
    else
        relativeResidual = abs(residual);
    end
    
    energyRes.relativeResidual = relativeResidual;
    
    % Assessment
    tolerance = 0.01;  % 1%
    energyRes.conserved = relativeResidual < tolerance;
    
    fprintf('  Net enthalpy flux: %.6e W\n', enthalpyFlux);
    fprintf('  Heat transfer: %.6e W\n', heatTransfer);
    fprintf('  Work: %.6e W\n', work);
    fprintf('  Residual: %.6e W (%.4f%% relative)\n', ...
            residual, relativeResidual*100);
    fprintf('  Status: %s\n\n', conservationStatus(energyRes.conserved));
end

function momentumFlux = calculateMomentumFlux(solData, bdryData, rho)
    % Calculate net momentum flux across control surface
    
    momentumFlux = [0; 0; 0];
    
    % Inlet contribution
    if isfield(bdryData, 'inlet')
        inlets = bdryData.inlet;
        
        if ~iscell(inlets)
            inlets = {inlets};
        end
        
        for i = 1:length(inlets)
            inlet = inlets{i};
            
            % Momentum flux: rho * u * (u . n) * A
            velocity = inlet.velocity;  % Scalar or vector
            
            if isscalar(velocity)
                % Assume normal to surface
                flux = rho * velocity^2 * inlet.area * inlet.normal;
            else
                flux = rho * norm(velocity)^2 * inlet.area * inlet.normal;
            end
            
            momentumFlux = momentumFlux - flux;  % Negative (into domain)
        end
    end
    
    % Outlet contribution
    if isfield(bdryData, 'outlet')
        outlets = bdryData.outlet;
        
        if ~iscell(outlets)
            outlets = {outlets};
        end
        
        for i = 1:length(outlets)
            outlet = outlets{i};
            
            velocity = outlet.velocity;
            
            if isscalar(velocity)
                flux = rho * velocity^2 * outlet.area * outlet.normal;
            else
                flux = rho * norm(velocity)^2 * outlet.area * outlet.normal;
            end
            
            momentumFlux = momentumFlux + flux;  % Positive (out of domain)
        end
    end
end

function pressureForce = calculatePressureForce(solData, bdryData)
    % Calculate integrated pressure force on control surface
    
    pressureForce = [0; 0; 0];
    
    % Inlet pressure force
    if isfield(bdryData, 'inlet')
        inlets = bdryData.inlet;
        
        if ~iscell(inlets)
            inlets = {inlets};
        end
        
        for i = 1:length(inlets)
            inlet = inlets{i};
            
            force = -inlet.pressure * inlet.area * inlet.normal;
            pressureForce = pressureForce + force;
        end
    end
    
    % Outlet pressure force
    if isfield(bdryData, 'outlet')
        outlets = bdryData.outlet;
        
        if ~iscell(outlets)
            outlets = {outlets};
        end
        
        for i = 1:length(outlets)
            outlet = outlets{i};
            
            force = outlet.pressure * outlet.area * outlet.normal;
            pressureForce = pressureForce + force;
        end
    end
end

function viscousForce = calculateViscousForce(solData, bdryData, fluidProps)
    % Calculate integrated viscous force (primarily on walls)
    
    viscousForce = [0; 0; 0];
    
    if isfield(bdryData, 'wall')
        walls = bdryData.wall;
        
        if ~iscell(walls)
            walls = {walls};
        end
        
        mu = fluidProps.viscosity;
        
        for i = 1:length(walls)
            wall = walls{i};
            
            if isfield(wall, 'shearStress')
                % Use provided wall shear stress
                force = wall.shearStress * wall.area * wall.tangent;
                viscousForce = viscousForce + force;
            end
        end
    end
end

function enthalpyFlux = calculateEnthalpyFlux(solData, bdryData, rho, cp)
    % Calculate net enthalpy flux
    
    enthalpyFlux = 0;
    
    % Inlet enthalpy flux
    if isfield(bdryData, 'inlet')
        inlets = bdryData.inlet;
        
        if ~iscell(inlets)
            inlets = {inlets};
        end
        
        for i = 1:length(inlets)
            inlet = inlets{i};
            
            h_in = cp * inlet.temperature;
            massFlow = rho * inlet.velocity * inlet.area;
            
            enthalpyFlux = enthalpyFlux - h_in * massFlow;
        end
    end
    
    % Outlet enthalpy flux
    if isfield(bdryData, 'outlet')
        outlets = bdryData.outlet;
        
        if ~iscell(outlets)
            outlets = {outlets};
        end
        
        for i = 1:length(outlets)
            outlet = outlets{i};
            
            h_out = cp * outlet.temperature;
            massFlow = rho * outlet.velocity * outlet.area;
            
            enthalpyFlux = enthalpyFlux + h_out * massFlow;
        end
    end
end

function heatTransfer = calculateHeatTransfer(solData, bdryData, fluidProps)
    % Calculate total heat transfer across boundaries
    
    heatTransfer = 0;
    
    if isfield(bdryData, 'wall')
        walls = bdryData.wall;
        
        if ~iscell(walls)
            walls = {walls};
        end
        
        for i = 1:length(walls)
            wall = walls{i};
            
            if isfield(wall, 'heatFlux')
                % Positive = into domain
                heatTransfer = heatTransfer + wall.heatFlux * wall.area;
            end
        end
    end
end

function work = calculateWork(solData, bdryData, fluidProps)
    % Calculate work done (pressure work + viscous dissipation)
    
    % Simplified: primarily pressure work at boundaries
    work = 0;
    
    % This would require detailed integration of p(u.n) over boundaries
    % Placeholder for demonstration
end

function valid = assessOverallConservation(consRes)
    % Assess overall conservation validity
    
    massConserved = consRes.mass.conserved;
    momentumConserved = consRes.momentum.conserved;
    
    if consRes.energy.applicable
        energyConserved = consRes.energy.conserved;
        valid = massConserved && momentumConserved && energyConserved;
    else
        valid = massConserved && momentumConserved;
    end
end

function generateConservationReport(consRes)
    % Generate comprehensive conservation report
    
    fprintf('\n=== CONSERVATION REPORT ===\n\n');
    
    fprintf('MASS CONSERVATION:\n');
    fprintf('  Inlet: %.8f kg/s\n', consRes.mass.inletMassFlow);
    fprintf('  Outlet: %.8f kg/s\n', consRes.mass.outletMassFlow);
    fprintf('  Imbalance: %.6f%%\n', consRes.mass.imbalancePercent);
    fprintf('  Status: %s\n\n', conservationStatus(consRes.mass.conserved));
    
    fprintf('MOMENTUM CONSERVATION:\n');
    fprintf('  Residual magnitude: %.6e N\n', consRes.momentum.residualMagnitude);
    fprintf('  Relative residual: %.4f%%\n', consRes.momentum.relativeResidual*100);
    fprintf('  Status: %s\n\n', conservationStatus(consRes.momentum.conserved));
    
    if consRes.energy.applicable
        fprintf('ENERGY CONSERVATION:\n');
        fprintf('  Residual: %.6e W\n', consRes.energy.residual);
        fprintf('  Relative residual: %.4f%%\n', consRes.energy.relativeResidual*100);
        fprintf('  Status: %s\n\n', conservationStatus(consRes.energy.conserved));
    end
    
    fprintf('OVERALL VALIDITY:\n');
    if consRes.overallValid
        fprintf('  ? ALL CONSERVATION LAWS SATISFIED\n');
    else
        fprintf('  ? CONSERVATION VIOLATIONS DETECTED\n');
    end
    
    fprintf('\n=== END OF REPORT ===\n');
end

function statusStr = conservationStatus(isConserved)
    % Convert boolean to conservation status string
    if isConserved
        statusStr = 'SATISFIED';
    else
        statusStr = 'VIOLATED';
    end
end
