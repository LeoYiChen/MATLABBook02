%% chapter_FundamentalMathematics_conclusion_statistics.m
% Statistical analysis and uncertainty quantification.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_conclusion_statistics
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateStatisticalMethods();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateStatisticalMethods()
    % DEMONSTRATESTATISTICALMETHODS Probability and statistical inference
    %   Explores fundamental statistical concepts and applications
    
    fprintf('Probability and Statistics: Reasoning Under Uncertainty\n');
    fprintf('========================================================\n\n');
    
    %% Central Limit Theorem
    fprintf('CENTRAL LIMIT THEOREM DEMONSTRATION\n');
    fprintf('------\n\n');
    
    fprintf(['The CLT states: averages of independent random variables\n', ...
        'converge to normal distribution regardless of original distribution.\n\n']);
    
    % Demonstrate with exponential distribution (highly skewed)
    rng(42);
    lambda = 2;
    num_simulations = 10000;
    sample_sizes = [1, 5, 10, 30, 100];
    
    figure('Position', [100, 100, 1400, 800]);
    
    for idx = 1:length(sample_sizes)
        n = sample_sizes(idx);
        
        sample_means = zeros(num_simulations, 1);
        for sim = 1:num_simulations
            samples = exprnd(1/lambda, n, 1);
            sample_means(sim) = mean(samples);
        end
        
        subplot(2, 3, idx);
        histogram(sample_means, 50, 'Normalization', 'pdf', ...
            'FaceColor', [0.3, 0.6, 0.9], 'EdgeColor', 'none');
        hold on;
        
        % Overlay theoretical normal distribution
        mu_theory = 1/lambda;
        sigma_theory = 1/(lambda * sqrt(n));
        x_range = linspace(min(sample_means), max(sample_means), 100);
        normal_pdf = normpdf(x_range, mu_theory, sigma_theory);
        plot(x_range, normal_pdf, 'r-', 'LineWidth', 2);
        
        xlabel('Sample Mean');
        ylabel('Probability Density');
        title(sprintf('Sample Size n = %d', n));
        legend('Simulated', 'Theoretical Normal', 'Location', 'best');
        grid on;
    end
    
    fprintf('As sample size increases, distribution of sample means\n');
    fprintf('approaches normal distribution (red curve).\n\n');
    
    %% Hypothesis Testing
    fprintf('HYPOTHESIS TESTING\n');
    fprintf('---\n\n');
    
    fprintf(['Testing whether two samples come from populations\n', ...
        'with different means (two-sample t-test).\n\n']);
    
    % Generate two samples
    rng(123);
    group1 = normrnd(10, 2, 50, 1);  % mean=10, std=2
    group2 = normrnd(11.5, 2, 50, 1);  % mean=11.5, std=2
    
    fprintf('Group 1: n=%d, mean=%.2f, std=%.2f\n', ...
        length(group1), mean(group1), std(group1));
    fprintf('Group 2: n=%d, mean=%.2f, std=%.2f\n\n', ...
        length(group2), mean(group2), std(group2));
    
    % Perform two-sample t-test
    [h, p_value, ci, stats] = ttest2(group1, group2);
    
    fprintf('Two-sample t-test results:\n');
    fprintf('  Test statistic (t): %.4f\n', stats.tstat);
    fprintf('  Degrees of freedom: %.0f\n', stats.df);
    fprintf('  P-value: %.6f\n', p_value);
    fprintf('  95%% confidence interval: [%.4f, %.4f]\n\n', ci(1), ci(2));
    
    if h == 1
        fprintf('Decision: REJECT null hypothesis (p < 0.05)\n');
        fprintf('Conclusion: Significant difference between group means.\n\n');
    else
        fprintf('Decision: FAIL TO REJECT null hypothesis (p >= 0.05)\n');
        fprintf('Conclusion: No significant difference detected.\n\n');
    end
    
    %% Confidence Intervals
    fprintf('CONFIDENCE INTERVALS\n');
    fprintf('----\n\n');
    
    % Bootstrap confidence intervals
    num_bootstrap = 10000;
    bootstrap_means = bootstrp(num_bootstrap, @mean, group1);
    
    ci_bootstrap = prctile(bootstrap_means, [2.5, 97.5]);
    
    fprintf('Bootstrap 95%% confidence interval for Group 1 mean:\n');
    fprintf('  [%.4f, %.4f]\n\n', ci_bootstrap(1), ci_bootstrap(2));
    
    subplot(2, 3, 6);
    histogram(bootstrap_means, 50, 'FaceColor', [0.3, 0.7, 0.3], ...
        'EdgeColor', 'none');
    hold on;
    xline(ci_bootstrap(1), 'r-', 'LineWidth', 2);
    xline(ci_bootstrap(2), 'r-', 'LineWidth', 2);
    xline(mean(group1), 'k-', 'LineWidth', 2);
    
    xlabel('Bootstrap Sample Mean');
    ylabel('Frequency');
    title('Bootstrap Distribution (Group 1)');
    legend('Bootstrap Samples', '2.5*th percentile', '97.5*th percentile', ...
        'Original Mean', 'Location', 'best');
    grid on;
    
    fprintf('Bootstrap methods provide robust confidence intervals\n');
    fprintf('without assuming specific distributional forms.\n\n');
end
