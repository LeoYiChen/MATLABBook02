%% chapter_AI_Mechanics_Problem10_roc_syntax.m
% ROC curve and optimal threshold selection syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem10_roc_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Compute ROC curve and find optimal threshold
% reconErrors: reconstruction errors on test set
% trueLabels: ground truth (0=normal, 1=anomaly)

% Sort errors and compute TPR/FPR at each threshold
[sortedErrors, sortIdx] = sort(reconErrors);
sortedLabels = trueLabels(sortIdx);

numSamples = length(sortedErrors);
TPR = zeros(numSamples, 1);
FPR = zeros(numSamples, 1);

numPositives = sum(trueLabels == 1);
numNegatives = sum(trueLabels == 0);

for i = 1:numSamples
    % Classify as anomaly if error > threshold
    threshold = sortedErrors(i);
    predicted = reconErrors > threshold;
    
    TP = sum(predicted == 1 & trueLabels == 1);
    FP = sum(predicted == 1 & trueLabels == 0);
    
    TPR(i) = TP / numPositives;
    FPR(i) = FP / numNegatives;
end

% Compute AUC
AUC = trapz(FPR, TPR);

% Find optimal threshold (max F1 score)
precision = zeros(numSamples, 1);
recall = TPR;

for i = 1:numSamples
    threshold = sortedErrors(i);
    predicted = reconErrors > threshold;
    
    TP = sum(predicted == 1 & trueLabels == 1);
    FP = sum(predicted == 1 & trueLabels == 0);
    
    precision(i) = TP / (TP + FP + 1e-8);
end

F1 = 2 * (precision .* recall) ./ (precision + recall + 1e-8);
[maxF1, optIdx] = max(F1);
optimalThreshold = sortedErrors(optIdx);

fprintf('AUC-ROC: %.4f\n', AUC);
fprintf('Optimal threshold: %.6f (F1=%.4f)\n', optimalThreshold, maxF1);

% Plot ROC curve
figure;
plot(FPR, TPR, 'b-', 'LineWidth', 2);
hold on;
plot([0, 1], [0, 1], 'k-');  % Random classifier
xlabel('False Positive Rate', 'Interpreter', 'latex');
ylabel('True Positive Rate', 'Interpreter', 'latex');
title(sprintf('ROC Curve (AUC=%.4f)', AUC), 'Interpreter', 'latex');
grid on;
