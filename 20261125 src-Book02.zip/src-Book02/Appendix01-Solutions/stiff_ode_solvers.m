%% stiff_ode_solvers.m
% Stiff ODE Solver Comparison
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : stiff_ode_solvers
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem5.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Define the stiff ODE system
function dydt = stiff_chem_kinetics(t, y)
dydt = zeros(3, 1);
dydt(1) = -0.04y(1) + 1e4y(2)y(3);
dydt(2) = 0.04y(1) - 1e4y(2)y(3) - 3e7y(2)^2;
dydt(3) = 3e7y(2)^2;
end

% Initial conditions and time span
y0 = [1; 0; 0];
tspan = [0 40];

% Options for ODE solvers
options = odeset('RelTol', 1e-6, 'AbsTol', 1e-8, 'Stats', 'on');

% Solve using different ODE solvers
fprintf('Solving stiff chemical kinetics problem...\n\n');

tic;
[t_ode45, y_ode45] = ode45(@stiff_chem_kinetics, tspan, y0, options);
time_ode45 = toc;
fprintf('ode45 (non-stiff solver):\n');
fprintf(' Time taken: %.4f seconds\n', time_ode45);
fprintf(' Number of steps: %d\n\n', length(t_ode45));

tic;
[t_ode15s, y_ode15s] = ode15s(@stiff_chem_kinetics, tspan, y0, options);
time_ode15s = toc;
fprintf('ode15s (stiff solver, BDF method):\n');
fprintf(' Time taken: %.4f seconds\n', time_ode15s);
fprintf(' Number of steps: %d\n\n', length(t_ode15s));

tic;
[t_ode23s, y_ode23s] = ode23s(@stiff_chem_kinetics, tspan, y0, options);
time_ode23s = toc;
fprintf('ode23s (stiff solver, Rosenbrock method):\n');
fprintf(' Time taken: %.4f seconds\n', time_ode23s);
fprintf(' Number of steps: %d\n\n', length(t_ode23s));

tic;
[t_ode23t, y_ode23t] = ode23t(@stiff_chem_kinetics, tspan, y0, options);
time_ode23t = toc;
fprintf('ode23t (moderately stiff solver, trapezoidal rule):\n');
fprintf(' Time taken: %.4f seconds\n', time_ode23t);
fprintf(' Number of steps: %d\n\n', length(t_ode23t));

tic;
[t_ode23tb, y_ode23tb] = ode23tb(@stiff_chem_kinetics, tspan, y0, options);
time_ode23tb = toc;
fprintf('ode23tb (stiff solver, TR-BDF2 method):\n');
fprintf(' Time taken: %.4f seconds\n', time_ode23tb);
fprintf(' Number of steps: %d\n\n', length(t_ode23tb));

% Now implement a simple explicit Euler method to demonstrate stiffness issues
fprintf('Attempting Explicit Euler method with different step sizes...\n');

try_step_sizes = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5];
euler_successful = false;

for h = try_step_sizes
try
fprintf(' Step size h = %.0e: ', h);

% Explicit Euler with fixed step size
    tic;
    t_euler = 0:h:40;
    y_euler = zeros(length(t_euler), 3);
    y_euler(1,:) = y0';
    
    for i = 1:length(t_euler)-1
        dydt = stiff_chem_kinetics(t_euler(i), y_euler(i,:)');
        y_euler(i+1,:) = y_euler(i,:) + h * dydt';
        
        % Check for numerical instability
        if any(isnan(y_euler(i+1,:))) || any(abs(y_euler(i+1,:)) > 1e10)
            error('Numerical instability detected at t = %.4f', t_euler(i));
        end
    end
    
    euler_time = toc;
    fprintf('Successful! Time taken: %.4f seconds, Steps: %d\n', euler_time, length(t_euler));
    euler_successful = true;
    break;
    
catch ME
    fprintf('Failed - %s\n', ME.message);
end

end

if ~euler_successful
fprintf(' Explicit Euler requires extremely small step sizes for this stiff problem.\n');
end

% Plot results
figure;

% Plot y1
subplot(3,1,1);
plot(t_ode45, y_ode45(:,1), 'b-', 'LineWidth', 1.5, 'DisplayName', 'ode45');
hold on;
plot(t_ode15s, y_ode15s(:,1), 'r-', 'LineWidth', 1.5, 'DisplayName', 'ode15s');
plot(t_ode23s, y_ode23s(:,1), 'g-.', 'LineWidth', 1.5, 'DisplayName', 'ode23s');
plot(t_ode23t, y_ode23t(:,1), 'm:', 'LineWidth', 1.5, 'DisplayName', 'ode23t');
plot(t_ode23tb, y_ode23tb(:,1), 'c-', 'LineWidth', 1.5, 'DisplayName', 'ode23tb');
if euler_successful
plot(t_euler, y_euler(:,1), 'k.', 'MarkerSize', 6, 'DisplayName', 'Explicit Euler');
end
xlabel('Time');
ylabel('y_1');
title('Stiff Chemical Kinetics Problem - y_1 Component');
legend('show');
grid on;

% Plot y2
subplot(3,1,2);
plot(t_ode45, y_ode45(:,2), 'b-', 'LineWidth', 1.5, 'DisplayName', 'ode45');
hold on;
plot(t_ode15s, y_ode15s(:,2), 'r-', 'LineWidth', 1.5, 'DisplayName', 'ode15s');
plot(t_ode23s, y_ode23s(:,2), 'g-.', 'LineWidth', 1.5, 'DisplayName', 'ode23s');
plot(t_ode23t, y_ode23t(:,2), 'm:', 'LineWidth', 1.5, 'DisplayName', 'ode23t');
plot(t_ode23tb, y_ode23tb(:,2), 'c-', 'LineWidth', 1.5, 'DisplayName', 'ode23tb');
if euler_successful
plot(t_euler, y_euler(:,2), 'k.', 'MarkerSize', 6, 'DisplayName', 'Explicit Euler');
end
xlabel('Time');
ylabel('y_2');
title('Stiff Chemical Kinetics Problem - y_2 Component');
grid on;

% Plot y3
subplot(3,1,3);
plot(t_ode45, y_ode45(:,3), 'b-', 'LineWidth', 1.5, 'DisplayName', 'ode45');
hold on;
plot(t_ode15s, y_ode15s(:,3), 'r-', 'LineWidth', 1.5, 'DisplayName', 'ode15s');
plot(t_ode23s, y_ode23s(:,3), 'g-.', 'LineWidth', 1.5, 'DisplayName', 'ode23s');
plot(t_ode23t, y_ode23t(:,3), 'm:', 'LineWidth', 1.5, 'DisplayName', 'ode23t');
plot(t_ode23tb, y_ode23tb(:,3), 'c-', 'LineWidth', 1.5, 'DisplayName', 'ode23tb');
if euler_successful
plot(t_euler, y_euler(:,3), 'k.', 'MarkerSize', 6, 'DisplayName', 'Explicit Euler');
end
xlabel('Time');
ylabel('y_3');
title('Stiff Chemical Kinetics Problem - y_3 Component');
grid on;

% Create a zoomed-in plot of y2 to show the initial transient
figure;
plot(t_ode45, y_ode45(:,2), 'b-', 'LineWidth', 1.5, 'DisplayName', 'ode45');
hold on;
plot(t_ode15s, y_ode15s(:,2), 'r-', 'LineWidth', 1.5, 'DisplayName', 'ode15s');
plot(t_ode23s, y_ode23s(:,2), 'g-.', 'LineWidth', 1.5, 'DisplayName', 'ode23s');
xlabel('Time');
ylabel('y_2');
title('Zoomed View of y_2 Component - Initial Transient');
xlim([0 0.01]);
legend('show');
grid on;

% Plot step sizes used by adaptive solvers
figure;
semilogy(diff(t_ode45), 'b-', 'LineWidth', 1.5, 'DisplayName', 'ode45');
hold on;
semilogy(diff(t_ode15s), 'r-', 'LineWidth', 1.5, 'DisplayName', 'ode15s');
semilogy(diff(t_ode23s), 'g-.', 'LineWidth', 1.5, 'DisplayName', 'ode23s');
semilogy(diff(t_ode23t), 'm:', 'LineWidth', 1.5, 'DisplayName', 'ode23t');
semilogy(diff(t_ode23tb), 'c-', 'LineWidth', 1.5, 'DisplayName', 'ode23tb');
xlabel('Step Number');
ylabel('Step Size (log scale)');
title('Step Sizes Used by Adaptive ODE Solvers');
legend('show');
grid on;

% Calculate reference solution using ode15s with very tight tolerances
options_ref = odeset('RelTol', 1e-10, 'AbsTol', 1e-12);
[t_ref, y_ref] = ode15s(@stiff_chem_kinetics, tspan, y0, options_ref);

% Compute errors relative to reference solution
solvers = {'ode45', 'ode15s', 'ode23s', 'ode23t', 'ode23tb'};
solutions = {y_ode45, y_ode15s, y_ode23s, y_ode23t, y_ode23tb};
times = {t_ode45, t_ode15s, t_ode23s, t_ode23t, t_ode23tb};
computation_times = [time_ode45, time_ode15s, time_ode23s, time_ode23t, time_ode23tb];
step_counts = [length(t_ode45), length(t_ode15s), length(t_ode23s), length(t_ode23t), length(t_ode23tb)];

fprintf('\nError Analysis (using ode15s with tight tolerances as reference):\n');
fprintf('%-10s %-15s %-15s %-15s %-15s\n', 'Solver', 'Max Error', 'Step Count', 'Compute Time (s)', 'Steps/Second');

for i = 1:length(solvers)
% Interpolate reference solution to match solver's time points
y_ref_interp = interp1(t_ref, y_ref, times{i}, 'spline');

% Calculate max error
error_mat = abs(solutions{i} - y_ref_interp);
max_err = max(error_mat(:));

% Display results
fprintf('%-10s %-15.2e %-15d %-15.4f %-15.1f\n', ...
    solvers{i}, max_err, step_counts(i), computation_times(i), step_counts(i)/computation_times(i));
    
    end
