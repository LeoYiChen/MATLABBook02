%% code_discrete_model.m
% Discrete spring-mass model.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:discrete_model
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function U_discrete = discreteSpringMassModel(X, Y, F_active, E_young, dx, dy)
    % Simulate morphing using discrete spring-mass model
    % This provides a microscopic perspective for comparison
    
    [Ny, Nx] = size(X);
    N_nodes = Ny * Nx;
    
    % Spring stiffness (related to Young's modulus through homogenisation)
    k_spring = E_young * dx;  % Simplified relationship
    
    % Connectivity matrix (4-neighbour connectivity)
    A = buildConnectivityMatrix(Ny, Nx);
    
    % Equilibrium rest lengths
    l0 = sqrt(dx^2 + dy^2);
    
    % System matrix for discrete model
    K = buildStiffnessMatrix(A, k_spring, Ny, Nx);
    
    % Force vector
    F_vec = reshape(F_active, [], 1);
    
    % Solve linear system: K * u = F
    u_discrete = K \ F_vec;
    
    % Reshape to 2D
    U_discrete = reshape(u_discrete, Ny, Nx);
end

function A = buildConnectivityMatrix(Ny, Nx)
    % Build connectivity matrix for grid
    N = Ny * Nx;
    A = sparse(N, N);
    
    for i = 1:Ny
        for j = 1:Nx
            idx = (i-1) * Nx + j;
            
            % Right neighbour
            if j < Nx
                idx_right = (i-1) * Nx + (j+1);
                A(idx, idx_right) = 1;
            end
            
            % Top neighbour
            if i < Ny
                idx_top = i * Nx + j;
                A(idx, idx_top) = 1;
            end
        end
    end
    
    % Make symmetric
    A = A + A';
end

function K = buildStiffnessMatrix(A, k, Ny, Nx)
    % Build stiffness matrix from connectivity
    N = Ny * Nx;
    K = sparse(N, N);
    
    [rows, cols] = find(A);
    
    for i = 1:length(rows)
        r = rows(i);
        c = cols(i);
        K(r, r) = K(r, r) + k;
        K(c, c) = K(c, c) + k;
        K(r, c) = K(r, c) - k;
        K(c, r) = K(c, r) - k;
    end
    
    % Add small regularisation for stability
    K = K + 1e-6 * speye(N);
end
