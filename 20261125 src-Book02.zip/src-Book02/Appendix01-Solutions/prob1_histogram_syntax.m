%% prob1_histogram_syntax.m
% Histogram generation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob1_histogram_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
histogram(data, 'NumBins', numberOfBins, 'Normalization', 'pdf');
xlabel('Variable Name');
ylabel('Probability Density');
title('Histogram Title');
