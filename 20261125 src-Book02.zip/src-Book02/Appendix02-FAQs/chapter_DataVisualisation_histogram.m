%% chapter_DataVisualisation_histogram.m
% Histogram Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_histogram
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
figure('Position', [100 100 800 600]);
histogram(data, 'Normalization', 'probability', ...
'FaceColor', 'b', 'FaceAlpha', 0.3);
xlabel('Values');
ylabel('Probability');
title('Probability Distribution Histogram');
grid on;

% Add statistical annotations
mu = mean(data);
sigma = std(data);
text(0.7, 0.9, sprintf('\mu = %.2f\n\sigma = %.2f', mu, sigma), ...
'Units', 'normalized', 'Interpreter', 'tex');

% Export figure in multiple formats
exportFigure(gca, 'histogram_plot');

