%% C0201Introduction_code_011.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Computing product of many small probabilities
% UNSTABLE: Direct multiplication causes underflow
probabilities = rand(1000, 1) * 0.01;
product_unstable = prod(probabilities);  % Often returns 0

% STABLE: Use logarithms
logProduct = sum(log(probabilities));
product_stable = exp(logProduct);

% For numerical stability in probability calculations
% MATLAB provides logsumexp-style functions
logProbabilities = log(probabilities);
logSum = logsumexp(logProbabilities);  % Custom or from toolbox

function lse = logsumexp(logValues)
    % LOGSUMEXP Numerically stable log-sum-exp
    %   Computes log(sum(exp(logValues))) avoiding overflow/underflow
    
    maxVal = max(logValues);
    lse = maxVal + log(sum(exp(logValues - maxVal)));
end
