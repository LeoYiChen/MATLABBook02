%% C020201Maths_Fundamental_code_106.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Compute analytic signal via Hilbert transform
analyticSignal = hilbert(realSignal);

% Extract envelope (instantaneous amplitude)
envelope = abs(analyticSignal);

% Extract instantaneous phase and frequency
instantaneousPhase = unwrap(angle(analyticSignal));
instantaneousFrequency = diff(instantaneousPhase) * ...
    samplingFrequency / (2 * pi);

% Visualise
figure;
subplot(2,1,1);
plot(time, realSignal, 'b-', 'LineWidth', 1);
hold on;
plot(time, envelope, 'r-', 'LineWidth', 2);
title('Signal Envelope', 'Interpreter', 'latex');
legend({'Signal', 'Envelope'}, 'Interpreter', 'latex');

subplot(2,1,2);
plot(time(2:end), instantaneousFrequency, 'g-', 'LineWidth', 1.5);
title('Instantaneous Frequency', 'Interpreter', 'latex');
ylabel('Frequency (Hz)', 'Interpreter', 'latex');
