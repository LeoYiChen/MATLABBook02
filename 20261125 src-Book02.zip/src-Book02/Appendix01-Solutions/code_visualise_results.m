%% code_visualise_results.m
% Results visualisation function.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:visualise_results
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function visualiseResults(lambda_ref, lambda_single, lambda_mixed, ...
    error_single, error_mixed, history)
    % Visualise comparison of precision methods
    
    figure('Position', [100, 100, 1400, 800]);
    
    % Eigenvalue comparison
    subplot(2, 2, 1);
    hold on;
    plot(1:length(lambda_ref), sort(abs(lambda_ref)), 'ko-', ...
        'LineWidth', 2, 'MarkerSize', 8, 'DisplayName', 'Double Precision');
    plot(1:length(lambda_single), sort(abs(lambda_single)), 'bs-', ...
        'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', 'Single Precision');
    plot(1:length(lambda_mixed), sort(abs(lambda_mixed)), 'r^:', ...
        'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', 'Mixed Precision');
    hold off;
    xlabel('Eigenvalue Index', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|\lambda|$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Eigenvalue Magnitude Comparison', 'Interpreter', 'latex', ...
        'FontSize', 14);
    legend('Location', 'northwest', 'Interpreter', 'latex');
    grid on;
    set(gca, 'YScale', 'log');
    
    % Error comparison
    subplot(2, 2, 2);
    semilogy(1:length(error_single), error_single, 'bs-', 'LineWidth', 1.5, ...
        'MarkerSize', 8, 'DisplayName', 'Single Precision');
    hold on;
    semilogy(1:length(error_mixed), error_mixed, 'r^-', 'LineWidth', 1.5, ...
        'MarkerSize', 8, 'DisplayName', 'Mixed Precision');
    hold off;
    xlabel('Eigenvalue Index', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Relative Error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Accuracy Comparison', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Refinement convergence
    subplot(2, 2, 3);
    semilogy(history, 'LineWidth', 1.5);
    xlabel('Refinement Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Residual Norm', 'Interpreter', 'latex', 'FontSize', 12);
    title('Mixed Precision Refinement Convergence', 'Interpreter', 'latex', ...
        'FontSize', 14);
    grid on;
    
    % Performance metrics
    subplot(2, 2, 4);
    categories = {'Single', 'Mixed'};
    mean_errors = [mean(error_single), mean(error_mixed)];
    bar(mean_errors, 'FaceColor', [0.2 0.4 0.8]);
    set(gca, 'XTickLabel', categories, 'YScale', 'log');
    ylabel('Mean Relative Error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Average Accuracy', 'Interpreter', 'latex', 'FontSize', 14);
    grid on;
    
    sgtitle('\textbf{Mixed Precision Eigenvalue Solver: Performance Analysis}', ...
        'Interpreter', 'latex', 'FontSize', 16);
end
