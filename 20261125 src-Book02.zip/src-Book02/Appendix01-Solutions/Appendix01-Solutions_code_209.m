%% Appendix01-Solutions_code_209.m
% CNN for Handwritten Physics Symbol Recognition
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, classification_report
import seaborn as sns
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import gaussian_filter, rotate, affine_transform

# ============================================================================
# Synthetic Dataset Generation
# ============================================================================
class PhysicsSymbolDataset(Dataset):
    """Generate synthetic handwritten physics symbols"""
    
    def __init__(self, num_samples_per_class=500, train=True, transform=None):
        self.symbols = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                       '+', '-', 'x', '/', ' ', ' ', ' ', ' ', ' ']
        self.num_classes = len(self.symbols)
        self.num_samples = num_samples_per_class * self.num_classes
        self.transform = transform
        self.train = train
        
        # Generate dataset
        self.images, self.labels = self._generate_data(num_samples_per_class)
    
    def _generate_data(self, n_per_class):
        """Generate synthetic symbol images"""
        images = []
        labels = []
        
        for class_idx, symbol in enumerate(self.symbols):
            for _ in range(n_per_class):
                # Create base image
                img = Image.new('L', (32, 32), color=0)
                draw = ImageDraw.Draw(img)
                
                # Random font size
                font_size = np.random.randint(18, 24)
                try:
                    font = ImageFont.truetype("arial.ttf", font_size)
                except:
                    font = ImageFont.load_default()
                
                # Draw symbol
                text_width, text_height = draw.textsize(symbol, font=font)
                position = ((32 - text_width) // 2, (32 - text_height) // 2)
                draw.text(position, symbol, fill=255, font=font)
                
                # Convert to numpy
                img_array = np.array(img, dtype=np.float32) / 255.0
                
                # Apply augmentations
                if self.train:
                    img_array = self._augment(img_array)
                
                # Crop to 28x28
                img_array = img_array[2:30, 2:30]
                
                images.append(img_array)
                labels.append(class_idx)
        
        # Convert to tensors
        images = torch.tensor(np.array(images), dtype=torch.float32)
        images = images.unsqueeze(1)  # Add channel dimension
        labels = torch.tensor(labels, dtype=torch.long)
        
        return images, labels
    
    def _augment(self, img):
        """Apply random augmentations"""
        # Random rotation
        angle = np.random.uniform(-15, 15)
        img = rotate(img, angle, reshape=False, mode='constant', cval=0.0)
        
        # Random scaling
        scale = np.random.uniform(0.85, 1.15)
        center = np.array(img.shape) / 2
        matrix = np.array([[scale, 0], [0, scale]])
        offset = center - center.dot(matrix)
        img = affine_transform(img, matrix.T, offset=offset, 
                              mode='constant', cval=0.0)
        
        # Gaussian noise
        noise = np.random.normal(0, 0.05, img.shape)
        img = np.clip(img + noise, 0, 1)
        
        # Gaussian blur (occasionally)
        if np.random.rand() < 0.3:
            img = gaussian_filter(img, sigma=0.5)
        
        return img
    
    def __len__(self):
        return self.num_samples
    
    def __getitem__(self, idx):
        return self.images[idx], self.labels[idx]


# ============================================================================
# CNN Architecture
# ============================================================================
class PhysicsSymbolCNN(nn.Module):
    """Convolutional Neural Network for symbol classification"""
    
    def __init__(self, num_classes=19):
        super(PhysicsSymbolCNN, self).__init__()
        
        # Convolutional layers
        self.conv1 = nn.Conv2d(1, 16, kernel_size=5, padding=0)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=3, padding=0)
        
        # Pooling
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        
        # Fully connected layers
        self.fc1 = nn.Linear(32 * 5 * 5, 128)
        self.fc2 = nn.Linear(128, num_classes)
        
        # Dropout
        self.dropout = nn.Dropout(0.5)
        
        # Batch normalization
        self.bn1 = nn.BatchNorm2d(16)
        self.bn2 = nn.BatchNorm2d(32)
    
    def forward(self, x):
        # Conv block 1
        x = self.conv1(x)           # 28x28x1 -> 24x24x16
        x = self.bn1(x)
        x = F.relu(x)
        x = self.pool(x)             # 24x24x16 -> 12x12x16
        
        # Conv block 2
        x = self.conv2(x)           # 12x12x16 -> 10x10x32
        x = self.bn2(x)
        x = F.relu(x)
        x = self.pool(x)             # 10x10x32 -> 5x5x32
        
        # Flatten
        x = x.view(-1, 32 * 5 * 5)  # 5x5x32 -> 800
        
        # Fully connected
        x = self.fc1(x)
        x = F.relu(x)
        x = self.dropout(x)
        
        # Output
        x = self.fc2(x)
        return x


# ============================================================================
# Training Setup
# ============================================================================
# Hyperparameters
BATCH_SIZE = 64
LEARNING_RATE = 1e-3
NUM_EPOCHS = 20
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Create datasets
print("Generating training dataset...")
train_dataset = PhysicsSymbolDataset(num_samples_per_class=500, train=True)
print("Generating test dataset...")
test_dataset = PhysicsSymbolDataset(num_samples_per_class=100, train=False)

# Data loaders
train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, 
                         shuffle=True, num_workers=2)
test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, 
                        shuffle=False, num_workers=2)

# Initialize model
model = PhysicsSymbolCNN(num_classes=19).to(DEVICE)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE, 
                      weight_decay=1e-4)

# Learning rate scheduler
scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=7, gamma=0.5)

print(f"\nModel initialized on {DEVICE}")
print(f"Total parameters: {sum(p.numel() for p in model.parameters()):,}")

# ============================================================================
# Training Loop
# ============================================================================
train_losses = []
train_accs = []
test_accs = []

print("\n" + "="*70)
print("TRAINING STARTED")
print("="*70)

for epoch in range(NUM_EPOCHS):
    # Training phase
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    
    for batch_idx, (images, labels) in enumerate(train_loader):
        images, labels = images.to(DEVICE), labels.to(DEVICE)
        
        # Forward pass
        outputs = model(images)
        loss = criterion(outputs, labels)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        # Statistics
        running_loss += loss.item()
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()
    
    # Epoch statistics
    epoch_loss = running_loss / len(train_loader)
    epoch_acc = 100. * correct / total
    train_losses.append(epoch_loss)
    train_accs.append(epoch_acc)
    
    # Validation phase
    model.eval()
    correct = 0
    total = 0
    
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(DEVICE), labels.to(DEVICE)
            outputs = model(images)
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()
    
    test_acc = 100. * correct / total
    test_accs.append(test_acc)
    
    # Update learning rate
    scheduler.step()
    
    print(f"Epoch [{epoch+1}/{NUM_EPOCHS}] | "
          f"Loss: {epoch_loss:.4f} | "
          f"Train Acc: {epoch_acc:.2f}% | "
          f"Test Acc: {test_acc:.2f}% | "
          f"LR: {scheduler.get_last_lr()[0]:.6f}")

# ============================================================================
# Evaluation
# ============================================================================
print("\n" + "="*70)
print("FINAL EVALUATION")
print("="*70)

model.eval()
all_preds = []
all_labels = []

with torch.no_grad():
    for images, labels in test_loader:
        images = images.to(DEVICE)
        outputs = model(images)
        _, predicted = outputs.max(1)
        all_preds.extend(predicted.cpu().numpy())
        all_labels.extend(labels.numpy())

# Confusion matrix
cm = confusion_matrix(all_labels, all_preds)
symbol_names = train_dataset.symbols

# Classification report
print("\nClassification Report:")
print(classification_report(all_labels, all_preds, 
                           target_names=symbol_names, 
                           digits=3))

# ============================================================================
# Visualization
# ============================================================================
fig = plt.figure(figsize=(16, 12))

# Plot 1: Training curves
ax1 = plt.subplot(2, 3, 1)
ax1.plot(train_losses, 'b-', label='Training Loss', linewidth=2)
ax1.set_xlabel('Epoch')
ax1.set_ylabel('Loss')
ax1.set_title('Training Loss Over Time')
ax1.legend()
ax1.grid(True, alpha=0.3)

ax2 = plt.subplot(2, 3, 2)
ax2.plot(train_accs, 'g-', label='Train Accuracy', linewidth=2)
ax2.plot(test_accs, 'r-', label='Test Accuracy', linewidth=2)
ax2.set_xlabel('Epoch')
ax2.set_ylabel('Accuracy (%)')
ax2.set_title('Accuracy Over Time')
ax2.legend()
ax2.grid(True, alpha=0.3)

# Plot 2: Confusion matrix
ax3 = plt.subplot(2, 3, 3)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
           xticklabels=symbol_names, yticklabels=symbol_names, ax=ax3)
ax3.set_title('Confusion Matrix')
ax3.set_ylabel('True Label')
ax3.set_xlabel('Predicted Label')

# Plot 3: First convolutional layer filters
ax4 = plt.subplot(2, 3, 4)
conv1_weights = model.conv1.weight.data.cpu().numpy()
fig_filters, axes = plt.subplots(4, 4, figsize=(6, 6))
for i, ax in enumerate(axes.flat):
    if i < 16:
        ax.imshow(conv1_weights[i, 0], cmap='gray')
        ax.axis('off')
plt.suptitle('Learned Conv1 Filters (5x5)')
plt.tight_layout()

# Plot 4: Sample predictions
ax5 = plt.subplot(2, 3, 5)
n_samples = 10
sample_indices = np.random.choice(len(test_dataset), n_samples, replace=False)
fig_samples, axes_samples = plt.subplots(2, 5, figsize=(10, 4))

model.eval()
with torch.no_grad():
    for idx, ax in zip(sample_indices, axes_samples.flat):
        img, label = test_dataset[idx]
        img_input = img.unsqueeze(0).to(DEVICE)
        output = model(img_input)
        pred = output.argmax(dim=1).item()
        
        ax.imshow(img.squeeze(), cmap='gray')
        true_symbol = symbol_names[label]
        pred_symbol = symbol_names[pred]
        color = 'green' if pred == label else 'red'
        ax.set_title(f'T:{true_symbol} P:{pred_symbol}', color=color)
        ax.axis('off')

plt.suptitle('Sample Predictions (Green=Correct, Red=Wrong)')
plt.tight_layout()

# Plot 5: Per-class accuracy
ax6 = plt.subplot(2, 3, 6)
class_correct = np.diag(cm)
class_total = cm.sum(axis=1)
class_acc = 100 * class_correct / class_total

ax6.bar(range(len(symbol_names)), class_acc)
ax6.set_xlabel('Symbol Class')
ax6.set_ylabel('Accuracy (%)')
ax6.set_title('Per-Class Accuracy')
ax6.set_xticks(range(len(symbol_names)))
ax6.set_xticklabels(symbol_names, rotation=45)
ax6.axhline(y=95, color='r', linestyle='-', label='95% Target')
ax6.legend()
ax6.grid(True, alpha=0.3, axis='y')

plt.tight_layout()
plt.savefig('cnn_physics_symbols_results.png', dpi=300, bbox_inches='tight')
plt.show()

print(f"\nFinal Test Accuracy: {test_accs[-1]:.2f}%")
print(f"Best Test Accuracy: {max(test_accs):.2f}% (Epoch {np.argmax(test_accs)+1})")
