%% C020201Maths_Fundamental_code_117.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Trust-region algorithm
options_tr = optimoptions('fminunc', 'Algorithm', 'trust-region', ...
    'SpecifyObjectiveGradient', true, 'HessianFcn', 'objective');

% Requires both gradient and Hessian
objFull = @(x) deal(f(x), grad(x), hessian(x));

[xOpt, fOpt] = fminunc(objFull, x0, options_tr);
