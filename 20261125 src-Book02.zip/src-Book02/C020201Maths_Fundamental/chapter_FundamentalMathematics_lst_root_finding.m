%% chapter_FundamentalMathematics_lst_root_finding.m
% Root finding using MATLAB's built-in functions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_lst_root_finding
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section5.1_example1.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates root finding for nonlinear equations
%              and polynomials using fzero and roots

% - Part 1: Finding root of a nonlinear function using fzero -
% Define the function whose root is to be found, e.g., f(x) = x^3 - 2*x - 5
nonLinearFunction = @(x) x.^3 - 2*x - 5;

% Initial guess for the root
initialGuess_x0 = 2;
fprintf('Finding root of f(x) = x^3 - 2*x - 5 near x = %.2f\n', initialGuess_x0);

% Use fzero to find the root
try
    root_fzero = fzero(nonLinearFunction, initialGuess_x0);
    functionValueAtRoot = nonLinearFunction(root_fzero);
    
    fprintf('Root found by fzero: x = %.10f\n', root_fzero);
    fprintf('Function value at this root, f(x_root): %.2e\n', functionValueAtRoot);
catch ME
    fprintf('Error using fzero: %s\n', ME.message);
    root_fzero = NaN; % Assign NaN if fzero fails
end

% Example with an interval known to contain a root
% For f(x) = cos(x) - x, a root lies between 0 and pi/2
functionCosMinusX = @(x) cos(x) - x;
intervalWithRoot = [0, pi/2];
fprintf('\nFinding root of f(x) = cos(x) - x in interval [%.2f, %.2f]\n', ...
    intervalWithRoot(1), intervalWithRoot(2));
root_fzero_interval = fzero(functionCosMinusX, intervalWithRoot);
fprintf('Root found by fzero in interval: x = %.10f\n', root_fzero_interval);

% - Part 2: Finding roots of a polynomial using roots -
% Define polynomial coefficients p = [c_n, c_{n-1}, ..., c_1, c_0]
% Example: x^3 - 6*x^2 + 11*x - 6 = 0 (roots are 1, 2, 3)
polynomialCoefficients = [1, -6, 11, -6];
fprintf('\nFinding roots of polynomial P(x) = x^3 - 6*x^2 + 11*x - 6\n');

polynomialRoots = roots(polynomialCoefficients);
fprintf('Roots found by roots function:\n');
disp(sort(polynomialRoots)); % Display sorted roots

% Verify by evaluating the polynomial at these roots using polyval
polyValuesAtRoots = polyval(polynomialCoefficients, polynomialRoots);
fprintf('Polynomial values at computed roots (should be close to zero):\n');
for rootIdx = 1:length(polyValuesAtRoots)
    fprintf('  P(%.10f) = %.2e\n', polynomialRoots(rootIdx), ...
        polyValuesAtRoots(rootIdx));
end

% - Part 3: Visualisation of root-finding process -
figure('Position', [100, 100, 1200, 400]);

% Subplot 1: Nonlinear function
subplot(1, 3, 1);
xPlot = linspace(1.5, 2.5, 200);
yPlot = arrayfun(nonLinearFunction, xPlot);
plot(xPlot, yPlot, 'b-', 'LineWidth', 2);
hold on;
plot(root_fzero, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
plot([xPlot(1), xPlot(end)], [0, 0], 'k--', 'LineWidth', 1);
grid on;
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$f(x) = x^3 - 2*x - 5$', 'Interpreter', 'latex', 'FontSize', 12);
title('Root of Cubic Function', 'Interpreter', 'latex', 'FontSize', 14);
legend('$f(x)$', 'Root', 'Interpreter', 'latex', 'Location', 'best');

% Subplot 2: Transcendental function
subplot(1, 3, 2);
xPlot2 = linspace(0, pi/2, 200);
yPlot2_cos = cos(xPlot2);
yPlot2_x = xPlot2;
plot(xPlot2, yPlot2_cos, 'b-', 'LineWidth', 2);
hold on;
plot(xPlot2, yPlot2_x, 'r-', 'LineWidth', 2);
plot(root_fzero_interval, root_fzero_interval, 'ko', 'MarkerSize', 10, ...
    'MarkerFaceColor', 'g');
grid on;
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
title('Transcendental Equation $\cos(x) = x$', 'Interpreter', 'latex', 'FontSize', 14);
legend('$\cos(x)$', '$x$', 'Root', 'Interpreter', 'latex', 'Location', 'best');

% Subplot 3: Polynomial roots
subplot(1, 3, 3);
xPlot3 = linspace(0, 4, 200);
yPlot3 = polyval(polynomialCoefficients, xPlot3);
plot(xPlot3, yPlot3, 'b-', 'LineWidth', 2);
hold on;
realRoots = real(polynomialRoots(imag(polynomialRoots) == 0));
for rootIdx = 1:length(realRoots)
    plot(realRoots(rootIdx), 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
end
plot([xPlot3(1), xPlot3(end)], [0, 0], 'k--', 'LineWidth', 1);
grid on;
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$P(x) = x^3 - 6*x^2 + 11*x - 6$', 'Interpreter', 'latex', 'FontSize', 12);
title('Polynomial Roots', 'Interpreter', 'latex', 'FontSize', 14);
legend('$P(x)$', 'Roots', 'Interpreter', 'latex', 'Location', 'best');

% Save figure
saveas(gcf, 'root_finding_methods.png');
