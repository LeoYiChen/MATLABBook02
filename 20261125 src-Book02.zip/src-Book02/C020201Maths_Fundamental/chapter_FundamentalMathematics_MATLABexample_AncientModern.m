%% chapter_FundamentalMathematics_MATLABexample_AncientModern.m
% Connecting Ancient Methods to Modern Matrix Theory
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_AncientModern
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Demonstrate equivalence between Chinese column method and modern LU
A = [2 1 3;
     3 2 1;
     1 3 2];
b = [39; 34; 26];

fprintf('═══════════════════════════════════════════════════\n');
fprintf('Ancient Method vs. Modern Linear Algebra\n');
fprintf('═══════════════════════════════════════════════════\n\n');

% Ancient Chinese method (column operations)
fprintf('1. ANCIENT CHINESE FANGCHENG METHOD\n');
fprintf('───────────────────────────────────────────────────\n');
x_ancient = chineseFangcheng(A, b);

% Modern method using MATLAB's built-in solver
fprintf('\n2. MODERN MATLAB SOLVER (using LU decomposition)\n');
fprintf('───────────────────────────────────────────────────\n');
x_modern = A \ b;
fprintf('Solution: x₁ = %.4f, x₂ = %.4f, x₃ = %.4f\n', ...
        x_modern(1), x_modern(2), x_modern(3));

% Show LU factorization connection
fprintf('\n3. LU FACTORIZATION ANALYSIS\n');
fprintf('───────────────────────────────────────────────────\n');
[L, U, P] = lu(A);
fprintf('Lower triangular factor L:\n');
disp(L);
fprintf('Upper triangular factor U:\n');
disp(U);

% Demonstrate that ancient column operations create similar structure
fprintf(['\nThe Chinese counting board method creates upper\n' ...
         'triangular structure equivalent to the U factor\n' ...
         'in LU decomposition, demonstrating remarkable\n' ...
         'mathematical insight nearly 2000 years before\n' ...
         'modern matrix theory was formalized.\n']);

% Compute relative error
relativeError = norm(x_ancient - x_modern) / norm(x_modern);
fprintf('\nRelative error between methods: %.2e\n', relativeError);
fprintf('(Essentially identical solutions)\n');
