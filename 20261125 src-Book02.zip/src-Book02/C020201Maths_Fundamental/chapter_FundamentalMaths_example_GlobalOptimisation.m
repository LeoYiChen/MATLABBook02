%% chapter_FundamentalMaths_example_GlobalOptimisation.m
% Global optimisation using genetic algorithms and particle swarm optimisation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_GlobalOptimisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter06_CalculusOptimisation_Example06.m
% Author: Dr Leo Chen
% Date: June 5, 2025
% MATLAB Version: R2025a
% Description: Global optimisation using metaheuristic algorithms
%              including genetic algorithms and particle swarm.

function demonstrateGlobalOptimisation()
    fprintf('Global Optimisation with Metaheuristic Algorithms\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Genetic algorithm on Rastrigin function
    demonstrateGeneticAlgorithm();
    
    % Part 2: Particle swarm optimisation
    demonstrateParticleSwarm();
    
    % Part 3: Multi-start gradient descent
    demonstrateMultiStart();
end

function demonstrateGeneticAlgorithm()
    fprintf('Part 1: Genetic Algorithm on Rastrigin Function\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Rastrigin function: highly multimodal with many local minima
    % f(x) = 10*n + sum(x_i^2 - 10*cos(2*pi*x_i))
    % Global minimum: f(0,...,0) = 0
    
    n = 2; % Dimension
    A = 10;
    
    rastrigin = @(x) A*n + sum(x.^2 - A*cos(2*pi*x));
    
    fprintf('Rastrigin function (2*D):\n');
    fprintf('f(x,y) = 20 + x^2 + y^2 - 10*(cos(2*pi*x) + cos(2*pi*y))\n');
    fprintf('Global minimum: f(0,0) = 0\n');
    fprintf('Highly multimodal with many local minima\n\n');
    
    % Variable bounds
    lb = [-5.12, -5.12];
    ub = [5.12, 5.12];
    
    % GA options
    options = optimoptions('ga', ...
        'Display', 'iter', ...
        'PopulationSize', 100, ...
        'MaxGenerations', 200, ...
        'EliteCount', 10, ...
        'CrossoverFraction', 0.8, ...
        'PlotFcn', @gaplotbestf);
    
    fprintf('Genetic Algorithm Parameters:\n');
    fprintf('  Population size: 100\n');
    fprintf('  Maximum generations: 200\n');
    fprintf('  Elite count: 10 (best individuals preserved)\n');
    fprintf('  Crossover fraction: 0.8\n\n');
    
    % Run genetic algorithm
    rng(42); % For reproducibility
    [x_ga, fval_ga, exitflag, output] = ga(rastrigin, n, [], [], [], [], ...
                                            lb, ub, [], options);
    
    fprintf('\n%s\n', repmat('=', 1, 70));
    fprintf('Genetic Algorithm Results:\n');
    fprintf('  Optimal solution: [%.8f, %.8f]\n', x_ga(1), x_ga(2));
    fprintf('  Optimal value: %.10f\n', fval_ga);
    fprintf('  Generations: %d\n', output.generations);
    fprintf('  Function evaluations: %d\n', output.funccount);
    fprintf('  Distance from global optimum: %.8e\n\n', norm(x_ga));
    
    % Visualise Rastrigin function
    visualiseRastrigin(rastrigin, x_ga, lb, ub);
end

function demonstrateParticleSwarm()
    fprintf('Part 2: Particle Swarm Optimisation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Ackley function: another challenging multimodal function
    % f(x,y) = -20*exp(-0.2*sqrt(0.5*(x^2+y^2))) - 
    %          exp(0.5*(cos(2*pi*x)+cos(2*pi*y))) + e + 20
    % Global minimum: f(0,0) = 0
    
    ackley = @(x) -20*exp(-0.2*sqrt(0.5*(x(1)^2 + x(2)^2))) - ...
                   exp(0.5*(cos(2*pi*x(1)) + cos(2*pi*x(2)))) + ...
                   exp(1) + 20;
    
    fprintf('Ackley function (2*D):\n');
    fprintf('Highly multimodal with nearly flat outer region\n');
    fprintf('Global minimum: f(0,0) = 0\n\n');
    
    % Variable bounds
    lb = [-5, -5];
    ub = [5, 5];
    
    % Particle swarm options
    options = optimoptions('particleswarm', ...
        'Display', 'iter', ...
        'SwarmSize', 50, ...
        'MaxIterations', 200, ...
        'FunctionTolerance', 1e-8);
    
    fprintf('Particle Swarm Parameters:\n');
    fprintf('  Swarm size: 50\n');
    fprintf('  Maximum iterations: 200\n');
    fprintf('  Function tolerance: 1e-8\n\n');
    
    % Run particle swarm optimisation
    rng(42);
    nvars = 2;
    [x_pso, fval_pso, exitflag, output] = particleswarm(ackley, nvars, ...
                                                         lb, ub, options);
    
    fprintf('\n%s\n', repmat('=', 1, 70));
    fprintf('Particle Swarm Results:\n');
    fprintf('  Optimal solution: [%.8f, %.8f]\n', x_pso(1), x_pso(2));
    fprintf('  Optimal value: %.10f\n', fval_pso);
    fprintf('  Iterations: %d\n', output.iterations);
    fprintf('  Function evaluations: %d\n', output.funccount);
    fprintf('  Distance from global optimum: %.8e\n\n', norm(x_pso));
    
    % Visualise Ackley function
    visualiseAckley(ackley, x_pso, lb, ub);
end

function demonstrateMultiStart()
    fprintf('Part 3: Multi-Start Global Search\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Six-hump camel function
    % f(x,y) = (4 - 2.1*x^2 + x^4/3)*x^2 + x*y + (-4 + 4*y^2)*y^2
    % Has six local minima, two global minima
    
    camel = @(x) (4 - 2.1*x(1)^2 + x(1)^4/3)*x(1)^2 + ...
                 x(1)*x(2) + (-4 + 4*x(2)^2)*x(2)^2;
    
    fprintf('Six-hump camel function:\n');
    fprintf('Has six local minima, two global minima\n');
    fprintf('Global minimum: f ≈ -1.0316 at two symmetric points\n\n');
    
    % Variable bounds
    lb = [-3, -2];
    ub = [3, 2];
    
    % Create problem structure for MultiStart
    problem = createOptimProblem('fmincon', ...
        'objective', camel, ...
        'x0', [0, 0], ...
        'lb', lb, ...
        'ub', ub, ...
        'options', optimoptions('fmincon', 'Display', 'off', ...
                               'Algorithm', 'sqp'));
    
    % Multi-start options
    ms = MultiStart('Display', 'iter', ...
                    'UseParallel', false, ...
                    'StartPointsToRun', 'bounds');
    
    fprintf('Multi-Start Parameters:\n');
    fprintf('  Number of start points: 50\n');
    fprintf('  Local solver: fmincon (SQP)\n\n');
    
    % Run multi-start optimisation
    rng(42);
    [x_ms, fval_ms, exitflag, output, solutions] = run(ms, problem, 50);
    
    fprintf('\n%s\n', repmat('=', 1, 70));
    fprintf('Multi-Start Results:\n');
    fprintf('  Global minimum found: [%.8f, %.8f]\n', x_ms(1), x_ms(2));
    fprintf('  Global minimum value: %.10f\n', fval_ms);
    fprintf('  Total function evaluations: %d\n', output.funcCount);
    fprintf('  Local solver runs: %d\n', output.localSolverTotal);
    fprintf('  Successful runs: %d\n', output.localSolverSuccess);
    
    % Analyse all local minima found
    fprintf('\n  All distinct local minima found:\n');
    uniqueSolutions = [];
    uniqueValues = [];
    tolerance = 1e-4;
    
    for k = 1:length(solutions)
        x_local = solutions(k).X;
        fval_local = solutions(k).Fval;
        
        % Check if this is a new unique solution
        isNew = true;
        for j = 1:size(uniqueSolutions, 1)
            if norm(x_local - uniqueSolutions(j,:)) < tolerance
                isNew = false;
                break;
            end
        end
        
        if isNew
            uniqueSolutions = [uniqueSolutions; x_local'];
            uniqueValues = [uniqueValues; fval_local];
        end
    end
    
    % Sort by function value
    [uniqueValues, sortIdx] = sort(uniqueValues);
    uniqueSolutions = uniqueSolutions(sortIdx, :);
    
    for k = 1:size(uniqueSolutions, 1)
        fprintf('    %2*d: f = %12.8*f at [%8.4*f, %8.4*f]\n', ...
                k, uniqueValues(k), uniqueSolutions(k,1), uniqueSolutions(k,2));
    end
    
    fprintf('\n  Successfully identified both global minima!\n\n');
    
    % Visualise
    visualiseCamel(camel, uniqueSolutions, lb, ub);
end

function visualiseRastrigin(f, x_opt, lb, ub)
    figure('Position', [100, 100, 1200, 500]);
    
    [X, Y] = meshgrid(linspace(lb(1), ub(1), 200), ...
                      linspace(lb(2), ub(2), 200));
    Z = arrayfun(@(x,y) f([x, y]), X, Y);
    
    subplot(1, 2, 1);
    contour(X, Y, Z, 50);
    hold on;
    plot(x_opt(1), x_opt(2), 'r*', 'MarkerSize', 15, 'LineWidth', 2);
    plot(0, 0, 'go', 'MarkerSize', 10, 'LineWidth', 2);
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Rastrigin Function - Contour Plot', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Contours', 'GA Solution', 'Global Optimum', ...
           'Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    subplot(1, 2, 2);
    surf(X, Y, Z, 'EdgeColor', 'none');
    hold on;
    plot3(x_opt(1), x_opt(2), f([x_opt(1), x_opt(2)]), 'r*', ...
          'MarkerSize', 15, 'LineWidth', 2);
    plot3(0, 0, 0, 'go', 'MarkerSize', 12, 'LineWidth', 2);
    colormap('jet');
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$f(x,y)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Rastrigin Function - 3*D Surface', 'Interpreter', 'latex', ...
          'FontSize', 13);
    view(45, 30);
end

function visualiseAckley(f, x_opt, lb, ub)
    figure('Position', [100, 100, 1200, 500]);
    
    [X, Y] = meshgrid(linspace(lb(1), ub(1), 200), ...
                      linspace(lb(2), ub(2), 200));
    Z = arrayfun(@(x,y) f([x, y]), X, Y);
    
    subplot(1, 2, 1);
    contour(X, Y, Z, 50);
    hold on;
    plot(x_opt(1), x_opt(2), 'r*', 'MarkerSize', 15, 'LineWidth', 2);
    plot(0, 0, 'go', 'MarkerSize', 10, 'LineWidth', 2);
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Ackley Function - Contour Plot', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Contours', 'PSO Solution', 'Global Optimum', ...
           'Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    subplot(1, 2, 2);
    surf(X, Y, Z, 'EdgeColor', 'none');
    hold on;
    plot3(x_opt(1), x_opt(2), f([x_opt(1), x_opt(2)]), 'r*', ...
          'MarkerSize', 15, 'LineWidth', 2);
    plot3(0, 0, 0, 'go', 'MarkerSize', 12, 'LineWidth', 2);
    colormap('jet');
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$f(x,y)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Ackley Function - 3*D Surface', 'Interpreter', 'latex', ...
          'FontSize', 13);
    view(45, 30);
end

function visualiseCamel(f, solutions, lb, ub)
    figure('Position', [100, 100, 1200, 500]);
    
    [X, Y] = meshgrid(linspace(lb(1), ub(1), 200), ...
                      linspace(lb(2), ub(2), 200));
    Z = arrayfun(@(x,y) f([x, y]), X, Y);
    
    subplot(1, 2, 1);
    contour(X, Y, Z, 50);
    hold on;
    
    % Plot all local minima
    for k = 1:size(solutions, 1)
        if k <= 2
            plot(solutions(k,1), solutions(k,2), 'r*', 'MarkerSize', 15, ...
                 'LineWidth', 2);
        else
            plot(solutions(k,1), solutions(k,2), 'bo', 'MarkerSize', 8, ...
                 'LineWidth', 1.5);
        end
    end
    
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Six-Hump Camel Function - Local Minima', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Contours', 'Global Minima', 'Local Minima', ...
           'Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    subplot(1, 2, 2);
    surf(X, Y, Z, 'EdgeColor', 'none');
    hold on;
    
    for k = 1:size(solutions, 1)
        fval_k = f([solutions(k,1), solutions(k,2)]);
        if k <= 2
            plot3(solutions(k,1), solutions(k,2), fval_k, 'r*', ...
                  'MarkerSize', 15, 'LineWidth', 2);
        else
            plot3(solutions(k,1), solutions(k,2), fval_k, 'bo', ...
                  'MarkerSize', 8, 'LineWidth', 1.5);
        end
    end
    
    colormap('jet');
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$f(x,y)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Six-Hump Camel Function - 3*D Surface', 'Interpreter', 'latex', ...
          'FontSize', 13);
    view(45, 30);
end
