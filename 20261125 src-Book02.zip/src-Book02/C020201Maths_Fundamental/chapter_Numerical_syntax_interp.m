%% chapter_Numerical_syntax_interp.m
% Interpolation method syntax structure.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Numerical_syntax_interp
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Linear interpolation
y_linear = interp1(x_data, y_data, x_query, 'linear');

% Cubic spline interpolation
y_spline = interp1(x_data, y_data, x_query, 'spline');
% or equivalently
y_spline = spline(x_data, y_data, x_query);

% Shape-preserving interpolation
y_pchip = interp1(x_data, y_data, x_query, 'pchip');
