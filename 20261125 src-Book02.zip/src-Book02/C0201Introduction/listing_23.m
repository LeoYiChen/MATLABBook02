%% listing_23.m
% Colourblind-friendly palettes and line styles
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : listing_23
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Colourblind-friendly palettes
rng(23);

% Okabe-Ito palette (universally accessible)
colourOkabeIto = [
    0,    0,    0;      % Black
    230,  159,  0;      % Orange
    86,   180,  233;    % Sky Blue
    0,    158,  115;    % Bluish Green
    240,  228,  66;     % Yellow
    0,    114,  178;    % Blue
    213,  94,   0;      % Vermillion
    204,  121,  167     % Reddish Purple
] / 255;

% Apply to plot
figure;
hold on;
for i = 1:4
    data = rand(1, 100) * i;
    plot(data, 'Color', colourOkabeIto(i+1,:), 'LineWidth', 2, ...
        'DisplayName', sprintf('Series %d', i));
end
legend('Location', 'best');
title('Colourblind-Friendly Plot', 'FontSize', 14);

% Alternative: line styles AND Okabe-Ito colours (this figure is exported)
figure;
rng(23);  % reset so this figure is independent of the first
lineStyles = {'-', '--', '-.', ':'};
hold on;
for i = 1:4
    plot(rand(1, 100) * i, lineStyles{i}, ...
        'Color', colourOkabeIto(i+1,:), 'LineWidth', 2, ...
        'DisplayName', sprintf('Series %d', i));
end
legend('Location', 'northwest');
title('Lines Distinguishable by Style and Colour', 'FontSize', 14);
