%% chapter_Math_example_testing.m
% Unit testing example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_testing
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% File: testSumSquare.m
% Unit tests for sumSquare function

% Test basic functionality

% Test array inputs

% Test zero inputs

% Run tests
testBasicScalars();
testArrayInputs();
testZeros();
fprintf('All tests passed.\n');

% Local functions (moved to end so this listing is a valid MATLAB script)
function testBasicScalars
    result = sumSquare(3, 4);
    expected = 25;
    assert(abs(result - expected) < 1e-10, ...
        'Failed: sumSquare(3, 4) should equal 25');
end

function testArrayInputs
    result = sumSquare([1 2], [3 4]);
    expected = [10 20];
    assert(all(abs(result - expected) < 1e-10), ...
        'Failed: Array input test');
end

function testZeros
    result = sumSquare(0, 0);
    expected = 0;
    assert(result == expected, 'Failed: Zero input test');
end
