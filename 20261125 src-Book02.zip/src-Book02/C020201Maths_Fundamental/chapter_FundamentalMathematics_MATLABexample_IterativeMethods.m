%% chapter_FundamentalMathematics_MATLABexample_IterativeMethods.m
% Iterative methods for sparse linear systems.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_IterativeMethods
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_4_2_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates iterative methods for solving large sparse
%              linear systems, including conjugate gradient and GMRES.

function demonstrateIterativeMethods()
    fprintf('Iterative Methods for Sparse Linear Systems\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Sparse matrix characteristics
    demonstrateSparseMatrices();
    
    % Part 2: Conjugate Gradient method
    demonstrateConjugateGradient();
    
    % Part 3: GMRES for non-symmetric systems
    demonstrateGMRES();
    
    % Part 4: Preconditioning effects
    demonstratePreconditioning();
end

function demonstrateSparseMatrices()
    % Demonstrate sparse matrix characteristics and storage
    
    fprintf('Part 1: Sparse Matrix Characteristics\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create sparse matrix (5-point stencil from 2*D Poisson equation)
    n = 100; % Grid points per dimension
    N = n * n; % Total unknowns
    
    fprintf('Creating sparse matrix from 2*D Poisson equation discretization\n');
    fprintf('Grid size: %d $\times$ %d = %d total unknowns\n', n, n, N);
    
    % Build sparse matrix using finite differences
    e = ones(N, 1);
    A_sparse = spdiags([e, e, -4*e, e, e], [-n, -1, 0, 1, n], N, N);
    
    % Analyze sparsity
    numNonZero = nnz(A_sparse);
    totalElements = N^2;
    sparsityRatio = (totalElements - numNonZero) / totalElements * 100;
    
    fprintf('\nSparsity analysis:\n');
    fprintf('  Total matrix elements:    %d\n', totalElements);
    fprintf('  Non-zero elements:        %d\n', numNonZero);
    fprintf('  Sparsity:                 %.2f%%\n', sparsityRatio);
    fprintf('  Average non-zeros per row: %.1f\n', numNonZero / N);
    
    % Memory comparison
    A_full = full(A_sparse);
    memSparse = whos('A_sparse').bytes;
    memFull = whos('A_full').bytes;
    
    fprintf('\nMemory usage:\n');
    fprintf('  Sparse storage:  %10*d bytes (%.2f MB)\n', ...
            memSparse, memSparse / 1024^2);
    fprintf('  Dense storage:   %10*d bytes (%.2f MB)\n', ...
            memFull, memFull / 1024^2);
    fprintf('  Memory reduction: %.1f$\times$\n\n', memFull / memSparse);
    
    % Visualize sparsity pattern
    figure('Position', [100, 100, 800, 700]);
    spy(A_sparse);
    title('Sparsity Pattern of 2*D Poisson Matrix', ...
          'Interpreter', 'latex', 'FontSize', 14);
    xlabel('Column Index', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Row Index', 'Interpreter', 'latex', 'FontSize', 12);
    set(gca, 'FontSize', 11);
    
    fprintf('Sparsity pattern visualized (spy plot)\n');
    fprintf('Note the banded structure characteristic of PDE discretizations\n\n');
    
    clear A_full; % Free memory
end

function demonstrateConjugateGradient()
    % Demonstrate Conjugate Gradient method for symmetric positive definite systems
    
    fprintf('Part 2: Conjugate Gradient Method\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create symmetric positive definite sparse matrix
    n = 50;
    N = n * n;
    
    fprintf('System size: %d $\times$ %d\n', N, N);
    
    % 2*D Poisson equation: -∇²u = f
    e = ones(N, 1);
    A = spdiags([e, e, -4*e, e, e], [-n, -1, 0, 1, n], N, N);
    
    % Ensure symmetry and positive definiteness
    % (Already satisfied for this Poisson matrix)
    
    % Create right-hand side
    b = randn(N, 1);
    
    % Solve using conjugate gradient
    fprintf('\nSolving using Conjugate Gradient (CG)...\n');
    
    tolerance = 1e-6;
    maxIterations = 1000;
    
    [x_cg, flag, relres, iter, resvec] = ...
        pcg(A, b, tolerance, maxIterations);
    
    fprintf('Convergence information:\n');
    fprintf('  Flag:             %d ', flag);
    if flag == 0
        fprintf('(converged successfully)\n');
    else
        fprintf('(did not converge)\n');
    end
    fprintf('  Iterations:       %d\n', iter);
    fprintf('  Relative residual: %.6e\n', relres);
    
    % Verify solution
    actualResidual = norm(A * x_cg - b);
    fprintf('\nVerification:\n');
    fprintf('  ||Ax - b||:       %.6e\n', actualResidual);
    fprintf('  ||b||:            %.6e\n', norm(b));
    fprintf('  ||Ax - b|| / ||b||: %.6e\n\n', actualResidual / norm(b));
    
    % Plot convergence history
    figure('Position', [100, 100, 800, 600]);
    semilogy(0:length(resvec)-1, resvec / norm(b), 'b-o', ...
             'LineWidth', 2, 'MarkerSize', 5);
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Relative Residual $\|r_k\| / \|b\|$', ...
           'Interpreter', 'latex', 'FontSize', 12);
    title('Conjugate Gradient Convergence History', ...
          'Interpreter', 'latex', 'FontSize', 14);
    set(gca, 'FontSize', 11);
    
    fprintf('Convergence history plotted\n');
    fprintf('Note the monotonic decrease in residual norm\n\n');
end

function demonstrateGMRES()
    % Demonstrate GMRES for non-symmetric systems
    
    fprintf('Part 3: GMRES for Non-symmetric Systems\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create non-symmetric sparse matrix (convection-diffusion problem)
    n = 40;
    N = n * n;
    
    fprintf('System size: %d $\times$ %d (non-symmetric)\n', N, N);
    
    % Convection-diffusion operator with dominant convection
    e = ones(N, 1);
    A = spdiags([e, e, -4*e, e, e], [-n, -1, 0, 1, n], N, N);
    
    % Add convection term (breaks symmetry)
    convectionStrength = 2;
    A = A + convectionStrength * spdiags([e, -e], [-1, 1], N, N);
    
    % Verify non-symmetry
    symmetryError = norm(A - A', 'fro') / norm(A, 'fro');
    fprintf('Symmetry check: ||A - A''||_F / ||A||_F = %.6f\n', symmetryError);
    fprintf('(> 0 indicates non-symmetric matrix)\n\n');
    
    % Create right-hand side
    b = randn(N, 1);
    
    % Solve using GMRES
    fprintf('Solving using GMRES...\n');
    
    tolerance = 1e-6;
    restart = 50; % GMRES(50)
    maxIterations = 200;
    
    [x_gmres, flag, relres, iter, resvec] = ...
        gmres(A, b, restart, tolerance, maxIterations);
    
    fprintf('Convergence information:\n');
    fprintf('  Flag:             %d ', flag);
    if flag == 0
        fprintf('(converged successfully)\n');
    else
        fprintf('(did not converge)\n');
    end
    fprintf('  Iterations:       %d (outer), restart = %d\n', ...
            iter(1), restart);
    fprintf('  Relative residual: %.6e\n\n', relres);
    
    % Verify solution
    actualResidual = norm(A * x_gmres - b);
    fprintf('Verification: ||Ax - b|| = %.6e\n\n', actualResidual);
    
    % Plot convergence
    figure('Position', [100, 100, 800, 600]);
    semilogy(0:length(resvec)-1, resvec / norm(b), 'r-o', ...
             'LineWidth', 2, 'MarkerSize', 5);
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Relative Residual $\|r_k\| / \|b\|$', ...
           'Interpreter', 'latex', 'FontSize', 12);
    title('GMRES Convergence History', ...
          'Interpreter', 'latex', 'FontSize', 14);
    set(gca, 'FontSize', 11);
    
    fprintf('Convergence history plotted\n');
    fprintf('Note the sawtooth pattern due to restarts\n\n');
end

function demonstratePreconditioning()
    % Demonstrate effect of preconditioning on convergence
    
    fprintf('Part 4: Effect of Preconditioning\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create ill-conditioned system
    n = 30;
    N = n * n;
    
    fprintf('Creating ill-conditioned system (size %d $\times$ %d)\n', N, N);
    
    % 2*D Poisson with varying coefficients (creates ill-conditioning)
    e = ones(N, 1);
    A = spdiags([e, e, -4*e, e, e], [-n, -1, 0, 1, n], N, N);
    
    % Scale rows to create ill-conditioning
    scaling = 1 + 100 * rand(N, 1);
    D = spdiags(scaling, 0, N, N);
    A = D * A;
    
    condA = condest(A);
    fprintf('Estimated condition number: %.2e (ill-conditioned)\n\n', condA);
    
    b = randn(N, 1);
    tolerance = 1e-6;
    maxIterations = 500;
    
    % Solve WITHOUT preconditioning
    fprintf('Solving WITHOUT preconditioning...\n');
    tic;
    [x_no_precond, flag_no, relres_no, iter_no, resvec_no] = ...
        pcg(A, b, tolerance, maxIterations);
    time_no_precond = toc;
    
    fprintf('  Iterations: %d\n', iter_no);
    fprintf('  Time: %.4f seconds\n', time_no_precond);
    fprintf('  Relative residual: %.6e\n\n', relres_no);
    
    % Solve WITH incomplete Cholesky preconditioning
    fprintf('Solving WITH incomplete Cholesky preconditioner...\n');
    
    % Compute preconditioner
    L_precond = ichol(A);
    
    tic;
    [x_precond, flag_precond, relres_precond, iter_precond, resvec_precond] = ...
        pcg(A, b, tolerance, maxIterations, L_precond, L_precond');
    time_precond = toc;
    
    fprintf('  Iterations: %d\n', iter_precond);
    fprintf('  Time: %.4f seconds\n', time_precond);
    fprintf('  Relative residual: %.6e\n\n', relres_precond);
    
    fprintf('Preconditioning improvement:\n');
    fprintf('  Iteration reduction: %.1f$\times$ fewer iterations\n', ...
            iter_no / iter_precond);
    fprintf('  Time speedup: %.1f$\times$\n\n', time_no_precond / time_precond);
    
    % Compare convergence histories
    figure('Position', [100, 100, 1000, 600]);
    semilogy(0:length(resvec_no)-1, resvec_no / norm(b), ...
             'b-o', 'LineWidth', 2, 'MarkerSize', 5, ...
             'DisplayName', 'Without Preconditioning');
    hold on;
    semilogy(0:length(resvec_precond)-1, resvec_precond / norm(b), ...
             'r-s', 'LineWidth', 2, 'MarkerSize', 5, ...
             'DisplayName', 'With IC Preconditioning');
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Relative Residual $\|r_k\| / \|b\|$', ...
           'Interpreter', 'latex', 'FontSize', 12);
    title('Effect of Preconditioning on Convergence', ...
          'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northeast', 'FontSize', 11);
    set(gca, 'FontSize', 11);
    hold off;
    
    fprintf('Convergence comparison plotted\n');
    fprintf('Preconditioning dramatically accelerates convergence!\n');
end
