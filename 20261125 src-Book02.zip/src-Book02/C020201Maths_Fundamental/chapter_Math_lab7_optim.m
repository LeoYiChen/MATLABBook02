%% chapter_Math_lab7_optim.m
% Optimisation Algorithm Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab7_optim
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Lab7_OptimisationComparison()
    % LAB7_OPTIMISATIONCOMPARISON Compare optimisation algorithms
    %   Tests gradient descent, momentum, and Adam on non-convex functions
    
    fprintf('\\textbf{Optimisation Algorithm Comparison}\n');
    fprintf('===========================================\n\n');
    
    % Test both functions
    testRosenbrockOptimisation();
    testRastriginOptimisation();
end

function testRosenbrockOptimisation()
    % Test on Rosenbrock function
    fprintf('\\textbf{Test 1: Rosenbrock Function}\n');
    fprintf('Objective: $f(x) = (1-x_1)^2 + 100*(x_2-x_1^2)^2$\n');
    fprintf('Global minimum: $(1, 1)$ with $f = 0$\n\n');
    
    % Define Rosenbrock function and gradient
    rosenbrock = @(x) (1 - x(1))^2 + 100*(x(2) - x(1)^2)^2;
    grad_rosenbrock = @(x) [
        -2*(1 - x(1)) - 400*x(1)*(x(2) - x(1)^2);
        200*(x(2) - x(1)^2)
    ];
    
    % Initial point
    x0 = [-1.2; 1.0];  % Standard starting point
    
    % Algorithmic parameters
    max_iter = 5000;
    tol = 1e-6;
    
    % Test multiple learning rates
    learning_rates = [0.001, 0.01];
    
    results = struct();
    
    for lr_idx = 1:length(learning_rates)
        alpha = learning_rates(lr_idx);
        
        fprintf('Learning rate: %.4f\n', alpha);
        
        % Gradient Descent
        [x_gd, history_gd, converged_gd] = gradientDescent(...
            rosenbrock, grad_rosenbrock, x0, alpha, max_iter, tol);
        
        fprintf('  Gradient Descent:\n');
        fprintf('    Final point: (%.6f, %.6f)\n', x_gd(1), x_gd(2));
        fprintf('    Final value: %.6e\n', rosenbrock(x_gd));
        fprintf('    Iterations: %d\n', length(history_gd));
        fprintf('    Converged: %s\n', string(converged_gd));
        
        % Momentum
        beta = 0.9;
        [x_mom, history_mom, converged_mom] = momentum(...
            rosenbrock, grad_rosenbrock, x0, alpha, beta, max_iter, tol);
        
        fprintf('  Momentum (beta=%.2f):\n', beta);
        fprintf('    Final point: (%.6f, %.6f)\n', x_mom(1), x_mom(2));
        fprintf('    Final value: %.6e\n', rosenbrock(x_mom));
        fprintf('    Iterations: %d\n', length(history_mom));
        fprintf('    Converged: %s\n', string(converged_mom));
        
        % Adam
        beta1 = 0.9;
        beta2 = 0.999;
        [x_adam, history_adam, converged_adam] = adam(...
            rosenbrock, grad_rosenbrock, x0, alpha, beta1, beta2, max_iter, tol);
        
        fprintf('  Adam (beta1=%.2f, beta2=%.3f):\n', beta1, beta2);
        fprintf('    Final point: (%.6f, %.6f)\n', x_adam(1), x_adam(2));
        fprintf('    Final value: %.6e\n', rosenbrock(x_adam));
        fprintf('    Iterations: %d\n', length(history_adam));
        fprintf('    Converged: %s\n\n', string(converged_adam));
        
        % Store for visualisation
        results(lr_idx).alpha = alpha;
        results(lr_idx).history_gd = history_gd;
        results(lr_idx).history_mom = history_mom;
        results(lr_idx).history_adam = history_adam;
    end
    
    % Visualise optimisation trajectories
    visualiseRosenbrockTrajectories(rosenbrock, results);
end

function testRastriginOptimisation()
    % Test on Rastrigin function (more challenging, multimodal)
    fprintf('\\textbf{Test 2: Rastrigin Function (2*D)}\n');
    fprintf('Objective: $f(x) = 20 + x_1^2 + x_2^2 - 10*(\\cos(2\\pi x_1) + \\cos(2\\pi x_2))$\n');
    fprintf('Global minimum: $(0, 0)$ with $f = 0$\n\n');
    
    % Define Rastrigin function and gradient
    rastrigin = @(x) 20 + x(1)^2 + x(2)^2 - ...
        10*(cos(2*pi*x(1)) + cos(2*pi*x(2)));
    
    grad_rastrigin = @(x) [
        2*x(1) + 20*pi*sin(2*pi*x(1));
        2*x(2) + 20*pi*sin(2*pi*x(2))
    ];
    
    % Test multiple random starting points
    num_trials = 5;
    alpha = 0.01;
    max_iter = 3000;
    tol = 1e-6;
    
    success_gd = 0;
    success_mom = 0;
    success_adam = 0;
    
    fprintf('Running %d trials with random initialisation...\n', num_trials);
    
    for trial = 1:num_trials
        % Random initial point in [-5, 5]^2
        x0 = -5 + 10*rand(2, 1);
        
        % Gradient Descent
        [x_gd, ~, ~] = gradientDescent(...
            rastrigin, grad_rastrigin, x0, alpha, max_iter, tol);
        if rastrigin(x_gd) < 1e-2, success_gd = success_gd + 1; end
        
        % Momentum
        [x_mom, ~, ~] = momentum(...
            rastrigin, grad_rastrigin, x0, alpha, 0.9, max_iter, tol);
        if rastrigin(x_mom) < 1e-2, success_mom = success_mom + 1; end
        
        % Adam
        [x_adam, ~, ~] = adam(...
            rastrigin, grad_rastrigin, x0, alpha, 0.9, 0.999, max_iter, tol);
        if rastrigin(x_adam) < 1e-2, success_adam = success_adam + 1; end
    end
    
    fprintf('\nSuccess rates (finding global minimum):\n');
    fprintf('  Gradient Descent: %d/%d (%.0f%%)\n', ...
        success_gd, num_trials, 100*success_gd/num_trials);
    fprintf('  Momentum: %d/%d (%.0f%%)\n', ...
        success_mom, num_trials, 100*success_mom/num_trials);
    fprintf('  Adam: %d/%d (%.0f%%)\n\n', ...
        success_adam, num_trials, 100*success_adam/num_trials);
    
    % Visualise Rastrigin landscape
    visualiseRastriginLandscape(rastrigin);
end

% Helper functions for optimisation algorithms

function [x, history, converged] = gradientDescent(f, gradf, x0, alpha, max_iter, tol)
    % GRADIENTDESCENT Vanilla gradient descent implementation
    
    x = x0;
    history = zeros(2, max_iter);
    history(:, 1) = x;
    converged = false;
    
    for k = 1:max_iter-1
        grad = gradf(x);
        x = x - alpha * grad;
        history(:, k+1) = x;
        
        if norm(grad) < tol
            history = history(:, 1:k+1);
            converged = true;
            break;
        end
    end
end

function [x, history, converged] = momentum(f, gradf, x0, alpha, beta, max_iter, tol)
    % MOMENTUM Gradient descent with momentum
    
    x = x0;
    v = zeros(size(x0));
    history = zeros(2, max_iter);
    history(:, 1) = x;
    converged = false;
    
    for k = 1:max_iter-1
        grad = gradf(x);
        v = beta * v + grad;
        x = x - alpha * v;
        history(:, k+1) = x;
        
        if norm(grad) < tol
            history = history(:, 1:k+1);
            converged = true;
            break;
        end
    end
end

function [x, history, converged] = adam(f, gradf, x0, alpha, beta1, beta2, max_iter, tol)
    % ADAM Adaptive Moment Estimation optimiser
    
    x = x0;
    m = zeros(size(x0));  % First moment
    v = zeros(size(x0));  % Second moment
    epsilon = 1e-8;
    history = zeros(2, max_iter);
    history(:, 1) = x;
    converged = false;
    
    for k = 1:max_iter-1
        grad = gradf(x);
        
        % Update biased first and second moment estimates
        m = beta1 * m + (1 - beta1) * grad;
        v = beta2 * v + (1 - beta2) * (grad.^2);
        
        % Compute bias-corrected moment estimates
        m_hat = m / (1 - beta1^k);
        v_hat = v / (1 - beta2^k);
        
        % Update parameters
        x = x - alpha * m_hat ./ (sqrt(v_hat) + epsilon);
        history(:, k+1) = x;
        
        if norm(grad) < tol
            history = history(:, 1:k+1);
            converged = true;
            break;
        end
    end
end

function visualiseRosenbrockTrajectories(f, results)
    % VISUALISEROSENBROCKTRAJECTORIES Plot optimisation paths
    
    figure('Position', [100, 100, 1400, 500], ...
        'Name', 'Rosenbrock optimisation Trajectories');
    
    % Create mesh for contour plot
    x1 = linspace(-2, 2, 100);
    x2 = linspace(-1, 3, 100);
    [X1, X2] = meshgrid(x1, x2);
    Z = zeros(size(X1));
    
    for i = 1:numel(X1)
        Z(i) = f([X1(i); X2(i)]);
    end
    
    for idx = 1:length(results)
        subplot(1, length(results), idx);
        
        % Contour plot with logarithmic levels
        contour(X1, X2, log10(Z + 1), 30);
        hold on;
        colorbar;
        
        % Plot trajectories
        plot(results(idx).history_gd(1, :), results(idx).history_gd(2, :), ...
            'b.-', 'LineWidth', 1.5, 'MarkerSize', 4, 'DisplayName', 'GD');
        plot(results(idx).history_mom(1, :), results(idx).history_mom(2, :), ...
            'r.-', 'LineWidth', 1.5, 'MarkerSize', 4, 'DisplayName', 'Momentum');
        plot(results(idx).history_adam(1, :), results(idx).history_adam(2, :), ...
            'g.-', 'LineWidth', 1.5, 'MarkerSize', 4, 'DisplayName', 'Adam');
        
        % Mark start and end points
        plot(-1.2, 1.0, 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'k', ...
            'DisplayName', 'Start');
        plot(1, 1, 'kp', 'MarkerSize', 15, 'MarkerFaceColor', 'y', ...
            'DisplayName', 'Optimum');
        
        xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('$\\alpha = %.4f$', results(idx).alpha), ...
            'Interpreter', 'latex', 'FontSize', 14);
        legend('Interpreter', 'latex', 'Location', 'best');
        grid on;
        axis equal tight;
    end
end

function visualiseRastriginLandscape(f)
    % VISUALISERASTRIGINLANDSCAPE Show multimodal landscape
    
    figure('Position', [150, 150, 800, 600], ...
        'Name', 'Rastrigin Function Landscape');
    
    x1 = linspace(-5, 5, 200);
    x2 = linspace(-5, 5, 200);
    [X1, X2] = meshgrid(x1, x2);
    Z = zeros(size(X1));
    
    for i = 1:numel(X1)
        Z(i) = f([X1(i); X2(i)]);
    end
    
    surf(X1, X2, Z, 'EdgeColor', 'none');
    colormap(parula);
    colorbar;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$f(x)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Rastrigin Function (Highly Multimodal)', ...
        'Interpreter', 'latex', 'FontSize', 14);
    view(-30, 45);
    lighting gouraud;
    camlight;
end

% Execute laboratory
Lab7_OptimisationComparison();

% Added missing local function (book correction)
function [f, g] = rosenbrock(x)
f = 100*(x(2)-x(1)^2)^2 + (1-x(1))^2;
if nargout > 1, g = [-400*x(1)*(x(2)-x(1)^2)-2*(1-x(1)); 200*(x(2)-x(1)^2)]; end
end

% Added missing local function (book correction)
function f = rastrigin(x)
x = x(:); n = numel(x); f = 10*n + sum(x.^2 - 10*cos(2*pi*x));
end
