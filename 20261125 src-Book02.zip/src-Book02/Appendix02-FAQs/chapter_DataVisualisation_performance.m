%% chapter_DataVisualisation_performance.m
% Performance Optimization
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_performance
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Example of efficient handling of large datasets
function h = efficientPlot(x, y)
% Reduce number of points for large datasets
if length(x) > 1e4
step = floor(length(x)/1e4);
x = x(1:step:end);
y = y(1:step:end);
end

% Use efficient plotting
h = plot(x, y, '.', 'MarkerSize', 1);

% Disable automatic updating
set(h, 'DrawMode', 'fast');
drawnow;

end
