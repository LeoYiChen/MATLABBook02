%% chapter_FundamentalMaths_example_SVD.m
% Singular value decomposition and applications to data compression.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_SVD
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_LinearAlgebra_Example04.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Comprehensive demonstration of Singular Value Decomposition
%              with applications to image compression and low-rank approximation.

function demonstrateSVD()
    fprintf('Singular Value Decomposition in MATLAB\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic SVD computation
    demonstrateBasicSVD();
    
    % Part 2: Low-rank approximation
    demonstrateLowRankApproximation();
    
    % Part 3: Image compression
    demonstrateImageCompression();
    
    % Part 4: Noise filtering
    demonstrateNoiseFiltering();
    
    % Part 5: Pseudoinverse computation
    demonstratePseudoinverse();
end

function demonstrateBasicSVD()
    fprintf('Part 1: Basic SVD Computation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define rectangular matrix
    A = [1, 2, 3; 4, 5, 6];
    
    fprintf('Matrix A (2$\times$3):\n');
    disp(A);
    
    % Compute SVD
    [U, S, V] = svd(A);
    
    fprintf('\nLeft singular vectors U (2$\times$2):\n');
    disp(U);
    
    fprintf('Singular value matrix Σ (2$\times$3):\n');
    disp(S);
    
    fprintf('Right singular vectors V (3$\times$3):\n');
    disp(V);
    
    % Extract singular values
    singularValues = diag(S);
    fprintf('Singular values: ');
    fprintf('%.6f ', singularValues);
    fprintf('\n');
    
    % Verify decomposition
    A_reconstructed = U * S * V';
    fprintf('\nReconstructed A = UΣV'':\n');
    disp(A_reconstructed);
    
    reconstruction_error = norm(A - A_reconstructed, 'fro');
    fprintf('Reconstruction error: %.10e\n', reconstruction_error);
    
    % Verify orthogonality
    fprintf('\nVerify orthogonality of U: U''U =\n');
    disp(U' * U);
    
    fprintf('Verify orthogonality of V: V''V =\n');
    disp(V' * V);
    
    % Relationship to eigenvalues
    fprintf('\nRelationship to eigenvalue decomposition:\n');
    fprintf('Singular values of A = sqrt(eigenvalues of A''A)\n');
    
    ATA = A' * A;
    eigenvalues_ATA = sort(eig(ATA), 'descend');
    
    fprintf('Eigenvalues of A''A: ');
    fprintf('%.6f ', eigenvalues_ATA);
    fprintf('\n');
    
    fprintf('σ²: ');
    fprintf('%.6f ', singularValues.^2);
    fprintf('\n\n');
end

function demonstrateLowRankApproximation()
    fprintf('Part 2: Low-Rank Approximation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create low-rank matrix with noise
    fprintf('Creating noisy low-rank matrix...\n');
    
    m = 100;
    n = 80;
    trueRank = 5;
    
    % True low-rank component
    U_true = randn(m, trueRank);
    V_true = randn(n, trueRank);
    A_true = U_true * V_true';
    
    % Add noise
    noiseLevel = 0.1;
    noise = noiseLevel * norm(A_true, 'fro') * randn(m, n) / sqrt(m*n);
    A_noisy = A_true + noise;
    
    fprintf('Matrix size: %d $\times$ %d\n', m, n);
    fprintf('True rank: %d\n', trueRank);
    fprintf('Noise level: %.2f (relative)\n\n', noiseLevel);
    
    % Compute SVD
    [U, S, V] = svd(A_noisy);
    singularValues = diag(S);
    
    % Display singular values
    fprintf('First 10 singular values:\n');
    for k = 1:min(10, length(singularValues))
        fprintf('  σ_%d = %.6f\n', k, singularValues(k));
    end
    fprintf('\n');
    
    % Test different ranks
    ranks = [1, 2, 5, 10, 20];
    
    fprintf('Low-rank approximation errors:\n');
    fprintf('%8*s %20*s %20*s\n', 'Rank k', 'Error vs True', 'Error vs Noisy');
    fprintf('%s\n', repmat('-', 1, 50));
    
    for k = ranks
        % Truncated SVD
        A_approx = U(:, 1:k) * S(1:k, 1:k) * V(:, 1:k)';
        
        error_true = norm(A_approx - A_true, 'fro') / norm(A_true, 'fro');
        error_noisy = norm(A_approx - A_noisy, 'fro') / norm(A_noisy, 'fro');
        
        fprintf('%8*d %20.6*f %20.6*f\n', k, error_true, error_noisy);
    end
    
    fprintf('\nNote: Rank-5 approximation best recovers true signal.\n');
    fprintf('This demonstrates SVD''s effectiveness for noise reduction.\n\n');
    
    % Visualise singular value spectrum
    figure('Position', [100, 100, 800, 500]);
    semilogy(1:min(30, length(singularValues)), ...
             singularValues(1:min(30, length(singularValues))), ...
             'b-o', 'LineWidth', 2, 'MarkerSize', 6);
    hold on;
    plot([trueRank, trueRank], ylim, 'r--', 'LineWidth', 2);
    text(trueRank, singularValues(1), ' ← True rank', ...
         'FontSize', 11, 'Color', 'r');
    grid on;
    xlabel('Index $i$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Singular Value $\sigma_i$ (log scale)', ...
           'Interpreter', 'latex', 'FontSize', 12);
    title('Singular Value Spectrum', 'Interpreter', 'latex', ...
          'FontSize', 13);
    set(gca, 'FontSize', 11);
end

function demonstrateImageCompression()
    fprintf('Part 3: Image Compression via SVD\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create synthetic image
    [X, Y] = meshgrid(linspace(-2, 2, 200), linspace(-2, 2, 200));
    img = exp(-(X.^2 + Y.^2)) .* cos(4*X) .* sin(4*Y);
    img = mat2gray(img);
    
    fprintf('Image size: %d $\times$ %d\n', size(img, 1), size(img, 2));
    
    % Compute SVD
    [U, S, V] = svd(img);
    singularValues = diag(S);
    
    fprintf('Total singular values: %d\n\n', length(singularValues));
    
    % Test compression ratios
    ranks = [5, 10, 20, 50];
    
    fprintf('Compression analysis:\n');
    fprintf('%8*s %15*s %18*s %15*s\n', 'Rank k', 'Storage %%', ...
            'Rel. Error', 'PSNR (dB)');
    fprintf('%s\n', repmat('-', 1, 60));
    
    figure('Position', [100, 100, 1200, 800]);
    
    % Original image
    subplot(2, 3, 1);
    imshow(img);
    title('Original Image', 'Interpreter', 'latex', 'FontSize', 12);
    
    for idx = 1:length(ranks)
        k = ranks(idx);
        
        % Truncated SVD reconstruction
        img_compressed = U(:, 1:k) * S(1:k, 1:k) * V(:, 1:k)';
        
        % Storage calculation
        [m, n] = size(img);
        storage_compressed = m*k + k + n*k;
        storage_original = m * n;
        storage_ratio = storage_compressed / storage_original * 100;
        
        % Relative error
        rel_error = norm(img - img_compressed, 'fro') / norm(img, 'fro');
        
        % PSNR
        mse = mean((img(:) - img_compressed(:)).^2);
        psnr_value = 10 * log10(1 / mse);
        
        fprintf('%8*d %15.2*f %18.6*f %15.2*f\n', ...
                k, storage_ratio, rel_error, psnr_value);
        
        % Display compressed image
        subplot(2, 3, idx + 1);
        imshow(img_compressed);
        title(sprintf('Rank %d (%.1f\\%% storage)', k, storage_ratio), ...
              'Interpreter', 'latex', 'FontSize', 11);
    end
    
    % Singular value plot
    subplot(2, 3, 6);
    semilogy(1:min(100, length(singularValues)), ...
             singularValues(1:min(100, length(singularValues))), ...
             'b-', 'LineWidth', 2);
    hold on;
    
    for k = ranks
        plot(k, singularValues(k), 'ro', 'MarkerSize', 8, 'LineWidth', 2);
    end
    
    grid on;
    xlabel('Index', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Singular Value', 'Interpreter', 'latex', 'FontSize', 11);
    title('Singular Value Decay', 'Interpreter', 'latex', 'FontSize', 12);
    set(gca, 'FontSize', 10);
    
    fprintf('\nvisualisation demonstrates compression-quality trade-off\n\n');
end

function demonstrateNoiseFiltering()
    fprintf('Part 4: Noise Filtering via SVD\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create clean signal
    t = linspace(0, 1, 500);
    signal_clean = sin(2*pi*5*t) + 0.5*sin(2*pi*10*t);
    
    % Add noise
    rng(42);
    noise = 0.3 * randn(size(signal_clean));
    signal_noisy = signal_clean + noise;
    
    % Create trajectory matrix (Hankel matrix for time series)
    windowSize = 100;
    n = length(signal_noisy) - windowSize + 1;
    H = zeros(windowSize, n);
    
    for k = 1:n
        H(:, k) = signal_noisy(k:k+windowSize-1)';
    end
    
    fprintf('Created trajectory matrix: %d $\times$ %d\n', size(H, 1), size(H, 2));
    
    % SVD
    [U, S, V] = svd(H);
    singularValues = diag(S);
    
    fprintf('\nFirst 10 singular values:\n');
    for k = 1:10
        fprintf('  σ_%d = %.6f\n', k, singularValues(k));
    end
    
    % Reconstruct using top components
    numComponents = 5;
    H_denoised = U(:, 1:numComponents) * S(1:numComponents, 1:numComponents) * ...
                 V(:, 1:numComponents)';
    
    % Extract denoised signal (diagonal averaging)
    signal_denoised = zeros(size(signal_noisy));
    counts = zeros(size(signal_noisy));
    
    for k = 1:n
        indices = k:k+windowSize-1;
        signal_denoised(indices) = signal_denoised(indices) + H_denoised(:, k)';
        counts(indices) = counts(indices) + 1;
    end
    
    signal_denoised = signal_denoised ./ counts;
    
    % Compute errors
    error_noisy = norm(signal_clean - signal_noisy) / norm(signal_clean);
    error_denoised = norm(signal_clean - signal_denoised) / norm(signal_clean);
    
    fprintf('\nRelative error (noisy signal): %.6f\n', error_noisy);
    fprintf('Relative error (denoised): %.6f\n', error_denoised);
    fprintf('Noise reduction: %.2f%%\n\n', ...
            (1 - error_denoised/error_noisy) * 100);
    
    % Visualise
    figure('Position', [100, 100, 1200, 400]);
    
    subplot(1, 3, 1);
    plot(t, signal_clean, 'b-', 'LineWidth', 2);
    title('Clean Signal', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Time', 'Interpreter', 'latex');
    ylabel('Amplitude', 'Interpreter', 'latex');
    grid on;
    
    subplot(1, 3, 2);
    plot(t, signal_noisy, 'Color', [0.7, 0.7, 0.7], 'LineWidth', 1);
    hold on;
    plot(t, signal_clean, 'b-', 'LineWidth', 2);
    title('Noisy Signal', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Time', 'Interpreter', 'latex');
    ylabel('Amplitude', 'Interpreter', 'latex');
    legend('Noisy', 'Clean', 'Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    subplot(1, 3, 3);
    plot(t, signal_denoised, 'r-', 'LineWidth', 2);
    hold on;
    plot(t, signal_clean, 'b--', 'LineWidth', 1.5);
    title('SVD Denoised Signal', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Time', 'Interpreter', 'latex');
    ylabel('Amplitude', 'Interpreter', 'latex');
    legend('Denoised', 'Clean', 'Interpreter', 'latex', 'Location', 'best');
    grid on;
end

function demonstratePseudoinverse()
    fprintf('Part 5: Pseudoinverse Computation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create overdetermined system
    fprintf('Overdetermined system (more equations than unknowns):\n');
    
    A = [1, 2; 3, 4; 5, 6; 7, 8];
    b = [1; 2; 3; 4];
    
    fprintf('Matrix A (%d $\times$ %d):\n', size(A, 1), size(A, 2));
    disp(A);
    fprintf('Vector b:\n');
    disp(b);
    
    % Compute pseudoinverse
    A_pinv = pinv(A);
    fprintf('Pseudoinverse A+ (%d $\times$ %d):\n', size(A_pinv, 1), size(A_pinv, 2));
    disp(A_pinv);
    
    % Least-squares solution
    x_ls = A_pinv * b;
    fprintf('Least-squares solution x = A+b:\n');
    disp(x_ls);
    
    % Verify via SVD
    [U, S, V] = svd(A);
    
    % Create S+
    S_pinv = zeros(size(S'));
    for k = 1:min(size(S))
        if S(k,k) > 1e-10
            S_pinv(k,k) = 1/S(k,k);
        end
    end
    
    A_pinv_svd = V * S_pinv * U';
    fprintf('\nPseudoinverse via SVD: A+ = VS+U'':\n');
    disp(A_pinv_svd);
    
    error_pinv = norm(A_pinv - A_pinv_svd, 'fro');
    fprintf('Difference: %.10e\n', error_pinv);
    
    % Compute residual
    residual = A * x_ls - b;
    fprintf('\nResidual ||Ax - b||: %.6f\n', norm(residual));
    
    % Verify minimum norm property
    fprintf('Solution norm ||x||: %.6f\n', norm(x_ls));
    fprintf('\nThis is the minimum-norm least-squares solution\n');
end
