%% chapter_FundamentalMaths_example_GradientDescent.m
% Implementation of gradient descent algorithm with multiple test functions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_GradientDescent
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter06_CalculusOptimisation_Example02.m
% Author: Dr Leo Chen
% Date: June 5, 2025
% MATLAB Version: R2025a
% Description: Comprehensive gradient descent implementation with
%              visualisation, convergence analysis, and comparison
%              of different learning rate strategies.

function demonstrateGradientDescent()
    fprintf('Gradient Descent Optimisation\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic gradient descent on simple quadratic
    demonstrateBasicGradientDescent();
    
    % Part 2: Rosenbrock function (challenging non-convex)
    demonstrateRosenbrockOptimisation();
    
    % Part 3: Learning rate comparison
    demonstrateLearningRateComparison();
    
    % Part 4: Momentum-based gradient descent
    demonstrateMomentum();
    
    % Part 5: Stochastic gradient descent simulation
    demonstrateStochasticGD();
end

function demonstrateBasicGradientDescent()
    fprintf('Part 1: Basic Gradient Descent on Quadratic Function\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define quadratic function: f(x,y) = x^2 + 4*y^2
    f = @(x) x(1)^2 + 4*x(2)^2;
    grad_f = @(x) [2*x(1); 8*x(2)];
    
    fprintf('Objective function: f(x,y) = x^2 + 4*y^2\n');
    fprintf('Gradient: gradient f = [2*x, 8*y]\n');
    fprintf('Global minimum: (0, 0) with f* = 0\n\n');
    
    % Parameters
    x0 = [2.0; 1.5];
    alpha = 0.1;
    maxIter = 50;
    tolerance = 1e-6;
    
    fprintf('Initial point: [%.6f, %.6f]\n', x0(1), x0(2));
    fprintf('Learning rate: alpha = %.6f\n', alpha);
    fprintf('Tolerance: %.6e\n\n', tolerance);
    
    % Optimisation
    x = x0;
    history = zeros(2, maxIter);
    f_history = zeros(1, maxIter);
    grad_norm_history = zeros(1, maxIter);
    
    fprintf('%5*s %15*s %15*s %15*s\n', 'Iter', 'f(x)', '||x||', '||grad f||');
    fprintf('%s\n', repmat('-', 1, 55));
    
    for k = 1:maxIter
        history(:, k) = x;
        f_history(k) = f(x);
        grad = grad_f(x);
        grad_norm_history(k) = norm(grad);
        
        if mod(k, 5) == 0 || k == 1
            fprintf('%5*d %15.8*f %15.8*f %15.8*e\n', ...
                    k, f_history(k), norm(x), grad_norm_history(k));
        end
        
        % Check convergence
        if norm(grad) < tolerance
            history = history(:, 1:k);
            f_history = f_history(1:k);
            grad_norm_history = grad_norm_history(1:k);
            fprintf('\nConverged after %d iterations\n', k);
            break;
        end
        
        % Gradient descent update
        x = x - alpha * grad;
    end
    
    fprintf('\nFinal solution: [%.10f, %.10f]\n', x(1), x(2));
    fprintf('Final function value: %.10e\n', f(x));
    fprintf('Distance from optimum: %.10e\n\n', norm(x));
    
    % Visualise
    visualiseOptimisation(f, history, f_history, [-3, 3], [-2, 2], ...
                          'Gradient Descent on Quadratic Function');
end

function demonstrateRosenbrockOptimisation()
    fprintf('Part 2: Rosenbrock Function Optimisation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Rosenbrock function (challenging banana-shaped valley)
    a = 1;
    b = 100;
    f = @(x) (a - x(1))^2 + b*(x(2) - x(1)^2)^2;
    grad_f = @(x) [-2*(a - x(1)) - 4*b*x(1)*(x(2) - x(1)^2);
                   2*b*(x(2) - x(1)^2)];
    
    fprintf('Rosenbrock function: f(x,y) = (1-x)^2 + 100*(y-x^2)^2\n');
    fprintf('Global minimum: (1, 1) with f* = 0\n');
    fprintf('This is a challenging test function with a narrow valley\n\n');
    
    % Parameters
    x0 = [-1.2; 1.0];
    alpha = 0.001;
    maxIter = 20000;
    tolerance = 1e-6;
    
    fprintf('Initial point: [%.6f, %.6f]\n', x0(1), x0(2));
    fprintf('Initial function value: %.6f\n', f(x0));
    fprintf('Learning rate: alpha = %.6f\n', alpha);
    fprintf('Maximum iterations: %d\n\n', maxIter);
    
    % Optimisation
    x = x0;
    history = zeros(2, maxIter);
    f_history = zeros(1, maxIter);
    
    for k = 1:maxIter
        history(:, k) = x;
        f_history(k) = f(x);
        grad = grad_f(x);
        
        if norm(grad) < tolerance
            history = history(:, 1:k);
            f_history = f_history(1:k);
            fprintf('Converged after %d iterations\n', k);
            break;
        end
        
        x = x - alpha * grad;
    end
    
    fprintf('\nFinal solution: [%.10f, %.10f]\n', x(1), x(2));
    fprintf('Final function value: %.10e\n', f(x));
    fprintf('Error in x: %.10e\n', abs(x(1) - 1));
    fprintf('Error in y: %.10e\n\n', abs(x(2) - 1));
    
    % Visualise
    visualiseOptimisation(f, history, f_history, [-1.5, 1.5], [-0.5, 1.5], ...
                          'Gradient Descent on Rosenbrock Function');
end

function demonstrateLearningRateComparison()
    fprintf('Part 3: Learning Rate Comparison\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Simple quadratic with poor conditioning
    f = @(x) x(1)^2 + 25*x(2)^2;
    grad_f = @(x) [2*x(1); 50*x(2)];
    
    fprintf('Objective: f(x,y) = x^2 + 25*y^2 (poorly conditioned)\n');
    fprintf('Condition number: 25 (ratio of eigenvalues)\n\n');
    
    % Test different learning rates
    learning_rates = [0.01, 0.05, 0.1, 0.15];
    x0 = [3.0; 2.0];
    maxIter = 100;
    
    figure('Position', [100, 100, 1200, 800]);
    
    for idx = 1:length(learning_rates)
        alpha = learning_rates(idx);
        
        % Run optimisation
        x = x0;
        history = zeros(2, maxIter);
        f_history = zeros(1, maxIter);
        
        converged = false;
        for k = 1:maxIter
            history(:, k) = x;
            f_history(k) = f(x);
            grad = grad_f(x);
            
            if norm(grad) < 1e-8
                history = history(:, 1:k);
                f_history = f_history(1:k);
                converged = true;
                break;
            end
            
            x = x - alpha * grad;
            
            % Check for divergence
            if norm(x) > 1e6
                fprintf('alpha = %.3f: DIVERGED at iteration %d\n', alpha, k);
                break;
            end
        end
        
        if converged
            fprintf('alpha = %.3f: Converged in %d iterations\n', alpha, k);
        elseif norm(x) <= 1e6
            fprintf('alpha = %.3f: Did not converge within %d iterations\n', ...
                    alpha, maxIter);
        end
        
        % Plot convergence
        subplot(2, 2, idx);
        semilogy(1:length(f_history), f_history, 'b-', 'LineWidth', 2);
        grid on;
        xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('$f(x)$ (log scale)', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('Learning Rate $\\alpha = %.3f$', alpha), ...
              'Interpreter', 'latex', 'FontSize', 12);
        set(gca, 'FontSize', 10);
    end
    
    fprintf('\nLearning rate selection is critical for convergence speed\n');
    fprintf('Too small: slow convergence\n');
    fprintf('Too large: oscillation or divergence\n\n');
end

function demonstrateMomentum()
    fprintf('Part 4: Momentum-Based Gradient Descent\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Function with narrow valley
    f = @(x) 0.5*x(1)^2 + 4.5*x(2)^2;
    grad_f = @(x) [x(1); 9*x(2)];
    
    fprintf('Objective: f(x,y) = 0.5*x^2 + 4.5*y^2\n');
    fprintf('Comparing standard gradient descent vs momentum\n\n');
    
    x0 = [5.0; 5.0];
    alpha = 0.05;
    beta = 0.9; % Momentum coefficient
    maxIter = 100;
    
    % Standard gradient descent
    x_gd = x0;
    history_gd = zeros(2, maxIter);
    f_history_gd = zeros(1, maxIter);
    
    for k = 1:maxIter
        history_gd(:, k) = x_gd;
        f_history_gd(k) = f(x_gd);
        grad = grad_f(x_gd);
        
        if norm(grad) < 1e-8
            history_gd = history_gd(:, 1:k);
            f_history_gd = f_history_gd(1:k);
            break;
        end
        
        x_gd = x_gd - alpha * grad;
    end
    
    fprintf('Standard gradient descent: %d iterations\n', ...
            size(history_gd, 2));
    
    % Momentum-based gradient descent
    x_momentum = x0;
    v = zeros(2, 1); % Velocity
    history_momentum = zeros(2, maxIter);
    f_history_momentum = zeros(1, maxIter);
    
    for k = 1:maxIter
        history_momentum(:, k) = x_momentum;
        f_history_momentum(k) = f(x_momentum);
        grad = grad_f(x_momentum);
        
        if norm(grad) < 1e-8
            history_momentum = history_momentum(:, 1:k);
            f_history_momentum = f_history_momentum(1:k);
            break;
        end
        
        % Momentum update
        v = beta * v + alpha * grad;
        x_momentum = x_momentum - v;
    end
    
    fprintf('Momentum gradient descent: %d iterations\n', ...
            size(history_momentum, 2));
    fprintf('Speedup: %.2fx\n\n', size(history_gd, 2) / ...
            size(history_momentum, 2));
    
    % Visualise comparison
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    semilogy(1:size(f_history_gd, 2), f_history_gd, 'b-', ...
             'LineWidth', 2, 'DisplayName', 'Standard GD');
    hold on;
    semilogy(1:size(f_history_momentum, 2), f_history_momentum, 'r-', ...
             'LineWidth', 2, 'DisplayName', 'Momentum GD');
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f(x)$ (log scale)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Convergence Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 11);
    
    subplot(1, 2, 2);
    [X, Y] = meshgrid(linspace(-6, 6, 100), linspace(-6, 6, 100));
    Z = arrayfun(@(x,y) f([x;y]), X, Y);
    contour(X, Y, Z, 30, 'LineWidth', 0.5);
    hold on;
    plot(history_gd(1,:), history_gd(2,:), 'b-o', 'LineWidth', 1.5, ...
         'MarkerSize', 4, 'DisplayName', 'Standard GD');
    plot(history_momentum(1,:), history_momentum(2,:), 'r-o', ...
         'LineWidth', 1.5, 'MarkerSize', 4, 'DisplayName', 'Momentum GD');
    plot(0, 0, 'k*', 'MarkerSize', 15, 'LineWidth', 2, ...
         'DisplayName', 'Optimum');
    axis equal;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Optimisation Paths', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 10);
    
    fprintf('Momentum accelerates convergence by accumulating velocity\n');
    fprintf('Particularly effective for ill-conditioned problems\n');
end

function demonstrateStochasticGD()
    fprintf('Part 5: Stochastic Gradient Descent Simulation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Simulate least-squares problem: minimise ||Ax - b||^2
    rng(42);
    n = 20;     % Dimension
    m = 1000;   % Number of samples
    
    A = randn(m, n);
    x_true = randn(n, 1);
    b = A * x_true + 0.1 * randn(m, 1);
    
    % Full gradient function
    f = @(x) 0.5 * norm(A*x - b)^2;
    grad_f = @(x) A' * (A*x - b);
    
    fprintf('Least-squares problem: min ||Ax - b||^2\n');
    fprintf('Dimension: n = %d\n', n);
    fprintf('Number of samples: m = %d\n\n', m);
    
    % Parameters
    x0 = zeros(n, 1);
    alpha = 0.001;
    batchSize = 10;
    numEpochs = 50;
    
    % Batch gradient descent
    fprintf('Running batch gradient descent...\n');
    x_bgd = x0;
    f_history_bgd = zeros(numEpochs, 1);
    
    for epoch = 1:numEpochs
        grad = grad_f(x_bgd);
        x_bgd = x_bgd - alpha * grad;
        f_history_bgd(epoch) = f(x_bgd);
    end
    
    fprintf('Final error (BGD): %.6e\n', norm(x_bgd - x_true));
    
    % Stochastic gradient descent
    fprintf('Running stochastic gradient descent...\n');
    x_sgd = x0;
    f_history_sgd = zeros(numEpochs, 1);
    
    for epoch = 1:numEpochs
        % Shuffle data
        indices = randperm(m);
        
        % Mini-batch updates
        for k = 1:batchSize:m
            batch_indices = indices(k:min(k+batchSize-1, m));
            A_batch = A(batch_indices, :);
            b_batch = b(batch_indices);
            
            % Stochastic gradient
            grad_batch = A_batch' * (A_batch*x_sgd - b_batch);
            x_sgd = x_sgd - alpha * grad_batch;
        end
        
        f_history_sgd(epoch) = f(x_sgd);
    end
    
    fprintf('Final error (SGD): %.6e\n\n', norm(x_sgd - x_true));
    
    % Visualise
    figure('Position', [100, 100, 800, 500]);
    semilogy(1:numEpochs, f_history_bgd, 'b-', 'LineWidth', 2, ...
             'DisplayName', 'Batch GD');
    hold on;
    semilogy(1:numEpochs, f_history_sgd, 'r-', 'LineWidth', 2, ...
             'DisplayName', 'Stochastic GD');
    grid on;
    xlabel('Epoch', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Objective Value (log scale)', 'Interpreter', 'latex', ...
           'FontSize', 12);
    title('Batch vs Stochastic Gradient Descent', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 11);
    
    fprintf('SGD uses mini-batches instead of full dataset\n');
    fprintf('Faster per-iteration, but noisier convergence\n');
    fprintf('Widely used in deep learning for large datasets\n');
end

function visualiseOptimisation(f, history, f_history, xlim_range, ylim_range, titleStr)
    figure('Position', [100, 100, 1200, 500]);
    
    % Convergence plot
    subplot(1, 2, 1);
    semilogy(1:length(f_history), f_history, 'b-', 'LineWidth', 2);
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Function Value (log scale)', 'Interpreter', 'latex', ...
           'FontSize', 12);
    title('Convergence History', 'Interpreter', 'latex', 'FontSize', 13);
    set(gca, 'FontSize', 11);
    
    % Contour plot with path
    subplot(1, 2, 2);
    [X, Y] = meshgrid(linspace(xlim_range(1), xlim_range(2), 100), ...
                      linspace(ylim_range(1), ylim_range(2), 100));
    Z = arrayfun(@(x,y) f([x;y]), X, Y);
    
    contour(X, Y, Z, 30, 'LineWidth', 1);
    hold on;
    plot(history(1,:), history(2,:), 'r-o', 'LineWidth', 2, 'MarkerSize', 4);
    plot(history(1,1), history(2,1), 'gs', 'MarkerSize', 12, 'LineWidth', 2);
    plot(history(1,end), history(2,end), 'r*', 'MarkerSize', 15, ...
         'LineWidth', 2);
    
    colorbar;
    axis equal;
    xlim(xlim_range);
    ylim(ylim_range);
    grid on;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title(titleStr, 'Interpreter', 'latex', 'FontSize', 13);
    legend('Contours', 'Path', 'Start', 'End', 'Interpreter', 'latex', ...
           'Location', 'best', 'FontSize', 10);
    set(gca, 'FontSize', 11);
end
