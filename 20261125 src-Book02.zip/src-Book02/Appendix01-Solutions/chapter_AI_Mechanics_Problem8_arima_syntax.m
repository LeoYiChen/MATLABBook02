%% chapter_AI_Mechanics_Problem8_arima_syntax.m
% ARIMA model fitting and forecasting syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem8_arima_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Fit ARIMA model for baseline comparison
% y: univariate time series (1D array)

% Auto-select ARIMA order using AIC/BIC
model = arima('ARLags', 1:5, 'D', 1, 'MALags', 1:3);
[estModel, estParamCov, logL, info] = estimate(model, yTrain, 'Display', 'off');

fprintf('ARIMA model: p=%d, d=%d, q=%d\n', ...
    estModel.P, estModel.D, estModel.Q);

% Forecast horizon steps ahead
horizon = 168;
[yForecast, YMSE] = forecast(estModel, horizon, yTrain);

% Confidence intervals (95%)
CI_lower = yForecast - 1.96 * sqrt(YMSE);
CI_upper = yForecast + 1.96 * sqrt(YMSE);

% Evaluation
MAE_arima = mean(abs(yTest(1:horizon) - yForecast));
RMSE_arima = sqrt(mean((yTest(1:horizon) - yForecast).^2));
R2_arima = 1 - sum((yTest(1:horizon) - yForecast).^2) / ...
               sum((yTest(1:horizon) - mean(yTest(1:horizon))).^2);

fprintf('ARIMA Performance: MAE=%.4f, RMSE=%.4f, R=%.4f\n', ...
    MAE_arima, RMSE_arima, R2_arima);
