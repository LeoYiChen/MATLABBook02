%% chapter_CFDPrinciples_example_postprocessing.m
% Intelligent post-processing framework.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_postprocessing
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function postResults = intelligentPostProcessing(cfdSolution, geometryData, ...
    flowConditions, postProcessingTasks)
    % INTELLIGENTPOSTPROCESSING Physically-informed CFD post-processing
    % Extracts engineering-relevant quantities and features
    %
    % Inputs:
    %   cfdSolution         - Struct: velocity, pressure, turbulence fields
    %   geometryData        - Struct: surface normals, areas, reference geometry
    %   flowConditions      - Struct: freestream conditions, reference values
    %   postProcessingTasks - Cell array: requested analyses
    %
    % Output:
    %   postResults         - Comprehensive post-processing results
    %
    % Author: Dr Leo Chen
    % Institution: University of Cambridge
    % Version: 3.0
    
    fprintf('=== Intelligent Post-Processing ===\n\n');
    
    postResults = struct();
    
    % Process each requested task
    for i = 1:length(postProcessingTasks)
        task = postProcessingTasks{i};
        
        fprintf('Processing: %s\n', task);
        
        switch lower(task)
            case 'forces'
                postResults.forces = computeAerodynamicForces(cfdSolution, ...
                    geometryData, flowConditions);
                
            case 'pressure_distribution'
                postResults.pressureDistribution = analysePressureDistribution(...
                    cfdSolution, geometryData, flowConditions);
                
            case 'vortex_identification'
                postResults.vortices = identifyVortexStructures(cfdSolution);
                
            case 'boundary_layer'
                postResults.boundaryLayer = analyseBoundaryLayer(cfdSolution, ...
                    geometryData, flowConditions);
                
            case 'turbulence_statistics'
                postResults.turbulenceStats = computeTurbulenceStatistics(cfdSolution);
                
            otherwise
                warning('Unknown post-processing task: %s', task);
        end
    end
    
    % Generate comprehensive report
    generatePostProcessingReport(postResults);
    
    fprintf('\nPost-processing completed.\n');
end

function forces = computeAerodynamicForces(solution, geometry, conditions)
    % Compute integrated aerodynamic forces and moments
    
    fprintf('  Computing aerodynamic forces...\n');
    
    forces = struct();
    
    % Reference quantities
    rho_inf = conditions.density;
    U_inf = conditions.velocity;
    q_inf = 0.5 * rho_inf * U_inf^2;
    A_ref = conditions.referenceArea;
    
    % Extract wall surfaces
    wallSurfaces = geometry.wallSurfaces;
    numSurfaces = length(wallSurfaces);
    
    % Initialise force components
    F_pressure = zeros(3, 1);
    F_viscous = zeros(3, 1);
    
    % Integrate over all wall surfaces
    for i = 1:numSurfaces
        surf = wallSurfaces{i};
        
        % Pressure contribution
        for j = 1:surf.numFaces
            p = solution.pressure(surf.faceIDs(j));
            normal = surf.normals(j, :)';
            area = surf.areas(j);
            
            F_pressure = F_pressure + p * area * normal;
        end
        
        % Viscous contribution
        if isfield(solution, 'wallShearStress')
            for j = 1:surf.numFaces
                tau = solution.wallShearStress(surf.faceIDs(j), :)';
                area = surf.areas(j);
                
                F_viscous = F_viscous + tau * area;
            end
        end
    end
    
    % Total force
    F_total = F_pressure + F_viscous;
    
    % Force coefficients
    C_F = F_total / (q_inf * A_ref);
    
    % Decompose into lift and drag (assuming z-axis is lift direction)
    liftDirection = [0; 0; 1];
    dragDirection = [conditions.velocityDirection(1); conditions.velocityDirection(2); 0];
    dragDirection = dragDirection / norm(dragDirection);
    
    C_L = dot(C_F, liftDirection);
    C_D = dot(C_F, dragDirection);
    
    % Store results
    forces.pressure = F_pressure;
    forces.viscous = F_viscous;
    forces.total = F_total;
    forces.C_L = C_L;
    forces.C_D = C_D;
    forces.C_F = C_F;
    
    fprintf('    C_L = %.6f\n', C_L);
    fprintf('    C_D = %.6f\n', C_D);
    fprintf('    L/D = %.2f\n', C_L/C_D);
end

function pressureDist = analysePressureDistribution(solution, geometry, conditions)
    % Analyse pressure distribution and compute Cp
    
    fprintf('  Analysing pressure distribution...\n');
    
    pressureDist = struct();
    
    % Reference pressure
    p_inf = conditions.pressure;
    q_inf = 0.5 * conditions.density * conditions.velocity^2;
    
    % Compute pressure coefficient
    C_p = (solution.pressure - p_inf) / q_inf;
    
    pressureDist.C_p = C_p;
    pressureDist.C_p_min = min(C_p);
    pressureDist.C_p_max = max(C_p);
    pressureDist.C_p_mean = mean(C_p);
    
    fprintf('    Cp range: [%.4f, %.4f]\n', pressureDist.C_p_min, pressureDist.C_p_max);
end

function vortices = identifyVortexStructures(solution)
    % Identify vortex structures using Q-criterion
    
    fprintf('  Identifying vortex structures...\n');
    
    vortices = struct();
    
    % Compute velocity gradient tensor
    if isfield(solution, 'velocityGradient')
        gradU = solution.velocityGradient;
    else
        fprintf('    Warning: Velocity gradient not available\n');
        vortices.available = false;
        return;
    end
    
    numCells = size(gradU, 1);
    Q = zeros(numCells, 1);
    
    % Compute Q-criterion for each cell
    for i = 1:numCells
        % Extract gradient tensor (3x3)
        grad = reshape(gradU(i, :), 3, 3);
        
        % Symmetric (strain rate) and anti-symmetric (rotation) parts
        S = 0.5 * (grad + grad');
        Omega = 0.5 * (grad - grad');
        
        % Q-criterion
        Q(i) = 0.5 * (norm(Omega, 'fro')^2 - norm(S, 'fro')^2);
    end
    
    vortices.Q = Q;
    vortices.Q_max = max(Q);
    vortices.Q_threshold = 0.1 * vortices.Q_max;  % Typical threshold
    
    % Identify vortex cores
    vortices.vortexCells = find(Q > vortices.Q_threshold);
    vortices.numVortexCells = length(vortices.vortexCells);
    
    fprintf('    Vortex cells identified: %d (%.2f%% of domain)\n', ...
            vortices.numVortexCells, vortices.numVortexCells/numCells*100);
end

function blAnalysis = analyseBoundaryLayer(solution, geometry, conditions)
    % Analyse boundary layer characteristics
    
    fprintf('  Analysing boundary layer...\n');
    
    blAnalysis = struct();
    
    % Extract wall-normal profiles
    wallSurface = geometry.wallSurfaces{1};  % Primary wall
    
    % Compute boundary layer thickness (뿯½뿯½99)
    % Location where u = 0.99 * U_inf
    
    if isfield(solution, 'boundaryLayerThickness')
        blAnalysis.delta99 = solution.boundaryLayerThickness;
    else
        blAnalysis.delta99 = NaN;
    end
    
    % Displacement thickness
    if isfield(solution, 'displacementThickness')
        blAnalysis.deltastar = solution.displacementThickness;
    else
        blAnalysis.deltastar = NaN;
    end
    
    % Momentum thickness
    if isfield(solution, 'momentumThickness')
        blAnalysis.theta = solution.momentumThickness;
    else
        blAnalysis.theta = NaN;
    end
    
    % Shape factor
    if ~isnan(blAnalysis.deltastar) && ~isnan(blAnalysis.theta)
        blAnalysis.H = blAnalysis.deltastar / blAnalysis.theta;
        fprintf('    Shape factor H = %.3f\n', blAnalysis.H);
        
        % Turbulent BL typically H 뿯½뿯½ 1.3-1.4
        % Laminar BL typically H 뿯½뿯½ 2.6
        if blAnalysis.H > 2.0
            blAnalysis.regime = 'laminar';
        else
            blAnalysis.regime = 'turbulent';
        end
        
        fprintf('    Regime: %s\n', blAnalysis.regime);
    end
end

function turbStats = computeTurbulenceStatistics(solution)
    % Compute turbulence statistics
    
    fprintf('  Computing turbulence statistics...\n');
    
    turbStats = struct();
    
    if isfield(solution, 'turbulentKineticEnergy')
        k = solution.turbulentKineticEnergy;
        
        turbStats.k_mean = mean(k);
        turbStats.k_max = max(k);
        turbStats.k_std = std(k);
        
        fprintf('    TKE (mean): %.6e m?/s?\n', turbStats.k_mean);
        fprintf('    TKE (max): %.6e m?/s?\n', turbStats.k_max);
    end
    
    if isfield(solution, 'turbulentDissipation')
        epsilon = solution.turbulentDissipation;
        
        turbStats.epsilon_mean = mean(epsilon);
        turbStats.epsilon_max = max(epsilon);
        
        fprintf('    Dissipation (mean): %.6e m?/s?\n', turbStats.epsilon_mean);
    end
    
    % Turbulence intensity
    if isfield(solution, 'velocity') && isfield(solution, 'turbulentKineticEnergy')
        U_mag = sqrt(sum(solution.velocity.^2, 2));
        k = solution.turbulentKineticEnergy;
        
        TI = sqrt(2/3 * k) ./ U_mag;
        
        turbStats.TI_mean = mean(TI(U_mag > 0.01 * max(U_mag)));  % Exclude wake
        
        fprintf('    Turbulence intensity: %.2f%%\n', turbStats.TI_mean * 100);
    end
end

function generatePostProcessingReport(results)
    % Generate comprehensive post-processing report
    
    fprintf('\n=== POST-PROCESSING REPORT ===\n\n');
    
    if isfield(results, 'forces')
        fprintf('AERODYNAMIC FORCES:\n');
        fprintf('  Lift coefficient: %.6f\n', results.forces.C_L);
        fprintf('  Drag coefficient: %.6f\n', results.forces.C_D);
        fprintf('  Lift-to-drag ratio: %.2f\n', results.forces.C_L/results.forces.C_D);
        fprintf('\n');
    end
    
    if isfield(results, 'boundaryLayer')
        fprintf('BOUNDARY LAYER:\n');
        fprintf('  Regime: %s\n', results.boundaryLayer.regime);
        fprintf('  Shape factor: %.3f\n', results.boundaryLayer.H);
        fprintf('\n');
    end
    
    if isfield(results, 'vortices')
        fprintf('VORTEX STRUCTURES:\n');
        fprintf('  Vortex cells: %d\n', results.vortices.numVortexCells);
        fprintf('  Q (max): %.6e s??\n', results.vortices.Q_max);
        fprintf('\n');
    end
    
    fprintf('=== END OF REPORT ===\n');
end
