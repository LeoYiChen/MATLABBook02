%% ch08_prob1_code.m
% Datastore-based CSV loading and pre-processing (MATLABBook02_Chapter08_Problem1.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob1_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem1.m
% --------------------------------
% Purpose : Load and pre-process large CSV files using datastores.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later recommended
% --------------------------------
clc; clear; close all;

%% Step 1 – Generate synthetic CSV files for demonstration
dataFolder = fullfile(pwd, 'SyntheticSensorData');
if ~isfolder(dataFolder)
    mkdir(dataFolder);
end

numFiles        = 5;
rowsPerFile     = 200000;  % Adjust for available memory
featureNames    = {'Temperature','Pressure','Vibration','Humidity','Speed'};
numFeatures     = numel(featureNames);

fprintf('=== Step 1: Generating %d synthetic CSV files ===\n', numFiles);
for fileIndex = 1:numFiles
    rawData = randn(rowsPerFile, numFeatures) .* [10 5 2 15 50] + ...
              [25 101 0.5 60 1500];
    % Inject ~2 % missing values
    missingMask = rand(rowsPerFile, numFeatures) < 0.02;
    rawData(missingMask) = NaN;
    dataTable = array2table(rawData, 'VariableNames', featureNames);
    fileName  = fullfile(dataFolder, ...
                 sprintf('sensor_batch_%03d.csv', fileIndex));
    writetable(dataTable, fileName);
    fprintf('  Created: %s  (%d rows)\n', fileName, rowsPerFile);
end

%% Step 2 – Create tabularTextDatastore
fprintf('\n=== Step 2: Creating tabularTextDatastore ===\n');
sensorDatastore = tabularTextDatastore(dataFolder, ...
    'FileExtensions', '.csv', ...
    'MissingValue',   NaN);
fprintf('  Datastore created. Files detected: %d\n', ...
    numel(sensorDatastore.Files));

%% Step 3 – Preview the data
fprintf('\n=== Step 3: Previewing data ===\n');
previewData = preview(sensorDatastore);
disp(previewData);

%% Step 4 – Handle missing values via transform
cleanFunction = @(dataChunk) rmmissing(dataChunk);
cleanDatastore = transform(sensorDatastore, cleanFunction);
fprintf('=== Step 4: Missing-value removal transform applied ===\n');

%% Step 5 – Compute incremental summary statistics
fprintf('\n=== Step 5: Computing summary statistics incrementally ===\n');
reset(cleanDatastore);
runningSum   = zeros(1, numFeatures);
runningSumSq = zeros(1, numFeatures);
runningMin   = inf(1, numFeatures);
runningMax   = -inf(1, numFeatures);
totalRows    = 0;

while hasdata(cleanDatastore)
    chunk      = read(cleanDatastore);
    chunkArray = table2array(chunk);
    numRows    = size(chunkArray, 1);
    runningSum   = runningSum   + sum(chunkArray, 1, 'omitnan');
    runningSumSq = runningSumSq + sum(chunkArray.^2, 1, 'omitnan');
    runningMin   = min(runningMin, min(chunkArray, [], 1, 'omitnan'));
    runningMax   = max(runningMax, max(chunkArray, [], 1, 'omitnan'));
    totalRows    = totalRows + numRows;
end

globalMean = runningSum ./ totalRows;
globalStd  = sqrt(runningSumSq./totalRows - globalMean.^2);

fprintf('  Total clean rows : %d\n', totalRows);
for featureIdx = 1:numFeatures
    fprintf('  %12s | Mean: %8.3f | Std: %8.3f | Min: %8.3f | Max: %8.3f\n', ...
        featureNames{featureIdx}, globalMean(featureIdx), ...
        globalStd(featureIdx), runningMin(featureIdx), ...
        runningMax(featureIdx));
end

%% Step 6 – Normalise and export a cleaned subset
fprintf('\n=== Step 6: Normalising and exporting cleaned subset ===\n');
reset(cleanDatastore);
firstChunk    = read(cleanDatastore);
firstArray    = table2array(firstChunk);
normalisedArr = (firstArray - globalMean) ./ globalStd;
normalisedTbl = array2table(normalisedArr, 'VariableNames', featureNames);
outputFile    = fullfile(pwd, 'CleanedSensorSubset.csv');
writetable(normalisedTbl, outputFile);
fprintf('  Exported normalised subset to: %s\n', outputFile);

%% Step 7 – Visualise feature distributions
fprintf('\n=== Step 7: Generating distribution plots ===\n');
figHandle = figure('Name','Feature Distributions', ...
    'Position',[100 100 1200 800]);
for featureIdx = 1:numFeatures
    subplot(2, 3, featureIdx);
    histogram(normalisedArr(:, featureIdx), 50, ...
        'FaceColor', [0.2 0.4 0.8], 'EdgeColor', 'none');
    title(sprintf('$\\mathrm{%s}$', featureNames{featureIdx}), ...
        'Interpreter','latex', 'FontSize', 12);
    xlabel('Normalised Value', 'Interpreter','latex');
    ylabel('Frequency', 'Interpreter','latex');
    grid on;
end
sgtitle('\textbf{Feature Distributions (Normalised Subset)}', ...
    'Interpreter','latex', 'FontSize', 14);

%% Step 8 – Save figures
fprintf('\n=== Step 8: Saving figures ===\n');
savefig(figHandle, 'Ch08_Problem1_Distributions.fig');
exportgraphics(figHandle, 'Ch08_Problem1_Distributions.eps', ...
    'ContentType','vector');
exportgraphics(figHandle, 'Ch08_Problem1_Distributions.jpg', ...
    'Resolution', 300);
fprintf('  Saved: .fig, .eps, .jpg\n');

fprintf('\n=== Problem 1 Complete ===\n');
% --------------------------------
% Computational Complexity:
% Generating N rows across F files is O(N*F). Creating the datastore
% is O(F). The incremental statistics loop processes all rows once,
% giving O(N_total * numFeatures). Normalisation of a single chunk
% is O(chunkSize * numFeatures). Overall complexity is linear in
% the total number of data points: O(N_total * numFeatures). Space
% complexity is O(chunkSize * numFeatures) per iteration, which is
% independent of total dataset size-the key advantage of datastores.
% --------------------------------
