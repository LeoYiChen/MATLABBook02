%% chapter_FundamentalMathematics_Lab4_code.m
% Laboratory4: Statistical analysis and hypothesis testing.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_Lab4_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory exercise
laboratoryExercise4_StatisticalAnalysis();

% Local functions (moved to end so this listing is a valid MATLAB script)
function laboratoryExercise4_StatisticalAnalysis()
    % LABORATORYEXERCISE4_STATISTICALANALYSIS Hypothesis testing methods
    %   Comprehensive exploration of statistical inference techniques
    %
    %   Author: Dr Leo Chen
    %   Created: December 2024
    %   Version: 1.0
    %   MATLAB Version: R2023b or later
    
    fprintf('\\textbf{Laboratory4: Statistical Analysis}\n');
    fprintf('====================================================\n\n');
    
    %% Part A: Descriptive Statistics
    fprintf('\\textbf{PART A: DESCRIPTIVE STATISTICS}\n');
    fprintf('--------\n\n');
    
    fprintf(['Historical Context: Karl Pearson (1890*s) established\n', ...
        'modern descriptive statistics, developing measures like\n', ...
        'standard deviation, correlation, and skewness.\n\n']);
    
    % Generate sample data: exam scores
    rng(123, 'twister');
    numStudents = 100;
    
    % Mixture of two normal distributions (bimodal)
    group1 = 65 + 10 * randn(60, 1);
    group2 = 82 + 8 * randn(40, 1);
    examScores = [group1; group2];
    examScores = max(0, min(100, examScores));  % Bound to [0,100]
    
    fprintf('\\textbf{Dataset}: Examination scores ($n = %d$)\n\n', numStudents);
    
    % Compute comprehensive statistics
    meanScore = mean(examScores);
    medianScore = median(examScores);
    modeScore = mode(round(examScores));
    stdScore = std(examScores);
    varScore = var(examScores);
    rangeScore = range(examScores);
    iqrScore = iqr(examScores);
    
    % Quantiles
    quantiles = quantile(examScores, [0.25, 0.50, 0.75]);
    
    % Shape measures
    skewnessScore = skewness(examScores);
    kurtosisScore = kurtosis(examScores);
    
    fprintf('\\textbf{Measures of Central Tendency}:\n');
    fprintf('  Mean:   $\\bar{x} = %.2f$\n', meanScore);
    fprintf('  Median: $\\tilde{x} = %.2f$\n', medianScore);
    fprintf('  Mode:   $\\hat{x} = %.0f$\n\n', modeScore);
    
    fprintf('\\textbf{Measures of Dispersion}:\n');
    fprintf('  Standard deviation: $s = %.2f$\n', stdScore);
    fprintf('  Variance: $s^2 = %.2f$\n', varScore);
    fprintf('  Range: $R = %.2f$\n', rangeScore);
    fprintf('  Interquartile range: $IQR = %.2f$\n\n', iqrScore);
    
    fprintf('\\textbf{Quantiles}:\n');
    fprintf('  25*th percentile (Q1): %.2f\n', quantiles(1));
    fprintf('  50*th percentile (Q2/Median): %.2f\n', quantiles(2));
    fprintf('  75*th percentile (Q3): %.2f\n\n', quantiles(3));
    
    fprintf('\\textbf{Shape Measures}:\n');
    fprintf('  Skewness: $\\gamma_1 = %.3f$ ', skewnessScore);
    if abs(skewnessScore) < 0.5
        fprintf('(approximately symmetric)\n');
    elseif skewnessScore < 0
        fprintf('(left-skewed)\n');
    else
        fprintf('(right-skewed)\n');
    end
    
    fprintf('  Kurtosis: $\\gamma_2 = %.3f$ ', kurtosisScore);
    if kurtosisScore < 3
        fprintf('(platykurtic - flatter than normal)\n\n');
    elseif kurtosis > 3
        fprintf('(leptokurtic - more peaked than normal)\n\n');
    else
        fprintf('(mesokurtic - similar to normal)\n\n');
    end
    
    % Outlier detection using IQR method
    lowerFence = quantiles(1) - 1.5 * iqrScore;
    upperFence = quantiles(3) + 1.5 * iqrScore;
    outliers = examScores(examScores < lowerFence | examScores > upperFence);
    
    fprintf('\\textbf{Outlier Analysis} (Tukey''s method):\n');
    fprintf('  Lower fence: %.2f\n', lowerFence);
    fprintf('  Upper fence: %.2f\n', upperFence);
    fprintf('  Number of outliers: %d (%.1f\\%%)\n', length(outliers), ...
        100*length(outliers)/numStudents);
    if ~isempty(outliers)
        fprintf('  Outlier values: ');
        fprintf('%.1f ', outliers');
        fprintf('\n');
    end
    fprintf('\n');
    
    %% Part B: Probability Distributions
    fprintf('\\textbf{PART B: PROBABILITY DISTRIBUTIONS}\n');
    fprintf('--------\n\n');
    
    fprintf(['Historical Context: Abraham de Moivre (1733) derived\n', ...
        'the normal distribution; Laplace and Gauss established\n', ...
        'its centrality in probability theory.\n\n']);
    
    % Fit normal distribution to data
    [mu*Hat, sigma*Hat] = normfit(examScores);
    [mu*CI, sigma*CI] = normfit(examScores, 0.05);  % 95% CI
    
    fprintf('\\textbf{Normal Distribution Fit}:\n');
    fprintf('  Estimated mean: $\\hat{\\mu} = %.2f$ [%.2f, %.2f]\n', ...
        mu*Hat, mu*CI(1), mu*CI(2));
    fprintf('  Estimated std: $\\hat{\\sigma} = %.2f$ [%.2f, %.2f]\n\n', ...
        sigma*Hat, sigma*CI(1), sigma*CI(2));
    
    % Goodness-of-fit test: Kolmogorov-Smirnov
    [ksTestResult, ksTestPValue, ksStatistic] = ...
        kstest((examScores - mu*Hat) / sigma*Hat);
    
    fprintf('\\textbf{Normality Test} (Kolmogorov-Smirnov):\n');
    fprintf('  Test statistic: $D = %.4f$\n', ksStatistic);
    fprintf('  $p$-value: $p = %.4f$\n', ksTestPValue);
    
    if ksTestResult == 0
        fprintf('  Conclusion: Fail to reject normality ($p > 0.05$)\n\n');
    else
        fprintf('  Conclusion: Reject normality ($p < 0.05$)\n\n');
    end
    
    % Central Limit Theorem demonstration
    fprintf('\\textbf{Central Limit Theorem Demonstration}:\n');
    
    % Sample from exponential (highly skewed)
    numTrials = 10000;
    sampleSizes = [1, 5, 10, 30, 50];
    
    fprintf(['  Drawing samples from exponential distribution\n', ...
        '  (highly right-skewed, $\\lambda = 0.5$)\n\n']);
    
    sampleMeans = cell(length(sampleSizes), 1);
    
    for idx = 1:length(sampleSizes)
        n = sampleSizes(idx);
        sampleMatrix = exprnd(2, n, numTrials);  % lambda = 0.5
        sampleMeans{idx} = mean(sampleMatrix, 1);
        
        fprintf('  Sample size $n = %d$:\n', n);
        fprintf('    Mean of sample means: %.3f\n', mean(sampleMeans{idx}));
        fprintf('    Std of sample means: %.3f (theory: %.3f)\n', ...
            std(sampleMeans{idx}), 2/sqrt(n));
        
        % Test normality of sample means
        [~, cltPValue] = kstest(zscore(sampleMeans{idx}));
        fprintf('    Normality test $p$-value: %.4f\n\n', cltPValue);
    end
    
    %% Part C: Hypothesis Testing
    fprintf('\\textbf{PART C: HYPOTHESIS TESTING}\n');
    fprintf('------\n\n');
    
    fprintf(['Historical Context: Student (W.S. Gosset, 1908)\n', ...
        'developed t-test for small samples; Fisher (1925)\n', ...
        'formalised hypothesis testing framework.\n\n']);
    
    % One-sample t-test: Is mean score different from 70?
    hypothesisedMean = 70;
    [tTestResult, tTestPValue, tTestCI, tTestStats] = ...
        ttest(examScores, hypothesisedMean);
    
    fprintf('\\textbf{One-Sample t-Test}:\n');
    fprintf('  $H_0$: $\\mu = %.0f$ vs $H_1$: $\\mu \\neq %.0f$\n', ...
        hypothesisedMean, hypothesisedMean);
    fprintf('  Sample mean: $\\bar{x} = %.2f$\n', meanScore);
    fprintf('  Test statistic: $t = %.3f$\n', tTestStats.tstat);
    fprintf('  Degrees of freedom: $df = %d$\n', tTestStats.df);
    fprintf('  $p$-value: $p = %.4f$\n', tTestPValue);
    fprintf('  95\\%% CI: $[%.2f, %.2f]$\n', tTestCI(1), tTestCI(2));
    
    if tTestResult == 1
        fprintf(['  Conclusion: Reject $H_0$ at $\\alpha = 0.05$\n', ...
            '  (significant evidence that mean differs from %.0f)\n\n'], ...
            hypothesisedMean);
    else
        fprintf(['  Conclusion: Fail to reject $H_0$ at $\\alpha = 0.05$\n', ...
            '  (insufficient evidence that mean differs from %.0f)\n\n'], ...
            hypothesisedMean);
    end
    
    % Two-sample t-test: Compare two teaching methods
    method1Scores = 68 + 12 * randn(40, 1);
    method2Scores = 75 + 10 * randn(35, 1);
    
    [twoSampleResult, twoSamplePValue, twoSampleCI, twoSampleStats] = ...
        ttest2(method1Scores, method2Scores);
    
    fprintf('\\textbf{Two-Sample t-Test} (independent groups):\n');
    fprintf('  Comparing two teaching methods\n');
    fprintf('  $H_0$: $\\mu_1 = \\mu_2$ vs $H_1$: $\\mu_1 \\neq \\mu_2$\n\n');
    
    fprintf('  Method 1: $n_1 = %d$, $\\bar{x}_1 = %.2f$, $s_1 = %.2f$\n', ...
        length(method1Scores), mean(method1Scores), std(method1Scores));
    fprintf('  Method 2: $n_2 = %d$, $\\bar{x}_2 = %.2f$, $s_2 = %.2f$\n\n', ...
        length(method2Scores), mean(method2Scores), std(method2Scores));
    
    fprintf('  Test statistic: $t = %.3f$\n', twoSampleStats.tstat);
    fprintf('  Degrees of freedom: $df = %.1f$\n', twoSampleStats.df);
    fprintf('  $p$-value: $p = %.4f$\n', twoSamplePValue);
    fprintf('  95\\%% CI for difference: $[%.2f, %.2f]$\n', ...
        twoSampleCI(1), twoSampleCI(2));
    
    % Effect size: Cohen's d
    pooledStd = sqrt(((length(method1Scores)-1)*var(method1Scores) + ...
        (length(method2Scores)-1)*var(method2Scores)) / ...
        (length(method1Scores) + length(method2Scores) - 2));
    cohensD = (mean(method2Scores) - mean(method1Scores)) / pooledStd;
    
    fprintf('  Effect size (Cohen''s $d$): $d = %.3f$ ', cohensD);
    if abs(cohensD) < 0.2
        fprintf('(negligible)\n\n');
    elseif abs(cohensD) < 0.5
        fprintf('(small)\n\n');
    elseif abs(cohensD) < 0.8
        fprintf('(medium)\n\n');
    else
        fprintf('(large)\n\n');
    end
    
    % One-way ANOVA: Compare three teaching strategies
    strategy1 = 65 + 10 * randn(30, 1);
    strategy2 = 72 + 12 * randn(30, 1);
    strategy3 = 78 + 9 * randn(30, 1);
    
    allScores = [strategy1; strategy2; strategy3];
    groupLabels = [ones(30,1); 2*ones(30,1); 3*ones(30,1)];
    
    [anovaPValue, anovaTable, anovaStats] = anova1(allScores, ...
        groupLabels, 'off');
    
    fprintf('\\textbf{One-Way ANOVA} (three groups):\n');
    fprintf('  $H_0$: $\\mu_1 = \\mu_2 = \\mu_3$ vs $H_1$: not all means equal\n\n');
    
    fprintf('  Strategy 1: $\\bar{x}_1 = %.2f$, $s_1 = %.2f$\n', ...
        mean(strategy1), std(strategy1));
    fprintf('  Strategy 2: $\\bar{x}_2 = %.2f$, $s_2 = %.2f$\n', ...
        mean(strategy2), std(strategy2));
    fprintf('  Strategy 3: $\\bar{x}_3 = %.2f$, $s_3 = %.2f$\n\n', ...
        mean(strategy3), std(strategy3));
    
    fStatistic = anovaTable{2,5};
    dfBetween = anovaTable{2,3};
    dfWithin = anovaTable{3,3};
    
    fprintf('  $F$-statistic: $F_{%d,%d} = %.3f$\n', dfBetween, ...
        dfWithin, fStatistic);
    fprintf('  $p$-value: $p = %.4e$\n\n', anovaPValue);
    
    if anovaPValue < 0.05
        fprintf(['  Conclusion: Reject $H_0$ (significant differences\n', ...
            '  between at least two group means)\n\n']);
        
        % Post-hoc pairwise comparisons (Tukey HSD)
        fprintf('  \\textbf{Post-hoc Analysis} (Tukey HSD):\n');
        [comparison, ~, ~, groupNames] = multcompare(anovaStats, ...
            'Display', 'off');
        
        for idx = 1:size(comparison, 1)
            fprintf('    Group %d vs Group %d: ', comparison(idx,1), ...
                comparison(idx,2));
            if comparison(idx,6) < 0.05
                fprintf('Significant ($p = %.4f$)\n', comparison(idx,6));
            else
                fprintf('Not significant ($p = %.4f$)\n', comparison(idx,6));
            end
        end
        fprintf('\n');
    else
        fprintf(['  Conclusion: Fail to reject $H_0$ (no significant\n', ...
            '  differences detected)\n\n']);
    end
    
    % Correlation and simple linear regression
    fprintf('\\textbf{Correlation and Regression Analysis}:\n');
    
    % Generate correlated data: study hours vs exam score
    studyHours = 5 + 15 * rand(50, 1);
    examResults = 40 + 3 * studyHours + 8 * randn(50, 1);
    examResults = min(100, max(0, examResults));
    
    % Pearson correlation
    [rho, pValueCorr] = corr(studyHours, examResults);
    
    fprintf('  Variables: Study hours vs Exam score ($n = 50$)\n');
    fprintf('  Pearson correlation: $r = %.3f$\n', rho);
    fprintf('  $p$-value: $p = %.4e$\n', pValueCorr);
    fprintf('  Interpretation: ');
    
    if abs(rho) < 0.3
        fprintf('Weak correlation\n\n');
    elseif abs(rho) < 0.7
        fprintf('Moderate correlation\n\n');
    else
        fprintf('Strong correlation\n\n');
    end
    
    % Simple linear regression: score = beta0 + beta1 * hours
    regressionModel = fitlm(studyHours, examResults);
    
    fprintf('  \\textbf{Linear Regression Model}:\n');
    fprintf('    $\\hat{y} = %.2f + %.2f x$\n', ...
        regressionModel.Coefficients.Estimate(1), ...
        regressionModel.Coefficients.Estimate(2));
    fprintf('    $R^2 = %.3f$ (%.1f\\%% variance explained)\n', ...
        regressionModel.Rsquared.Ordinary, ...
        100*regressionModel.Rsquared.Ordinary);
    fprintf('    Adjusted $R^2 = %.3f$\n', regressionModel.Rsquared.Adjusted);
    fprintf('    RMSE = %.2f\n\n', regressionModel.RMSE);
    
    fprintf('  \\textbf{Coefficient Tests}:\n');
    fprintf('    Intercept: $\\beta_0 = %.2f$, $p = %.4f$\n', ...
        regressionModel.Coefficients.Estimate(1), ...
        regressionModel.Coefficients.pValue(1));
    fprintf('    Slope: $\\beta_1 = %.2f$, $p = %.4e$\n', ...
        regressionModel.Coefficients.Estimate(2), ...
        regressionModel.Coefficients.pValue(2));
    fprintf('    (Slope significantly different from zero)\n\n');
    
    % Bootstrap confidence interval for correlation
    fprintf('  \\textbf{Bootstrap Analysis} (correlation coefficient):\n');
    numBootstrap = 10000;
    
    bootstrapCorrelations = bootstrp(numBootstrap, ...
        @(x,y) corr(x,y), studyHours, examResults);
    
    bootstrapCI = prctile(bootstrapCorrelations, [2.5, 97.5]);
    
    fprintf('    Bootstrap samples: %d\n', numBootstrap);
    fprintf('    Bootstrap mean: $\\bar{r}_{boot} = %.3f$\n', ...
        mean(bootstrapCorrelations));
    fprintf('    Bootstrap std: $s_{boot} = %.4f$\n', ...
        std(bootstrapCorrelations));
    fprintf('    95\\%% Bootstrap CI: $[%.3f, %.3f]$\n\n', ...
        bootstrapCI(1), bootstrapCI(2));
    
    %% Visualisations
    createStatisticalPlots(examScores, quantiles, sampleMeans, ...
        sampleSizes, method1Scores, method2Scores, ...
        strategy1, strategy2, strategy3, studyHours, examResults, ...
        regressionModel);
    
    fprintf('\\textbf{Exercise Complete}\n\n');
    fprintf(['Key Insights:\n', ...
        '1. Descriptive statistics summarise data distributions\n', ...
        '2. Central Limit Theorem ensures normal sampling distributions\n', ...
        '3. Hypothesis tests quantify evidence against null hypotheses\n', ...
        '4. Effect sizes complement $p$-values for practical significance\n', ...
        '5. Bootstrap methods enable robust inference without assumptions\n']);
end

function createStatisticalPlots(scores, quants, sampleMeans, sizes, ...
    method1, method2, strat1, strat2, strat3, hours, results, model)
    % CREATESTATISTICALPLOTS Generate comprehensive visualisations
    
    figure('Position', [100, 100, 1600, 1000]);
    
    % Histogram with fitted normal
    subplot(3, 3, 1);
    histogram(scores, 'Normalization', 'pdf', 'FaceColor', [0.3, 0.6, 0.9]);
    hold on;
    xRange = linspace(min(scores), max(scores), 100);
    fittedPDF = normpdf(xRange, mean(scores), std(scores));
    plot(xRange, fittedPDF, 'r-', 'LineWidth', 2.5);
    xlabel('Exam Score', 'Interpreter', 'latex');
    ylabel('Probability Density', 'Interpreter', 'latex');
    title('Histogram with Fitted Normal', 'Interpreter', 'latex');
    legend({'Data', 'Fitted Normal'}, 'Interpreter', 'latex');
    grid on;
    
    % Box plot
    subplot(3, 3, 2);
    boxplot(scores, 'Orientation', 'horizontal');
    xlabel('Exam Score', 'Interpreter', 'latex');
    title('Box Plot (Outlier Detection)', 'Interpreter', 'latex');
    grid on;
    
    % Q-Q plot
    subplot(3, 3, 3);
    qqplot(scores);
    title('Q-Q Plot (Normality Assessment)', 'Interpreter', 'latex');
    grid on;
    
    % Central Limit Theorem demonstration
    subplot(3, 3, 4);
    hold on;
    colours = lines(length(sizes));
    for idx = 1:length(sizes)
        histogram(sampleMeans{idx}, 'Normalization', 'pdf', ...
            'FaceColor', colours(idx,:), 'FaceAlpha', 0.5, ...
            'DisplayName', sprintf('$n = %d$', sizes(idx)));
    end
    xlabel('Sample Mean', 'Interpreter', 'latex');
    ylabel('Density', 'Interpreter', 'latex');
    title('CLT: Distribution of Sample Means', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Two-sample comparison
    subplot(3, 3, 5);
    boxplot([method1; method2], [ones(length(method1),1); ...
        2*ones(length(method2),1)], 'Labels', {'Method 1', 'Method 2'});
    ylabel('Score', 'Interpreter', 'latex');
    title('Two Teaching Methods Comparison', 'Interpreter', 'latex');
    grid on;
    
    % ANOVA comparison
    subplot(3, 3, 6);
    boxplot([strat1; strat2; strat3], [ones(length(strat1),1); ...
        2*ones(length(strat2),1); 3*ones(length(strat3),1)], ...
        'Labels', {'Strategy 1', 'Strategy 2', 'Strategy 3'});
    ylabel('Score', 'Interpreter', 'latex');
    title('ANOVA: Three Strategies', 'Interpreter', 'latex');
    grid on;
    
    % Scatter plot with regression
    subplot(3, 3, 7);
    scatter(hours, results, 50, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    plot(model, 'LineWidth', 2);
    xlabel('Study Hours', 'Interpreter', 'latex');
    ylabel('Exam Score', 'Interpreter', 'latex');
    title(sprintf('Linear Regression ($R^2 = %.3f$)', ...
        model.Rsquared.Ordinary), 'Interpreter', 'latex');
    legend('off');
    grid on;
    
    % Residual plot
    subplot(3, 3, 8);
    plotResiduals(model, 'fitted');
    title('Residual Plot', 'Interpreter', 'latex');
    grid on;
    
    % Normal probability plot of residuals
    subplot(3, 3, 9);
    plotResiduals(model, 'probability');
    title('Residual Q-Q Plot', 'Interpreter', 'latex');
    grid on;
end

% Added missing local function (book correction)
function qqplot(x, varargin)
x=sort(x(:)); n=numel(x); q=sqrt(2)*erfinv(2*((1:n)'-0.5)/n-1);
plot(q,x,'o'); grid on; xlabel('Theoretical quantiles'); ylabel('Sample quantiles');
end
