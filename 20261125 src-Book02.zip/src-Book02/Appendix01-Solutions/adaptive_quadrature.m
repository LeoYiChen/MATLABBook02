%% adaptive_quadrature.m
% Adaptive Simpson's Quadrature
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : adaptive_quadrature
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem1.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Function to integrate
f = @(x) exp(x) .* sin(5*x);

% Visualise the function
x = linspace(0, 2, 1000);
y = f(x);
figure;
plot(x, y, 'LineWidth', 2);
grid on;
xlabel('x');
ylabel('f(x) = e^x sin(5x)');
title('Function for Integration');

% Parameters for adaptive quadrature
tol = 1e-10;
max_depth = 20;
evaluation_points = []; % To track function evaluations

% Adaptive Simpson's quadrature implementation
result = adaptive_simpson(f, 0, 2, tol, max_depth);

% Integration using MATLAB's built-in methods for comparison
standard_quad = integral(f, 0, 2);
trapz_result = trapz(x, y);
simp_result = (2-0)/6 * (f(0) + 4*f(1) + f(2));

% Show results
fprintf('Adaptive Simpson''s Quadrature: %.10f\n', result);
fprintf('MATLAB integral: %.10f\n', standard_quad);
fprintf('Trapezoid rule (1000 points): %.10f\n', trapz_result);
fprintf('Standard Simpson''s rule (3 points): %.10f\n', simp_result);

% Plot evaluation points from adaptive quadrature
figure;
plot(x, y, 'LineWidth', 1.5);
hold on;
plot(evaluation_points, f(evaluation_points), 'ro', 'MarkerSize', 8);
grid on;
xlabel('x');
ylabel('f(x)');
title('Adaptive Quadrature Evaluation Points');
legend('Function', 'Evaluation Points');

% Recursive adaptive Simpson's rule function
function [result, points] = adaptive_simpson(f, a, b, tol, max_depth, depth, points)
global evaluation_points;

if nargin < 6
    depth = 0;
    evaluation_points = [a, (a+b)/2, b];
end

% Evaluate function at endpoints and midpoint
h = b - a;
c = (a + b) / 2;

% Simpson's rule estimates
S1 = h/6 * (f(a) + 4*f(c) + f(b));

d = (a + c) / 2;
e = (c + b) / 2;
evaluation_points = [evaluation_points, d, e];

S2 = h/12 * (f(a) + 4*f(d) + 2*f(c) + 4*f(e) + f(b));

% Error estimate
if abs(S2 - S1) <= 15*tol || depth >= max_depth
    result = S2 + (S2 - S1) / 15;  % Error correction
else
    % Recursively apply adaptive Simpson's rule
    [left_result, evaluation_points] = adaptive_simpson(f, a, c, tol/2, max_depth, depth+1, evaluation_points);
    [right_result, evaluation_points] = adaptive_simpson(f, c, b, tol/2, max_depth, depth+1, evaluation_points);
    result = left_result + right_result;
end

points = evaluation_points;

end
