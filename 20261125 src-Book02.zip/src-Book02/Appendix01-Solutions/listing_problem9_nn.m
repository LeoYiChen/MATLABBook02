%% listing_problem9_nn.m
% Problem 9: Neural network control for nonlinear plant identification and control, including NN class, backpropagation training, Van der Pol oscillator identification, inverse model controller, comparison with PID, and robustness analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem9_nn
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 9 - Neural Network Control
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: Neural network identification and control for Van der Pol
%              oscillator. Implements feedforward NN, backpropagation,
%              system identification, inverse model control, and comparison
%              with PID controller.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 9: Neural Network Control\n');
fprintf('==================================================================\n\n');

%% System: Van der Pol Oscillator
fprintf('=== Van der Pol Oscillator Dynamics ===\n');

plant.mu = 1.0;         % Nonlinearity parameter
plant.dt = 0.01;        % Time step (s)
plant.name = 'Van der Pol';

fprintf('System: %s oscillator\n', plant.name);
fprintf('Parameter   = %.2f\n', plant.mu);
fprintf('Time step dt = %.3f s\n\n', plant.dt);

%% Phase 1: Data Collection for System Identification
fprintf('=== Phase 1: Data Collection ===\n');

T_collect = 50;         % Collection time (s)
t_collect = 0:plant.dt:T_collect;
N_collect = length(t_collect);

fprintf('Collection duration: %.1f s\n', T_collect);
fprintf('Samples: %d\n', N_collect);

% PRBS input for system excitation
rng(42);
input_amplitude = 2.0;
switch_prob = 0.05;     % Probability of switching at each step

u_collect = zeros(N_collect, 1);
u_collect(1) = input_amplitude * (2*randi([0,1]) - 1);

for k = 2:N_collect
    if rand < switch_prob
        u_collect(k) = input_amplitude * (2*randi([0,1]) - 1);
    else
        u_collect(k) = u_collect(k-1);
    end
end

fprintf('Input: PRBS with amplitude  %.1f, switch prob = %.2f\n', ...
    input_amplitude, switch_prob);

% Simulate plant to collect output data
x_collect = zeros(N_collect, 2);
x_collect(1,:) = [0.1; 0];      % Initial condition

for k = 1:N_collect-1
    x_collect(k+1,:) = vanderpol_dynamics(x_collect(k,:)', u_collect(k), plant)';
end

y_collect = x_collect(:,1);     % Output = first state

fprintf('Output range: [%.3f, %.3f]\n', min(y_collect), max(y_collect));
fprintf('Data collection complete.\n\n');

%% Phase 2: Neural Network System Identification
fprintf('=== Phase 2: System Identification ===\n');

% Network architecture for identification
nn_id.n_inputs = 5;         % [y(k), y(k-1), u(k), u(k-1), u(k-2)]
nn_id.n_hidden = 10;        % Hidden layer neurons
nn_id.n_outputs = 1;        % y(k+1)
nn_id.activation = 'tanh';  % Activation function
nn_id.output_activation = 'linear';

fprintf('Identification network architecture:\n');
fprintf('  Input layer: %d neurons\n', nn_id.n_inputs);
fprintf('  Hidden layer: %d neurons (%s activation)\n', ...
    nn_id.n_hidden, nn_id.activation);
fprintf('  Output layer: %d neuron (%s activation)\n\n', ...
    nn_id.n_outputs, nn_id.output_activation);

% Prepare training data
ny_order = 2;       % Output history order
nu_order = 3;       % Input history order
delay_steps = max(ny_order, nu_order);

N_train = N_collect - delay_steps - 1;
X_train = zeros(N_train, nn_id.n_inputs);
T_train = zeros(N_train, 1);

% Normalize data
y_mean = mean(y_collect);
y_std = std(y_collect);
u_mean = mean(u_collect);
u_std = std(u_collect);

y_norm = (y_collect - y_mean) / y_std;
u_norm = (u_collect - u_mean) / u_std;

for i = 1:N_train
    k = delay_steps + i;
    X_train(i,:) = [y_norm(k), y_norm(k-1), ...
                    u_norm(k), u_norm(k-1), u_norm(k-2)];
    T_train(i) = y_norm(k+1);
end

fprintf('Training dataset prepared:\n');
fprintf('  Samples: %d\n', N_train);
fprintf('  Normalization: y_mean=%.3f, y_std=%.3f\n', y_mean, y_std);
fprintf('  Normalization: u_mean=%.3f, u_std=%.3f\n\n', u_mean, u_std);

% Train identification network
fprintf('Training identification network...\n');

training_params.learning_rate = 0.01;
training_params.momentum = 0.9;
training_params.max_epochs = 500;
training_params.batch_size = 32;
training_params.validation_split = 0.2;
training_params.patience = 20;      % Early stopping
training_params.min_delta = 1e-6;

[net_id, train_history] = train_neural_network(X_train, T_train, nn_id, training_params);

fprintf('Training complete. Final MSE: %.6f\n\n', train_history.mse(end));

%% Phase 3: Validate Identification Model
fprintf('=== Phase 3: Model Validation ===\n');

% One-step-ahead prediction
y_pred_onestep = zeros(N_train, 1);
for i = 1:N_train
    y_pred_onestep(i) = forward_pass(net_id, X_train(i,:)');
end

mse_onestep = mean((T_train - y_pred_onestep).^2);
fprintf('One-step-ahead MSE: %.6f\n', mse_onestep);

% Simulation mode (free-run prediction)
T_sim = 20;
t_sim = 0:plant.dt:T_sim;
N_sim = length(t_sim);

u_sim = sin(2*pi*0.2*t_sim)';       % Sinusoidal test input
u_sim_norm = (u_sim - u_mean) / u_std;

x_true = zeros(N_sim, 2);
x_true(1,:) = [0.5; 0];
y_true = zeros(N_sim, 1);
y_true(1) = x_true(1,1);

for k = 1:N_sim-1
    x_true(k+1,:) = vanderpol_dynamics(x_true(k,:)', u_sim(k), plant)';
    y_true(k+1) = x_true(k+1,1);
end

y_true_norm = (y_true - y_mean) / y_std;

% NN simulation
y_nn_sim = zeros(N_sim, 1);
y_nn_sim(1:delay_steps) = y_true_norm(1:delay_steps);

u_history = zeros(nu_order, 1);

for k = delay_steps+1:N_sim
    % Build input vector
    y_hist = y_nn_sim(k-1:-1:k-ny_order);
    
    % Update input history
    u_history = [u_sim_norm(k); u_history(1:end-1)];
    
    nn_input = [y_hist; u_history];
    
    y_nn_sim(k) = forward_pass(net_id, nn_input);
end

% Denormalize
y_nn_denorm = y_nn_sim * y_std + y_mean;

mse_sim = mean((y_true - y_nn_denorm).^2);
fprintf('Simulation mode MSE: %.6f\n\n', mse_sim);

%% Phase 4: Design Neural Network Controller
fprintf('=== Phase 4: Neural Network Controller Design ===\n');

% Inverse model controller architecture
nn_ctrl.n_inputs = 4;       % [y_d(k+1), y(k), y(k-1), u(k-1)]
nn_ctrl.n_hidden = 12;
nn_ctrl.n_outputs = 1;      % u(k)
nn_ctrl.activation = 'tanh';
nn_ctrl.output_activation = 'tanh';     % Bound output

fprintf('Controller network architecture:\n');
fprintf('  Input: desired output + state feedback\n');
fprintf('  Hidden: %d neurons\n', nn_ctrl.n_hidden);
fprintf('  Output: control signal (bounded)\n\n');

% Generate training data for inverse model
% Use identified forward model to generate consistent pairs

N_ctrl_train = 5000;
X_ctrl_train = zeros(N_ctrl_train, nn_ctrl.n_inputs);
T_ctrl_train = zeros(N_ctrl_train, 1);

fprintf('Generating controller training data (%d samples)...\n', N_ctrl_train);

% Random sampling approach
for i = 1:N_ctrl_train
    % Random states and inputs
    y_curr = randn * 2;
    y_prev = randn * 2;
    u_prev = randn * 2;
    u_trial = randn * 2;
    
    % Normalize
    y_curr_n = (y_curr - y_mean) / y_std;
    y_prev_n = (y_prev - y_mean) / y_std;
    u_prev_n = (u_prev - u_mean) / u_std;
    u_trial_n = (u_trial - u_mean) / u_std;
    
    % Predict next output using forward model
    fwd_input = [y_curr_n; y_prev_n; u_trial_n; u_prev_n; 0];
    y_next_n = forward_pass(net_id, fwd_input);
    
    % Training pair: given desired y_next, what u is needed
    X_ctrl_train(i,:) = [y_next_n; y_curr_n; y_prev_n; u_prev_n];
    T_ctrl_train(i) = u_trial_n;
end

fprintf('Training controller network...\n');

ctrl_train_params = training_params;
ctrl_train_params.max_epochs = 300;

[net_ctrl, ctrl_history] = train_neural_network(X_ctrl_train, T_ctrl_train, ...
    nn_ctrl, ctrl_train_params);

fprintf('Controller training complete. Final MSE: %.6f\n\n', ...
    ctrl_history.mse(end));

%% Phase 5: PID Controller Design (for comparison)
fprintf('=== Phase 5: PID Controller Design ===\n');

% Tune PID using trial and error or Ziegler-Nichols-like approach
pid.Kp = 5.0;
pid.Ki = 2.0;
pid.Kd = 1.0;
pid.integral = 0;
pid.prev_error = 0;

fprintf('PID gains: Kp=%.2f, Ki=%.2f, Kd=%.2f\n\n', pid.Kp, pid.Ki, pid.Kd);

%% Phase 6: Closed-Loop Simulation and Comparison
fprintf('=== Phase 6: Closed-Loop Tracking Performance ===\n');

T_test = 30;
t_test = 0:plant.dt:T_test;
N_test = length(t_test);

% Reference trajectory: multi-frequency sinusoid
y_desired = 1.5*sin(2*pi*0.1*t_test) + 0.5*sin(2*pi*0.3*t_test);

fprintf('Test duration: %.1f s\n', T_test);
fprintf('Reference: multi-frequency sinusoid\n\n');

% NN controller simulation
fprintf('Simulating with NN controller...\n');
[t_nn, y_nn, u_nn, x_nn] = simulate_nn_control(t_test, y_desired, ...
    net_ctrl, plant, y_mean, y_std, u_mean, u_std);

% PID controller simulation
fprintf('Simulating with PID controller...\n');
[t_pid, y_pid, u_pid, x_pid] = simulate_pid_control(t_test, y_desired, ...
    pid, plant);

% Performance metrics
e_nn = y_desired' - y_nn;
e_pid = y_desired' - y_pid;

mae_nn = mean(abs(e_nn));
rmse_nn = sqrt(mean(e_nn.^2));
ise_nn = sum(e_nn.^2) * plant.dt;
control_effort_nn = sum(u_nn.^2) * plant.dt;

mae_pid = mean(abs(e_pid));
rmse_pid = sqrt(mean(e_pid.^2));
ise_pid = sum(e_pid.^2) * plant.dt;
control_effort_pid = sum(u_pid.^2) * plant.dt;

fprintf('\n=== Performance Comparison ===\n');
fprintf('Neural Network Controller:\n');
fprintf('  MAE:  %.4f\n', mae_nn);
fprintf('  RMSE: %.4f\n', rmse_nn);
fprintf('  ISE:  %.4f\n', ise_nn);
fprintf('  Control effort: %.4f\n', control_effort_nn);

fprintf('\nPID Controller:\n');
fprintf('  MAE:  %.4f\n', mae_pid);
fprintf('  RMSE: %.4f\n', rmse_pid);
fprintf('  ISE:  %.4f\n', ise_pid);
fprintf('  Control effort: %.4f\n\n', control_effort_pid);

%% Phase 7: Robustness Test (Parameter Variation)
fprintf('=== Phase 7: Robustness Analysis ===\n');

mu_variations = [0.5, 1.0, 1.5, 2.0];
N_var = length(mu_variations);

rmse_nn_robust = zeros(N_var, 1);
rmse_pid_robust = zeros(N_var, 1);

fprintf('Testing robustness to parameter changes ( ):\n');

for i = 1:N_var
    plant_var = plant;
    plant_var.mu = mu_variations(i);
    
    % NN control
    [~, y_nn_r, ~, ~] = simulate_nn_control(t_test, y_desired, ...
        net_ctrl, plant_var, y_mean, y_std, u_mean, u_std);
    e_nn_r = y_desired' - y_nn_r;
    rmse_nn_robust(i) = sqrt(mean(e_nn_r.^2));
    
    % PID control
    pid_reset = pid;
    pid_reset.integral = 0;
    pid_reset.prev_error = 0;
    [~, y_pid_r, ~, ~] = simulate_pid_control(t_test, y_desired, ...
        pid_reset, plant_var);
    e_pid_r = y_desired' - y_pid_r;
    rmse_pid_robust(i) = sqrt(mean(e_pid_r.^2));
    
    fprintf('    = %.2f: NN RMSE = %.4f, PID RMSE = %.4f\n', ...
        mu_variations(i), rmse_nn_robust(i), rmse_pid_robust(i));
end

fprintf('\n');

%% Plotting Results
fprintf('=== Generating Plots ===\n');

% Figure 1: Training history
figure('Position', [50, 50, 1400, 500]);

subplot(1,2,1);
semilogy(train_history.mse, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Epoch', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('MSE (log scale)', 'Interpreter', 'latex', 'FontSize', 11);
title('Identification Network Training', 'Interpreter', 'latex', 'FontSize', 12);

subplot(1,2,2);
semilogy(ctrl_history.mse, 'r-', 'LineWidth', 1.5);
grid on;
xlabel('Epoch', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('MSE (log scale)', 'Interpreter', 'latex', 'FontSize', 11);
title('Controller Network Training', 'Interpreter', 'latex', 'FontSize', 12);

sgtitle('Neural Network Training Convergence', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem09_Training.fig');
saveas(gcf, 'Problem09_Training.eps', 'epsc');

% Figure 2: Model validation
figure('Position', [100, 100, 1400, 800]);

subplot(2,2,1);
plot(t_sim, y_true, 'k-', 'LineWidth', 1.5, 'DisplayName', 'True plant');
hold on;
plot(t_sim, y_nn_denorm, 'b-', 'LineWidth', 1.2, 'DisplayName', 'NN model');
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Output $y$', 'Interpreter', 'latex', 'FontSize', 10);
title('Free-Run Simulation (Model Validation)', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

subplot(2,2,2);
error_sim = y_true - y_nn_denorm;
plot(t_sim, error_sim, 'r-', 'LineWidth', 1.2);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Prediction Error', 'Interpreter', 'latex', 'FontSize', 10);
title(sprintf('Simulation Error (RMSE = %.4f)', sqrt(mean(error_sim.^2))), ...
    'Interpreter', 'latex', 'FontSize', 12);

subplot(2,2,3);
scatter(T_train, y_pred_onestep, 10, 'b', 'filled');
hold on;
plot([-3, 3], [-3, 3], 'k-', 'LineWidth', 1);
grid on;
axis equal;
xlabel('True $y(k+1)$', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Predicted $\hat{y}(k+1)$', 'Interpreter', 'latex', 'FontSize', 10);
title('One-Step Prediction Accuracy', 'Interpreter', 'latex', 'FontSize', 12);

subplot(2,2,4);
histogram(T_train - y_pred_onestep, 50, 'FaceColor', 'b', 'FaceAlpha', 0.6);
grid on;
xlabel('Prediction Error', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 10);
title('Error Distribution', 'Interpreter', 'latex', 'FontSize', 12);

sgtitle('System Identification Results', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem09_Identification.fig');
saveas(gcf, 'Problem09_Identification.eps', 'epsc');

% Figure 3: Closed-loop tracking
figure('Position', [150, 150, 1400, 900]);

subplot(3,2,1);
plot(t_test, y_desired, 'k-', 'LineWidth', 1.5, 'DisplayName', 'Desired');
hold on;
plot(t_nn, y_nn, 'b-', 'LineWidth', 1.2, 'DisplayName', 'NN');
plot(t_pid, y_pid, 'r:', 'LineWidth', 1.2, 'DisplayName', 'PID');
grid on;
ylabel('Output $y$', 'Interpreter', 'latex', 'FontSize', 10);
title('Tracking Performance', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

subplot(3,2,2);
plot(t_nn, e_nn, 'b-', 'LineWidth', 1.2, 'DisplayName', 'NN');
hold on;
plot(t_pid, e_pid, 'r:', 'LineWidth', 1.2, 'DisplayName', 'PID');
yline(0, 'k-', 'LineWidth', 1);
grid on;
ylabel('Tracking Error', 'Interpreter', 'latex', 'FontSize', 10);
title('Error Comparison', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

subplot(3,2,3);
plot(t_nn, u_nn, 'b-', 'LineWidth', 1.2, 'DisplayName', 'NN');
hold on;
plot(t_pid, u_pid, 'r:', 'LineWidth', 1.2, 'DisplayName', 'PID');
grid on;
ylabel('Control Signal $u$', 'Interpreter', 'latex', 'FontSize', 10);
title('Control Effort', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

subplot(3,2,4);
plot(x_nn(:,1), x_nn(:,2), 'b-', 'LineWidth', 1.2, 'DisplayName', 'NN');
hold on;
plot(x_pid(:,1), x_pid(:,2), 'r:', 'LineWidth', 1.2, 'DisplayName', 'PID');
grid on;
xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 10);
title('Phase Portrait', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

subplot(3,2,5);
histogram(e_nn, 40, 'FaceColor', 'b', 'FaceAlpha', 0.5, 'DisplayName', 'NN');
hold on;
histogram(e_pid, 40, 'FaceColor', 'r', 'FaceAlpha', 0.5, 'DisplayName', 'PID');
grid on;
xlabel('Error', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 10);
title('Error Distribution', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

subplot(3,2,6);
bar([mae_nn, mae_pid; rmse_nn, rmse_pid; ise_nn/10, ise_pid/10]);
set(gca, 'XTickLabel', {'MAE', 'RMSE', 'ISE/10'});
ylabel('Metric Value', 'Interpreter', 'latex', 'FontSize', 10);
title('Performance Metrics', 'Interpreter', 'latex', 'FontSize', 12);
legend({'NN', 'PID'}, 'Interpreter', 'latex', 'Location', 'best');
grid on;

sgtitle('Closed-Loop Control Performance Comparison', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem09_ClosedLoop.fig');
saveas(gcf, 'Problem09_ClosedLoop.eps', 'epsc');

% Figure 4: Robustness analysis
figure('Position', [200, 200, 800, 600]);

plot(mu_variations, rmse_nn_robust, 'b-o', 'LineWidth', 2, 'MarkerSize', 8, ...
    'MarkerFaceColor', 'b', 'DisplayName', 'NN Controller');
hold on;
plot(mu_variations, rmse_pid_robust, 'r-s', 'LineWidth', 2, 'MarkerSize', 8, ...
    'MarkerFaceColor', 'r', 'DisplayName', 'PID Controller');
grid on;
xlabel('Nonlinearity Parameter $\mu$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('RMSE', 'Interpreter', 'latex', 'FontSize', 11);
title('Robustness to Parameter Variations', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 11);

saveas(gcf, 'Problem09_Robustness.fig');
saveas(gcf, 'Problem09_Robustness.eps', 'epsc');

fprintf('All plots saved.\n\n');
fprintf('=== Problem 9 Complete ===\n');

%% Helper Functions

function x_next = vanderpol_dynamics(x, u, plant)
    % Van der Pol oscillator dynamics
    % x = [x1; x2], dx1/dt = x2, dx2/dt = mu*(1-x1^2)*x2 - x1 + u
    
    x1 = x(1);
    x2 = x(2);
    
    dx1 = x2;
    dx2 = plant.mu * (1 - x1^2) * x2 - x1 + u;
    
    % Euler integration
    x_next = x + plant.dt * [dx1; dx2];
end

function [net, history] = train_neural_network(X, T, architecture, params)
    % Train feedforward neural network using backpropagation
    
    [N, n_in] = size(X);
    n_hidden = architecture.n_hidden;
    n_out = architecture.n_outputs;
    
    % Initialize weights (Xavier initialization)
    net.W1 = randn(n_hidden, n_in) * sqrt(2 / n_in);
    net.b1 = zeros(n_hidden, 1);
    net.W2 = randn(n_out, n_hidden) * sqrt(2 / n_hidden);
    net.b2 = zeros(n_out, 1);
    net.activation = architecture.activation;
    net.output_activation = architecture.output_activation;
    
    % Training parameters
    lr = params.learning_rate;
    momentum = params.momentum;
    max_epochs = params.max_epochs;
    batch_size = params.batch_size;
    val_split = params.validation_split;
    
    % Split data
    N_train = floor(N * (1 - val_split));
    idx = randperm(N);
    
    X_tr = X(idx(1:N_train), :);
    T_tr = T(idx(1:N_train), :);
    X_val = X(idx(N_train+1:end), :);
    T_val = T(idx(N_train+1:end), :);
    
    % Momentum terms
    vW1 = zeros(size(net.W1));
    vb1 = zeros(size(net.b1));
    vW2 = zeros(size(net.W2));
    vb2 = zeros(size(net.b2));
    
    % Training history
    history.mse = zeros(max_epochs, 1);
    history.val_mse = zeros(max_epochs, 1);
    
    best_val_mse = inf;
    patience_counter = 0;
    
    for epoch = 1:max_epochs
        % Shuffle training data
        shuffle_idx = randperm(N_train);
        X_tr = X_tr(shuffle_idx, :);
        T_tr = T_tr(shuffle_idx, :);
        
        % Mini-batch training
        n_batches = ceil(N_train / batch_size);
        
        for batch = 1:n_batches
            batch_start = (batch - 1) * batch_size + 1;
            batch_end = min(batch * batch_size, N_train);
            
            X_batch = X_tr(batch_start:batch_end, :)';
            T_batch = T_tr(batch_start:batch_end, :)';
            
            % Forward pass
            [Y_batch, cache] = forward_pass_batch(net, X_batch);
            
            % Backward pass
            [dW1, db1, dW2, db2] = backward_pass(net, X_batch, T_batch, cache);
            
            % Update with momentum
            vW1 = momentum * vW1 - lr * dW1;
            vb1 = momentum * vb1 - lr * db1;
            vW2 = momentum * vW2 - lr * dW2;
            vb2 = momentum * vb2 - lr * db2;
            
            net.W1 = net.W1 + vW1;
            net.b1 = net.b1 + vb1;
            net.W2 = net.W2 + vW2;
            net.b2 = net.b2 + vb2;
        end
        
        % Compute epoch MSE
        Y_tr = forward_pass_batch(net, X_tr');
        mse_tr = mean((T_tr' - Y_tr').^2);
        
        Y_val = forward_pass_batch(net, X_val');
        mse_val = mean((T_val' - Y_val').^2);
        
        history.mse(epoch) = mse_tr;
        history.val_mse(epoch) = mse_val;
        
        % Early stopping
        if mse_val < best_val_mse - params.min_delta
            best_val_mse = mse_val;
            patience_counter = 0;
        else
            patience_counter = patience_counter + 1;
        end
        
        if patience_counter >= params.patience
            fprintf('  Early stopping at epoch %d\n', epoch);
            history.mse = history.mse(1:epoch);
            history.val_mse = history.val_mse(1:epoch);
            break;
        end
        
        if mod(epoch, 50) == 0
            fprintf('  Epoch %d/%d: Train MSE = %.6f, Val MSE = %.6f\n', ...
                epoch, max_epochs, mse_tr, mse_val);
        end
    end
end

function y = forward_pass(net, x)
    % Forward pass for single input
    
    % Hidden layer
    z1 = net.W1 * x + net.b1;
    a1 = activate(z1, net.activation);
    
    % Output layer
    z2 = net.W2 * a1 + net.b2;
    y = activate(z2, net.output_activation);
end

function [Y, cache] = forward_pass_batch(net, X)
    % Forward pass for batch of inputs
    % X: [n_in x batch_size]
    % Y: [n_out x batch_size]
    
    % Hidden layer
    Z1 = net.W1 * X + net.b1;
    A1 = activate(Z1, net.activation);
    
    % Output layer
    Z2 = net.W2 * A1 + net.b2;
    Y = activate(Z2, net.output_activation);
    
    % Cache for backward pass
    cache.X = X;
    cache.Z1 = Z1;
    cache.A1 = A1;
    cache.Z2 = Z2;
    cache.Y = Y;
end

function [dW1, db1, dW2, db2] = backward_pass(net, X, T, cache)
    % Backpropagation
    
    batch_size = size(X, 2);
    
    % Output layer gradient
    delta2 = (cache.Y - T) .* activate_derivative(cache.Z2, net.output_activation);
    
    dW2 = (delta2 * cache.A1') / batch_size;
    db2 = mean(delta2, 2);
    
    % Hidden layer gradient
    delta1 = (net.W2' * delta2) .* activate_derivative(cache.Z1, net.activation);
    
    dW1 = (delta1 * X') / batch_size;
    db1 = mean(delta1, 2);
end

function a = activate(z, type)
    % Activation function
    
    switch type
        case 'sigmoid'
            a = 1 ./ (1 + exp(-z));
        case 'tanh'
            a = tanh(z);
        case 'relu'
            a = max(0, z);
        case 'linear'
            a = z;
        otherwise
            error('Unknown activation function');
    end
end

function da = activate_derivative(z, type)
    % Activation function derivative
    
    switch type
        case 'sigmoid'
            sig = 1 ./ (1 + exp(-z));
            da = sig .* (1 - sig);
        case 'tanh'
            da = 1 - tanh(z).^2;
        case 'relu'
            da = double(z > 0);
        case 'linear'
            da = ones(size(z));
        otherwise
            error('Unknown activation function');
    end
end

function [t, y, u, x] = simulate_nn_control(t, y_ref, net_ctrl, plant, ...
    y_mean, y_std, u_mean, u_std)
    % Closed-loop simulation with NN controller
    
    N = length(t);
    dt = t(2) - t(1);
    
    x = zeros(N, 2);
    x(1,:) = [0; 0];        % Initial state
    
    y = zeros(N, 1);
    u = zeros(N, 1);
    
    y(1) = x(1,1);
    
    % History buffers
    y_hist = zeros(2, 1);
    u_hist = zeros(1, 1);
    
    for k = 1:N-1
        % Normalize current state
        y_curr_norm = (y(k) - y_mean) / y_std;
        y_ref_next_norm = (y_ref(k+1) - y_mean) / y_std;
        
        % Update histories
        y_hist = [y_curr_norm; y_hist(1)];
        
        % Controller input: [y_d(k+1), y(k), y(k-1), u(k-1)]
        ctrl_input = [y_ref_next_norm; y_hist; u_hist];
        
        % NN controller
        u_norm = forward_pass(net_ctrl, ctrl_input);
        
        % Denormalize and saturate
        u(k) = u_norm * u_std + u_mean;
        u(k) = max(min(u(k), 10), -10);     % Saturation limits
        
        % Update u history
        u_hist = (u(k) - u_mean) / u_std;
        
        % Plant dynamics
        x(k+1,:) = vanderpol_dynamics(x(k,:)', u(k), plant)';
        y(k+1) = x(k+1,1);
    end
    
    t = t(:);
    y = y(:);
    u = u(:);
end

function [t, y, u, x] = simulate_pid_control(t, y_ref, pid, plant)
    % Closed-loop simulation with PID controller
    
    N = length(t);
    dt = t(2) - t(1);
    
    x = zeros(N, 2);
    x(1,:) = [0; 0];
    
    y = zeros(N, 1);
    u = zeros(N, 1);
    
    y(1) = x(1,1);
    
    integral = pid.integral;
    prev_error = pid.prev_error;
    
    for k = 1:N-1
        error = y_ref(k) - y(k);
        integral = integral + error * dt;
        derivative = (error - prev_error) / dt;
        
        u(k) = pid.Kp * error + pid.Ki * integral + pid.Kd * derivative;
        
        % Anti-windup
        u(k) = max(min(u(k), 10), -10);
        
        prev_error = error;
        
        % Plant dynamics
        x(k+1,:) = vanderpol_dynamics(x(k,:)', u(k), plant)';
        y(k+1) = x(k+1,1);
    end
    
    t = t(:);
    y = y(:);
    u = u(:);
end
