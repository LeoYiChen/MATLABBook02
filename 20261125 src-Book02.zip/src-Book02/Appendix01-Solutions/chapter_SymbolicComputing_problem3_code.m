%% chapter_SymbolicComputing_problem3_code.m
% Symbolic differential equation system with AI enhancement.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_SymbolicComputing_problem3_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter_SymbolicComputing_Problem03.m
%
% Symbolic Differential Equation System with AI Enhancement
%
% Author: Dr Yi Chen
% Institution: University Engineering Department
% Date: 2024
% Version: 1.0
% MATLAB Version: R2024a
%
% Description: Advanced hybrid system combining symbolic DE solving
% with AI-enhanced techniques for complex dynamical systems

function symbolic_ai_differential_equation_system()
    %SYMBOLIC_AI_DIFFERENTIAL_EQUATION_SYSTEM Hybrid DE solver
    %   Combines symbolic methods with AI enhancement for complex systems
    
    clear; clc;
    
    % Display system header
    fprintf('Symbolic Differential Equation System with AI Enhancement\n');
    fprintf('========================================================\n\n');
    
    % Problem 1: Coupled oscillator system
    solve_coupled_oscillator_system();
    
    % Problem 2: Heat equation with symbolic boundary conditions
    solve_heat_equation_symbolic();
    
    % Problem 3: Van der Pol oscillator with parameter estimation
    solve_van_der_pol_with_ai();
    
    % Advanced AI-enhanced demonstrations
    demonstrate_ai_enhanced_techniques();
    
end

function solve_coupled_oscillator_system()
    %SOLVE_COUPLED_OSCILLATOR_SYSTEM Analyse coupled harmonic oscillators
    %   Solves:  +  x + k(x-y) = 0,  +  y + k(y-x) = 0
    
    fprintf('Problem 1: Coupled Oscillator System\n');
    fprintf('====================================\n');
    
    syms x(t) y(t) t omega1 omega2 k real
    syms A1 A2 B1 B2 C1 C2 D1 D2 real  % Integration constants
    
    % Define the coupled system
    eq1 = diff(x, t, 2) + omega1^2*x + k*(x - y) == 0;
    eq2 = diff(y, t, 2) + omega2^2*y + k*(y - x) == 0;
    
    fprintf('Coupled oscillator equations:\n');
    fprintf(' +  x + k(x-y) = 0\n');
    fprintf(' +  y + k(y-x) = 0\n\n');
    
    % Rewrite in matrix form for analysis
    fprintf('Matrix form analysis:\n');
    fprintf('Let z = [x, , y, ], then  = Az where:\n');
    
    % State-space representation
    %  = z ( = )
    %  = -(  + k)z + kz ( = -(  + k)x + ky)
    %  = z ( = )
    %  = kz - (  + k)z ( = kx - (  + k)y)
    
    A_matrix = [0, 1, 0, 0;
                -(omega1^2 + k), 0, k, 0;
                0, 0, 0, 1;
                k, 0, -(omega2^2 + k), 0];
    
    fprintf('System matrix A:\n');
    disp(A_matrix);
    
    % Solve symbolically using normal modes
    fprintf('\nNormal mode analysis:\n');
    fprintf('----------\n');
    
    % For identical oscillators (  =   =  ), the normal modes are:
    % Mode 1: x + y (symmetric mode, frequency  )
    % Mode 2: x - y (antisymmetric mode, frequency  (  + 2k))
    
    fprintf('For identical oscillators (  =   =  ):\n');
    fprintf('Symmetric mode: x + y, frequency =  \n');
    fprintf('Antisymmetric mode: x - y, frequency =  (  + 2k)\n\n');
    
    % Numerical example with specific parameters
    fprintf('Numerical Example:\n');
    fprintf('---------\n');
    
    % Parameters
    omega1_val = 2;  % rad/s
    omega2_val = 3;  % rad/s
    k_val = 1;       % coupling strength
    
    fprintf('Parameters:   = %.1f rad/s,   = %.1f rad/s, k = %.1f\n', ...
           omega1_val, omega2_val, k_val);
    
    % Solve numerically
    time_span = [0, 10];
    initial_conditions = [1, 0, 0.5, 0];  % [x, , y, ]
    
    % Define ODE function
    coupled_oscillator_ode = @(t_val, z_val) coupled_oscillator_dynamics(t_val, z_val, omega1_val, omega2_val, k_val);
    
    [time_solution, state_solution] = ode45(coupled_oscillator_ode, time_span, initial_conditions);
    
    % Extract solutions
    x_solution = state_solution(:, 1);
    y_solution = state_solution(:, 3);
    
    fprintf('Numerical solution computed for t   [%.1f, %.1f] s\n', time_span(1), time_span(2));
    fprintf('Initial conditions: x = %.1f,  = %.1f, y = %.1f,  = %.1f\n', ...
           initial_conditions);
    
    % Energy analysis
    kinetic_energy = 0.5 * (state_solution(:, 2).^2 + state_solution(:, 4).^2);
    potential_energy = 0.5 * (omega1_val^2 * state_solution(:, 1).^2 + ...
                             omega2_val^2 * state_solution(:, 3).^2 + ...
                             k_val * (state_solution(:, 1) - state_solution(:, 3)).^2);
    total_energy = kinetic_energy + potential_energy;
    
    fprintf('Energy conservation check:\n');
    fprintf('Initial total energy: %.6f\n', total_energy(1));
    fprintf('Final total energy: %.6f\n', total_energy(end));
    fprintf('Energy variation: %.2e (should be   0)\n', std(total_energy));
    
    fprintf('\n');
end

function dzdt = coupled_oscillator_dynamics(t_val, z_val, omega1, omega2, k)
    %COUPLED_OSCILLATOR_DYNAMICS ODE function for coupled oscillators
    %   Defines the dynamics for numerical integration
    
    % State variables: z = [x, , y, ]
    x = z_val(1);
    x_dot = z_val(2);
    y = z_val(3);
    y_dot = z_val(4);
    
    % Derivatives
    x_ddot = -(omega1^2 + k)*x + k*y;
    y_ddot = k*x - (omega2^2 + k)*y;
    
    dzdt = [x_dot; x_ddot; y_dot; y_ddot];
end

function solve_heat_equation_symbolic()
    %SOLVE_HEAT_EQUATION_SYMBOLIC Symbolic solution of heat equation
    %   Solves: u/t =  u/x with symbolic boundary conditions
    
    fprintf('Problem 2: Heat Equation with Symbolic Boundary Conditions\n');
    fprintf('==========================================================\n');
    
    syms u(x, t) x t alpha L real positive
    syms n integer positive
    syms A_n real
    
    % Heat equation
    heat_equation = diff(u, t) - alpha * diff(u, x, 2) == 0;
    
    fprintf('Heat equation: u/t =   u/x\n');
    fprintf('where   is the thermal diffusivity\n\n');
    
    % Boundary conditions
    fprintf('Boundary conditions:\n');
    fprintf('u(0,t) = 0 (left end at x=0)\n');
    fprintf('u(L,t) = 0 (right end at x=L)\n\n');
    
    % Initial condition
    fprintf('Initial condition:\n');
    fprintf('u(x,0) = f(x) (arbitrary initial temperature distribution)\n\n');
    
    % Separation of variables solution
    fprintf('Solution by separation of variables:\n');
    fprintf('------------------\n');
    
    % Assume solution of the form u(x,t) = X(x)T(t)
    fprintf('Assume u(x,t) = X(x)T(t)\n');
    fprintf('Substituting into PDE: X(x)T''(t) =   X''''(x)T(t)\n');
    fprintf('Separating: T''(t)/( T(t)) = X''''(x)/X(x) = -  (constant)\n\n');
    
    % Spatial part: X''''(x) +  X(x) = 0
    fprintf('Spatial equation: X''''(x) +  X(x) = 0\n');
    fprintf('General solution: X(x) = A cos( x) + B sin( x)\n\n');
    
    % Apply boundary conditions
    fprintf('Applying boundary conditions:\n');
    fprintf('X(0) = 0   A = 0\n');
    fprintf('X(L) = 0   B sin( L) = 0\n');
    fprintf('For non-trivial solution:  L = n , so   = n /L\n\n');
    
    % Eigenfunction
    X_n = sin(n * pi * x / L);
    fprintf('Eigenfunctions: X(x) = sin(n x/L)\n');
    
    % Temporal part: T''(t) +  (n /L)T(t) = 0
    lambda_n = n * pi / L;
    fprintf('\nTemporal equation: T''(t) +  (n /L)T(t) = 0\n');
    
    T_n = exp(-alpha * lambda_n^2 * t);
    fprintf('Solution: T(t) = exp(- (n /L)t)\n\n');
    
    % Complete solution (Fourier series)
    fprintf('Complete solution (Fourier series):\n');
    fprintf('u(x,t) =   A sin(n x/L) exp(- (n /L)t)\n\n');
    
    % Fourier coefficients
    fprintf('Fourier coefficients:\n');
    fprintf('A = (2/L)   f(x) sin(n x/L) dx\n\n');
    
    % Example: Initial condition f(x) = sin( x/L)
    fprintf('Example with f(x) = sin( x/L):\n');
    
    initial_condition_example = sin(pi * x / L);
    fprintf('Initial condition: f(x) = %s\n', char(initial_condition_example));
    
    % For this case, only A = 1, all other coefficients are zero
    solution_example = sin(pi * x / L) * exp(-alpha * (pi/L)^2 * t);
    
    fprintf('Solution: u(x,t) = %s\n', char(solution_example));
    
    % Verification
    fprintf('\nVerification:\n');
    du_dt_example = diff(solution_example, t);
    d2u_dx2_example = diff(solution_example, x, 2);
    
    verification_lhs = du_dt_example;
    verification_rhs = alpha * d2u_dx2_example;
    verification_difference = simplify(verification_lhs - verification_rhs);
    
    fprintf('u/t = %s\n', char(du_dt_example));
    fprintf(' u/x = %s\n', char(verification_rhs));
    fprintf('Difference: %s\n', char(verification_difference));
    
    if isequal(verification_difference, sym(0))
        fprintf(' Solution verified!\n');
    else
        fprintf(' Verification failed\n');
    end
    
    fprintf('\n');
end

function solve_van_der_pol_with_ai()
    %SOLVE_VAN_DER_POL_WITH_AI AI-enhanced parameter estimation
    %   Solves Van der Pol with parameter estimation:  -  (1-x) + x = 0
    
    fprintf('Problem 3: Van der Pol Oscillator with AI Parameter Estimation\n');
    fprintf('==============================================================\n');
    
    syms x(t) t mu real
    
    % Van der Pol equation
    van_der_pol_eq = diff(x, t, 2) - mu*(1 - x^2)*diff(x, t) + x == 0;
    
    fprintf('Van der Pol equation:  -  (1-x) + x = 0\n');
    fprintf('where   is the damping parameter\n\n');
    
    % Characteristics of the equation
    fprintf('Equation characteristics:\n');
    fprintf('   = 0: Simple harmonic oscillator\n');
    fprintf('   > 0: Self-sustaining oscillations (limit cycle)\n');
    fprintf('   >> 1: Relaxation oscillations\n\n');
    
    % AI-enhanced parameter estimation
    fprintf('AI-Enhanced Parameter Estimation:\n');
    fprintf('----------------\n');
    
    % Generate synthetic data with known parameter
    true_mu = 2.0;
    fprintf('True parameter:   = %.1f\n', true_mu);
    
    % Generate trajectory data
    time_span = [0, 20];
    initial_conditions = [1, 0];  % [x, ]
    
    van_der_pol_ode = @(t_val, y_val) van_der_pol_dynamics(t_val, y_val, true_mu);
    
    [time_data, state_data] = ode45(van_der_pol_ode, time_span, initial_conditions);
    
    x_data = state_data(:, 1);
    x_dot_data = state_data(:, 2);
    
    % Add noise to simulate real measurements
    noise_level = 0.05;
    x_noisy = x_data + noise_level * randn(size(x_data));
    x_dot_noisy = x_dot_data + noise_level * randn(size(x_dot_data));
    
    fprintf('Generated %d data points with %.1f%% noise\n', length(time_data), noise_level*100);
    
    % AI parameter estimation using least squares
    fprintf('\nParameter estimation using least squares fitting:\n');
    
    % The Van der Pol equation can be written as:
    %  =  (1-x) - x
    
    % Estimate   using the data
    x_ddot_estimated = gradient(x_dot_noisy, time_data);
    
    % Set up least squares problem:  + x =  (1-x)
    A_matrix = (1 - x_noisy.^2) .* x_dot_noisy;
    b_vector = x_ddot_estimated + x_noisy;
    
    % Remove points where x_dot is near zero to avoid division issues
    valid_indices = abs(A_matrix) > 0.1;
    A_valid = A_matrix(valid_indices);
    b_valid = b_vector(valid_indices);
    
    % Least squares solution
    mu_estimated = (A_valid' * A_valid) \ (A_valid' * b_valid);
    
    fprintf('Estimated parameter:   = %.4f\n', mu_estimated);
    fprintf('True parameter:   = %.4f\n', true_mu);
    fprintf('Estimation error: %.2f%%\n', abs(mu_estimated - true_mu) / true_mu * 100);
    
    % Validate estimation by simulation
    fprintf('\nValidation by forward simulation:\n');
    
    van_der_pol_estimated = @(t_val, y_val) van_der_pol_dynamics(t_val, y_val, mu_estimated);
    [time_validation, state_validation] = ode45(van_der_pol_estimated, time_span, initial_conditions);
    
    % Compare trajectories
    mse_position = mean((state_validation(:, 1) - x_data).^2);
    mse_velocity = mean((state_validation(:, 2) - x_dot_data).^2);
    
    fprintf('Mean squared error (position): %.6f\n', mse_position);
    fprintf('Mean squared error (velocity): %.6f\n', mse_velocity);
    
    % Phase plane analysis
    fprintf('\nPhase plane analysis:\n');
    fprintf('Original trajectory forms limit cycle\n');
    fprintf('Estimated model reproduces limit cycle behaviour\n');
    
    % Stability analysis
    fprintf('\nStability analysis:\n');
    fprintf('Fixed point at origin: (0, 0)\n');
    
    % Linearisation around origin
    %  = y
    %  =  y - x
    % Jacobian: [0, 1; -1,  ]
    
    jacobian_eigenvalues = [mu_estimated/2 + sqrt(mu_estimated^2/4 - 1), ...
                           mu_estimated/2 - sqrt(mu_estimated^2/4 - 1)];
    
    fprintf('Linearised system eigenvalues: %.4f   %.4fi\n', ...
           real(jacobian_eigenvalues(1)), imag(jacobian_eigenvalues(1)));
    
    if real(jacobian_eigenvalues(1)) > 0
        fprintf('Origin is unstable (limit cycle attractor exists)\n');
    else
        fprintf('Origin is stable\n');
    end
    
    fprintf('\n');
end

function dydt = van_der_pol_dynamics(t_val, y_val, mu)
    %VAN_DER_POL_DYNAMICS Dynamics function for Van der Pol oscillator
    %   State vector: y = [x, ]
    
    x = y_val(1);
    x_dot = y_val(2);
    
    x_ddot = mu * (1 - x^2) * x_dot - x;
    
    dydt = [x_dot; x_ddot];
end

function demonstrate_ai_enhanced_techniques()
    %DEMONSTRATE_AI_ENHANCED_TECHNIQUES Show advanced AI integration
    %   Demonstrates sophisticated AI-symbolic hybrid approaches
    
    fprintf('Advanced AI-Enhanced Techniques\n');
    fprintf('==============================\n');
    
    % Technique 1: Neural ODEs
    demonstrate_neural_odes();
    
    % Technique 2: Physics-Informed Neural Networks
    demonstrate_pinns();
    
    % Technique 3: Symbolic regression for equation discovery
    demonstrate_symbolic_regression();
    
end

function demonstrate_neural_odes()
    %DEMONSTRATE_NEURAL_ODES Show Neural ODE concepts
    %   Demonstrates the concept of Neural ODEs
    
    fprintf('Neural ODEs:\n');
    fprintf('------\n');
    
    fprintf('Concept: Replace ODE right-hand side with neural network\n');
    fprintf('Standard ODE: dx/dt = f(x, t;  )\n');
    fprintf('Neural ODE: dx/dt = NN(x, t;  _neural)\n\n');
    
    fprintf('Advantages:\n');
    fprintf(' Continuous-depth models\n');
    fprintf(' Memory-efficient training\n');
    fprintf(' Adaptive computation\n');
    fprintf(' Natural incorporation of physical constraints\n\n');
    
    fprintf('Training: Adjoint sensitivity method for gradient computation\n');
    fprintf('Applications: Time series modeling, continuous normalizing flows\n\n');
end

function demonstrate_pinns()
    %DEMONSTRATE_PINNS Show Physics-Informed Neural Networks
    %   Demonstrates PINN concepts for DE solving
    
    fprintf('Physics-Informed Neural Networks (PINNs):\n');
    fprintf('--------------------\n');
    
    fprintf('Approach: Train NN to satisfy both data and physics\n');
    fprintf('Loss function: L =  L_data +  L_physics +  L_boundary\n\n');
    
    fprintf('Physics loss example (heat equation):\n');
    fprintf('L_physics = ||u_NN/t -  u_NN||\n\n');
    
    fprintf('Advantages:\n');
    fprintf(' Works with sparse/noisy data\n');
    fprintf(' Incorporates physical laws\n');
    fprintf(' Handles inverse problems\n');
    fprintf(' Provides uncertainty quantification\n\n');
    
    fprintf('Implementation: Automatic differentiation for computing\n');
    fprintf('derivatives of neural network outputs\n\n');
end

function demonstrate_symbolic_regression()
    %DEMONSTRATE_SYMBOLIC_REGRESSION Show equation discovery
    %   Demonstrates AI-driven equation discovery
    
    fprintf('Symbolic Regression for Equation Discovery:\n');
    fprintf('---------------------\n');
    
    fprintf('Goal: Discover governing equations from data\n');
    fprintf('Input: Time series data [x(t), (t), (t)]\n');
    fprintf('Output: Symbolic expression for dynamics\n\n');
    
    fprintf('Methods:\n');
    fprintf(' Genetic programming\n');
    fprintf(' Sparse regression (SINDy)\n');
    fprintf(' Deep symbolic regression\n\n');
    
    fprintf('Example discovery:\n');
    fprintf('Data from pendulum     + (g/L)sin( ) = 0\n');
    fprintf('Data from Van der Pol    -  (1-x) + x = 0\n\n');
    
    fprintf('Benefits:\n');
    fprintf(' Interpretable models\n');
    fprintf(' Discovers hidden physics\n');
    fprintf(' Enables scientific insight\n');
    fprintf(' Validates theoretical models\n\n');
end
