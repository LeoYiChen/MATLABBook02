%% prob3_complete.m
% Problem 3: Multi-GPU Scaling Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob3_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 3: Multi-GPU Scaling Efficiency Investigation
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b

clear; close all; clc;

%% Empirical Data
gpuCounts = [1, 2, 4, 8, 16];
epochTimes_minutes = [20, 11, 6, 3.5, 2.2];

%% Calculate Speedup and Efficiency
speedups = epochTimes_minutes(1) ./ epochTimes_minutes;
efficiencies = (speedups ./ gpuCounts) * 100;

%% Estimate Communication Overhead
ideal_times = epochTimes_minutes(1) ./ gpuCounts;
comm_overhead = epochTimes_minutes - ideal_times;

%% Display Results Table
fprintf('Multi-GPU Scaling Analysis\n');
fprintf('%-8s %-12s %-10s %-15s %-18s\n', 'GPUs', 'Time (min)', ...
        'Speedup', 'Efficiency (%)', 'Comm Overhead (min)');
fprintf('%s\n', repmat('-', 1, 70));
for i = 1:length(gpuCounts)
    fprintf('%-8d %-12.2f %-10.2f %-15.1f %-18.2f\n', ...
            gpuCounts(i), epochTimes_minutes(i), speedups(i), ...
            efficiencies(i), comm_overhead(i));
end

%% Fit Amdahl's Law
% Model: T(N) = s*T(1) + p*T(1)/N where s + p = 1
% Use nonlinear fitting to estimate s and p

fitfunc = @(params, N) params(1) * epochTimes_minutes(1) + ...
                       (1 - params(1)) * epochTimes_minutes(1) ./ N;
s_initial = 0.15;  % Initial guess for serial fraction
s_fitted = lsqcurvefit(fitfunc, s_initial, gpuCounts, epochTimes_minutes, ...
                       0, 1, optimset('Display', 'off'));

fprintf('\nFitted Amdahl''s Law Parameters:\n');
fprintf('  Serial fraction (s): %.3f (%.1f%%)\n', s_fitted, s_fitted * 100);
fprintf('  Parallel fraction (p): %.3f (%.1f%%)\n\n', ...
        1 - s_fitted, (1 - s_fitted) * 100);

%% Predict for 32 and 64 GPUs
predicted_gpus = [32, 64];
predicted_times = fitfunc(s_fitted, predicted_gpus);
predicted_speedups = epochTimes_minutes(1) ./ predicted_times;
predicted_efficiencies = (predicted_speedups ./ predicted_gpus) * 100;

fprintf('Predictions for Larger GPU Counts:\n');
fprintf('%-8s %-12s %-10s %-15s\n', 'GPUs', 'Time (min)', ...
        'Speedup', 'Efficiency (%)');
fprintf('%s\n', repmat('-', 1, 50));
for i = 1:length(predicted_gpus)
    fprintf('%-8d %-12.2f %-10.2f %-15.1f\n', predicted_gpus(i), ...
            predicted_times(i), predicted_speedups(i), ...
            predicted_efficiencies(i));
end
