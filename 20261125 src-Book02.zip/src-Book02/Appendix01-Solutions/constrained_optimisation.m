%% constrained_optimisation.m
% Constrained Optimisation Problem
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : constrained_optimisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem7.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Define the objective function: f(x,y) = (x-3)^2 + (y-2)^2
objectiveFunction = @(X) (X(1)-3)^2 + (X(2)-2)^2;

% Define constraints
% x + y - 4 <= 0
% -x <= 0 (or x >= 0)
% -y <= 0 (or y >= 0)
constraints = @(X) [X(1) + X(2) - 4; -X(1); -X(2)];

% Set up optimisation options
options_interior = optimoptions('fmincon', 'Algorithm', 'interior-point', ...
'Display', 'iter-detailed', ...
'OptimalityTolerance', 1e-10, ...
'ConstraintTolerance', 1e-10);

options_sqp = optimoptions('fmincon', 'Algorithm', 'sqp', ...
'Display', 'iter-detailed', ...
'OptimalityTolerance', 1e-10, ...
'ConstraintTolerance', 1e-10);

options_activeset = optimoptions('fmincon', 'Algorithm', 'active-set', ...
'Display', 'iter-detailed', ...
'OptimalityTolerance', 1e-10, ...
'ConstraintTolerance', 1e-10);

% Initial point
x0 = [1; 1];

% Linear inequality constraints (alternative formulation)
A = [1 1; -1 0; 0 -1];
b = [4; 0; 0];

% No linear equality constraints
Aeq = [];
beq = [];

% No bounds
lb = [];
ub = [];

% No nonlinear constraints (using the A, b formulation for linear constraints)
nonlcon = [];

% Solve the problem using interior-point algorithm
fprintf('Solving constrained optimisation problem with interior-point algorithm...\n');
[x_ip, fval_ip, exitflag_ip, output_ip, lambda_ip] = fmincon(objectiveFunction, x0, A, b, Aeq, beq, lb, ub, nonlcon, options_interior);

% Solve the problem using SQP algorithm
fprintf('\nSolving constrained optimisation problem with SQP algorithm...\n');
[x_sqp, fval_sqp, exitflag_sqp, output_sqp, lambda_sqp] = fmincon(objectiveFunction, x0, A, b, Aeq, beq, lb, ub, nonlcon, options_sqp);

% Solve the problem using active-set algorithm
fprintf('\nSolving constrained optimisation problem with active-set algorithm...\n');
[x_as, fval_as, exitflag_as, output_as, lambda_as] = fmincon(objectiveFunction, x0, A, b, Aeq, beq, lb, ub, nonlcon, options_activeset);

% Unconstrained minimum (analytical solution)
x_unconstrained = [3; 2];
f_unconstrained = objectiveFunction(x_unconstrained);

% Display results
fprintf('\nResults Summary:\n');
fprintf('%-20s %-20s %-20s\n', 'Algorithm', 'Optimal Point', 'Objective Value');
fprintf('%-20s [%-8.6f, %-8.6f] %-20.10f\n', 'Interior-Point', x_ip(1), x_ip(2), fval_ip);
fprintf('%-20s [%-8.6f, %-8.6f] %-20.10f\n', 'SQP', x_sqp(1), x_sqp(2), fval_sqp);
fprintf('%-20s [%-8.6f, %-8.6f] %-20.10f\n', 'Active-Set', x_as(1), x_as(2), fval_as);
fprintf('%-20s [%-8.6f, %-8.6f] %-20.10f\n', 'Unconstrained', x_unconstrained(1), x_unconstrained(2), f_unconstrained);

% Verify constraints
fprintf('\nConstraint Verification (Interior-Point Solution):\n');
g = constraints(x_ip);
fprintf('g1(x,y) = x + y - 4 = %.10f (<= 0)\n', g(1));
fprintf('g2(x,y) = -x = %.10f (<= 0)\n', g(2));
fprintf('g3(x,y) = -y = %.10f (<= 0)\n', g(3));

% Identify active constraints
fprintf('\nActive Constraints:\n');
active_tolerance = 1e-8;
if abs(g(1)) < active_tolerance
fprintf('g1(x,y) = x + y - 4 is active\n');
end
if abs(g(2)) < active_tolerance
fprintf('g2(x,y) = -x is active\n');
end
if abs(g(3)) < active_tolerance
fprintf('g3(x,y) = -y is active\n');
end

% Lagrange multipliers
fprintf('\nLagrange Multipliers (Interior-Point Solution):\n');
fprintf('lambda_g1 = %.10f\n', lambda_ip.ineqlin(1));
fprintf('lambda_g2 = %.10f\n', lambda_ip.ineqlin(2));
fprintf('lambda_g3 = %.10f\n', lambda_ip.ineqlin(3));

% Visualise the problem
% Create a grid of points
[X, Y] = meshgrid(linspace(0, 4, 100), linspace(0, 4, 100));
Z = zeros(size(X));

% Calculate objective function values
for i = 1:size(X, 1)
for j = 1:size(X, 2)
Z(i, j) = (X(i,j)-3)^2 + (Y(i,j)-2)^2;
end
end

figure;
% Plot contours of the objective function
contour(X, Y, Z, 20, 'LineWidth', 1);
colorbar;
hold on;

% Plot constraints
x_line = linspace(0, 4, 100);
y_g1 = 4 - x_line; % g1: x + y - 4 = 0
plot(x_line, y_g1, 'r-', 'LineWidth', 2, 'DisplayName', 'x + y = 4');
plot([0 0], [0 4], 'r-', 'LineWidth', 2, 'DisplayName', 'x = 0');
plot([0 4], [0 0], 'r-', 'LineWidth', 2, 'DisplayName', 'y = 0');

% Shade the feasible region
[X_fill, Y_fill] = meshgrid(linspace(0, 4, 20), linspace(0, 4, 20));
feasible = X_fill + Y_fill <= 4 & X_fill >= 0 & Y_fill >= 0;
X_fill(~feasible) = NaN;
Y_fill(~feasible) = NaN;
fill(X_fill(:), Y_fill(:), 'g', 'FaceAlpha', 0.2, 'EdgeColor', 'none', 'DisplayName', 'Feasible Region');

% Plot optimal points
plot(x_ip(1), x_ip(2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r', 'DisplayName', 'Constrained Optimum');
plot(x_unconstrained(1), x_unconstrained(2), 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'b', 'DisplayName', 'Unconstrained Optimum');

% Add labels and legend
xlabel('x');
ylabel('y');
title('Constrained Optimisation Problem');
legend('show', 'Location', 'northwest');
grid on;
axis([0 4 0 4]);
