%% chapter_AIforMechatronics_problem08_code.m
% Time series prediction with LSTM networks.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem08_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 8: Time Series Prediction with LSTM Networks
% Author: Dr Yi Chen
% Purpose: Compare LSTM architectures for time series forecasting
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox, Statistics Toolbox
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Generate synthetic time series data
fprintf('=== Time Series Prediction with LSTM Networks ===\n\n');
fprintf('Step 1: Generating synthetic time series...\n');

% Time series parameters
dt = 0.1; % Sampling interval (seconds)
T = 200; % Total duration (seconds)
timeVector = 0:dt:T;
numSamples = length(timeVector);

% Generate complex multi-component time series
% Component 1: Linear trend
trend = 0.02 * timeVector;

% Component 2: Seasonal (sinusoidal) patterns
seasonal1 = 2.0 * sin(2 * pi * timeVector / 20); % Long period
seasonal2 = 0.5 * sin(2 * pi * timeVector / 5);  % Short period

% Component 3: Non-linear dynamics (simulating system resonance)
nonlinear = 0.3 * sin(2 * pi * timeVector / 10).^3;

% Component 4: Random walk (simulating drift/degradation)
randomWalk = cumsum(0.05 * randn(1, numSamples));

% Component 5: Measurement noise
noise = 0.1 * randn(1, numSamples);

% Combined time series
timeSeries = trend + seasonal1 + seasonal2 + nonlinear + ...
    0.2 * randomWalk + noise;

fprintf('  Time series length: %d samples\n', numSamples);
fprintf('  Sampling interval: %.2f seconds\n', dt);
fprintf('  Total duration: %.1f seconds\n', T);

%% Step 2: Data preprocessing and sequence creation
fprintf('\nStep 2: Preprocessing data and creating sequences...\n');

% Normalisation (zero mean, unit variance)
meanValue = mean(timeSeries);
stdValue = std(timeSeries);
timeSeriesNorm = (timeSeries - meanValue) / stdValue;

% Create sequences using sliding window
sequenceLength = 50; % Input sequence length
forecastHorizon = 1; % Number of steps to predict ahead

numSequences = numSamples - sequenceLength - forecastHorizon + 1;
XData = cell(numSequences, 1);
YData = zeros(numSequences, 1);

for i = 1:numSequences
    XData{i} = timeSeriesNorm(i:(i + sequenceLength - 1))';
    YData(i) = timeSeriesNorm(i + sequenceLength + forecastHorizon - 1);
end

% Split data (70% train, 15% validation, 15% test)
% Maintain temporal ordering - no shuffling!
trainRatio = 0.70;
valRatio = 0.15;

trainIdx = 1:floor(trainRatio * numSequences);
valIdx = (max(trainIdx) + 1):floor((trainRatio + valRatio) * numSequences);
testIdx = (max(valIdx) + 1):numSequences;

XTrain = XData(trainIdx);
YTrain = YData(trainIdx);

XVal = XData(valIdx);
YVal = YData(valIdx);

XTest = XData(testIdx);
YTest = YData(testIdx);

fprintf('  Sequence length: %d\n', sequenceLength);
fprintf('  Forecast horizon: %d step(s)\n', forecastHorizon);
fprintf('  Training sequences: %d\n', length(trainIdx));
fprintf('  Validation sequences: %d\n', length(valIdx));
fprintf('  Test sequences: %d\n', length(testIdx));

%% Step 3: Implement vanilla LSTM architecture
fprintf('\nStep 3: Implementing vanilla LSTM architecture...\n');

numHiddenUnits = 100;

layersVanillaLSTM = [
    sequenceInputLayer(1, 'Name', 'input')
    lstmLayer(numHiddenUnits, 'Name', 'lstm', 'OutputMode', 'last')
    fullyConnectedLayer(1, 'Name', 'fc')
    regressionLayer('Name', 'output')];

fprintf('  Vanilla LSTM: %d hidden units\n', numHiddenUnits);

%% Step 4: Train vanilla LSTM
fprintf('\nStep 4: Training vanilla LSTM...\n');

optionsVanilla = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'InitialLearnRate', 0.005, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 50, ...
    'LearnRateDropFactor', 0.5, ...
    'GradientThreshold', 1, ...
    'ValidationData', {XVal, YVal}, ...
    'ValidationFrequency', 30, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
netVanilla = trainNetwork(XTrain, YTrain, layersVanillaLSTM, optionsVanilla);
trainingTimeVanilla = toc;

fprintf('  Training completed in %.2f seconds\n', trainingTimeVanilla);

%% Step 5: Implement bidirectional LSTM
fprintf('\nStep 5: Implementing bidirectional LSTM architecture...\n');

layersBiLSTM = [
    sequenceInputLayer(1, 'Name', 'input')
    bilstmLayer(numHiddenUnits, 'Name', 'bilstm', 'OutputMode', 'last')
    fullyConnectedLayer(1, 'Name', 'fc')
    regressionLayer('Name', 'output')];

fprintf('  Bidirectional LSTM: %d hidden units\n', numHiddenUnits);

%% Step 6: Train bidirectional LSTM
fprintf('\nStep 6: Training bidirectional LSTM...\n');

optionsBiLSTM = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'InitialLearnRate', 0.005, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 50, ...
    'LearnRateDropFactor', 0.5, ...
    'GradientThreshold', 1, ...
    'ValidationData', {XVal, YVal}, ...
    'ValidationFrequency', 30, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
netBiLSTM = trainNetwork(XTrain, YTrain, layersBiLSTM, optionsBiLSTM);
trainingTimeBiLSTM = toc;

fprintf('  Training completed in %.2f seconds\n', trainingTimeBiLSTM);

%% Step 7: Implement stacked LSTM
fprintf('\nStep 7: Implementing stacked LSTM architecture...\n');

layersStackedLSTM = [
    sequenceInputLayer(1, 'Name', 'input')
    lstmLayer(numHiddenUnits, 'Name', 'lstm1', 'OutputMode', 'sequence')
    lstmLayer(numHiddenUnits/2, 'Name', 'lstm2', 'OutputMode', 'last')
    fullyConnectedLayer(1, 'Name', 'fc')
    regressionLayer('Name', 'output')];

fprintf('  Stacked LSTM: [%d, %d] hidden units\n', ...
    numHiddenUnits, numHiddenUnits/2);

%% Step 8: Train stacked LSTM
fprintf('\nStep 8: Training stacked LSTM...\n');

optionsStacked = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'InitialLearnRate', 0.005, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 50, ...
    'LearnRateDropFactor', 0.5, ...
    'GradientThreshold', 1, ...
    'ValidationData', {XVal, YVal}, ...
    'ValidationFrequency', 30, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
netStacked = trainNetwork(XTrain, YTrain, layersStackedLSTM, optionsStacked);
trainingTimeStacked = toc;

fprintf('  Training completed in %.2f seconds\n', trainingTimeStacked);

%% Step 9: Evaluate models on test set
fprintf('\nStep 9: Evaluating models on test set...\n');

% Predictions
YPredVanilla = predict(netVanilla, XTest);
YPredBiLSTM = predict(netBiLSTM, XTest);
YPredStacked = predict(netStacked, XTest);

% Compute metrics (normalised space)
rmseVanilla = sqrt(mean((YTest - YPredVanilla).^2));
rmseBiLSTM = sqrt(mean((YTest - YPredBiLSTM).^2));
rmseStacked = sqrt(mean((YTest - YPredStacked).^2));

maeVanilla = mean(abs(YTest - YPredVanilla));
maeBiLSTM = mean(abs(YTest - YPredBiLSTM));
maeStacked = mean(abs(YTest - YPredStacked));

% R-squared
SSresVanilla = sum((YTest - YPredVanilla).^2);
SStot = sum((YTest - mean(YTest)).^2);
r2Vanilla = 1 - SSresVanilla / SStot;

SSresBiLSTM = sum((YTest - YPredBiLSTM).^2);
r2BiLSTM = 1 - SSresBiLSTM / SStot;

SSresStacked = sum((YTest - YPredStacked).^2);
r2Stacked = 1 - SSresStacked / SStot;

fprintf('  Vanilla LSTM - RMSE: %.4f, MAE: %.4f, R: %.4f\n', ...
    rmseVanilla, maeVanilla, r2Vanilla);
fprintf('  Bidirectional LSTM - RMSE: %.4f, MAE: %.4f, R: %.4f\n', ...
    rmseBiLSTM, maeBiLSTM, r2BiLSTM);
fprintf('  Stacked LSTM - RMSE: %.4f, MAE: %.4f, R: %.4f\n', ...
    rmseStacked, maeStacked, r2Stacked);

%% Step 10: Multi-horizon forecasting
fprintf('\nStep 10: Performing multi-horizon forecasting...\n');

horizons = [1, 5, 10, 20];
numHorizons = length(horizons);

rmseVanillaHorizon = zeros(1, numHorizons);
rmseBiLSTMHorizon = zeros(1, numHorizons);
rmseStackedHorizon = zeros(1, numHorizons);

for hIdx = 1:numHorizons
    horizon = horizons(hIdx);
    
    % Recreate sequences for this horizon
    numSeqH = numSamples - sequenceLength - horizon + 1;
    XDataH = cell(numSeqH, 1);
    YDataH = zeros(numSeqH, 1);
    
    for i = 1:numSeqH
        XDataH{i} = timeSeriesNorm(i:(i + sequenceLength - 1))';
        YDataH(i) = timeSeriesNorm(i + sequenceLength + horizon - 1);
    end
    
    % Use test portion
    testIdxH = (max(valIdx) + 1):numSeqH;
    XTestH = XDataH(testIdxH);
    YTestH = YDataH(testIdxH);
    
    % Predictions
    YPredVanillaH = predict(netVanilla, XTestH);
    YPredBiLSTMH = predict(netBiLSTM, XTestH);
    YPredStackedH = predict(netStacked, XTestH);
    
    % RMSE
    rmseVanillaHorizon(hIdx) = sqrt(mean((YTestH - YPredVanillaH).^2));
    rmseBiLSTMHorizon(hIdx) = sqrt(mean((YTestH - YPredBiLSTMH).^2));
    rmseStackedHorizon(hIdx) = sqrt(mean((YTestH - YPredStackedH).^2));
end

fprintf('  Multi-horizon forecasting completed\n');
for hIdx = 1:numHorizons
    fprintf('    Horizon %d: Vanilla=%.4f, BiLSTM=%.4f, Stacked=%.4f\n', ...
        horizons(hIdx), rmseVanillaHorizon(hIdx), ...
        rmseBiLSTMHorizon(hIdx), rmseStackedHorizon(hIdx));
end

%% Step 11: Implement baseline ARIMA model
fprintf('\nStep 11: Implementing baseline ARIMA model...\n');

% Use training data for ARIMA
trainData = timeSeriesNorm(trainIdx(1):(trainIdx(end) + sequenceLength - 1));

% Fit ARIMA model (automated order selection)
try
    % Simple ARIMA(2,0,2) model
    ARIMAModel = arima(2, 0, 2);
    fittedARIMA = estimate(ARIMAModel, trainData');
    
    % Forecast on test data
    testStartIdx = testIdx(1) + sequenceLength - 1;
    numTestSteps = length(testIdx);
    
    % One-step-ahead forecasting
    YPredARIMA = zeros(numTestSteps, 1);
    
    for i = 1:numTestSteps
        % Use all data up to current point
        histData = timeSeriesNorm(1:(testStartIdx + i - 1));
        [YForecast, ~] = forecast(fittedARIMA, 1, 'Y0', histData');
        YPredARIMA(i) = YForecast(end);
    end
    
    rmseARIMA = sqrt(mean((YTest - YPredARIMA).^2));
    maeARIMA = mean(abs(YTest - YPredARIMA));
    
    fprintf('  ARIMA model - RMSE: %.4f, MAE: %.4f\n', rmseARIMA, maeARIMA);
    arimaSuccess = true;
catch
    fprintf('  ARIMA model fitting failed (expected for complex series)\n');
    arimaSuccess = false;
    YPredARIMA = zeros(size(YTest));
end

%% Step 12: Inference speed benchmarking
fprintf('\nStep 12: Benchmarking inference speed...\n');

numRuns = 100;

% Vanilla LSTM timing
inferenceTimesVanilla = zeros(numRuns, 1);
for runIdx = 1:numRuns
    sampleSeq = XTest{randi(length(XTest))};
    tic;
    predict(netVanilla, {sampleSeq});
    inferenceTimesVanilla(runIdx) = toc * 1000; % ms
end

% BiLSTM timing
inferenceTimesBiLSTM = zeros(numRuns, 1);
for runIdx = 1:numRuns
    sampleSeq = XTest{randi(length(XTest))};
    tic;
    predict(netBiLSTM, {sampleSeq});
    inferenceTimesBiLSTM(runIdx) = toc * 1000; % ms
end

% Stacked LSTM timing
inferenceTimesStacked = zeros(numRuns, 1);
for runIdx = 1:numRuns
    sampleSeq = XTest{randi(length(XTest))};
    tic;
    predict(netStacked, {sampleSeq});
    inferenceTimesStacked(runIdx) = toc * 1000; % ms
end

avgInferenceVanilla = mean(inferenceTimesVanilla);
avgInferenceBiLSTM = mean(inferenceTimesBiLSTM);
avgInferenceStacked = mean(inferenceTimesStacked);

fprintf('  Vanilla LSTM: %.3f ms\n', avgInferenceVanilla);
fprintf('  Bidirectional LSTM: %.3f ms\n', avgInferenceBiLSTM);
fprintf('  Stacked LSTM: %.3f ms\n', avgInferenceStacked);

%% Step 13: Visualisation
fprintf('\nStep 13: Generating visualisations...\n');

figure('Name', 'LSTM Time Series Prediction', ...
    'Position', [100, 100, 1400, 900]);

% Original time series
subplot(3, 3, 1);
plot(timeVector, timeSeries, 'k-', 'LineWidth', 1.2);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Signal Amplitude', 'Interpreter', 'latex');
title('Original Time Series', 'Interpreter', 'latex');
grid on;

% Normalised time series with train/val/test splits
subplot(3, 3, 2);
plot(timeSeriesNorm, 'k-', 'LineWidth', 1);
hold on;
xline(trainIdx(end) + sequenceLength, 'r-', 'LineWidth', 1.5, ...
    'DisplayName', 'Train End');
xline(valIdx(end) + sequenceLength, 'b-', 'LineWidth', 1.5, ...
    'DisplayName', 'Val End');
xlabel('Sample Index', 'Interpreter', 'latex');
ylabel('Normalised Amplitude', 'Interpreter', 'latex');
title('Data Split', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Prediction comparison on test set
subplot(3, 3, 3);
testTimeIndices = testIdx + sequenceLength - 1;
plot(testTimeIndices, YTest, 'k-', 'LineWidth', 1.5, 'DisplayName', 'Ground Truth');
hold on;
plot(testTimeIndices, YPredVanilla, 'r-', 'LineWidth', 1.2, ...
    'DisplayName', 'Vanilla LSTM');
plot(testTimeIndices, YPredBiLSTM, 'b-', 'LineWidth', 1.2, ...
    'DisplayName', 'BiLSTM');
plot(testTimeIndices, YPredStacked, 'g-', 'LineWidth', 1.2, ...
    'DisplayName', 'Stacked LSTM');
xlabel('Sample Index', 'Interpreter', 'latex');
ylabel('Normalised Amplitude', 'Interpreter', 'latex');
title('Test Set Predictions', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% RMSE comparison
subplot(3, 3, 4);
modelNames = {'Vanilla', 'BiLSTM', 'Stacked'};
rmseValues = [rmseVanilla, rmseBiLSTM, rmseStacked];
bar(rmseValues);
set(gca, 'XTickLabel', modelNames);
ylabel('RMSE', 'Interpreter', 'latex');
title('Prediction Accuracy', 'Interpreter', 'latex');
grid on;

% R comparison
subplot(3, 3, 5);
r2Values = [r2Vanilla, r2BiLSTM, r2Stacked];
bar(r2Values);
set(gca, 'XTickLabel', modelNames);
ylabel('R Score', 'Interpreter', 'latex');
title('Model Fit Quality', 'Interpreter', 'latex');
ylim([0, 1]);
grid on;

% Multi-horizon RMSE
subplot(3, 3, 6);
plot(horizons, rmseVanillaHorizon, 'ro-', 'LineWidth', 1.5, ...
    'MarkerSize', 8, 'DisplayName', 'Vanilla');
hold on;
plot(horizons, rmseBiLSTMHorizon, 'bs-', 'LineWidth', 1.5, ...
    'MarkerSize', 8, 'DisplayName', 'BiLSTM');
plot(horizons, rmseStackedHorizon, 'g^-', 'LineWidth', 1.5, ...
    'MarkerSize', 8, 'DisplayName', 'Stacked');
xlabel('Forecast Horizon (steps)', 'Interpreter', 'latex');
ylabel('RMSE', 'Interpreter', 'latex');
title('Multi-Horizon Forecasting', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Prediction errors
subplot(3, 3, 7);
errorsVanilla = YTest - YPredVanilla;
errorsBiLSTM = YTest - YPredBiLSTM;
errorsStacked = YTest - YPredStacked;

histogram(errorsVanilla, 30, 'FaceAlpha', 0.5, 'DisplayName', 'Vanilla');
hold on;
histogram(errorsBiLSTM, 30, 'FaceAlpha', 0.5, 'DisplayName', 'BiLSTM');
histogram(errorsStacked, 30, 'FaceAlpha', 0.5, 'DisplayName', 'Stacked');
xlabel('Prediction Error', 'Interpreter', 'latex');
ylabel('Frequency', 'Interpreter', 'latex');
title('Error Distribution', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Inference speed comparison
subplot(3, 3, 8);
inferenceValues = [avgInferenceVanilla, avgInferenceBiLSTM, avgInferenceStacked];
bar(inferenceValues);
set(gca, 'XTickLabel', modelNames);
ylabel('Inference Time (ms)', 'Interpreter', 'latex');
title('Computational Efficiency', 'Interpreter', 'latex');
grid on;

% Detailed prediction segment
subplot(3, 3, 9);
detailRange = 1:min(200, length(YTest));
plot(detailRange, YTest(detailRange), 'k-', 'LineWidth', 2, ...
    'DisplayName', 'Ground Truth');
hold on;
plot(detailRange, YPredVanilla(detailRange), 'r-', 'LineWidth', 1.2, ...
    'DisplayName', 'Vanilla LSTM');
plot(detailRange, YPredBiLSTM(detailRange), 'b-', 'LineWidth', 1.2, ...
    'DisplayName', 'BiLSTM');
xlabel('Sample Index', 'Interpreter', 'latex');
ylabel('Normalised Amplitude', 'Interpreter', 'latex');
title('Detailed Prediction Comparison', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

suptitle('LSTM Time Series Forecasting Performance', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 8 completed successfully.\n');
