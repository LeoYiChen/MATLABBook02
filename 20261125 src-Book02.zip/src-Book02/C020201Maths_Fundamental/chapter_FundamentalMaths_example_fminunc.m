%% chapter_FundamentalMaths_example_fminunc.m
% Unconstrained nonlinear optimisation using fminunc.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_fminunc
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter06_CalculusOptimisation_Example03.m
% Author: Dr Leo Chen
% Date: June 5, 2025
% MATLAB Version: R2025a
% Description: Demonstrates unconstrained nonlinear optimisation
%              using fminunc with the Rosenbrock function.

function unconstrainedOptimisationExample()
    fprintf('Unconstrained Nonlinear Optimisation with fminunc\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Define Rosenbrock function
    objectiveFunction = @(x) 100 * (x(2) - x(1)^2)^2 + (1 - x(1))^2;
    
    % Define gradient function for improved convergence
    gradientFunction = @(x) [-400 * x(1) * (x(2) - x(1)^2) - 2 * (1 - x(1));
                            200 * (x(2) - x(1)^2)];
    
    fprintf('Objective: Rosenbrock function\n');
    fprintf('f(x,y) = 100*(y - x^2)^2 + (1 - x)^2\n');
    fprintf('Global minimum: (1, 1) with f* = 0\n\n');
    
    % Set optimisation options
    optimisationOptions = optimoptions('fminunc', ...
        'Display', 'iter', ...
        'SpecifyObjectiveGradient', true, ...
        'Algorithm', 'trust-region', ...
        'MaxIterations', 1000, ...
        'OptimalityTolerance', 1e-8, ...
        'StepTolerance', 1e-8);
    
    % Initial guess
    initialPoint = [-1.2; 1.0];
    
    fprintf('Initial point: [%.6f, %.6f]\n', initialPoint(1), initialPoint(2));
    fprintf('Initial function value: %.6f\n\n', objectiveFunction(initialPoint));
    
    % Solve optimisation problem
    [optimalSolution, optimalValue, exitFlag, output] = ...
        fminunc(@(x) objectiveFunctionWithGradient(x, objectiveFunction, gradientFunction), ...
                initialPoint, optimisationOptions);
    
    % Display results
    fprintf('\nOptimisation Results:\n');
    fprintf('Optimal Point: [%.10f, %.10f]\n', optimalSolution(1), optimalSolution(2));
    fprintf('Optimal Value: %.10e\n', optimalValue);
    fprintf('Exit Flag: %d\n', exitFlag);
    fprintf('Iterations: %d\n', output.iterations);
    fprintf('Function Evaluations: %d\n', output.funcCount);
    fprintf('Algorithm: %s\n\n', output.algorithm);
    
    % Error analysis
    fprintf('Error Analysis:\n');
    fprintf('Distance from true optimum (1,1): %.10e\n', ...
            norm(optimalSolution - [1; 1]));
    fprintf('Function value error: %.10e\n\n', optimalValue);
    
    % Visualise convergence behaviour
    visualiseOptimisationPath(objectiveFunction, initialPoint, optimalSolution);
end

function [functionValue, gradient] = objectiveFunctionWithGradient(x, f, g)
    % Combined function and gradient evaluation
    functionValue = f(x);
    if nargout > 1
        gradient = g(x);
    end
end

function visualiseOptimisationPath(f, x0, xOpt)
    % Create contour plot showing optimisation path
    figure('Position', [100, 100, 1200, 500]);
    
    % Define mesh for contour plotting
    xMesh = linspace(-2, 2, 100);
    yMesh = linspace(-1, 3, 100);
    [X, Y] = meshgrid(xMesh, yMesh);
    
    % Evaluate function on mesh
    Z = arrayfun(@(x, y) f([x; y]), X, Y);
    
    % Subplot 1: Contour plot
    subplot(1, 2, 1);
    contour(X, Y, Z, 50);
    hold on;
    
    % Plot initial and optimal points
    plot(x0(1), x0(2), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red', ...
         'DisplayName', 'Initial Point');
    plot(xOpt(1), xOpt(2), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'green', ...
         'DisplayName', 'Optimal Point');
    plot(1, 1, 'k*', 'MarkerSize', 12, 'LineWidth', 2, ...
         'DisplayName', 'True Optimum');
    
    % Configure plot
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Rosenbrock Function Contours', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Location', 'best', 'Interpreter', 'latex', 'FontSize', 10);
    colorbar;
    grid on;
    
    % Subplot 2: 3*D surface
    subplot(1, 2, 2);
    surf(X, Y, Z, 'EdgeColor', 'none', 'FaceAlpha', 0.8);
    hold on;
    plot3(x0(1), x0(2), f([x0(1); x0(2)]), 'ro', 'MarkerSize', 12, ...
          'LineWidth', 2);
    plot3(xOpt(1), xOpt(2), f([xOpt(1); xOpt(2)]), 'go', 'MarkerSize', 12, ...
          'LineWidth', 2);
    plot3(1, 1, 0, 'k*', 'MarkerSize', 15, 'LineWidth', 2);
    
    colormap('jet');
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$f(x_1, x_2)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Rosenbrock Function Surface', 'Interpreter', 'latex', 'FontSize', 13);
    view(45, 30);
    grid on;
end
