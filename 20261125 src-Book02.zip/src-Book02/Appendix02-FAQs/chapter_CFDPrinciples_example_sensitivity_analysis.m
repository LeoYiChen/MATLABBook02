%% chapter_CFDPrinciples_example_sensitivity_analysis.m
% Comprehensive sensitivity analysis framework.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_sensitivity_analysis
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function sensitivityResults = performSensitivityAnalysis(baselineParams, ...
    parameterRanges, outputQuantities, simulationFunction)
    % PERFORMSENSITIVITYANALYSIS Comprehensive sensitivity and uncertainty analysis
    % Implements OFAT, Morris screening, and Monte Carlo propagation
    %
    % Inputs:
    %   baselineParams    - Struct: nominal parameter values
    %   parameterRanges   - Struct: min/max or distribution for each parameter
    %   outputQuantities  - Cell array: names of outputs to analyse
    %   simulationFunction- Function handle: @(params) -> results
    %
    % Output:
    %   sensitivityResults - Comprehensive sensitivity assessment
    %
    % Author: Dr Leo Chen
    % Institution: University of Cambridge
    % Version: 3.0
    %
    % References:
    %   [1] Oberkampf & Roy (2010) Verification and Validation
    %   [2] Saltelli et al. (2008) Global Sensitivity Analysis
    %   [3] Morris (1991) Factorial sampling plans
    
    fprintf('=== Sensitivity Analysis ===\n\n');
    
    sensitivityResults = struct();
    
    % Baseline simulation
    fprintf('Running baseline simulation...\n');
    baselineResults = simulationFunction(baselineParams);
    sensitivityResults.baseline = baselineResults;
    
    % Extract parameter names
    paramNames = fieldnames(parameterRanges);
    numParams = length(paramNames);
    
    fprintf('  Baseline complete\n');
    fprintf('  Number of parameters: %d\n\n', numParams);
    
    % 1. One-Factor-At-a-Time (OFAT) sensitivity
    fprintf('Performing OFAT sensitivity analysis...\n');
    ofatResults = performOFAT(baselineParams, parameterRanges, ...
                             outputQuantities, simulationFunction, ...
                             baselineResults);
    sensitivityResults.OFAT = ofatResults;
    
    % 2. Morris screening (if feasible)
    if numParams <= 20  % Morris practical for moderate dimensions
        fprintf('\nPerforming Morris screening...\n');
        morrisResults = performMorrisScreening(baselineParams, parameterRanges, ...
                                              outputQuantities, simulationFunction);
        sensitivityResults.Morris = morrisResults;
    else
        fprintf('\nMorris screening skipped (too many parameters)\n');
        sensitivityResults.Morris = struct('performed', false);
    end
    
    % 3. Monte Carlo uncertainty propagation (limited samples)
    fprintf('\nPerforming Monte Carlo uncertainty propagation...\n');
    mcResults = performMonteCarloUQ(baselineParams, parameterRanges, ...
                                   outputQuantities, simulationFunction);
    sensitivityResults.MonteCarlo = mcResults;
    
    % Generate comprehensive report
    generateSensitivityReport(sensitivityResults, outputQuantities);
    
    % Visualise results
    visualiseSensitivityResults(sensitivityResults, outputQuantities);
    
    fprintf('\nSensitivity analysis completed.\n');
end

function ofatRes = performOFAT(baseline, ranges, outputs, simFunc, baseResults)
    % One-Factor-At-a-Time sensitivity analysis
    
    ofatRes = struct();
    
    paramNames = fieldnames(ranges);
    numParams = length(paramNames);
    numOutputs = length(outputs);
    
    % Perturbation magnitude (뿯½뿯½10% by default)
    perturbFraction = 0.10;
    
    fprintf('  Perturbation magnitude: 뿯½뿯½%.1f%%\n', perturbFraction*100);
    
    % Initialise sensitivity matrices
    sensitivities = zeros(numOutputs, numParams);
    normalisedSensitivities = zeros(numOutputs, numParams);
    
    for i = 1:numParams
        paramName = paramNames{i};
        
        fprintf('  Varying %s... ', paramName);
        
        baseValue = baseline.(paramName);
        
        % Positive perturbation
        perturbedParams = baseline;
        perturbedParams.(paramName) = baseValue * (1 + perturbFraction);
        
        resultsPlus = simFunc(perturbedParams);
        
        % Negative perturbation
        perturbedParams.(paramName) = baseValue * (1 - perturbFraction);
        resultsMinus = simFunc(perturbedParams);
        
        % Compute sensitivities for each output
        for j = 1:numOutputs
            outputName = outputs{j};
            
            phi_base = baseResults.(outputName);
            phi_plus = resultsPlus.(outputName);
            phi_minus = resultsMinus.(outputName);
            
            % Central difference approximation
            delta_theta = 2 * perturbFraction * baseValue;
            
            if delta_theta > 1e-12
                dPhi_dTheta = (phi_plus - phi_minus) / delta_theta;
                sensitivities(j, i) = dPhi_dTheta;
                
                % Normalised sensitivity
                if abs(phi_base) > 1e-12
                    normalisedSensitivities(j, i) = ...
                        (baseValue / phi_base) * dPhi_dTheta;
                else
                    normalisedSensitivities(j, i) = dPhi_dTheta;
                end
            end
        end
        
        fprintf('complete\n');
    end
    
    ofatRes.sensitivities = sensitivities;
    ofatRes.normalisedSensitivities = normalisedSensitivities;
    ofatRes.parameterNames = paramNames;
    ofatRes.outputNames = outputs;
    
    fprintf('  OFAT analysis complete\n');
end

function morrisRes = performMorrisScreening(baseline, ranges, outputs, simFunc)
    % Morris screening method for global sensitivity
    
    morrisRes = struct();
    
    paramNames = fieldnames(ranges);
    numParams = length(paramNames);
    numOutputs = length(outputs);
    
    % Morris sampling parameters
    numTrajectories = 10;  % Typical: 10-50
    numLevels = 4;         % Discretisation levels
    
    fprintf('  Number of trajectories: %d\n', numTrajectories);
    fprintf('  Grid levels: %d\n', numLevels);
    fprintf('  Total simulations: %d\n', numTrajectories * (numParams + 1));
    
    % Initialise elementary effects storage
    elementaryEffects = zeros(numTrajectories, numParams, numOutputs);
    
    for traj = 1:numTrajectories
        fprintf('  Trajectory %d/%d... ', traj, numTrajectories);
        
        % Generate Morris trajectory
        trajectory = generateMorrisTrajectory(baseline, ranges, numParams, numLevels);
        
        % Evaluate along trajectory
        for step = 1:numParams+1
            stepParams = setParamsFromTrajectory(baseline, ranges, ...
                                                 trajectory(step, :), paramNames);
            
            stepResults = simFunc(stepParams);
            
            % Store results
            if step == 1
                prevResults = stepResults;
            else
                % Compute elementary effect for changed parameter
                changedParam = step - 1;
                
                for outIdx = 1:numOutputs
                    outputName = outputs{outIdx};
                    
                    delta = (stepResults.(outputName) - prevResults.(outputName)) / ...
                            (trajectory(step, changedParam) - trajectory(step-1, changedParam));
                    
                    elementaryEffects(traj, changedParam, outIdx) = delta;
                end
                
                prevResults = stepResults;
            end
        end
        
        fprintf('complete\n');
    end
    
    % Compute Morris statistics
    mu_star = zeros(numParams, numOutputs);  % Mean absolute effect
    sigma = zeros(numParams, numOutputs);    % Standard deviation
    
    for i = 1:numParams
        for j = 1:numOutputs
            effects = elementaryEffects(:, i, j);
            mu_star(i, j) = mean(abs(effects));
            sigma(i, j) = std(effects);
        end
    end
    
    morrisRes.mu_star = mu_star;
    morrisRes.sigma = sigma;
    morrisRes.parameterNames = paramNames;
    morrisRes.outputNames = outputs;
    morrisRes.elementaryEffects = elementaryEffects;
    
    fprintf('  Morris screening complete\n');
end

function mcRes = performMonteCarloUQ(baseline, ranges, outputs, simFunc)
    % Monte Carlo uncertainty quantification
    
    mcRes = struct();
    
    paramNames = fieldnames(ranges);
    numParams = length(paramNames);
    numOutputs = length(outputs);
    
    % Number of MC samples (limited for CFD)
    numSamples = 50;  % Typical: 50-1000 depending on computational cost
    
    fprintf('  Number of MC samples: %d\n', numSamples);
    
    % Generate random samples
    samples = generateMCSamples(baseline, ranges, paramNames, numSamples);
    
    % Initialise output storage
    outputSamples = cell(numOutputs, 1);
    
    for i = 1:numOutputs
        outputSamples{i} = zeros(numSamples, 1);
    end
    
    % Run simulations
    for samp = 1:numSamples
        fprintf('  Sample %d/%d... ', samp, numSamples);
        
        sampParams = setParamsFromSample(baseline, samples(samp, :), paramNames);
        
        sampResults = simFunc(sampParams);
        
        % Store output values
        for outIdx = 1:numOutputs
            outputName = outputs{outIdx};
            outputSamples{outIdx}(samp) = sampResults.(outputName);
        end
        
        fprintf('complete\n');
    end
    
    % Compute statistics for each output
    mcRes.mean = zeros(numOutputs, 1);
    mcRes.std = zeros(numOutputs, 1);
    mcRes.CI_95 = zeros(numOutputs, 2);  % 95% confidence interval
    
    for i = 1:numOutputs
        data = outputSamples{i};
        
        mcRes.mean(i) = mean(data);
        mcRes.std(i) = std(data);
        
        % 95% confidence interval (assuming normal distribution)
        mcRes.CI_95(i, :) = [prctile(data, 2.5), prctile(data, 97.5)];
    end
    
    mcRes.outputSamples = outputSamples;
    mcRes.outputNames = outputs;
    
    fprintf('  Monte Carlo UQ complete\n');
end

function trajectory = generateMorrisTrajectory(baseline, ranges, numParams, levels)
    % Generate Morris sampling trajectory
    
    % Simple implementation: random walk in parameter space
    trajectory = zeros(numParams+1, numParams);
    
    % Start at random point
    trajectory(1, :) = rand(1, numParams);
    
    % Create path with one parameter change per step
    paramOrder = randperm(numParams);
    
    for step = 1:numParams
        trajectory(step+1, :) = trajectory(step, :);
        
        % Change one parameter
        paramIdx = paramOrder(step);
        
        % Random jump of 뿯½뿯½1/levels
        direction = 2*(randi(2)-1) - 1;  % 뿯½뿯½1
        jump = direction / (levels - 1);
        
        newValue = trajectory(step, paramIdx) + jump;
        
        % Clip to [0, 1]
        newValue = max(0, min(1, newValue));
        
        trajectory(step+1, paramIdx) = newValue;
    end
end

function params = setParamsFromTrajectory(baseline, ranges, trajPoint, paramNames)
    % Convert normalised trajectory point to actual parameters
    
    params = baseline;
    
    for i = 1:length(paramNames)
        paramName = paramNames{i};
        
        if isfield(ranges.(paramName), 'min') && isfield(ranges.(paramName), 'max')
            minVal = ranges.(paramName).min;
            maxVal = ranges.(paramName).max;
            
            params.(paramName) = minVal + trajPoint(i) * (maxVal - minVal);
        end
    end
end

function samples = generateMCSamples(baseline, ranges, paramNames, numSamples)
    % Generate Monte Carlo samples
    
    numParams = length(paramNames);
    samples = zeros(numSamples, numParams);
    
    for i = 1:numParams
        paramName = paramNames{i};
        
        if isfield(ranges.(paramName), 'distribution')
            % Use specified distribution
            distType = ranges.(paramName).distribution;
            
            switch distType
                case 'uniform'
                    minVal = ranges.(paramName).min;
                    maxVal = ranges.(paramName).max;
                    samples(:, i) = minVal + (maxVal - minVal) * rand(numSamples, 1);
                    
                case 'normal'
                    mu = baseline.(paramName);
                    sigma = ranges.(paramName).std;
                    samples(:, i) = mu + sigma * randn(numSamples, 1);
                    
                otherwise
                    % Default: uniform 뿯½뿯½10%
                    baseVal = baseline.(paramName);
                    samples(:, i) = baseVal * (0.9 + 0.2 * rand(numSamples, 1));
            end
        else
            % Default: uniform between min and max
            minVal = ranges.(paramName).min;
            maxVal = ranges.(paramName).max;
            samples(:, i) = minVal + (maxVal - minVal) * rand(numSamples, 1);
        end
    end
end

function params = setParamsFromSample(baseline, sample, paramNames)
    % Set parameters from MC sample vector
    
    params = baseline;
    
    for i = 1:length(paramNames)
        params.(paramNames{i}) = sample(i);
    end
end

function generateSensitivityReport(sensRes, outputs)
    % Generate comprehensive sensitivity report
    
    fprintf('\n=== SENSITIVITY ANALYSIS REPORT ===\n\n');
    
    % OFAT results
    fprintf('ONE-FACTOR-AT-A-TIME SENSITIVITY:\n\n');
    
    for i = 1:length(outputs)
        fprintf('  Output: %s\n', outputs{i});
        
        [~, sortIdx] = sort(abs(sensRes.OFAT.normalisedSensitivities(i, :)), 'descend');
        
        fprintf('    Most sensitive parameters (normalised):\n');
        
        for j = 1:min(5, length(sortIdx))
            paramIdx = sortIdx(j);
            paramName = sensRes.OFAT.parameterNames{paramIdx};
            sensValue = sensRes.OFAT.normalisedSensitivities(i, paramIdx);
            
            fprintf('      %s: %.4f\n', paramName, sensValue);
        end
        
        fprintf('\n');
    end
    
    % Morris results (if available)
    if isfield(sensRes, 'Morris') && isfield(sensRes.Morris, 'mu_star')
        fprintf('MORRIS SCREENING RESULTS:\n\n');
        
        for i = 1:length(outputs)
            fprintf('  Output: %s\n', outputs{i});
            
            [~, sortIdx] = sort(sensRes.Morris.mu_star(:, i), 'descend');
            
            fprintf('    Most influential parameters (뿯½뿯½*):\n');
            
            for j = 1:min(5, length(sortIdx))
                paramIdx = sortIdx(j);
                paramName = sensRes.Morris.parameterNames{paramIdx};
                muStar = sensRes.Morris.mu_star(paramIdx, i);
                sigma = sensRes.Morris.sigma(paramIdx, i);
                
                fprintf('      %s: 뿯½뿯½*=%.4f, 뿯½뿯½=%.4f\n', paramName, muStar, sigma);
            end
            
            fprintf('\n');
        end
    end
    
    % Monte Carlo results
    fprintf('MONTE CARLO UNCERTAINTY QUANTIFICATION:\n\n');
    
    for i = 1:length(outputs)
        fprintf('  Output: %s\n', outputs{i});
        fprintf('    Mean: %.6f\n', sensRes.MonteCarlo.mean(i));
        fprintf('    Std: %.6f\n', sensRes.MonteCarlo.std(i));
        fprintf('    95%% CI: [%.6f, %.6f]\n', ...
                sensRes.MonteCarlo.CI_95(i, 1), sensRes.MonteCarlo.CI_95(i, 2));
        fprintf('\n');
    end
    
    fprintf('=== END OF REPORT ===\n');
end

function visualiseSensitivityResults(sensRes, outputs)
    % Visualise sensitivity analysis results
    
    figure('Name', 'Sensitivity Analysis', 'Position', [100, 100, 1400, 900]);
    
    numOutputs = length(outputs);
    
    % OFAT normalised sensitivities (bar chart)
    for i = 1:min(numOutputs, 2)
        subplot(2, 2, i);
        
        normSens = sensRes.OFAT.normalisedSensitivities(i, :);
        
        [sortedSens, sortIdx] = sort(abs(normSens), 'descend');
        sortedParams = sensRes.OFAT.parameterNames(sortIdx);
        
        % Plot top 10
        numPlot = min(10, length(sortedSens));
        
        barh(sortedSens(1:numPlot));
        set(gca, 'YTick', 1:numPlot, 'YTickLabel', sortedParams(1:numPlot));
        xlabel('Normalised sensitivity', 'Interpreter', 'latex');
        title(['OFAT: ' outputs{i}], 'Interpreter', 'latex');
        grid on;
    end
    
    % Monte Carlo histograms
    for i = 1:min(numOutputs, 2)
        subplot(2, 2, 2+i);
        
        data = sensRes.MonteCarlo.outputSamples{i};
        
        histogram(data, 20, 'Normalization', 'pdf');
        xlabel(outputs{i}, 'Interpreter', 'latex');
        ylabel('Probability density', 'Interpreter', 'latex');
        title(['Monte Carlo: ' outputs{i}], 'Interpreter', 'latex');
        grid on;
        
        % Add mean and CI lines
        hold on;
        yLim = ylim;
        plot([sensRes.MonteCarlo.mean(i), sensRes.MonteCarlo.mean(i)], yLim, ...
             'r--', 'LineWidth', 2);
        plot([sensRes.MonteCarlo.CI_95(i, 1), sensRes.MonteCarlo.CI_95(i, 1)], yLim, ...
             'k--', 'LineWidth', 1);
        plot([sensRes.MonteCarlo.CI_95(i, 2), sensRes.MonteCarlo.CI_95(i, 2)], yLim, ...
             'k--', 'LineWidth', 1);
        
        legend('Distribution', 'Mean', '95% CI', 'Location', 'best', ...
               'Interpreter', 'latex');
    end
    
    sgtitle('Sensitivity and Uncertainty Analysis', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
end
