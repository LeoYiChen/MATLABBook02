%% code_inverse_design.m
% AI-enhanced inverse design.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:inverse_design
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [optimalActuation, history] = inverseDesignAI(X, Y, targetShape, ...
    E_young, nu, h, dx, dy)
    % Use AI optimisation to find actuation pattern for target shape
    % Employs genetic algorithm for global optimisation
    
    % Parameterise actuation using Gaussian basis functions
    nGaussians = 5;  % Number of Gaussian actuators
    
    % Optimisation bounds: [x_centre, y_centre, sigma, amplitude] for each
    lb = repmat([0, 0, 0.05, 0], 1, nGaussians);
    ub = repmat([1, 1, 0.3, 2e4], 1, nGaussians);
    
    % Genetic algorithm options
    gaOptions = optimoptions('ga', ...
        'PopulationSize', 50, ...
        'MaxGenerations', 30, ...
        'Display', 'iter', ...
        'UseParallel', false, ...
        'PlotFcn', @gaplotbestf);
    
    % Objective: minimise difference from target
    objectiveFcn = @(params) shapeMatchingObjective(params, X, Y, ...
        targetShape, E_young, nu, h, dx, dy);
    
    % Run genetic algorithm
    [optimalParams, ~, ~, output] = ga(objectiveFcn, ...
        4*nGaussians, [], [], [], [], lb, ub, [], gaOptions);
    
    % Reconstruct optimal actuation
    optimalActuation = reconstructActuation(optimalParams, X, Y, nGaussians);
    history = output;
    
    % Visualise result
    visualiseInverseDesign(X, Y, targetShape, optimalActuation, optimalParams, ...
        E_young, nu, h, dx, dy);
end

function F = reconstructActuation(params, X, Y, nGaussians)
    % Reconstruct actuation field from parameters
    F = zeros(size(X));
    
    for i = 1:nGaussians
        idx = (i-1)*4 + 1;
        x0 = params(idx);
        y0 = params(idx+1);
        sigma = params(idx+2);
        amp = params(idx+3);
        
        F = F + amp * exp(-((X - x0).^2 + (Y - y0).^2) / (2 * sigma^2));
    end
end

function error = shapeMatchingObjective(params, X, Y, target, E, nu, h, dx, dy)
    % Objective function for inverse design
    
    nGaussians = length(params) / 4;
    F_active = reconstructActuation(params, X, Y, nGaussians);
    
    % Solve forward problem
    [Ny, Nx] = size(X);
    u0 = zeros(Ny * Nx, 1);
    
    options = optimoptions('fminunc', 'Display', 'off', 'MaxIterations', 100);
    u_opt = fminunc(@(u) computeTotalEnergy(u, X, Y, F_active, E, nu, h, dx, dy), ...
        u0, options);
    
    U_result = reshape(u_opt, Ny, Nx);
    
    % Shape matching error
    error = sum((U_result(:) - target(:)).^2);
end

function targetShape = generateTargetShape(X, Y)
    % Generate example target shape (saddle surface)
    targetShape = 0.1 * (X - 0.5).^2 - 0.1 * (Y - 0.5).^2;
end

function visualiseInverseDesign(X, Y, target, actuation, params, E, nu, h, dx, dy)
    % Visualise inverse design results
    
    % Compute achieved shape
    [Ny, Nx] = size(X);
    u0 = zeros(Ny * Nx, 1);
    options = optimoptions('fminunc', 'Display', 'off');
    u_opt = fminunc(@(u) computeTotalEnergy(u, X, Y, actuation, E, nu, h, dx, dy), ...
        u0, options);
    U_achieved = reshape(u_opt, Ny, Nx);
    
    figure('Position', [100, 100, 1400, 400]);
    
    subplot(1, 3, 1);
    surf(X, Y, target, 'EdgeColor', 'none');
    title('Target Shape', 'Interpreter', 'latex', 'FontSize', 14);
    colorbar; colormap(jet);
    
    subplot(1, 3, 2);
    contourf(X, Y, actuation, 20);
    title('Optimal Actuation', 'Interpreter', 'latex', 'FontSize', 14);
    colorbar; colormap(jet);
    
    subplot(1, 3, 3);
    surf(X, Y, U_achieved, 'EdgeColor', 'none');
    title('Achieved Shape', 'Interpreter', 'latex', 'FontSize', 14);
    colorbar; colormap(jet);
    
    sgtitle('\textbf{AI-Enhanced Inverse Design Results}', 'Interpreter', 'latex');
end
