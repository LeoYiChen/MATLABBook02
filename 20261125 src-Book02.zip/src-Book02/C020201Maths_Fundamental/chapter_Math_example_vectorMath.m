%% chapter_Math_example_vectorMath.m
% Vectorised mathematical operations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_vectorMath
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Generate sample data
x = linspace(0, 2*pi, 100);

% Multiple vectorised operations combined
y1 = sin(x);                    % Sine of all elements
y2 = exp(-x.^2);               % Gaussian decay
y3 = (x.^3 - 2*x.^2 + x - 1);  % Polynomial evaluation

% Complex vectorised expression
y4 = sin(x) .* exp(-x/4) + cos(2*x) .* (1 - x/10);

% Matrix operations are naturally vectorised
A = rand(100, 100);
B = rand(100, 100);
C = A * B;              % Matrix multiplication
D = A .* B;             % Element-wise multiplication
E = A.^2;               % Element-wise squaring
F = sqrt(A);            % Element-wise square root

% Vectorised conditional operations
x = -5:0.1:5;
% Implement: y = x^2 if x > 0, else y = 0
y = max(x.^2, 0);  % Elegant vectorised approach

% Or using logical indexing
y = zeros(size(x));
posIdx = x > 0;
y(posIdx) = x(posIdx).^2;
