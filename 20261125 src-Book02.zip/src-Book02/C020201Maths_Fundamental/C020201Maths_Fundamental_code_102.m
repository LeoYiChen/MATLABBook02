%% C020201Maths_Fundamental_code_102.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Boundary value problem: y'' + p(x)y' + q(x)y = f(x)
% with y(a) = alpha, y(b) = beta

solinit = bvpinit(linspace(0, 1, 10), @initialGuess);
bvpODE = @(x, y) [y(2); -abs(y(1))];
bvpBC = @(ya, yb) [ya(1) - 0; yb(1) - 2];

sol = bvp4c(bvpODE, bvpBC, solinit);
