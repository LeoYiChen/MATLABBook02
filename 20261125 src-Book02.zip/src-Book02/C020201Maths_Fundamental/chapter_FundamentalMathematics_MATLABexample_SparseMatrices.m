%% chapter_FundamentalMathematics_MATLABexample_SparseMatrices.m
% Sparse matrix efficiency demonstration.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_SparseMatrices
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_2_3_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates sparse matrix efficiency through memory
%              usage and computational performance comparisons.

function demonstrateSparseMatrixEfficiency()
    % System parameters
    matrixSize = 5000;
    targetSparsity = 0.98; % 98% of elements are zero
    
    fprintf('Sparse Matrix Efficiency Demonstration\n');
    fprintf('Matrix Dimension: %d $\times$ %d\n', matrixSize, matrixSize);
    fprintf('Target Sparsity: %.1f%%\n', targetSparsity * 100);
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Generate sparse test matrix (tridiagonal with random sparse elements)
    [sparseMatrix, denseMatrix] = generateSparseTestSystem(matrixSize, ...
                                                          targetSparsity);
    
    % Analyse actual sparsity achieved
    actualSparsity = 1 - nnz(sparseMatrix) / numel(sparseMatrix);
    fprintf('Actual Sparsity Achieved: %.2f%%\n', actualSparsity * 100);
    fprintf('Non-zero Elements: %d out of %d\n', nnz(sparseMatrix), ...
            numel(sparseMatrix));
    
    % Memory usage comparison
    sparseInfo = whos('sparseMatrix');
    denseInfo = whos('denseMatrix');
    
    fprintf('\nMemory Usage Comparison:\n');
    fprintf('  Sparse Matrix: %.2f MB\n', sparseInfo.bytes / 1024^2);
    fprintf('  Dense Matrix:  %.2f MB\n', denseInfo.bytes / 1024^2);
    fprintf('  Memory Reduction Factor: %.1f$\times$\n', ...
            denseInfo.bytes / sparseInfo.bytes);
    
    % Generate right-hand side vector
    rhsVector = randn(matrixSize, 1);
    
    % Computational performance comparison
    fprintf('\nComputational Performance:\n');
    
    % Sparse matrix solution
    fprintf('  Sparse matrix solution:\n');
    tic;
    sparseSolution = sparseMatrix \ rhsVector;
    sparseTime = toc;
    fprintf('    Time: %.4f seconds\n', sparseTime);
    sparseResidual = norm(sparseMatrix * sparseSolution - rhsVector);
    fprintf('    Residual norm: %.6e\n', sparseResidual);
    
    % Dense matrix solution (only for smaller systems to avoid excessive time)
    if matrixSize <= 2000
        fprintf('  Dense matrix solution:\n');
        tic;
        denseSolution = denseMatrix \ rhsVector;
        denseTime = toc;
        fprintf('    Time: %.4f seconds\n', denseTime);
        denseResidual = norm(denseMatrix * denseSolution - rhsVector);
        fprintf('    Residual norm: %.6e\n', denseResidual);
        
        fprintf('  Speed Improvement: %.1f$\times$\n', denseTime / sparseTime);
        
        % Verify solution equivalence
        solutionDifference = norm(sparseSolution - denseSolution);
        fprintf('  Solution Difference: %.6e\n', solutionDifference);
    else
        fprintf('  Dense matrix solution skipped (matrix too large)\n');
    end
    
    % Visualise sparsity pattern
    visualiseSparsityStructure(sparseMatrix);
    
    % Analyse sparse matrix properties
    analyseMatrixProperties(sparseMatrix);
end

function [sparseMat, denseMat] = generateSparseTestSystem(n, sparsity)
    % Generate sparse test matrix with controlled sparsity pattern
    % Uses tridiagonal structure (common in finite difference methods)
    % plus random sparse elements
    
    % Create tridiagonal matrix (represents discretised 1*D Laplacian)
    mainDiag = 4 * ones(n, 1);
    offDiag = -ones(n-1, 1);
    
    sparseMat = spdiags([offDiag, mainDiag, offDiag], [-1, 0, 1], n, n);
    
    % Add random sparse elements to achieve target sparsity
    currentNonZeros = nnz(sparseMat);
    targetNonZeros = round((1 - sparsity) * n^2);
    additionalNonZeros = targetNonZeros - currentNonZeros;
    
    if additionalNonZeros > 0
        % Generate random positions for additional non-zero elements
        numCandidates = min(additionalNonZeros * 2, n^2);
        linearIndices = randperm(n^2, numCandidates);
        
        addedCount = 0;
        for idx = 1:numCandidates
            if addedCount >= additionalNonZeros
                break;
            end
            
            [rowIdx, colIdx] = ind2sub([n, n], linearIndices(idx));
            
            % Only add if currently zero
            if sparseMat(rowIdx, colIdx) == 0
                sparseMat(rowIdx, colIdx) = 0.1 * randn();
                addedCount = addedCount + 1;
            end
        end
    end
    
    % Ensure symmetric positive definiteness for numerical stability
    sparseMat = (sparseMat + sparseMat') / 2; % Symmetrise
    sparseMat = sparseMat + (abs(min(eig(full(sparseMat(1:min(50,n), ...
                1:min(50,n)))))) + 1) * speye(n); % Ensure positive definite
    
    % Create equivalent dense matrix
    denseMat = full(sparseMat);
end

function visualiseSparsityStructure(sparseMat)
    % Visualise the sparsity pattern of the matrix
    
    figure('Position', [100, 100, 800, 700]);
    
    spy(sparseMat);
    title(sprintf('Sparse Matrix Structure (%.2f%% non-zero)', ...
                 100 * nnz(sparseMat) / numel(sparseMat)), ...
          'Interpreter', 'latex', 'FontSize', 14);
    xlabel('Column Index', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Row Index', 'Interpreter', 'latex', 'FontSize', 12);
    
    % Add informative annotation
    dimensionText = sprintf('Matrix Size: $%d \\times %d$', ...
                           size(sparseMat, 1), size(sparseMat, 2));
    nonZeroText = sprintf('Non-zeros: $%d$ (%.3f\\%%)', ...
                         nnz(sparseMat), ...
                         100 * nnz(sparseMat) / numel(sparseMat));
    
    annotation('textbox', [0.15, 0.80, 0.3, 0.1], ...
               'String', {dimensionText, nonZeroText}, ...
               'Interpreter', 'latex', 'FontSize', 11, ...
               'BackgroundColor', 'white', 'EdgeColor', 'black', ...
               'LineWidth', 1);
    
    set(gca, 'FontSize', 11);
end

function analyseMatrixProperties(sparseMat)
    % Analyse numerical and structural properties
    
    fprintf('\nMatrix Property Analysis:\n');
    fprintf('%s\n', repmat('-', 1, 50));
    
    % Bandwidth analysis
    [rowIndices, colIndices] = find(sparseMat);
    bandwidth = max(abs(rowIndices - colIndices));
    fprintf('  Matrix Bandwidth: %d\n', bandwidth);
    
    % Symmetry check (for small sample)
    sampleSize = min(100, size(sparseMat, 1));
    sampleMatrix = sparseMat(1:sampleSize, 1:sampleSize);
    symmetryError = norm(sampleMatrix - sampleMatrix', 'fro') / ...
                   norm(sampleMatrix, 'fro');
    fprintf('  Symmetry Error (sample): %.6e\n', symmetryError);
    
    % Diagonal dominance check
    absDiag = abs(diag(sparseMat));
    absRowSum = sum(abs(sparseMat), 2) - absDiag;
    diagDominance = min(absDiag ./ absRowSum);
    fprintf('  Min Diagonal Dominance Ratio: %.4f\n', diagDominance);
    
    if diagDominance >= 1
        fprintf('  Matrix is diagonally dominant\n');
    end
    
    % Condition number estimate (for small sample to avoid expensive computation)
    if size(sparseMat, 1) <= 1000
        conditionNumber = condest(sparseMat);
        fprintf('  Condition Number (estimated): %.4e\n', conditionNumber);
    else
        fprintf('  Condition number estimation skipped (matrix too large)\n');
    end
end
