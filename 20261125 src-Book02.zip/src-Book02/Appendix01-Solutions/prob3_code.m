%% prob3_code.m
% 3D surface fitting for CVD process optimisation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob3_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% 3D Surface Fitting: CVD Process Optimisation
% File: MATLABBook02_Chapter07_Problem03.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Fits 3D response surface to experimental CVD data and
%              identifies optimal operating conditions
% =========================================================================

function MATLABBook02_Chapter07_Problem03()
    % Main function for Problem 3: 3D Surface Fitting
    
    clc; clear; close all;
    
    % Generate experimental design data
    [temperature, flowRate, thickness] = generateCVDdata();
    
    % Fit response surface using multiple methods
    [gridTemp, gridFlow, fittedThickness] = fitResponseSurface(...
        temperature, flowRate, thickness);
    
    % Create comprehensive visualisations
    visualise3Dsurface(temperature, flowRate, thickness, ...
                      gridTemp, gridFlow, fittedThickness);
    
    % Generate contour plots
    createContourAnalysis(gridTemp, gridFlow, fittedThickness, ...
                         temperature, flowRate, thickness);
    
    % Find optimal conditions
    [optTemp, optFlow, maxThickness] = findOptimalConditions(...
        gridTemp, gridFlow, fittedThickness);
    
    % Display results
    fprintf('\n========================================\n');
    fprintf('   CVD PROCESS OPTIMISATION RESULTS\n');
    fprintf('========================================\n');
    fprintf('Optimal Temperature:  %.1f  C\n', optTemp);
    fprintf('Optimal Flow Rate:    %.1f sccm\n', optFlow);
    fprintf('Maximum Thickness:    %.2f nm\n', maxThickness);
    fprintf('========================================\n');
    
    % Perform sensitivity analysis
    performSensitivityAnalysis(gridTemp, gridFlow, fittedThickness, ...
                              optTemp, optFlow);
end

function [T, Q, thickness] = generateCVDdata()
    % GENERATECVDDATA - Creates synthetic CVD experimental data
    %
    % Outputs:
    %   T - Temperature ( C)
    %   Q - Flow rate (sccm)
    %   thickness - Film thickness (nm)
    
    rng(456);
    
    % Experimental design: 5 5 factorial with center points
    T_levels = linspace(300, 500, 5);
    Q_levels = linspace(50, 150, 5);
    
    [T_grid, Q_grid] = meshgrid(T_levels, Q_levels);
    T = T_grid(:);
    Q = Q_grid(:);
    
    % Add center point replicates for pure error estimation
    T = [T; 400*ones(3,1)];
    Q = [Q; 100*ones(3,1)];
    
    % True response surface (quadratic with interaction)
    % Optimal region around T=450 C, Q=100 sccm
    thickness_true = 50 + 0.4*(T-400) + 0.2*(Q-100) - ...
                    0.0008*(T-400).^2 - 0.0015*(Q-100).^2 + ...
                    0.0005*(T-400).*(Q-100);
    
    % Add experimental noise ( 3 nm standard deviation)
    noise = 3 * randn(size(thickness_true));
    thickness = thickness_true + noise;
end

function [gridT, gridQ, fitted_thickness] = fitResponseSurface(T, Q, thickness)
    % FITRESPONSESURFACE - Creates interpolated response surface
    %
    % Uses scattered interpolation with natural neighbour method
    
    % Create high-resolution grid for smooth surface
    Tq = linspace(min(T), max(T), 100);
    Qq = linspace(min(Q), max(Q), 100);
    [gridT, gridQ] = meshgrid(Tq, Qq);
    
    % Fit surface using scattered interpolant
    F = scatteredInterpolant(T, Q, thickness, 'natural', 'linear');
    fitted_thickness = F(gridT, gridQ);
end

function visualise3Dsurface(T, Q, thickness, gridT, gridQ, fitted_thickness)
    % VISUALISE3DSURFACE - Creates comprehensive 3D visualisation
    
    figure('Name', '3D Response Surface: CVD Process', ...
           'Position', [50, 50, 1400, 600]);
    
    % Subplot 1: Surface with experimental points
    subplot(1, 2, 1);
    surf(gridT, gridQ, fitted_thickness, 'EdgeColor', 'none', 'FaceAlpha', 0.85);
    hold on;
    
    % Plot experimental data points
    scatter3(T, Q, thickness, 80, 'r', 'filled', 'MarkerEdgeColor', 'k', ...
            'LineWidth', 1);
    
    colormap(jet);
    colorbar('FontSize', 10);
    
    xlabel('Temperature, $T$ ( C)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Flow Rate, $Q$ (sccm)', 'Interpreter', 'latex', 'FontSize', 11);
    zlabel('Thickness, $h$ (nm)', 'Interpreter', 'latex', 'FontSize', 11);
    title('3D Response Surface with Experimental Data', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    
    view(45, 30);
    grid on;
    lighting gouraud;
    material shiny;
    camlight('headlight');
    set(gca, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 2: Contour on 3D surface
    subplot(1, 2, 2);
    surfc(gridT, gridQ, fitted_thickness, 'EdgeColor', 'none', 'FaceAlpha', 0.7);
    
    xlabel('Temperature, $T$ ( C)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Flow Rate, $Q$ (sccm)', 'Interpreter', 'latex', 'FontSize', 11);
    zlabel('Thickness, $h$ (nm)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Surface with Projected Contours', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    
    view(45, 30);
    colormap(jet);
    colorbar('FontSize', 10);
    grid on;
    set(gca, 'LineWidth', 1.2);
end

function createContourAnalysis(gridT, gridQ, fitted_thickness, T, Q, thickness)
    % CREATECONTOURANALYSIS - Generates detailed contour plots
    
    figure('Name', 'Contour Analysis: CVD Process', ...
           'Position', [100, 100, 1200, 500]);
    
    % Subplot 1: Filled contour plot
    subplot(1, 2, 1);
    contourf(gridT, gridQ, fitted_thickness, 20, 'LineColor', 'k', 'LineWidth', 0.5);
    hold on;
    
    % Overlay experimental points
    scatter(T, Q, 60, thickness, 'filled', 'MarkerEdgeColor', 'k', ...
           'LineWidth', 1.5);
    
    colormap(jet);
    colorbar('FontSize', 10);
    
    xlabel('Temperature, $T$ ( C)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Flow Rate, $Q$ (sccm)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Filled Contour Plot with Experimental Points', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    
    grid on;
    set(gca, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 2: Contour with labels
    subplot(1, 2, 2);
    [C, h] = contour(gridT, gridQ, fitted_thickness, 15, 'LineWidth', 1.5);
    clabel(C, h, 'FontSize', 9, 'Color', 'k', 'FontWeight', 'bold');
    
    xlabel('Temperature, $T$ ( C)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Flow Rate, $Q$ (sccm)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Labelled Contour Plot (Iso-Thickness Lines)', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    
    colormap(jet);
    colorbar('FontSize', 10);
    grid on;
    set(gca, 'LineWidth', 1.2);
end

function [optT, optQ, maxThick] = findOptimalConditions(gridT, gridQ, thickness)
    % FINDOPTIMALCONDITIONS - Locates maximum on response surface
    
    % Find global maximum
    [maxThick, maxIdx] = max(thickness(:));
    optT = gridT(maxIdx);
    optQ = gridQ(maxIdx);
    
    % Verify using optimisation (fminunc on negative surface)
    f = @(x) -interp2(gridT, gridQ, thickness, x(1), x(2), 'cubic');
    options = optimset('Display', 'off');
    [x_opt, ~] = fminunc(f, [optT, optQ], options);
    
    optT = x_opt(1);
    optQ = x_opt(2);
    maxThick = interp2(gridT, gridQ, thickness, optT, optQ, 'cubic');
end

function performSensitivityAnalysis(gridT, gridQ, thickness, optT, optQ)
    % PERFORMSENSITIVITYANALYSIS - Assesses parameter sensitivity
    
    fprintf('\n=== Sensitivity Analysis at Optimal Point ===\n');
    
    % Compute numerical gradients
    [dT, dQ] = gradient(thickness, gridT(1,:), gridQ(:,1));
    
    % Interpolate gradients at optimal point
    grad_T = interp2(gridT, gridQ, dT, optT, optQ, 'cubic');
    grad_Q = interp2(gridT, gridQ, dQ, optT, optQ, 'cubic');
    
    fprintf('Partial derivative h/T: %.4f nm/ C\n', grad_T);
    fprintf('Partial derivative h/Q: %.4f nm/sccm\n', grad_Q);
    
    % Assess tolerance requirements
    delta_T = 5; %  5 C tolerance
    delta_Q = 10; %  10 sccm tolerance
    
    thickness_var_T = abs(grad_T * delta_T);
    thickness_var_Q = abs(grad_Q * delta_Q);
    
    fprintf('\nExpected thickness variation:\n');
    fprintf('  Due to  %.0f C temperature tolerance:  %.2f nm\n', ...
            delta_T, thickness_var_T);
    fprintf('  Due to  %.0f sccm flow rate tolerance:  %.2f nm\n', ...
            delta_Q, thickness_var_Q);
    fprintf('  Total combined effect:  %.2f nm\n', ...
            sqrt(thickness_var_T^2 + thickness_var_Q^2));
end
