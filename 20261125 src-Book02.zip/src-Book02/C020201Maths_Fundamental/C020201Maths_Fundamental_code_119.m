%% C020201Maths_Fundamental_code_119.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Particle swarm optimisation
options_pso = optimoptions('particleswarm', 'SwarmSize', 100, ...
    'MaxIterations', 200, 'Display', 'off');

[xOpt, fOpt, exitflag, output] = particleswarm(objectiveFunc, ...
    numVariables, lowerBounds, upperBounds, options_pso);
