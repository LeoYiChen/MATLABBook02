%% chapter_AI_Mechanics_Problem1_nn_syntax.m
% Neural network regression syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem1_nn_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define network architecture
layers = [
    featureInputLayer(numFeatures, 'Name', 'input', 'Normalization', 'zscore')
    fullyConnectedLayer(64, 'Name', 'fc1')
    reluLayer('Name', 'relu1')
    dropoutLayer(0.2, 'Name', 'dropout1')
    fullyConnectedLayer(32, 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    dropoutLayer(0.2, 'Name', 'dropout2')
    fullyConnectedLayer(1, 'Name', 'output')
    regressionLayer('Name', 'regression')
];

% Training options
options = trainingOptions('adam', ...
    'MaxEpochs', 500, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 100, ...
    'ValidationData', {featuresVal, targetVal}, ...
    'ValidationFrequency', 10, ...
    'Plots', 'training-progress', ...
    'Verbose', false);

% Train network
nnModel = trainNetwork(featuresTrain, targetTrain, layers, options);

% Predict
predictionsNN = predict(nnModel, featuresTest);
