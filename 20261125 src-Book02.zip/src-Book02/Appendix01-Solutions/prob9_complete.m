%% prob9_complete.m
% Problem 9: Gradient Clipping Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob9_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 9: Gradient Clipping and Exploding Gradients
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Analysis of gradient explosion, clipping strategies,
%              and their impact on RNN training stability

%% Initialization
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 9: Gradient Clipping and Exploding Gradients\n');
fprintf('================================================================\n\n');

%% Network Configuration: LSTM for Sequence Modeling
networkType = 'LSTM';
hiddenSize = 512;
numLayers = 3;
vocabSize = 10000;

fprintf('Network Configuration:\n');
fprintf('  Architecture: %d-layer %s\n', numLayers, networkType);
fprintf('  Hidden size: %d units\n', hiddenSize);
fprintf('  Vocabulary: %d tokens\n', vocabSize);
fprintf('  Task: Language modeling (Penn TreeBank)\n\n');

%% Part (a): Gradient Norm Monitoring Without Clipping

epochs = 1:100;

% Simulated gradient norms (showing explosion)
gradNorm_noClipping = 0.5 * exp(0.08 * epochs) .* (1 + 0.3 * randn(size(epochs)));
gradNorm_noClipping(gradNorm_noClipping < 0) = abs(gradNorm_noClipping(gradNorm_noClipping < 0));

% Training loss (degrades due to instability)
trainLoss_noClipping = 4.5 - 0.02 * epochs + 0.5 * log(gradNorm_noClipping);
trainLoss_noClipping(gradNorm_noClipping > 100) = NaN;  % Training diverges

fprintf('========================================\n');
fprintf('(a) Gradient Explosion Detection\n');
fprintf('========================================\n');

% Find when explosion occurs
explosionEpoch = find(gradNorm_noClipping > 10, 1);

fprintf('Gradient Statistics (No Clipping):\n');
fprintf('  Initial gradient norm: %.2f\n', gradNorm_noClipping(1));
fprintf('  Gradient norm at epoch %d: %.2f\n', explosionEpoch, ...
        gradNorm_noClipping(explosionEpoch));
fprintf('  Growth rate: %.1fx per 10 epochs\n', ...
        gradNorm_noClipping(min(10, length(epochs))) / gradNorm_noClipping(1));
fprintf('  Training diverges at epoch: %d\n\n', ...
        find(isnan(trainLoss_noClipping), 1, 'first'));

fprintf('SIGNS OF GRADIENT EXPLOSION:\n');
fprintf('  1. Exponentially increasing gradient norms\n');
fprintf('  2. NaN or Inf values in weights or losses\n');
fprintf('  3. Oscillating or diverging training loss\n');
fprintf('  4. Overflow errors in computations\n\n');

%% Part (b): Gradient Clipping Methods Comparison

clippingMethods = {'No Clipping', 'Clip by Value ( =1)', ...
                   'Clip by Norm ( =5)', 'Clip by Norm ( =10)', ...
                   'Adaptive Clipping'};

% Simulated results with different clipping strategies
finalAccuracy = [NaN, 65.2, 78.5, 82.3, 83.8];  % NaN = diverged
trainingStability = [0, 60, 85, 95, 98];  % Percentage of stable epochs
convergenceEpoch = [NaN, 85, 65, 50, 45];
maxGradNorm = [Inf, 1.0, 5.0, 10.0, 8.2];  % After clipping

fprintf('========================================\n');
fprintf('(b) Clipping Method Comparison\n');
fprintf('========================================\n');
fprintf('%-25s %-18s %-20s %-22s %-18s\n', 'Method', 'Accuracy (%%)', ...
        'Stability (%%)', 'Convergence (epoch)', 'Max Grad Norm');
fprintf('%s\n', repmat('-', 1, 108));

for i = 1:length(clippingMethods)
    if isnan(finalAccuracy(i))
        fprintf('%-25s %-18s %-20.0f %-22s %-18.1f\n', ...
                clippingMethods{i}, 'DIVERGED', trainingStability(i), ...
                'N/A', maxGradNorm(i));
    else
        fprintf('%-25s %-18.1f %-20.0f %-22.0f %-18.1f\n', ...
                clippingMethods{i}, finalAccuracy(i), ...
                trainingStability(i), convergenceEpoch(i), maxGradNorm(i));
    end
end
fprintf('\n');

fprintf('METHOD ANALYSIS:\n');
fprintf('  Clip by Value: Too aggressive, slows convergence\n');
fprintf('  Clip by Norm ( =5): Good balance, stable training\n');
fprintf('  Clip by Norm ( =10): Best accuracy, slightly less stable\n');
fprintf('  Adaptive: Automatically tunes threshold   best overall\n\n');

%% Part (c): Clipping Threshold Tuning

thresholds = [0.5, 1, 2, 5, 10, 20, 50, 100];
thresholdAccuracy = [62.5, 65.2, 72.8, 78.5, 82.3, 83.5, 82.8, NaN];
thresholdStability = [95, 92, 88, 85, 95, 98, 85, 20];
thresholdConvergence = [95, 85, 75, 65, 50, 45, 48, NaN];

fprintf('========================================\n');
fprintf('(c) Threshold Sensitivity Analysis\n');
fprintf('========================================\n');
fprintf('%-15s %-20s %-20s %-25s\n', 'Threshold  ', 'Accuracy (%%)', ...
        'Stability (%%)', 'Convergence (epoch)');
fprintf('%s\n', repmat('-', 1, 85));

for i = 1:length(thresholds)
    if isnan(thresholdAccuracy(i))
        fprintf('%-15.1f %-20s %-20.0f %-25s\n', ...
                thresholds(i), 'DIVERGED', thresholdStability(i), 'N/A');
    else
        fprintf('%-15.1f %-20.1f %-20.0f %-25.0f\n', ...
                thresholds(i), thresholdAccuracy(i), ...
                thresholdStability(i), thresholdConvergence(i));
    end
end
fprintf('\n');

[bestAcc, bestIdx] = max(thresholdAccuracy(~isnan(thresholdAccuracy)));
optimalThreshold = thresholds(bestIdx);

fprintf('OPTIMAL THRESHOLD:\n');
fprintf('  Best   = %.0f\n', optimalThreshold);
fprintf('  Achieves %.1f%% accuracy\n', bestAcc);
fprintf('  Stability: %.0f%% of epochs\n', thresholdStability(bestIdx));
fprintf('  Converges in %d epochs\n\n', thresholdConvergence(bestIdx));

fprintf('THRESHOLD SELECTION GUIDELINES:\n');
fprintf('  - Too small (< 1): Over-constrains gradients, slow learning\n');
fprintf('  - Too large (> 50): Insufficient protection, instability\n');
fprintf('  - Sweet spot:     [5, 20] for most RNN architectures\n');
fprintf('  - Tune based on: task, network depth, sequence length\n\n');

%% Part (d): Sequence Length Impact on Gradient Explosion

sequenceLengths = [10, 25, 50, 100, 200, 500];

% Gradient growth factor: ( _max)^T where  _max is largest eigenvalue
eigenvalue_max = 1.05;  % Slightly > 1   explosion over long sequences
gradGrowthFactor = eigenvalue_max .^ sequenceLengths;

% Required clipping threshold (empirical scaling)
requiredThreshold = 2 * log(sequenceLengths);

% Training success rate without clipping
successRate_noClip = max(0, 100 - 5 * log(sequenceLengths));

% With optimal clipping
successRate_withClip = 95 * ones(size(sequenceLengths));

fprintf('========================================\n');
fprintf('(d) Sequence Length vs Gradient Explosion\n');
fprintf('========================================\n');
fprintf('%-18s %-25s %-25s %-22s\n', 'Sequence Length', ...
        'Gradient Growth ( )', 'Required Threshold', 'Success w/o Clip');
fprintf('%s\n', repmat('-', 1, 95));

for i = 1:length(sequenceLengths)
    fprintf('%-18d %-25.2f %-25.1f %-22.0f%%\n', ...
            sequenceLengths(i), gradGrowthFactor(i), ...
            requiredThreshold(i), successRate_noClip(i));
end
fprintf('\n');

fprintf('SEQUENCE LENGTH INSIGHTS:\n');
fprintf('  - Gradient growth:  ( _max)^T exponential in sequence length\n');
fprintf('  - Long sequences (T > 100) require clipping for stability\n');
fprintf('  - Alternative: Truncated backpropagation through time (TBPTT)\n');
fprintf('  - Modern solution: Attention mechanisms (avoid recurrence)\n\n');

%% Part (e): Gradient Clipping Implementation

fprintf('========================================\n');
fprintf('(e) Gradient Clipping Implementations\n');
fprintf('========================================\n\n');

fprintf('CLIP BY GLOBAL NORM (Recommended):\n');
fprintf('```matlab\n');
fprintf('function g_clipped = clipGradientGlobalNorm(g, theta)\n');
fprintf('    grad_norm = norm(g(:));  %% L2 norm of all gradients\n');
fprintf('    if grad_norm > theta\n');
fprintf('        g_clipped = g * (theta / grad_norm);\n');
fprintf('    else\n');
fprintf('        g_clipped = g;\n');
fprintf('    end\n');
fprintf('end\n');
fprintf('```\n\n');

fprintf('CLIP BY VALUE:\n');
fprintf('```matlab\n');
fprintf('function g_clipped = clipGradientByValue(g, theta)\n');
fprintf('    g_clipped = max(min(g, theta), -theta);\n');
fprintf('end\n');
fprintf('```\n\n');

fprintf('ADAPTIVE CLIPPING (Automatic Threshold):\n');
fprintf('```matlab\n');
fprintf('function [g_clipped, theta] = adaptiveClipping(g, history, percentile)\n');
fprintf('    %% Update gradient norm history\n');
fprintf('    history = [history; norm(g(:))];\n');
fprintf('    \n');
fprintf('    %% Set threshold at specified percentile\n');
fprintf('    theta = prctile(history, percentile);  %% e.g., 95th percentile\n');
fprintf('    \n');
fprintf('    %% Clip by global norm\n');
fprintf('    g_clipped = clipGradientGlobalNorm(g, theta);\n');
fprintf('end\n');
fprintf('```\n\n');

%% Part (f): Impact on Training Dynamics

epochs_analysis = 1:100;

% Gradient norms with different strategies
gradNorm_noClip_sim = min(0.5 * exp(0.05 * epochs_analysis), 1000);
gradNorm_clipNorm5 = min(gradNorm_noClip_sim, 5);
gradNorm_clipNorm10 = min(gradNorm_noClip_sim, 10);
gradNorm_adaptive = min(gradNorm_noClip_sim, 3 + 0.05 * epochs_analysis);

% Training loss curves
loss_noClip = 4.5 - 0.03 * epochs_analysis;
loss_noClip(gradNorm_noClip_sim > 50) = NaN;  % Diverges

loss_clipNorm5 = 4.5 - 0.025 * epochs_analysis + 0.2 * exp(-epochs_analysis/20);
loss_clipNorm10 = 4.5 - 0.028 * epochs_analysis + 0.15 * exp(-epochs_analysis/25);
loss_adaptive = 4.5 - 0.030 * epochs_analysis + 0.1 * exp(-epochs_analysis/30);

fprintf('========================================\n');
fprintf('(f) Training Dynamics Analysis\n');
fprintf('========================================\n\n');

fprintf('CONVERGENCE COMPARISON (at epoch 50):\n');
fprintf('  No clipping: %s\n', ...
        isnan(loss_noClip(50))  'DIVERGED' : sprintf('Loss = %.3f', loss_noClip(50)));
fprintf('  Clip norm  =5: Loss = %.3f\n', loss_clipNorm5(50));
fprintf('  Clip norm  =10: Loss = %.3f\n', loss_clipNorm10(50));
fprintf('  Adaptive clip: Loss = %.3f (best)\n\n', loss_adaptive(50));

fprintf('GRADIENT STATISTICS (epoch 50):\n');
fprintf('  No clipping: norm = %.1f (unstable)\n', gradNorm_noClip_sim(50));
fprintf('  Clip norm  =5: norm = %.1f (conservative)\n', gradNorm_clipNorm5(50));
fprintf('  Clip norm  =10: norm = %.1f (balanced)\n', gradNorm_clipNorm10(50));
fprintf('  Adaptive: norm = %.1f (optimized)\n\n', gradNorm_adaptive(50));

%% Part (g): Alternative Mitigation Strategies

alternatives = {'Gradient Clipping', 'Batch Normalization', ...
                'Layer Normalization', 'Residual Connections', ...
                'LSTM/GRU Gates', 'Careful Init (Xavier)', ...
                'Gradient Noise Injection'};

effectiveness_explosion = [95, 85, 90, 80, 88, 70, 65];  % % prevention
effectiveness_vanishing = [20, 90, 85, 95, 92, 75, 30];
implementationComplexity = [1, 3, 2, 2, 4, 1, 2];  % 1=easy, 5=hard
computationalOverhead = [0, 5, 3, 0, 10, 0, 2];  % % increase

fprintf('========================================\n');
fprintf('(g) Alternative Mitigation Strategies\n');
fprintf('========================================\n');
fprintf('%-25s %-20s %-20s %-18s %-15s\n', 'Strategy', 'vs Explosion (%%)', ...
        'vs Vanishing (%%)', 'Complexity (1-5)', 'Overhead (%)');
fprintf('%s\n', repmat('-', 1, 103));

for i = 1:length(alternatives)
    fprintf('%-25s %-20.0f %-20.0f %-18d %-15.0f\n', ...
            alternatives{i}, effectiveness_explosion(i), ...
            effectiveness_vanishing(i), implementationComplexity(i), ...
            computationalOverhead(i));
end
fprintf('\n');

fprintf('RECOMMENDATION MATRIX:\n');
fprintf('  For RNNs: Gradient Clipping + LSTM/GRU gates\n');
fprintf('  For Feedforward: Batch/Layer Norm + Residual Connections\n');
fprintf('  For Transformers: Layer Norm + Careful Init\n');
fprintf('  Universal: Always monitor gradient norms during training\n\n');

%% Visualization

figure('Position', [50, 50, 1800, 1000], 'Color', 'w');

% Panel 1: Gradient Explosion Without Clipping
subplot(2, 4, 1);
semilogy(epochs, gradNorm_noClipping, 'r-', 'LineWidth', 2.5);
hold on;
yline(10, 'g-', 'LineWidth', 2, 'Label', 'Explosion Threshold', ...
      'Interpreter', 'latex');

xlabel('Training Epoch', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Gradient Norm (log scale)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(a) Gradient Explosion}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 2: Clipping Methods Comparison
subplot(2, 4, 2);
bar(finalAccuracy(2:end), 'FaceColor', [0.3, 0.6, 0.8], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);

ylabel('Final Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(b) Clipping Methods}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', clippingMethods(2:end), 'FontSize', 10, ...
         'XTickLabelRotation', 20);
grid on; box on;
ylim([60, 85]);

% Panel 3: Threshold Sensitivity
subplot(2, 4, 3);
yyaxis left
plot(thresholds(1:end-1), thresholdAccuracy(1:end-1), 'b-o', ...
     'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', 'b');
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);

yyaxis right
plot(thresholds(1:end-1), thresholdConvergence(1:end-1), 'r-s', ...
     'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', 'r');
ylabel('Convergence (epoch)', 'Interpreter', 'latex', 'FontSize', 13);

xlabel('Clipping Threshold $\theta$', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(c) Threshold Tuning}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XScale', 'log');
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 4: Sequence Length Impact
subplot(2, 4, 4);
semilogy(sequenceLengths, gradGrowthFactor, 'b-o', 'LineWidth', 2.5, ...
         'MarkerSize', 10, 'MarkerFaceColor', 'b');
hold on;
plot(sequenceLengths, requiredThreshold, 'r-', 'LineWidth', 2.5);

xlabel('Sequence Length', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Gradient Growth / Req. Threshold', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(d) Sequence Length Effect}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend({'Growth Factor', 'Required $\theta$'}, 'Interpreter', 'latex', ...
       'Location', 'northwest', 'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 5: Gradient Norms Over Training
subplot(2, 4, 5);
plot(epochs_analysis, gradNorm_noClip_sim, 'r-', 'LineWidth', 2, ...
     'DisplayName', 'No Clipping');
hold on;
plot(epochs_analysis, gradNorm_clipNorm5, 'b-', 'LineWidth', 2, ...
     'DisplayName', '$\theta=5$');
plot(epochs_analysis, gradNorm_clipNorm10, 'g-', 'LineWidth', 2, ...
     'DisplayName', '$\theta=10$');
plot(epochs_analysis, gradNorm_adaptive, 'm-', 'LineWidth', 2, ...
     'DisplayName', 'Adaptive');

xlabel('Epoch', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Gradient Norm', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(e) Gradient Control}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend('Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 11);
set(gca, 'YScale', 'log');
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 6: Training Loss Curves
subplot(2, 4, 6);
plot(epochs_analysis, loss_noClip, 'r-', 'LineWidth', 2, ...
     'DisplayName', 'No Clipping');
hold on;
plot(epochs_analysis, loss_clipNorm5, 'b-', 'LineWidth', 2, ...
     'DisplayName', '$\theta=5$');
plot(epochs_analysis, loss_clipNorm10, 'g-', 'LineWidth', 2, ...
     'DisplayName', '$\theta=10$');
plot(epochs_analysis, loss_adaptive, 'm-', 'LineWidth', 2, ...
     'DisplayName', 'Adaptive');

xlabel('Epoch', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Training Loss', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(f) Loss Convergence}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend('Interpreter', 'latex', 'Location', 'northeast', 'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 7: Alternative Strategies (Explosion)
subplot(2, 4, 7);
barh(effectiveness_explosion, 'FaceColor', [0.8, 0.4, 0.2], ...
     'EdgeColor', 'k', 'LineWidth', 1.5);

xlabel('Effectiveness vs Explosion (\%)', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(g) Mitigation Strategies}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'YTickLabel', alternatives, 'FontSize', 10);
grid on; box on;
xlim([0, 100]);

% Panel 8: Complexity-Effectiveness Trade-off
subplot(2, 4, 8);
scatter(implementationComplexity, effectiveness_explosion, 250, ...
        computationalOverhead, 'filled', 'MarkerEdgeColor', 'k');
colorbar;
colormap('jet');

xlabel('Implementation Complexity (1-5)', 'Interpreter', 'latex', ...
       'FontSize', 13);
ylabel('Effectiveness (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(h) Complexity vs Effectiveness}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

fprintf('Analysis complete! Gradient clipping prevents training instability.\n\n');
