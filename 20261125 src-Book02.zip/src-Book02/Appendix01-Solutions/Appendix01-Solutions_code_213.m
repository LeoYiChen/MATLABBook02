%% Appendix01-Solutions_code_213.m
% Ensemble Learning for Particle Mass Prediction
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import cauchy
from sklearn.model_selection import train_test_split, cross_val_predict
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import StackingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import pandas as pd

# ============================================================================
# Physics Event Generation
# ============================================================================
class ZBosonDecaySimulator:
    """Simulate Z boson decay to lepton pairs with detector effects"""
    
    def __init__(self, M_Z=91.2, Gamma_Z=2.5, resolution_factor=0.1):
        self.M_Z = M_Z          # Z boson mass (GeV)
        self.Gamma_Z = Gamma_Z  # Decay width (GeV)
        self.resolution_factor = resolution_factor
        
    def generate_events(self, n_signal, n_background):
        """Generate signal and background events"""
        # Signal: Z -> l+l-
        signal_events = self._generate_signal(n_signal)
        signal_events['label'] = 1
        
        # Background: Drell-Yan continuum
        background_events = self._generate_background(n_background)
        background_events['label'] = 0
        
        # Combine datasets
        all_events = pd.concat([signal_events, background_events], 
                               ignore_index=True)
        
        # Shuffle
        all_events = all_events.sample(frac=1.0, 
                                       random_state=42).reset_index(drop=True)
        
        return all_events
    
    def _generate_signal(self, n_events):
        """Generate Z boson signal events"""
        events = []
        
        for _ in range(n_events):
            # Sample Z mass from Breit-Wigner distribution
            M_parent = cauchy.rvs(loc=self.M_Z, scale=self.Gamma_Z/2)
            M_parent = np.clip(M_parent, 70, 110)  # Physical constraints
            
            # Z momentum in lab frame (random)
            p_Z = np.random.uniform(0, 50)  # GeV
            theta_Z = np.random.uniform(0, np.pi)
            phi_Z = np.random.uniform(-np.pi, np.pi)
            
            # Z four-momentum
            E_Z = np.sqrt(M_parent**2 + p_Z**2)
            p_Zx = p_Z * np.sin(theta_Z) * np.cos(phi_Z)
            p_Zy = p_Z * np.sin(theta_Z) * np.sin(phi_Z)
            p_Zz = p_Z * np.cos(theta_Z)
            
            # Decay in Z rest frame (isotropic)
            cos_theta_star = np.random.uniform(-1, 1)
            phi_star = np.random.uniform(-np.pi, np.pi)
            
            # Lepton momentum in Z rest frame
            p_star = M_parent / 2.0  # Massless leptons approximation
            
            px_star = p_star * np.sqrt(1 - cos_theta_star**2) * np.cos(phi_star)
            py_star = p_star * np.sqrt(1 - cos_theta_star**2) * np.sin(phi_star)
            pz_star = p_star * cos_theta_star
            E_star = p_star
            
            # Boost to lab frame
            beta = p_Z / E_Z
            gamma = E_Z / M_parent
            
            # Lepton 1 (forward in Z rest frame)
            E1 = gamma * (E_star + beta * pz_star)
            p1z = gamma * (pz_star + beta * E_star)
            p1x = px_star
            p1y = py_star
            
            # Lepton 2 (backward in Z rest frame)
            E2 = gamma * (E_star - beta * pz_star)
            p2z = gamma * (-pz_star - beta * E_star)
            p2x = -px_star
            p2y = -py_star
            
            # Apply detector resolution
            E1, p1x, p1y, p1z = self._apply_resolution(E1, p1x, p1y, p1z)
            E2, p2x, p2y, p2z = self._apply_resolution(E2, p2x, p2y, p2z)
            
            # Compute kinematic variables
            event = self._compute_features(E1, p1x, p1y, p1z, 
                                           E2, p2x, p2y, p2z)
            events.append(event)
        
        return pd.DataFrame(events)
    
    def _generate_background(self, n_events):
        """Generate Drell-Yan background events"""
        events = []
        
        for _ in range(n_events):
            # Sample dilepton mass from falling spectrum
            M_ll = np.random.uniform(60, 120)
            
            # Similar kinematics to signal but different mass distribution
            # (simplified model)
            
            # Random lepton momenta
            E1 = np.random.uniform(20, 80)
            E2 = np.random.uniform(20, 80)
            
            theta1 = np.random.uniform(0, np.pi)
            phi1 = np.random.uniform(-np.pi, np.pi)
            theta2 = np.random.uniform(0, np.pi)
            phi2 = np.random.uniform(-np.pi, np.pi)
            
            p1 = np.sqrt(E1**2)  # Massless approximation
            p1x = p1 * np.sin(theta1) * np.cos(phi1)
            p1y = p1 * np.sin(theta1) * np.sin(phi1)
            p1z = p1 * np.cos(theta1)
            
            p2 = np.sqrt(E2**2)
            p2x = p2 * np.sin(theta2) * np.cos(phi2)
            p2y = p2 * np.sin(theta2) * np.sin(phi2)
            p2z = p2 * np.cos(theta2)
            
            # Apply detector resolution
            E1, p1x, p1y, p1z = self._apply_resolution(E1, p1x, p1y, p1z)
            E2, p2x, p2y, p2z = self._apply_resolution(E2, p2x, p2y, p2z)
            
            event = self._compute_features(E1, p1x, p1y, p1z, 
                                           E2, p2x, p2y, p2z)
            events.append(event)
        
        return pd.DataFrame(events)
    
    def _apply_resolution(self, E, px, py, pz):
        """Apply detector energy/momentum resolution"""
        # Energy resolution: sigma_E / E = resolution_factor / sqrt(E)
        sigma_E = self.resolution_factor * np.sqrt(E)
        E_measured = E + np.random.normal(0, sigma_E)
        
        # Momentum smearing (simplified)
        p_total = np.sqrt(px**2 + py**2 + pz**2)
        sigma_p = self.resolution_factor * np.sqrt(p_total)
        
        px_measured = px + np.random.normal(0, sigma_p)
        py_measured = py + np.random.normal(0, sigma_p)
        pz_measured = pz + np.random.normal(0, sigma_p)
        
        return E_measured, px_measured, py_measured, pz_measured
    
    def _compute_features(self, E1, p1x, p1y, p1z, E2, p2x, p2y, p2z):
        """Extract physics features from four-momenta"""
        # Transverse momentum
        pT1 = np.sqrt(p1x**2 + p1y**2)
        pT2 = np.sqrt(p2x**2 + p2y**2)
        
        # Total momentum
        p1 = np.sqrt(p1x**2 + p1y**2 + p1z**2)
        p2 = np.sqrt(p2x**2 + p2y**2 + p2z**2)
        
        # Pseudorapidity
        theta1 = np.arccos(p1z / (p1 + 1e-10))
        theta2 = np.arccos(p2z / (p2 + 1e-10))
        eta1 = -np.log(np.tan(theta1 / 2.0 + 1e-10))
        eta2 = -np.log(np.tan(theta2 / 2.0 + 1e-10))
        
        # Azimuthal angle
        phi1 = np.arctan2(p1y, p1x)
        phi2 = np.arctan2(p2y, p2x)
        
        # Invariant mass (target variable)
        M_ll = np.sqrt((E1 + E2)**2 - (p1x + p2x)**2 - 
                       (p1y + p2y)**2 - (p1z + p2z)**2)
        
        # Angular separation
        delta_eta = eta1 - eta2
        delta_phi = phi1 - phi2
        # Wrap phi to [-pi, pi]
        delta_phi = np.arctan2(np.sin(delta_phi), np.cos(delta_phi))
        delta_R = np.sqrt(delta_eta**2 + delta_phi**2)
        
        return {
            'pT1': pT1,
            'pT2': pT2,
            'eta1': eta1,
            'eta2': eta2,
            'phi1': phi1,
            'phi2': phi2,
            'E1': E1,
            'E2': E2,
            'delta_R': delta_R,
            'M_ll': M_ll
        }

# ============================================================================
# Generate Dataset
# ============================================================================
print("="*70)
print("GENERATING PARTICLE PHYSICS DATASET")
print("="*70)

simulator = ZBosonDecaySimulator(M_Z=91.2, Gamma_Z=2.5, resolution_factor=0.1)

# Generate events
n_signal = 1500
n_background = 500
data = simulator.generate_events(n_signal, n_background)

print(f"\nDataset Statistics:")
print(f"  Signal events: {n_signal}")
print(f"  Background events: {n_background}")
print(f"  Total events: {len(data)}")
print(f"\nFeatures: {list(data.columns[:-2])}")  # Exclude M_ll and label
print(f"Target: M_ll (invariant mass)")

# Separate features and target
feature_cols = ['pT1', 'pT2', 'eta1', 'eta2', 'phi1', 'phi2', 'E1', 'E2']
X = data[feature_cols].values
y = data['M_ll'].values

# Train-validation-test split
X_temp, X_test, y_temp, y_test = train_test_split(
    X, y, test_size=0.15, random_state=42
)
X_train, X_val, y_train, y_val = train_test_split(
    X_temp, y_temp, test_size=0.176, random_state=42  # 0.176 * 0.85   0.15
)

print(f"\nData Splits:")
print(f"  Training: {len(X_train)} events")
print(f"  Validation: {len(X_val)} events")
print(f"  Test: {len(X_test)} events")

# Feature scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)
X_test_scaled = scaler.transform(X_test)

# ============================================================================
# Base Model Training
# ============================================================================
print("\n" + "="*70)
print("TRAINING BASE MODELS")
print("="*70)

# Model 1: Linear Regression
print("\n[1/3] Training Linear Regression...")
lr_model = LinearRegression()
lr_model.fit(X_train_scaled, y_train)
lr_train_pred = lr_model.predict(X_train_scaled)
lr_val_pred = lr_model.predict(X_val_scaled)
lr_test_pred = lr_model.predict(X_test_scaled)

lr_train_mae = mean_absolute_error(y_train, lr_train_pred)
lr_val_mae = mean_absolute_error(y_val, lr_val_pred)
lr_test_mae = mean_absolute_error(y_test, lr_test_pred)

print(f"  Train MAE: {lr_train_mae:.3f} GeV")
print(f"  Val MAE:   {lr_val_mae:.3f} GeV")
print(f"  Test MAE:  {lr_test_mae:.3f} GeV")

# Model 2: Decision Tree
print("\n[2/3] Training Decision Tree Regressor...")
dt_model = DecisionTreeRegressor(max_depth=10, min_samples_split=20, 
                                  random_state=42)
dt_model.fit(X_train_scaled, y_train)
dt_train_pred = dt_model.predict(X_train_scaled)
dt_val_pred = dt_model.predict(X_val_scaled)
dt_test_pred = dt_model.predict(X_test_scaled)

dt_train_mae = mean_absolute_error(y_train, dt_train_pred)
dt_val_mae = mean_absolute_error(y_val, dt_val_pred)
dt_test_mae = mean_absolute_error(y_test, dt_test_pred)

print(f"  Train MAE: {dt_train_mae:.3f} GeV")
print(f"  Val MAE:   {dt_val_mae:.3f} GeV")
print(f"  Test MAE:  {dt_test_mae:.3f} GeV")

# Model 3: Neural Network
print("\n[3/3] Training Neural Network...")
nn_model = MLPRegressor(hidden_layer_sizes=(50, 50), 
                        activation='relu',
                        solver='adam',
                        max_iter=500,
                        random_state=42,
                        early_stopping=True,
                        validation_fraction=0.1,
                        alpha=0.001)  # L2 regularization

nn_model.fit(X_train_scaled, y_train)
nn_train_pred = nn_model.predict(X_train_scaled)
nn_val_pred = nn_model.predict(X_val_scaled)
nn_test_pred = nn_model.predict(X_test_scaled)

nn_train_mae = mean_absolute_error(y_train, nn_train_pred)
nn_val_mae = mean_absolute_error(y_val, nn_val_pred)
nn_test_mae = mean_absolute_error(y_test, nn_test_pred)

print(f"  Train MAE: {nn_train_mae:.3f} GeV")
print(f"  Val MAE:   {nn_val_mae:.3f} GeV")
print(f"  Test MAE:  {nn_test_mae:.3f} GeV")

# ============================================================================
# Stacking Ensemble
# ============================================================================
print("\n" + "="*70)
print("TRAINING STACKING ENSEMBLE")
print("="*70)

# Define base estimators
base_estimators = [
    ('linear_regression', LinearRegression()),
    ('decision_tree', DecisionTreeRegressor(max_depth=10, 
                                            min_samples_split=20,
                                            random_state=42)),
    ('neural_network', MLPRegressor(hidden_layer_sizes=(50, 50),
                                    max_iter=500,
                                    random_state=42,
                                    early_stopping=True))
]

# Meta-learner
meta_learner = LinearRegression()

# Create stacking regressor
stacking_model = StackingRegressor(
    estimators=base_estimators,
    final_estimator=meta_learner,
    cv=5  # 5-fold cross-validation for out-of-fold predictions
)

print("\nTraining stacking ensemble with 5-fold CV...")
stacking_model.fit(X_train_scaled, y_train)

# Predictions
stack_train_pred = stacking_model.predict(X_train_scaled)
stack_val_pred = stacking_model.predict(X_val_scaled)
stack_test_pred = stacking_model.predict(X_test_scaled)

# Metrics
stack_train_mae = mean_absolute_error(y_train, stack_train_pred)
stack_train_mse = mean_squared_error(y_train, stack_train_pred)
stack_train_r2 = r2_score(y_train, stack_train_pred)

stack_val_mae = mean_absolute_error(y_val, stack_val_pred)
stack_val_mse = mean_squared_error(y_val, stack_val_pred)
stack_val_r2 = r2_score(y_val, stack_val_pred)

stack_test_mae = mean_absolute_error(y_test, stack_test_pred)
stack_test_mse = mean_squared_error(y_test, stack_test_pred)
stack_test_r2 = r2_score(y_test, stack_test_pred)

print(f"\nStacking Ensemble Performance:")
print(f"  Train MAE: {stack_train_mae:.3f} GeV | MSE: {stack_train_mse:.3f} | R: {stack_train_r2:.4f}")
print(f"  Val MAE:   {stack_val_mae:.3f} GeV | MSE: {stack_val_mse:.3f} | R: {stack_val_r2:.4f}")
print(f"  Test MAE:  {stack_test_mae:.3f} GeV | MSE: {stack_test_mse:.3f} | R: {stack_test_r2:.4f}")

# ============================================================================
# Feature Importance Analysis
# ============================================================================
print("\n" + "="*70)
print("FEATURE IMPORTANCE ANALYSIS")
print("="*70)

# Extract feature importances from decision tree
dt_importances = dt_model.feature_importances_
feature_names = feature_cols

print("\nDecision Tree Feature Importances:")
for name, importance in zip(feature_names, dt_importances):
    print(f"  {name:8s}: {importance:.4f}")

# Linear regression coefficients
lr_coefs = lr_model.coef_
print("\nLinear Regression Coefficients:")
for name, coef in zip(feature_names, lr_coefs):
    print(f"  {name:8s}: {coef:+.4f}")

# ============================================================================
# Visualization
# ============================================================================
print("\n" + "="*70)
print("GENERATING VISUALIZATIONS")
print("="*70)

fig = plt.figure(figsize=(18, 12))

# Plot 1: Model Comparison - Test Set Performance
ax1 = plt.subplot(3, 3, 1)
models = ['Linear\nRegression', 'Decision\nTree', 'Neural\nNetwork', 
          'Stacking\nEnsemble']
test_maes = [lr_test_mae, dt_test_mae, nn_test_mae, stack_test_mae]
colors = ['skyblue', 'lightcoral', 'lightgreen', 'gold']

bars = ax1.bar(models, test_maes, color=colors, edgecolor='black', linewidth=1.5)
ax1.set_ylabel('Mean Absolute Error (GeV)', fontsize=11)
ax1.set_title('Test Set Performance Comparison', fontsize=13, fontweight='bold')
ax1.grid(True, alpha=0.3, axis='y')

# Add value labels on bars
for bar, mae in zip(bars, test_maes):
    height = bar.get_height()
    ax1.text(bar.get_x() + bar.get_width()/2., height,
            f'{mae:.3f}', ha='center', va='bottom', fontweight='bold')

# Plot 2: Predicted vs True (Stacking Ensemble)
ax2 = plt.subplot(3, 3, 2)
ax2.scatter(y_test, stack_test_pred, alpha=0.5, s=30, edgecolors='k', linewidth=0.5)
ax2.plot([60, 120], [60, 120], 'r-', linewidth=2, label='Perfect Prediction')
ax2.set_xlabel('True Mass (GeV)', fontsize=11)
ax2.set_ylabel('Predicted Mass (GeV)', fontsize=11)
ax2.set_title('Stacking Ensemble: Predicted vs True', fontsize=13, fontweight='bold')
ax2.legend()
ax2.grid(True, alpha=0.3)
ax2.text(0.05, 0.95, f'$R^2$ = {stack_test_r2:.4f}\nMAE = {stack_test_mae:.3f} GeV',
        transform=ax2.transAxes, fontsize=10, verticalalignment='top',
        bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

# Plot 3: Residual Distribution (Stacking)
ax3 = plt.subplot(3, 3, 3)
residuals = y_test - stack_test_pred
ax3.hist(residuals, bins=30, color='purple', alpha=0.7, edgecolor='black')
ax3.axvline(0, color='red', linestyle='-', linewidth=2, label='Zero Error')
ax3.set_xlabel('Residual (GeV)', fontsize=11)
ax3.set_ylabel('Frequency', fontsize=11)
ax3.set_title('Residual Distribution (Stacking)', fontsize=13, fontweight='bold')
ax3.legend()
ax3.grid(True, alpha=0.3, axis='y')
ax3.text(0.05, 0.95, f'Mean: {np.mean(residuals):.3f}\nStd: {np.std(residuals):.3f}',
        transform=ax3.transAxes, fontsize=10, verticalalignment='top',
        bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.8))

# Plot 4: Individual Model Predictions (Sample)
ax4 = plt.subplot(3, 3, 4)
sample_indices = np.argsort(y_test)[:50]  # First 50 sorted by true mass
x_axis = np.arange(len(sample_indices))

ax4.plot(x_axis, y_test[sample_indices], 'ko-', label='True Mass', 
        linewidth=2, markersize=4)
ax4.plot(x_axis, lr_test_pred[sample_indices], 's-', label='Linear Reg', 
        alpha=0.7, markersize=3)
ax4.plot(x_axis, dt_test_pred[sample_indices], '^-', label='Decision Tree', 
        alpha=0.7, markersize=3)
ax4.plot(x_axis, nn_test_pred[sample_indices], 'v-', label='Neural Net', 
        alpha=0.7, markersize=3)
ax4.plot(x_axis, stack_test_pred[sample_indices], 'd-', label='Stacking', 
        alpha=0.9, markersize=3, linewidth=2)

ax4.set_xlabel('Sample Index', fontsize=11)
ax4.set_ylabel('Mass (GeV)', fontsize=11)
ax4.set_title('Individual Predictions (50 Samples)', fontsize=13, fontweight='bold')
ax4.legend(fontsize=9, loc='upper left')
ax4.grid(True, alpha=0.3)

# Plot 5: Feature Importance (Decision Tree)
ax5 = plt.subplot(3, 3, 5)
sorted_idx = np.argsort(dt_importances)
ax5.barh(np.array(feature_names)[sorted_idx], dt_importances[sorted_idx], 
        color='teal', edgecolor='black')
ax5.set_xlabel('Importance', fontsize=11)
ax5.set_title('Feature Importances (Decision Tree)', fontsize=13, fontweight='bold')
ax5.grid(True, alpha=0.3, axis='x')

# Plot 6: Reconstructed Mass Distribution
ax6 = plt.subplot(3, 3, 6)
ax6.hist(y_test, bins=40, alpha=0.5, label='True Mass', 
        color='blue', edgecolor='black')
ax6.hist(stack_test_pred, bins=40, alpha=0.5, label='Predicted Mass (Stacking)', 
        color='red', edgecolor='black')
ax6.axvline(91.2, color='green', linestyle='-', linewidth=2, label='$M_Z$ = 91.2 GeV')
ax6.set_xlabel('Invariant Mass (GeV)', fontsize=11)
ax6.set_ylabel('Frequency', fontsize=11)
ax6.set_title('Reconstructed Mass Distribution', fontsize=13, fontweight='bold')
ax6.legend(fontsize=9)
ax6.grid(True, alpha=0.3, axis='y')

# Plot 7: Error vs True Mass
ax7 = plt.subplot(3, 3, 7)
abs_errors = np.abs(residuals)
ax7.scatter(y_test, abs_errors, alpha=0.6, s=30, edgecolors='k', linewidth=0.5)
ax7.set_xlabel('True Mass (GeV)', fontsize=11)
ax7.set_ylabel('Absolute Error (GeV)', fontsize=11)
ax7.set_title('Error vs True Mass', fontsize=13, fontweight='bold')
ax7.axhline(stack_test_mae, color='r', linestyle='-', linewidth=2, 
           label=f'Mean = {stack_test_mae:.3f}')
ax7.legend()
ax7.grid(True, alpha=0.3)

# Plot 8: Learning Curves (Neural Network)
ax8 = plt.subplot(3, 3, 8)
if hasattr(nn_model, 'loss_curve_'):
    ax8.plot(nn_model.loss_curve_, linewidth=2, color='navy')
    ax8.set_xlabel('Iteration', fontsize=11)
    ax8.set_ylabel('Loss', fontsize=11)
    ax8.set_title('Neural Network Training Loss', fontsize=13, fontweight='bold')
    ax8.grid(True, alpha=0.3)
    ax8.set_yscale('log')
else:
    ax8.text(0.5, 0.5, 'Loss curve not available', 
            ha='center', va='center', transform=ax8.transAxes)

# Plot 9: Model Comparison Table
ax9 = plt.subplot(3, 3, 9)
ax9.axis('tight')
ax9.axis('off')

comparison_data = [
    ['Model', 'Test MAE', 'Test MSE', 'Test R'],
    ['Linear Regression', f'{lr_test_mae:.3f}', 
     f'{mean_squared_error(y_test, lr_test_pred):.3f}',
     f'{r2_score(y_test, lr_test_pred):.4f}'],
    ['Decision Tree', f'{dt_test_mae:.3f}',
     f'{mean_squared_error(y_test, dt_test_pred):.3f}',
     f'{r2_score(y_test, dt_test_pred):.4f}'],
    ['Neural Network', f'{nn_test_mae:.3f}',
     f'{mean_squared_error(y_test, nn_test_pred):.3f}',
     f'{r2_score(y_test, nn_test_pred):.4f}'],
    ['Stacking Ensemble', f'{stack_test_mae:.3f}',
     f'{stack_test_mse:.3f}', f'{stack_test_r2:.4f}']
]

table = ax9.table(cellText=comparison_data, cellLoc='center', loc='center',
                 colWidths=[0.35, 0.22, 0.22, 0.21])
table.auto_set_font_size(False)
table.set_fontsize(9)
table.scale(1, 2)

# Style header row
for i in range(4):
    table[(0, i)].set_facecolor('#4CAF50')
    table[(0, i)].set_text_props(weight='bold', color='white')

# Highlight best ensemble
for i in range(4):
    table[(4, i)].set_facecolor('#FFD700')
    table[(4, i)].set_text_props(weight='bold')

ax9.set_title('Performance Summary', fontsize=13, fontweight='bold', pad=20)

plt.tight_layout()
plt.savefig('ensemble_particle_mass_results.png', dpi=300, bbox_inches='tight')
plt.show()

print("\nVisualization saved as 'ensemble_particle_mass_results.png'")

# ============================================================================
# Final Performance Summary
# ============================================================================
print("\n" + "="*70)
print("FINAL PERFORMANCE SUMMARY")
print("="*70)

print(f"\nTest Set Results:")
print(f"{'Model':<20} {'MAE (GeV)':<12} {'MSE (GeV)':<12} {'R':<8}")
print("-" * 52)
print(f"{'Linear Regression':<20} {lr_test_mae:<12.3f} {mean_squared_error(y_test, lr_test_pred):<12.3f} {r2_score(y_test, lr_test_pred):<8.4f}")
print(f"{'Decision Tree':<20} {dt_test_mae:<12.3f} {mean_squared_error(y_test, dt_test_pred):<12.3f} {r2_score(y_test, dt_test_pred):<8.4f}")
print(f"{'Neural Network':<20} {nn_test_mae:<12.3f} {mean_squared_error(y_test, nn_test_pred):<12.3f} {r2_score(y_test, nn_test_pred):<8.4f}")
print(f"{'Stacking Ensemble':<20} {stack_test_mae:<12.3f} {stack_test_mse:<12.3f} {stack_test_r2:<8.4f}")

# Improvement over best individual model
best_individual_mae = min(lr_test_mae, dt_test_mae, nn_test_mae)
improvement = ((best_individual_mae - stack_test_mae) / best_individual_mae) * 100

print(f"\n Ensemble improves over best individual model by {improvement:.2f}%")
print(f" Mass resolution: {stack_test_mae:.3f} GeV ({stack_test_mae/91.2*100:.2f}% of $M_Z$)")
