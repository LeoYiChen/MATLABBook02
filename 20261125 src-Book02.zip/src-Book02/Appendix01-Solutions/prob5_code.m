%% prob5_code.m
% Polar plots and radar charts for anisotropic material characterisation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob5_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Polar Plots: Anisotropic Composite Strength Analysis
% File: MATLABBook02_Chapter07_Problem05.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Analyses directional strength data using polar plots,
%              radar charts, and theoretical model fitting
% =========================================================================

function MATLABBook02_Chapter07_Problem05()
    % Main function for Problem 5: Polar Plots and Radar Charts
    
    clc; clear; close all;
    
    % Define test angles (degrees)
    theta_deg = (0:15:345)';
    theta_rad = deg2rad(theta_deg);
    
    % Generate anisotropic strength data
    [strength, materialParams] = generateAnisotropicStrengthData(theta_rad);
    
    % Fit Tsai-Hill theoretical model
    fittedStrength = fitTsaiHillModel(theta_rad, materialParams);
    
    % Create polar visualisations
    createPolarStrengthPlots(theta_rad, strength, fittedStrength, materialParams);
    
    % Generate radar charts for material comparison
    createMaterialComparisonRadarChart();
    
    % Create rose diagram for failure orientation distribution
    createRoseDiagramFailureAnalysis(theta_rad, strength);
    
    % Quantify anisotropy
    quantifyAnisotropy(strength, theta_deg, materialParams);
end

function [strength, params] = generateAnisotropicStrengthData(theta)
    % GENERATEANISOTROPICSTRENGTHDATA - Creates realistic composite strength data
    %
    % Inputs:
    %   theta - Orientation angles (radians)
    %
    % Outputs:
    %   strength - Measured tensile strength (MPa)
    %   params - Material property structure
    
    rng(321);
    
    % Material properties for unidirectional carbon/epoxy
    params.sigma_11 = 1500;  % Longitudinal tensile strength (MPa)
    params.sigma_22 = 50;    % Transverse tensile strength (MPa)
    params.tau_12 = 75;      % In-plane shear strength (MPa)
    
    % Tsai-Hill failure criterion for off-axis loading
    % 1/sigma_theta^2 = cos^4( )/sigma_11^2 + sin^4( )/sigma_22^2 + 
    %                   (1/tau_12^2 - 1/sigma_11^2)*sin^2( )*cos^2( )
    
    cos_theta = cos(theta);
    sin_theta = sin(theta);
    
    sigma_theta_inv_sq = (cos_theta.^4) / params.sigma_11^2 + ...
                         (sin_theta.^4) / params.sigma_22^2 + ...
                         (1/params.tau_12^2 - 1/params.sigma_11^2) * ...
                         (sin_theta.^2) .* (cos_theta.^2);
    
    strength_theoretical = 1 ./ sqrt(sigma_theta_inv_sq);
    
    % Add realistic measurement noise ( 5% coefficient of variation)
    noise = 0.05 * strength_theoretical .* randn(size(theta));
    strength = strength_theoretical + noise;
    
    % Ensure non-negative values
    strength = max(strength, 10);
end

function strength_fit = fitTsaiHillModel(theta, params)
    % FITTSAIHILLMODEL - Computes theoretical Tsai-Hill predictions
    
    cos_theta = cos(theta);
    sin_theta = sin(theta);
    
    sigma_theta_inv_sq = (cos_theta.^4) / params.sigma_11^2 + ...
                         (sin_theta.^4) / params.sigma_22^2 + ...
                         (1/params.tau_12^2 - 1/params.sigma_11^2) * ...
                         (sin_theta.^2) .* (cos_theta.^2);
    
    strength_fit = 1 ./ sqrt(sigma_theta_inv_sq);
end

function createPolarStrengthPlots(theta, strength, fittedStrength, params)
    % CREATEPOLARSTRENGTHPLOTS - Generates comprehensive polar visualisations
    
    figure('Name', 'Polar Plots: Anisotropic Strength', ...
           'Position', [50, 50, 1400, 600]);
    
    % Subplot 1: Experimental data with fitted model
    subplot(1, 2, 1, polaraxes);
    
    % Plot experimental data points
    polarplot(theta, strength, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', ...
             'DisplayName', 'Experimental Data');
    hold on;
    
    % Plot fitted Tsai-Hill model
    theta_fine = linspace(0, 2*pi, 200);
    strength_fine = fitTsaiHillModel(theta_fine, params);
    polarplot(theta_fine, strength_fine, 'b-', 'LineWidth', 2.5, ...
             'DisplayName', 'Tsai-Hill Model');
    
    % Highlight principal directions
    polarplot([0, pi], [params.sigma_11, params.sigma_11], 'g-', ...
             'LineWidth', 2, 'DisplayName', '$\sigma_{11}$ direction');
    polarplot([pi/2, 3*pi/2], [params.sigma_22, params.sigma_22], 'm-', ...
             'LineWidth', 2, 'DisplayName', '$\sigma_{22}$ direction');
    
    rlim([0, max(strength)*1.1]);
    thetaticks(0:30:330);
    title('Off-Axis Strength: Experimental vs. Theoretical', ...
          'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold');
    legend('Location', 'southoutside', 'Interpreter', 'latex', 'FontSize', 9);
    set(gca, 'FontSize', 10);
    hold off;
    
    % Subplot 2: Normalised polar plot
    subplot(1, 2, 2, polaraxes);
    
    % Normalise by maximum strength
    strength_norm = strength / max(strength);
    strength_fine_norm = strength_fine / max(strength_fine);
    
    polarplot(theta, strength_norm, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
    hold on;
    polarplot(theta_fine, strength_fine_norm, 'r-', 'LineWidth', 2.5);
    
    % Add reference circles
    theta_circle = linspace(0, 2*pi, 100);
    for r_ref = [0.2, 0.4, 0.6, 0.8, 1.0]
        polarplot(theta_circle, r_ref*ones(size(theta_circle)), 'k:', ...
                 'LineWidth', 0.5, 'HandleVisibility', 'off');
    end
    
    rlim([0, 1.1]);
    thetaticks(0:30:330);
    title('Normalised Strength Distribution', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    set(gca, 'FontSize', 10);
    hold off;
end

function createMaterialComparisonRadarChart()
    % CREATEMATERIALCOMPARISONRADARCHART - Compares multiple materials
    
    % Define properties for comparison
    propertyNames = {'Tensile Strength', 'Compressive Strength', ...
                    'Shear Strength', 'Stiffness', 'Toughness', ...
                    'Density', 'Cost', 'Machinability'};
    
    numProperties = length(propertyNames);
    theta_radar = linspace(0, 2*pi, numProperties + 1);
    
    % Material property values (normalised 0-1 scale)
    % Material 1: High-performance carbon/epoxy
    material1 = [0.95, 0.85, 0.75, 0.90, 0.60, 0.40, 0.30, 0.45];
    material1 = [material1, material1(1)]; % Close polygon
    
    % Material 2: Glass/epoxy (cost-effective)
    material2 = [0.60, 0.65, 0.55, 0.65, 0.70, 0.65, 0.85, 0.75];
    material2 = [material2, material2(1)];
    
    % Material 3: Aramid/epoxy (impact-resistant)
    material3 = [0.75, 0.55, 0.60, 0.70, 0.90, 0.55, 0.50, 0.60];
    material3 = [material3, material3(1)];
    
    figure('Name', 'Radar Chart: Material Comparison', ...
           'Position', [100, 100, 800, 800]);
    
    ax = polaraxes;
    
    % Plot materials
    polarplot(theta_radar, material1, 'r-o', 'LineWidth', 2.5, ...
             'MarkerSize', 8, 'MarkerFaceColor', 'r', ...
             'DisplayName', 'Carbon/Epoxy');
    hold on;
    polarplot(theta_radar, material2, 'b-s', 'LineWidth', 2.5, ...
             'MarkerSize', 8, 'MarkerFaceColor', 'b', ...
             'DisplayName', 'Glass/Epoxy');
    polarplot(theta_radar, material3, 'g-^', 'LineWidth', 2.5, ...
             'MarkerSize', 8, 'MarkerFaceColor', 'g', ...
             'DisplayName', 'Aramid/Epoxy');
    
    % Customise appearance
    rlim([0, 1]);
    thetaticks(rad2deg(theta_radar(1:end-1)));
    thetaticklabels(propertyNames);
    
    title('Material Property Comparison Radar Chart', 'Interpreter', 'latex', ...
          'FontSize', 13, 'FontWeight', 'bold');
    legend('Location', 'southoutside', 'Orientation', 'horizontal', ...
          'Interpreter', 'latex', 'FontSize', 10);
    
    set(gca, 'FontSize', 9, 'LineWidth', 1.2);
    grid on;
    hold off;
end

function createRoseDiagramFailureAnalysis(theta, strength)
    % CREATEROSEDIAGRAMFAILUREANALYSIS - Shows failure orientation distribution
    
    % Simulate failure orientations weighted by inverse strength
    % (weaker directions fail more frequently)
    rng(654);
    
    failure_probability = 1 ./ strength;
    failure_probability = failure_probability / sum(failure_probability);
    
    % Generate random failure orientations based on probability distribution
    numFailures = 500;
    failure_angles = randsample(theta, numFailures, true, failure_probability);
    
    figure('Name', 'Rose Diagram: Failure Orientation Analysis', ...
           'Position', [150, 150, 700, 700]);
    
    % Create rose diagram with 24 bins
    polarhistogram(failure_angles, 24, 'FaceColor', [0.8, 0.3, 0.3], ...
                  'EdgeColor', 'k', 'FaceAlpha', 0.7);
    
    title('Rose Diagram: Failure Orientation Distribution', ...
          'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    
    % Add interpretation text
    annotation('textbox', [0.15, 0.02, 0.7, 0.08], 'String', ...
              ['Higher frequency indicates orientations more susceptible to failure. ', ...
               'Peak near 90  confirms transverse weakness in unidirectional composite.'], ...
              'Interpreter', 'latex', 'FontSize', 9, 'EdgeColor', 'none');
end

function quantifyAnisotropy(strength, theta_deg, params)
    % QUANTIFYANISOTROPY - Calculates anisotropy metrics
    
    fprintf('\n========================================\n');
    fprintf('   ANISOTROPY QUANTIFICATION\n');
    fprintf('========================================\n');
    
    % Find maximum and minimum strengths
    [max_strength, max_idx] = max(strength);
    [min_strength, min_idx] = min(strength);
    
    max_orientation = theta_deg(max_idx);
    min_orientation = theta_deg(min_idx);
    
    % Anisotropy ratio
    anisotropy_ratio = max_strength / min_strength;
    
    % Planar anisotropy index: (max - min) / (max + min)
    planar_anisotropy = (max_strength - min_strength) / ...
                       (max_strength + min_strength);
    
    fprintf('Maximum Strength: %.2f MPa at   = %.0f \n', ...
           max_strength, max_orientation);
    fprintf('Minimum Strength: %.2f MPa at   = %.0f \n', ...
           min_strength, min_orientation);
    fprintf('Anisotropy Ratio: %.2f\n', anisotropy_ratio);
    fprintf('Planar Anisotropy Index: %.4f\n', planar_anisotropy);
    
    fprintf('\n=== Principal Material Strengths ===\n');
    fprintf('Longitudinal (0 ):  %.0f MPa\n', params.sigma_11);
    fprintf('Transverse (90 ):   %.0f MPa\n', params.sigma_22);
    fprintf('Shear:              %.0f MPa\n', params.tau_12);
    
    fprintf('\n=== Design Recommendations ===\n');
    if anisotropy_ratio > 10
        fprintf('HIGHLY ANISOTROPIC material\n');
        fprintf('Critical: Load alignment with fibres (0  5 ) for optimal performance\n');
    elseif anisotropy_ratio > 3
        fprintf('MODERATELY ANISOTROPIC material\n');
        fprintf('Important: Consider fibre orientation in design\n');
    else
        fprintf('QUASI-ISOTROPIC material\n');
        fprintf('Orientation less critical\n');
    end
end
