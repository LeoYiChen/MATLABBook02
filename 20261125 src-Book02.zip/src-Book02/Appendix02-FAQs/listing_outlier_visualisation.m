%% listing_outlier_visualisation.m
% Comprehensive outlier visualisation toolkit.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : listing_outlier_visualisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function visualiseOutlierDetection(original_data, outlier_indices, method_name, detection_stats)
% visualiseOutlierDetection - Create comprehensive outlier analysis plots
%
% Inputs:
%   original_data   - Original dataset
%   outlier_indices - Logical array marking outliers
%   method_name     - String describing detection method
%   detection_stats - Statistics structure from detection function

    % Create comprehensive figure
    figure('Position', [100, 100, 1400, 900]);
    
    % Subplot 1: Box plot with outliers highlighted
    subplot(2, 4, 1);
    boxplot(original_data, 'Symbol', 'r+');
    hold on;
    outlier_data = original_data(outlier_indices);
    if ~isempty(outlier_data)
        scatter(ones(size(outlier_data)), outlier_data, 50, 'r', 'filled', 'DisplayName', 'Detected Outliers');
    end
    title(sprintf('Box Plot: %s Method', method_name));
    ylabel('Data Values');
    legend('show');
    grid on;
    
    % Subplot 2: Histogram with outliers highlighted
    subplot(2, 4, 2);
    histogram(original_data, 'Normalization', 'probability', 'FaceAlpha', 0.7, 'DisplayName', 'All Data');
    hold on;
    if ~isempty(outlier_data)
        histogram(outlier_data, 'Normalization', 'probability', 'FaceColor', 'red', 'FaceAlpha', 0.8, 'DisplayName', 'Outliers');
    end
    title('Data Distribution');
    xlabel('Value');
    ylabel('Probability');
    legend('show');
    grid on;
    
    % Subplot 3: Scatter plot with indices
    subplot(2, 4, 3);
    scatter(1:length(original_data), original_data, 30, 'b', 'filled', 'DisplayName', 'Normal Points');
    hold on;
    if any(outlier_indices)
        scatter(find(outlier_indices), original_data(outlier_indices), 50, 'r', 'filled', 'DisplayName', 'Outliers');
    end
    title('Data Points by Index');
    xlabel('Data Point Index');
    ylabel('Value');
    legend('show');
    grid on;
    
    % Subplot 4: Q-Q plot
    subplot(2, 4, 4);
    qqplot(original_data);
    title('Normal Q-Q Plot');
    grid on;
    
    % Subplot 5: Detection method specific plot
    subplot(2, 4, 5);
    switch lower(method_name)
        case 'iqr'
            if isfield(detection_stats, 'Q1')
                y_line = [detection_stats.lower_fence, detection_stats.Q1, median(original_data), detection_stats.Q3, detection_stats.upper_fence];
                x_line = 1:5;
                plot(x_line, y_line, 'ro-', 'LineWidth', 2, 'MarkerSize', 8);
                set(gca, 'XTick', x_line, 'XTickLabel', {'Lower Fence', 'Q1', 'Median', 'Q3', 'Upper Fence'});
                title('IQR Fence Analysis');
                ylabel('Value');
                grid on;
            end
            
        case 'zscore'
            if isfield(detection_stats, 'mean_used')
                z_scores = abs(original_data - detection_stats.mean_used) ./ detection_stats.std_used;
                scatter(1:length(z_scores), z_scores, 30, 'b', 'filled');
                hold on;
                yline(detection_stats.threshold_used, 'r--', 'LineWidth', 2, 'DisplayName', 'Threshold');
                if any(outlier_indices)
                    scatter(find(outlier_indices), z_scores(outlier_indices), 50, 'r', 'filled');
                end
                title('Z-Score Analysis');
                xlabel('Data Point Index');
                ylabel('|Z-Score|');
                legend('show');
                grid on;
            end
    end
    
    % Subplot 6: Before/After comparison
    subplot(2, 4, 6);
    cleaned_data = original_data(~outlier_indices);
    boxplot([original_data, [cleaned_data; NaN(sum(outlier_indices), 1)]], 'Labels', {'Original', 'Cleaned'});
    title('Before/After Comparison');
    ylabel('Value');
    grid on;
    
    % Subplot 7: Statistical summary
    subplot(2, 4, 7);
    axis off;
    summary_text = {
        sprintf('Method: %s', method_name),
        sprintf('Original Size: %d', detection_stats.original_size),
        sprintf('Outliers Detected: %d', detection_stats.outliers_detected),
        sprintf('Outlier Percentage: %.2f%%', detection_stats.outlier_percentage),
        sprintf('Remaining Data: %d', detection_stats.original_size - detection_stats.outliers_detected)
    };
    
    if isfield(detection_stats, 'threshold_used')
        summary_text{end+1} = sprintf('Threshold: %.2f', detection_stats.threshold_used);
    end
    
    text(0.1, 0.8, summary_text, 'FontSize', 10, 'VerticalAlignment', 'top', 'FontWeight', 'bold');
    title('Detection Summary');
    
    % Subplot 8: Outlier impact on statistics
    subplot(2, 4, 8);
    original_stats = [mean(original_data), median(original_data), std(original_data)];
    cleaned_stats = [mean(cleaned_data), median(cleaned_data), std(cleaned_data)];
    
    x_positions = 1:3;
    bar_width = 0.35;
    bar(x_positions - bar_width/2, original_stats, bar_width, 'DisplayName', 'Original');
    hold on;
    bar(x_positions + bar_width/2, cleaned_stats, bar_width, 'DisplayName', 'Cleaned');
    
    set(gca, 'XTick', x_positions, 'XTickLabel', {'Mean', 'Median', 'Std Dev'});
    title('Statistical Impact');
    ylabel('Value');
    legend('show');
    grid on;
    
    % Overall title
    sgtitle(sprintf('Comprehensive Outlier Analysis: %s Method', method_name), 'FontSize', 14, 'FontWeight', 'bold');
end
