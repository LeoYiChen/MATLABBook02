%% chapter_Combinatorics_example_basics.m
% Fundamental combinatorial calculations in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Combinatorics_example_basics
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateCombinatorialBasics();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateCombinatorialBasics()
    % DEMONSTRATECOMBINATORIALBASICS Fundamental permutations and combinations
    %   Illustrates basic combinatorial calculations and their applications
    
    fprintf('Fundamental Combinatorial Mathematics\n');
    fprintf('======================================\n\n');
    
    %% Historical Context
    fprintf('HISTORICAL BACKGROUND\n');
    fprintf('-----\n\n');
    
    fprintf(['Pascal and Fermat (1654): Founded probability theory through\n', ...
        'combinatorial analysis of gambling problems.\n\n', ...
        'Bernoulli (1713): "Ars Conjectandi" established combinatorics\n', ...
        'as a mathematical discipline.\n\n']);
    
    %% Factorial Calculations
    fprintf('FACTORIAL CALCULATIONS\n');
    fprintf('-----\n\n');
    
    fprintf('The factorial function n! = n $\times$ (n-1) $\times$ (n-2) $\times$ ... $\times$ 2 $\times$ 1\n');
    fprintf('represents the number of ways to arrange n distinct objects.\n\n');
    
    test_values = [0, 1, 5, 10, 15, 20];
    
    fprintf('%-10*s  %-25*s\n', 'n', 'n!');
    fprintf('%s\n', repmat('-', 1, 40));
    
    for n = test_values
        if n <= 20
            fact_value = factorial(n);
            fprintf('%-10*d  %-25.0*f\n', n, fact_value);
        end
    end
    fprintf('\n');
    
    fprintf('Note: factorial(0) = 1 by convention (empty product).\n');
    fprintf('Factorials grow extremely rapidly: 20! ≈ 2.43 $\times$ 10^18\n\n');
    
    %% Permutation Calculations
    fprintf('PERMUTATION CALCULATIONS\n');
    fprintf('----\n\n');
    
    fprintf('P(n,r) = n!/(n-r)! counts ordered arrangements.\n\n');
    
    fprintf('Example: Arranging 3 books from a shelf of 10:\n');
    n = 10;
    r = 3;
    perm_count = factorial(n) / factorial(n - r);
    fprintf('  P(%d,%d) = %d!/%d! = %.0f arrangements\n\n', ...
        n, r, n, n-r, perm_count);
    
    fprintf('Generating all permutations of a small set:\n');
    small_set = [1, 2, 3];
    all_perms = perms(small_set);
    
    fprintf('  Set: [%s]\n', num2str(small_set));
    fprintf('  Number of permutations: %d\n', size(all_perms, 1));
    fprintf('  All permutations:\n');
    
    for i = 1:size(all_perms, 1)
        fprintf('    [%s]\n', num2str(all_perms(i, :)));
    end
    fprintf('\n');
    
    %% Combination Calculations
    fprintf('COMBINATION CALCULATIONS\n');
    fprintf('----\n\n');
    
    fprintf('C(n,r) = n!/(r!(n-r)!) counts unordered selections.\n\n');
    
    fprintf('Example: Selecting 3 books from a shelf of 10:\n');
    comb_count = nchoosek(n, r);
    fprintf('  C(%d,%d) = %.0f selections\n\n', n, r, comb_count);
    
    fprintf('Generating all combinations of a small set:\n');
    small_set_comb = [1, 2, 3, 4];
    k = 2;
    all_combs = nchoosek(small_set_comb, k);
    
    fprintf('  Set: [%s]\n', num2str(small_set_comb));
    fprintf('  Selecting %d elements\n', k);
    fprintf('  Number of combinations: %d\n', size(all_combs, 1));
    fprintf('  All combinations:\n');
    
    for i = 1:size(all_combs, 1)
        fprintf('    [%s]\n', num2str(all_combs(i, :)));
    end
    fprintf('\n');
    
    %% Relationship Between Permutations and Combinations
    fprintf('PERMUTATIONS VS COMBINATIONS\n');
    fprintf('------\n\n');
    
    fprintf('For selecting r objects from n:\n');
    fprintf('  P(n,r) = C(n,r) $\times$ r!\n');
    fprintf('  (permutations = combinations $\times$ arrangements of selection)\n\n');
    
    n_demo = 5;
    r_demo = 3;
    
    perm_demo = factorial(n_demo) / factorial(n_demo - r_demo);
    comb_demo = nchoosek(n_demo, r_demo);
    
    fprintf('Example with n=%d, r=%d:\n', n_demo, r_demo);
    fprintf('  P(%d,%d) = %.0f\n', n_demo, r_demo, perm_demo);
    fprintf('  C(%d,%d) = %.0f\n', n_demo, r_demo, comb_demo);
    fprintf('  Verification: C(%d,%d) $\times$ %d! = %.0f $\times$ %.0f = %.0f\n\n', ...
        n_demo, r_demo, r_demo, comb_demo, factorial(r_demo), ...
        comb_demo * factorial(r_demo));
    
    %% Poker Hand Probability
    fprintf('APPLICATION: POKER HAND PROBABILITIES\n');
    fprintf('-------\n\n');
    
    deck_size = 52;
    hand_size = 5;
    
    total_hands = nchoosek(deck_size, hand_size);
    fprintf('Total possible 5-card poker hands: %s\n\n', ...
        addCommasToNumber(total_hands));
    
    % Royal flush: 4 possible (one per suit)
    royal_flush_count = 4;
    royal_flush_prob = royal_flush_count / total_hands;
    
    fprintf('Royal Flush (A-K-Q-J-10 of same suit):\n');
    fprintf('  Count: %d\n', royal_flush_count);
    fprintf('  Probability: %.10f\n', royal_flush_prob);
    fprintf('  Odds: 1 in %s\n\n', addCommasToNumber(round(1/royal_flush_prob)));
    
    % Straight flush (excluding royal): 36 possible
    straight_flush_count = 36;
    straight_flush_prob = straight_flush_count / total_hands;
    
    fprintf('Straight Flush (5 consecutive cards, same suit, not royal):\n');
    fprintf('  Count: %d\n', straight_flush_count);
    fprintf('  Probability: %.8f\n', straight_flush_prob);
    fprintf('  Odds: 1 in %s\n\n', addCommasToNumber(round(1/straight_flush_prob)));
    
    % Four of a kind: C(13,1) $\times$ C(48,1) = 624
    four_kind_count = 624;
    four_kind_prob = four_kind_count / total_hands;
    
    fprintf('Four of a Kind:\n');
    fprintf('  Count: %d\n', four_kind_count);
    fprintf('  Probability: %.6f\n', four_kind_prob);
    fprintf('  Odds: 1 in %s\n\n', addCommasToNumber(round(1/four_kind_prob)));
    
    %% Lottery Probability
    fprintf('APPLICATION: LOTTERY PROBABILITIES\n');
    fprintf('-------\n\n');
    
    fprintf('UK National Lottery (6 numbers from 59):\n');
    lottery_total = 59;
    lottery_pick = 6;
    
    lottery_combinations = nchoosek(lottery_total, lottery_pick);
    lottery_prob = 1 / lottery_combinations;
    
    fprintf('  Total combinations: %s\n', addCommasToNumber(lottery_combinations));
    fprintf('  Probability of jackpot: %.12f\n', lottery_prob);
    fprintf('  Odds: 1 in %s\n\n', addCommasToNumber(lottery_combinations));
    
    fprintf('Comparison with being struck by lightning in a year:\n');
    fprintf('  Lightning strike odds: approximately 1 in 700,000\n');
    fprintf('  You are %.1f times more likely to be struck by lightning\n', ...
        lottery_combinations / 700000);
    fprintf('  than to win the lottery jackpot.\n\n');
    
    %% Birthday Paradox
    fprintf('APPLICATION: BIRTHDAY PARADOX\n');
    fprintf('-----\n\n');
    
    fprintf(['The birthday paradox asks: In a group of people, what is\n', ...
        'the probability that at least two share the same birthday?\n\n']);
    
    people_counts = [10, 20, 23, 30, 40, 50, 70];
    
    fprintf('%-15*s  %-25*s\n', 'Group Size', 'Probability of Match');
    fprintf('%s\n', repmat('-', 1, 45));
    
    for num_people = people_counts
        prob_no_match = 1;
        for i = 1:(num_people - 1)
            prob_no_match = prob_no_match * (365 - i) / 365;
        end
        prob_match = 1 - prob_no_match;
        
        fprintf('%-15*d  %24.2*f%%\n', num_people, prob_match * 100);
    end
    
    fprintf('\nRemarkably, with just 23 people, the probability exceeds 50%%.\n');
    fprintf('With 70 people, the probability exceeds 99.9%%.\n\n');
    
    %% Visualisation
    visualiseCombinatorialGrowth();
    visualiseBirthdayParadox();
    visualisePokerProbabilities();
end

function str = addCommasToNumber(num)
    % Add thousand separators to numbers for readability
    str = num2str(num);
    k = length(str);
    result = '';
    counter = 0;
    
    for i = k:-1:1
        result = [str(i), result];
        counter = counter + 1;
        if counter == 3 && i > 1
            result = [',' result];
            counter = 0;
        end
    end
    str = result;
end

function visualiseCombinatorialGrowth()
    % Visualise rapid growth of factorials and combinatorial functions
    
    figure('Position', [100, 100, 1400, 500]);
    
    % Factorial growth
    subplot(1, 3, 1);
    n_vals = 0:20;
    fact_vals = arrayfun(@(n) factorial(n), n_vals);
    
    semilogy(n_vals, fact_vals, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
    xlabel('n');
    ylabel('n! (log scale)');
    title('Factorial Growth');
    grid on;
    
    % Permutation growth for different r values
    subplot(1, 3, 2);
    n_range = 1:15;
    r_values = [2, 5, 10];
    
    hold on;
    for r = r_values
        perm_vals = arrayfun(@(n) computePermutation(n, r), n_range);
        plot(n_range, perm_vals, '-o', 'LineWidth', 2, ...
            'DisplayName', sprintf('r = %d', r));
    end
    
    xlabel('n');
    ylabel('P(n,r)');
    title('Permutation Growth P(n,r)');
    legend('Location', 'northwest');
    grid on;
    
    % Combination growth
    subplot(1, 3, 3);
    n_fixed = 20;
    r_range = 0:n_fixed;
    comb_vals = arrayfun(@(r) nchoosek(n_fixed, r), r_range);
    
    plot(r_range, comb_vals, 'r-o', 'LineWidth', 2, 'MarkerSize', 6);
    xlabel('r');
    ylabel(sprintf('C(%d,r)', n_fixed));
    title(sprintf('Binomial Coefficients C(%d,r)', n_fixed));
    grid on;
end

function result = computePermutation(n, r)
    % Safely compute permutation avoiding overflow
    if r > n
        result = 0;
    else
        result = factorial(n) / factorial(n - r);
    end
end

function visualiseBirthdayParadox()
    % Visualise birthday paradox probabilities
    
    figure('Position', [100, 100, 700, 500]);
    
    group_sizes = 1:100;
    probabilities = zeros(size(group_sizes));
    
    for num_people = group_sizes
        prob_no_match = 1;
        for i = 1:(num_people - 1)
            prob_no_match = prob_no_match * (365 - i) / 365;
        end
        probabilities(num_people) = 1 - prob_no_match;
    end
    
    plot(group_sizes, probabilities * 100, 'b-', 'LineWidth', 2);
    hold on;
    yline(50, 'r-', '50% threshold', 'LineWidth', 1.5);
    xline(23, 'g-', '23 people', 'LineWidth', 1.5);
    
    xlabel('Group Size');
    ylabel('Probability of Shared Birthday (%)');
    title('Birthday Paradox: Probability vs Group Size');
    grid on;
    xlim([0, 100]);
    ylim([0, 100]);
end

function visualisePokerProbabilities()
    % Visualise poker hand probabilities
    
    figure('Position', [100, 100, 800, 600]);
    
    hand_names = {'Royal Flush', 'Straight Flush', 'Four of Kind', ...
        'Full House', 'Flush', 'Straight', 'Three of Kind', ...
        'Two Pair', 'One Pair', 'High Card'};
    
    hand_counts = [4, 36, 624, 3744, 5108, 10200, 54912, ...
        123552, 1098240, 1302540];
    
    total_hands = 2598960;
    probabilities = hand_counts / total_hands * 100;
    
    barh(probabilities);
    set(gca, 'YTick', 1:length(hand_names));
    set(gca, 'YTickLabel', hand_names);
    xlabel('Probability (%)');
    title('Poker Hand Probabilities (5-card hands)');
    grid on;
end
