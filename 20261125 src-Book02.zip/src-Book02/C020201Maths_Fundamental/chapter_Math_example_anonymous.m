%% chapter_Math_example_anonymous.m
% Anonymous function examples.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_anonymous
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define anonymous function for squaring
square = @(x) x.^2;

% Define anonymous function for quadratic formula
quadratic = @(a, b, c, x) a*x.^2 + b*x + c;

% Define anonymous function for Gaussian
gaussian = @(x, mu, sigma) (1/(sigma*sqrt(2*pi))) * ...
    exp(-((x-mu).^2)/(2*sigma^2));

% Use anonymous functions
y1 = square([1 2 3 4]);              % Returns [1 4 9 16]
y2 = quadratic(2, -3, 1, 5);         % Evaluates 2*5^2 - 3*5 + 1
x = linspace(-3, 3, 100);
y3 = gaussian(x, 0, 1);              % Standard normal distribution
