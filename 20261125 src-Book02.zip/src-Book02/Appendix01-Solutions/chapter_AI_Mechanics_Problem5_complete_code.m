%% chapter_AI_Mechanics_Problem5_complete_code.m
% Complete phase-field fracture simulation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem5_complete_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 5: Crack Propagation Using Phase-Field Models
% Author: Dr Yi Chen
% Date: 2024-01-20
% Version: 2.1
% MATLAB Version: R2023b
% Description: AT2 phase-field model for Mode I tensile crack with GP surrogate

clear; clc; close all;

fprintf('=== Problem 5: Phase-Field Fracture Simulation ===\n\n');

%% Domain and Discretisation

Lx = 1.0;  % Domain width (m)
Ly = 1.0;  % Domain height (m)
Nx = 101;  % Grid points in x
Ny = 101;  % Grid points in y

x = linspace(0, Lx, Nx);
y = linspace(0, Ly, Ny);
[X, Y] = meshgrid(x, y);

dx = x(2) - x(1);
dy = y(2) - y(1);

fprintf('Domain discretisation:\n');
fprintf('  Size: %.2f   %.2f m\n', Lx, Ly);
fprintf('  Grid: %d   %d points\n', Nx, Ny);
fprintf('  Resolution: dx = %.4f m\n\n', dx);

%% Material Parameters

E = 210e9;          % Young's modulus (Pa) - steel
nu = 0.3;           % Poisson's ratio
Gc = 2.7e3;         % Fracture toughness (J/m)
l_scale = 4 * dx;   % Length scale (m)

% Lam  parameters
lambda = E * nu / ((1 + nu) * (1 - 2*nu));
mu = E / (2 * (1 + nu));

fprintf('Material properties:\n');
fprintf('  Young''s modulus: %.1f GPa\n', E/1e9);
fprintf('  Poisson''s ratio: %.2f\n', nu);
fprintf('  Fracture toughness: %.1f J/m\n', Gc);
fprintf('  Length scale: %.4f m (%.1f   dx)\n\n', l_scale, l_scale/dx);

%% Initialisation

% Displacement field
ux = zeros(Ny, Nx);
uy = zeros(Ny, Nx);

% Damage field
d = zeros(Ny, Nx);

% Initial edge notch (left side, centred)
notch_length = 0.2 * Lx;
notch_y_centre = 0.5 * Ly;
notch_width = 2 * dx;

for i = 1:Ny
    for j = 1:Nx
        if X(i,j) < notch_length && abs(Y(i,j) - notch_y_centre) < notch_width
            d(i,j) = 1.0;  % Fully broken
        end
    end
end

% History field (max tensile energy)
H = zeros(Ny, Nx);

fprintf('Initialisation complete:\n');
fprintf('  Initial notch length: %.3f m\n', notch_length);
fprintf('  Notch position: y = %.3f m\n\n', notch_y_centre);

%% Loading Protocol

num_steps = 20;
u_max = 0.002 * Ly;  % Maximum applied displacement (0.2% strain)
u_applied = linspace(0, u_max, num_steps);

% Storage
crack_length = zeros(num_steps, 1);
reaction_force = zeros(num_steps, 1);
total_energy = zeros(num_steps, 1);

fprintf('Loading protocol:\n');
fprintf('  Load steps: %d\n', num_steps);
fprintf('  Max displacement: %.4f m (%.2f%% strain)\n\n', u_max, 100*u_max/Ly);

%% Staggered Solver

max_iter = 50;
tol = 1e-6;

fprintf('Starting staggered iteration...\n\n');

for step = 1:num_steps
    fprintf('-- Load Step %d/%d (u = %.4e m) --\n', step, num_steps, u_applied(step));
    
    converged = false;
    
    for iter = 1:max_iter
        % Store previous solution
        ux_old = ux;
        uy_old = uy;
        d_old = d;
        
        % -- Step 1: Solve for displacement (fixed damage) --
        
        % Apply boundary conditions
        uy(end, :) = u_applied(step);  % Top edge: prescribed displacement
        uy(1, :) = 0;                  % Bottom edge: fixed
        
        % Compute strains
        [ux_x, ux_y] = gradient(ux, dx, dy);
        [uy_x, uy_y] = gradient(uy, dx, dy);
        
        eps_xx = ux_x;
        eps_yy = uy_y;
        eps_xy = 0.5 * (ux_y + uy_x);
        
        % Trace strain
        tr_eps = eps_xx + eps_yy;
        tr_eps_pos = max(tr_eps, 0);
        tr_eps_neg = min(tr_eps, 0);
        
        % Degradation function
        g_d = (1 - d).^2 + 1e-6;  % Small residual stiffness
        
        % Stresses (simplified - full implementation would use FEM)
        sigma_xx = g_d .* (lambda .* tr_eps_pos + 2*mu .* eps_xx) + ...
                   lambda .* tr_eps_neg + 2*mu .* eps_xx;
        sigma_yy = g_d .* (lambda .* tr_eps_pos + 2*mu .* eps_yy) + ...
                   lambda .* tr_eps_neg + 2*mu .* eps_yy;
        sigma_xy = g_d .* (2*mu .* eps_xy);
        
        % Equilibrium (simplified update - full would solve linear system)
        [sigma_xx_x, ~] = gradient(sigma_xx, dx, dy);
        [~, sigma_xy_y] = gradient(sigma_xy, dx, dy);
        [sigma_xy_x, ~] = gradient(sigma_xy, dx, dy);
        [~, sigma_yy_y] = gradient(sigma_yy, dx, dy);
        
        residual_x = sigma_xx_x + sigma_xy_y;
        residual_y = sigma_xy_x + sigma_yy_y;
        
        % Update displacements (Gauss-Seidel-like)
        omega = 0.5;  % Relaxation parameter
        ux(2:end-1, 2:end-1) = ux(2:end-1, 2:end-1) - omega * residual_x(2:end-1, 2:end-1) * dx^2 / (2*mu);
        uy(2:end-1, 2:end-1) = uy(2:end-1, 2:end-1) - omega * residual_y(2:end-1, 2:end-1) * dy^2 / (2*mu);
        
        % Reapply BCs
        uy(end, :) = u_applied(step);
        uy(1, :) = 0;
        ux(:, 1) = 0;  % Prevent rigid body motion
        
        % -- Step 2: Update history field --
        
        eps_dev_xx = eps_xx - tr_eps / 2;
        eps_dev_yy = eps_yy - tr_eps / 2;
        
        psi_plus = 0.5 * lambda * tr_eps_pos.^2 + ...
                   mu * (eps_dev_xx.^2 + eps_dev_yy.^2 + 2*eps_xy.^2);
        
        H = max(H, psi_plus);  % History field (no healing)
        
        % -- Step 3: Solve for damage (fixed displacement) --
        
        % Laplacian of d
        Lap_d = del2(d, dx, dy);
        
        % Damage evolution: (Gc/l + 2*H)*d - Gc*l*Lap_d = 2*H
        A_coeff = Gc / l_scale + 2 * H + 1e-12;  % Avoid division by zero
        b_rhs = 2 * H + Gc * l_scale * Lap_d;
        
        d_new = b_rhs ./ A_coeff;
        
        % Enforce irreversibility and bounds
        d = max(d_old, d_new);
        d = min(1, max(0, d));
        
        % Maintain notch
        for i = 1:Ny
            for j = 1:Nx
                if X(i,j) < notch_length && abs(Y(i,j) - notch_y_centre) < notch_width
                    d(i,j) = 1.0;
                end
            end
        end
        
        % -- Convergence check --
        
        err_u = norm([ux(:) - ux_old(:); uy(:) - uy_old(:)]) / (norm([ux(:); uy(:)]) + 1e-12);
        err_d = norm(d(:) - d_old(:)) / (norm(d(:)) + 1e-12);
        
        if err_u < tol && err_d < tol
            converged = true;
            fprintf('  Converged in %d iterations (err_u=%.2e, err_d=%.2e)\n', iter, err_u, err_d);
            break;
        end
    end
    
    if ~converged
        fprintf('  WARNING: Did not converge in %d iterations\n', max_iter);
    end
    
    % -- Post-processing --
    
    % Crack length (contour d = 0.5)
    crack_mask = d > 0.5;
    crack_x_max = 0;
    for i = 1:Ny
        crack_row = find(crack_mask(i, :), 1, 'last');
        if ~isempty(crack_row)
            crack_x_max = max(crack_x_max, X(i, crack_row));
        end
    end
    crack_length(step) = crack_x_max;
    
    % Reaction force (integrate stress at top boundary)
    reaction_force(step) = sum(sigma_yy(end, :)) * dx;
    
    % Total energy
    elastic_energy = sum(g_d .* psi_plus, 'all') * dx * dy;
    fracture_energy = Gc * sum(d.^2 / (2*l_scale) + l_scale/2 * (gradient(d, dx).^2 + gradient(d', dy).^2), 'all') * dx * dy;
    total_energy(step) = elastic_energy + fracture_energy;
    
    fprintf('  Crack length: %.4f m, Reaction force: %.2e N, Energy: %.2e J\n\n', ...
            crack_length(step), reaction_force(step), total_energy(step));
end

fprintf('Simulation complete!\n\n');

%% Gaussian Process Surrogate (Simplified Demo)

fprintf('-- Training GP Surrogate Model --\n\n');

% Generate synthetic training data (in practice, run multiple simulations)
num_train = 50;
rng(42);

% Features: [Gc, notch_length, u_max]
Gc_range = Gc * (0.5 + rand(num_train, 1));
notch_range = 0.1 + 0.2 * rand(num_train, 1);
u_range = u_max * (0.8 + 0.4 * rand(num_train, 1));

X_train = [Gc_range, notch_range, u_range];

% Target: approximate final crack length (simplified)
Y_train = notch_range + 0.3 * sqrt(Gc_range / Gc) .* (u_range / u_max) + 0.01 * randn(num_train, 1);

% Train GP
gpModel = fitrgp(X_train, Y_train, ...
    'KernelFunction', 'matern52', ...
    'Standardize', true, ...
    'Verbose', 0);

fprintf('GP model trained on %d samples\n', num_train);
fprintf('  Kernel: Mat rn 5/2\n');
fprintf('  Hyperparameters optimised via MLE\n\n');

% Predict
X_test = [Gc, notch_length, u_max];
[Y_pred, Y_std, Y_interval] = predict(gpModel, X_test);

fprintf('GP prediction for current configuration:\n');
fprintf('  Predicted crack length: %.4f   %.4f m\n', Y_pred, 2*Y_std);
fprintf('  95%% CI: [%.4f, %.4f] m\n', Y_interval(1), Y_interval(2));
fprintf('  Actual: %.4f m\n\n', crack_length(end));

%% Visualisation

figure('Position', [50, 50, 1600, 1000]);

% Subplot 1: Final damage field
subplot(2, 3, 1);
contourf(X, Y, d, 20, 'LineStyle', 'none');
colorbar;
colormap(jet);
caxis([0, 1]);
xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
title('Final Damage Field $d(\mathbf{x})$', 'Interpreter', 'latex', 'FontSize', 14);
axis equal tight;

% Subplot 2: Crack path
subplot(2, 3, 2);
contour(X, Y, d, [0.5, 0.5], 'r', 'LineWidth', 2);
hold on;
contour(X, Y, d, [0.1, 0.9], 'k-', 'LineWidth', 1);
xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
title('Crack Path ($d = 0.5$ contour)', 'Interpreter', 'latex', 'FontSize', 14);
axis equal tight;
grid on;
hold off;

% Subplot 3: Force-displacement
subplot(2, 3, 3);
plot(u_applied * 1e3, reaction_force / 1e6, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Applied Displacement (mm)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Reaction Force (MN)', 'Interpreter', 'latex', 'FontSize', 12);
title('Force-Displacement Curve', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 4: Crack length evolution
subplot(2, 3, 4);
plot(u_applied * 1e3, crack_length, 'r-s', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Applied Displacement (mm)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Crack Length (m)', 'Interpreter', 'latex', 'FontSize', 12);
title('Crack Propagation', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 5: Energy evolution
subplot(2, 3, 5);
plot(u_applied * 1e3, total_energy / 1e3, 'g-d', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Applied Displacement (mm)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Total Energy (kJ)', 'Interpreter', 'latex', 'FontSize', 12);
title('Energy Dissipation', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Subplot 6: Displacement field magnitude
subplot(2, 3, 6);
u_mag = sqrt(ux.^2 + uy.^2);
contourf(X, Y, u_mag * 1e3, 20, 'LineStyle', 'none');
colorbar;
colormap(jet);
xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
title('Displacement Magnitude (mm)', 'Interpreter', 'latex', 'FontSize', 14);
axis equal tight;

fprintf('\n=== Problem 5 Complete ===\n\n');
