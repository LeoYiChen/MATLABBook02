%% C020201Maths_Fundamental_code_108.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Read grayscale image
imageData = imread('cameraman.tif');
imageDouble = double(imageData);

% Compute 2*D FFT
fftImage = fft2(imageDouble);
fftShifted = fftshift(fftImage);  % Centre zero frequency

% Magnitude spectrum
magnitudeSpectrum = log(1 + abs(fftShifted));

% Design 2*D low-pass filter (circular)
[rows, cols] = size(imageData);
[X, Y] = meshgrid(1:cols, 1:rows);
centreX = cols / 2;
centreY = rows / 2;
radius = 50;

filterMask = sqrt((X - centreX).^2 + (Y - centreY).^2) <= radius;

% Apply filter and reconstruct
filteredFFT = fftShifted .* filterMask;
imageFiltered = real(ifft2(ifftshift(filteredFFT)));
