%% chapter_UQ_example_systemReliability.m
% System reliability analysis: exact Poisson-binomial k-out-of-n reliability, the unified standby formula with limit verification, bridge network pivotal decomposition, competing-risk bathtub hazard, and transient availability.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_UQ_example_systemReliability
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% System reliability: architecture, redundancy, ageing, and availability
%  Requires: base MATLAB, R2016b or later. No toolboxes required.

clearvars; close all; clc;
rng(3, 'twister');

analyseStaticArchitectures();
analyseStandbyRedundancy();
analyseBridgeNetwork();
analyseAgeingAndAvailability();

%% --------- local functions -----------
function analyseStaticArchitectures()

    fprintf('Static architectures\n');
    fprintf('====================\n\n');

    componentReliability = [0.95, 0.98, 0.92, 0.96, 0.99];

    seriesReliability   = prod(componentReliability);
    parallelReliability = 1 - prod(1 - componentReliability);

    fprintf('Component reliabilities: %s\n', ...
        sprintf('%.3f ', componentReliability));
    fprintf('  Series   : %.6f (worse than every component)\n', ...
        seriesReliability);
    fprintf('  Parallel : %.6f (better than every component)\n\n', ...
        parallelReliability);

    % -- Exact k-out-of-n for NON-identical components -------
    % The generating polynomial prod(q_i + p_i z) yields the exact
    % Poisson-binomial pmf; conv performs the multiplication.
    workingCountPmf = poissonBinomialPmf(componentReliability);

    fprintf('Exact k-out-of-5 reliability, non-identical components:\n');
    for requiredWorking = 1:numel(componentReliability)
        atLeastK = sum(workingCountPmf(requiredWorking+1:end));
        fprintf('  %d-out-of-5 : %.6f\n', requiredWorking, atLeastK);
    end

    % Verification against the binomial formula in the identical case
    identicalReliability = 0.95;
    identicalPmf = poissonBinomialPmf(repmat(identicalReliability, 1, 5));
    binomialValue = 0;
    for workingCount = 2:5
        binomialValue = binomialValue + nchoosek(5, workingCount) * ...
            identicalReliability^workingCount * ...
            (1-identicalReliability)^(5-workingCount);
    end
    fprintf('\n  Verification, 2-out-of-5 with identical components:\n');
    fprintf('    Poisson-binomial : %.10f\n', sum(identicalPmf(3:end)));
    fprintf('    Binomial formula : %.10f\n', binomialValue);
    fprintf('    Difference       : %.3e\n\n', ...
        abs(sum(identicalPmf(3:end)) - binomialValue));

    % -- The cost of complexity ---------------
    componentCount = 1:200;
    seriesCurve = 0.99 .^ componentCount;
    fprintf('Series reliability at R = 0.99: n=10 gives %.4f, ', ...
        seriesCurve(10));
    fprintf('n=100 gives %.4f, n=200 gives %.4f\n\n', ...
        seriesCurve(100), seriesCurve(200));

    visualiseStaticArchitectures(componentCount, seriesCurve, ...
        workingCountPmf, componentReliability);
end

function workingCountPmf = poissonBinomialPmf(reliabilities)
    % Exact distribution of the number of working components.
    workingCountPmf = 1;
    for componentIndex = 1:numel(reliabilities)
        workingCountPmf = conv(workingCountPmf, ...
            [1 - reliabilities(componentIndex), ...
             reliabilities(componentIndex)]);
    end
end

function analyseStandbyRedundancy()

    fprintf('Standby redundancy: one formula, three classical cases\n');
    fprintf('=====================================================\n\n');

    failureRate  = 1e-3;      % per hour
    missionTime  = 100;       % hours
    dormantRates = [1e-9, 0.25*failureRate, 0.5*failureRate, failureRate];

    singleUnit     = exp(-failureRate*missionTime);
    coldStandby    = exp(-failureRate*missionTime) * ...
        (1 + failureRate*missionTime);
    activeParallel = 1 - (1 - singleUnit)^2;

    fprintf('Mission time %.0f h, active failure rate %.1e per hour\n\n', ...
        missionTime, failureRate);
    fprintf('%-28s %12s %10s\n', 'Configuration', 'Reliability', 'Gain');
    fprintf('%-28s %12.6f %10s\n', 'Single unit', singleUnit, '-');
    for rateIndex = 1:numel(dormantRates)
        unifiedValue = unifiedStandbyReliability(failureRate, ...
            dormantRates(rateIndex), missionTime);
        fprintf('Standby, mu_s = %.2e   %12.6f %10.4f\n', ...
            dormantRates(rateIndex), unifiedValue, ...
            unifiedValue/singleUnit);
    end

    fprintf('\nLimit verification of Equation (unified standby):\n');
    coldLimit   = unifiedStandbyReliability(failureRate, 1e-12, missionTime);
    activeLimit = unifiedStandbyReliability(failureRate, failureRate, ...
        missionTime);
    fprintf('  mu_s -> 0 gives %.10f, classical cold standby %.10f\n', ...
        coldLimit, coldStandby);
    fprintf('  mu_s = lambda gives %.10f, active parallel %.10f\n', ...
        activeLimit, activeParallel);
    fprintf('  Residuals: %.3e and %.3e. The unification holds.\n\n', ...
        abs(coldLimit - coldStandby), abs(activeLimit - activeParallel));
end

function reliabilityValue = unifiedStandbyReliability(failureRate, ...
    dormantRate, missionTime)
    % R(t) = exp(-lambda t) * [1 + (lambda/mu_s)(1 - exp(-mu_s t))]
    reliabilityValue = exp(-failureRate*missionTime) .* ...
        (1 + (failureRate ./ dormantRate) .* ...
        (1 - exp(-dormantRate*missionTime)));
end

function analyseBridgeNetwork()

    fprintf('Bridge network: pivotal decomposition versus simulation\n');
    fprintf('======================================================\n\n');

    % Topology: 1 and 2 leave the source, 4 and 5 enter the sink,
    % 3 bridges the two intermediate nodes.
    componentReliability = [0.90, 0.90, 0.95, 0.90, 0.85];

    analyticalValue = bridgeReliabilityExact(componentReliability);
    numTrials = 2e6;
    simulatedValue = bridgeReliabilityMonteCarlo(componentReliability, ...
        numTrials);

    fprintf('Component reliabilities: %s\n', ...
        sprintf('%.2f ', componentReliability));
    fprintf('  Pivotal decomposition : %.6f\n', analyticalValue);
    fprintf('  Monte Carlo (%d)  : %.6f\n', numTrials, simulatedValue);
    fprintf('  Relative difference   : %.3f%%\n', ...
        100*abs(analyticalValue - simulatedValue)/analyticalValue);
    fprintf('  Minimal path sets: {1,4}, {2,5}, {1,3,5}, {2,3,4}\n');
    fprintf('  The bridge contributes only through the last two paths,\n');
    fprintf('  which is why its Birnbaum importance is modest here.\n\n');

    % Importance of the bridge element across its own reliability range
    bridgeRange = linspace(0, 1, 101);
    bridgeCurve = zeros(size(bridgeRange));
    for pointIndex = 1:numel(bridgeRange)
        trialVector = componentReliability;
        trialVector(3) = bridgeRange(pointIndex);
        bridgeCurve(pointIndex) = bridgeReliabilityExact(trialVector);
    end

    visualiseBridgeNetwork(bridgeRange, bridgeCurve, analyticalValue);
end

function systemReliability = bridgeReliabilityExact(R)
    sourceSide = 1 - (1 - R(1))*(1 - R(2));
    sinkSide   = 1 - (1 - R(4))*(1 - R(5));
    bridgeUp   = R(3) * sourceSide * sinkSide;
    bridgeDown = (1 - R(3)) * (1 - (1 - R(1)*R(4))*(1 - R(2)*R(5)));
    systemReliability = bridgeUp + bridgeDown;
end

function systemReliability = bridgeReliabilityMonteCarlo(R, numTrials)
    isWorking = rand(numTrials, 5) < R;
    pathA = isWorking(:,1) & isWorking(:,4);
    pathB = isWorking(:,2) & isWorking(:,5);
    pathC = isWorking(:,1) & isWorking(:,3) & isWorking(:,5);
    pathD = isWorking(:,2) & isWorking(:,3) & isWorking(:,4);
    systemReliability = mean(pathA | pathB | pathC | pathD);
end

function analyseAgeingAndAvailability()

    fprintf('Ageing and availability\n');
    fprintf('=======================\n\n');

    timeGrid = linspace(1, 2000, 800);

    % -- The bathtub curve requires COMPETING RISKS -------
    % A single Weibull has monotone hazard for every shape parameter, so a
    % bathtub must arise from superposed mechanisms.
    infantShape = 0.45;  infantScale = 60;
    randomRate  = 2.0e-4;
    wearShape   = 4.0;   wearScale   = 1200;

    infantHazard = (infantShape/infantScale) * ...
        (timeGrid/infantScale).^(infantShape - 1);
    wearHazard   = (wearShape/wearScale) * ...
        (timeGrid/wearScale).^(wearShape - 1);
    totalHazard  = infantHazard + randomRate + wearHazard;

    cumulativeHazard = cumtrapz(timeGrid, totalHazard);
    systemReliability = exp(-cumulativeHazard);

    [minimumHazard, minimumIndex] = min(totalHazard);
    fprintf('Competing-risk bathtub hazard:\n');
    fprintf('  Hazard minimum %.3e per hour at t = %.0f h\n', ...
        minimumHazard, timeGrid(minimumIndex));
    fprintf('  Reliability at 500 h : %.4f\n', ...
        interp1(timeGrid, systemReliability, 500));
    fprintf('  Reliability at 1500 h: %.4f\n', ...
        interp1(timeGrid, systemReliability, 1500));
    fprintf('  A single Weibull cannot produce this shape, since its\n');
    fprintf('  hazard is monotone for every shape parameter beta.\n\n');

    % -- Availability ------------------
    meanTimeBetweenFailures = 1000;   % hours
    meanTimeToRepair        = 10;     % hours
    failureRate = 1/meanTimeBetweenFailures;
    repairRate  = 1/meanTimeToRepair;
    steadyAvailability = repairRate/(failureRate + repairRate);

    availabilityGrid = steadyAvailability + (1 - steadyAvailability) * ...
        exp(-(failureRate + repairRate)*timeGrid);

    fprintf('Availability with MTBF %.0f h and MTTR %.0f h:\n', ...
        meanTimeBetweenFailures, meanTimeToRepair);
    fprintf('  Steady-state availability : %.6f (%.4f%%)\n', ...
        steadyAvailability, 100*steadyAvailability);
    fprintf('  Expected downtime per year: %.1f hours\n', ...
        8760*(1 - steadyAvailability));
    fprintf('  Halving MTTR to %.0f h raises availability to %.6f,\n', ...
        meanTimeToRepair/2, ...
        (2*repairRate)/(failureRate + 2*repairRate));
    fprintf('  usually far cheaper than doubling the MTBF.\n\n');

    visualiseAgeing(timeGrid, infantHazard, randomRate, wearHazard, ...
        totalHazard, systemReliability, availabilityGrid, ...
        steadyAvailability);
end

function visualiseStaticArchitectures(componentCount, seriesCurve, ...
    workingCountPmf, componentReliability)

    figure('Position', [100, 100, 1300, 400], 'Name', 'Architectures');

    subplot(1, 3, 1);
    semilogy(componentCount, seriesCurve, 'LineWidth', 2);
    xlabel('Number of components in series'); ylabel('System reliability');
    title('(a) The cost of complexity'); grid on;

    subplot(1, 3, 2);
    redundancyCount = 1:6;
    parallelCurve = 1 - (1 - 0.90).^redundancyCount;
    marginalGain = [parallelCurve(1) - 0.90, diff(parallelCurve)];
    yyaxis left;  plot(redundancyCount, parallelCurve, '-o', 'LineWidth', 2);
    ylabel('Parallel reliability');
    yyaxis right; bar(redundancyCount, marginalGain, 0.4);
    ylabel('Marginal gain'); set(gca, 'YScale', 'log');
    xlabel('Redundant units'); title('(b) Diminishing returns'); grid on;

    subplot(1, 3, 3);
    bar(0:numel(componentReliability), workingCountPmf);
    xlabel('Number of components working');
    ylabel('Probability'); title('(c) Exact Poisson-binomial pmf'); grid on;
end

function visualiseBridgeNetwork(bridgeRange, bridgeCurve, analyticalValue)

    figure('Position', [100, 100, 700, 380], 'Name', 'Bridge network');
    plot(bridgeRange, bridgeCurve, 'LineWidth', 2); hold on;
    yline(analyticalValue, 'r--', 'LineWidth', 1.5);
    xlabel('Reliability of the bridging element R_3');
    ylabel('System reliability');
    title('Sensitivity to the bridge element');
    legend('System reliability', 'Nominal design', 'Location', 'southeast');
    grid on;
end

function visualiseAgeing(timeGrid, infantHazard, randomRate, wearHazard, ...
    totalHazard, systemReliability, availabilityGrid, steadyAvailability)

    figure('Position', [100, 100, 1300, 400], 'Name', 'Ageing');

    subplot(1, 3, 1);
    semilogy(timeGrid, infantHazard, '--', 'LineWidth', 1.5); hold on;
    semilogy(timeGrid, randomRate*ones(size(timeGrid)), ':', ...
        'LineWidth', 1.5);
    semilogy(timeGrid, wearHazard, '-.', 'LineWidth', 1.5);
    semilogy(timeGrid, totalHazard, 'k-', 'LineWidth', 2.2);
    xlabel('Time [h]'); ylabel('Hazard rate [1/h]');
    title('(a) Bathtub from competing risks');
    legend('Infant mortality', 'Random', 'Wear-out', 'Total', ...
        'Location', 'north'); grid on;

    subplot(1, 3, 2);
    plot(timeGrid, systemReliability, 'LineWidth', 2);
    xlabel('Time [h]'); ylabel('Reliability R(t)');
    title('(b) Resulting survival function'); grid on;

    subplot(1, 3, 3);
    plot(timeGrid, availabilityGrid, 'LineWidth', 2); hold on;
    yline(steadyAvailability, 'r--', 'LineWidth', 1.5);
    xlabel('Time [h]'); ylabel('Availability A(t)');
    title('(c) Transient availability');
    legend('A(t)', 'Steady state', 'Location', 'northeast'); grid on;
end

% -----------------------
% Computational complexity. Series and parallel evaluations are O(n). The
% Poisson-binomial recursion via conv costs O(n^2) and returns the exact
% pmf for all k simultaneously, replacing an O(2^n) enumeration. Pivotal
% decomposition of the bridge is O(1) once the pivot is chosen, whereas
% Monte Carlo verification costs O(N) with O(N^{-1/2}) accuracy. The
% competing-risk hazard integration is O(m) for m time points through
% cumtrapz, so the whole listing is dominated by the simulation branch.
% -----------------------
