%% C020201Maths_Fundamental_code_111.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Wilcoxon rank-sum test (Mann-Whitney U test)
[pValue, hResult, stats] = ranksum(group1Data, group2Data);

% Kruskal-Wallis test (non-parametric ANOVA)
[pValue, anovaTable, stats] = kruskalwallis([group1; group2; group3], ...
    groupLabels, 'off');

% Spearman rank correlation (non-parametric)
[rhoSpearman, pValueSpearman] = corr(x, y, 'Type', 'Spearman');
