%% Appendix02-FAQs_code_037.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLAB Code for Local Magnification of 3D Plots

% Add magnify.m to MATLAB search path or current working directory
% After completing the basic drawing, enter the following two lines of code
magnify(gcf);

% Example usage with a simple 3D plot
clc;
clear;
close all;

% Data
x = linspace(-5, 5, 50);
y = linspace(-5, 5, 50);
[X, Y] = meshgrid(x, y);
Z = sin(sqrt(X.^2 + Y.^2));

% Main axes
figure;
axes1 = axes('Units', 'normalized');
hold(axes1, 'on');
surf(X, Y, Z, 'Parent', axes1);
xlabel('X-axis');
ylabel('Y-axis');
zlabel('Z-axis');
title('3D Surface Plot');

% Enable magnification
magnify(gcf);
