%% chapter_FundamentalMaths_example_FFT.m
% Comprehensive FFT analysis and digital filtering in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_FFT
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section6_example1.m
% Author: Dr Leo Chen
% Date: June 4, 2025
% MATLAB Version: R2025a
% Description: Comprehensive Fourier analysis demonstrating FFT computation,
% spectral analysis, windowing effects, and digital filtering for signal
% processing in autonomous systems and digital twin applications

fprintf('=== Comprehensive Fourier Analysis and Filtering ===\n\n');

%% Signal Generation and Parameter Definition
% Define sampling parameters
samplingFrequency = 1000;           % Sampling frequency (Hz)
samplingPeriod = 1/samplingFrequency;  % Sampling period (s)
signalLength = 1500;                % Signal length (samples)
timeVector = (0:signalLength-1) * samplingPeriod;  % Time vector

% Construct multi-component test signal
fundamentalFreq = 50;     % Primary frequency component (Hz)
secondHarmonic = 120;     % Secondary frequency component (Hz)
thirdHarmonic = 200;      % Tertiary frequency component (Hz)

% Generate clean signal: weighted sum of sinusoids
cleanSignal = 0.7*sin(2*pi*fundamentalFreq*timeVector) + ...
              sin(2*pi*secondHarmonic*timeVector) + ...
              0.5*sin(2*pi*thirdHarmonic*timeVector);

% Add realistic Gaussian noise to simulate sensor measurements
noiseAmplitude = 2.0;
noisySignal = cleanSignal + noiseAmplitude*randn(size(timeVector));

fprintf('Signal parameters:\n');
fprintf('  Sampling frequency: %d Hz\n', samplingFrequency);
fprintf('  Signal duration: %.2f seconds\n', signalLength*samplingPeriod);
fprintf('  Frequency components: %d, %d, %d Hz\n', ...
    fundamentalFreq, secondHarmonic, thirdHarmonic);

%% FFT Computation with Proper Normalisation
% Compute FFT
fftOutput = fft(noisySignal);
fftLength = length(fftOutput);

% Construct two-sided amplitude spectrum
twoSidedSpectrum = abs(fftOutput/fftLength);

% Extract single-sided spectrum (positive frequencies only)
singleSidedSpectrum = twoSidedSpectrum(1:fftLength/2+1);
singleSidedSpectrum(2:end-1) = 2*singleSidedSpectrum(2:end-1);

% Construct frequency domain vector
frequencyVector = samplingFrequency*(0:(fftLength/2))/fftLength;

fprintf('\nFFT computation complete.\n');
fprintf('  FFT length: %d points\n', fftLength);
fprintf('  Frequency resolution: %.3f Hz\n', ...
    samplingFrequency/fftLength);

%% Windowing Effects Demonstration
% Apply Hamming window to reduce spectral leakage
hammingWindow = hamming(signalLength)';
windowedSignal = noisySignal .* hammingWindow;

% Compute FFT of windowed signal
fftWindowed = fft(windowedSignal);
spectrumWindowed = abs(fftWindowed/fftLength);
spectrumWindowed = spectrumWindowed(1:fftLength/2+1);
spectrumWindowed(2:end-1) = 2*spectrumWindowed(2:end-1);

%% Digital Filter Design and Application
% Design sixth-order Butterworth low-pass filter
cutoffFrequency = 150;  % Cutoff frequency (Hz)
filterOrder = 6;        % Filter order (controls roll-off steepness)
normalisedCutoff = cutoffFrequency/(samplingFrequency/2);

[filterNumerator, filterDenominator] = butter(filterOrder, ...
    normalisedCutoff, 'low');

% Apply digital filter to noisy signal
filteredSignal = filter(filterNumerator, filterDenominator, noisySignal);

% Compute FFT of filtered signal
fftFiltered = fft(filteredSignal);
spectrumFiltered = abs(fftFiltered/fftLength);
spectrumFiltered = spectrumFiltered(1:fftLength/2+1);
spectrumFiltered(2:end-1) = 2*spectrumFiltered(2:end-1);

fprintf('\nDigital filter designed:\n');
fprintf('  Type: Butterworth low-pass\n');
fprintf('  Order: %d\n', filterOrder);
fprintf('  Cutoff frequency: %d Hz\n', cutoffFrequency);

%% Visualisation: Time and Frequency Domain Analysis
figure('Position', [100, 100, 1400, 900]);

% Subplot 1: Clean reference signal (time domain)
subplot(3, 2, 1);
plot(1000*timeVector(1:200), cleanSignal(1:200), 'b-', 'LineWidth', 1.5);
xlabel('Time (ms)', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
title('Clean Reference Signal (Time Domain)', 'Interpreter', 'latex', ...
    'FontSize', 12);
grid on;
xlim([0, 200]);

% Subplot 2: Noisy measurement signal (time domain)
subplot(3, 2, 2);
plot(1000*timeVector(1:200), noisySignal(1:200), 'r-', 'LineWidth', 1);
xlabel('Time (ms)', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
title('Noisy Measurement Signal (Time Domain)', 'Interpreter', 'latex', ...
    'FontSize', 12);
grid on;
xlim([0, 200]);

% Subplot 3: Single-sided amplitude spectrum (no windowing)
subplot(3, 2, 3);
plot(frequencyVector, singleSidedSpectrum, 'k-', 'LineWidth', 1.5);
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('$|P_1(f)|$', 'Interpreter', 'latex');
title('Single-Sided Amplitude Spectrum (Rectangular Window)', ...
    'Interpreter', 'latex', 'FontSize', 12);
xlim([0, 300]);
grid on;

% Subplot 4: Windowed spectrum comparison
subplot(3, 2, 4);
plot(frequencyVector, singleSidedSpectrum, 'k-', 'LineWidth', 1, ...
    'DisplayName', 'Rectangular');
hold on;
plot(frequencyVector, spectrumWindowed, 'b-', 'LineWidth', 1.5, ...
    'DisplayName', 'Hamming Window');
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('$|P_1(f)|$', 'Interpreter', 'latex');
title('Windowing Effect on Spectral Leakage', 'Interpreter', 'latex', ...
    'FontSize', 12);
legend('show', 'Interpreter', 'latex', 'Location', 'northeast');
xlim([0, 300]);
grid on;
hold off;

% Subplot 5: Filtered signal (time domain)
subplot(3, 2, 5);
plot(1000*timeVector(1:200), filteredSignal(1:200), 'g-', 'LineWidth', 1.5);
hold on;
plot(1000*timeVector(1:200), cleanSignal(1:200), 'b--', 'LineWidth', 1);
xlabel('Time (ms)', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
title('Filtered Signal vs Clean Reference', 'Interpreter', 'latex', ...
    'FontSize', 12);
legend('Filtered', 'Reference', 'Interpreter', 'latex', 'Location', 'best');
grid on;
xlim([0, 200]);
hold off;

% Subplot 6: Filtered spectrum
subplot(3, 2, 6);
plot(frequencyVector, singleSidedSpectrum, 'k-', 'LineWidth', 1, ...
    'DisplayName', 'Original');
hold on;
plot(frequencyVector, spectrumFiltered, 'g-', 'LineWidth', 1.5, ...
    'DisplayName', 'Filtered');
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('$|P_1(f)|$', 'Interpreter', 'latex');
title('Frequency Domain: Filtering Effect', 'Interpreter', 'latex', ...
    'FontSize', 12);
legend('show', 'Interpreter', 'latex', 'Location', 'northeast');
xlim([0, 300]);
grid on;
hold off;

saveas(gcf, 'fourier_analysis_comprehensive.png');

%% Quantitative Performance Assessment
% Compute signal-to-noise ratio improvements
snrBefore = snr(cleanSignal, noisySignal - cleanSignal);
snrAfter = snr(cleanSignal, filteredSignal - cleanSignal);
snrImprovement = snrAfter - snrBefore;

% Compute mean squared error
mseBefore = mean((cleanSignal - noisySignal).^2);
mseAfter = mean((cleanSignal - filteredSignal).^2);
mseReduction = 100 * (mseBefore - mseAfter) / mseBefore;

fprintf('\n=== Signal Processing Performance Metrics ===\n');
fprintf('SNR before filtering: %.2f dB\n', snrBefore);
fprintf('SNR after filtering:  %.2f dB\n', snrAfter);
fprintf('SNR improvement:      %.2f dB\n', snrImprovement);
fprintf('MSE reduction:        %.1f%%\n', mseReduction);

fprintf('\nFourier analysis example complete.\n');
fprintf('Figure saved as: fourier_analysis_comprehensive.png\n');
