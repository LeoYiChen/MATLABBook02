%% chapter_Math_problem2_integral.m
% MATLAB adaptive quadrature.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem2_integral
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Adaptive Gauss-Kronrod quadrature
W = integral(@(x) f(x), a, b);

% With specified tolerances
W = integral(@(x) f(x), a, b, 'AbsTol', 1e-10, 'RelTol', 1e-8);
