%% C020201Maths_Fundamental_code_120.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Bayesian optimisation for hyperparameter tuning
optimVars = [
    optimizableVariable('learningRate', [1e-4, 1e-1], 'Transform', 'log')
    optimizableVariable('numLayers', [1, 5], 'Type', 'integer')
];

results = bayesopt(@(params) objectiveFunc(params), optimVars, ...
    'MaxObjectiveEvaluations', 30, 'IsObjectiveDeterministic', false);
