%% listing_consistency_validation.m
% Advanced data consistency validation and standardisation framework.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : listing_consistency_validation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [consistent_data, validation_report] = validateDataConsistency(data, consistency_rules, options)
% validateDataConsistency - Comprehensive data consistency checking and correction
%
% Syntax: [clean_data, report] = validateDataConsistency(data, rules, options)
%
% Inputs:
%   data              - Input data (table, cell array, or structure)
%   consistency_rules - Structure defining validation rules
%   options          - Configuration options for validation
%
% Outputs:
%   consistent_data   - Data after consistency validation and correction
%   validation_report - Detailed report of validation results

    % Input validation and default parameters
    if nargin < 2, consistency_rules = struct(); end
    if nargin < 3, options = struct(); end
    
    % Set default options
    if ~isfield(options, 'auto_correct'), options.auto_correct = true; end
    if ~isfield(options, 'strict_mode'), options.strict_mode = false; end
    if ~isfield(options, 'date_format'), options.date_format = 'auto'; end
    if ~isfield(options, 'currency_normalisation'), options.currency_normalisation = true; end
    if ~isfield(options, 'case_standardisation'), options.case_standardisation = 'proper'; end
    
    % Initialise validation report
    validation_report = struct();
    validation_report.total_records = height(data);
    validation_report.validation_time = tic;
    validation_report.errors_detected = {};
    validation_report.corrections_applied = {};
    validation_report.field_statistics = {};
    
    % Create working copy of data
    consistent_data = data;
    
    % Perform systematic validation checks
    [consistent_data, validation_report] = validateFieldFormats(consistent_data, validation_report, options);
    [consistent_data, validation_report] = validateDataTypes(consistent_data, validation_report, options);
    [consistent_data, validation_report] = validateBusinessRules(consistent_data, consistency_rules, validation_report, options);
    [consistent_data, validation_report] = validateCrossFieldConsistency(consistent_data, consistency_rules, validation_report, options);
    [consistent_data, validation_report] = standardiseFormats(consistent_data, validation_report, options);
    
    % Calculate final validation statistics
    validation_report.validation_time = toc(validation_report.validation_time);
    validation_report.total_errors = length(validation_report.errors_detected);
    validation_report.total_corrections = length(validation_report.corrections_applied);
    validation_report.consistency_score = calculateConsistencyScore(validation_report);
    validation_report.records_with_issues = countRecordsWithIssues(validation_report);
end

function [data, report] = validateFieldFormats(data, report, options)
% Validate and standardise field formats
    
    if ~istable(data)
        return; % Skip if not a table
    end
    
    variable_names = data.Properties.VariableNames;
    
    for i = 1:length(variable_names)
        var_name = variable_names{i};
        column_data = data.(var_name);
        
        % Detect and validate date fields
        if iscell(column_data) || isstring(column_data) || ischar(column_data)
            [is_date, standardised_dates] = detectAndStandardiseDates(column_data, options);
            
            if is_date
                if options.auto_correct
                    data.(var_name) = standardised_dates;
                    report.corrections_applied{end+1} = sprintf('Standardised date format in field: %s', var_name);
                end
                report.field_statistics.(var_name) = struct('type', 'date', 'format_standardised', true);
            end
            
            % Detect and validate currency fields
            [is_currency, standardised_currency] = detectAndStandardiseCurrency(column_data, options);
            
            if is_currency && ~is_date % Avoid double processing
                if options.auto_correct
                    data.(var_name) = standardised_currency;
                    report.corrections_applied{end+1} = sprintf('Standardised currency format in field: %s', var_name);
                end
                report.field_statistics.(var_name) = struct('type', 'currency', 'format_standardised', true);
            end
            
            % Detect and validate email addresses
            [is_email, email_issues] = validateEmailAddresses(column_data);
            
            if is_email
                if ~isempty(email_issues)
                    report.errors_detected{end+1} = sprintf('Invalid email addresses in field %s: %d issues', var_name, length(email_issues));
                end
                report.field_statistics.(var_name) = struct('type', 'email', 'validation_issues', length(email_issues));
            end
            
            % Detect and validate phone numbers
            [is_phone, standardised_phones] = detectAndStandardisePhones(column_data, options);
            
            if is_phone
                if options.auto_correct
                    data.(var_name) = standardised_phones;
                    report.corrections_applied{end+1} = sprintf('Standardised phone format in field: %s', var_name);
                end
                report.field_statistics.(var_name) = struct('type', 'phone', 'format_standardised', true);
            end
        end
    end
end

function [is_date, standardised_dates] = detectAndStandardiseDates(column_data, options)
% Detect and standardise date formats
    
    % Convert to cell array for processing
    if isstring(column_data) || ischar(column_data)
        column_data = cellstr(column_data);
    end
    
    standardised_dates = column_data;
    date_count = 0;
    
    % Common date patterns for detection
    date_patterns = {
        '\d{4}-\d{2}-\d{2}',           % YYYY-MM-DD
        '\d{2}/\d{2}/\d{4}',           % MM/DD/YYYY or DD/MM/YYYY
        '\d{1,2}[-/]\w{3}[-/]\d{4}',   % DD-MMM-YYYY
        '\w{3}\s+\d{1,2},?\s+\d{4}',   % MMM DD, YYYY
        '\d{2}-\d{2}-\d{4}'            % DD-MM-YYYY or MM-DD-YYYY
    };
    
    for i = 1:length(column_data)
        if ischar(column_data{i}) || isstring(column_data{i})
            cell_content = char(column_data{i});
            
            % Check if content matches date patterns
            for pattern = date_patterns
                if ~isempty(regexp(cell_content, pattern{1}, 'once'))
                    try
                        % Attempt to parse as date
                        parsed_date = datetime(cell_content, 'InputFormat', 'auto');
                        
                        if ~isnat(parsed_date)
                            date_count = date_count + 1;
                            
                            % Standardise to ISO 8601 format
                            if strcmp(options.date_format, 'auto') || strcmp(options.date_format, 'iso')
                                standardised_dates{i} = datestr(parsed_date, 'yyyy-mm-dd');
                            else
                                standardised_dates{i} = datestr(parsed_date, options.date_format);
                            end
                        end
                    catch
                        % Invalid date format, continue
                    end
                    break;
                end
            end
        end
    end
    
    % Consider column as date if majority of entries are dates
    is_date = (date_count / length(column_data)) > 0.7;
end

function [is_currency, standardised_currency] = detectAndStandardiseCurrency(column_data, options)
% Detect and standardise currency formats
    
    if ~options.currency_normalisation
        is_currency = false;
        standardised_currency = column_data;
        return;
    end
    
    % Convert to cell array for processing
    if isstring(column_data) || ischar(column_data)
        column_data = cellstr(column_data);
    end
    
    standardised_currency = column_data;
    currency_count = 0;
    
    % Currency patterns for detection
    currency_patterns = {
        '[$?뿯₽?][\d,]+\.?\d*',           % Currency symbols with numbers
        '\d+\.?\d*\s*[$?뿯₽?]',           % Numbers with trailing currency
        '[\d,]+\.?\d*\s*(USD|GBP|EUR|JPY|AUD|CAD)', % Numbers with currency codes
        '(USD|GBP|EUR|JPY|AUD|CAD)\s*[\d,]+\.?\d*'  % Currency codes with numbers
    };
    
    for i = 1:length(column_data)
        if ischar(column_data{i}) || isstring(column_data{i})
            cell_content = char(column_data{i});
            
            % Check if content matches currency patterns
            for pattern = currency_patterns
                matches = regexp(cell_content, pattern{1}, 'match');
                
                if ~isempty(matches)
                    currency_count = currency_count + 1;
                    
                    % Extract numeric value
                    numeric_part = regexp(cell_content, '[\d,]+\.?\d*', 'match', 'once');
                    numeric_value = str2double(strrep(numeric_part, ',', ''));
                    
                    % Detect currency type
                    if contains(cell_content, '$') || contains(cell_content, 'USD')
                        standardised_currency{i} = sprintf('USD %.2f', numeric_value);
                    elseif contains(cell_content, '?') || contains(cell_content, 'GBP')
                        standardised_currency{i} = sprintf('GBP %.2f', numeric_value);
                    elseif contains(cell_content, '뿯₽') || contains(cell_content, 'EUR')
                        standardised_currency{i} = sprintf('EUR %.2f', numeric_value);
                    else
                        standardised_currency{i} = sprintf('%.2f', numeric_value);
                    end
                    break;
                end
            end
        end
    end
    
    % Consider column as currency if majority of entries are currency
    is_currency = (currency_count / length(column_data)) > 0.5;
end

function [is_email, email_issues] = validateEmailAddresses(column_data)
% Validate email address formats
    
    % Convert to cell array for processing
    if isstring(column_data) || ischar(column_data)
        column_data = cellstr(column_data);
    end
    
    email_count = 0;
    email_issues = [];
    
    % RFC 5322 compliant email pattern (simplified)
    email_pattern = '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
    
    for i = 1:length(column_data)
        if ischar(column_data{i}) || isstring(column_data{i})
            cell_content = strtrim(char(column_data{i}));
            
            % Check if content looks like an email
            if contains(cell_content, '@') && contains(cell_content, '.')
                email_count = email_count + 1;
                
                % Validate against email pattern
                if isempty(regexp(cell_content, email_pattern, 'once'))
                    email_issues = [email_issues, i];
                end
            end
        end
    end
    
    % Consider column as email if majority of entries contain @ symbol
    is_email = (email_count / length(column_data)) > 0.7;
end

function [is_phone, standardised_phones] = detectAndStandardisePhones(column_data, options)
% Detect and standardise phone number formats
    
    % Convert to cell array for processing
    if isstring(column_data) || ischar(column_data)
        column_data = cellstr(column_data);
    end
    
    standardised_phones = column_data;
    phone_count = 0;
    
    % Phone number patterns for detection
    phone_patterns = {
        '\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', % International and US formats
        '\d{3}[-.\s]?\d{3}[-.\s]?\d{4}',                        % US format without country code
        '\+?\d{1,3}[-.\s]?\d{3,4}[-.\s]?\d{3,4}[-.\s]?\d{3,4}' % General international format
    };
    
    for i = 1:length(column_data)
        if ischar(column_data{i}) || isstring(column_data{i})
            cell_content = char(column_data{i});
            
            % Check if content matches phone patterns
            for pattern = phone_patterns
                if ~isempty(regexp(cell_content, pattern{1}, 'once'))
                    phone_count = phone_count + 1;
                    
                    % Extract digits only
                    digits_only = regexp(cell_content, '\d', 'match');
                    digits_string = strjoin(digits_only, '');
                    
                    % Standardise format based on length
                    if length(digits_string) == 10
                        % US domestic number
                        standardised_phones{i} = sprintf('(%s) %s-%s', ...
                            digits_string(1:3), digits_string(4:6), digits_string(7:10));
                    elseif length(digits_string) == 11 && digits_string(1) == '1'
                        % US number with country code
                        standardised_phones{i} = sprintf('+1 (%s) %s-%s', ...
                            digits_string(2:4), digits_string(5:7), digits_string(8:11));
                    else
                        % International number - keep digits with + prefix
                        standardised_phones{i} = sprintf('+%s', digits_string);
                    end
                    break;
                end
            end
        end
    end
    
    % Consider column as phone if majority of entries match phone patterns
    is_phone = (phone_count / length(column_data)) > 0.6;
end

function [data, report] = validateDataTypes(data, report, options)
% Validate data types and perform type coercion where appropriate
    
    if ~istable(data)
        return; % Skip if not a table
    end
    
    variable_names = data.Properties.VariableNames;
    
    for i = 1:length(variable_names)
        var_name = variable_names{i};
        column_data = data.(var_name);
        original_class = class(column_data);
        
        % Attempt intelligent type conversion
        if iscell(column_data) || isstring(column_data)
            % Check if all entries can be converted to numeric
            [is_numeric, numeric_data] = attemptNumericConversion(column_data);
            
            if is_numeric && options.auto_correct
                data.(var_name) = numeric_data;
                report.corrections_applied{end+1} = sprintf('Converted field %s from %s to numeric', var_name, original_class);
            end
            
            % Check for logical/boolean values
            [is_logical, logical_data] = attemptLogicalConversion(column_data);
            
            if is_logical && ~is_numeric && options.auto_correct
                data.(var_name) = logical_data;
                report.corrections_applied{end+1} = sprintf('Converted field %s from %s to logical', var_name, original_class);
            end
        end
        
        % Check for data type consistency within column
        type_consistency = checkTypeConsistency(data.(var_name));
        if type_consistency < 1.0
            report.errors_detected{end+1} = sprintf('Mixed data types in field %s (consistency: %.2f)', var_name, type_consistency);
        end
    end
end

function [is_numeric, numeric_data] = attemptNumericConversion(column_data)
% Attempt to convert cell/string array to numeric
    
    % Convert to cell array for processing
    if isstring(column_data)
        column_data = cellstr(column_data);
    end
    
    numeric_data = zeros(length(column_data), 1);
    conversion_count = 0;
    
    for i = 1:length(column_data)
        if isempty(column_data{i}) || (ischar(column_data{i}) && isempty(strtrim(column_data{i})))
            numeric_data(i) = NaN;
            conversion_count = conversion_count + 1;
        else
            % Clean the string for numeric conversion
            cleaned_str = strtrim(char(column_data{i}));
            cleaned_str = regexprep(cleaned_str, '[,$%]', ''); % Remove common non-numeric characters
            
            converted_value = str2double(cleaned_str);
            
            if ~isnan(converted_value)
                numeric_data(i) = converted_value;
                conversion_count = conversion_count + 1;
            else
                numeric_data(i) = NaN;
            end
        end
    end
    
    % Consider successful if majority can be converted
    is_numeric = (conversion_count / length(column_data)) > 0.8;
end

function [is_logical, logical_data] = attemptLogicalConversion(column_data)
% Attempt to convert cell/string array to logical
    
    % Convert to cell array for processing
    if isstring(column_data)
        column_data = cellstr(column_data);
    end
    
    logical_data = false(length(column_data), 1);
    conversion_count = 0;
    
    % Common boolean representations
    true_values = {'true', 'yes', 'y', '1', 'on', 'enabled', 'active'};
    false_values = {'false', 'no', 'n', '0', 'off', 'disabled', 'inactive'};
    
    for i = 1:length(column_data)
        if ~isempty(column_data{i})
            cleaned_str = lower(strtrim(char(column_data{i})));
            
            if ismember(cleaned_str, true_values)
                logical_data(i) = true;
                conversion_count = conversion_count + 1;
            elseif ismember(cleaned_str, false_values)
                logical_data(i) = false;
                conversion_count = conversion_count + 1;
            end
        end
    end
    
    % Consider successful if majority can be converted
    is_logical = (conversion_count / length(column_data)) > 0.8;
end

function consistency = checkTypeConsistency(column_data)
% Check type consistency within a column
    
    if isnumeric(column_data) || islogical(column_data)
        consistency = 1.0; % Homogeneous numeric/logical data
        return;
    end
    
    if iscell(column_data)
        % Check consistency of cell contents
        types = cellfun(@class, column_data, 'UniformOutput', false);
        unique_types = unique(types);
        
        % Calculate consistency as proportion of most common type
        type_counts = zeros(length(unique_types), 1);
        for i = 1:length(unique_types)
            type_counts(i) = sum(strcmp(types, unique_types{i}));
        end
        
        consistency = max(type_counts) / length(column_data);
    else
        consistency = 1.0; % Other homogeneous types
    end
end

function [data, report] = validateBusinessRules(data, consistency_rules, report, options)
% Validate business-specific rules
    
    if ~isfield(consistency_rules, 'business_rules') || isempty(consistency_rules.business_rules)
        return; % No business rules defined
    end
    
    business_rules = consistency_rules.business_rules;
    rule_names = fieldnames(business_rules);
    
    for i = 1:length(rule_names)
        rule_name = rule_names{i};
        rule_definition = business_rules.(rule_name);
        
        % Apply rule based on type
        switch rule_definition.type
            case 'range'
                violations = validateRangeRule(data, rule_definition);
                
            case 'pattern'
                violations = validatePatternRule(data, rule_definition);
                
            case 'custom'
                violations = validateCustomRule(data, rule_definition);
                
            otherwise
                continue;
        end
        
        if ~isempty(violations)
            report.errors_detected{end+1} = sprintf('Business rule violation (%s): %d records affected', rule_name, length(violations));
        end
    end
end

function violations = validateRangeRule(data, rule_definition)
% Validate range constraints
    violations = [];
    
    if ~istable(data) || ~isfield(rule_definition, 'field') || ~isfield(rule_definition, 'min_value') || ~isfield(rule_definition, 'max_value')
        return;
    end
    
    field_name = rule_definition.field;
    min_value = rule_definition.min_value;
    max_value = rule_definition.max_value;
    
    if ~ismember(field_name, data.Properties.VariableNames)
        return;
    end
    
    column_data = data.(field_name);
    
    if isnumeric(column_data)
        violations = find(column_data < min_value | column_data > max_value);
    end
end

function violations = validatePatternRule(data, rule_definition)
% Validate pattern matching rules
    violations = [];
    
    if ~istable(data) || ~isfield(rule_definition, 'field') || ~isfield(rule_definition, 'pattern')
        return;
    end
    
    field_name = rule_definition.field;
    pattern = rule_definition.pattern;
    
    if ~ismember(field_name, data.Properties.VariableNames)
        return;
    end
    
    column_data = data.(field_name);
    
    if iscell(column_data) || isstring(column_data)
        for i = 1:length(column_data)
            if ~isempty(column_data{i})
                if isempty(regexp(char(column_data{i}), pattern, 'once'))
                    violations = [violations, i];
                end
            end
        end
    end
end

function violations = validateCustomRule(data, rule_definition)
% Validate custom rules using function handles
    violations = [];
    
    if ~istable(data) || ~isfield(rule_definition, 'validation_function')
        return;
    end
    
    validation_function = rule_definition.validation_function;
    
    if isa(validation_function, 'function_handle')
        try
            violations = validation_function(data);
        catch ME
            warning('Custom validation function failed: %s', ME.message);
        end
    end
end

function [data, report] = validateCrossFieldConsistency(data, consistency_rules, report, options)
% Validate consistency across multiple fields
    
    if ~isfield(consistency_rules, 'cross_field_rules') || isempty(consistency_rules.cross_field_rules)
        return; % No cross-field rules defined
    end
    
    cross_field_rules = consistency_rules.cross_field_rules;
    rule_names = fieldnames(cross_field_rules);
    
    for i = 1:length(rule_names)
        rule_name = rule_names{i};
        rule_definition = cross_field_rules.(rule_name);
        
        violations = validateCrossFieldRule(data, rule_definition);
        
        if ~isempty(violations)
            report.errors_detected{end+1} = sprintf('Cross-field consistency violation (%s): %d records affected', rule_name, length(violations));
        end
    end
end

function violations = validateCrossFieldRule(data, rule_definition)
% Validate individual cross-field rule
    violations = [];
    
    if ~istable(data) || ~isfield(rule_definition, 'fields') || ~isfield(rule_definition, 'constraint')
        return;
    end
    
    fields = rule_definition.fields;
    constraint = rule_definition.constraint;
    
    % Check if all required fields exist
    if ~all(ismember(fields, data.Properties.VariableNames))
        return;
    end
    
    % Apply constraint based on type
    switch constraint.type
        case 'date_order'
            % Validate that dates are in proper order
            if length(fields) == 2
                date1 = data.(fields{1});
                date2 = data.(fields{2});
                
                % Convert to datetime if necessary
                if iscell(date1) || isstring(date1)
                    date1 = datetime(date1, 'InputFormat', 'auto');
                end
                if iscell(date2) || isstring(date2)
                    date2 = datetime(date2, 'InputFormat', 'auto');
                end
                
                violations = find(date1 >= date2);
            end
            
        case 'sum_constraint'
            % Validate that sum of fields meets constraint
            if isfield(constraint, 'target_sum')
                field_data = zeros(height(data), length(fields));
                for j = 1:length(fields)
                    field_data(:, j) = data.(fields{j});
                end
                
                row_sums = sum(field_data, 2);
                violations = find(abs(row_sums - constraint.target_sum) > 0.01);
            end
            
        case 'logical_dependency'
            % Validate logical dependencies between fields
            if length(fields) == 2 && isfield(constraint, 'dependency_type')
                field1 = data.(fields{1});
                field2 = data.(fields{2});
                
                switch constraint.dependency_type
                    case 'if_then'
                        % If field1 is true/non-empty, then field2 must be true/non-empty
                        violations = find(~isempty(field1) & isempty(field2));
                        
                    case 'mutual_exclusive'
                        % Fields cannot both be true/non-empty
                        violations = find(~isempty(field1) & ~isempty(field2));
                end
            end
    end
end

function [data, report] = standardiseFormats(data, report, options)
% Apply final format standardisation
    
    if ~istable(data)
        return; % Skip if not a table
    end
    
    variable_names = data.Properties.VariableNames;
    
    for i = 1:length(variable_names)
        var_name = variable_names{i};
        column_data = data.(var_name);
        
        % Standardise text case
        if (iscell(column_data) || isstring(column_data)) && isfield(options, 'case_standardisation')
            standardised_case = standardiseTextCase(column_data, options.case_standardisation);
            
            if ~isequal(column_data, standardised_case)
                data.(var_name) = standardised_case;
                report.corrections_applied{end+1} = sprintf('Standardised text case in field: %s', var_name);
            end
        end
        
        % Trim whitespace
        if iscell(column_data) || isstring(column_data)
            trimmed_data = cellfun(@strtrim, cellstr(column_data), 'UniformOutput', false);
            
            if ~isequal(cellstr(column_data), trimmed_data)
                data.(var_name) = trimmed_data;
                report.corrections_applied{end+1} = sprintf('Trimmed whitespace in field: %s', var_name);
            end
        end
    end
end

function standardised_text = standardiseTextCase(column_data, case_type)
% Standardise text case according to specified type
    
    % Convert to cell array for processing
    if isstring(column_data)
        column_data = cellstr(column_data);
    end
    
    standardised_text = column_data;
    
    for i = 1:length(column_data)
        if ischar(column_data{i}) || isstring(column_data{i})
            text_content = char(column_data{i});
            
            switch lower(case_type)
                case 'lower'
                    standardised_text{i} = lower(text_content);
                    
                case 'upper'
                    standardised_text{i} = upper(text_content);
                    
                case 'proper'
                    % Title case - capitalise first letter of each word
                    words = strsplit(lower(text_content), ' ');
                    for j = 1:length(words)
                        if ~isempty(words{j})
                            words{j}(1) = upper(words{j}(1));
                        end
                    end
                    standardised_text{i} = strjoin(words, ' ');
                    
                case 'sentence'
                    % Sentence case - capitalise first letter only
                    text_content = lower(text_content);
                    if ~isempty(text_content)
                        text_content(1) = upper(text_content(1));
                    end
                    standardised_text{i} = text_content;
                    
                otherwise
                    % No change for unknown case types
            end
        end
    end
end

function consistency_score = calculateConsistencyScore(validation_report)
% Calculate overall consistency score based on validation results
    
    total_issues = validation_report.total_errors;
    total_records = validation_report.total_records;
    
    if total_records == 0
        consistency_score = 0;
    else
        % Score based on percentage of records without issues
        issue_rate = total_issues / total_records;
        consistency_score = max(0, 1 - issue_rate);
    end
    
    % Convert to percentage
    consistency_score = consistency_score * 100;
end

function records_with_issues = countRecordsWithIssues(validation_report)
% Count unique records that have validation issues
    
    % This is a simplified calculation - in practice, would need to track
    % which specific records have issues across different validation checks
    records_with_issues = min(validation_report.total_errors, validation_report.total_records);
end
