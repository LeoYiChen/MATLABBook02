%% chapter_Math_lab10_signal.m
% Signal Processing Pipeline Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab10_signal
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory
Lab10_SignalProcessingPipeline();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab10_SignalProcessingPipeline()
    % LAB10_SIGNALPROCESSINGPIPELINE Comprehensive vibration analysis
    %   Integrates FFT, filtering, and wavelet decomposition
    
    fprintf('\\textbf{Laboratory 10: Signal Processing Pipeline}\n');
    fprintf('==================================================\n\n');
    
    % Generate synthetic vibration signal
    [signal, fs, t, components] = generateVibrationSignal();
    
    % Task 1: Frequency domain analysis with FFT
    analyseFrequencyDomain(signal, fs, t, components);
    
    % Task 2: Digital filter design and implementation
    designAndApplyFilters(signal, fs, t);
    
    % Task 3: Wavelet decomposition
    performWaveletAnalysis(signal, fs, t);
    
    % Task 4: Noise reduction comparison
    compareNoiseReductionMethods(signal, fs, t);
    
    % Task 5: Time-frequency analysis
    performTimeFrequencyAnalysis(signal, fs, t);
end

function [signal, fs, t, components] = generateVibrationSignal()
    % GENERATEVIBRATIONSIGNAL Create realistic multi-component signal
    %   Simulates machinery vibration with multiple frequency components
    
    fprintf('\\textbf{Signal Generation}\n');
    fprintf('-----\n');
    
    % Sampling parameters
    fs = 2000;  % Sampling frequency (Hz)
    duration = 5;  % Signal duration (seconds)
    t = (0:1/fs:duration-1/fs)';
    N = length(t);
    
    fprintf('Sampling frequency: %d Hz\n', fs);
    fprintf('Duration: %.1f seconds\n', duration);
    fprintf('Number of samples: %d\n\n', N);
    
    % Signal components (simulating different vibration sources)
    f1 = 50;   % Rotating shaft frequency
    f2 = 120;  % Bearing defect frequency
    f3 = 250;  % Gear mesh frequency
    f4 = 180;  % Harmonic component
    
    fprintf('Signal Components:\n');
    fprintf('  f1 = %d Hz (Rotating shaft, amplitude = 2.0)\n', f1);
    fprintf('  f2 = %d Hz (Bearing defect, amplitude = 1.5)\n', f2);
    fprintf('  f3 = %d Hz (Gear mesh, amplitude = 1.0)\n', f3);
    fprintf('  f4 = %d Hz (Harmonic, amplitude = 0.8)\n\n', f4);
    
    % Generate components
    component1 = 2.0 * sin(2*pi*f1*t);
    component2 = 1.5 * sin(2*pi*f2*t);
    component3 = 1.0 * sin(2*pi*f3*t);
    component4 = 0.8 * sin(2*pi*f4*t);
    
    % Add amplitude modulation to simulate non-stationarity
    modulation = 1 + 0.3*sin(2*pi*2*t);  % 2 Hz modulation
    component2 = component2 .* modulation;
    
    % Combine components
    signal_clean = component1 + component2 + component3 + component4;
    
    % Add white noise
    noise_level = 0.5;
    noise = noise_level * randn(N, 1);
    signal = signal_clean + noise;
    
    fprintf('Noise characteristics:\n');
    fprintf('  Type: White Gaussian\n');
    fprintf('  Standard deviation: %.2f\n', noise_level);
    fprintf('  SNR: %.2f dB\n\n', 10*log10(var(signal_clean)/var(noise)));
    
    % Store components for reference
    components = struct();
    components.f = [f1, f2, f3, f4];
    components.amplitudes = [2.0, 1.5, 1.0, 0.8];
    components.clean = signal_clean;
    components.noise = noise;
    
    % Visualise generated signal
    visualiseSignalGeneration(signal, signal_clean, noise, t, fs);
end

function visualiseSignalGeneration(signal, signal_clean, noise, t, fs)
    % VISUALISESIGNALGENERATION Plot generated signal components
    
    figure('Position', [100, 100, 1400, 600], 'Name', 'Signal Generation');
    
    % Time domain view (first 0.5 seconds for clarity)
    t_view = t(t <= 0.5);
    signal_view = signal(t <= 0.5);
    clean_view = signal_clean(t <= 0.5);
    noise_view = noise(t <= 0.5);
    
    subplot(2, 3, 1);
    plot(t_view, clean_view, 'b-', 'LineWidth', 1.5);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Clean Signal', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    subplot(2, 3, 2);
    plot(t_view, noise_view, 'r-', 'LineWidth', 0.5);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Noise', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    subplot(2, 3, 3);
    plot(t_view, signal_view, 'k-', 'LineWidth', 1);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Noisy Signal', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Frequency domain
    N = length(signal);
    f = (0:N-1)*(fs/N);
    f = f(1:floor(N/2));
    
    % FFT of clean signal
    X_clean = fft(signal_clean);
    P_clean = abs(X_clean/N).^2;
    P_clean = P_clean(1:floor(N/2));
    
    subplot(2, 3, 4);
    plot(f, P_clean, 'b-', 'LineWidth', 1.5);
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Power', 'Interpreter', 'latex', 'FontSize', 12);
    title('Power Spectrum: Clean Signal', 'Interpreter', 'latex', 'FontSize', 13);
    xlim([0, 400]);
    grid on;
    
    % FFT of noise
    X_noise = fft(noise);
    P_noise = abs(X_noise/N).^2;
    P_noise = P_noise(1:floor(N/2));
    
    subplot(2, 3, 5);
    plot(f, P_noise, 'r-', 'LineWidth', 0.5);
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Power', 'Interpreter', 'latex', 'FontSize', 12);
    title('Power Spectrum: Noise', 'Interpreter', 'latex', 'FontSize', 13);
    xlim([0, 400]);
    grid on;
    
    % FFT of noisy signal
    X = fft(signal);
    P = abs(X/N).^2;
    P = P(1:floor(N/2));
    
    subplot(2, 3, 6);
    plot(f, P, 'k-', 'LineWidth', 1);
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Power', 'Interpreter', 'latex', 'FontSize', 12);
    title('Power Spectrum: Noisy Signal', 'Interpreter', 'latex', 'FontSize', 13);
    xlim([0, 400]);
    grid on;
end

function analyseFrequencyDomain(signal, fs, t, components)
    % ANALYSEFREQUENCYDOMAIN Comprehensive FFT analysis
    
    fprintf('\\textbf{Task 1: Frequency Domain Analysis (FFT)}\n');
    fprintf('--------\n');
    
    N = length(signal);
    
    % Compute FFT
    fprintf('Computing FFT...\n');
    tic;
    X = fft(signal);
    fft_time = toc;
    fprintf('  Computation time: %.6f seconds\n', fft_time);
    fprintf('  Complexity: O(N log N) where N = %d\n\n', N);
    
    % Frequency vector
    f = (0:N-1)*(fs/N);
    
    % Single-sided spectrum
    P = abs(X/N);
    P = P(1:floor(N/2)+1);
    P(2:end-1) = 2*P(2:end-1);
    f = f(1:floor(N/2)+1);
    
    % Find peaks
    [peaks, locs] = findpeaks(P, 'MinPeakHeight', 0.5, 'MinPeakDistance', 20);
    peak_freqs = f(locs);
    
    fprintf('Detected Frequency Peaks:\n');
    for i = 1:length(peak_freqs)
        fprintf('  f = %.2f Hz, Amplitude = %.4f\n', peak_freqs(i), peaks(i));
        
        % Match to known components
        [~, idx] = min(abs(components.f - peak_freqs(i)));
        if abs(components.f(idx) - peak_freqs(i)) < 2
            fprintf('    -> Matches component at %.0f Hz\n', components.f(idx));
        end
    end
    fprintf('\n');
    
    % Spectral energy distribution
    total_energy = sum(P.^2);
    freq_ranges = [0, 100; 100, 200; 200, 300; 300, fs/2];
    
    fprintf('Spectral Energy Distribution:\n');
    for i = 1:size(freq_ranges, 1)
        range_mask = f >= freq_ranges(i, 1) & f < freq_ranges(i, 2);
        range_energy = sum(P(range_mask).^2);
        percent = 100 * range_energy / total_energy;
        fprintf('  %.0f-%.0f Hz: %.2f%% of total energy\n', ...
            freq_ranges(i, 1), freq_ranges(i, 2), percent);
    end
    fprintf('\n');
    
    % Effect of windowing
    fprintf('Analysing windowing effects...\n');
    
    windows = {
        struct('name', 'Rectangular', 'func', @(N) ones(N, 1)), ...
        struct('name', 'Hamming', 'func', @hamming), ...
        struct('name', 'Hanning', 'func', @hann), ...
        struct('name', 'Blackman', 'func', @blackman)
    };
    
    % Visualise FFT results with different windows
    visualiseFFTAnalysis(signal, fs, P, f, peak_freqs, peaks, windows);
end

function visualiseFFTAnalysis(signal, fs, P, f, peak_freqs, peaks, windows)
    % VISUALISEFFTANALYSIS Create comprehensive FFT visualisation
    
    figure('Position', [150, 150, 1400, 800], 'Name', 'FFT Analysis');
    
    N = length(signal);
    
    % Main spectrum
    subplot(3, 2, 1);
    plot(f, P, 'b-', 'LineWidth', 1.5);
    hold on;
    plot(peak_freqs, peaks, 'rv', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Single-Sided Amplitude Spectrum', 'Interpreter', 'latex', 'FontSize', 13);
    xlim([0, 400]);
    grid on;
    
    % Logarithmic scale
    subplot(3, 2, 2);
    semilogy(f, P, 'b-', 'LineWidth', 1.5);
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Magnitude (log scale)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Logarithmic Amplitude Spectrum', 'Interpreter', 'latex', 'FontSize', 13);
    xlim([0, 400]);
    grid on;
    
    % Compare different windows
    for i = 1:4
        subplot(3, 2, i+2);
        
        window = windows{i}.func(N);
        signal_windowed = signal .* window;
        
        X_win = fft(signal_windowed);
        P_win = abs(X_win/N);
        P_win = P_win(1:floor(N/2)+1);
        P_win(2:end-1) = 2*P_win(2:end-1);
        
        plot(f, P_win, 'b-', 'LineWidth', 1.5);
        xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('%s Window', windows{i}.name), ...
            'Interpreter', 'latex', 'FontSize', 13);
        xlim([0, 400]);
        grid on;
    end
end

function designAndApplyFilters(signal, fs, t)
    % DESIGNANDAPPLYFILTERS Design and compare digital filters
    
    fprintf('\\textbf{Task 2: Digital Filter Design and Application}\n');
    fprintf('----------\n');
    
    % Design specifications
    fprintf('Filter Specifications:\n\n');
    
    % 1. Low-pass filter (remove high-frequency noise above 200 Hz)
    fc_low = 200;  % Cutoff frequency
    order_low = 6;
    
    fprintf('1. Low-Pass Butterworth Filter:\n');
    fprintf('   Cutoff frequency: %d Hz\n', fc_low);
    fprintf('   Filter order: %d\n', order_low);
    
    [b_lp, a_lp] = butter(order_low, fc_low/(fs/2), 'low');
    
    % Analyse filter characteristics
    [H_lp, f_lp] = freqz(b_lp, a_lp, 1024, fs);
    mag_lp = abs(H_lp);
    phase_lp = angle(H_lp);
    
    % -3*dB point
    [~, idx_3db] = min(abs(mag_lp - 1/sqrt(2)));
    fc_actual = f_lp(idx_3db);
    fprintf('   Actual -3*dB frequency: %.2f Hz\n', fc_actual);
    
    % Apply filter
    fprintf('   Applying filter...\n');
    tic;
    signal_lp = filtfilt(b_lp, a_lp, signal);  % Zero-phase filtering
    time_lp = toc;
    fprintf('   Computation time: %.6f seconds\n\n', time_lp);
    
    % 2. Band-pass filter (isolate bearing frequency 100-140 Hz)
    fc_low_bp = 100;
    fc_high_bp = 140;
    order_bp = 4;
    
    fprintf('2. Band-Pass Butterworth Filter:\n');
    fprintf('   Passband: %d-%d Hz\n', fc_low_bp, fc_high_bp);
    fprintf('   Filter order: %d\n', order_bp);
    
    [b_bp, a_bp] = butter(order_bp, [fc_low_bp, fc_high_bp]/(fs/2), 'bandpass');
    
    fprintf('   Applying filter...\n');
    tic;
    signal_bp = filtfilt(b_bp, a_bp, signal);
    time_bp = toc;
    fprintf('   Computation time: %.6f seconds\n\n', time_bp);
    
    % 3. High-pass filter
    fc_high = 150;
    order_hp = 6;
    
    fprintf('3. High-Pass Butterworth Filter:\n');
    fprintf('   Cutoff frequency: %d Hz\n', fc_high);
    fprintf('   Filter order: %d\n', order_hp);
    
    [b_hp, a_hp] = butter(order_hp, fc_high/(fs/2), 'high');
    
    fprintf('   Applying filter...\n');
    tic;
    signal_hp = filtfilt(b_hp, a_hp, signal);
    time_hp = toc;
    fprintf('   Computation time: %.6f seconds\n\n', time_hp);
    
    % 4. Notch filter (remove specific frequency)
    f_notch = 120;
    bw = 10;  % Bandwidth
    
    fprintf('4. Notch Filter:\n');
    fprintf('   Center frequency: %d Hz\n', f_notch);
    fprintf('   Bandwidth: %d Hz\n', bw);
    
    wo = f_notch/(fs/2);
    bw_norm = bw/(fs/2);
    [b_notch, a_notch] = iirnotch(wo, bw_norm);
    
    fprintf('   Applying filter...\n');
    tic;
    signal_notch = filtfilt(b_notch, a_notch, signal);
    time_notch = toc;
    fprintf('   Computation time: %.6f seconds\n\n', time_notch);
    
    % Visualise filter responses and results
    filters = struct();
    filters.lp = struct('b', b_lp, 'a', a_lp, 'signal', signal_lp, 'name', 'Low-Pass');
    filters.bp = struct('b', b_bp, 'a', a_bp, 'signal', signal_bp, 'name', 'Band-Pass');
    filters.hp = struct('b', b_hp, 'a', a_hp, 'signal', signal_hp, 'name', 'High-Pass');
    filters.notch = struct('b', b_notch, 'a', a_notch, 'signal', signal_notch, 'name', 'Notch');
    
    visualiseFilterResults(signal, filters, fs, t);
end

function visualiseFilterResults(signal, filters, fs, t)
    % VISUALISEFILTERRESULTS Create comprehensive filter visualisation
    
    % Figure 1: Filter frequency responses
    figure('Position', [200, 200, 1400, 500], 'Name', 'Filter Characteristics');
    
    filter_names = fieldnames(filters);
    
    for i = 1:length(filter_names)
        filt = filters.*(filter_names{i});
        
        subplot(2, 4, i);
        [H, f] = freqz(filt.b, filt.a, 1024, fs);
        plot(f, 20*log10(abs(H)), 'b-', 'LineWidth', 2);
        xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('Magnitude (dB)', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('%s: Magnitude Response', filt.name), ...
            'Interpreter', 'latex', 'FontSize', 12);
        grid on;
        xlim([0, fs/2]);
        
        subplot(2, 4, i+4);
        plot(f, unwrap(angle(H))*180/pi, 'r-', 'LineWidth', 2);
        xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('Phase (degrees)', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('%s: Phase Response', filt.name), ...
            'Interpreter', 'latex', 'FontSize', 12);
        grid on;
        xlim([0, fs/2]);
    end
    
    % Figure 2: Time domain comparison
    figure('Position', [250, 250, 1400, 800], 'Name', 'Filtered Signals');
    
    % Original signal
    subplot(3, 2, 1);
    t_view = t(t <= 0.5);
    plot(t_view, signal(t <= 0.5), 'k-', 'LineWidth', 1);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Signal', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Filtered signals
    for i = 1:length(filter_names)
        filt = filters.*(filter_names{i});
        
        subplot(3, 2, i+1);
        plot(t_view, filt.signal(t <= 0.5), 'b-', 'LineWidth', 1);
        xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('%s Filtered', filt.name), 'Interpreter', 'latex', 'FontSize', 13);
        grid on;
    end
    
    % Figure 3: Frequency domain comparison
    figure('Position', [300, 300, 1400, 800], 'Name', 'Spectral Comparison');
    
    N = length(signal);
    f_fft = (0:N-1)*(fs/N);
    f_fft = f_fft(1:floor(N/2)+1);
    
    % Original spectrum
    subplot(3, 2, 1);
    X_orig = fft(signal);
    P_orig = abs(X_orig/N);
    P_orig = P_orig(1:floor(N/2)+1);
    P_orig(2:end-1) = 2*P_orig(2:end-1);
    
    plot(f_fft, P_orig, 'k-', 'LineWidth', 1.5);
    xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Signal Spectrum', 'Interpreter', 'latex', 'FontSize', 13);
    xlim([0, 400]);
    grid on;
    
    % Filtered spectra
    for i = 1:length(filter_names)
        filt = filters.*(filter_names{i});
        
        subplot(3, 2, i+1);
        X_filt = fft(filt.signal);
        P_filt = abs(X_filt/N);
        P_filt = P_filt(1:floor(N/2)+1);
        P_filt(2:end-1) = 2*P_filt(2:end-1);
        
        plot(f_fft, P_filt, 'b-', 'LineWidth', 1.5);
        xlabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('Magnitude', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('%s Filtered Spectrum', filt.name), ...
            'Interpreter', 'latex', 'FontSize', 13);
        xlim([0, 400]);
        grid on;
    end
end

function performWaveletAnalysis(signal, fs, t)
    % PERFORMWAVELETANALYSIS Multi-resolution wavelet decomposition
    
    fprintf('\\textbf{Task 3: Wavelet Decomposition}\n');
    fprintf('-------\n');
    
    % Wavelet parameters
    wavelet_name = 'db4';  % Daubechies 4
    level = 5;             % Decomposition level
    
    fprintf('Wavelet: %s (Daubechies 4)\n', wavelet_name);
    fprintf('Decomposition level: %d\n', level);
    fprintf('Frequency bands per level (approximate):\n');
    
    for j = 1:level
        f_low = fs / 2^(j+1);
        f_high = fs / 2^j;
        fprintf('  Level %d: %.1f - %.1f Hz\n', j, f_low, f_high);
    end
    fprintf('\n');
    
    % Perform DWT
    fprintf('Performing Discrete Wavelet Transform...\n');
    tic;
    [C, L] = wavedec(signal, level, wavelet_name);
    dwt_time = toc;
    fprintf('  Computation time: %.6f seconds\n', dwt_time);
    fprintf('  Total coefficients: %d\n', length(C));
    fprintf('  Compression ratio: %.2f:1\n\n', length(signal) / length(C));
    
    % Extract approximation and details
    approx = appcoef(C, L, wavelet_name, level);
    details = cell(level, 1);
    
    fprintf('Coefficient Statistics:\n');
    fprintf('  Approximation (level %d): %d coefficients\n', level, length(approx));
    
    for j = 1:level
        details{j} = detcoef(C, L, j);
        fprintf('  Detail level %d: %d coefficients\n', j, length(details{j}));
    end
    fprintf('\n');
    
    % Reconstruct from each level
    fprintf('Reconstructing signal components...\n');
    reconstructions = cell(level, 1);
    
    for j = 1:level
        D = zeros(size(C));
        D(sum(L(1:j))+1:sum(L(1:j+1))) = C(sum(L(1:j))+1:sum(L(1:j+1)));
        reconstructions{j} = waverec(D, L, wavelet_name);
    end
    
    A = zeros(size(C));
    A(1:L(1)) = C(1:L(1));
    reconstruction_approx = waverec(A, L, wavelet_name);
    
    % Energy distribution
    fprintf('\nEnergy Distribution:\n');
    total_energy = sum(C.^2);
    
    approx_energy = sum(C(1:L(1)).^2);
    fprintf('  Approximation: %.2f%%\n', 100*approx_energy/total_energy);
    
    for j = 1:level
        detail_energy = sum(details{j}.^2);
        fprintf('  Detail level %d: %.2f%%\n', j, 100*detail_energy/total_energy);
    end
    fprintf('\n');
    
    % Denoising via thresholding
    fprintf('Wavelet denoising...\n');
    
    % Estimate noise level
    detail1 = details{1};
    sigma = median(abs(detail1)) / 0.6745;  % Robust noise estimation
    fprintf('  Estimated noise level: %.4f\n', sigma);
    
    % Universal threshold
    n = length(signal);
    thr = sigma * sqrt(2*log(n));
    fprintf('  Universal threshold: %.4f\n', thr);
    
    % Apply soft thresholding
    C_denoised = wthresh(C, 's', thr);
    signal_denoised = waverec(C_denoised, L, wavelet_name);
    
    % Compute SNR improvement
    noise_estimate = signal - signal_denoised;
    snr_improvement = 10*log10(var(signal_denoised) / var(noise_estimate));
    fprintf('  SNR improvement: %.2f dB\n\n', snr_improvement);
    
    % Visualise results
    visualiseWaveletAnalysis(signal, approx, details, reconstructions, ...
        reconstruction_approx, signal_denoised, t, level, wavelet_name);
end

function visualiseWaveletAnalysis(signal, approx, details, reconstructions, ...
    reconstruction_approx, signal_denoised, t, level, wavelet_name)
    % VISUALISEWAVELETANALYSIS Create wavelet decomposition visualisation
    
    % Figure 1: Wavelet decomposition tree
    figure('Position', [100, 100, 1400, 900], 'Name', 'Wavelet Decomposition');
    
    % Original signal
    subplot(level+2, 2, 1:2);
    t_view = t(t <= 1);
    plot(t_view, signal(t <= 1), 'k-', 'LineWidth', 1);
    ylabel('Original', 'Interpreter', 'latex', 'FontSize', 11);
    title(sprintf('Wavelet Decomposition: %s, Level %d', wavelet_name, level), ...
        'Interpreter', 'latex', 'FontSize', 14);
    grid on;
    
    % Approximation
    t_approx = linspace(0, t(end), length(approx));
    subplot(level+2, 2, 3:4);
    plot(t_approx(t_approx <= 1), approx(t_approx <= 1), 'b-', 'LineWidth', 1);
    ylabel(sprintf('A%d', level), 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    
    % Details
    for j = 1:level
        t_detail = linspace(0, t(end), length(details{j}));
        subplot(level+2, 2, 2*j+3:2*j+4);
        plot(t_detail(t_detail <= 1), details{j}(t_detail <= 1), 'r-', 'LineWidth', 1);
        ylabel(sprintf('D%d', j), 'Interpreter', 'latex', 'FontSize', 11);
        grid on;
        
        if j == level
            xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
        end
    end
    
    % Figure 2: Reconstructed components
    figure('Position', [150, 150, 1400, 800], 'Name', 'Wavelet Reconstruction');
    
    % Original
    subplot(3, 2, 1);
    plot(t_view, signal(t <= 1), 'k-', 'LineWidth', 1);
    ylabel('Original', 'Interpreter', 'latex', 'FontSize', 11);
    title('Signal Components', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Approximation reconstruction
    subplot(3, 2, 2);
    plot(t_view, reconstruction_approx(t <= 1), 'b-', 'LineWidth', 1);
    ylabel(sprintf('A%d Recon', level), 'Interpreter', 'latex', 'FontSize', 11);
    title('Approximation Component', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Detail reconstructions
    for j = 1:min(4, level)
        subplot(3, 2, j+2);
        plot(t_view, reconstructions{j}(t <= 1), 'r-', 'LineWidth', 1);
        ylabel(sprintf('D%d Recon', j), 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('Detail Level %d', j), 'Interpreter', 'latex', 'FontSize', 13);
        grid on;
        
        if j >= 3
            xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
        end
    end
    
    % Figure 3: Denoising comparison
    figure('Position', [200, 200, 1200, 400], 'Name', 'Wavelet Denoising');
    
    subplot(1, 3, 1);
    plot(t_view, signal(t <= 1), 'k-', 'LineWidth', 1);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Noisy Signal', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    subplot(1, 3, 2);
    plot(t_view, signal_denoised(t <= 1), 'b-', 'LineWidth', 1);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Denoised Signal', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    subplot(1, 3, 3);
    noise_removed = signal - signal_denoised;
    plot(t_view, noise_removed(t <= 1), 'r-', 'LineWidth', 0.5);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Removed Noise', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
end

function compareNoiseReductionMethods(signal, fs, t)
    % COMPARENOISEREDUCTIONMETHODS Compare filtering vs wavelet denoising
    
    fprintf('\\textbf{Task 4: Noise Reduction Method Comparison}\n');
    fprintf('---------\n\n');
    
    % Method 1: Low-pass filtering
    fprintf('Method 1: Low-Pass Butterworth Filter\n');
    [b_lp, a_lp] = butter(6, 200/(fs/2), 'low');
    signal_filtered = filtfilt(b_lp, a_lp, signal);
    
    % Method 2: Wavelet denoising
    fprintf('Method 2: Wavelet Soft Thresholding\n');
    [C, L] = wavedec(signal, 5, 'db4');
    detail1 = detcoef(C, L, 1);
    sigma = median(abs(detail1)) / 0.6745;
    thr = sigma * sqrt(2*log(length(signal)));
    C_denoised = wthresh(C, 's', thr);
    signal_wavelet = waverec(C_denoised, L, 'db4');
    
    % Method 3: Moving average
    fprintf('Method 3: Moving Average (Window=21)\n');
    window_size = 21;
    signal_ma = movmean(signal, window_size);
    
    % Method 4: Savitzky-Golay filter
    fprintf('Method 4: Savitzky-Golay Filter (Order=3, Frame=21)\n\n');
    signal_sg = sgolayfilt(signal, 3, 21);
    
    % Performance metrics
    % Assume we have access to clean signal (in practice, this would be estimated)
    % For demonstration, create synthetic clean signal
    components_f = [50, 120, 180, 250];
    components_a = [2.0, 1.5, 0.8, 1.0];
    signal_clean = zeros(size(signal));
    for i = 1:length(components_f)
        signal_clean = signal_clean + components_a(i)*sin(2*pi*components_f(i)*t);
    end
    
    % Compute metrics
    methods = {signal_filtered, signal_wavelet, signal_ma, signal_sg};
    method_names = {'Low-Pass Filter', 'Wavelet Denoising', 'Moving Average', 'Savitzky-Golay'};
    
    fprintf('Performance Comparison:\n');
    fprintf('%-20*s | %8*s | %8*s | %8*s\n', 'Method', 'MSE', 'SNR (dB)', 'Corr');
    fprintf('%s\n', repmat('-', 1, 60));
    
    for i = 1:length(methods)
        mse = mean((methods{i} - signal_clean).^2);
        snr = 10*log10(var(signal_clean) / var(methods{i} - signal_clean));
        correlation = corr(signal_clean, methods{i});
        
        fprintf('%-20*s | %8.4*f | %8.2*f | %8.4*f\n', ...
            method_names{i}, mse, snr, correlation);
    end
    fprintf('\n');
    
    % Visualise comparison
    visualiseNoiseReductionComparison(signal, signal_clean, methods, method_names, t);
end

function visualiseNoiseReductionComparison(signal, signal_clean, methods, method_names, t)
    % VISUALISENOISEREDUCTIONCOMPARISON Compare denoising methods
    
    figure('Position', [250, 250, 1400, 900], 'Name', 'Noise Reduction Comparison');
    
    t_view = t(t <= 0.5);
    
    % Original noisy signal
    subplot(3, 2, 1);
    plot(t_view, signal(t <= 0.5), 'Color', [0.5, 0.5, 0.5], 'LineWidth', 0.5);
    hold on;
    plot(t_view, signal_clean(t <= 0.5), 'k-', 'LineWidth', 2);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Noisy vs Clean Signal', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Noisy', 'Clean', 'Interpreter', 'latex');
    grid on;
    
    % Denoised signals
    for i = 1:length(methods)
        subplot(3, 2, i+1);
        plot(t_view, signal_clean(t <= 0.5), 'k-', 'LineWidth', 1, ...
            'DisplayName', 'True Signal');
        hold on;
        plot(t_view, methods{i}(t <= 0.5), 'b-', 'LineWidth', 1.5, ...
            'DisplayName', 'Denoised');
        xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
        title(method_names{i}, 'Interpreter', 'latex', 'FontSize', 13);
        legend('Interpreter', 'latex', 'Location', 'best');
        grid on;
    end
end

function performTimeFrequencyAnalysis(signal, fs, t)
    % PERFORMTIMEFREQUENCYANALYSIS Spectrogram and CWT analysis
    
    fprintf('\\textbf{Task 5: Time-Frequency Analysis}\n');
    fprintf('-------\n\n');
    
    % Short-Time Fourier Transform (Spectrogram)
    fprintf('Computing Spectrogram (STFT)...\n');
    window = 256;
    noverlap = window/2;
    nfft = 512;
    
    tic;
    [S, F, T, P] = spectrogram(signal, hamming(window), noverlap, nfft, fs);
    stft_time = toc;
    
    fprintf('  Window size: %d samples (%.3f s)\n', window, window/fs);
    fprintf('  Overlap: %d samples\n', noverlap);
    fprintf('  FFT points: %d\n', nfft);
    fprintf('  Computation time: %.6f seconds\n\n', stft_time);
    
    % Continuous Wavelet Transform
    fprintf('Computing Continuous Wavelet Transform...\n');
    
    % Use scales corresponding to frequencies of interest
    frequencies = 10:2:400;  % Hz
    scales = scal2frq('morl', frequencies, 1/fs);
    
    tic;
    [cwtCoeffs, cwtFreqs] = cwt(signal, scales, 'morl', 1/fs);
    cwt_time = toc;
    
    fprintf('  Wavelet: Morlet\n');
    fprintf('  Frequency range: %.1f - %.1f Hz\n', min(frequencies), max(frequencies));
    fprintf('  Number of scales: %d\n', length(scales));
    fprintf('  Computation time: %.6f seconds\n\n', cwt_time);
    
    % Visualise results
    visualiseTimeFrequencyAnalysis(signal, t, S, F, T, P, cwtCoeffs, cwtFreqs, fs);
end

function visualiseTimeFrequencyAnalysis(signal, t, S, F, T, P, cwtCoeffs, cwtFreqs, fs)
    % VISUALISETIMEFREQUENCYANALYSIS Create time-frequency visualisations
    
    figure('Position', [300, 300, 1400, 800], 'Name', 'Time-Frequency Analysis');
    
    % Time domain signal
    subplot(3, 2, 1:2);
    plot(t, signal, 'k-', 'LineWidth', 0.5);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Signal', 'Interpreter', 'latex', 'FontSize', 14);
    grid on;
    xlim([0, max(t)]);
    
    % Spectrogram
    subplot(3, 2, 3:4);
    imagesc(T, F, 10*log10(P));
    axis xy;
    colormap(jet);
    colorbar;
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Spectrogram (STFT)', 'Interpreter', 'latex', 'FontSize', 14);
    ylim([0, 400]);
    caxis([-80, 0]);
    
    % Continuous Wavelet Transform
    subplot(3, 2, 5:6);
    imagesc(t, cwtFreqs, abs(cwtCoeffs));
    axis xy;
    colormap(jet);
    colorbar;
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Frequency (Hz)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Continuous Wavelet Transform Scalogram', 'Interpreter', 'latex', 'FontSize', 14);
    ylim([0, 400]);
end
