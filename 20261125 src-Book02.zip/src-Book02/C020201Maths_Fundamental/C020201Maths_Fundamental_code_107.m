%% C020201Maths_Fundamental_code_107.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Multitaper spectral estimation
numTapers = 8;
timeBandwidthProduct = 4;

[psd, frequencies] = pmtm(signal, timeBandwidthProduct, [], ...
    samplingFrequency, 'Tapers', numTapers);

% Plot with confidence intervals
figure;
plot(frequencies, 10*log10(psd), 'LineWidth', 2);
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('Power Spectral Density (dB/Hz)', 'Interpreter', 'latex');
title('Multitaper PSD Estimate', 'Interpreter', 'latex');
grid on;
