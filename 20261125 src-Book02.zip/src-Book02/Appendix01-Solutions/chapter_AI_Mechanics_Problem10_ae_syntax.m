%% chapter_AI_Mechanics_Problem10_ae_syntax.m
% Autoencoder network definition syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem10_ae_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define autoencoder for anomaly detection
% inputDim: number of sensor channels (e.g., 16)
% latentDim: bottleneck dimension (e.g., 8)

inputDim = 16;
hiddenDim1 = 64;
hiddenDim2 = 32;
latentDim = 8;

% Encoder layers
encoderLayers = [
    featureInputLayer(inputDim, 'Name', 'input')
    fullyConnectedLayer(hiddenDim1, 'Name', 'fc_enc1')
    batchNormalizationLayer('Name', 'bn_enc1')
    reluLayer('Name', 'relu_enc1')
    dropoutLayer(0.2, 'Name', 'dropout_enc1')
    
    fullyConnectedLayer(hiddenDim2, 'Name', 'fc_enc2')
    batchNormalizationLayer('Name', 'bn_enc2')
    reluLayer('Name', 'relu_enc2')
    
    fullyConnectedLayer(latentDim, 'Name', 'latent')  % Bottleneck
];

% Decoder layers
decoderLayers = [
    fullyConnectedLayer(hiddenDim2, 'Name', 'fc_dec1')
    batchNormalizationLayer('Name', 'bn_dec1')
    reluLayer('Name', 'relu_dec1')
    
    fullyConnectedLayer(hiddenDim1, 'Name', 'fc_dec2')
    batchNormalizationLayer('Name', 'bn_dec2')
    reluLayer('Name', 'relu_dec2')
    dropoutLayer(0.2, 'Name', 'dropout_dec1')
    
    fullyConnectedLayer(inputDim, 'Name', 'output')
    regressionLayer('Name', 'regression')
];

% Combine encoder + decoder
layers = [encoderLayers; decoderLayers];
