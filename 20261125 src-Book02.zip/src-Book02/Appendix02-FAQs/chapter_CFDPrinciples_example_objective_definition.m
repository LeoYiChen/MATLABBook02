%% chapter_CFDPrinciples_example_objective_definition.m
% Problem definition and physics regime identification.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_objective_definition
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function problemSpec = defineFlowProblem(objectiveType, fluidProperties, ...
    flowConditions, geometryParams)
    % DEFINEFLOWPROBLEM Systematic CFD problem specification
    % Establishes objectives, dimensionless parameters, and physics regime
    %
    % Inputs:
    %   objectiveType    - String: 'drag_minimisation', 'heat_transfer', 
    %                      'pressure_drop', 'mixing_efficiency'
    %   fluidProperties  - Struct with fields: density, viscosity, 
    %                      specificHeat, thermalConductivity
    %   flowConditions   - Struct with fields: velocity, temperature, 
    %                      pressure, characteristicLength
    %   geometryParams   - Struct with geometry-specific parameters
    %
    % Output:
    %   problemSpec      - Comprehensive problem specification structure
    %
    % Author: Dr Leo Chen
    % Institution: University of Oxford
    % Version: 3.0
    % MATLAB Version: R2023b and later
    %
    % References:
    %   [1] Ferziger & Peric (2002) Computational Methods for Fluid Dynamics
    %   [2] Versteeg & Malalasekera (2007) Introduction to CFD
    
    fprintf('=== CFD Problem Definition ===\n\n');
    
    % Initialise problem specification structure
    problemSpec = struct();
    problemSpec.objective = objectiveType;
    problemSpec.fluidProperties = fluidProperties;
    problemSpec.flowConditions = flowConditions;
    problemSpec.geometryParams = geometryParams;
    
    % Calculate dimensionless parameters
    dimensionlessParams = computeDimensionlessNumbers(fluidProperties, flowConditions);
    problemSpec.dimensionlessParams = dimensionlessParams;
    
    % Identify flow regime
    flowRegime = identifyFlowRegime(dimensionlessParams);
    problemSpec.flowRegime = flowRegime;
    
    % Select governing equations
    governingEqs = selectGoverningEquations(flowRegime, objectiveType);
    problemSpec.governingEquations = governingEqs;
    
    % Define quantitative success criteria
    successCriteria = defineSuccessCriteria(objectiveType, flowConditions);
    problemSpec.successCriteria = successCriteria;
    
    % Display summary
    displayProblemSummary(problemSpec);
    
    fprintf('\nProblem definition completed successfully.\n');
end

function dimParams = computeDimensionlessNumbers(fluidProps, flowConds)
    % Compute fundamental dimensionless parameters
    
    dimParams = struct();
    
    % Reynolds number
    dimParams.Re = fluidProps.density * flowConds.velocity * ...
                   flowConds.characteristicLength / fluidProps.viscosity;
    
    % Mach number (if speed of sound provided)
    if isfield(flowConds, 'speedOfSound')
        dimParams.Ma = flowConds.velocity / flowConds.speedOfSound;
    elseif isfield(fluidProps, 'specificHeatRatio')
        % Estimate from ideal gas relation
        R = 287;  % Specific gas constant for air (J/kg/K)
        gamma = fluidProps.specificHeatRatio;
        c = sqrt(gamma * R * flowConds.temperature);
        dimParams.Ma = flowConds.velocity / c;
    else
        dimParams.Ma = NaN;
    end
    
    % Prandtl number (thermal/momentum diffusivity ratio)
    if isfield(fluidProps, 'specificHeat') && ...
       isfield(fluidProps, 'thermalConductivity')
        dimParams.Pr = fluidProps.viscosity * fluidProps.specificHeat / ...
                       fluidProps.thermalConductivity;
    else
        dimParams.Pr = NaN;
    end
    
    % Grashof number (buoyancy/viscous forces) if temperature difference specified
    if isfield(flowConds, 'temperatureDifference') && ...
       isfield(fluidProps, 'thermalExpansion')
        g = 9.81;  % Gravitational acceleration (m/s^2)
        dimParams.Gr = g * fluidProps.thermalExpansion * ...
                       flowConds.temperatureDifference * ...
                       flowConds.characteristicLength^3 / ...
                       (fluidProps.viscosity / fluidProps.density)^2;
    else
        dimParams.Gr = NaN;
    end
    
    % Rayleigh number (natural convection)
    if ~isnan(dimParams.Gr) && ~isnan(dimParams.Pr)
        dimParams.Ra = dimParams.Gr * dimParams.Pr;
    else
        dimParams.Ra = NaN;
    end
    
    % Froude number (inertia/gravity) if relevant
    if isfield(flowConds, 'gravitationalEffect') && flowConds.gravitationalEffect
        g = 9.81;
        dimParams.Fr = flowConds.velocity / ...
                       sqrt(g * flowConds.characteristicLength);
    else
        dimParams.Fr = NaN;
    end
end

function regime = identifyFlowRegime(dimParams)
    % Identify flow regime from dimensionless parameters
    
    regime = struct();
    
    % Compressibility classification
    if isnan(dimParams.Ma)
        regime.compressibility = 'unknown';
    elseif dimParams.Ma < 0.3
        regime.compressibility = 'incompressible';
    elseif dimParams.Ma < 0.8
        regime.compressibility = 'compressible_subsonic';
    elseif dimParams.Ma < 1.2
        regime.compressibility = 'transonic';
    elseif dimParams.Ma < 5.0
        regime.compressibility = 'supersonic';
    else
        regime.compressibility = 'hypersonic';
    end
    
    % Turbulence classification
    if dimParams.Re < 2300
        regime.turbulence = 'laminar';
    elseif dimParams.Re < 4000
        regime.turbulence = 'transitional';
    else
        regime.turbulence = 'turbulent';
    end
    
    % Thermal regime (if applicable)
    if ~isnan(dimParams.Ra)
        if dimParams.Ra < 1e8
            regime.thermalConvection = 'forced_or_laminar_natural';
        else
            regime.thermalConvection = 'turbulent_natural';
        end
    else
        regime.thermalConvection = 'not_applicable';
    end
    
    % Combined regime descriptor
    regime.description = sprintf('%s, %s flow', ...
                                 regime.compressibility, regime.turbulence);
end

function govEqs = selectGoverningEquations(flowRegime, objectiveType)
    % Select appropriate governing equations based on regime and objective
    
    govEqs = struct();
    
    % Continuity equation (always required)
    govEqs.continuity = 'mass_conservation';
    
    % Momentum equations
    if strcmp(flowRegime.turbulence, 'laminar')
        govEqs.momentum = 'Navier_Stokes_laminar';
    else
        govEqs.momentum = 'Reynolds_Averaged_Navier_Stokes';
        govEqs.turbulenceModel = 'required';
    end
    
    % Energy equation (if thermal objective)
    if contains(objectiveType, 'heat') || contains(objectiveType, 'thermal')
        if strcmp(flowRegime.compressibility, 'incompressible')
            govEqs.energy = 'scalar_transport_temperature';
        else
            govEqs.energy = 'total_energy_compressible';
        end
    else
        govEqs.energy = 'not_required';
    end
    
    % Equation of state
    if strcmp(flowRegime.compressibility, 'incompressible')
        govEqs.equationOfState = 'constant_density';
    else
        govEqs.equationOfState = 'ideal_gas_law';
    end
    
    % Additional transport equations
    govEqs.additionalTransport = {};
    
    if strcmp(govEqs.turbulenceModel, 'required')
        govEqs.additionalTransport{end+1} = 'turbulent_kinetic_energy';
        govEqs.additionalTransport{end+1} = 'turbulent_dissipation';
    end
end

function criteria = defineSuccessCriteria(objectiveType, flowConditions)
    % Define quantitative success criteria for simulation
    
    criteria = struct();
    criteria.objectiveType = objectiveType;
    
    switch objectiveType
        case 'drag_minimisation'
            criteria.primaryMetric = 'drag_coefficient';
            criteria.targetValue = 'minimise';
            criteria.convergenceTolerance = 1e-4;  % Relative change
            criteria.validationRequirement = 'compare_with_experimental_Cd';
            
        case 'heat_transfer'
            criteria.primaryMetric = 'Nusselt_number';
            criteria.targetValue = 'maximise';
            criteria.convergenceTolerance = 1e-4;
            criteria.validationRequirement = 'compare_with_correlation';
            
        case 'pressure_drop'
            criteria.primaryMetric = 'pressure_drop_Pa';
            criteria.targetValue = 'minimise';
            criteria.convergenceTolerance = 1e-3;
            criteria.validationRequirement = 'compare_with_measurement';
            
        case 'mixing_efficiency'
            criteria.primaryMetric = 'mixing_index';
            criteria.targetValue = 'maximise';
            criteria.convergenceTolerance = 1e-3;
            criteria.validationRequirement = 'flow_visualisation_comparison';
            
        otherwise
            warning('Unknown objective type. Using default criteria.');
            criteria.primaryMetric = 'user_defined';
            criteria.targetValue = 'user_specified';
            criteria.convergenceTolerance = 1e-3;
    end
    
    % Residual convergence criteria (universal)
    criteria.residualCriteria = struct();
    criteria.residualCriteria.continuity = 1e-4;
    criteria.residualCriteria.momentum = 1e-5;
    criteria.residualCriteria.energy = 1e-6;
    criteria.residualCriteria.turbulence = 1e-4;
end

function displayProblemSummary(problemSpec)
    % Display comprehensive problem summary
    
    fprintf('Objective: %s\n', problemSpec.objective);
    fprintf('\nDimensionless Parameters:\n');
    fprintf('  Reynolds number: %.2e\n', problemSpec.dimensionlessParams.Re);
    
    if ~isnan(problemSpec.dimensionlessParams.Ma)
        fprintf('  Mach number: %.4f\n', problemSpec.dimensionlessParams.Ma);
    end
    
    if ~isnan(problemSpec.dimensionlessParams.Pr)
        fprintf('  Prandtl number: %.4f\n', problemSpec.dimensionlessParams.Pr);
    end
    
    fprintf('\nFlow Regime:\n');
    fprintf('  %s\n', problemSpec.flowRegime.description);
    
    fprintf('\nGoverning Equations:\n');
    fprintf('  Continuity: %s\n', problemSpec.governingEquations.continuity);
    fprintf('  Momentum: %s\n', problemSpec.governingEquations.momentum);
    fprintf('  Energy: %s\n', problemSpec.governingEquations.energy);
    
    fprintf('\nSuccess Criteria:\n');
    fprintf('  Primary metric: %s\n', problemSpec.successCriteria.primaryMetric);
    fprintf('  Target: %s\n', problemSpec.successCriteria.targetValue);
    fprintf('  Convergence tolerance: %.1e\n', ...
            problemSpec.successCriteria.convergenceTolerance);
end
