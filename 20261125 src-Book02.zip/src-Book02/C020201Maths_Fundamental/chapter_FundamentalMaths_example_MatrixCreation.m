%% chapter_FundamentalMaths_example_MatrixCreation.m
% Comprehensive matrix creation and indexing operations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_MatrixCreation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_LinearAlgebra_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates various matrix creation methods and indexing
%              operations fundamental to MATLAB programming.

function demonstrateMatrixCreation()
    fprintf('Matrix Creation and Indexing in MATLAB\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Direct matrix assignment
    demonstrateDirectAssignment();
    
    % Part 2: Built-in constructor functions
    demonstrateBuiltInConstructors();
    
    % Part 3: Advanced indexing techniques
    demonstrateAdvancedIndexing();
    
    % Part 4: Matrix concatenation
    demonstrateConcatenation();
    
    % Part 5: Logical indexing
    demonstrateLogicalIndexing();
end

function demonstrateDirectAssignment()
    fprintf('Part 1: Direct Matrix Assignment\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create matrix using explicit element specification
    A = [1, 2, 3; 4, 5, 6; 7, 8, 9];
    
    fprintf('Matrix A created using direct assignment:\n');
    disp(A);
    
    % Matrix properties
    [rows, cols] = size(A);
    fprintf('Matrix dimensions: %d rows $\times$ %d columns\n', rows, cols);
    fprintf('Total elements: %d\n', numel(A));
    fprintf('Matrix class: %s\n\n', class(A));
    
    % Create column vector
    v = [1; 2; 3; 4; 5];
    fprintf('Column vector v:\n');
    disp(v);
    
    % Create row vector
    w = [1, 2, 3, 4, 5];
    fprintf('Row vector w:\n');
    disp(w);
    fprintf('\n');
end

function demonstrateBuiltInConstructors()
    fprintf('Part 2: Built-in Constructor Functions\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Zero matrix
    Z = zeros(3, 4);
    fprintf('Zero matrix (3$\times$4):\n');
    disp(Z);
    
    % Ones matrix
    O = ones(2, 5);
    fprintf('Ones matrix (2$\times$5):\n');
    disp(O);
    
    % Identity matrix
    I = eye(4);
    fprintf('Identity matrix (4$\times$4):\n');
    disp(I);
    
    % Random uniform matrix
    rng(42); % Set random seed for reproducibility
    R = rand(3, 3);
    fprintf('Random uniform matrix (3$\times$3) with values in [0,1]:\n');
    disp(R);
    
    % Random normal matrix
    N = randn(3, 3);
    fprintf('Random normal matrix (3$\times$3) from N(0,1):\n');
    disp(N);
    
    % Diagonal matrix
    D = diag([1, 2, 3, 4]);
    fprintf('Diagonal matrix from vector:\n');
    disp(D);
    
    % Upper triangular matrix
    U = triu(ones(4, 4));
    fprintf('Upper triangular matrix:\n');
    disp(U);
    
    % Lower triangular matrix
    L = tril(ones(4, 4));
    fprintf('Lower triangular matrix:\n');
    disp(L);
    fprintf('\n');
end

function demonstrateAdvancedIndexing()
    fprintf('Part 3: Advanced Indexing Techniques\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create sample matrix
    A = magic(5); % 5$\times$5 magic square
    fprintf('Sample matrix A (magic square):\n');
    disp(A);
    
    % Single element extraction
    element = A(2, 3);
    fprintf('Element A(2,3): %d\n', element);
    
    % Row extraction
    row2 = A(2, :);
    fprintf('Second row A(2,:): ');
    disp(row2);
    
    % Column extraction
    col3 = A(:, 3);
    fprintf('Third column A(:,3):\n');
    disp(col3);
    
    % Submatrix extraction
    submat = A(2:4, 1:3);
    fprintf('Submatrix A(2:4, 1:3):\n');
    disp(submat);
    
    % Diagonal extraction
    mainDiag = diag(A);
    fprintf('Main diagonal:\n');
    disp(mainDiag);
    
    % Anti-diagonal extraction
    antiDiag = diag(fliplr(A));
    fprintf('Anti-diagonal:\n');
    disp(antiDiag);
    
    % Linear indexing (column-major order)
    element_linear = A(7); % 7*th element in column-major order
    fprintf('Element A(7) using linear indexing: %d\n', element_linear);
    fprintf('This corresponds to A(2,2) in subscript notation\n');
    
    % Multiple element extraction using index vectors
    indices = [1, 3, 5];
    selectedRows = A(indices, :);
    fprintf('Selected rows [1,3,5]:\n');
    disp(selectedRows);
    fprintf('\n');
end

function demonstrateConcatenation()
    fprintf('Part 4: Matrix Concatenation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create component matrices
    A = [1, 2; 3, 4];
    B = [5, 6; 7, 8];
    C = [9; 10];
    
    fprintf('Matrix A:\n');
    disp(A);
    fprintf('Matrix B:\n');
    disp(B);
    fprintf('Vector C:\n');
    disp(C);
    
    % Horizontal concatenation
    H = [A, B];
    fprintf('Horizontal concatenation [A, B]:\n');
    disp(H);
    
    % Vertical concatenation
    V = [A; B];
    fprintf('Vertical concatenation [A; B]:\n');
    disp(V);
    
    % Combined concatenation
    Combined = [A, C; B, C];
    fprintf('Combined concatenation [A, C; B, C]:\n');
    disp(Combined);
    
    % Using cat function
    H2 = cat(2, A, B); % Concatenate along dimension 2 (columns)
    fprintf('Using cat(2, A, B) - horizontal:\n');
    disp(H2);
    
    V2 = cat(1, A, B); % Concatenate along dimension 1 (rows)
    fprintf('Using cat(1, A, B) - vertical:\n');
    disp(V2);
    fprintf('\n');
end

function demonstrateLogicalIndexing()
    fprintf('Part 5: Logical Indexing\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create sample matrix
    A = [12, 5, 8, 3; 7, 15, 4, 11; 9, 2, 13, 6];
    fprintf('Sample matrix A:\n');
    disp(A);
    
    % Find elements greater than 8
    mask = A > 8;
    fprintf('Logical mask (A > 8):\n');
    disp(mask);
    
    % Extract elements satisfying condition
    largeElements = A(A > 8);
    fprintf('Elements greater than 8:\n');
    disp(largeElements);
    
    % Replace elements
    A_modified = A;
    A_modified(A_modified > 10) = 10; % Cap values at 10
    fprintf('Matrix after capping values at 10:\n');
    disp(A_modified);
    
    % Find elements in range
    inRange = A(A >= 5 & A <= 10);
    fprintf('Elements in range [5, 10]:\n');
    disp(inRange);
    
    % Find row and column indices
    [rows, cols] = find(A > 10);
    fprintf('Positions where A > 10:\n');
    for k = 1:length(rows)
        fprintf('  A(%d,%d) = %d\n', rows(k), cols(k), A(rows(k), cols(k)));
    end
    fprintf('\n');
end
