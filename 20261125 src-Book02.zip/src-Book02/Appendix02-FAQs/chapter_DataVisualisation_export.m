%% chapter_DataVisualisation_export.m
% Figure Export Function
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_export
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function exportFigure(h, basename)
% Input validation
if nargin < 2
basename = 'figure';
end

% Ensure output directory exists
if ~exist('figures', 'dir')
    mkdir('figures');
end

% Base path for output
basepath = fullfile('figures', basename);

% Vector format for publication (EPS)
print(h, [basepath '.eps'], '-depsc2', '-r300');

% Raster formats for presentations/web
print(h, [basepath '.png'], '-dpng', '-r300');
print(h, [basepath '.jpg'], '-djpeg', '-r300');

% Optional PDF format
print(h, [basepath '.pdf'], '-dpdf', '-r300');

fprintf('Figures saved to %s.[eps/png/jpg/pdf]\n', basepath);

end
