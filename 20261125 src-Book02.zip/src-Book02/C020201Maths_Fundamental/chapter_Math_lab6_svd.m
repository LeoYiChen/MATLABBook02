%% chapter_Math_lab6_svd.m
% Image Compression via SVD
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab6_svd
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory
Lab6_ImageCompression();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab6_ImageCompression()
    % LAB6_IMAGECOMPRESSION Analyse image compression using SVD
    %   Demonstrates low-rank approximation and compression ratios
    
    % Load grayscale image (or convert RGB to grayscale)
    img = imread('cameraman.tif');  % Standard MATLAB test image
    
    % Convert to double for computation
    A = double(img);
    [m, n] = size(A);
    
    fprintf('Original image dimensions: %d x %d\n', m, n);
    fprintf('Original data points: %d\n', m*n);
    
    % Perform SVD
    fprintf('\nPerforming Singular Value Decomposition...\n');
    tic;
    [U, S, V] = svd(A);
    svd_time = toc;
    fprintf('SVD computation time: %.4f seconds\n', svd_time);
    
    % Extract singular values
    singularValues = diag(S);
    rank_A = sum(singularValues > 1e-10);  % Numerical rank
    fprintf('Matrix rank: %d\n', rank_A);
    
    % Analyse energy distribution
    totalEnergy = sum(singularValues.^2);
    cumulativeEnergy = cumsum(singularValues.^2) / totalEnergy;
    
    % Find number of singular values for 90%, 95%, 99% energy
    k_90 = find(cumulativeEnergy >= 0.90, 1);
    k_95 = find(cumulativeEnergy >= 0.95, 1);
    k_99 = find(cumulativeEnergy >= 0.99, 1);
    
    fprintf('\nEnergy Retention Analysis:\n');
    fprintf('  90%% energy retained with %d singular values (%.1f%% of rank)\n', ...
        k_90, 100*k_90/rank_A);
    fprintf('  95%% energy retained with %d singular values (%.1f%% of rank)\n', ...
        k_95, 100*k_95/rank_A);
    fprintf('  99%% energy retained with %d singular values (%.1f%% of rank)\n', ...
        k_99, 100*k_99/rank_A);
    
    % Reconstruct images with varying numbers of singular values
    k_values = [1, 5, 10, 20, 50, 100, rank_A];
    reconstructions = cell(length(k_values), 1);
    compressionRatios = zeros(length(k_values), 1);
    rmseErrors = zeros(length(k_values), 1);
    psnrValues = zeros(length(k_values), 1);
    
    for i = 1:length(k_values)
        k = min(k_values(i), rank_A);
        
        % Low-rank approximation
        A_k = U(:, 1:k) * S(1:k, 1:k) * V(:, 1:k)';
        reconstructions{i} = A_k;
        
        % Storage requirements
        % Original: m*n elements
        % Compressed: k*(m + n + 1) elements (U(:,1:k), S(1:k,1:k), V(:,1:k))
        original_storage = m * n;
        compressed_storage = k * (m + n + 1);
        compressionRatios(i) = original_storage / compressed_storage;
        
        % Error metrics
        rmseErrors(i) = sqrt(mean((A(:) - A_k(:)).^2));
        
        % Peak Signal-to-Noise Ratio
        maxValue = max(A(:));
        mseVal = mean((A(:) - A_k(:)).^2);
        psnrValues(i) = 10 * log10(maxValue^2 / mseVal);
        
        fprintf('\nRank-%d Approximation:\n', k);
        fprintf('  Compression ratio: %.2f:1\n', compressionRatios(i));
        fprintf('  RMSE: %.4f\n', rmseErrors(i));
        fprintf('  PSNR: %.2f dB\n', psnrValues(i));
        fprintf('  Energy retained: %.2f%%\n', 100*cumulativeEnergy(k));
    end
    
    % Visualisation
    visualiseResults(A, reconstructions, k_values, singularValues, ...
        cumulativeEnergy, compressionRatios, rmseErrors, psnrValues);
end

function visualiseResults(original, reconstructions, k_values, ...
    singularValues, cumulativeEnergy, compressionRatios, rmseErrors, psnrValues)
    % VISUALISERESULTS Create comprehensive visualisation of results
    
    % Figure 1: Image reconstructions
    figure('Position', [100, 100, 1200, 800], 'Name', 'SVD Image Compression');
    
    % Display original and reconstructions
    numImages = length(reconstructions) + 1;
    rows = ceil(sqrt(numImages));
    cols = ceil(numImages / rows);
    
    subplot(rows, cols, 1);
    imshow(uint8(original));
    title('Original Image', 'FontSize', 12, 'Interpreter', 'latex');
    
    for i = 1:length(reconstructions)
        subplot(rows, cols, i + 1);
        imshow(uint8(reconstructions{i}));
        if k_values(i) < length(singularValues)
            title(sprintf('Rank-%d Approximation', k_values(i)), ...
                'FontSize', 12, 'Interpreter', 'latex');
        else
            title('Full Rank (Original)', 'FontSize', 12, 'Interpreter', 'latex');
        end
    end
    
    % Figure 2: Singular value spectrum
    figure('Position', [150, 150, 1200, 400], 'Name', 'SVD Analysis');
    
    subplot(1, 3, 1);
    semilogy(singularValues, 'b-', 'LineWidth', 2);
    hold on;
    semilogy(k_values(1:end-1), singularValues(k_values(1:end-1)), ...
        'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    grid on;
    xlabel('Index $i$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Singular Value $\sigma_i$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Singular Value Spectrum', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Singular Values', 'Approximation Ranks', 'Interpreter', 'latex', ...
        'Location', 'best');
    
    subplot(1, 3, 2);
    plot(1:length(cumulativeEnergy), 100*cumulativeEnergy, 'b-', 'LineWidth', 2);
    hold on;
    yline(90, 'r-', '90\%', 'LineWidth', 1.5, 'LabelHorizontalAlignment', 'left');
    yline(95, 'g-', '95\%', 'LineWidth', 1.5, 'LabelHorizontalAlignment', 'left');
    yline(99, 'm-', '99\%', 'LineWidth', 1.5, 'LabelHorizontalAlignment', 'left');
    grid on;
    xlabel('Number of Singular Values', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Cumulative Energy (\%)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Energy Retention', 'Interpreter', 'latex', 'FontSize', 14);
    xlim([0, length(cumulativeEnergy)]);
    ylim([0, 105]);
    
    subplot(1, 3, 3);
    yyaxis left;
    plot(k_values(1:end-1), compressionRatios(1:end-1), 'b-o', ...
        'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'b');
    ylabel('Compression Ratio', 'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    
    yyaxis right;
    plot(k_values(1:end-1), psnrValues(1:end-1), 'r-s', ...
        'LineWidth', 2, 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    ylabel('PSNR (dB)', 'Interpreter', 'latex', 'FontSize', 12);
    
    xlabel('Rank $k$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Compression vs. Quality Trade-off', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Compression Ratio', 'PSNR', 'Interpreter', 'latex', 'Location', 'best');
end
