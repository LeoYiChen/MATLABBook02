%% chapter_Numerical_syntax_bisection.m
% Bisection method syntax structure.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Numerical_syntax_bisection
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function root = bisectionMethod(func, leftBound, rightBound, tolerance)
% Implements bisection method for root finding
% Requires: func(leftBound) * func(rightBound) < 0
while (rightBound - leftBound) > tolerance
    midpoint = (leftBound + rightBound) / 2;
    if func(leftBound) * func(midpoint) < 0
        rightBound = midpoint;
    else
        leftBound = midpoint;
    end
end
root = (leftBound + rightBound) / 2;
end
