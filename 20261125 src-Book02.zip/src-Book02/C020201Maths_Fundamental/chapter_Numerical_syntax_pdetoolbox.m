%% chapter_Numerical_syntax_pdetoolbox.m
% Heat equation using PDE Toolbox.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Numerical_syntax_pdetoolbox
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create thermal model
thermalModel = createpde('thermal', 'transient');

% Define geometry (unit square)
geometryFromEdges(thermalModel, @squareg);

% Generate mesh
generateMesh(thermalModel, 'Hmax', 0.05);

% Set thermal properties
thermalProperties(thermalModel, 'ThermalConductivity', alpha, ...
    'MassDensity', 1, 'SpecificHeat', 1);

% Apply boundary conditions
thermalBC(thermalModel, 'Edge', 1:4, 'Temperature', 0);

% Set initial conditions
thermalIC(thermalModel, @(location) sin(pi*location.x));

% Solve
tlist = 0:0.01:0.5;
results = solve(thermalModel, tlist);

% Visualise
pdeplot(thermalModel, 'XYData', results.Temperature(:,end));
