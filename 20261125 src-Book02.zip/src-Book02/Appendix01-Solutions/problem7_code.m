%% problem7_code.m
% Intersectional Fairness in Building Energy Management
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem7_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Intersectional Fairness Analysis for Smart Building Energy Management
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-17
% Description: Implements intersectional fairness analysis for HVAC control
%              evaluating thermal comfort equity across multiple demographics

clear; close all; clc;

%% 1. Building Occupancy and Demographics Model
fprintf('========================================\n');
fprintf('Intersectional Fairness - Building Energy Management\n');
fprintf('========================================\n\n');

fprintf('Step 1: Generating occupant demographics and preferences...\n');

rng(987); % Reproducibility

numOccupants = 100;

% Demographic attributes
incomeCategories = {'Low', 'Medium', 'High'};
ageCategories = {'Young', 'Middle', 'Senior'};
genderCategories = {'Male', 'Female'};

% Random assignment with controlled distribution
incomeLevel = randi([1, 3], numOccupants, 1); % 1-Low, 2-Medium, 3-High
ageGroup = randi([1, 3], numOccupants, 1);    % 1-Young, 2-Middle, 3-Senior
gender = randi([1, 2], numOccupants, 1);      % 1-Male, 2-Female

% Thermal preference model (temperature in Celsius)
% Base preference: 22 C
% Adjustments: seniors prefer warmer (+1 C), females prefer warmer (+0.5 C)
% Low income less flexible (narrower comfort range)

thermalPreference = 22 * ones(numOccupants, 1);

for occupantIdx = 1:numOccupants
    % Age adjustment
    if ageGroup(occupantIdx) == 3 % Senior
        thermalPreference(occupantIdx) = thermalPreference(occupantIdx) + 1.0;
    end
    
    % Gender adjustment
    if gender(occupantIdx) == 2 % Female
        thermalPreference(occupantIdx) = thermalPreference(occupantIdx) + 0.5;
    end
    
    % Add individual variation
    thermalPreference(occupantIdx) = thermalPreference(occupantIdx) + 0.5 * randn();
end

% Comfort tolerance (acceptable deviation from preference)
comfortTolerance = ones(numOccupants, 1);

for occupantIdx = 1:numOccupants
    if incomeLevel(occupantIdx) == 1 % Low income: less flexible
        comfortTolerance(occupantIdx) = 0.8;
    elseif incomeLevel(occupantIdx) == 3 % High income: more flexible
        comfortTolerance(occupantIdx) = 1.2;
    end
end

fprintf('Occupant Demographics:\n');
fprintf('  Total occupants: %d\n', numOccupants);
fprintf('  Income distribution: Low=%d, Medium=%d, High=%d\n', ...
        sum(incomeLevel == 1), sum(incomeLevel == 2), sum(incomeLevel == 3));
fprintf('  Age distribution: Young=%d, Middle=%d, Senior=%d\n', ...
        sum(ageGroup == 1), sum(ageGroup == 2), sum(ageGroup == 3));
fprintf('  Gender distribution: Male=%d, Female=%d\n', ...
        sum(gender == 1), sum(gender == 2));
fprintf('  Thermal preferences: Mean=%.2f C, Range=[%.2f, %.2f] C\n\n', ...
        mean(thermalPreference), min(thermalPreference), max(thermalPreference));

%% 2. Baseline Energy-Minimising HVAC Control
fprintf('Step 2: Simulating baseline energy-minimising HVAC control...\n');

% Simulation parameters
numHours = 168; % One week
outdoorTemp = 15 + 5 * sin(2 * pi * (1:numHours) / 24); % Diurnal outdoor temperature

% Baseline controller: maintain building at average preferred temperature
targetTemp = mean(thermalPreference);

% Simplified energy model: energy = k * |T_indoor - T_outdoor|
energyCoefficient = 0.5; % kWh per degree-hour

indoorTempBaseline = targetTemp * ones(1, numHours);
energyConsumptionBaseline = zeros(1, numHours);

for hour = 1:numHours
    energyConsumptionBaseline(hour) = energyCoefficient * ...
                                      abs(indoorTempBaseline(hour) - outdoorTemp(hour)) * ...
                                      numOccupants;
end

totalEnergyBaseline = sum(energyConsumptionBaseline);

% Compute comfort satisfaction for each occupant
comfortSatisfactionBaseline = zeros(numOccupants, numHours);

for occupantIdx = 1:numOccupants
    for hour = 1:numHours
        tempDeviation = abs(indoorTempBaseline(hour) - thermalPreference(occupantIdx));
        if tempDeviation <= comfortTolerance(occupantIdx)
            comfortSatisfactionBaseline(occupantIdx, hour) = 1; % Satisfied
        else
            comfortSatisfactionBaseline(occupantIdx, hour) = 0; % Dissatisfied
        end
    end
end

% Overall comfort (percentage time satisfied)
overallComfortBaseline = mean(comfortSatisfactionBaseline(:));

fprintf('Baseline HVAC Control:\n');
fprintf('  Target temperature: %.2f C (occupant average)\n', targetTemp);
fprintf('  Total energy consumption: %.2f kWh\n', totalEnergyBaseline);
fprintf('  Overall comfort satisfaction: %.2f%%\n\n', overallComfortBaseline * 100);

%% 3. Single-Attribute Fairness Analysis
fprintf('Step 3: Analysing fairness across individual demographic attributes...\n');

% Compute comfort by income level
comfortByIncome = zeros(3, 1);
for incomeIdx = 1:3
    incomeMask = incomeLevel == incomeIdx;
    comfortByIncome(incomeIdx) = mean(comfortSatisfactionBaseline(incomeMask, :), 'all');
end

% Compute comfort by age group
comfortByAge = zeros(3, 1);
for ageIdx = 1:3
    ageMask = ageGroup == ageIdx;
    comfortByAge(ageIdx) = mean(comfortSatisfactionBaseline(ageMask, :), 'all');
end

% Compute comfort by gender
comfortByGender = zeros(2, 1);
for genderIdx = 1:2
    genderMask = gender == genderIdx;
    comfortByGender(genderIdx) = mean(comfortSatisfactionBaseline(genderMask, :), 'all');
end

fprintf('Single-Attribute Comfort Analysis:\n');
fprintf('  Income: Low=%.2f%%, Medium=%.2f%%, High=%.2f%% (disparity: %.2f pp)\n', ...
        comfortByIncome(1) * 100, comfortByIncome(2) * 100, comfortByIncome(3) * 100, ...
        (max(comfortByIncome) - min(comfortByIncome)) * 100);
fprintf('  Age: Young=%.2f%%, Middle=%.2f%%, Senior=%.2f%% (disparity: %.2f pp)\n', ...
        comfortByAge(1) * 100, comfortByAge(2) * 100, comfortByAge(3) * 100, ...
        (max(comfortByAge) - min(comfortByAge)) * 100);
fprintf('  Gender: Male=%.2f%%, Female=%.2f%% (disparity: %.2f pp)\n\n', ...
        comfortByGender(1) * 100, comfortByGender(2) * 100, ...
        abs(comfortByGender(1) - comfortByGender(2)) * 100);

%% 4. Intersectional Fairness Analysis
fprintf('Step 4: Conducting intersectional fairness analysis...\n');

% Create all intersectional subgroups (3 income   3 age   2 gender = 18)
intersectionalSubgroups = struct();
subgroupIdx = 1;

for incomeIdx = 1:3
    for ageIdx = 1:3
        for genderIdx = 1:2
            % Identify occupants in this intersectional subgroup
            subgroupMask = (incomeLevel == incomeIdx) & ...
                          (ageGroup == ageIdx) & ...
                          (gender == genderIdx);
            
            numInSubgroup = sum(subgroupMask);
            
            if numInSubgroup > 0
                subgroupComfort = mean(comfortSatisfactionBaseline(subgroupMask, :), 'all');
            else
                subgroupComfort = NaN; % Empty subgroup
            end
            
            intersectionalSubgroups(subgroupIdx).income = incomeCategories{incomeIdx};
            intersectionalSubgroups(subgroupIdx).age = ageCategories{ageIdx};
            intersectionalSubgroups(subgroupIdx).gender = genderCategories{genderIdx};
            intersectionalSubgroups(subgroupIdx).size = numInSubgroup;
            intersectionalSubgroups(subgroupIdx).comfort = subgroupComfort;
            intersectionalSubgroups(subgroupIdx).mask = subgroupMask;
            
            subgroupIdx = subgroupIdx + 1;
        end
    end
end

% Remove empty subgroups
validSubgroups = ~isnan([intersectionalSubgroups.comfort]);
intersectionalSubgroups = intersectionalSubgroups(validSubgroups);

numSubgroups = length(intersectionalSubgroups);

% Find most and least comfortable subgroups
[minComfort, minIdx] = min([intersectionalSubgroups.comfort]);
[maxComfort, maxIdx] = max([intersectionalSubgroups.comfort]);

fprintf('Intersectional Subgroup Analysis:\n');
fprintf('  Total subgroups: %d (with occupants)\n', numSubgroups);
fprintf('  Most comfortable: %s/%s/%s (%.2f%%)\n', ...
        intersectionalSubgroups(maxIdx).income, ...
        intersectionalSubgroups(maxIdx).age, ...
        intersectionalSubgroups(maxIdx).gender, ...
        maxComfort * 100);
fprintf('  Least comfortable: %s/%s/%s (%.2f%%)\n', ...
        intersectionalSubgroups(minIdx).income, ...
        intersectionalSubgroups(minIdx).age, ...
        intersectionalSubgroups(minIdx).gender, ...
        minComfort * 100);
fprintf('  Intersectional disparity: %.2f percentage points\n', ...
        (maxComfort - minComfort) * 100);

% Compare to maximum single-attribute disparity
maxSingleDisparity = max([(max(comfortByIncome) - min(comfortByIncome)), ...
                          (max(comfortByAge) - min(comfortByAge)), ...
                          abs(comfortByGender(1) - comfortByGender(2))]);

fprintf('  Single-attribute max disparity: %.2f pp\n', maxSingleDisparity * 100);
fprintf('  Intersectional amplification: %.2fx\n\n', ...
        (maxComfort - minComfort) / maxSingleDisparity);

%% 5. Intersectionality-Aware Fairness Intervention
fprintf('Step 5: Implementing subgroup reweighting intervention...\n');

% Assign weights inversely proportional to baseline comfort
subgroupWeights = zeros(numSubgroups, 1);

for subgroupIdx = 1:numSubgroups
    % Weight = 1 / comfort (higher weight for disadvantaged groups)
    subgroupWeights(subgroupIdx) = 1 / intersectionalSubgroups(subgroupIdx).comfort;
end

% Normalise weights
subgroupWeights = subgroupWeights / sum(subgroupWeights);

% Reweighted target temperature
targetTempReweighted = 0;

for subgroupIdx = 1:numSubgroups
    subgroupMask = intersectionalSubgroups(subgroupIdx).mask;
    subgroupPreference = mean(thermalPreference(subgroupMask));
    targetTempReweighted = targetTempReweighted + ...
                          subgroupWeights(subgroupIdx) * subgroupPreference;
end

% Simulate reweighted HVAC control
indoorTempReweighted = targetTempReweighted * ones(1, numHours);
energyConsumptionReweighted = zeros(1, numHours);

for hour = 1:numHours
    energyConsumptionReweighted(hour) = energyCoefficient * ...
                                        abs(indoorTempReweighted(hour) - outdoorTemp(hour)) * ...
                                        numOccupants;
end

totalEnergyReweighted = sum(energyConsumptionReweighted);

% Compute comfort under reweighted control
comfortSatisfactionReweighted = zeros(numOccupants, numHours);

for occupantIdx = 1:numOccupants
    for hour = 1:numHours
        tempDeviation = abs(indoorTempReweighted(hour) - thermalPreference(occupantIdx));
        if tempDeviation <= comfortTolerance(occupantIdx)
            comfortSatisfactionReweighted(occupantIdx, hour) = 1;
        else
            comfortSatisfactionReweighted(occupantIdx, hour) = 0;
        end
    end
end

overallComfortReweighted = mean(comfortSatisfactionReweighted(:));

% Recompute intersectional comfort
for subgroupIdx = 1:numSubgroups
    subgroupMask = intersectionalSubgroups(subgroupIdx).mask;
    intersectionalSubgroups(subgroupIdx).comfortReweighted = ...
        mean(comfortSatisfactionReweighted(subgroupMask, :), 'all');
end

[minComfortRW, minIdxRW] = min([intersectionalSubgroups.comfortReweighted]);
[maxComfortRW, maxIdxRW] = max([intersectionalSubgroups.comfortReweighted]);

fprintf('Reweighted HVAC Control:\n');
fprintf('  Target temperature: %.2f C (weighted by disadvantage)\n', targetTempReweighted);
fprintf('  Total energy consumption: %.2f kWh (%.2f%% vs baseline)\n', ...
        totalEnergyReweighted, (totalEnergyReweighted / totalEnergyBaseline - 1) * 100);
fprintf('  Overall comfort: %.2f%% (%.2f pp vs baseline)\n', ...
        overallComfortReweighted * 100, ...
        (overallComfortReweighted - overallComfortBaseline) * 100);
fprintf('  Intersectional disparity: %.2f pp (baseline: %.2f pp)\n', ...
        (maxComfortRW - minComfortRW) * 100, (maxComfort - minComfort) * 100);
fprintf('  Disparity reduction: %.2f%%\n\n', ...
        (1 - (maxComfortRW - minComfortRW) / (maxComfort - minComfort)) * 100);

%% 6. Constrained Fair Optimisation
fprintf('Step 6: Applying minimum comfort constraint for all subgroups...\n');

% Set minimum comfort threshold: 85% satisfaction for all subgroups
minComfortThreshold = 0.85;

% Find temperature maximising minimum subgroup comfort
% (Simplified: grid search over temperature range)
tempRange = 20:0.1:25;
minSubgroupComfort = zeros(size(tempRange));

for tempIdx = 1:length(tempRange)
    candidateTemp = tempRange(tempIdx);
    
    % Compute comfort for each subgroup at this temperature
    tempSubgroupComfort = zeros(numSubgroups, 1);
    
    for subgroupIdx = 1:numSubgroups
        subgroupMask = intersectionalSubgroups(subgroupIdx).mask;
        subgroupOccupants = find(subgroupMask);
        
        satisfactionCount = 0;
        totalCount = 0;
        
        for occupantIdx = subgroupOccupants'
            tempDeviation = abs(candidateTemp - thermalPreference(occupantIdx));
            if tempDeviation <= comfortTolerance(occupantIdx)
                satisfactionCount = satisfactionCount + 1;
            end
            totalCount = totalCount + 1;
        end
        
        tempSubgroupComfort(subgroupIdx) = satisfactionCount / totalCount;
    end
    
    % Store minimum subgroup comfort at this temperature
    minSubgroupComfort(tempIdx) = min(tempSubgroupComfort);
end

% Select temperature maximising minimum comfort (Rawlsian)
[maxMinComfort, optTempIdx] = max(minSubgroupComfort);
targetTempConstrained = tempRange(optTempIdx);

% Simulate constrained HVAC control
indoorTempConstrained = targetTempConstrained * ones(1, numHours);
energyConsumptionConstrained = zeros(1, numHours);

for hour = 1:numHours
    energyConsumptionConstrained(hour) = energyCoefficient * ...
                                        abs(indoorTempConstrained(hour) - outdoorTemp(hour)) * ...
                                        numOccupants;
end

totalEnergyConstrained = sum(energyConsumptionConstrained);

% Compute comfort under constrained control
comfortSatisfactionConstrained = zeros(numOccupants, numHours);

for occupantIdx = 1:numOccupants
    for hour = 1:numHours
        tempDeviation = abs(indoorTempConstrained(hour) - thermalPreference(occupantIdx));
        if tempDeviation <= comfortTolerance(occupantIdx)
            comfortSatisfactionConstrained(occupantIdx, hour) = 1;
        else
            comfortSatisfactionConstrained(occupantIdx, hour) = 0;
        end
    end
end

overallComfortConstrained = mean(comfortSatisfactionConstrained(:));

% Recompute intersectional comfort
for subgroupIdx = 1:numSubgroups
    subgroupMask = intersectionalSubgroups(subgroupIdx).mask;
    intersectionalSubgroups(subgroupIdx).comfortConstrained = ...
        mean(comfortSatisfactionConstrained(subgroupMask, :), 'all');
end

minComfortConstr = min([intersectionalSubgroups.comfortConstrained]);
maxComfortConstr = max([intersectionalSubgroups.comfortConstrained]);

fprintf('Constrained Fair HVAC Control:\n');
fprintf('  Target temperature: %.2f C (maximin optimisation)\n', targetTempConstrained);
fprintf('  Total energy consumption: %.2f kWh (%.2f%% vs baseline)\n', ...
        totalEnergyConstrained, (totalEnergyConstrained / totalEnergyBaseline - 1) * 100);
fprintf('  Overall comfort: %.2f%%\n', overallComfortConstrained * 100);
fprintf('  Minimum subgroup comfort: %.2f%% (target: %.2f%%)\n', ...
        minComfortConstr * 100, minComfortThreshold * 100);
fprintf('  Intersectional disparity: %.2f pp\n\n', ...
        (maxComfortConstr - minComfortConstr) * 100);

%% 7. Visualisation
fprintf('Step 7: Generating visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: Single-Attribute vs Intersectional Disparity
fig1 = figure('Position', [100, 100, 1400, 500]);

subplot(1, 3, 1);
bar(categorical(incomeCategories), comfortByIncome * 100);
ylabel('Comfort Satisfaction (\%)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Comfort by Income}', 'Interpreter', 'latex', 'FontSize', 11);
grid on;
ylim([70, 100]);

subplot(1, 3, 2);
bar(categorical(ageCategories), comfortByAge * 100);
ylabel('Comfort Satisfaction (\%)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Comfort by Age}', 'Interpreter', 'latex', 'FontSize', 11);
grid on;
ylim([70, 100]);

subplot(1, 3, 3);
bar(categorical(genderCategories), comfortByGender * 100);
ylabel('Comfort Satisfaction (\%)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Comfort by Gender}', 'Interpreter', 'latex', 'FontSize', 11);
grid on;
ylim([70, 100]);

sgtitle('\textbf{Single-Attribute Fairness Analysis (Baseline)}', ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig1, 'figures/Problem7_Single_Attribute.fig');
saveas(fig1, 'figures/Problem7_Single_Attribute.eps', 'epsc');
saveas(fig1, 'figures/Problem7_Single_Attribute.jpg');
fprintf('Saved: Problem7_Single_Attribute\n');

% Figure 2: Intersectional Comfort Heatmap
fig2 = figure('Position', [150, 150, 1200, 800]);

% Create heatmap data (3 age groups   6 income-gender combinations)
heatmapData = NaN(3, 6);
heatmapLabels = cell(1, 6);

colIdx = 1;
for incomeIdx = 1:3
    for genderIdx = 1:2
        heatmapLabels{colIdx} = sprintf('%s/%s', ...
                                        incomeCategories{incomeIdx}, ...
                                        genderCategories{genderIdx});
        
        for ageIdx = 1:3
            % Find corresponding subgroup
            for subgroupIdx = 1:numSubgroups
                if strcmp(intersectionalSubgroups(subgroupIdx).income, incomeCategories{incomeIdx}) && ...
                   strcmp(intersectionalSubgroups(subgroupIdx).age, ageCategories{ageIdx}) && ...
                   strcmp(intersectionalSubgroups(subgroupIdx).gender, genderCategories{genderIdx})
                    heatmapData(ageIdx, colIdx) = intersectionalSubgroups(subgroupIdx).comfort * 100;
                    break;
                end
            end
        end
        
        colIdx = colIdx + 1;
    end
end

imagesc(heatmapData');
colormap('jet');
colorbar;
caxis([70, 100]);

set(gca, 'XTick', 1:3, 'XTickLabel', ageCategories);
set(gca, 'YTick', 1:6, 'YTickLabel', heatmapLabels);
xlabel('Age Group', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Income/Gender', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Intersectional Comfort Satisfaction (\%)}', 'Interpreter', 'latex', 'FontSize', 12);

saveas(fig2, 'figures/Problem7_Intersectional_Heatmap.fig');
saveas(fig2, 'figures/Problem7_Intersectional_Heatmap.eps', 'epsc');
saveas(fig2, 'figures/Problem7_Intersectional_Heatmap.jpg');
fprintf('Saved: Problem7_Intersectional_Heatmap\n');

% Figure 3: Fairness Intervention Comparison
fig3 = figure('Position', [200, 200, 1200, 500]);

subplot(1, 2, 1);
methods = categorical({'Baseline', 'Reweighted', 'Constrained'});
disparities = [(maxComfort - minComfort), (maxComfortRW - minComfortRW), ...
               (maxComfortConstr - minComfortConstr)] * 100;

bar(methods, disparities, 'FaceColor', [0.8, 0.4, 0.4]);
ylabel('Intersectional Disparity (pp)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Fairness Improvement}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

subplot(1, 2, 2);
energies = [totalEnergyBaseline, totalEnergyReweighted, totalEnergyConstrained];
comforts = [overallComfortBaseline, overallComfortReweighted, overallComfortConstrained] * 100;

yyaxis left;
bar(methods, energies, 'FaceAlpha', 0.6);
ylabel('Energy Consumption (kWh)', 'Interpreter', 'latex', 'FontSize', 11);

yyaxis right;
plot(1:3, comforts, 'ro-', 'LineWidth', 2, 'MarkerSize', 8);
ylabel('Overall Comfort (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Energy-Comfort Trade-off}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle('\textbf{Intersectional Fairness Intervention Comparison}', ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig3, 'figures/Problem7_Fairness_Interventions.fig');
saveas(fig3, 'figures/Problem7_Fairness_Interventions.eps', 'epsc');
saveas(fig3, 'figures/Problem7_Fairness_Interventions.jpg');
fprintf('Saved: Problem7_Fairness_Interventions\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');
