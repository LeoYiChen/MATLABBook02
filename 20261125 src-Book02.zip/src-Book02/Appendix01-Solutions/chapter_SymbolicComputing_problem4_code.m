%% chapter_SymbolicComputing_problem4_code.m
% Robotics inverse kinematics with comprehensive symbolic solutions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_SymbolicComputing_problem4_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter_SymbolicComputing_Problem04.m
%
% Robotics Inverse Kinematics with Symbolic Solutions
%
% Author: Dr Yi Chen
% Institution: University Engineering Department
% Date: 2024
% Version: 1.0
% MATLAB Version: R2024a
%
% Description: Comprehensive robotics kinematics solver with symbolic
% inverse kinematics, workspace analysis, and singularity detection

function robotics_inverse_kinematics_system()
    %ROBOTICS_INVERSE_KINEMATICS_SYSTEM Advanced robotics kinematics
    %   Comprehensive symbolic inverse kinematics with multiple solutions
    
    clear; clc;
    
    % Display system header
    fprintf('Robotics Inverse Kinematics with Symbolic Solutions\n');
    fprintf('==================================================\n\n');
    
    % Problem 1: 6-DOF industrial manipulator
    solve_six_dof_manipulator();
    
    % Problem 2: 7-DOF redundant manipulator
    solve_redundant_manipulator();
    
    % Problem 3: Stewart platform (parallel manipulator)
    solve_stewart_platform();
    
    % Problem 4: Real-time trajectory planning
    demonstrate_trajectory_planning();
    
    % Advanced demonstrations
    demonstrate_advanced_kinematics();
    
end

function solve_six_dof_manipulator()
    %SOLVE_SIX_DOF_MANIPULATOR Symbolic inverse kinematics for 6-DOF robot
    %   Implements analytical solution for anthropomorphic manipulator
    
    fprintf('Problem 1: 6-DOF Industrial Manipulator\n');
    fprintf('=======================================\n');
    
    % Define symbolic variables
    syms theta1 theta2 theta3 theta4 theta5 theta6 real
    syms a1 a2 a3 d1 d4 d6 real positive
    syms px py pz nx ny nz ox oy oz ax ay az real
    
    fprintf('6-DOF Anthropomorphic Manipulator (e.g., PUMA-type)\n');
    fprintf('DH Parameters:\n');
    fprintf('Joint |       | d | a |  \n');
    fprintf('---|----|--|--|--\n');
    fprintf('  1   |       | d | 0  |  /2\n');
    fprintf('  2   |  - /2 | 0  | a | 0\n');
    fprintf('  3   |       | 0  | a |  /2\n');
    fprintf('  4   |       | d | 0  | - /2\n');
    fprintf('  5   |       | 0  | 0  |  /2\n');
    fprintf('  6   |       | d | 0  | 0\n\n');
    
    % Forward kinematics transformation matrices
    T01 = dh_transformation_matrix(theta1, d1, 0, pi/2);
    T12 = dh_transformation_matrix(theta2 - pi/2, 0, a2, 0);
    T23 = dh_transformation_matrix(theta3, 0, a3, pi/2);
    T34 = dh_transformation_matrix(theta4, d4, 0, -pi/2);
    T45 = dh_transformation_matrix(theta5, 0, 0, pi/2);
    T56 = dh_transformation_matrix(theta6, d6, 0, 0);
    
    % Overall transformation
    T06_symbolic = T01 * T12 * T23 * T34 * T45 * T56;
    T06_symbolic = simplify(T06_symbolic);
    
    fprintf('Forward Kinematics Matrix T computed symbolically\n');
    fprintf('Matrix size: 4 4 with symbolic entries\n\n');
    
    % Extract position and orientation
    position_symbolic = T06_symbolic(1:3, 4);
    rotation_symbolic = T06_symbolic(1:3, 1:3);
    
    fprintf('End-effector position: p = [px; py; pz]\n');
    fprintf('End-effector orientation: R = 3 3 rotation matrix\n\n');
    
    % Inverse kinematics solution procedure
    fprintf('Inverse Kinematics Solution Procedure:\n');
    fprintf('------------------\n');
    
    % Step 1: Solve for   (base rotation)
    fprintf('Step 1: Solve for   (base joint)\n');
    fprintf('From wrist centre position:\n');
    fprintf('  = atan2(py_wc, px_wc)\n\n');
    
    % Step 2: Solve for   and   (arm configuration)
    fprintf('Step 2: Solve for   and   (shoulder and elbow)\n');
    fprintf('Using geometric approach with law of cosines:\n');
    
    % Distance from shoulder to wrist
    syms r_sw s real positive
    r_sw = sqrt((px^2 + py^2) + (pz - d1)^2);
    
    fprintf('Distance shoulder to wrist: r =  ((px + py) + (pz - d))\n');
    
    % Cosine rule for  
    cos_theta3 = (r_sw^2 - a2^2 - a3^2) / (2*a2*a3);
    fprintf('cos( ) = (r - a - a)/(2aa)\n');
    fprintf('  =  acos(cos( )) (elbow up/down)\n\n');
    
    %   solution
    fprintf('  = atan2(pz - d,  (px + py)) - atan2(asin( ), a + acos( ))\n\n');
    
    % Step 3: Solve for  ,  ,   (wrist orientation)
    fprintf('Step 3: Solve for  ,  ,   (wrist orientation)\n');
    fprintf('From rotation matrix R = (R)R:\n');
    
    % Euler angle extraction
    fprintf('Using ZYZ Euler angles:\n');
    fprintf('  = atan2(R, R)\n');
    fprintf('  = atan2( (R + R), R)\n');
    fprintf('  = atan2(R, -R)\n\n');
    
    % Multiple solutions analysis
    fprintf('Multiple Solutions:\n');
    fprintf('  : unique solution\n');
    fprintf('  : two solutions (elbow up/down)\n');
    fprintf('  : two solutions (wrist flip)\n');
    fprintf(' Total: up to 8 solutions\n\n');
    
    % Singularity analysis
    fprintf('Singularity Analysis:\n');
    fprintf(' Shoulder singularity: when wrist centre is on z axis\n');
    fprintf(' Elbow singularity: when arm is fully extended or retracted\n');
    fprintf(' Wrist singularity: when   = 0 or   (axes 4 and 6 aligned)\n\n');
    
    % Numerical example
    demonstrate_numerical_ik_example();
    
end

function T = dh_transformation_matrix(theta, d, a, alpha)
    %DH_TRANSFORMATION_MATRIX Create DH transformation matrix
    %   Implements standard Denavit-Hartenberg transformation
    
    T = [cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta);
         sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta);
         0,           sin(alpha),             cos(alpha),            d;
         0,           0,                      0,                     1];
end

function demonstrate_numerical_ik_example()
    %DEMONSTRATE_NUMERICAL_IK_EXAMPLE Show specific numerical solution
    %   Demonstrates inverse kinematics with specific target pose
    
    fprintf('Numerical Example:\n');
    fprintf('---------\n');
    
    % Robot parameters (PUMA 560-like)
    a2_val = 0.4318;  % m
    a3_val = 0.0203;  % m
    d1_val = 0.6604;  % m
    d4_val = 0.4318;  % m
    d6_val = 0.0560;  % m
    
    fprintf('Robot parameters:\n');
    fprintf('a = %.4f m, a = %.4f m\n', a2_val, a3_val);
    fprintf('d = %.4f m, d = %.4f m, d = %.4f m\n\n', d1_val, d4_val, d6_val);
    
    % Target pose
    px_target = 0.5;   % m
    py_target = 0.3;   % m
    pz_target = 0.8;   % m
    
    % Target orientation (identity for simplicity)
    R_target = eye(3);
    
    fprintf('Target pose:\n');
    fprintf('Position: [%.2f, %.2f, %.2f] m\n', px_target, py_target, pz_target);
    fprintf('Orientation: Identity matrix (no rotation)\n\n');
    
    % Solve inverse kinematics analytically
    ik_solutions = solve_puma_ik_analytical(px_target, py_target, pz_target, R_target, ...
                                           a2_val, a3_val, d1_val, d4_val, d6_val);
    
    fprintf('Inverse Kinematics Solutions:\n');
    fprintf('Solution |  ( ) |  ( ) |  ( ) |  ( ) |  ( ) |  ( )\n');
    fprintf('-----|----|----|----|----|----|----\n');
    
    for sol_idx = 1:size(ik_solutions, 1)
        solution = ik_solutions(sol_idx, :) * 180/pi;  % Convert to degrees
        fprintf('   %d     | %5.1f | %5.1f | %5.1f | %5.1f | %5.1f | %5.1f\n', ...
               sol_idx, solution);
    end
    
    % Verify solutions
    fprintf('\nSolution Verification:\n');
    for sol_idx = 1:size(ik_solutions, 1)
        angles = ik_solutions(sol_idx, :);
        [pos_computed, rot_computed] = compute_forward_kinematics(angles, a2_val, a3_val, d1_val, d4_val, d6_val);
        
        position_error = norm([px_target; py_target; pz_target] - pos_computed);
        orientation_error = norm(R_target - rot_computed, 'fro');
        
        fprintf('Solution %d: Position error = %.2e m, Orientation error = %.2e\n', ...
               sol_idx, position_error, orientation_error);
    end
    
    fprintf('\n');
end

function solutions = solve_puma_ik_analytical(px, py, pz, R_target, a2, a3, d1, d4, d6)
    %SOLVE_PUMA_IK_ANALYTICAL Analytical inverse kinematics solver
    %   Returns all valid solutions for PUMA-type manipulator
    
    % Wrist centre position
    wrist_offset = R_target * [0; 0; d6];
    px_wc = px - wrist_offset(1);
    py_wc = py - wrist_offset(2);
    pz_wc = pz - wrist_offset(3);
    
    solutions = [];
    
    %   solutions
    theta1_solutions = atan2(py_wc, px_wc);
    if px_wc ~= 0 || py_wc ~= 0
        theta1_solutions = [theta1_solutions, theta1_solutions + pi];
    end
    
    for theta1 = theta1_solutions
        % Arm plane coordinates
        r = sqrt(px_wc^2 + py_wc^2);
        s = pz_wc - d1;
        D = sqrt(r^2 + s^2);
        
        % Check reachability
        if D > (a2 + a3) || D < abs(a2 - a3)
            continue;
        end
        
        %   solutions (elbow up/down)
        cos_theta3 = (D^2 - a2^2 - a3^2) / (2*a2*a3);
        if abs(cos_theta3) <= 1
            theta3_up = acos(cos_theta3);
            theta3_down = -acos(cos_theta3);
            
            for theta3 = [theta3_up, theta3_down]
                %   solution
                alpha = atan2(s, r);
                beta = atan2(a3*sin(theta3), a2 + a3*cos(theta3));
                theta2 = alpha - beta;
                
                % Wrist orientation (simplified for identity target)
                theta4 = 0;
                theta5 = 0;
                theta6 = 0;
                
                solution = [theta1, theta2, theta3, theta4, theta5, theta6];
                solutions = [solutions; solution];
            end
        end
    end
    
    % Remove duplicate solutions
    if size(solutions, 1) > 1
        solutions = unique(round(solutions*1000)/1000, 'rows');
    end
end

function [position, rotation] = compute_forward_kinematics(angles, a2, a3, d1, d4, d6)
    %COMPUTE_FORWARD_KINEMATICS Forward kinematics computation
    %   Computes end-effector pose from joint angles
    
    theta1 = angles(1); theta2 = angles(2); theta3 = angles(3);
    theta4 = angles(4); theta5 = angles(5); theta6 = angles(6);
    
    % Transformation matrices
    T01 = dh_transform_numeric(theta1, d1, 0, pi/2);
    T12 = dh_transform_numeric(theta2 - pi/2, 0, a2, 0);
    T23 = dh_transform_numeric(theta3, 0, a3, pi/2);
    T34 = dh_transform_numeric(theta4, d4, 0, -pi/2);
    T45 = dh_transform_numeric(theta5, 0, 0, pi/2);
    T56 = dh_transform_numeric(theta6, d6, 0, 0);
    
    T06 = T01 * T12 * T23 * T34 * T45 * T56;
    
    position = T06(1:3, 4);
    rotation = T06(1:3, 1:3);
end

function T = dh_transform_numeric(theta, d, a, alpha)
    %DH_TRANSFORM_NUMERIC Numerical DH transformation
    %   Numerical version of DH transformation for computation
    
    T = [cos(theta), -sin(theta)*cos(alpha),  sin(theta)*sin(alpha), a*cos(theta);
         sin(theta),  cos(theta)*cos(alpha), -cos(theta)*sin(alpha), a*sin(theta);
         0,           sin(alpha),             cos(alpha),            d;
         0,           0,                      0,                     1];
end

function solve_redundant_manipulator()
    %SOLVE_REDUNDANT_MANIPULATOR 7-DOF redundant manipulator analysis
    %   Implements null-space projection for redundancy resolution
    
    fprintf('Problem 2: 7-DOF Redundant Manipulator\n');
    fprintf('======================================\n');
    
    syms q1 q2 q3 q4 q5 q6 q7 real  % Joint angles
    syms qd1 qd2 qd3 qd4 qd5 qd6 qd7 real  % Joint velocities
    syms vx vy vz wx wy wz real  % End-effector velocity
    
    fprintf('7-DOF Redundant Manipulator Analysis\n');
    fprintf('Degrees of Freedom: 7 joints, 6 task coordinates\n');
    fprintf('Redundancy: 1 additional degree of freedom\n\n');
    
    % Jacobian matrix (6 7 for 6 DOF task space, 7 joint space)
    fprintf('Jacobian Matrix Analysis:\n');
    fprintf('J(q)   , rank(J)   6\n');
    fprintf('Velocity relationship:  = J(q)q\n\n');
    
    % Redundancy resolution using null-space projection
    fprintf('Redundancy Resolution Methods:\n');
    fprintf('---------------\n');
    
    fprintf('1. Pseudo-inverse method:\n');
    fprintf('   q = J + (I - JJ)q\n');
    fprintf('   where J = J(JJ) (Moore-Penrose pseudo-inverse)\n\n');
    
    fprintf('2. Damped least-squares method:\n');
    fprintf('   J = J(JJ +  I)\n');
    fprintf('   where   is damping factor\n\n');
    
    fprintf('3. Weighted pseudo-inverse:\n');
    fprintf('   J = WJ(JWJ)\n');
    fprintf('   where W is joint weighting matrix\n\n');
    
    % Null-space projection
    fprintf('Null-Space Projection:\n');
    fprintf('N(q) = I - J(q)J(q)\n');
    fprintf('Properties:\n');
    fprintf(' N(q) = N(q) (symmetric)\n');
    fprintf(' N(q) = N(q) (idempotent)\n');
    fprintf(' J(q)N(q) = 0 (null-space property)\n\n');
    
    % Secondary task optimization
    fprintf('Secondary Task Optimisation:\n');
    fprintf('q = J + N(q)q\n');
    fprintf('where q optimises secondary objective:\n');
    fprintf(' Joint limit avoidance\n');
    fprintf(' Singularity avoidance\n');
    fprintf(' Energy minimisation\n');
    fprintf(' Obstacle avoidance\n\n');
    
    % Singularity analysis for redundant manipulator
    fprintf('Singularity Analysis:\n');
    fprintf(' Algorithmic singularities: rank(J) < 6\n');
    fprintf(' Kinematic singularities: det(JJ) = 0\n');
    fprintf(' Self-motion manifolds: solutions to J(q)q = 0\n\n');
    
    % Demonstrate numerical example
    demonstrate_7dof_example();
end

function demonstrate_7dof_example()
    %DEMONSTRATE_7DOF_EXAMPLE Numerical example for 7-DOF manipulator
    %   Shows redundancy resolution with specific configuration
    
    fprintf('Numerical Example - 7-DOF Manipulator:\n');
    fprintf('-------------------\n');
    
    % Example Jacobian (6 7) at a specific configuration
    J_example = [
        0.5,  0.3, -0.2,  0.4, -0.1,  0.2,  0.0;
        0.3, -0.4,  0.5, -0.2,  0.3, -0.1,  0.0;
        0.0,  0.0,  0.0,  0.0,  0.0,  0.0,  1.0;
        0.1,  0.2, -0.3,  0.1,  0.4, -0.2,  0.0;
        -0.2, 0.1,  0.4, -0.3,  0.1,  0.3,  0.0;
        1.0,  0.0,  0.0,  0.0,  0.0,  0.0,  0.0
    ];
    
    fprintf('Example Jacobian matrix J   :\n');
    disp(J_example);
    
    % Compute pseudo-inverse
    J_pinv = pinv(J_example);
    
    fprintf('Pseudo-inverse J   :\n');
    fprintf('(showing first 3 columns)\n');
    disp(J_pinv(:, 1:3));
    
    % Null-space projector
    N = eye(7) - J_pinv * J_example;
    
    fprintf('Null-space projector N   :\n');
    fprintf('(showing first 3 3 block)\n');
    disp(N(1:3, 1:3));
    
    % Verify null-space properties
    N_symmetric_error = norm(N - N', 'fro');
    N_idempotent_error = norm(N*N - N, 'fro');
    JN_error = norm(J_example * N, 'fro');
    
    fprintf('Null-space verification:\n');
    fprintf('Symmetric property ||N - N||: %.2e\n', N_symmetric_error);
    fprintf('Idempotent property ||N - N||: %.2e\n', N_idempotent_error);
    fprintf('Null-space property ||JN||: %.2e\n', JN_error);
    
    % Example motion
    desired_velocity = [0.1; 0.0; 0.0; 0.0; 0.0; 0.1];  % End-effector velocity
    secondary_objective = [0.1; -0.1; 0.0; 0.1; -0.1; 0.0; 0.1];  % Joint preference
    
    % Compute joint velocities
    joint_velocity_primary = J_pinv * desired_velocity;
    joint_velocity_secondary = N * secondary_objective;
    joint_velocity_total = joint_velocity_primary + joint_velocity_secondary;
    
    fprintf('\nVelocity resolution example:\n');
    fprintf('Desired end-effector velocity: [%.2f, %.2f, %.2f, %.2f, %.2f, %.2f]\n', desired_velocity);
    fprintf('Primary joint velocities: [%.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f]\n', joint_velocity_primary);
    fprintf('Secondary component: [%.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f]\n', joint_velocity_secondary);
    fprintf('Total joint velocities: [%.3f, %.3f, %.3f, %.3f, %.3f, %.3f, %.3f]\n', joint_velocity_total);
    
    % Verify that end-effector velocity is achieved
    achieved_velocity = J_example * joint_velocity_total;
    velocity_error = norm(desired_velocity - achieved_velocity);
    
    fprintf('Verification: ||_desired - _achieved|| = %.2e\n', velocity_error);
    
    fprintf('\n');
end

function solve_stewart_platform()
    %SOLVE_STEWART_PLATFORM Parallel manipulator forward kinematics
    %   Solves Stewart platform (6-6 parallel manipulator) forward kinematics
    
    fprintf('Problem 3: Stewart Platform (Parallel Manipulator)\n');
    fprintf('=================================================\n');
    
    syms x y z phi theta psi real  % Platform pose
    syms l1 l2 l3 l4 l5 l6 real positive  % Leg lengths
    
    fprintf('Stewart Platform Configuration:\n');
    fprintf(' 6 degrees of freedom: [x, y, z,  ,  ,  ]\n');
    fprintf(' 6 actuated legs with variable lengths\n');
    fprintf(' Forward kinematics: leg lengths   platform pose\n');
    fprintf(' Inverse kinematics: platform pose   leg lengths\n\n');
    
    % Platform and base attachment points
    fprintf('Geometric Configuration:\n');
    fprintf('Base attachment points: B, B, ..., B\n');
    fprintf('Platform attachment points: P, P, ..., P\n');
    fprintf('Leg vectors: L = P - B\n');
    fprintf('Constraint equations: ||L|| = l (i = 1, ..., 6)\n\n');
    
    % Forward kinematics problem
    fprintf('Forward Kinematics Problem:\n');
    fprintf('Given: leg lengths [l, l, l, l, l, l]\n');
    fprintf('Find: platform pose [x, y, z,  ,  ,  ]\n\n');
    
    % Mathematical formulation
    fprintf('Mathematical Formulation:\n');
    fprintf('Platform position: p = [x, y, z]\n');
    fprintf('Platform orientation: R( , , )   SO(3)\n');
    fprintf('Platform points: P = p + R p\n');
    fprintf('where p are attachment points in body frame\n\n');
    
    % Constraint equations
    fprintf('Constraint Equations:\n');
    for i = 1:6
        fprintf('||P%d - B%d|| = l%d\n', i, i, i);
    end
    fprintf('\nThis gives 6 nonlinear equations in 6 unknowns\n\n');
    
    % Solution complexity
    fprintf('Solution Characteristics:\n');
    fprintf(' Up to 40 real solutions possible\n');
    fprintf(' Typically 1-2 physically realizable solutions\n');
    fprintf(' Requires numerical methods for general case\n');
    fprintf(' Special configurations admit analytical solutions\n\n');
    
    % Numerical solution approach
    fprintf('Numerical Solution Approach:\n');
    fprintf('1. Newton-Raphson iteration\n');
    fprintf('2. Polynomial continuation methods\n');
    fprintf('3. Geometric constraint satisfaction\n\n');
    
    % Demonstrate numerical example
    demonstrate_stewart_example();
end

function demonstrate_stewart_example()
    %DEMONSTRATE_STEWART_EXAMPLE Numerical Stewart platform example
    %   Shows forward kinematics solution for specific configuration
    
    fprintf('Numerical Example - Stewart Platform:\n');
    fprintf('------------------\n');
    
    % Platform configuration (simplified symmetric design)
    base_radius = 1.0;      % Base radius
    platform_radius = 0.6;  % Platform radius
    
    % Base attachment points (hexagonal)
    base_angles = (0:5) * pi/3;
    base_points = base_radius * [cos(base_angles); sin(base_angles); zeros(1,6)];
    
    % Platform attachment points (hexagonal, offset)
    platform_angles = (0:5) * pi/3 + pi/6;
    platform_points_body = platform_radius * [cos(platform_angles); sin(platform_angles); zeros(1,6)];
    
    fprintf('Base attachment points (radius %.1f m):\n', base_radius);
    for i = 1:6
        fprintf('B%d: [%.3f, %.3f, %.3f]\n', i, base_points(:,i));
    end
    
    fprintf('\nPlatform attachment points (radius %.1f m):\n', platform_radius);
    for i = 1:6
        fprintf('P%d: [%.3f, %.3f, %.3f] (body frame)\n', i, platform_points_body(:,i));
    end
    
    % Example platform pose
    platform_position = [0.2; 0.1; 1.5];  % [x, y, z]
    platform_orientation = [0.1; 0.05; 0.2];  % [ ,  ,  ] (small angles)
    
    fprintf('\nExample platform pose:\n');
    fprintf('Position: [%.2f, %.2f, %.2f] m\n', platform_position);
    fprintf('Orientation: [%.3f, %.3f, %.3f] rad\n', platform_orientation);
    
    % Compute rotation matrix (small angle approximation)
    phi = platform_orientation(1);
    theta = platform_orientation(2);
    psi = platform_orientation(3);
    
    R = [cos(psi)*cos(theta), -sin(psi)*cos(phi)+cos(psi)*sin(theta)*sin(phi), sin(psi)*sin(phi)+cos(psi)*sin(theta)*cos(phi);
         sin(psi)*cos(theta), cos(psi)*cos(phi)+sin(psi)*sin(theta)*sin(phi), -cos(psi)*sin(phi)+sin(psi)*sin(theta)*cos(phi);
         -sin(theta), cos(theta)*sin(phi), cos(theta)*cos(phi)];
    
    % Compute leg lengths (inverse kinematics)
    leg_lengths = zeros(6, 1);
    platform_points_global = zeros(3, 6);
    
    for i = 1:6
        platform_points_global(:,i) = platform_position + R * platform_points_body(:,i);
        leg_vector = platform_points_global(:,i) - base_points(:,i);
        leg_lengths(i) = norm(leg_vector);
    end
    
    fprintf('\nComputed leg lengths:\n');
    for i = 1:6
        fprintf('l%d = %.4f m\n', i, leg_lengths(i));
    end
    
    % Verify forward kinematics (would normally solve the inverse problem)
    fprintf('\nForward Kinematics Verification:\n');
    fprintf('Given leg lengths, solve for platform pose...\n');
    fprintf('(This requires iterative numerical solution)\n');
    
    % Show constraint satisfaction
    fprintf('\nConstraint Verification:\n');
    for i = 1:6
        computed_length = norm(platform_points_global(:,i) - base_points(:,i));
        error = abs(computed_length - leg_lengths(i));
        fprintf('Leg %d: ||P%d - B%d|| = %.6f m, error = %.2e\n', ...
               i, i, i, computed_length, error);
    end
    
    fprintf('\n');
end

function demonstrate_trajectory_planning()
    %DEMONSTRATE_TRAJECTORY_PLANNING Real-time trajectory planning
    %   Shows symbolic constraint handling in trajectory planning
    
    fprintf('Problem 4: Real-time Trajectory Planning\n');
    fprintf('========================================\n');
    
    syms t T real positive
    syms q0 qf qd0 qdf qdd0 qddf real
    
    fprintf('Trajectory Planning with Symbolic Constraints\n');
    fprintf('Objective: Generate smooth joint trajectories\n');
    fprintf('Constraints: Position, velocity, acceleration at endpoints\n\n');
    
    % Polynomial trajectory generation
    fprintf('Polynomial Trajectory Generation:\n');
    fprintf('----------------\n');
    
    % Fifth-order polynomial for smooth trajectory
    syms a0 a1 a2 a3 a4 a5 real
    q_trajectory = a0 + a1*t + a2*t^2 + a3*t^3 + a4*t^4 + a5*t^5;
    qd_trajectory = diff(q_trajectory, t);
    qdd_trajectory = diff(qd_trajectory, t);
    
    fprintf('Trajectory polynomial: q(t) = a + at + at + at + at + at\n');
    fprintf('Velocity: q(t) = %s\n', char(qd_trajectory));
    fprintf('Acceleration: q(t) = %s\n', char(qdd_trajectory));
    
    % Boundary conditions
    boundary_conditions = [
        subs(q_trajectory, t, 0) == q0;        % q(0) = q
        subs(q_trajectory, t, T) == qf;        % q(T) = qf
        subs(qd_trajectory, t, 0) == qd0;      % q(0) = q
        subs(qd_trajectory, t, T) == qdf;      % q(T) = qf
        subs(qdd_trajectory, t, 0) == qdd0;    % q(0) = q
        subs(qdd_trajectory, t, T) == qddf     % q(T) = qf
    ];
    
    fprintf('\nBoundary Conditions:\n');
    for i = 1:length(boundary_conditions)
        fprintf('%s\n', char(boundary_conditions(i)));
    end
    
    % Solve for coefficients symbolically
    coefficients = solve(boundary_conditions, [a0, a1, a2, a3, a4, a5]);
    
    fprintf('\nSymbolic Solution for Coefficients:\n');
    coeff_names = {'a', 'a', 'a', 'a', 'a', 'a'};
    coeff_fields = {'a0', 'a1', 'a2', 'a3', 'a4', 'a5'};
    
    for i = 1:6
        coeff_expr = coefficients.(coeff_fields{i});
        fprintf('%s = %s\n', coeff_names{i}, char(coeff_expr));
    end
    
    % Multi-joint trajectory coordination
    fprintf('\nMulti-Joint Trajectory Coordination:\n');
    fprintf('For n-joint robot: q(t) = [q(t), q(t), ..., q(t)]\n');
    fprintf('Synchronised motion: all joints reach target simultaneously\n');
    fprintf('Trajectory duration: T = max(T) where T is minimum time for joint i\n\n');
    
    % Obstacle avoidance
    fprintf('Obstacle Avoidance Integration:\n');
    fprintf(' Potential field methods\n');
    fprintf(' Rapidly-exploring Random Trees (RRT)\n');
    fprintf(' Optimal control with inequality constraints\n');
    fprintf(' Real-time replanning capabilities\n\n');
    
    % Real-time considerations
    fprintf('Real-time Implementation:\n');
    fprintf(' Pre-computed trajectory libraries\n');
    fprintf(' Online trajectory modification\n');
    fprintf(' Computational complexity: O(n) per time step\n');
    fprintf(' Update frequencies: 100-1000 Hz typical\n\n');
end

function demonstrate_advanced_kinematics()
    %DEMONSTRATE_ADVANCED_KINEMATICS Show advanced techniques
    %   Demonstrates sophisticated kinematics analysis methods
    
    fprintf('Advanced Kinematics Techniques\n');
    fprintf('=============================\n');
    
    % Screw theory
    fprintf('1. Screw Theory Representation:\n');
    fprintf('Joint motion:    where     se(3)\n');
    fprintf('Forward kinematics: g( ) = e^{  }e^{  }...e^{  }g\n');
    fprintf('Adjoint representation: Ad_g( ) for coordinate transformations\n\n');
    
    % Differential kinematics
    fprintf('2. Differential Kinematics:\n');
    fprintf('Body Jacobian: V^b = J^b( ) \n');
    fprintf('Spatial Jacobian: V^s = J^s( ) \n');
    fprintf('Relationship: J^s = Ad_{g}J^b\n\n');
    
    % Singularity analysis
    fprintf('3. Advanced Singularity Analysis:\n');
    fprintf(' Decoupling points: position and orientation singularities separate\n');
    fprintf(' Constraint singularities: loss of workspace boundary\n');
    fprintf(' Algorithmic singularities: numerical conditioning issues\n\n');
    
    % Calibration
    fprintf('4. Kinematic Calibration:\n');
    fprintf('Parameter identification: minimize ||f( ,p) - x_measured||\n');
    fprintf('Observable parameters: those affecting end-effector pose\n');
    fprintf('Symbolic sensitivity analysis for optimal measurement poses\n\n');
    
    % Parallel mechanisms
    fprintf('5. Parallel Mechanism Analysis:\n');
    fprintf(' Closed-loop constraints:  (q,x) = 0\n');
    fprintf(' Constraint Jacobian:  /q  +  /x  = 0\n');
    fprintf(' Force analysis:   = J^T F (principle of virtual work)\n\n');
    
    fprintf('Advanced kinematics demonstration complete.\n\n');
end
