%% C0201Introduction_code_012.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% SLOW: Element-wise loop
n = 1000000;
result = zeros(n, 1);
tic;
for i = 1:n
    result(i) = sin(i) * cos(i) + sqrt(i);
end
timeLoop = toc;

% FAST: Vectorised operations
tic;
i = (1:n)';
result = sin(i) .* cos(i) + sqrt(i);
timeVectorised = toc;

fprintf('Loop time: %.4f seconds\n', timeLoop);
fprintf('Vectorised time: %.4f seconds\n', timeVectorised);
fprintf('Speedup: %.1fx\n', timeLoop / timeVectorised);
% Typical speedup: 50-100*x
