%% prob9_code.m
% Parametric curves and mathematical art visualisation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob9_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Parametric Curves and Mathematical Art
% File: MATLABBook02_Chapter07_Problem09.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Creates stunning visualisations of parametric curves,
%              spirals, fractals, and 3D mathematical surfaces
% =========================================================================

function MATLABBook02_Chapter07_Problem09()
    % Main function for Problem 9: Mathematical Art Visualisation
    
    clc; clear; close all;
    
    % Create Lissajous figures gallery
    createLissajousGallery();
    
    % Generate spiral collection
    createSpiralCollection();
    
    % Plot rose curves
    createRoseCurveGallery();
    
    % Visualise epicycloids and hypocycloids
    createCycloidVisualisation();
    
    % Create 3D parametric surfaces
    create3DParametricSurfaces();
    
    % Generate fractal patterns
    createFractalArt();
    
    % Comprehensive mathematical art showcase
    createMathematicalArtShowcase();
end

function createLissajousGallery()
    % CREATELISSAJOUSGALLERY - Generates various Lissajous figures
    %
    % Lissajous curves: x = A*sin(a*t + delta), y = B*sin(b*t)
    % The ratio a:b determines the number of lobes
    
    figure('Name', 'Lissajous Figures Gallery', ...
           'Position', [50, 50, 1400, 1000]);
    
    % Parameter combinations to explore
    ratios = [1,1; 1,2; 2,3; 3,4; 3,5; 4,5; 5,6; 5,4];
    phases = [0, pi/4, pi/2, pi/2, pi/4, 3*pi/4, pi/3, 0];
    
    t = linspace(0, 2*pi, 2000);
    
    for idx = 1:8
        subplot(2, 4, idx);
        
        a = ratios(idx, 1);
        b = ratios(idx, 2);
        delta = phases(idx);
        
        % Generate Lissajous curve
        x = sin(a * t + delta);
        y = sin(b * t);
        
        % Colour by parameter t for visual effect
        scatter(x, y, 15, t, 'filled');
        colormap(gca, jet);
        
        % Formatting
        axis equal;
        axis off;
        title(sprintf('$a{:}b = %d{:}%d, \\delta = %.2f\\pi$', ...
              a, b, delta/pi), 'Interpreter', 'latex', 'FontSize', 11);
        xlim([-1.2, 1.2]);
        ylim([-1.2, 1.2]);
    end
    
    sgtitle('Lissajous Figures: Harmonic Motion Patterns', ...
           'Interpreter', 'latex', 'FontSize', 14, 'FontWeight', 'bold');
end

function createSpiralCollection()
    % CREATESPIRALCOLLECTION - Visualises different spiral types
    
    figure('Name', 'Spiral Collection', 'Position', [100, 100, 1400, 450]);
    
    % Archimedean Spiral: r = a + b*theta
    subplot(1, 3, 1);
    theta = linspace(0, 6*pi, 2000);
    a = 0.5;
    b = 0.3;
    r = a + b * theta;
    
    x = r .* cos(theta);
    y = r .* sin(theta);
    
    % Colour by radius for gradient effect
    scatter(x, y, 20, r, 'filled');
    colormap(gca, parula);
    cb1 = colorbar;
    ylabel(cb1, 'Radius', 'Interpreter', 'latex', 'FontSize', 9);
    
    axis equal;
    title('Archimedean Spiral: $r = a + b\theta$', ...
          'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold');
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'FontSize', 10);
    
    % Logarithmic (Equiangular) Spiral: r = a*e^(b*theta)
    subplot(1, 3, 2);
    theta = linspace(0, 4*pi, 2000);
    a = 0.1;
    b = 0.3;
    r = a * exp(b * theta);
    
    x = r .* cos(theta);
    y = r .* sin(theta);
    
    scatter(x, y, 20, theta, 'filled');
    colormap(gca, hot);
    cb2 = colorbar;
    ylabel(cb2, '$\theta$', 'Interpreter', 'latex', 'FontSize', 9);
    
    axis equal;
    title('Logarithmic Spiral: $r = ae^{b\theta}$', ...
          'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold');
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'FontSize', 10);
    
    % Fermat's Spiral: r = a*sqrt(theta)
    subplot(1, 3, 3);
    theta = linspace(0, 20*pi, 2000);
    a = 0.8;
    r = a * sqrt(theta);
    
    x = r .* cos(theta);
    y = r .* sin(theta);
    
    scatter(x, y, 20, sqrt(theta), 'filled');
    colormap(gca, cool);
    cb3 = colorbar;
    ylabel(cb3, '$\sqrt{\theta}$', 'Interpreter', 'latex', 'FontSize', 9);
    
    axis equal;
    title('Fermat''s Spiral: $r = a\sqrt{\theta}$', ...
          'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold');
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'FontSize', 10);
    
    sgtitle('Mathematical Spirals Showcase', 'Interpreter', 'latex', ...
           'FontSize', 14, 'FontWeight', 'bold');
end

function createRoseCurveGallery()
    % CREATEROSECURVEGALLERY - Plots rose curves with different parameters
    %
    % Rose curve: r = a*cos(k*theta) or r = a*sin(k*theta)
    % k integer: k petals if k odd, 2k petals if k even
    % k rational: complex patterns
    
    figure('Name', 'Rose Curve Gallery', 'Position', [150, 150, 1400, 900]);
    
    k_values = [2, 3, 4, 5, 7/3, 5/2, 7/2, 11/3];
    
    theta = linspace(0, 2*pi, 2000);
    
    for idx = 1:8
        subplot(2, 4, idx);
        
        k = k_values(idx);
        a = 1;
        
        % Adjust theta range for rational k
        if mod(k, 1) ~= 0
            theta = linspace(0, 2*pi*lcm(round(k*2), 2)/2, 3000);
        end
        
        r = a * cos(k * theta);
        
        % Convert to Cartesian
        x = r .* cos(theta);
        y = r .* sin(theta);
        
        % Plot with colour gradient
        scatter(x, y, 15, theta, 'filled');
        colormap(gca, hsv);
        
        axis equal;
        axis off;
        xlim([-1.5, 1.5]);
        ylim([-1.5, 1.5]);
        
        if mod(k, 1) == 0
            title(sprintf('$k = %d$', k), 'Interpreter', 'latex', 'FontSize', 11);
        else
            title(sprintf('$k = %d/%d$', round(k*k_values(idx)), k_values(idx)), ...
                  'Interpreter', 'latex', 'FontSize', 11);
        end
    end
    
    sgtitle('Rose Curves: $r = \cos(k\theta)$', 'Interpreter', 'latex', ...
           'FontSize', 14, 'FontWeight', 'bold');
end

function createCycloidVisualisation()
    % CREATECYCLOIDVISUALISATION - Epicycloids and hypocycloids
    
    figure('Name', 'Cycloid Patterns', 'Position', [50, 50, 1400, 900]);
    
    % Epicycloid: circle rolling outside another circle
    % x = (R+r)*cos(t) - r*cos((R+r)/r * t)
    % y = (R+r)*sin(t) - r*sin((R+r)/r * t)
    
    subplot(2, 2, 1);
    R = 5;  % Fixed circle radius
    r = 1.5;  % Rolling circle radius
    t = linspace(0, 2*pi*r, 2000);
    
    x = (R + r) * cos(t) - r * cos((R + r) / r * t);
    y = (R + r) * sin(t) - r * sin((R + r) / r * t);
    
    plot(x, y, 'b-', 'LineWidth', 2);
    hold on;
    % Draw fixed circle
    theta_circle = linspace(0, 2*pi, 100);
    plot(R*cos(theta_circle), R*sin(theta_circle), 'k-', 'LineWidth', 1);
    axis equal;
    title(sprintf('Epicycloid: $R = %.1f, r = %.1f$', R, r), ...
          'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'FontSize', 10);
    hold off;
    
    % Hypocycloid: circle rolling inside another circle
    subplot(2, 2, 2);
    R = 5;
    r = 2;
    t = linspace(0, 2*pi*r, 2000);
    
    x = (R - r) * cos(t) + r * cos((R - r) / r * t);
    y = (R - r) * sin(t) - r * sin((R - r) / r * t);
    
    plot(x, y, 'r-', 'LineWidth', 2);
    hold on;
    plot(R*cos(theta_circle), R*sin(theta_circle), 'k-', 'LineWidth', 1);
    axis equal;
    title(sprintf('Hypocycloid: $R = %.1f, r = %.1f$', R, r), ...
          'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'FontSize', 10);
    hold off;
    
    % Epitrochoid (generalised epicycloid with offset)
    subplot(2, 2, 3);
    R = 5;
    r = 1.2;
    d = 0.8;  % Distance from rolling circle center
    t = linspace(0, 2*pi*r*5, 3000);
    
    x = (R + r) * cos(t) - d * cos((R + r) / r * t);
    y = (R + r) * sin(t) - d * sin((R + r) / r * t);
    
    scatter(x, y, 8, t, 'filled');
    colormap(gca, jet);
    hold on;
    plot(R*cos(theta_circle), R*sin(theta_circle), 'k-', 'LineWidth', 1);
    axis equal;
    title(sprintf('Epitrochoid: $R{=}%.1f, r{=}%.1f, d{=}%.1f$', R, r, d), ...
          'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'FontSize', 10);
    hold off;
    
    % Hypotrochoid (generalised hypocycloid with offset)
    subplot(2, 2, 4);
    R = 6;
    r = 1.5;
    d = 2.5;
    t = linspace(0, 2*pi*r*4, 3000);
    
    x = (R - r) * cos(t) + d * cos((R - r) / r * t);
    y = (R - r) * sin(t) - d * sin((R - r) / r * t);
    
    scatter(x, y, 8, t, 'filled');
    colormap(gca, parula);
    hold on;
    plot(R*cos(theta_circle), R*sin(theta_circle), 'k-', 'LineWidth', 1);
    axis equal;
    title(sprintf('Hypotrochoid: $R{=}%.1f, r{=}%.1f, d{=}%.1f$', R, r, d), ...
          'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'FontSize', 10);
    hold off;
    
    sgtitle('Cycloid Family: Rolling Circle Curves', 'Interpreter', 'latex', ...
           'FontSize', 13, 'FontWeight', 'bold');
end

function create3DParametricSurfaces()
    % CREATE3DPARAMETRICSURFACES - 3D mathematical surfaces
    
    figure('Name', '3D Parametric Surfaces', 'Position', [100, 100, 1400, 450]);
    
    % Torus
    subplot(1, 3, 1);
    R = 3;  % Major radius
    r = 1;  % Minor radius
    u = linspace(0, 2*pi, 80);
    v = linspace(0, 2*pi, 80);
    [U, V] = meshgrid(u, v);
    
    X = (R + r*cos(V)) .* cos(U);
    Y = (R + r*cos(V)) .* sin(U);
    Z = r * sin(V);
    
    surf(X, Y, Z, 'EdgeColor', 'none', 'FaceAlpha', 0.9);
    colormap(gca, parula);
    shading interp;
    lighting gouraud;
    camlight;
    
    axis equal;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 11);
    zlabel('$z$', 'Interpreter', 'latex', 'FontSize', 11);
    title('Torus Surface', 'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold');
    view(45, 20);
    grid on;
    set(gca, 'FontSize', 10);
    
    % Mbius Strip
    subplot(1, 3, 2);
    u = linspace(0, 2*pi, 100);
    v = linspace(-0.5, 0.5, 20);
    [U, V] = meshgrid(u, v);
    
    R = 2;
    X = (R + V.*cos(U/2)) .* cos(U);
    Y = (R + V.*cos(U/2)) .* sin(U);
    Z = V .* sin(U/2);
    
    surf(X, Y, Z, V, 'EdgeColor', 'none', 'FaceAlpha', 0.9);
    colormap(gca, cool);
    shading interp;
    lighting gouraud;
    camlight;
    
    axis equal;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 11);
    zlabel('$z$', 'Interpreter', 'latex', 'FontSize', 11);
    title('M\"obius Strip', 'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold');
    view(45, 20);
    grid on;
    set(gca, 'FontSize', 10);
    
    % Trefoil Knot
    subplot(1, 3, 3);
    t = linspace(0, 2*pi, 500);
    
    x = sin(t) + 2*sin(2*t);
    y = cos(t) - 2*cos(2*t);
    z = -sin(3*t);
    
    % Create tube around curve
    plot3(x, y, z, 'LineWidth', 12);
    colormap(gca, jet);
    
    axis equal;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 11);
    zlabel('$z$', 'Interpreter', 'latex', 'FontSize', 11);
    title('Trefoil Knot', 'Interpreter', 'latex', 'FontSize', 12, 'FontWeight', 'bold');
    view(45, 20);
    grid on;
    set(gca, 'FontSize', 10);
    
    sgtitle('3D Parametric Surfaces and Knots', 'Interpreter', 'latex', ...
           'FontSize', 13, 'FontWeight', 'bold');
end

function createFractalArt()
    % CREATEFRACTALART - Generates fractal patterns
    
    figure('Name', 'Fractal Art', 'Position', [50, 50, 1400, 700]);
    
    % Sierpi ski Triangle
    subplot(1, 2, 1);
    drawSierpinskiTriangle(5);
    axis equal;
    axis off;
    title('Sierpi\'nski Triangle (5 iterations)', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    
    % Julia Set
    subplot(1, 2, 2);
    generateJuliaSet();
    axis equal;
    axis off;
    title('Julia Set Fractal', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    
    sgtitle('Fractal Geometry', 'Interpreter', 'latex', ...
           'FontSize', 13, 'FontWeight', 'bold');
end

function drawSierpinskiTriangle(depth)
    % DRAWSIERPINSKITRIANGLE - Recursive Sierpi ski triangle
    
    % Initial triangle vertices
    vertices = [0, 0; 1, 0; 0.5, sqrt(3)/2];
    
    % Draw recursively
    plotSierpinski(vertices, depth);
end

function plotSierpinski(vertices, depth)
    % PLOTSIERPINSKI - Recursive helper function
    
    if depth == 0
        % Base case: draw filled triangle
        patch(vertices(:,1), vertices(:,2), 'b', 'EdgeColor', 'none');
    else
        % Recursive case: find midpoints and recurse
        mid1 = (vertices(1,:) + vertices(2,:)) / 2;
        mid2 = (vertices(2,:) + vertices(3,:)) / 2;
        mid3 = (vertices(3,:) + vertices(1,:)) / 2;
        
        % Three smaller triangles
        plotSierpinski([vertices(1,:); mid1; mid3], depth-1);
        plotSierpinski([mid1; vertices(2,:); mid2], depth-1);
        plotSierpinski([mid3; mid2; vertices(3,:)], depth-1);
    end
end

function generateJuliaSet()
    % GENERATEJULIASET - Julia set fractal visualisation
    
    % Grid setup
    xMin = -1.5; xMax = 1.5;
    yMin = -1.5; yMax = 1.5;
    resolution = 500;
    
    x = linspace(xMin, xMax, resolution);
    y = linspace(yMin, yMax, resolution);
    [X, Y] = meshgrid(x, y);
    Z = X + 1i*Y;
    
    % Julia set parameter
    c = -0.7 + 0.27015i;
    
    % Iteration
    maxIter = 100;
    iterMap = zeros(size(Z));
    
    for iter = 1:maxIter
        mask = abs(Z) < 2;
        Z(mask) = Z(mask).^2 + c;
        iterMap(mask) = iter;
    end
    
    % Display
    imagesc(x, y, iterMap);
    colormap(jet);
    axis xy;
end

function createMathematicalArtShowcase()
    % CREATEMATHEMATICALARTSHOWCASE - Comprehensive art gallery
    
    figure('Name', 'Mathematical Art Showcase', ...
           'Position', [50, 50, 1600, 1200]);
    
    % Panel 1: Butterfly curve
    subplot(3, 3, 1);
    t = linspace(0, 12*pi, 5000);
    x = sin(t) .* (exp(cos(t)) - 2*cos(4*t) - sin(t/12).^5);
    y = cos(t) .* (exp(cos(t)) - 2*cos(4*t) - sin(t/12).^5);
    scatter(x, y, 5, t, 'filled');
    colormap(gca, hot);
    axis equal; axis off;
    title('Butterfly Curve', 'Interpreter', 'latex', 'FontSize', 10);
    
    % Panel 2: Heart curve
    subplot(3, 3, 2);
    t = linspace(0, 2*pi, 2000);
    x = 16 * sin(t).^3;
    y = 13*cos(t) - 5*cos(2*t) - 2*cos(3*t) - cos(4*t);
    scatter(x, y, 10, t, 'filled');
    colormap(gca, pink);
    axis equal; axis off;
    title('Heart Curve', 'Interpreter', 'latex', 'FontSize', 10);
    
    % Panel 3: Rhodonea (8-petal rose)
    subplot(3, 3, 3);
    theta = linspace(0, 2*pi, 2000);
    r = cos(4*theta);
    x = r .* cos(theta);
    y = r .* sin(theta);
    scatter(x, y, 15, theta, 'filled');
    colormap(gca, spring);
    axis equal; axis off;
    title('8-Petal Rose', 'Interpreter', 'latex', 'FontSize', 10);
    
    % Panel 4: Astroid
    subplot(3, 3, 4);
    t = linspace(0, 2*pi, 2000);
    a = 1;
    x = a * cos(t).^3;
    y = a * sin(t).^3;
    scatter(x, y, 15, t, 'filled');
    colormap(gca, copper);
    axis equal; axis off;
    title('Astroid', 'Interpreter', 'latex', 'FontSize', 10);
    
    % Panel 5: Cardioid
    subplot(3, 3, 5);
    theta = linspace(0, 2*pi, 2000);
    a = 1;
    r = a * (1 - cos(theta));
    x = r .* cos(theta);
    y = r .* sin(theta);
    scatter(x, y, 15, theta, 'filled');
    colormap(gca, autumn);
    axis equal; axis off;
    title('Cardioid', 'Interpreter', 'latex', 'FontSize', 10);
    
    % Panel 6: Lemniscate of Bernoulli
    subplot(3, 3, 6);
    theta = linspace(0, 2*pi, 2000);
    a = 1;
    r_squared = 2*a^2 * cos(2*theta);
    r = sqrt(abs(r_squared)) .* sign(r_squared);
    x = r .* cos(theta);
    y = r .* sin(theta);
    scatter(x, y, 15, theta, 'filled');
    colormap(gca, winter);
    axis equal; axis off;
    title('Lemniscate', 'Interpreter', 'latex', 'FontSize', 10);
    
    % Panel 7: Deltoid
    subplot(3, 3, 7);
    t = linspace(0, 2*pi, 2000);
    R = 3; r = 1;
    x = (R-r)*cos(t) + r*cos((R-r)/r * t);
    y = (R-r)*sin(t) - r*sin((R-r)/r * t);
    scatter(x, y, 10, t, 'filled');
    colormap(gca, cool);
    axis equal; axis off;
    title('Deltoid', 'Interpreter', 'latex', 'FontSize', 10);
    
    % Panel 8: Folium of Descartes
    subplot(3, 3, 8);
    t = linspace(-4, 4, 2000);
    t(abs(t + 1) < 0.01) = [];  % Remove singularity
    x = 3*t ./ (1 + t.^3);
    y = 3*t.^2 ./ (1 + t.^3);
    scatter(x, y, 10, t, 'filled');
    colormap(gca, jet);
    axis equal; axis off;
    xlim([-2, 4]); ylim([-4, 4]);
    title('Folium of Descartes', 'Interpreter', 'latex', 'FontSize', 10);
    
    % Panel 9: Limacon
    subplot(3, 3, 9);
    theta = linspace(0, 2*pi, 2000);
    a = 1; b = 2;
    r = b + a*cos(theta);
    x = r .* cos(theta);
    y = r .* sin(theta);
    scatter(x, y, 15, theta, 'filled');
    colormap(gca, parula);
    axis equal; axis off;
    title('Lima\c{c}on', 'Interpreter', 'latex', 'FontSize', 10);
    
    sgtitle('Gallery of Famous Mathematical Curves', 'Interpreter', 'latex', ...
           'FontSize', 14, 'FontWeight', 'bold');
end
