%% chapter_FundamentalMathematics_example_QuantumGate.m
% Simulating a simple quantum gate operation using matrix algebra.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_QuantumGate
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Quantum Computing Simulation: Hadamard Gate
% Demonstrates quantum superposition using linear algebra

% Define quantum basis states |0> and |1>
ket0 = [1; 0];  % Quantum state |0>
ket1 = [0; 1];  % Quantum state |1>

% Define Hadamard gate (creates superposition)
hadamardGate = (1/sqrt(2)) * [1, 1; 1, -1];

% Apply Hadamard gate to |0> state
superpositionState = hadamardGate * ket0;

% Verify unitarity (quantum gates must be unitary)
isUnitary = norm(hadamardGate * hadamardGate' - eye(2)) < 1e-10;

% Calculate measurement probabilities
prob0 = abs(superpositionState(1))^2;
prob1 = abs(superpositionState(2))^2;

% Display results
fprintf('Initial state |0>: [%.2f, %.2f]^T\n', ket0);
fprintf('After Hadamard gate: [%.4f, %.4f]^T\n', superpositionState);
fprintf('Probability of measuring |0>: %.4f\n', prob0);
fprintf('Probability of measuring |1>: %.4f\n', prob1);
fprintf('Gate is unitary: %s\n', string(isUnitary));
