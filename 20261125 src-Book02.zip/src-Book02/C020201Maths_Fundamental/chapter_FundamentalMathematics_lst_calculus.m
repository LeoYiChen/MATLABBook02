%% chapter_FundamentalMathematics_lst_calculus.m
% Numerical differentiation and integration in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_lst_calculus
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section5.3_example1.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates numerical differentiation and integration

fprintf('=== Numerical Differentiation and Integration ===\n\n');

% - Part 1: Numerical Differentiation -
fprintf('- Part 1: Numerical Differentiation -\n');

% Define test function and its analytical derivative
testFunction = @(x) sin(x);
analyticDerivative = @(x) cos(x);

% Create data points
xData = linspace(0, 2*pi, 21);  % Relatively coarse grid
yData = testFunction(xData);
h = xData(2) - xData(1);  % Grid spacing

% Method 1: Using diff
dydx_diff = diff(yData) ./ diff(xData);
x_diff = xData(1:end-1) + h/2;  % Midpoints

% Method 2: Using gradient
dydx_gradient = gradient(yData, xData);

% Method 3: Custom central difference (interior points only)
dydx_central = (yData(3:end) - yData(1:end-2)) / (2*h);
x_central = xData(2:end-1);

% Analytical derivative for comparison
xFine = linspace(0, 2*pi, 200);
yAnalytic = analyticDerivative(xFine);

% Compute errors
error_gradient = abs(dydx_gradient - analyticDerivative(xData));
error_central = abs(dydx_central - analyticDerivative(x_central));

fprintf('Maximum error using gradient: %.6e\n', max(error_gradient));
fprintf('Maximum error using central difference: %.6e\n', max(error_central));

% Plot differentiation results
figure('Position', [100, 100, 1400, 600]);

subplot(1, 3, 1);
plot(xFine, yAnalytic, 'k-', 'LineWidth', 2, 'DisplayName', 'Analytical $\cos(x)$');
hold on;
plot(xData, dydx_gradient, 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r', ...
    'DisplayName', 'gradient method');
plot(x_central, dydx_central, 'bs', 'MarkerSize', 6, 'MarkerFaceColor', 'b', ...
    'DisplayName', 'Central difference');
plot(x_diff, dydx_diff, 'g^', 'MarkerSize', 6, 'MarkerFaceColor', 'g', ...
    'DisplayName', 'diff method');
grid on;
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$dy/dx$', 'Interpreter', 'latex', 'FontSize', 12);
title('Numerical Differentiation Methods', 'Interpreter', 'latex', 'FontSize', 14);
legend('show', 'Interpreter', 'latex', 'Location', 'best');
hold off;

% - Part 2: Step Size Effect on Differentiation -
fprintf('\n- Part 2: Step Size Analysis -\n');

% Test different step sizes
hValues = logspace(-10, -1, 50);
errors_forward = zeros(size(hValues));
errors_central = zeros(size(hValues));

x0 = pi/4;  % Test point
f_prime_exact = analyticDerivative(x0);

for idx = 1:length(hValues)
    h_test = hValues(idx);
    
    % Forward difference
    f_prime_forward = (testFunction(x0 + h_test) - testFunction(x0)) / h_test;
    errors_forward(idx) = abs(f_prime_forward - f_prime_exact);
    
    % Central difference
    f_prime_central = (testFunction(x0 + h_test) - testFunction(x0 - h_test)) / (2*h_test);
    errors_central(idx) = abs(f_prime_central - f_prime_exact);
end

subplot(1, 3, 2);
loglog(hValues, errors_forward, 'r-', 'LineWidth', 2, 'DisplayName', 'Forward difference');
hold on;
loglog(hValues, errors_central, 'b-', 'LineWidth', 2, 'DisplayName', 'Central difference');
loglog(hValues, hValues, 'k--', 'LineWidth', 1, 'DisplayName', '$\mathcal{O}(h)$');
loglog(hValues, hValues.^2, 'k-.', 'LineWidth', 1, 'DisplayName', '$\mathcal{O}(h^2)$');
grid on;
xlabel('Step size $h$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Absolute error', 'Interpreter', 'latex', 'FontSize', 12);
title('Error vs Step Size (Differentiation)', 'Interpreter', 'latex', 'FontSize', 14);
legend('show', 'Interpreter', 'latex', 'Location', 'best');
hold off;

fprintf('Optimal h for forward difference: %.2e (error: %.2e)\n', ...
    hValues(find(errors_forward == min(errors_forward), 1)), min(errors_forward));
fprintf('Optimal h for central difference: %.2e (error: %.2e)\n', ...
    hValues(find(errors_central == min(errors_central), 1)), min(errors_central));

% - Part 3: Numerical Integration -
fprintf('\n- Part 3: Numerical Integration -\n');

% Test function: Gaussian (no elementary antiderivative)
integrand = @(x) exp(-x.^2);
a_limit = 0;
b_limit = 1;

% Analytical result (using error function)
analytical_result = sqrt(pi)/2 * erf(1);

% Method 1: Trapezoidal rule with discrete data
nPoints_trap = 21;
xTrap = linspace(a_limit, b_limit, nPoints_trap);
yTrap = integrand(xTrap);
integral_trapz = trapz(xTrap, yTrap);

% Method 2: Simpson's rule (manual implementation)
nPoints_simpson = 21;  % Must be odd for Simpson's rule
if mod(nPoints_simpson, 2) == 0
    nPoints_simpson = nPoints_simpson + 1;
end
xSimpson = linspace(a_limit, b_limit, nPoints_simpson);
ySimpson = integrand(xSimpson);
h_simpson = (b_limit - a_limit) / (nPoints_simpson - 1);
integral_simpson = h_simpson/3 * (ySimpson(1) + 4*sum(ySimpson(2:2:end-1)) + ...
    2*sum(ySimpson(3:2:end-2)) + ySimpson(end));

% Method 3: MATLAB's adaptive quadrature
integral_adaptive = integral(integrand, a_limit, b_limit);

% Display results
fprintf('Analytical result: %.15f\n', analytical_result);
fprintf('Trapezoidal rule (n=%d): %.15f (error: %.2e)\n', ...
    nPoints_trap, integral_trapz, abs(integral_trapz - analytical_result));
fprintf('Simpson''s rule (n=%d): %.15f (error: %.2e)\n', ...
    nPoints_simpson, integral_simpson, abs(integral_simpson - analytical_result));
fprintf('Adaptive quadrature: %.15f (error: %.2e)\n', ...
    integral_adaptive, abs(integral_adaptive - analytical_result));

% - Part 4: Convergence Analysis for Integration -
fprintf('\n- Part 4: Integration Convergence Analysis -\n');

nPointsArray = 5:2:101;  % Odd values for Simpson's rule
errors_trapz = zeros(size(nPointsArray));
errors_simpson = zeros(size(nPointsArray));

for idx = 1:length(nPointsArray)
    n = nPointsArray(idx);
    
    % Trapezoidal rule
    xTrap_test = linspace(a_limit, b_limit, n);
    yTrap_test = integrand(xTrap_test);
    integral_trapz_test = trapz(xTrap_test, yTrap_test);
    errors_trapz(idx) = abs(integral_trapz_test - analytical_result);
    
    % Simpson's rule
    h_test = (b_limit - a_limit) / (n - 1);
    xSimpson_test = linspace(a_limit, b_limit, n);
    ySimpson_test = integrand(xSimpson_test);
    integral_simpson_test = h_test/3 * (ySimpson_test(1) + ...
        4*sum(ySimpson_test(2:2:end-1)) + 2*sum(ySimpson_test(3:2:end-2)) + ...
        ySimpson_test(end));
    errors_simpson(idx) = abs(integral_simpson_test - analytical_result);
end

subplot(1, 3, 3);
loglog(nPointsArray, errors_trapz, 'ro-', 'LineWidth', 2, 'MarkerSize', 4, ...
    'DisplayName', 'Trapezoidal rule');
hold on;
loglog(nPointsArray, errors_simpson, 'bs-', 'LineWidth', 2, 'MarkerSize', 4, ...
    'DisplayName', 'Simpson''s rule');
grid on;
xlabel('Number of points', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Absolute error', 'Interpreter', 'latex', 'FontSize', 12);
title('Integration Error Convergence', 'Interpreter', 'latex', 'FontSize', 14);
legend('show', 'Interpreter', 'latex', 'Location', 'best');
hold off;

% Save figure
saveas(gcf, 'numerical_calculus_methods.png');

fprintf('\nNumerical calculus examples complete.\n');
fprintf('Figure saved as: numerical_calculus_methods.png\n');
