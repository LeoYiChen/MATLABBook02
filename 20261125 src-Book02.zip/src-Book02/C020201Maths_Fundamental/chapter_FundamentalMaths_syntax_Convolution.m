%% chapter_FundamentalMaths_syntax_Convolution.m
% Basic convolution syntax in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_syntax_Convolution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Direct convolution (time domain)
y = conv(x, h);           % Full convolution
y = conv(x, h, 'same');   % Same length as x
y = conv(x, h, 'valid');  % Only where signals fully overlap

% FFT-based convolution (frequency domain) for efficiency
Y = ifft(fft(x) .* fft(h));
