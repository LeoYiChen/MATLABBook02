%% listing_outlier_detection.m
% Multi-method outlier detection framework with robust statistics.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : listing_outlier_detection
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [outlier_indices, cleaned_data, detection_stats] = detectAndTreatOutliers(data, method, options)
% detectAndTreatOutliers - Comprehensive outlier detection and treatment
%
% Syntax: [outliers, cleaned, stats] = detectAndTreatOutliers(data, method, options)
%
% Inputs:
%   data    - Input data vector or matrix (columns are variables)
%   method  - Detection method: 'zscore', 'iqr', 'mad', 'grubbs', 'dixon'
%   options - Structure with method-specific parameters
%
% Outputs:
%   outlier_indices - Logical array indicating outlier positions
%   cleaned_data    - Data with outliers removed or treated
%   detection_stats - Structure containing detection statistics

    % Input validation and default parameters
    if nargin < 2, method = 'iqr'; end
    if nargin < 3, options = struct(); end
    
    % Set default parameters
    if ~isfield(options, 'threshold'), options.threshold = 3; end
    if ~isfield(options, 'treatment'), options.treatment = 'remove'; end
    if ~isfield(options, 'iqr_multiplier'), options.iqr_multiplier = 1.5; end
    
    % Ensure data is column vector for univariate methods
    [n_rows, n_cols] = size(data);
    if n_cols > 1 && ~strcmp(method, 'mahalanobis')
        error('Multivariate data requires method = ''mahalanobis''');
    end
    
    % Initialise outputs
    outlier_indices = false(size(data));
    detection_stats = struct();
    detection_stats.method = method;
    detection_stats.original_size = length(data);
    
    % Apply selected detection method
    switch lower(method)
        case 'zscore'
            % Standard z-score method
            data_mean = mean(data, 'omitnan');
            data_std = std(data, 'omitnan');
            z_scores = abs(data - data_mean) ./ data_std;
            outlier_indices = z_scores > options.threshold;
            detection_stats.threshold_used = options.threshold;
            detection_stats.mean_used = data_mean;
            detection_stats.std_used = data_std;
            
        case 'iqr'
            % Interquartile range method
            Q1 = prctile(data, 25);
            Q3 = prctile(data, 75);
            IQR = Q3 - Q1;
            lower_fence = Q1 - options.iqr_multiplier * IQR;
            upper_fence = Q3 + options.iqr_multiplier * IQR;
            outlier_indices = (data < lower_fence) | (data > upper_fence);
            detection_stats.Q1 = Q1;
            detection_stats.Q3 = Q3;
            detection_stats.IQR = IQR;
            detection_stats.lower_fence = lower_fence;
            detection_stats.upper_fence = upper_fence;
            
        case 'mad'
            % Median Absolute Deviation method
            data_median = median(data, 'omitnan');
            mad_value = median(abs(data - data_median), 'omitnan');
            modified_z_scores = 0.6745 * (data - data_median) ./ mad_value;
            outlier_indices = abs(modified_z_scores) > options.threshold;
            detection_stats.median_used = data_median;
            detection_stats.mad_value = mad_value;
            detection_stats.threshold_used = options.threshold;
            
        case 'grubbs'
            % Grubbs' test for single outlier (iterative)
            data_clean = data(~isnan(data));
            outlier_indices = false(size(data));
            
            while length(data_clean) > 2
                n = length(data_clean);
                data_mean = mean(data_clean);
                data_std = std(data_clean);
                
                % Calculate Grubbs test statistic
                deviations = abs(data_clean - data_mean);
                [max_deviation, max_idx] = max(deviations);
                grubbs_stat = max_deviation / data_std;
                
                % Critical value for Grubbs test (approximate)
                alpha = 0.05;
                t_critical = tinv(1 - alpha/(2*n), n-2);
                grubbs_critical = ((n-1)/sqrt(n)) * sqrt(t_critical^2 / (n-2 + t_critical^2));
                
                if grubbs_stat > grubbs_critical
                    % Mark as outlier and remove from working data
                    outlier_value = data_clean(max_idx);
                    outlier_indices(data == outlier_value) = true;
                    data_clean(max_idx) = [];
                else
                    break; % No more outliers detected
                end
            end
            detection_stats.grubbs_critical = grubbs_critical;
            
        otherwise
            error('Unknown outlier detection method: %s', method);
    end
    
    % Calculate detection statistics
    detection_stats.outliers_detected = sum(outlier_indices);
    detection_stats.outlier_percentage = (detection_stats.outliers_detected / detection_stats.original_size) * 100;
    detection_stats.outlier_values = data(outlier_indices);
    
    % Apply treatment strategy
    switch lower(options.treatment)
        case 'remove'
            cleaned_data = data(~outlier_indices);
            
        case 'winsorise'
            % Replace outliers with nearest non-outlier values
            cleaned_data = data;
            if any(outlier_indices)
                non_outlier_data = data(~outlier_indices);
                cleaned_data(outlier_indices) = median(non_outlier_data, 'omitnan');
            end
            
        case 'cap'
            % Cap outliers at fence values (for IQR method)
            cleaned_data = data;
            if strcmp(method, 'iqr')
                cleaned_data(data < detection_stats.lower_fence) = detection_stats.lower_fence;
                cleaned_data(data > detection_stats.upper_fence) = detection_stats.upper_fence;
            end
            
        otherwise
            cleaned_data = data;
            warning('Unknown treatment method. Returning original data.');
    end
    
    detection_stats.treatment_applied = options.treatment;
    detection_stats.final_size = length(cleaned_data);
end
