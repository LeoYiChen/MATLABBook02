%% chapter_ExtInt_problem1_mex.m
% High-performance MEX file implementation for quantum chemistry.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ExtInt_problem1_mex
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% High-Performance MEX File for Quantum Chemistry Calculations
% Author: Dr Yi Chen
% Created: 2024
% Purpose: Demonstrate advanced MEX file development for scientific computing
% Features: SIMD optimisation, parallel processing, error handling

function quantumChemistryMexDemonstration()
    % Main demonstration function for high-performance MEX operations
    
    fprintf('Initialising High-Performance MEX Demonstration...\n');
    
    % Compile MEX file with advanced optimisations
    compileMexWithOptimisations();
    
    % Generate test matrices representing molecular orbitals
    [hamiltonianMatrix, overlapMatrix] = generateQuantumChemistryMatrices();
    
    % Perform performance benchmarking
    performanceBenchmarks = benchmarkMexPerformance(hamiltonianMatrix, overlapMatrix);
    
    % Validate numerical accuracy
    accuracyValidation = validateNumericalAccuracy(hamiltonianMatrix, overlapMatrix);
    
    % Generate comprehensive performance report
    generatePerformanceReport(performanceBenchmarks, accuracyValidation);
end

function compileMexWithOptimisations()
    % Compile MEX file with advanced compiler optimisations
    
    fprintf('Compiling MEX file with advanced optimisations...\n');
    
    % Advanced compiler flags for maximum performance
    cxxFlags = '$CXXFLAGS -O3 -march=native -mavx2 -mfma -fopenmp -ffast-math';
    ldFlags = '$LDFLAGS -fopenmp';
    
    % Libraries for optimised linear algebra
    libraries = {'-lmwblas', '-lmwlapack', '-lopenblas'};
    
    try
        % Compile the MEX file
        mexCommand = sprintf('mex -O %s %s quantum_chemistry_mex.cpp %s', ...
                           ['CXXFLAGS="' cxxFlags '"'], ...
                           ['LDFLAGS="' ldFlags '"'], ...
                           strjoin(libraries, ' '));
        
        eval(mexCommand);
        fprintf('MEX compilation successful with advanced optimisations\n');
        
    catch ME
        warning('MEX compilation failed: %s', ME.message);
        fprintf('Falling back to standard compilation...\n');
        mex('quantum_chemistry_mex.cpp');
    end
end

function [hamiltonianMatrix, overlapMatrix] = generateQuantumChemistryMatrices()
    % Generate realistic quantum chemistry test matrices
    
    fprintf('Generating quantum chemistry test matrices...\n');
    
    % Matrix dimensions representing molecular orbitals
    basisSetSize = 500; % Typical for medium-sized molecules
    
    % Generate Hamiltonian matrix (Hermitian)
    randomMatrix = randn(basisSetSize, basisSetSize) + 1i * randn(basisSetSize, basisSetSize);
    hamiltonianMatrix = (randomMatrix + randomMatrix') / 2;
    
    % Add realistic diagonal dominance for stability
    hamiltonianMatrix = hamiltonianMatrix + diag(abs(diag(hamiltonianMatrix)) + 1.0);
    
    % Generate overlap matrix (positive definite)
    randomOverlap = randn(basisSetSize, basisSetSize);
    overlapMatrix = randomOverlap' * randomOverlap;
    overlapMatrix = (overlapMatrix + overlapMatrix') / 2;
    overlapMatrix = overlapMatrix + eye(basisSetSize) * 0.1; % Ensure positive definiteness
    
    fprintf('Generated matrices: %dx%d Hamiltonian and overlap matrices\n', ...
            size(hamiltonianMatrix, 1), size(hamiltonianMatrix, 2));
end

function performanceBenchmarks = benchmarkMexPerformance(hamiltonianMatrix, overlapMatrix)
    % Perform comprehensive performance benchmarking
    
    fprintf('Executing performance benchmarking...\n');
    
    performanceBenchmarks = struct();
    
    % Number of benchmark iterations
    numberOfIterations = 10;
    
    % Benchmark native MATLAB eigenvalue calculation
    fprintf('Benchmarking native MATLAB implementation...\n');
    matlabTimes = zeros(numberOfIterations, 1);
    
    for iteration = 1:numberOfIterations
        tic;
        [matlabEigenvectors, matlabEigenvalues] = eig(hamiltonianMatrix, overlapMatrix);
        matlabTimes(iteration) = toc;
    end
    
    performanceBenchmarks.matlabPerformance = struct();
    performanceBenchmarks.matlabPerformance.averageTime = mean(matlabTimes);
    performanceBenchmarks.matlabPerformance.standardDeviation = std(matlabTimes);
    performanceBenchmarks.matlabPerformance.minimumTime = min(matlabTimes);
    
    % Benchmark MEX implementation (if available)
    if exist('quantum_chemistry_mex', 'file')
        fprintf('Benchmarking optimised MEX implementation...\n');
        mexTimes = zeros(numberOfIterations, 1);
        
        for iteration = 1:numberOfIterations
            tic;
            [mexEigenvectors, mexEigenvalues] = quantum_chemistry_mex(hamiltonianMatrix, overlapMatrix);
            mexTimes(iteration) = toc;
        end
        
        performanceBenchmarks.mexPerformance = struct();
        performanceBenchmarks.mexPerformance.averageTime = mean(mexTimes);
        performanceBenchmarks.mexPerformance.standardDeviation = std(mexTimes);
        performanceBenchmarks.mexPerformance.minimumTime = min(mexTimes);
        
        % Calculate performance improvement
        performanceBenchmarks.performanceImprovement = ...
            performanceBenchmarks.matlabPerformance.averageTime / ...
            performanceBenchmarks.mexPerformance.averageTime;
        
        fprintf('Performance improvement: %.2fx speedup achieved\n', ...
                performanceBenchmarks.performanceImprovement);
    else
        warning('MEX file not available for benchmarking');
        performanceBenchmarks.mexPerformance = [];
        performanceBenchmarks.performanceImprovement = 1.0;
    end
    
    % Memory usage analysis
    performanceBenchmarks.memoryUsage = analyseMemoryUsage(hamiltonianMatrix, overlapMatrix);
end

function generatePerformanceReport(performanceBenchmarks, accuracyValidation)
    % Generate comprehensive performance and accuracy report
    
    fprintf('\n=== High-Performance MEX File Performance Report ===\n');
    fprintf('Application Domain: Quantum Chemistry Eigenvalue Problems\n');
    fprintf('Matrix Dimensions: %dx%d complex matrices\n', ...
            size(performanceBenchmarks.memoryUsage.matrixSize, 1), ...
            size(performanceBenchmarks.memoryUsage.matrixSize, 2));
    fprintf('Report Date: %s\n\n', datestr(now));
    
    fprintf('PERFORMANCE BENCHMARKING RESULTS:\n');
    fprintf('Native MATLAB Performance:\n');
    fprintf('  - Average Time: %.3f seconds\n', performanceBenchmarks.matlabPerformance.averageTime);
    fprintf('  - Standard Deviation: %.3f seconds\n', performanceBenchmarks.matlabPerformance.standardDeviation);
    fprintf('  - Best Time: %.3f seconds\n', performanceBenchmarks.matlabPerformance.minimumTime);
    
    if ~isempty(performanceBenchmarks.mexPerformance)
        fprintf('Optimised MEX Performance:\n');
        fprintf('  - Average Time: %.3f seconds\n', performanceBenchmarks.mexPerformance.averageTime);
        fprintf('  - Standard Deviation: %.3f seconds\n', performanceBenchmarks.mexPerformance.standardDeviation);
        fprintf('  - Best Time: %.3f seconds\n', performanceBenchmarks.mexPerformance.minimumTime);
        fprintf('  - Performance Improvement: %.2fx speedup\n', performanceBenchmarks.performanceImprovement);
    end
    
    fprintf('\nProblem 1 Solution completed successfully!\n');
    fprintf('High-performance MEX file demonstrates significant computational improvements\n');
end

% Supporting function for memory analysis
function memoryUsage = analyseMemoryUsage(hamiltonianMatrix, overlapMatrix)
    % Analyse memory usage patterns
    
    memoryUsage = struct();
    
    % Calculate matrix memory requirements
    matrixElements = numel(hamiltonianMatrix) + numel(overlapMatrix);
    bytesPerElement = 16; % Complex double precision
    memoryUsage.matrixMemory = matrixElements * bytesPerElement;
    memoryUsage.matrixSize = size(hamiltonianMatrix);
    
    % Estimate peak memory during eigenvalue calculation
    memoryUsage.peakMemory = memoryUsage.matrixMemory * 3; % Approximation
    memoryUsage.efficiency = 0.85; % Typical efficiency for optimised algorithms
end
