%% chapter_AI_Chemistry_Problem07_code.m
% Problem 7: Reinforcement Learning for Reaction Pathway Optimization
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Chemistry_Problem07_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Script: Problem 7 - RL for Reaction Pathway Optimization
% Chapter: AI in Chemistry Research and Education
% Author: Dr Yi Chen (IEEE Fellow, IET Fellow, IMechE Fellow)
% Affiliation: Newcastle University, United Kingdom
% Date: January 2025
% MATLAB Version: R2023b or later
% Required Toolboxes: Statistics and Machine Learning Toolbox
% Description: Q-learning for optimising synthetic routes
% Version Control: v1.0 - Initial implementation
%                  Tested on MATLAB R2023b, Windows 11 Pro, 32GB RAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialisation
clear all; close all; clc;

fprintf('========================================\n');
fprintf('Problem 7: Reinforcement Learning for Reaction Pathway Optimization\n');
fprintf('Q-Learning for Synthesis Route Discovery\n');
fprintf('========================================\n\n');

rng(2025, 'twister');

%% Step 1: Define Chemical Reaction Network
fprintf('Step 1: Defining reaction network...\n');

% Molecules (states)
numMolecules = 10;
moleculeNames = {'CH4 (Methane)', 'CH3OH (Methanol)', 'CH2O (Formaldehyde)', ...
                'HCOOH (Formic Acid)', 'CO2 (Carbon Dioxide)', ...
                'CH3COOH (Acetic Acid)', 'CH3CHO (Acetaldehyde)', ...
                'C2H5OH (Ethanol)', 'C2H4 (Ethylene)', ...
                'C6H6 (Benzene - TARGET)'};

% Starting material and target
startState = 1; % Methane
targetState = 10; % Benzene

% Reactions (actions): [reactant, product, yield, cost]
reactions = [
    1, 2, 0.85, 10;   % R1: CH4 -> CH3OH (oxidation, yield 85%, cost 10)
    2, 3, 0.90, 8;    % R2: CH3OH -> CH2O (oxidation)
    3, 4, 0.75, 12;   % R3: CH2O -> HCOOH (oxidation)
    4, 5, 0.95, 5;    % R4: HCOOH -> CO2 (combustion)
    2, 6, 0.70, 15;   % R5: CH3OH -> CH3COOH (carbonylation, low yield)
    6, 7, 0.88, 7;    % R6: CH3COOH -> CH3CHO (reduction)
    7, 8, 0.92, 6;    % R7: CH3CHO -> C2H5OH (reduction)
    8, 9, 0.80, 10;   % R8: C2H5OH -> C2H4 (dehydration)
    9, 10, 0.65, 25;  % R9: C2H4 -> C6H6 (trimerisation, expensive!)
    1, 8, 0.60, 20;   % R10: CH4 -> C2H5OH (direct, low yield)
    3, 10, 0.40, 30;  % R11: CH2O -> C6H6 (cyclisation, very low yield)
    7, 10, 0.55, 22;  % R12: CH3CHO -> C6H6 (aldol + aromatisation)
    4, 10, 0.35, 35;  % R13: HCOOH -> C6H6 (multistep, poor)
    8, 10, 0.50, 28;  % R14: C2H5OH -> C6H6 (dehydrogenation)
    9, 8, 0.85, 8;    % R15: C2H4 -> C2H5OH (hydrogenation, reverse)
];

numReactions = size(reactions, 1);

fprintf('  Molecules: %d\n', numMolecules);
fprintf('  Reactions: %d\n', numReactions);
fprintf('  Start: %s (state %d)\n', moleculeNames{startState}, startState);
fprintf('  Target: %s (state %d)\n\n', moleculeNames{targetState}, targetState);

% Build state-action graph
% actionMap{state} = [action_indices] (which reactions can be applied)
actionMap = cell(numMolecules, 1);
for molIdx = 1:numMolecules
    actionMap{molIdx} = find(reactions(:, 1) == molIdx);
end

fprintf('  Reaction network constructed\n');
fprintf('  Average actions per state: %.1f\n\n', mean(cellfun(@length, actionMap)));

%% Step 2: Define Reward Function
fprintf('Step 2: Designing reward function...\n');

% Reward components:
% - Immediate reward: progress toward target
% - Yield penalty: low-yield reactions discouraged
% - Cost penalty: expensive reactions discouraged
% - Terminal rewards: large positive (reach target), large negative (dead-end)

function reward = computeReward(state, action, nextState, reactions, targetState)
    % Extract reaction parameters
    reactionYield = reactions(action, 3);
    reactionCost = reactions(action, 4);
    
    % Immediate reward
    if nextState == targetState
        reward = 100; % Success!
    else
        % Reward = yield bonus - cost penalty - step penalty
        reward = 10 * reactionYield - 0.5 * reactionCost - 1;
    end
    
    % Dead-end penalty (no further reactions possible)
    % (Not applicable in this network as all paths can continue)
end

fprintf('  Reward function designed:\n');
fprintf('    Terminal reward (target reached): +100\n');
fprintf('    Yield bonus: +10   yield\n');
fprintf('    Cost penalty: 0.5   cost\n');
fprintf('    Step penalty: 1 (encourages shorter routes)\n\n');

%% Step 3: Initialize Q-Table
fprintf('Step 3: Initialising Q-learning...\n');

% Q-table: Q(state, action)
% States: 1 to numMolecules
% Actions: 1 to numReactions (but not all valid from each state)
QTable = zeros(numMolecules, numReactions);

% Hyperparameters
alpha = 0.1;         % Learning rate
gamma = 0.95;        % Discount factor
epsilon = 0.2;       % Exploration rate
epsilonDecay = 0.995; % Decay per episode
epsilonMin = 0.01;
numEpisodes = 10000;
maxStepsPerEpisode = 15; % Prevent infinite loops

fprintf('  Hyperparameters:\n');
fprintf('    Learning rate ( ): %.2f\n', alpha);
fprintf('    Discount factor ( ): %.2f\n', gamma);
fprintf('    Initial exploration ( ): %.2f (decays to %.2f)\n', epsilon, epsilonMin);
fprintf('    Episodes: %d\n', numEpisodes);
fprintf('    Max steps/episode: %d\n\n', maxStepsPerEpisode);

%% Step 4: Q-Learning Training
fprintf('Step 4: Training Q-learning agent...\n');

episodeRewards = zeros(numEpisodes, 1);
episodeLengths = zeros(numEpisodes, 1);
successRate = zeros(numEpisodes, 1);

fprintf('  Training progress (reporting every 1000 episodes):\n');
tic;

for episode = 1:numEpisodes
    state = startState;
    episodeReward = 0;
    stepCount = 0;
    
    while stepCount < maxStepsPerEpisode
        stepCount = stepCount + 1;
        
        % Get valid actions from current state
        validActions = actionMap{state};
        
        if isempty(validActions)
            % Dead-end (shouldn't happen in our network)
            episodeReward = episodeReward - 50;
            break;
        end
        
        % Epsilon-greedy action selection
        if rand < epsilon
            % Explore: random action
            actionIdx = randi(length(validActions));
            action = validActions(actionIdx);
        else
            % Exploit: best known action
            QValues = QTable(state, validActions);
            [~, actionIdx] = max(QValues);
            action = validActions(actionIdx);
        end
        
        % Execute action
        nextState = reactions(action, 2);
        reward = computeReward(state, action, nextState, reactions, targetState);
        episodeReward = episodeReward + reward;
        
        % Q-learning update
        if nextState == targetState
            % Terminal state (no future actions)
            QTable(state, action) = QTable(state, action) + ...
                alpha * (reward - QTable(state, action));
            break;
        else
            % Temporal difference update
            nextValidActions = actionMap{nextState};
            if ~isempty(nextValidActions)
                maxNextQ = max(QTable(nextState, nextValidActions));
            else
                maxNextQ = 0;
            end
            
            QTable(state, action) = QTable(state, action) + ...
                alpha * (reward + gamma * maxNextQ - QTable(state, action));
        end
        
        % Move to next state
        state = nextState;
        
        % Check if target reached
        if state == targetState
            break;
        end
    end
    
    % Record episode statistics
    episodeRewards(episode) = episodeReward;
    episodeLengths(episode) = stepCount;
    successRate(episode) = double(state == targetState);
    
    % Decay epsilon
    epsilon = max(epsilonMin, epsilon * epsilonDecay);
    
    % Progress reporting
    if mod(episode, 1000) == 0
        avgReward = mean(episodeRewards(max(1, episode-999):episode));
        avgLength = mean(episodeLengths(max(1, episode-999):episode));
        successPct = mean(successRate(max(1, episode-999):episode)) * 100;
        fprintf('    Episode %5d: Avg Reward = %6.2f, Avg Length = %.2f, Success = %.1f%%\n', ...
                episode, avgReward, avgLength, successPct);
    end
end

trainingTime = toc;
fprintf('\n  Training complete in %.1f seconds (%.2f min)\n', trainingTime, trainingTime/60);
fprintf('  Final success rate (last 1000 episodes): %.1f%%\n\n', ...
        mean(successRate(end-999:end)) * 100);

%% Step 5: Extract Optimal Policy
fprintf('Step 5: Extracting optimal synthesis route...\n');

optimalRoute = {};
state = startState;
stepCount = 0;
totalYield = 1;
totalCost = 0;

while state ~= targetState && stepCount < maxStepsPerEpisode
    stepCount = stepCount + 1;
    
    validActions = actionMap{state};
    if isempty(validActions)
        fprintf('  Dead-end reached at %s\n', moleculeNames{state});
        break;
    end
    
    % Select best action
    QValues = QTable(state, validActions);
    [~, actionIdx] = max(QValues);
    action = validActions(actionIdx);
    
    % Record step
    nextState = reactions(action, 2);
    reactionYield = reactions(action, 3);
    reactionCost = reactions(action, 4);
    
    optimalRoute{end+1} = sprintf('Step %d: %s -> %s (R%d, Yield=%.0f%%, Cost=%d)', ...
                                  stepCount, moleculeNames{state}, ...
                                  moleculeNames{nextState}, action, ...
                                  reactionYield*100, reactionCost);
    
    totalYield = totalYield * reactionYield;
    totalCost = totalCost + reactionCost;
    
    state = nextState;
end

fprintf('  Optimal Route Found:\n');
for stepIdx = 1:length(optimalRoute)
    fprintf('    %s\n', optimalRoute{stepIdx});
end
fprintf('\n  Overall Statistics:\n');
fprintf('    Total steps: %d\n', stepCount);
fprintf('    Cumulative yield: %.2f%%\n', totalYield * 100);
fprintf('    Total cost: %d\n', totalCost);
fprintf('    Efficiency score: %.2f (yield/cost)\n\n', totalYield / totalCost * 100);

%% Step 6: Baseline Comparison - Random Policy
fprintf('Step 6: Baseline comparison - random policy...\n');

numRandomTrials = 1000;
randomSuccesses = 0;
randomLengths = [];

for trial = 1:numRandomTrials
    state = startState;
    steps = 0;
    
    while steps < maxStepsPerEpisode
        steps = steps + 1;
        validActions = actionMap{state};
        if isempty(validActions), break; end
        
        action = validActions(randi(length(validActions)));
        state = reactions(action, 2);
        
        if state == targetState
            randomSuccesses = randomSuccesses + 1;
            randomLengths(end+1) = steps;
            break;
        end
    end
end

randomSuccessRate = randomSuccesses / numRandomTrials * 100;
avgRandomLength = mean(randomLengths);

fprintf('  Random Policy (%d trials):\n', numRandomTrials);
fprintf('    Success rate: %.1f%%\n', randomSuccessRate);
if randomSuccesses > 0
    fprintf('    Avg successful route length: %.2f steps\n', avgRandomLength);
else
    fprintf('    No successful routes found\n');
end

fprintf('\n  Q-Learning vs. Random:\n');
fprintf('    Success improvement: %.1f%% -> %.1f%% (+%.1f pp)\n', ...
        randomSuccessRate, mean(successRate(end-999:end))*100, ...
        mean(successRate(end-999:end))*100 - randomSuccessRate);
fprintf('    Learned route: %d steps (optimal)\n\n', stepCount);

%% Step 7: Visualisation - Learning Curves
figure('Name', 'Q-Learning Convergence', 'Position', [100, 100, 1400, 600]);

subplot(1, 2, 1);
smoothRewards = movmean(episodeRewards, 100);
plot(1:numEpisodes, smoothRewards, 'LineWidth', 2, 'Color', [0.2, 0.6, 0.8]);
xlabel('Episode', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Cumulative Reward (100-episode MA)', 'Interpreter', 'latex', 'FontSize', 13);
title('Learning Curve: Reward', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

subplot(1, 2, 2);
smoothSuccess = movmean(successRate, 100) * 100;
plot(1:numEpisodes, smoothSuccess, 'LineWidth', 2, 'Color', [0.9, 0.4, 0.2]);
xlabel('Episode', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Success Rate (\%, 100-episode MA)', 'Interpreter', 'latex', 'FontSize', 13);
title('Learning Curve: Success Rate', 'Interpreter', 'latex', 'FontSize', 14);
grid on;
ylim([0, 100]);

saveas(gcf, 'Problem07_LearningCurves.fig');
saveas(gcf, 'Problem07_LearningCurves.eps', 'epsc');
saveas(gcf, 'Problem07_LearningCurves.jpg');

fprintf('  Learning curves saved\n\n');

%% Step 8: Q-Table Heatmap
figure('Name', 'Q-Table Heatmap', 'Position', [100, 100, 1200, 800]);

imagesc(QTable');
colormap('hot');
colorbar;
xlabel('State (Molecule)', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Action (Reaction)', 'Interpreter', 'latex', 'FontSize', 13);
title('Learned Q-Values (State-Action)', 'Interpreter', 'latex', 'FontSize', 14);
xticks(1:numMolecules);
xticklabels(strrep(moleculeNames, ' ', '\n'));
xtickangle(45);
yticks(1:numReactions);
yticklabels(arrayfun(@(x) sprintf('R%d', x), 1:numReactions, 'UniformOutput', false));

saveas(gcf, 'Problem07_QTable.fig');
saveas(gcf, 'Problem07_QTable.eps', 'epsc');
saveas(gcf, 'Problem07_QTable.jpg');

fprintf('  Q-table heatmap saved\n\n');

%% Summary
fprintf('========================================\n');
fprintf('Problem 7 Complete: Summary\n');
fprintf('========================================\n\n');

fprintf('Reaction Network:\n');
fprintf('  Molecules: %d\n', numMolecules);
fprintf('  Reactions: %d\n', numReactions);
fprintf('  Start: %s\n', moleculeNames{startState});
fprintf('  Target: %s\n\n', moleculeNames{targetState});

fprintf('Q-Learning Training:\n');
fprintf('  Episodes: %d\n', numEpisodes);
fprintf('  Training time: %.1f seconds\n', trainingTime);
fprintf('  Final success rate: %.1f%%\n', mean(successRate(end-999:end))*100);
fprintf('  Final avg reward: %.2f\n\n', mean(episodeRewards(end-999:end)));

fprintf('Optimal Route:\n');
for stepIdx = 1:length(optimalRoute)
    fprintf('  %s\n', optimalRoute{stepIdx});
end
fprintf('  Overall yield: %.2f%%, Cost: %d\n\n', totalYield*100, totalCost);

fprintf('Comparison:\n');
fprintf('  Random policy success: %.1f%%\n', randomSuccessRate);
fprintf('  Q-learning success: %.1f%%\n', mean(successRate(end-999:end))*100);
fprintf('  Improvement: %.1f  better\n\n', mean(successRate(end-999:end))/randomSuccessRate*100);

fprintf('Key Insights:\n');
fprintf('  - RL learns optimal routes via trial-and-error (no supervision)\n');
fprintf('  - Q-learning balances exploration and exploitation\n');
fprintf('  - Discovered route: %d steps, %.0f%% yield\n', stepCount, totalYield*100);
fprintf('  - Outperforms random search by %.1f \n', mean(successRate(end-999:end))/randomSuccessRate*100);
fprintf('  - Scalable to larger reaction networks (millions of reactions)\n\n');

fprintf('Figures saved:\n');
fprintf('  - Problem07_LearningCurves (.fig, .eps, .jpg)\n');
fprintf('  - Problem07_QTable (.fig, .eps, .jpg)\n\n');

fprintf('========================================\n');
