%% chapter_AI_Mechanics_Problem8_attention_viz_syntax.m
% Attention mechanism extraction and visualisation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem8_attention_viz_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Extract and visualise attention weights
% net: trained LSTM network
% XTest: test sequence (lookback   numFeatures)

% Forward pass to extract activations from attention layer
attentionLayerName = 'attention_weights';
attentionWeights = activations(net, XTest, attentionLayerName);

% attentionWeights: (lookback   1) vector of importance scores
% Reshape if needed
if size(attentionWeights, 2) > 1
    attentionWeights = mean(attentionWeights, 2);  % Average across features
end

% Visualise as heatmap over time
figure('Position', [100, 100, 1200, 400]);

subplot(2, 1, 1);
plot(1:length(XTest{1}), XTest{1}(1, :), 'b-', 'LineWidth', 1.5);
xlabel('Time Step (hours)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Normalised Strain', 'Interpreter', 'latex', 'FontSize', 12);
title('Input Sequence', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

subplot(2, 1, 2);
bar(1:length(attentionWeights), attentionWeights, 'FaceColor', [0.2 0.6 0.8]);
xlabel('Time Step (hours)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Attention Weight', 'Interpreter', 'latex', 'FontSize', 12);
title('Learned Attention Weights', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

% Identify peaks (most influential time steps)
[peakVals, peakLocs] = findpeaks(attentionWeights, 'MinPeakHeight', 0.05, ...
    'SortStr', 'descend', 'NPeaks', 5);
fprintf('Top 5 influential time lags: %s\n', mat2str(peakLocs));
