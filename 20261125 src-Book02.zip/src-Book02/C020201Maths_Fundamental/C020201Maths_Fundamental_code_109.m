%% C020201Maths_Fundamental_code_109.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Simulate sparse frequency signal
N = 8192;
K = 20;  % Number of non-zero frequencies
sparseSignal = zeros(1, N);
sparseLocations = randperm(N, K);
sparseSignal(sparseLocations) = randn(1, K) + 1*i*randn(1, K);

% Time-domain signal
timeSignal = ifft(sparseSignal);

% Random sampling (compressed sensing)
numMeasurements = 4 * K * log(N);  % Much less than N
samplingIndices = randperm(N, numMeasurements);
measurements = timeSignal(samplingIndices);

% Recovery via L1 minimisation (requires CVX or similar)
% cvx_begin
%     variable x(N) complex
%     minimise(norm(x, 1))
%     subject to
%         ifft(x)(samplingIndices) == measurements
% cvx_end
