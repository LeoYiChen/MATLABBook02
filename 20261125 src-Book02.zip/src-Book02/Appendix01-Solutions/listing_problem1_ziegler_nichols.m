%% listing_problem1_ziegler_nichols.m
% Problem 1: Ziegler-Nichols PID tuning for chemical reactor temperature control with comprehensive stability and performance analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem1_ziegler_nichols
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 1 - Ziegler-Nichols PID Tuning
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: Design PID controller using Ziegler-Nichols frequency
%              response method for third-order temperature control system.
%              Determine ultimate gain/period, compute PID parameters,
%              validate performance and robustness.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 1: Ziegler-Nichols PID Tuning for Temperature Control\n');
fprintf('==================================================================\n\n');

%% Plant Transfer Function: G(s) = 2.5 / (10s + 1)^3
K_plant = 2.5;
tau_plant = 10;

numeratorPlant = K_plant;
denominatorPlant = conv([tau_plant 1], conv([tau_plant 1], [tau_plant 1]));
plantTF = tf(numeratorPlant, denominatorPlant);

fprintf('=== Plant Transfer Function ===\n');
disp(plantTF);

plantPoles = pole(plantTF);
fprintf('Plant poles:\n');
for idx = 1:length(plantPoles)
    fprintf('  p_%d = %.4f\n', idx, plantPoles(idx));
end
fprintf('\n');

%% Step 1: Determine Ultimate Gain (Ku) and Ultimate Period (Pu)
fprintf('=== Step 1: Determine Ultimate Gain and Period ===\n');

% Method 1: Root Locus
% Find gain where poles cross imaginary axis
% Characteristic equation: 1 + Kp * G(s) = 0
% For marginally stable system, substitute s = j*omega

syms omega_sym Kp_sym positive

% Characteristic equation at s = j*omega
s_imaginary = 1j * omega_sym;
G_at_imaginary = K_plant / ((tau_plant * s_imaginary + 1)^3);

% For marginal stability: 1 + Kp * G(j*omega) = 0
% Separate real and imaginary parts
char_eq = 1 + Kp_sym * G_at_imaginary;
real_part = real(char_eq);
imag_part = imag(char_eq);

% Solve for omega where imaginary part = 0
omega_solution = solve(imag_part == 0, omega_sym, 'Real', true, 'ReturnConditions', true);
omega_u_candidates = double(omega_solution.omega_sym);
omega_u_candidates = omega_u_candidates(omega_u_candidates > 0);

if ~isempty(omega_u_candidates)
    omega_u = omega_u_candidates(1);
else
    error('Could not find ultimate frequency');
end

% Solve for Kp where real part = 0 at omega_u
real_part_at_omega_u = subs(real_part, omega_sym, omega_u);
Ku_solution = solve(real_part_at_omega_u == 0, Kp_sym);
Ku = double(Ku_solution(Ku_solution > 0));

% Ultimate period
Pu = 2 * pi / omega_u;

fprintf('Ultimate gain (Ku): %.4f\n', Ku);
fprintf('Ultimate frequency (omega_u): %.4f rad/s\n', omega_u);
fprintf('Ultimate period (Pu): %.4f s\n\n', Pu);

% Verification: Check poles at Ku
closedLoop_at_Ku = feedback(Ku * plantTF, 1);
poles_at_Ku = pole(closedLoop_at_Ku);

fprintf('Verification: Poles at Ku = %.4f\n', Ku);
for idx = 1:length(poles_at_Ku)
    if abs(imag(poles_at_Ku(idx))) < 1e-6
        fprintf('  p_%d = %.6f (real)\n', idx, real(poles_at_Ku(idx)));
    else
        fprintf('  p_%d = %.6f + %.6fi (|s| = %.6f)\n', idx, ...
            real(poles_at_Ku(idx)), imag(poles_at_Ku(idx)), abs(poles_at_Ku(idx)));
    end
end

% Check if poles on imaginary axis
max_real_part = max(real(poles_at_Ku));
if abs(max_real_part) < 1e-4
    fprintf('CONFIRMED: System marginally stable at Ku (poles on imaginary axis)\n\n');
else
    fprintf('WARNING: Poles not exactly on imaginary axis (max Re = %.6f)\n\n', max_real_part);
end

%% Step 2: Apply Ziegler-Nichols Tuning Rules
fprintf('=== Step 2: Ziegler-Nichols PID Parameters ===\n');

% Z-N tuning rules for PID
Kp_ZN = 0.6 * Ku;
Ti_ZN = Pu / 2;
Td_ZN = Pu / 8;

Ki_ZN = Kp_ZN / Ti_ZN;
Kd_ZN = Kp_ZN * Td_ZN;

fprintf('Ziegler-Nichols PID Parameters:\n');
fprintf('  Proportional gain (Kp): %.4f\n', Kp_ZN);
fprintf('  Integral time constant (Ti): %.4f s\n', Ti_ZN);
fprintf('  Derivative time constant (Td): %.4f s\n', Td_ZN);
fprintf('  Integral gain (Ki = Kp/Ti): %.4f\n', Ki_ZN);
fprintf('  Derivative gain (Kd = Kp*Td): %.4f\n\n', Kd_ZN);

%% Step 3: Construct PID Controller with Derivative Filter
fprintf('=== Step 3: PID Controller Construction ===\n');

% Ideal PID: C(s) = Kp + Ki/s + Kd*s
% Practical PID with derivative filter: C(s) = Kp + Ki/s + Kd*s/(1 + tau_f*s)
% Filter time constant: tau_f = Td / N where N = 10 (typical)

N_filter = 10;
tau_filter = Td_ZN / N_filter;

% Transfer function form:
% C(s) = [Kp*(1 + tau_f*s) + Ki*tau_f + Kd*s*(1 + tau_f*s)/s] / [s*(1 + tau_f*s)]
% Simplified: C(s) = [num] / [den]

num_PID = [Kd_ZN, Kp_ZN + Kd_ZN/tau_filter, Ki_ZN];
den_PID = [tau_filter, 1, 0];

pidController = tf(num_PID, den_PID);

fprintf('PID Controller Transfer Function (with derivative filter):\n');
disp(pidController);

fprintf('Derivative filter time constant (tau_f): %.4f s\n', tau_filter);
fprintf('Filter ratio (N = Td/tau_f): %.1f\n\n', N_filter);

%% Step 4: Closed-Loop Analysis
fprintf('=== Step 4: Closed-Loop Stability and Performance ===\n');

% Form closed-loop system
openLoopTF = pidController * plantTF;
closedLoopTF = feedback(openLoopTF, 1);

fprintf('Closed-Loop Transfer Function:\n');
disp(closedLoopTF);

% Stability margins
[Gm, Pm, Wgc, Wpc] = margin(openLoopTF);

fprintf('Stability Margins:\n');
fprintf('  Gain Margin (GM): %.2f dB at %.2f rad/s\n', 20*log10(Gm), Wgc);
fprintf('  Phase Margin (PM): %.2f degrees at %.2f rad/s\n\n', Pm, Wpc);

% Closed-loop poles
closedLoopPoles = pole(closedLoopTF);

fprintf('Closed-Loop Poles:\n');
for idx = 1:length(closedLoopPoles)
    if abs(imag(closedLoopPoles(idx))) < 1e-6
        fprintf('  p_%d = %.6f (real)\n', idx, real(closedLoopPoles(idx)));
    else
        zeta_pole = -real(closedLoopPoles(idx)) / abs(closedLoopPoles(idx));
        wn_pole = abs(closedLoopPoles(idx));
        fprintf('  p_%d = %.6f + %.6fi (zeta=%.3f, wn=%.3f rad/s)\n', idx, ...
            real(closedLoopPoles(idx)), imag(closedLoopPoles(idx)), zeta_pole, wn_pole);
    end
end

% Check stability
if all(real(closedLoopPoles) < 0)
    fprintf('\nSTABILITY: All poles in left-half plane - STABLE\n\n');
else
    fprintf('\nWARNING: System UNSTABLE - poles in right-half plane!\n\n');
end

%% Step 5: Step Response Performance
fprintf('=== Step 5: Step Response Performance ===\n');

figure('Position', [100, 100, 1400, 600]);

subplot(2,3,1);
step(closedLoopTF, 100);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Temperature ($^\circ$C)', 'Interpreter', 'latex', 'FontSize', 12);
title('Closed-Loop Step Response (Z-N PID)', 'Interpreter', 'latex', 'FontSize', 14);

stepInfo = stepinfo(closedLoopTF);

fprintf('Step Response Metrics:\n');
fprintf('  Rise Time (Tr): %.4f s\n', stepInfo.RiseTime);
fprintf('  Peak Time (Tp): %.4f s\n', stepInfo.PeakTime);
fprintf('  Settling Time (Ts, 2%%): %.4f s\n', stepInfo.SettlingTime);
fprintf('  Percentage Overshoot (Mp): %.2f %%\n', stepInfo.Overshoot);
fprintf('  Peak Value: %.4f\n', stepInfo.Peak);
fprintf('  Steady-State Value: %.4f\n\n', dcgain(closedLoopTF));

% Specification check
fprintf('Specification Verification:\n');
if stepInfo.SettlingTime < 60
    fprintf('  PASS: Settling time < 60 s (%.2f s)\n', stepInfo.SettlingTime);
else
    fprintf('  FAIL: Settling time exceeds 60 s (%.2f s)\n', stepInfo.SettlingTime);
end

if stepInfo.Overshoot < 25
    fprintf('  PASS: Overshoot < 25%% (%.2f %%)\n', stepInfo.Overshoot);
else
    fprintf('  FAIL: Overshoot exceeds 25%% (%.2f %%)\n', stepInfo.Overshoot);
end

ss_error = abs(1 - dcgain(closedLoopTF));
if ss_error < 0.01
    fprintf('  PASS: Steady-state error < 1%% (%.4f)\n\n', ss_error);
else
    fprintf('  FAIL: Steady-state error too large (%.4f)\n\n', ss_error);
end

%% Comparison with Other Controllers
fprintf('=== Comparison: P, PI, PID Controllers ===\n');

% P controller (Z-N rule)
Kp_P = 0.5 * Ku;
pController = tf(Kp_P, 1);
closedLoop_P = feedback(pController * plantTF, 1);

% PI controller (Z-N rule)
Kp_PI = 0.45 * Ku;
Ti_PI = Pu / 1.2;
Ki_PI = Kp_PI / Ti_PI;
piController = tf([Kp_PI, Ki_PI], [1, 0]);
closedLoop_PI = feedback(piController * plantTF, 1);

subplot(2,3,2);
step(closedLoop_P, closedLoop_PI, closedLoopTF, 100);
grid on;
legend('P Controller', 'PI Controller', 'PID Controller', ...
    'Interpreter', 'latex', 'Location', 'best');
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Output', 'Interpreter', 'latex', 'FontSize', 12);
title('Controller Comparison: P vs PI vs PID', 'Interpreter', 'latex', 'FontSize', 14);

stepInfo_P = stepinfo(closedLoop_P);
stepInfo_PI = stepinfo(closedLoop_PI);

fprintf('P Controller: Ts = %.2f s, Mp = %.2f %%, ess = %.4f\n', ...
    stepInfo_P.SettlingTime, stepInfo_P.Overshoot, abs(1 - dcgain(closedLoop_P)));
fprintf('PI Controller: Ts = %.2f s, Mp = %.2f %%, ess = %.4f\n', ...
    stepInfo_PI.SettlingTime, stepInfo_PI.Overshoot, abs(1 - dcgain(closedLoop_PI)));
fprintf('PID Controller: Ts = %.2f s, Mp = %.2f %%, ess = %.4f\n\n', ...
    stepInfo.SettlingTime, stepInfo.Overshoot, abs(1 - dcgain(closedLoopTF)));

%% Bode Plot Analysis
subplot(2,3,3);
margin(openLoopTF);
grid on;
title('Open-Loop Bode Plot with Margins', 'Interpreter', 'latex', 'FontSize', 14);

%% Root Locus
subplot(2,3,4);
rlocus(plantTF);
hold on;
plot(real(closedLoopPoles), imag(closedLoopPoles), 'rx', 'MarkerSize', 15, 'LineWidth', 3);
grid on;
title('Root Locus with Z-N PID Poles', 'Interpreter', 'latex', 'FontSize', 14);
legend('Root Locus', 'Closed-Loop Poles', 'Interpreter', 'latex');

%% Nyquist Plot
subplot(2,3,5);
nyquist(openLoopTF);
grid on;
title('Nyquist Plot (Open-Loop)', 'Interpreter', 'latex', 'FontSize', 14);

%% Control Effort
subplot(2,3,6);
t_sim = 0:0.1:100;
u_step = ones(size(t_sim));
[y_out, t_out, x_out] = lsim(closedLoopTF, u_step, t_sim);

% Calculate control signal
e_signal = u_step' - y_out;  % Error signal
u_control = lsim(pidController, e_signal, t_out);

plot(t_out, u_control, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Control Signal', 'Interpreter', 'latex', 'FontSize', 12);
title('Control Effort (PID Output)', 'Interpreter', 'latex', 'FontSize', 14);
xlim([0, 50]);

saveas(gcf, 'Problem01_ZieglerNichols_Analysis.fig');
saveas(gcf, 'Problem01_ZieglerNichols_Analysis.eps', 'epsc');
saveas(gcf, 'Problem01_ZieglerNichols_Analysis.jpg');

fprintf('Saved: Problem01_ZieglerNichols_Analysis.fig/.eps/.jpg\n\n');

%% Robustness Analysis: Parameter Variations
fprintf('=== Robustness Analysis: Plant Parameter Variations ===\n');

paramVariations = [-0.2, -0.1, 0, 0.1, 0.2];  %  20%,  10%

figure('Position', [100, 100, 1200, 500]);

subplot(1,2,1);
hold on;

for idx = 1:length(paramVariations)
    variation = paramVariations(idx);
    
    % Perturb plant gain
    K_perturbed = K_plant * (1 + variation);
    plantTF_perturbed = tf(K_perturbed, denominatorPlant);
    
    closedLoop_perturbed = feedback(pidController * plantTF_perturbed, 1);
    
    step(closedLoop_perturbed, 100);
    
    stepInfo_pert = stepinfo(closedLoop_perturbed);
    
    fprintf('Gain variation %+.0f%%: Ts = %.2f s, Mp = %.2f %%\n', ...
        variation*100, stepInfo_pert.SettlingTime, stepInfo_pert.Overshoot);
end

grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Output', 'Interpreter', 'latex', 'FontSize', 12);
title('Robustness: Plant Gain Variations ($\pm 20\%$)', 'Interpreter', 'latex', 'FontSize', 14);
legend(arrayfun(@(x) sprintf('%+.0f\\%%', x*100), paramVariations, 'UniformOutput', false), ...
    'Interpreter', 'latex', 'Location', 'best');

subplot(1,2,2);
hold on;

for idx = 1:length(paramVariations)
    variation = paramVariations(idx);
    
    % Perturb plant time constant
    tau_perturbed = tau_plant * (1 + variation);
    denom_perturbed = conv([tau_perturbed 1], conv([tau_perturbed 1], [tau_perturbed 1]));
    plantTF_perturbed = tf(K_plant, denom_perturbed);
    
    closedLoop_perturbed = feedback(pidController * plantTF_perturbed, 1);
    
    step(closedLoop_perturbed, 100);
    
    stepInfo_pert = stepinfo(closedLoop_perturbed);
    
    fprintf('Time constant variation %+.0f%%: Ts = %.2f s, Mp = %.2f %%\n', ...
        variation*100, stepInfo_pert.SettlingTime, stepInfo_pert.Overshoot);
end

grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Output', 'Interpreter', 'latex', 'FontSize', 12);
title('Robustness: Time Constant Variations ($\pm 20\%$)', 'Interpreter', 'latex', 'FontSize', 14);
legend(arrayfun(@(x) sprintf('%+.0f\\%%', x*100), paramVariations, 'UniformOutput', false), ...
    'Interpreter', 'latex', 'Location', 'best');

saveas(gcf, 'Problem01_Robustness.fig');
saveas(gcf, 'Problem01_Robustness.eps', 'epsc');
saveas(gcf, 'Problem01_Robustness.jpg');

fprintf('\nSaved: Problem01_Robustness.fig/.eps/.jpg\n\n');

fprintf('=== Problem 1 Complete ===\n');
