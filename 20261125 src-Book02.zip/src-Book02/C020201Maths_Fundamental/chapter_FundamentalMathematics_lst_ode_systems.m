%% chapter_FundamentalMathematics_lst_ode_systems.m
% Solving ODEs in MATLAB - Van der Pol and Lorenz systems.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_lst_ode_systems
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section5.4_example1.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates ODE solving for Van der Pol and Lorenz systems

fprintf('=== Ordinary Differential Equations in MATLAB ===\n\n');

% - Part 1: Van der Pol Oscillator -
fprintf('- Part 1: Van der Pol Oscillator -\n');

% Define Van der Pol oscillator with mu = 1
mu = 1;
vdp_ode = @(t, y) [y(2); mu*(1 - y(1)^2)*y(2) - y(1)];

% Initial conditions
y0_vdp = [2; 0];
tspan_vdp = [0 20];

% Solve using ode45
fprintf('Solving with ode45...\n');
tic;
[t_vdp45, y_vdp45] = ode45(vdp_ode, tspan_vdp, y0_vdp);
time_ode45 = toc;
fprintf('ode45 completed in %.4f seconds (%d steps)\n', time_ode45, length(t_vdp45));

% Solve stiff version with large mu
mu_stiff = 1000;
vdp_stiff = @(t, y) [y(2); mu_stiff*(1 - y(1)^2)*y(2) - y(1)];
tspan_stiff = [0 3000];

fprintf('\nSolving stiff Van der Pol (mu = %d) with ode15s...\n', mu_stiff);
tic;
[t_vdp15s, y_vdp15s] = ode15s(vdp_stiff, tspan_stiff, y0_vdp);
time_ode15s = toc;
fprintf('ode15s completed in %.4f seconds (%d steps)\n', time_ode15s, length(t_vdp15s));

% Plot Van der Pol results
figure('Position', [100, 100, 1400, 500]);

subplot(1, 3, 1);
plot(t_vdp45, y_vdp45(:,1), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y_1(t)$', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Van der Pol Solution ($\\mu = %d$)', mu), 'Interpreter', 'latex', ...
    'FontSize', 14);

subplot(1, 3, 2);
plot(y_vdp45(:,1), y_vdp45(:,2), 'r-', 'LineWidth', 1.5);
grid on;
xlabel('$y_1$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y_2 = dy_1/dt$', 'Interpreter', 'latex', 'FontSize', 12);
title('Phase Portrait', 'Interpreter', 'latex', 'FontSize', 14);

subplot(1, 3, 3);
plot(y_vdp15s(:,1), y_vdp15s(:,2), 'g-', 'LineWidth', 1);
grid on;
xlabel('$y_1$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y_2 = dy_1/dt$', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Stiff Van der Pol ($\\mu = %d$)', mu_stiff), 'Interpreter', 'latex', ...
    'FontSize', 14);

saveas(gcf, 'van_der_pol_solutions.png');

% - Part 2: Lorenz System -
fprintf('\n- Part 2: Lorenz System (Chaotic Dynamics) -\n');

% Lorenz system parameters
sigma = 10;
rho = 28;
beta = 8/3;

% Define Lorenz system
lorenz_ode = @(t, y) [sigma*(y(2) - y(1));
                      y(1)*(rho - y(3)) - y(2);
                      y(1)*y(2) - beta*y(3)];

% Initial conditions
y0_lorenz = [1; 1; 1];
tspan_lorenz = [0 50];

% Solve using ode45
fprintf('Solving Lorenz system...\n');
[t_lorenz, y_lorenz] = ode45(lorenz_ode, tspan_lorenz, y0_lorenz);
fprintf('Solution computed with %d time steps\n', length(t_lorenz));

% Demonstrate sensitivity to initial conditions
y0_perturbed = y0_lorenz + [1e-5; 0; 0];  % Tiny perturbation
[t_lorenz2, y_lorenz2] = ode45(lorenz_ode, tspan_lorenz, y0_perturbed);

% Calculate divergence
divergence = sqrt(sum((y_lorenz - y_lorenz2).^2, 2));

% Plot Lorenz attractor
figure('Position', [100, 100, 1400, 900]);

subplot(2, 3, 1);
plot3(y_lorenz(:,1), y_lorenz(:,2), y_lorenz(:,3), 'b-', 'LineWidth', 0.8);
grid on;
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
zlabel('$z$', 'Interpreter', 'latex', 'FontSize', 12);
title('Lorenz Attractor (3*D)', 'Interpreter', 'latex', 'FontSize', 14);
view(45, 30);

subplot(2, 3, 2);
plot(t_lorenz, y_lorenz(:,1), 'r-', 'LineWidth', 1);
grid on;
xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$x(t)$', 'Interpreter', 'latex', 'FontSize', 12);
title('$x$ Component vs Time', 'Interpreter', 'latex', 'FontSize', 14);

subplot(2, 3, 3);
plot(y_lorenz(:,1), y_lorenz(:,3), 'g-', 'LineWidth', 0.8);
grid on;
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$z$', 'Interpreter', 'latex', 'FontSize', 12);
title('$x$-$z$ Projection', 'Interpreter', 'latex', 'FontSize', 14);

subplot(2, 3, 4);
plot(y_lorenz(:,1), y_lorenz(:,2), 'Color', [0.5 0 0.5], 'LineWidth', 0.8);
grid on;
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
title('$x$-$y$ Projection', 'Interpreter', 'latex', 'FontSize', 14);

subplot(2, 3, 5);
semilogy(t_lorenz, divergence, 'k-', 'LineWidth', 1.5);
grid on;
xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Distance between trajectories', 'Interpreter', 'latex', 'FontSize', 12);
title('Sensitivity to Initial Conditions', 'Interpreter', 'latex', 'FontSize', 14);

subplot(2, 3, 6);
plot3(y_lorenz(:,1), y_lorenz(:,2), y_lorenz(:,3), 'b-', 'LineWidth', 0.8);
hold on;
plot3(y_lorenz2(:,1), y_lorenz2(:,2), y_lorenz2(:,3), 'r--', 'LineWidth', 0.8);
grid on;
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
zlabel('$z$', 'Interpreter', 'latex', 'FontSize', 12);
title('Two Nearby Trajectories', 'Interpreter', 'latex', 'FontSize', 14);
legend('Original IC', 'Perturbed IC', 'Interpreter', 'latex', 'Location', 'best');
view(45, 30);
hold off;

saveas(gcf, 'lorenz_attractor_analysis.png');

fprintf('\nODE examples complete.\n');
fprintf('Figures saved: van_der_pol_solutions.png, lorenz_attractor_analysis.png\n');
