%% chapter_FundamentalMathematics_Lab1_code.m
% Laboratory1: Eigenvalue analysis and PCA implementation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_Lab1_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory exercise
laboratoryExercise1_EigenvaluePCA();

% Local functions (moved to end so this listing is a valid MATLAB script)
function laboratoryExercise1_EigenvaluePCA()
    % LABORATORYEXERCISE1_EIGENVALUEPCA Eigenvalue decomposition and PCA
    %   Comprehensive exploration of eigenanalysis and dimensionality reduction
    %
    %   Author: Dr Leo Chen
    %   Created: December 2024
    %   Version: 1.0
    %   MATLAB Version: R2023b or later
    
    fprintf('\\textbf{Laboratory1: Eigenvalue Analysis and PCA}\n');
    fprintf('==========================================================\n\n');
    
    %% Part A: Eigenvalue Decomposition
    fprintf('\\textbf{PART A: EIGENVALUE DECOMPOSITION}\n');
    fprintf('-------\n\n');
    
    % Historical context
    fprintf(['Historical Context: Augustin-Louis Cauchy (1821) developed\n', ...
        'eigenvalue theory whilst investigating rotational dynamics.\n', ...
        'These "characteristic values" reveal fundamental properties\n', ...
        'of linear transformations.\n\n']);
    
    % Create symmetric positive-definite matrix
    rng(42, 'twister');
    dimensionSize = 4;
    randomMatrix = randn(dimensionSize, dimensionSize);
    covarianceMatrix = randomMatrix' * randomMatrix;
    
    fprintf('Symmetric positive-definite matrix $\\mathbf{A}$:\n');
    displayMatrix(covarianceMatrix);
    
    % Compute eigendecomposition
    [eigenvectorMatrix, eigenvalueMatrix] = eig(covarianceMatrix);
    eigenvalues = diag(eigenvalueMatrix);
    
    % Sort in descending order
    [eigenvaluesSorted, sortIndices] = sort(eigenvalues, 'descend');
    eigenvectorsSorted = eigenvectorMatrix(:, sortIndices);
    
    fprintf('\\textbf{Eigenvalues} (sorted descending):\n');
    for idx = 1:length(eigenvaluesSorted)
        fprintf('  $\\lambda_{%d} = %.6f$\n', idx, eigenvaluesSorted(idx));
    end
    fprintf('\n');
    
    % Verify eigenvalue equation
    fprintf('\\textbf{Verification}: $\\mathbf{A}\\mathbf{v}_i = \\lambda_i\\mathbf{v}_i$\n\n');
    verificationResults = zeros(dimensionSize, 1);
    
    for idx = 1:dimensionSize
        eigenvector = eigenvectorsSorted(:, idx);
        eigenvalue = eigenvaluesSorted(idx);
        
        leftSide = covarianceMatrix * eigenvector;
        rightSide = eigenvalue * eigenvector;
        
        verificationError = norm(leftSide - rightSide);
        verificationResults(idx) = verificationError;
        
        fprintf('Eigenpair %d: $||\\mathbf{A}\\mathbf{v}_%d - \\lambda_%d\\mathbf{v}_%d|| = %.2e$\n', ...
            idx, idx, idx, idx, verificationError);
    end
    fprintf('\n');
    
    % Condition number analysis
    conditionNumber = cond(covarianceMatrix);
    fprintf(['\\textbf{Condition Number}: $\\kappa(\\mathbf{A}) = %.4f$\n', ...
        '(ratio of largest to smallest eigenvalue)\n\n'], conditionNumber);
    
    %% Part B: Principal Component Analysis
    fprintf('\\textbf{PART B: PRINCIPAL COMPONENT ANALYSIS}\n');
    fprintf('---------\n\n');
    
    fprintf(['Historical Context: Karl Pearson (1901) developed PCA\n', ...
        'to identify patterns in biological measurements, creating\n', ...
        'foundation for modern multivariate statistics.\n\n']);
    
    % Generate correlated 3*D data
    numSamples = 1000;
    meanVector = [5; 3; 2];
    trueCovarianceMatrix = [4.0, 2.8, 1.5;
                           2.8, 3.0, 1.2;
                           1.5, 1.2, 2.0];
    
    % Generate multivariate normal data
    dataMatrix = mvnrnd(meanVector, trueCovarianceMatrix, numSamples)';
    
    fprintf('Generated dataset: %d samples, %d dimensions\n', ...
        numSamples, size(dataMatrix, 1));
    fprintf('True mean vector: $[%.1f, %.1f, %.1f]^T$\n', meanVector);
    fprintf('\nTrue covariance matrix:\n');
    displayMatrix(trueCovarianceMatrix);
    
    % Centre data
    dataMean = mean(dataMatrix, 2);
    dataCentred = dataMatrix - dataMean;
    
    fprintf('Data centred (mean removed from each dimension)\n\n');
    
    % Compute sample covariance
    sampleCovariance = (dataCentred * dataCentred') / (numSamples - 1);
    
    fprintf('\\textbf{Sample covariance matrix}:\n');
    displayMatrix(sampleCovariance);
    
    % PCA via eigendecomposition
    [pcaVectors, pcaValues] = eig(sampleCovariance);
    pcaEigenvalues = diag(pcaValues);
    
    % Sort principal components
    [pcaEigenvaluesSorted, pcaIndices] = sort(pcaEigenvalues, 'descend');
    pcaVectorsSorted = pcaVectors(:, pcaIndices);
    
    % Compute variance explained
    totalVariance = sum(pcaEigenvaluesSorted);
    varianceExplained = (pcaEigenvaluesSorted / totalVariance) * 100;
    cumulativeVariance = cumsum(varianceExplained);
    
    fprintf('\\textbf{Principal Components Analysis}:\n\n');
    fprintf('%-10*s  %-15*s  %-20*s  %-20*s\n', 'PC', 'Eigenvalue', ...
        'Variance (\\%%)', 'Cumulative (\\%%)');
    fprintf('%s\n', repmat('-', 1, 75));
    
    for idx = 1:length(pcaEigenvaluesSorted)
        fprintf('%-10*d  %-15.6*f  %-20.2*f  %-20.2*f\n', idx, ...
            pcaEigenvaluesSorted(idx), varianceExplained(idx), ...
            cumulativeVariance(idx));
    end
    fprintf('\n');
    
    % Project data onto principal components
    dataProjected = pcaVectorsSorted' * dataCentred;
    
    fprintf(['Data projected onto principal component space\n', ...
        'Dimensions uncorrelated in PC space\n\n']);
    
    % Dimensionality reduction: keep first 2 PCs
    numComponentsRetained = 2;
    dataReduced = dataProjected(1:numComponentsRetained, :);
    
    fprintf('Dimensionality reduced: %d dimensions to %d dimensions\n', ...
        size(dataMatrix, 1), numComponentsRetained);
    fprintf('Variance retained: %.2f\\%%\n\n', ...
        cumulativeVariance(numComponentsRetained));
    
    % Reconstruct from reduced dimensions
    dataReconstructed = pcaVectorsSorted(:, 1:numComponentsRetained) * ...
        dataReduced + dataMean;
    
    % Compute reconstruction error
    reconstructionError = norm(dataMatrix - dataReconstructed, 'fro') / ...
        norm(dataMatrix, 'fro');
    
    fprintf('Reconstruction error (relative Frobenius norm): %.4f\n\n', ...
        reconstructionError);
    
    %% Visualisation
    createVisualisations(dataMatrix, dataCentred, pcaVectorsSorted, ...
        dataProjected, dataReconstructed, varianceExplained);
    
    fprintf('\\textbf{Exercise Complete}\n\n');
    fprintf(['Key Insights:\n', ...
        '1. Eigendecomposition reveals fundamental matrix properties\n', ...
        '2. PCA identifies directions of maximum variance\n', ...
        '3. Dimensionality reduction preserves essential structure\n', ...
        '4. First few PCs often capture most variance\n']);
end

function displayMatrix(matrixData)
    % DISPLAYMATRIX Format matrix for display
    [numRows, numCols] = size(matrixData);
    for rowIdx = 1:numRows
        fprintf('  [');
        for colIdx = 1:numCols
            fprintf(' %8.4*f', matrixData(rowIdx, colIdx));
        end
        fprintf(' ]\n');
    end
    fprintf('\n');
end

function createVisualisations(originalData, centredData, pcaVectors, ...
    projectedData, reconstructedData, varianceExplained)
    % CREATEVISUALISATIONS Generate comprehensive plots
    
    figure('Position', [100, 100, 1400, 1000]);
    
    % Original data in 3*D
    subplot(2, 3, 1);
    scatter3(originalData(1, :), originalData(2, :), originalData(3, :), ...
        20, 'b', 'filled', 'MarkerFaceAlpha', 0.3);
    xlabel('$x_1$', 'Interpreter', 'latex');
    ylabel('$x_2$', 'Interpreter', 'latex');
    zlabel('$x_3$', 'Interpreter', 'latex');
    title('Original Data (3*D)', 'Interpreter', 'latex');
    grid on;
    axis equal;
    view(45, 30);
    
    % Centred data with principal axes
    subplot(2, 3, 2);
    scatter3(centredData(1, :), centredData(2, :), centredData(3, :), ...
        20, 'b', 'filled', 'MarkerFaceAlpha', 0.3);
    hold on;
    
    % Plot principal component vectors
    scaleFactor = 3;
    colours = {'r', 'g', 'm'};
    for idx = 1:3
        pcVector = pcaVectors(:, idx) * scaleFactor;
        quiver3(0, 0, 0, pcVector(1), pcVector(2), pcVector(3), ...
            'LineWidth', 3, 'Color', colours{idx}, 'MaxHeadSize', 2);
        text(pcVector(1)*1.2, pcVector(2)*1.2, pcVector(3)*1.2, ...
            sprintf('$PC_%d$', idx), 'Interpreter', 'latex', ...
            'FontSize', 12, 'FontWeight', 'bold', 'Color', colours{idx});
    end
    
    xlabel('$x_1$ (centred)', 'Interpreter', 'latex');
    ylabel('$x_2$ (centred)', 'Interpreter', 'latex');
    zlabel('$x_3$ (centred)', 'Interpreter', 'latex');
    title('Centred Data with Principal Components', 'Interpreter', 'latex');
    grid on;
    axis equal;
    view(45, 30);
    
    % Scree plot
    subplot(2, 3, 3);
    bar(varianceExplained, 'FaceColor', [0.3, 0.6, 0.9]);
    xlabel('Principal Component', 'Interpreter', 'latex');
    ylabel('Variance Explained (\%)', 'Interpreter', 'latex');
    title('Scree Plot', 'Interpreter', 'latex');
    grid on;
    
    % Projected data (PC1 vs PC2)
    subplot(2, 3, 4);
    scatter(projectedData(1, :), projectedData(2, :), 20, 'b', ...
        'filled', 'MarkerFaceAlpha', 0.3);
    xlabel('$PC_1$', 'Interpreter', 'latex');
    ylabel('$PC_2$', 'Interpreter', 'latex');
    title('Projection onto First Two PCs', 'Interpreter', 'latex');
    grid on;
    axis equal;
    
    % Original vs reconstructed (dimension 1)
    subplot(2, 3, 5);
    sampleIndices = 1:100;
    plot(sampleIndices, originalData(1, sampleIndices), 'b-', ...
        'LineWidth', 1.5, 'DisplayName', 'Original');
    hold on;
    plot(sampleIndices, reconstructedData(1, sampleIndices), 'r-', ...
        'LineWidth', 1.5, 'DisplayName', 'Reconstructed');
    xlabel('Sample Index', 'Interpreter', 'latex');
    ylabel('$x_1$', 'Interpreter', 'latex');
    title('Reconstruction Quality (Dimension 1)', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Cumulative variance explained
    subplot(2, 3, 6);
    plot(1:length(varianceExplained), cumsum(varianceExplained), ...
        'b-o', 'LineWidth', 2, 'MarkerFaceColor', 'b');
    hold on;
    yline(90, 'r-', 'LineWidth', 2, 'Label', '90\% threshold');
    xlabel('Number of Components', 'Interpreter', 'latex');
    ylabel('Cumulative Variance Explained (\%)', 'Interpreter', 'latex');
    title('Cumulative Variance', 'Interpreter', 'latex');
    grid on;
    ylim([0, 105]);
end
