%% Appendix01-Solutions_code_243.m
% Complete MPC Implementation for Coupled Tank System
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Model Predictive Control (MPC) for Coupled Tank System
% Problem 10: MPC for Constrained Optimal Control
% Author: Control Systems Course
% Description: Complete MPC implementation with constraint handling

clear all; close all; clc;

%% System Definition
fprintf('=== MPC for Coupled Tank System ===\n\n');

% Continuous-time state-space model
% States: [h1; h2] (tank levels)
% Input: u (pump flow rate)
% Outputs: [h1; h2]

tau1 = 20;      % Tank 1 time constant (s)
tau2 = 25;      % Tank 2 time constant (s)
k1 = 0.5;       % Pump gain
k12 = 0.4;      % Inter-tank coupling coefficient

% Continuous system matrices
Ac = [-1/tau1,    0;
       k12/tau2, -1/tau2];
Bc = [k1; 0];
Cc = eye(2);    % Measure both tank levels
Dc = zeros(2,1);

% Display continuous system
sys_c = ss(Ac, Bc, Cc, Dc);
fprintf('Continuous-time system:\n');
disp(sys_c);

% Sampling time
Ts = 1;  % 1 second

% Discretize system using zero-order hold
sys_d = c2d(sys_c, Ts, 'zoh');
A = sys_d.A;
B = sys_d.B;
C = sys_d.C;
D = sys_d.D;

nx = size(A, 1);  % Number of states
nu = size(B, 2);  % Number of inputs
ny = size(C, 1);  % Number of outputs

fprintf('Discrete-time system (Ts = %.2f s):\n', Ts);
fprintf('A matrix:\n');
disp(A);
fprintf('B matrix:\n');
disp(B);

%% MPC Parameters
Np = 20;  % Prediction horizon
Nc = 10;  % Control horizon

% Weight matrices
Q = diag([10, 15]);  % Output tracking weight (higher for h2)
R = 0.5;             % Control effort weight
S = 1.0;             % Control rate weight (penalize rapid changes)

% Constraints
u_min = 0;      % Minimum pump flow
u_max = 10;     % Maximum pump flow
du_max = 2;     % Maximum flow rate change
h_min = [0; 0]; % Minimum tank levels
h_max = [5; 5]; % Maximum tank levels

fprintf('\nMPC Configuration:\n');
fprintf('Prediction Horizon (Np): %d steps\n', Np);
fprintf('Control Horizon (Nc): %d steps\n', Nc);
fprintf('Sampling Time: %.2f s\n', Ts);
fprintf('Input constraints: [%.1f, %.1f]\n', u_min, u_max);
fprintf('Rate constraint: +/- %.1f per step\n', du_max);

%% Build MPC Prediction Matrices
fprintf('\nBuilding MPC prediction matrices...\n');

% Prediction matrix F (free response)
F = zeros(nx*Np, nx);
for i = 1:Np
    F((i-1)*nx+1:i*nx, :) = A^i;
end

% Prediction matrix Phi (forced response)
Phi = zeros(nx*Np, nu*Nc);
for i = 1:Np
    for j = 1:min(i, Nc)
        Phi((i-1)*nx+1:i*nx, (j-1)*nu+1:j*nu) = A^(i-j) * B;
    end
end

% Output prediction matrices
Theta = C * F;  % Compact form: repeating C for each prediction step
Theta_full = zeros(ny*Np, nx);
for i = 1:Np
    Theta_full((i-1)*ny+1:i*ny, :) = C * F((i-1)*nx+1:i*nx, :);
end

Psi = zeros(ny*Np, nu*Nc);
for i = 1:Np
    for j = 1:Nc
        if j <= i
            Psi((i-1)*ny+1:i*ny, (j-1)*nu+1:j*nu) = C * Phi((i-1)*nx+1:i*nx, (j-1)*nu+1:j*nu);
        end
    end
end

% Expanded weight matrices for horizon
Q_bar = kron(eye(Np), Q);
R_bar = kron(eye(Nc), R);
S_bar = kron(eye(Nc), S);

% QP Hessian matrix (constant)
H = 2*(Psi'*Q_bar*Psi + R_bar);

% Ensure H is symmetric and positive definite
H = (H + H')/2;
H = H + 1e-6*eye(size(H));  % Regularization for numerical stability

fprintf('Prediction matrices constructed.\n');
fprintf('Hessian matrix size: %dx%d\n', size(H,1), size(H,2));

%% Build Constraint Matrices
fprintf('\nBuilding constraint matrices...\n');

% Input constraints: u_min <= u(k+i) <= u_max
% For MPC with Nc moves
A_u = [eye(Nc); -eye(Nc)];
b_u = [u_max*ones(Nc,1); -u_min*ones(Nc,1)];

% Rate constraints: -du_max <= du(k+i) <= du_max
% du(k) = u(k) - u(k-1)
A_du = [eye(Nc); -eye(Nc)];
b_du_base = [du_max*ones(Nc,1); du_max*ones(Nc,1)];

% Output constraints: h_min <= y(k+i) <= h_max
% y = Psi*U + Theta*x, so Psi*U <= h_max - Theta*x
% More complex - we'll handle in optimization loop

% Combine input and rate constraints
A_ineq_base = [A_u; A_du];

fprintf('Constraint matrices constructed.\n');

%% Simulation Setup
T_sim = 200;  % Simulation time (steps)
x = zeros(nx, T_sim+1);  % State trajectory
y = zeros(ny, T_sim+1);  % Output trajectory
u = zeros(1, T_sim);     % Control input
u_mpc = zeros(1, T_sim); % MPC optimal sequence
r = zeros(ny, T_sim);    % Reference trajectory

% Initial conditions
x(:,1) = [2; 1.5];  % Start at [2m, 1.5m]
y(:,1) = C*x(:,1);
u_prev = 5;  % Previous control input

% Reference trajectory
r(1, 1:60) = 3;      % h1 = 3m
r(2, 1:60) = 2.5;    % h2 = 2.5m
r(1, 61:120) = 4;    % h1 = 4m  
r(2, 61:120) = 3.5;  % h2 = 3.5m
r(1, 121:end) = 2.5; % h1 = 2.5m
r(2, 121:end) = 2;   % h2 = 2m

% Disturbance (applied at k=140)
add_disturbance = true;
disturbance_time = 140;
disturbance_magnitude = [0.5; -0.3];

fprintf('\nStarting MPC simulation...\n');
fprintf('Simulation time: %d steps (%.1f seconds)\n', T_sim, T_sim*Ts);

%% MPC Closed-Loop Simulation
solve_times = zeros(T_sim, 1);

for k = 1:T_sim
    if mod(k, 20) == 0
        fprintf('Step %d/%d\n', k, T_sim);
    end
    
    % Current state
    x_curr = x(:, k);
    
    % Build reference trajectory over prediction horizon
    R = zeros(ny*Np, 1);
    for i = 1:Np
        if k+i <= T_sim
            R((i-1)*ny+1:i*ny) = r(:, k+i);
        else
            R((i-1)*ny+1:i*ny) = r(:, end);
        end
    end
    
    % QP linear term (depends on current state and reference)
    f = 2*Psi'*Q_bar*(Theta_full*x_curr - R);
    
    % Update rate constraint with previous control
    b_du = b_du_base;
    b_du(1) = b_du(1) + u_prev;          % u(k) - u(k-1) <= du_max
    b_du(Nc+1) = b_du(Nc+1) + u_prev;    % -(u(k) - u(k-1)) <= du_max
    
    % Combine constraints
    A_ineq = A_ineq_base;
    b_ineq = [b_u; b_du];
    
    % Output constraints (simplified - only check predicted outputs)
    % For full implementation, would add: Psi*U <= y_max - Theta*x_curr
    
    % Solve QP problem
    options = optimoptions('quadprog', 'Display', 'off', ...
                          'MaxIterations', 200, ...
                          'OptimalityTolerance', 1e-8);
    
    tic;
    [U_opt, ~, exitflag, ~] = quadprog(H, f, A_ineq, b_ineq, ...
                                       [], [], [], [], [], options);
    solve_times(k) = toc;
    
    if exitflag <= 0
        warning('QP solver failed at step %d (exitflag = %d)', k, exitflag);
        % Use previous control or zero
        u(k) = u_prev;
    else
        % Apply first control from optimal sequence
        u(k) = U_opt(1);
        u_mpc(k) = u(k);
    end
    
    % Saturate control (safety check)
    u(k) = max(u_min, min(u_max, u(k)));
    
    % Apply disturbance
    if add_disturbance && k == disturbance_time
        x(:, k) = x(:, k) + disturbance_magnitude;
        fprintf('Disturbance applied at k=%d: [%.2f, %.2f]\n', ...
                k, disturbance_magnitude(1), disturbance_magnitude(2));
    end
    
    % System update
    x(:, k+1) = A*x(:, k) + B*u(k);
    y(:, k+1) = C*x(:, k+1);
    
    % Update previous control
    u_prev = u(k);
end

fprintf('MPC simulation completed.\n');
fprintf('Average solve time: %.4f ms\n', mean(solve_times)*1000);
fprintf('Max solve time: %.4f ms\n', max(solve_times)*1000);

%% LQR Controller for Comparison
fprintf('\nDesigning LQR controller for comparison...\n');

% LQR design (unconstrained)
Q_lqr = Q;
R_lqr = R;
[K_lqr, ~, ~] = dlqr(A, B, Q_lqr, R_lqr);

% LQR simulation
x_lqr = zeros(nx, T_sim+1);
y_lqr = zeros(ny, T_sim+1);
u_lqr = zeros(1, T_sim);
x_lqr(:,1) = x(:,1);  % Same initial condition
y_lqr(:,1) = C*x_lqr(:,1);

% Compute equilibrium for reference tracking
% For step reference r_ss: x_ss = (I-A)^(-1)*B*u_ss, r_ss = C*x_ss
% This gives: u_ss = (C*(I-A)^(-1)*B)^(-1) * r_ss
% Augmented LQR for tracking would be better, but for comparison
% we'll use simple state feedback

for k = 1:T_sim
    % Simple implementation: regulate around reference
    % Convert reference to state (assuming steady-state)
    r_curr = r(:, k);
    
    % Compute feedforward (rough approximation)
    % For better tracking, use augmented state with integrator
    u_ff = (C*((eye(nx)-A)\B)) \ r_curr;
    
    % State feedback
    u_fb = -K_lqr * (x_lqr(:,k) - (eye(nx)-A)\(B*u_ff));
    u_lqr(k) = u_ff + u_fb;
    
    % Note: LQR doesn't respect constraints!
    % Saturate for safety
    u_lqr(k) = max(u_min, min(u_max, u_lqr(k)));
    
    % Apply disturbance
    if add_disturbance && k == disturbance_time
        x_lqr(:, k) = x_lqr(:, k) + disturbance_magnitude;
    end
    
    % System update
    x_lqr(:, k+1) = A*x_lqr(:, k) + B*u_lqr(k);
    y_lqr(:, k+1) = C*x_lqr(:, k+1);
end

fprintf('LQR simulation completed.\n');

%% Performance Metrics
fprintf('\n=== Performance Comparison ===\n');

% MPC metrics
e_mpc = y(:,1:T_sim) - r;
J_mpc = sum(sum(e_mpc.^2)) + R*sum(u.^2);
IAE_mpc = sum(sum(abs(e_mpc)));
ISE_mpc = sum(sum(e_mpc.^2));
max_u_mpc = max(u);
u_violations_mpc = sum(u > u_max | u < u_min);

% LQR metrics
e_lqr = y_lqr(:,1:T_sim) - r;
J_lqr = sum(sum(e_lqr.^2)) + R*sum(u_lqr.^2);
IAE_lqr = sum(sum(abs(e_lqr)));
ISE_lqr = sum(sum(e_lqr.^2));
max_u_lqr = max(u_lqr);
u_violations_lqr = sum(u_lqr > u_max | u_lqr < u_min);

fprintf('\nMPC Performance:\n');
fprintf('  Total cost J: %.2f\n', J_mpc);
fprintf('  IAE: %.2f\n', IAE_mpc);
fprintf('  ISE: %.2f\n', ISE_mpc);
fprintf('  Max control: %.2f\n', max_u_mpc);
fprintf('  Constraint violations: %d\n', u_violations_mpc);

fprintf('\nLQR Performance:\n');
fprintf('  Total cost J: %.2f\n', J_lqr);
fprintf('  IAE: %.2f\n', IAE_lqr);
fprintf('  ISE: %.2f\n', ISE_lqr);
fprintf('  Max control: %.2f\n', max_u_lqr);
fprintf('  Constraint violations: %d\n', u_violations_lqr);

%% Visualization
time = (0:T_sim)*Ts;

figure('Position', [100 100 1200 800]);

% Tank 1 level
subplot(3,2,1);
stairs(time(1:end-1), r(1,:), 'k-', 'LineWidth', 1.5); hold on;
stairs(time, y(1,:), 'b-', 'LineWidth', 2);
stairs(time, y_lqr(1,:), 'r:', 'LineWidth', 1.5);
if add_disturbance
    xline(disturbance_time*Ts, 'g-', 'Disturbance', 'LineWidth', 1.5);
end
grid on;
ylabel('Tank 1 Level (m)');
title('Tank 1 Level Control');
legend('Reference', 'MPC', 'LQR', 'Location', 'best');
ylim([0 5.5]);

% Tank 2 level
subplot(3,2,2);
stairs(time(1:end-1), r(2,:), 'k-', 'LineWidth', 1.5); hold on;
stairs(time, y(2,:), 'b-', 'LineWidth', 2);
stairs(time, y_lqr(2,:), 'r:', 'LineWidth', 1.5);
if add_disturbance
    xline(disturbance_time*Ts, 'g-', 'Disturbance', 'LineWidth', 1.5);
end
grid on;
ylabel('Tank 2 Level (m)');
title('Tank 2 Level Control');
legend('Reference', 'MPC', 'LQR', 'Location', 'best');
ylim([0 5.5]);

% Control input
subplot(3,2,3);
stairs(time(1:end-1), u, 'b-', 'LineWidth', 2); hold on;
stairs(time(1:end-1), u_lqr, 'r:', 'LineWidth', 1.5);
yline(u_max, 'r-', 'u_{max}', 'LineWidth', 1.5);
yline(u_min, 'r-', 'u_{min}', 'LineWidth', 1.5);
if add_disturbance
    xline(disturbance_time*Ts, 'g-', 'Disturbance', 'LineWidth', 1.5);
end
grid on;
ylabel('Pump Flow (L/s)');
xlabel('Time (s)');
title('Control Input');
legend('MPC', 'LQR', 'Constraints', 'Location', 'best');

% Control rate
subplot(3,2,4);
du_mpc = [0, diff(u)];
du_lqr_vec = [0, diff(u_lqr)];
stairs(time(1:end-1), du_mpc, 'b-', 'LineWidth', 2); hold on;
stairs(time(1:end-1), du_lqr_vec, 'r:', 'LineWidth', 1.5);
yline(du_max, 'r-', '\Deltau_{max}', 'LineWidth', 1.5);
yline(-du_max, 'r-', '\Deltau_{min}', 'LineWidth', 1.5);
grid on;
ylabel('\Deltau (L/s per step)');
xlabel('Time (s)');
title('Control Rate');
legend('MPC', 'LQR', 'Constraints', 'Location', 'best');

% Tracking error
subplot(3,2,5);
error_norm_mpc = sqrt(e_mpc(1,:).^2 + e_mpc(2,:).^2);
error_norm_lqr = sqrt(e_lqr(1,:).^2 + e_lqr(2,:).^2);
plot(time(1:end-1), error_norm_mpc, 'b-', 'LineWidth', 2); hold on;
plot(time(1:end-1), error_norm_lqr, 'r:', 'LineWidth', 1.5);
if add_disturbance
    xline(disturbance_time*Ts, 'g-', 'Disturbance', 'LineWidth', 1.5);
end
grid on;
ylabel('Tracking Error Norm');
xlabel('Time (s)');
title('Tracking Error ||y - r||');
legend('MPC', 'LQR', 'Location', 'best');

% Cost evolution
subplot(3,2,6);
J_cum_mpc = cumsum(sum(e_mpc.^2) + R*u.^2);
J_cum_lqr = cumsum(sum(e_lqr.^2) + R*u_lqr.^2);
plot(time(1:end-1), J_cum_mpc, 'b-', 'LineWidth', 2); hold on;
plot(time(1:end-1), J_cum_lqr, 'r:', 'LineWidth', 1.5);
grid on;
ylabel('Cumulative Cost');
xlabel('Time (s)');
title('Cumulative Cost Evolution');
legend('MPC', 'LQR', 'Location', 'best');

sgtitle('MPC vs LQR: Coupled Tank System Control', 'FontSize', 14, 'FontWeight', 'bold');

%% State-Space Trajectory
figure('Position', [150 150 800 600]);
plot(x(1,:), x(2,:), 'b-', 'LineWidth', 2); hold on;
plot(x_lqr(1,:), x_lqr(2,:), 'r:', 'LineWidth', 1.5);
plot(x(1,1), x(2,1), 'go', 'MarkerSize', 10, 'LineWidth', 2);
plot(x(1,end), x(2,end), 'bs', 'MarkerSize', 10, 'LineWidth', 2);

% Plot reference points
ref_points = unique(r', 'rows');
plot(ref_points(:,1), ref_points(:,2), 'kx', 'MarkerSize', 12, 'LineWidth', 2);

grid on;
xlabel('h_1 (m)');
ylabel('h_2 (m)');
title('State-Space Trajectory');
legend('MPC', 'LQR', 'Initial', 'Final', 'Setpoints', 'Location', 'best');
axis equal;
xlim([0 5]);
ylim([0 5]);

%% MPC Prediction Visualization (at one time instant)
k_plot = 80;  % Time instant to visualize

% Get optimal control sequence
x_curr = x(:, k_plot);
R_plot = zeros(ny*Np, 1);
for i = 1:Np
    if k_plot+i <= T_sim
        R_plot((i-1)*ny+1:i*ny) = r(:, k_plot+i);
    else
        R_plot((i-1)*ny+1:i*ny) = r(:, end);
    end
end

f_plot = 2*Psi'*Q_bar*(Theta_full*x_curr - R_plot);
b_du_plot = b_du_base;
b_du_plot(1) = b_du_plot(1) + u(k_plot-1);
b_du_plot(Nc+1) = b_du_plot(Nc+1) + u(k_plot-1);
A_ineq_plot = A_ineq_base;
b_ineq_plot = [b_u; b_du_plot];

[U_opt_plot, ~, ~, ~] = quadprog(H, f_plot, A_ineq_plot, b_ineq_plot, ...
                                 [], [], [], [], [], options);

% Predicted outputs
Y_pred = Psi*U_opt_plot + Theta_full*x_curr;

% Reshape predictions
h1_pred = Y_pred(1:ny:end);
h2_pred = Y_pred(2:ny:end);
u_pred = U_opt_plot(1:nu:end);

figure('Position', [200 200 1000 400]);

subplot(1,2,1);
stairs(k_plot:k_plot+Np-1, [h1_pred, h2_pred], 'LineWidth', 2); hold on;
stairs(k_plot:k_plot+Np-1, R_plot(1:ny:end), 'k-', 'LineWidth', 1.5);
stairs(k_plot:k_plot+Np-1, R_plot(2:ny:end), 'k-', 'LineWidth', 1.5);
grid on;
xlabel('Time Step');
ylabel('Tank Level (m)');
title(sprintf('MPC Output Prediction at k=%d', k_plot));
legend('h_1 predicted', 'h_2 predicted', 'References', 'Location', 'best');

subplot(1,2,2);
stairs(k_plot:k_plot+Nc-1, u_pred, 'b-', 'LineWidth', 2); hold on;
yline(u_max, 'r-', 'u_{max}', 'LineWidth', 1.5);
yline(u_min, 'r-', 'u_{min}', 'LineWidth', 1.5);
grid on;
xlabel('Time Step');
ylabel('Control Input (L/s)');
title('MPC Control Sequence');
legend('Optimal u', 'Constraints', 'Location', 'best');

sgtitle(sprintf('MPC Prediction Horizon at Time k=%d', k_plot), ...
        'FontSize', 13, 'FontWeight', 'bold');

fprintf('\n=== MPC Analysis Complete ===\n');
