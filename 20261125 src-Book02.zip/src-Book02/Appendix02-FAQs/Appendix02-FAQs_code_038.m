%% Appendix02-FAQs_code_038.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLAB Code for Local Magnification of Scatter Plots

% Add magnify.m to MATLAB search path or current working directory
% After completing the basic drawing, enter the following two lines of code
magnify(gcf);

% Example usage with a scatter plot
clc;
clear;
close all;

% Load Iris dataset
load fisheriris
meas = [meas(:,1), meas(:,2)];
species = categorical(species);

% Define colors for each species
colors = containers.Map({'setosa', 'versicolor', 'virginica'}, ...
                        {'#006a8e', '#b1283a', '#a8a6a7'});

% Create figure and main axes
fig = figure('Position', [100, 100, 800, 600]);
ax = axes('Parent', fig);

% Store median information for each category
medians = containers.Map;

% Plot data and mark medians
for i = 1:length(categories(species))
    category = categories(species)(i);
    subset = meas(species == category, :);
    
    % Scatter plot for each category
    scatter(ax, subset(:,1), subset(:,2), ...
            'MarkerEdgeColor', colors(category), ...
            'MarkerFaceAlpha', 0.6, ...
            'MarkerSize', 15);
    
    % Calculate median
    median_x = median(subset(:,1));
    median_y = median(subset(:,2));
    medians(category) = [median_x, median_y];
    
    % Mark median point
    scatter(ax, median_x, median_y, ...
            'MarkerEdgeColor', 'white', ...
            'MarkerFaceColor', 'black', ...
            'MarkerSize', 10, ...
            'ZData', 15);
    
    % Add text annotation for median point
    text(ax, median_x, median_y, ...
         category(1:3), ...
         'Color', 'black', ...
         'FontSize', 8, ...
         'HorizontalAlignment', 'center', ...
         'VerticalAlignment', 'center');
end

% Set title and labels
title(ax, 'Local Magnification of Scatter Plot', 'FontSize', 16, 'FontWeight', 'bold');
xlabel(ax, 'Sepal Length (cm)');
ylabel(ax, 'Sepal Width (cm)');
legend(ax, categories(species), 'Location', 'best');

% Enable magnification
magnify(gcf);
