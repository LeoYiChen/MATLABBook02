%% chapter_FundamentalMathematics_Lab2_code.m
% Laboratory2: Numerical calculus methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_Lab2_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory exercise
laboratoryExercise2_NumericalCalculus();

% Local functions (moved to end so this listing is a valid MATLAB script)
function laboratoryExercise2_NumericalCalculus()
    % LABORATORYEXERCISE2_NUMERICALCALCULUS Differentiation and integration
    %   Comprehensive exploration of numerical calculus techniques
    %
    %   Author: Dr Leo Chen
    %   Created: December 2024
    %   Version: 1.0
    %   MATLAB Version: R2023b or later
    
    fprintf('\\textbf{Laboratory2: Numerical Calculus}\n');
    fprintf('==================================================\n\n');
    
    %% Part A: Numerical Differentiation
    fprintf('\\textbf{PART A: NUMERICAL DIFFERENTIATION}\n');
    fprintf('--------\n\n');
    
    fprintf(['Historical Context: Newton (1665) developed calculus\n', ...
        'analytically, but numerical methods became essential for\n', ...
        'functions lacking closed-form derivatives.\n\n']);
    
    % Define test function and its exact derivative
    testFunction = @(x) sin(x);
    exactDerivative = @(x) cos(x);
    evaluationPoint = pi / 4;
    exactValue = exactDerivative(evaluationPoint);
    
    fprintf('Test function: $f(x) = \\sin(x)$\n');
    fprintf('Exact derivative: $f''(x) = \\cos(x)$\n');
    fprintf('Evaluation point: $x = \\pi/4$\n');
    fprintf('Exact value: $f''(\\pi/4) = %.15f$\n\n', exactValue);
    
    % Range of step sizes
    stepSizes = logspace(-16, 0, 33);
    numSteps = length(stepSizes);
    
    % Storage for errors
    errorsForward = zeros(numSteps, 1);
    errorsBackward = zeros(numSteps, 1);
    errorsCentral = zeros(numSteps, 1);
    
    % Compute finite differences
    for idx = 1:numSteps
        h = stepSizes(idx);
        
        % Forward difference: [f(x+h) - f(x)] / h
        derivForward = (testFunction(evaluationPoint + h) - ...
            testFunction(evaluationPoint)) / h;
        errorsForward(idx) = abs(derivForward - exactValue);
        
        % Backward difference: [f(x) - f(x-h)] / h
        derivBackward = (testFunction(evaluationPoint) - ...
            testFunction(evaluationPoint - h)) / h;
        errorsBackward(idx) = abs(derivBackward - exactValue);
        
        % Central difference: [f(x+h) - f(x-h)] / (2*h)
        derivCentral = (testFunction(evaluationPoint + h) - ...
            testFunction(evaluationPoint - h)) / (2 * h);
        errorsCentral(idx) = abs(derivCentral - exactValue);
    end
    
    % Find optimal step sizes
    [minErrorForward, idxForward] = min(errorsForward);
    [minErrorCentral, idxCentral] = min(errorsCentral);
    
    fprintf('\\textbf{Optimal Step Sizes}:\n');
    fprintf('  Forward difference: $h_{opt} = %.2e$, error = %.2e\n', ...
        stepSizes(idxForward), minErrorForward);
    fprintf('  Central difference: $h_{opt} = %.2e$, error = %.2e\n\n', ...
        stepSizes(idxCentral), minErrorCentral);
    
    % Theoretical analysis
    fprintf(['\\textbf{Theoretical Error Behaviour}:\n', ...
        '  Forward/Backward: $O(h)$ truncation + $O(\\epsilon/h)$ round-off\n', ...
        '  Central: $O(h^2)$ truncation + $O(\\epsilon/h)$ round-off\n', ...
        '  Optimal $h \\approx \\sqrt{\\epsilon}$ (forward), ', ...
        '$\\epsilon^{1/3}$ (central)\n', ...
        '  where $\\epsilon$ = machine epsilon $\\approx 10^{-16}$\n\n']);
    
    %% Part B: Numerical Integration
    fprintf('\\textbf{PART B: NUMERICAL INTEGRATION}\n');
    fprintf('--------\n\n');
    
    fprintf(['Historical Context: Newton-Cotes formulas (17*th century)\n', ...
        'approximate integrals using polynomial interpolation through\n', ...
        'equally-spaced points.\n\n']);
    
    % Define integrand with known exact integral
    integrand = @(x) sin(x);
    lowerLimit = 0;
    upperLimit = pi;
    exactIntegral = 2;  % ∫₀^π sin(x) dx = 2
    
    fprintf('Integrand: $f(x) = \\sin(x)$\n');
    fprintf('Limits: $a = 0$, $b = \\pi$\n');
    fprintf('Exact value: $\\int_0^\\pi \\sin(x) \\, dx = 2$\n\n');
    
    % Composite trapezoidal rule
    fprintf('\\textbf{Composite Trapezoidal Rule}:\n');
    subdivisions = [10, 50, 100, 500, 1000, 5000];
    
    fprintf('%-15*s  %-20*s  %-15*s\n', 'Subdivisions', 'Approximation', ...
        'Error');
    fprintf('%s\n', repmat('-', 1, 55));
    
    trapezoidalResults = zeros(length(subdivisions), 3);
    
    for idx = 1:length(subdivisions)
        n = subdivisions(idx);
        xPoints = linspace(lowerLimit, upperLimit, n + 1);
        yPoints = integrand(xPoints);
        h = (upperLimit - lowerLimit) / n;
        
        % Trapezoidal approximation
        integralApprox = h * (sum(yPoints) - ...
            (yPoints(1) + yPoints(end)) / 2);
        error = abs(integralApprox - exactIntegral);
        
        trapezoidalResults(idx, :) = [n, integralApprox, error];
        
        fprintf('%-15*d  %-20.15*f  %-15.2*e\n', n, integralApprox, error);
    end
    fprintf('\n');
    
    % Simpson's rule
    fprintf('\\textbf{Composite Simpson''s Rule}:\n');
    fprintf('%-15*s  %-20*s  %-15*s\n', 'Subdivisions', 'Approximation', ...
        'Error');
    fprintf('%s\n', repmat('-', 1, 55));
    
    simpsonResults = zeros(length(subdivisions), 3);
    
    for idx = 1:length(subdivisions)
        n = subdivisions(idx);
        if mod(n, 2) == 1
            n = n + 1;  % Simpson requires even number
        end
        
        xPoints = linspace(lowerLimit, upperLimit, n + 1);
        yPoints = integrand(xPoints);
        h = (upperLimit - lowerLimit) / n;
        
        % Simpson's 1/3 rule
        integralApprox = (h / 3) * (yPoints(1) + yPoints(end) + ...
            4 * sum(yPoints(2:2:end-1)) + 2 * sum(yPoints(3:2:end-2)));
        error = abs(integralApprox - exactIntegral);
        
        simpsonResults(idx, :) = [n, integralApprox, error];
        
        fprintf('%-15*d  %-20.15*f  %-15.2*e\n', n, integralApprox, error);
    end
    fprintf('\n');
    
    % MATLAB's adaptive quadrature
    fprintf('\\textbf{MATLAB Adaptive Quadrature}:\n');
    
    tic;
    integralAdaptive = integral(integrand, ...
        lowerLimit, upperLimit, 'AbsTol', 1e-12, 'RelTol', 1e-10);
    computeTime = toc;
    
    actualError = abs(integralAdaptive - exactIntegral);
    
    fprintf('  Result: %.15f\n', integralAdaptive);
    fprintf('  Estimated error: %.2e\n', errorEstimate);
    fprintf('  Actual error: %.2e\n', actualError);
    fprintf('  Computation time: %.6f seconds\n\n', computeTime);
    
    %% Part C: Ordinary Differential Equations
    fprintf('\\textbf{PART C: ORDINARY DIFFERENTIAL EQUATIONS}\n');
    fprintf('---------\n\n');
    
    fprintf(['Historical Context: Euler (1768) developed first numerical\n', ...
        'method for ODEs. Runge-Kutta methods (1900*s) dramatically\n', ...
        'improved accuracy whilst maintaining computational efficiency.\n\n']);
    
    % Define ODE: dy/dt = -2*y + cos(t), y(0) = 1
    % Exact solution: y(t) = (1/5)[2*cos(t) + sin(t)] + (3/5)*exp(-2*t)
    odeFunction = @(t, y) -2 * y + cos(t);
    exactSolution = @(t) (1/5) * (2 * cos(t) + sin(t)) + ...
        (3/5) * exp(-2 * t);
    
    initialCondition = 1;
    timeSpan = [0, 5];
    
    fprintf('ODE: $dy/dt = -2*y + \\cos(t)$, $y(0) = 1$\n\n');
    
    % Forward Euler method
    fprintf('\\textbf{Forward Euler Method}:\n');
    stepSize = 0.1;
    tEuler = timeSpan(1):stepSize:timeSpan(2);
    yEuler = zeros(size(tEuler));
    yEuler(1) = initialCondition;
    
    for idx = 1:(length(tEuler) - 1)
        yEuler(idx + 1) = yEuler(idx) + ...
            stepSize * odeFunction(tEuler(idx), yEuler(idx));
    end
    
    eulerError = abs(yEuler(end) - exactSolution(tEuler(end)));
    fprintf('  Step size: $h = %.2f$\n', stepSize);
    fprintf('  Final value: $y(%.1f) = %.6f$\n', tEuler(end), yEuler(end));
    fprintf('  Error: %.2e\n\n', eulerError);
    
    % MATLAB's ode45 (Dormand-Prince)
    fprintf('\\textbf{MATLAB ode45 (Runge-Kutta 4-5)}:\n');
    
    tic;
    [tODE45, yODE45] = ode45(odeFunction, timeSpan, initialCondition);
    ode45Time = toc;
    
    ode45Error = abs(yODE45(end) - exactSolution(tODE45(end)));
    
    fprintf('  Number of steps: %d\n', length(tODE45));
    fprintf('  Final value: $y(%.1f) = %.15f$\n', tODE45(end), yODE45(end));
    fprintf('  Error: %.2e\n', ode45Error);
    fprintf('  Computation time: %.6f seconds\n\n', ode45Time);
    
    fprintf(['\\textbf{Key Observation}: ode45 achieves %.2e error\n', ...
        'compared to Euler''s %.2e error, demonstrating superiority\n', ...
        'of higher-order methods.\n\n'], ode45Error, eulerError);
    
    %% Visualisations
    createNumericalCalculusPlots(stepSizes, errorsForward, errorsCentral, ...
        subdivisions, trapezoidalResults, simpsonResults, ...
        tEuler, yEuler, tODE45, yODE45, exactSolution, timeSpan);
    
    fprintf('\\textbf{Exercise Complete}\n\n');
    fprintf(['Key Insights:\n', ...
        '1. Central differences achieve $O(h^2)$ vs forward $O(h)$ accuracy\n', ...
        '2. Optimal step sizes balance truncation and round-off errors\n', ...
        '3. Simpson''s rule converges faster than trapezoidal rule\n', ...
        '4. Adaptive quadrature automatically selects appropriate subdivisions\n', ...
        '5. Higher-order ODE solvers dramatically reduce errors\n']);
end

function createNumericalCalculusPlots(stepSizes, errorsForward, ...
    errorsCentral, subdivisions, trapResults, simpResults, ...
    tEuler, yEuler, tODE45, yODE45, exactSol, timeSpan)
    % CREATENUMERICALCALCULUSPLOTS Generate comprehensive visualisations
    
    figure('Position', [100, 100, 1400, 900]);
    
    % Differentiation errors
    subplot(2, 3, 1);
    loglog(stepSizes, errorsForward, 'b-o', 'LineWidth', 2, ...
        'DisplayName', 'Forward Difference');
    hold on;
    loglog(stepSizes, errorsCentral, 'r-s', 'LineWidth', 2, ...
        'DisplayName', 'Central Difference');
    loglog(stepSizes, stepSizes, 'k-', 'LineWidth', 1.5, ...
        'DisplayName', '$O(h)$');
    loglog(stepSizes, stepSizes.^2, 'k:', 'LineWidth', 1.5, ...
        'DisplayName', '$O(h^2)$');
    
    xlabel('Step Size $h$', 'Interpreter', 'latex');
    ylabel('Absolute Error', 'Interpreter', 'latex');
    title('Numerical Differentiation Error', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Integration convergence
    subplot(2, 3, 2);
    loglog(trapResults(:, 1), trapResults(:, 3), 'b-o', 'LineWidth', 2, ...
        'DisplayName', 'Trapezoidal');
    hold on;
    loglog(simpResults(:, 1), simpResults(:, 3), 'r-s', 'LineWidth', 2, ...
        'DisplayName', 'Simpson');
    
    xlabel('Number of Subdivisions', 'Interpreter', 'latex');
    ylabel('Absolute Error', 'Interpreter', 'latex');
    title('Integration Convergence', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Convergence rates
    subplot(2, 3, 3);
    trapRates = -diff(log(trapResults(:, 3))) ./ ...
        diff(log(trapResults(:, 1)));
    simpRates = -diff(log(simpResults(:, 3))) ./ ...
        diff(log(simpResults(:, 1)));
    
    semilogx(subdivisions(2:end), trapRates, 'b-o', 'LineWidth', 2, ...
        'DisplayName', 'Trapezoidal');
    hold on;
    semilogx(subdivisions(2:end), simpRates, 'r-s', 'LineWidth', 2, ...
        'DisplayName', 'Simpson');
    yline(2, 'k-', 'LineWidth', 1.5, 'Label', 'Theoretical O(h^2)');
    yline(4, 'k:', 'LineWidth', 1.5, 'Label', 'Theoretical O(h^4)');
    
    xlabel('Number of Subdivisions', 'Interpreter', 'latex');
    ylabel('Convergence Rate', 'Interpreter', 'latex');
    title('Observed Convergence Rates', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    ylim([0, 5]);
    
    % ODE solutions comparison
    subplot(2, 3, 4);
    tExact = linspace(timeSpan(1), timeSpan(2), 1000);
    yExact = exactSol(tExact);
    
    plot(tExact, yExact, 'k-', 'LineWidth', 2.5, ...
        'DisplayName', 'Exact Solution');
    hold on;
    plot(tEuler, yEuler, 'b-o', 'LineWidth', 1.5, 'MarkerSize', 4, ...
        'DisplayName', 'Euler Method');
    plot(tODE45, yODE45, 'r:', 'LineWidth', 2, ...
        'DisplayName', 'ODE45');
    
    xlabel('Time $t$', 'Interpreter', 'latex');
    ylabel('$y(t)$', 'Interpreter', 'latex');
    title('ODE Solution Comparison', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % ODE errors over time
    subplot(2, 3, 5);
    eulerErrorOverTime = abs(yEuler - exactSol(tEuler));
    ode45ErrorOverTime = abs(yODE45 - exactSol(tODE45));
    
    semilogy(tEuler, eulerErrorOverTime, 'b-o', 'LineWidth', 1.5, ...
        'DisplayName', 'Euler Method');
    hold on;
    semilogy(tODE45, ode45ErrorOverTime, 'r-s', 'LineWidth', 1.5, ...
        'DisplayName', 'ODE45');
    
    xlabel('Time $t$', 'Interpreter', 'latex');
    ylabel('Absolute Error', 'Interpreter', 'latex');
    title('ODE Error Evolution', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Phase portrait (for visualisation)
    subplot(2, 3, 6);
    plot(yExact(1:end-1), diff(yExact) ./ diff(tExact), 'k-', ...
        'LineWidth', 2, 'DisplayName', 'Exact');
    hold on;
    plot(yEuler(1:end-1), diff(yEuler) ./ diff(tEuler), 'b-', ...
        'LineWidth', 1.5, 'DisplayName', 'Euler');
    plot(yODE45(1:end-1), diff(yODE45) ./ diff(tODE45), 'r:', ...
        'LineWidth', 2, 'DisplayName', 'ODE45');
    
    xlabel('$y$', 'Interpreter', 'latex');
    ylabel('$dy/dt$', 'Interpreter', 'latex');
    title('Phase Portrait', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
end
