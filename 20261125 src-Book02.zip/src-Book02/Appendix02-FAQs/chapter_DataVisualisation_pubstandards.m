%% chapter_DataVisualisation_pubstandards.m
% Publication Quality Setup
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_pubstandards
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Publication-quality figure setup
fig = figure('Position', [100 100 800 600]);
set(fig, 'PaperUnits', 'centimeters');
set(fig, 'PaperSize', [21 29.7]); % A4 size
set(fig, 'PaperPosition', [0 0 21 29.7]);
set(0, 'DefaultAxesFontSize', 10);
set(0, 'DefaultAxesFontName', 'Times New Roman');
