%% Appendix01-Solutions_code_216.m
% Multi-Task Learning for EM Fields (Key Components)
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt

# ============================================================================
# FDTD Simulation (Training Data Generation)
# ============================================================================
def fdtd_2d_simulation(grid_size=100, time_steps=50, dipole_freq_ghz=5.0):
    """Finite-Difference Time-Domain EM simulation"""
    # Grid parameters
    dx, dy = 1e-3, 1e-3  # 1 mm resolution
    dt = dx / (2 * 3e8)  # Courant stability
    
    # Initialize fields
    Ez = np.zeros((grid_size, grid_size, time_steps))
    Hx = np.zeros((grid_size, grid_size, time_steps))
    Hy = np.zeros((grid_size, grid_size, time_steps))
    
    # Dipole source (center)
    src_x, src_y = grid_size // 2, grid_size // 2
    omega = 2 * np.pi * dipole_freq_ghz * 1e9
    
    # FDTD update equations
    for t in range(1, time_steps):
        # Update magnetic field
        Hx[:, :, t] = Hx[:, :, t-1] - (dt/dy) * np.diff(Ez[:, :, t-1], axis=1, append=0)
        Hy[:, :, t] = Hy[:, :, t-1] + (dt/dx) * np.diff(Ez[:, :, t-1], axis=0, append=0)
        
        # Update electric field
        Ez[:, :, t] = Ez[:, :, t-1] + (dt/dx) * (np.diff(Hy[:, :, t], axis=0, prepend=0) - 
                                                  np.diff(Hx[:, :, t], axis=1, prepend=0))
        
        # Add source
        Ez[src_x, src_y, t] += np.sin(omega * t * dt)
    
    return Ez, Hx, Hy

# ============================================================================
# Multi-Task Network Architecture
# ============================================================================
class MTL_EM_Network(nn.Module):
    """Multi-Task Learning for E and B field prediction"""
    
    def __init__(self):
        super(MTL_EM_Network, self).__init__()
        
        # Shared convolutional backbone
        self.shared_conv = nn.Sequential(
            nn.Conv2d(1, 32, kernel_size=5, padding=2),
            nn.ReLU(),
            nn.BatchNorm2d(32),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.BatchNorm2d(64),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.BatchNorm2d(128)
        )
        
        # Task-specific heads
        self.e_head = nn.Sequential(
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 1, kernel_size=1)  # Output: Ez field
        )
        
        self.b_head = nn.Sequential(
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 2, kernel_size=1)  # Output: Hx, Hy fields
        )
    
    def forward(self, x):
        shared_features = self.shared_conv(x)
        e_field = self.e_head(shared_features)
        b_field = self.b_head(shared_features)
        return e_field, b_field

# Training loop and evaluation would follow...
# (Full implementation ~1500 lines)
