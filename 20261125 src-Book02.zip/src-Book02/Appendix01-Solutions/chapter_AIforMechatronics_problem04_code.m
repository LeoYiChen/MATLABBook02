%% chapter_AIforMechatronics_problem04_code.m
% Real-time inference optimisation for edge deployment.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem04_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 4: Real-Time Inference Optimisation for Edge Deployment
% Author: Dr Yi Chen
% Purpose: Implement model optimisation techniques for edge deployment
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox, Computer Vision Toolbox
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Generate synthetic object detection dataset
fprintf('=== Real-Time Inference Optimisation ===\n\n');
fprintf('Step 1: Generating synthetic object detection dataset...\n');

% Dataset parameters
imageSize = [128, 128, 3];
numClasses = 3; % Background, Object1, Object2
classNames = {'Background', 'Circle', 'Rectangle'};
numImages = 500;
maxObjectsPerImage = 3;

% Generate synthetic images with bounding boxes
allImages = zeros([imageSize, numImages], 'uint8');
allBoundingBoxes = cell(numImages, 1);
allLabels = cell(numImages, 1);

for imgIdx = 1:numImages
    % Create blank image
    currentImage = uint8(255 * ones(imageSize(1), imageSize(2), imageSize(3)));
    
    % Add random background texture
    backgroundNoise = uint8(20 * randn(imageSize(1), imageSize(2)));
    currentImage(:, :, 1) = currentImage(:, :, 1) + backgroundNoise;
    currentImage(:, :, 2) = currentImage(:, :, 2) + backgroundNoise;
    currentImage(:, :, 3) = currentImage(:, :, 3) + backgroundNoise;
    
    % Generate random objects
    numObjects = randi([1, maxObjectsPerImage]);
    bboxes = zeros(numObjects, 4);
    labels = cell(numObjects, 1);
    
    for objIdx = 1:numObjects
        % Random object type
        objectType = randi([1, 2]); % 1: Circle, 2: Rectangle
        
        % Random position and size
        objectSize = randi([15, 35]);
        xCentre = randi([objectSize, imageSize(2) - objectSize]);
        yCentre = randi([objectSize, imageSize(1) - objectSize]);
        
        % Random colour
        objectColour = uint8([randi([0, 255]), randi([0, 255]), randi([0, 255])]);
        
        if objectType == 1 % Circle
            currentImage = insertShape(currentImage, 'FilledCircle', ...
                [xCentre, yCentre, objectSize/2], ...
                'Color', double(objectColour), 'Opacity', 1);
            labels{objIdx} = 'Circle';
        else % Rectangle
            width = objectSize + randi([-5, 5]);
            height = objectSize + randi([-5, 5]);
            currentImage = insertShape(currentImage, 'FilledRectangle', ...
                [xCentre - width/2, yCentre - height/2, width, height], ...
                'Color', double(objectColour), 'Opacity', 1);
            labels{objIdx} = 'Rectangle';
        end
        
        % Store bounding box (xmin, ymin, width, height)
        bboxes(objIdx, :) = [xCentre - objectSize/2, ...
            yCentre - objectSize/2, objectSize, objectSize];
    end
    
    % Store image and annotations
    allImages(:, :, :, imgIdx) = currentImage;
    allBoundingBoxes{imgIdx} = bboxes;
    allLabels{imgIdx} = categorical(labels);
end

fprintf('  Generated %d synthetic images\n', numImages);
fprintf('  Image size: %dx%dx%d\n', imageSize);
fprintf('  Object classes: %d\n', numClasses - 1);

%% Step 2: Split dataset
fprintf('\nStep 2: Splitting dataset...\n');

trainRatio = 0.70;
valRatio = 0.15;
testRatio = 0.15;

[trainIdx, valIdx, testIdx] = dividerand(numImages, ...
    trainRatio, valRatio, testRatio);

trainImages = allImages(:, :, :, trainIdx);
trainBoxes = allBoundingBoxes(trainIdx);
trainImageLabels = allLabels(trainIdx);

valImages = allImages(:, :, :, valIdx);
valBoxes = allBoundingBoxes(valIdx);
valImageLabels = allLabels(valIdx);

testImages = allImages(:, :, :, testIdx);
testBoxes = allBoundingBoxes(testIdx);
testImageLabels = allLabels(testIdx);

fprintf('  Training images: %d\n', length(trainIdx));
fprintf('  Validation images: %d\n', length(valIdx));
fprintf('  Test images: %d\n', length(testIdx));

%% Step 3: Define baseline detection network
fprintf('\nStep 3: Defining baseline detection network...\n');

% Simplified object detection architecture (classification-based)
% For simplicity, we'll create a classification network
% In practice, would use YOLO/SSD architecture

layersBaseline = [
    imageInputLayer(imageSize, 'Name', 'input', 'Normalization', 'none')
    
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
    
    convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv4')
    batchNormalizationLayer('Name', 'bn4')
    reluLayer('Name', 'relu4')
    globalAveragePooling2dLayer('Name', 'gap')
    
    fullyConnectedLayer(128, 'Name', 'fc1')
    reluLayer('Name', 'relu_fc1')
    dropoutLayer(0.5, 'Name', 'dropout')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc2')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

fprintf('  Baseline network architecture defined\n');
fprintf('  Convolutional layers: 4\n');
fprintf('  Fully connected layers: 2\n');

%% Step 4: Train baseline model
fprintf('\nStep 4: Training baseline model...\n');

% Convert bounding boxes to image labels (simplified)
trainLabelsSimple = categorical(zeros(length(trainIdx), 1));
for imgIdx = 1:length(trainIdx)
    if ~isempty(trainImageLabels{imgIdx})
        trainLabelsSimple(imgIdx) = trainImageLabels{imgIdx}(1);
    else
        trainLabelsSimple(imgIdx) = categorical({'Background'});
    end
end

valLabelsSimple = categorical(zeros(length(valIdx), 1));
for imgIdx = 1:length(valIdx)
    if ~isempty(valImageLabels{imgIdx})
        valLabelsSimple(imgIdx) = valImageLabels{imgIdx}(1);
    else
        valLabelsSimple(imgIdx) = categorical({'Background'});
    end
end

% Training options
trainingOptionsBaseline = trainingOptions('adam', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 20, ...
    'MiniBatchSize', 16, ...
    'ValidationData', {valImages, valLabelsSimple}, ...
    'ValidationFrequency', 20, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
networkBaseline = trainNetwork(trainImages, trainLabelsSimple, ...
    layersBaseline, trainingOptionsBaseline);
trainingTimeBaseline = toc;

fprintf('  Baseline training completed in %.2f seconds\n', trainingTimeBaseline);

%% Step 5: Measure baseline performance
fprintf('\nStep 5: Measuring baseline inference performance...\n');

% Test accuracy
testLabelsSimple = categorical(zeros(length(testIdx), 1));
for imgIdx = 1:length(testIdx)
    if ~isempty(testImageLabels{imgIdx})
        testLabelsSimple(imgIdx) = testImageLabels{imgIdx}(1);
    else
        testLabelsSimple(imgIdx) = categorical({'Background'});
    end
end

predictedLabelsBaseline = classify(networkBaseline, testImages);
accuracyBaseline = sum(predictedLabelsBaseline == testLabelsSimple) / ...
    numel(testLabelsSimple);

% Inference timing (average over multiple runs)
numTimingRuns = 50;
inferenceTimesBaseline = zeros(numTimingRuns, 1);

for runIdx = 1:numTimingRuns
    sampleImage = testImages(:, :, :, randi(length(testIdx)));
    tic;
    classify(networkBaseline, sampleImage);
    inferenceTimesBaseline(runIdx) = toc * 1000; % Convert to milliseconds
end

avgInferenceTimeBaseline = mean(inferenceTimesBaseline);
stdInferenceTimeBaseline = std(inferenceTimesBaseline);

fprintf('  Baseline test accuracy: %.2f%%\n', accuracyBaseline * 100);
fprintf('  Average inference time: %.2f   %.2f ms\n', ...
    avgInferenceTimeBaseline, stdInferenceTimeBaseline);

%% Step 6: Implement weight pruning
fprintf('\nStep 6: Implementing weight pruning...\n');

% Extract network layers
layerGraphPruned = layerGraph(networkBaseline);
layers = layerGraphPruned.Layers;

% Pruning parameters
pruningThreshold = 0.01; % Prune weights with magnitude < threshold
pruningPercentage = 0.0;

% Count pruneable parameters
totalWeights = 0;
prunedWeights = 0;

for layerIdx = 1:length(layers)
    if isa(layers(layerIdx), 'nnet.cnn.layer.Convolution2DLayer') || ...
       isa(layers(layerIdx), 'nnet.cnn.layer.FullyConnectedLayer')
        
        % Get current weights
        currentWeights = layers(layerIdx).Weights;
        totalWeights = totalWeights + numel(currentWeights);
        
        % Apply magnitude-based pruning
        pruneMask = abs(currentWeights) < pruningThreshold;
        currentWeights(pruneMask) = 0;
        prunedWeights = prunedWeights + sum(pruneMask(:));
        
        % Update layer weights
        layers(layerIdx).Weights = currentWeights;
    end
end

pruningPercentage = (prunedWeights / totalWeights) * 100;

fprintf('  Total weights: %d\n', totalWeights);
fprintf('  Pruned weights: %d (%.2f%%)\n', prunedWeights, pruningPercentage);

% Reconstruct network with pruned weights
networkPruned = assembleNetwork(layerGraphPruned);

% Fine-tune pruned network
fprintf('  Fine-tuning pruned network...\n');

trainingOptionsPruned = trainingOptions('adam', ...
    'InitialLearnRate', 0.0001, ... % Lower learning rate for fine-tuning
    'MaxEpochs', 10, ...
    'MiniBatchSize', 16, ...
    'Verbose', false, ...
    'Plots', 'none');

networkPruned = trainNetwork(trainImages, trainLabelsSimple, ...
    layers, trainingOptionsPruned);

%% Step 7: Evaluate pruned model
fprintf('\nStep 7: Evaluating pruned model...\n');

predictedLabelsPruned = classify(networkPruned, testImages);
accuracyPruned = sum(predictedLabelsPruned == testLabelsSimple) / ...
    numel(testLabelsSimple);

% Inference timing for pruned model
inferenceTimesPruned = zeros(numTimingRuns, 1);

for runIdx = 1:numTimingRuns
    sampleImage = testImages(:, :, :, randi(length(testIdx)));
    tic;
    classify(networkPruned, sampleImage);
    inferenceTimesPruned(runIdx) = toc * 1000;
end

avgInferenceTimePruned = mean(inferenceTimesPruned);
stdInferenceTimePruned = std(inferenceTimesPruned);

fprintf('  Pruned model test accuracy: %.2f%%\n', accuracyPruned * 100);
fprintf('  Average inference time: %.2f   %.2f ms\n', ...
    avgInferenceTimePruned, stdInferenceTimePruned);
fprintf('  Accuracy change: %.2f%%\n', ...
    (accuracyPruned - accuracyBaseline) * 100);

%% Step 8: Implement knowledge distillation (simplified student network)
fprintf('\nStep 8: Implementing knowledge distillation...\n');

% Define compact student network
layersStudent = [
    imageInputLayer(imageSize, 'Name', 'input', 'Normalization', 'none')
    
    convolution2dLayer(3, 16, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    globalAveragePooling2dLayer('Name', 'gap')
    
    fullyConnectedLayer(64, 'Name', 'fc1')
    reluLayer('Name', 'relu_fc1')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc2')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

fprintf('  Student network defined (reduced capacity)\n');
fprintf('  Convolutional layers: 2 (vs 4 in teacher)\n');

% Train student network with standard training
fprintf('  Training student network...\n');

trainingOptionsStudent = trainingOptions('adam', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 20, ...
    'MiniBatchSize', 16, ...
    'Verbose', false, ...
    'Plots', 'none');

networkStudent = trainNetwork(trainImages, trainLabelsSimple, ...
    layersStudent, trainingOptionsStudent);

%% Step 9: Evaluate student model
fprintf('\nStep 9: Evaluating student model...\n');

predictedLabelsStudent = classify(networkStudent, testImages);
accuracyStudent = sum(predictedLabelsStudent == testLabelsSimple) / ...
    numel(testLabelsSimple);

% Inference timing for student model
inferenceTimesStudent = zeros(numTimingRuns, 1);

for runIdx = 1:numTimingRuns
    sampleImage = testImages(:, :, :, randi(length(testIdx)));
    tic;
    classify(networkStudent, sampleImage);
    inferenceTimesStudent(runIdx) = toc * 1000;
end

avgInferenceTimeStudent = mean(inferenceTimesStudent);
stdInferenceTimeStudent = std(inferenceTimesStudent);

fprintf('  Student model test accuracy: %.2f%%\n', accuracyStudent * 100);
fprintf('  Average inference time: %.2f   %.2f ms\n', ...
    avgInferenceTimeStudent, stdInferenceTimeStudent);
fprintf('  Accuracy change vs baseline: %.2f%%\n', ...
    (accuracyStudent - accuracyBaseline) * 100);

%% Step 10: Performance comparison and visualisation
fprintf('\nStep 10: Generating performance comparison...\n');

% Create comparison table
modelNames = {'Baseline', 'Pruned', 'Student'};
accuracies = [accuracyBaseline; accuracyPruned; accuracyStudent] * 100;
inferenceTimes = [avgInferenceTimeBaseline; avgInferenceTimePruned; ...
    avgInferenceTimeStudent];
speedups = avgInferenceTimeBaseline ./ inferenceTimes;

% Estimate model sizes (simplified)
baselineParams = 0;
for layerIdx = 1:length(networkBaseline.Layers)
    layer = networkBaseline.Layers(layerIdx);
    if isprop(layer, 'Weights')
        baselineParams = baselineParams + numel(layer.Weights);
    end
end

prunedActiveParams = totalWeights - prunedWeights;
studentParams = baselineParams * 0.35; % Approximate

modelSizes = [baselineParams; prunedActiveParams; studentParams];
compressionRatios = baselineParams ./ modelSizes;

% Display results table
fprintf('\n=== Model Comparison Summary ===\n');
fprintf('%-12s | Accuracy | Inference | Speedup | Parameters | Compression\n', 'Model');
fprintf('-------+-----+------+-----+------+------\n');
for modelIdx = 1:length(modelNames)
    fprintf('%-12s | %6.2f%% | %6.2f ms | %5.2fx  | %10d | %8.2fx\n', ...
        modelNames{modelIdx}, accuracies(modelIdx), ...
        inferenceTimes(modelIdx), speedups(modelIdx), ...
        round(modelSizes(modelIdx)), compressionRatios(modelIdx));
end

% Visualisation
figure('Name', 'Model Optimisation Comparison', ...
    'Position', [100, 100, 1200, 800]);

% Accuracy vs Inference Time
subplot(2, 2, 1);
scatter(inferenceTimes, accuracies, 200, [1:3], 'filled');
for modelIdx = 1:length(modelNames)
    text(inferenceTimes(modelIdx) + 0.1, accuracies(modelIdx), ...
        modelNames{modelIdx}, 'Interpreter', 'latex', 'FontSize', 10);
end
xlabel('Inference Time (ms)', 'Interpreter', 'latex');
ylabel('Accuracy (\%)', 'Interpreter', 'latex');
title('Accuracy vs Inference Time Trade-off', 'Interpreter', 'latex');
grid on;

% Model Size Comparison
subplot(2, 2, 2);
bar(modelSizes / 1e6);
set(gca, 'XTickLabel', modelNames);
ylabel('Parameters (Millions)', 'Interpreter', 'latex');
title('Model Complexity Comparison', 'Interpreter', 'latex');
grid on;

% Speedup Analysis
subplot(2, 2, 3);
bar(speedups);
set(gca, 'XTickLabel', modelNames);
ylabel('Speedup Factor', 'Interpreter', 'latex');
title('Inference Speedup vs Baseline', 'Interpreter', 'latex');
grid on;

% Accuracy Change
subplot(2, 2, 4);
accuracyChanges = accuracies - accuracies(1);
bar(accuracyChanges);
set(gca, 'XTickLabel', modelNames);
ylabel('Accuracy Change (\%)', 'Interpreter', 'latex');
title('Accuracy Relative to Baseline', 'Interpreter', 'latex');
grid on;

suptitle('Edge Deployment Optimisation Results', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 4 completed successfully.\n');
