%% chapter_DataVisualisation_stats.m
% Statistical Integration
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_stats
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function statVisualAnalysis(data1, data2)
% Perform statistical test
[h,p] = ttest2(data1, data2);

% Create visualization
figure('Position', [100 100 800 600]);

% Box plot with overlay
subplot(2,1,1);
boxplot([data1, data2], 'Labels', {'Group 1', 'Group 2'});
hold on;

% Add individual points
x1 = ones(size(data1)) + ...
     (rand(size(data1))-0.5)*0.1;
x2 = 2*ones(size(data2)) + ...
     (rand(size(data2))-0.5)*0.1;
plot(x1, data1, 'k.', x2, data2, 'k.');

% Add p-value annotation
sigstar([1,2], p);

% Density plot
subplot(2,1,2);
[f1,xi1] = ksdensity(data1);
[f2,xi2] = ksdensity(data2);
plot(xi1,f1,'b-', xi2,f2,'r-', 'LineWidth',2);
legend('Group 1', 'Group 2');

% Apply research standards
customiseResearchPlot(gcf);

end

function sigstar(groups, p)
% Add significance stars
y = max([data1;data2]) * 1.1;
plot(groups, [y y], 'k-');
if p < 0.001
text(mean(groups), y, '', ...
'HorizontalAlignment', 'center');
elseif p < 0.01
text(mean(groups), y, '', ...
'HorizontalAlignment', 'center');
elseif p < 0.05
text(mean(groups), y, '', ...
'HorizontalAlignment', 'center');
end
end
