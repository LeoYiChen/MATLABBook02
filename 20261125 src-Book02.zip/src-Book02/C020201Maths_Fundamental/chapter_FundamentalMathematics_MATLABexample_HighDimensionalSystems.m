%% chapter_FundamentalMathematics_MATLABexample_HighDimensionalSystems.m
% High-dimensional linear system solution and performance analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_HighDimensionalSystems
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_2_2_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates performance scaling and solution methods
%              for high-dimensional linear systems.

function demonstrateHighDimensionalSystemsPerformance()
    % Define system dimensions for performance analysis
    systemDimensions = [100, 500, 1000, 2000];
    numMethods = 3;
    solutionTimes = zeros(length(systemDimensions), numMethods);
    
    fprintf('High-Dimensional Linear System Performance Analysis\n');
    fprintf('%-12*s %-18*s %-18*s %-18*s\n', 'Dimension', ...
            'Direct (\)', 'LU Decomp', 'Iterative (GMRES)');
    fprintf('%s\n', repmat('-', 1, 75));
    
    for dimIdx = 1:length(systemDimensions)
        currentDim = systemDimensions(dimIdx);
        
        % Generate well-conditioned symmetric positive definite test system
        [testMatrix, rightHandSide, trueSolution] = ...
            generateWellConditionedSystem(currentDim);
        
        % Method 1: Direct solution using backslash operator
        % MATLAB intelligently selects optimal algorithm
        tic;
        solutionDirect = testMatrix \ rightHandSide;
        solutionTimes(dimIdx, 1) = toc;
        
        % Verify solution accuracy
        residualDirect = norm(testMatrix * solutionDirect - rightHandSide);
        relativeErrorDirect = norm(solutionDirect - trueSolution) / ...
                              norm(trueSolution);
        
        % Method 2: Explicit LU decomposition
        tic;
        [L, U, P] = lu(testMatrix);
        y = L \ (P * rightHandSide);
        solutionLU = U \ y;
        solutionTimes(dimIdx, 2) = toc;
        
        % Verify LU solution
        residualLU = norm(testMatrix * solutionLU - rightHandSide);
        
        % Method 3: Iterative method (GMRES)
        % Generalised Minimal Residual method for general systems
        tolerance = 1e-8;
        maxIterations = min(currentDim, 200);
        
        tic;
        [solutionGMRES, flag, relres, iter] = gmres(testMatrix, ...
            rightHandSide, [], tolerance, maxIterations);
        solutionTimes(dimIdx, 3) = toc;
        
        % Display results for current dimension
        fprintf('%-12*d %-18.6*f %-18.6*f %-18.6*f\n', currentDim, ...
                solutionTimes(dimIdx, 1), ...
                solutionTimes(dimIdx, 2), ...
                solutionTimes(dimIdx, 3));
        
        % Condition number analysis
        conditionNumber = cond(testMatrix);
        
        % Warning for ill-conditioned systems
        if conditionNumber > 1e10
            warning('System dimension %d is ill-conditioned (cond = %.2e)', ...
                    currentDim, conditionNumber);
        end
        
        % Verify iterative method convergence
        if flag ~= 0
            warning('GMRES did not converge for dimension %d (flag = %d)', ...
                    currentDim, flag);
        end
    end
    
    % Visualise performance scaling
    createPerformanceComparisonPlot(systemDimensions, solutionTimes);
    
    % Analyse algorithmic complexity
    analyseComplexityScaling(systemDimensions, solutionTimes);
end

function [coeffMatrix, rhsVector, trueSolution] = ...
    generateWellConditionedSystem(systemSize)
    % Generate symmetric positive definite system with known solution
    % This ensures numerical stability and enables solution verification
    
    % Create random matrix and form SPD matrix via A'*A
    randomMatrix = randn(systemSize, systemSize);
    coeffMatrix = randomMatrix' * randomMatrix + ...
                  10 * eye(systemSize); % Add diagonal dominance
    
    % Generate known solution vector
    trueSolution = randn(systemSize, 1);
    
    % Compute corresponding right-hand side
    rhsVector = coeffMatrix * trueSolution;
end

function createPerformanceComparisonPlot(dimensions, timingData)
    % Visualise computational performance scaling across methods
    
    figure('Position', [100, 100, 800, 600]);
    
    % Plot on log-log scale to reveal algorithmic complexity
    loglog(dimensions, timingData(:, 1), 'bo-', 'LineWidth', 2, ...
           'MarkerSize', 8, 'DisplayName', 'Direct Method (\)');
    hold on;
    loglog(dimensions, timingData(:, 2), 'rs-', 'LineWidth', 2, ...
           'MarkerSize', 8, 'DisplayName', 'LU Decomposition');
    loglog(dimensions, timingData(:, 3), 'g^-', 'LineWidth', 2, ...
           'MarkerSize', 8, 'DisplayName', 'Iterative (GMRES)');
    
    % Add theoretical O(n^3) reference line
    theoreticalScaling = (dimensions / dimensions(1)).^3 * timingData(1, 1);
    loglog(dimensions, theoreticalScaling, 'k--', 'LineWidth', 1.5, ...
           'DisplayName', '$O(n^3)$ Reference');
    
    xlabel('System Dimension $n$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Computation Time (seconds)', 'Interpreter', 'latex', ...
           'FontSize', 12);
    title('Linear System Solution: Performance Scaling Analysis', ...
          'Interpreter', 'latex', 'FontSize', 14);
    legend('Location', 'northwest', 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'FontSize', 11);
    
    hold off;
end

function analyseComplexityScaling(dimensions, timingData)
    % Analyse empirical complexity scaling
    
    fprintf('\nEmpirical Complexity Analysis:\n');
    fprintf('%-12*s %-20*s %-20*s\n', 'Method', 'Avg Scaling Factor', ...
            'Est. Complexity');
    fprintf('%s\n', repmat('-', 1, 60));
    
    methodNames = {'Direct (\)', 'LU Decomp', 'GMRES'};
    
    for methodIdx = 1:size(timingData, 2)
        % Compute scaling factors between consecutive dimension pairs
        scalingFactors = timingData(2:end, methodIdx) ./ ...
                        timingData(1:end-1, methodIdx);
        dimensionRatios = dimensions(2:end) ./ dimensions(1:end-1);
        
        % Estimate complexity exponent
        % If time ~ n^p, then time_ratio ~ (dim_ratio)^p
        % Therefore: p ≈ log(time_ratio) / log(dim_ratio)
        complexityExponents = log(scalingFactors) ./ log(dimensionRatios');
        avgExponent = mean(complexityExponents);
        
        avgScalingFactor = mean(scalingFactors);
        
        fprintf('%-12*s %-20.3*f %-20.2*f\n', methodNames{methodIdx}, ...
                avgScalingFactor, avgExponent);
    end
end
