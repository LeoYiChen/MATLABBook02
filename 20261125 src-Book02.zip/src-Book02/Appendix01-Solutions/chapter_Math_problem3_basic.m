%% chapter_Math_problem3_basic.m
% Basic matrix operations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem3_basic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define matrix
A = [2, 1, -1; -3, -1, 2; -2, 1, 2];

% Determinant
det_A = det(A);

% Inverse (if exists)
if det_A ~= 0
    A_inv = inv(A);
    % Verify: A * A_inv should equal identity
    verification = A * A_inv;
end

% Eigenvalues and eigenvectors
[V, D] = eig(A);  % V contains eigenvectors, D contains eigenvalues
lambda = diag(D); % Extract eigenvalues

% Condition number
kappa = cond(A);
