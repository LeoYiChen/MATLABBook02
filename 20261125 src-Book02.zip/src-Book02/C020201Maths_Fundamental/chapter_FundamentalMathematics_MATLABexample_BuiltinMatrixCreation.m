%% chapter_FundamentalMathematics_MATLABexample_BuiltinMatrixCreation.m
% Creating matrices using built-in MATLAB functions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_BuiltinMatrixCreation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_1_1_Example02.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates matrix creation using MATLAB's built-in
%              constructor functions with practical applications.

% Pre-allocate a large matrix for computational efficiency
% This practice, advocated by numerical analysts since the 1960*s,
% prevents costly memory reallocation during iterative computations
matrixDimension = 500;
preallocatedMatrix = zeros(matrixDimension, matrixDimension);
disp(['Pre-allocated matrix of size: ', num2str(size(preallocatedMatrix))]);

% Create identity matrix for transformation initialisation
identityMatrix3x3 = eye(3);
disp('3*x3 Identity Matrix:');
disp(identityMatrix3x3);

% Generate random matrix for Monte Carlo simulation
% Using Mersenne Twister algorithm (default in MATLAB)
numSimulations = 1000;
numVariables = 4;
monteCarloSamples = rand(numSimulations, numVariables);
disp(['Monte Carlo samples generated: ', num2str(size(monteCarloSamples))]);
disp('Sample statistics (first variable):');
disp(['  Mean: ', num2str(mean(monteCarloSamples(:,1)))]);
disp(['  Std Dev: ', num2str(std(monteCarloSamples(:,1)))]);

% Generate normally distributed random matrix for noise simulation
% Simulating measurement noise with zero mean and unit variance
numMeasurements = 100;
measurementNoise = randn(numMeasurements, 1);
disp('Measurement noise statistics:');
disp(['  Mean: ', num2str(mean(measurementNoise))]);
disp(['  Variance: ', num2str(var(measurementNoise))]);

% Create tridiagonal matrix using diag() function
% Common in finite difference discretisations of differential equations
gridSize = 10;
mainDiagonal = 2 * ones(gridSize, 1);
offDiagonal = -ones(gridSize - 1, 1);
tridiagonalMatrix = diag(mainDiagonal) + ...
                    diag(offDiagonal, 1) + ...
                    diag(offDiagonal, -1);
disp('Tridiagonal Matrix (first 5*x5 portion):');
disp(tridiagonalMatrix(1:5, 1:5));

% Create linearly spaced vector for plotting
% Generate 100 points between 0 and 2π for smooth curve plotting
numPlotPoints = 100;
xValues = linspace(0, 2*pi, numPlotPoints);
disp(['Linearly spaced vector created with ', num2str(length(xValues)), ' points']);
disp(['  First value: ', num2str(xValues(1))]);
disp(['  Last value: ', num2str(xValues(end))]);
disp(['  Spacing: ', num2str(xValues(2) - xValues(1))]);

% Create logarithmically spaced vector for frequency analysis
% Common in Bode plots and frequency response analysis
numFreqPoints = 50;
frequencyVector = logspace(0, 3, numFreqPoints); % 10^0 to 10^3 Hz
disp(['Logarithmically spaced frequencies: ', ...
      num2str(numFreqPoints), ' points']);
disp(['  First frequency: ', num2str(frequencyVector(1)), ' Hz']);
disp(['  Last frequency: ', num2str(frequencyVector(end)), ' Hz']);
