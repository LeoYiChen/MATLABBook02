%% lst_C01_Lab05.m
% AI-assisted surrogate modelling of a 2D heat-transfer field in MATLAB
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : lst:C01_Lab05
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab05.m
% Scientific computing + lightweight AI surrogate + visualisation

n = 81;  x = linspace(0,1,n);  y = linspace(0,1,n);
[X,Y] = meshgrid(x, y);
Tref = 22 + 58*exp(-2.15*X).*exp(-((Y-0.20)/0.42).^2) ...
     +  6*exp(-3.4*X).*exp(-((Y-0.18)/0.22).^2);

rng(11);
ns = 95;
idx = randperm(numel(X), ns);
xy = [X(idx).' Y(idx).'];  t = Tref(idx).';

sigma = 0.16;  lam = 4e-3;
D2 = sum(xy.^2,2) + sum(xy.^2,2)' - 2*(xy*xy');
K = exp(-D2/(2*sigma^2));
alpha = (K + lam*eye(ns)) \ t(:);
xyq = [X(:) Y(:)];
D2q = sum(xyq.^2,2) + sum(xy.^2,2)' - 2*(xyq*xy');
Tai = reshape(exp(-D2q/(2*sigma^2))*alpha, size(X));
E = abs(Tref - Tai);
rmse = sqrt(mean((Tref(:)-Tai(:)).^2));

figure('Color','w');
tiledlayout(1,3,'TileSpacing','compact','Padding','compact');
nexttile; contourf(X,Y,Tref,22,'LineStyle','none'); axis equal tight
title('Reference Temperature Field'); xlabel('x'); ylabel('y'); colorbar
nexttile; contourf(X,Y,Tai,22,'LineStyle','none'); axis equal tight
title('AI-Predicted Temperature Field'); xlabel('x'); ylabel('y'); colorbar
nexttile; contourf(X,Y,E,16,'LineStyle','none'); axis equal tight
title('Absolute Prediction Error'); xlabel('x'); ylabel('y'); colorbar
sprintf('RMSE = %.1f degC', rmse)
