%% chapter_FundamentalMaths_example_Convolution.m
% Convolution-based filtering with time and frequency domain methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_Convolution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section6_example4.m
% Author: Dr Leo Chen
% Date: June 4, 2025
% MATLAB Version: R2025a
% Description: Demonstration of convolution-based digital filtering using
% both time-domain and frequency-domain approaches for noise reduction

fprintf('=== Convolution and Digital Filtering ===\n\n');

%% Signal Generation: Step Function with Noise
% Create idealised step function corrupted by measurement noise

numSamples = 500;
stepSignal = [zeros(1, 200), ones(1, 300)];
noisySignal = stepSignal + 0.2 * randn(1, numSamples);

fprintf('Signal parameters:\n');
fprintf('  Signal length: %d samples\n', numSamples);
fprintf('  Noise standard deviation: 0.2\n');

%% Moving Average Filter Design
% Simple FIR filter for noise smoothing

windowSize = 10;
movingAverageFilter = ones(1, windowSize) / windowSize;

fprintf('\nFilter parameters:\n');
fprintf('  Filter type: Moving average (FIR)\n');
fprintf('  Window size: %d samples\n', windowSize);

%% Time-Domain Filtering (Direct Convolution)
tic;
filteredSignalTime = conv(noisySignal, movingAverageFilter, 'same');
timeConvolution = toc;

fprintf('  Time-domain convolution: %.4f seconds\n', timeConvolution);

%% Frequency-Domain Filtering (FFT-Based)
% Demonstrate computational efficiency of frequency-domain approach

tic;
% Zero-pad for circular convolution to match linear convolution
fftLength = length(noisySignal) + length(movingAverageFilter) - 1;
signalFFT = fft(noisySignal, fftLength);
filterFFT = fft(movingAverageFilter, fftLength);

% Multiplication in frequency domain
outputFFT = signalFFT .* filterFFT;

% Inverse FFT and extract relevant portion
filteredSignalFreq = real(ifft(outputFFT));
filteredSignalFreq = filteredSignalFreq(1:numSamples);
timeFFT = toc;

fprintf('  Frequency-domain filtering: %.4f seconds\n', timeFFT);
fprintf('  Speedup factor: %.2fx\n', timeConvolution / timeFFT);

%% Visualisation: Time Domain
figure('Position', [100, 100, 1400, 800]);

% Original step function
subplot(3, 1, 1);
plot(stepSignal, 'b-', 'LineWidth', 1.5);
title('Ideal Step Function (Reference)', 'Interpreter', 'latex', ...
    'FontSize', 12);
ylabel('Amplitude', 'Interpreter', 'latex');
ylim([-0.5, 1.5]);
grid on;

% Noisy measurement
subplot(3, 1, 2);
plot(noisySignal, 'r:', 'LineWidth', 1, 'DisplayName', 'Noisy Signal');
hold on;
plot(stepSignal, 'b--', 'LineWidth', 1.5, 'DisplayName', 'Original');
title('Noisy Measurement Signal', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Amplitude', 'Interpreter', 'latex');
legend('show', 'Interpreter', 'latex', 'Location', 'northwest');
ylim([-0.5, 1.5]);
grid on;
hold off;

% Filtered results
subplot(3, 1, 3);
plot(filteredSignalTime, 'g-', 'LineWidth', 2, ...
    'DisplayName', 'Filtered (Time Domain)');
hold on;
plot(filteredSignalFreq, 'm--', 'LineWidth', 1.5, ...
    'DisplayName', 'Filtered (Frequency Domain)');
plot(stepSignal, 'b:', 'LineWidth', 1.5, 'DisplayName', 'Original');
title('Convolution-Based Noise Reduction', 'Interpreter', 'latex', ...
    'FontSize', 12);
xlabel('Sample Index', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
legend('show', 'Interpreter', 'latex', 'Location', 'northwest');
ylim([-0.5, 1.5]);
grid on;
hold off;

saveas(gcf, 'convolution_filtering_time.png');

%% Frequency Domain Analysis
% Examine filtering effect in frequency domain

% Compute spectra
fftNoisy = fft(noisySignal);
fftFiltered = fft(filteredSignalTime);
frequencyVector = (0:numSamples-1) / numSamples;

figure('Position', [100, 100, 1400, 500]);

% Noisy signal spectrum
subplot(1, 2, 1);
plot(frequencyVector, abs(fftNoisy), 'r-', 'LineWidth', 1.5);
xlabel('Normalised Frequency', 'Interpreter', 'latex');
ylabel('Magnitude', 'Interpreter', 'latex');
title('Frequency Spectrum (Noisy Signal)', 'Interpreter', 'latex', ...
    'FontSize', 12);
grid on;
xlim([0, 0.5]);

% Filtered signal spectrum
subplot(1, 2, 2);
plot(frequencyVector, abs(fftNoisy), 'r-', 'LineWidth', 1, ...
    'DisplayName', 'Noisy');
hold on;
plot(frequencyVector, abs(fftFiltered), 'g-', 'LineWidth', 2, ...
    'DisplayName', 'Filtered');
xlabel('Normalised Frequency', 'Interpreter', 'latex');
ylabel('Magnitude', 'Interpreter', 'latex');
title('Frequency Domain: Filtering Effect', 'Interpreter', 'latex', ...
    'FontSize', 12);
legend('show', 'Interpreter', 'latex', 'Location', 'northeast');
grid on;
xlim([0, 0.5]);
hold off;

saveas(gcf, 'convolution_filtering_frequency.png');

%% Performance Metrics
% Quantitative assessment of filtering performance

mseNoisy = mean((stepSignal - noisySignal).^2);
mseFiltered = mean((stepSignal - filteredSignalTime).^2);
improvement = 100 * (mseNoisy - mseFiltered) / mseNoisy;

fprintf('\n=== Filtering Performance Metrics ===\n');
fprintf('MSE (noisy signal):    %.6f\n', mseNoisy);
fprintf('MSE (filtered signal): %.6f\n', mseFiltered);
fprintf('MSE reduction:         %.2f%%\n', improvement);

% Verify equivalence of time and frequency domain methods
maxDifference = max(abs(filteredSignalTime - filteredSignalFreq));
fprintf('\nTime vs Frequency domain methods:\n');
fprintf('  Maximum difference: %.2e (numerical precision)\n', maxDifference);

fprintf('\nConvolution filtering example complete.\n');
fprintf('Figures saved: convolution_filtering_time.png, ');
fprintf('convolution_filtering_frequency.png\n');
