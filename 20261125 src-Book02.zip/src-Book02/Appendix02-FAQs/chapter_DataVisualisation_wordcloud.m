%% chapter_DataVisualisation_wordcloud.m
% Word Cloud Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_wordcloud
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Requires Text Analytics Toolbox
documents = ["data science" "machine learning" ...
"artificial intelligence" "neural networks"];
figure('Position', [100 100 800 600]);
wordcloud(documents);
title('Text Analysis Visualisation');


% Export figure in multiple formats
exportFigure(gca, 'WordCloud_plot');

