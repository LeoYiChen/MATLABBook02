%% chapter_AI_Mechanics_Problem4_residual_syntax.m
% PDE residual computation using automatic differentiation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem4_residual_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function residual = computePDEResidual(dlnet, x, t, beamProperties)
    % Convert to dlarray for automatic differentiation
    xt = [x'; t'];
    dlxt = dlarray(xt, 'CB');  % C=channels, B=batch
    
    % Forward pass
    w = forward(dlnet, dlxt);
    
    % First derivatives
    dwdx = dlgradient(sum(w, 'all'), dlxt(1, :), 'EnableHigherDerivatives', true);
    dwdt = dlgradient(sum(w, 'all'), dlxt(2, :), 'EnableHigherDerivatives', true);
    
    % Second derivatives
    d2wdx2 = dlgradient(sum(dwdx, 'all'), dlxt(1, :), 'EnableHigherDerivatives', true);
    d2wdt2 = dlgradient(sum(dwdt, 'all'), dlxt(2, :));
    
    % Fourth derivative
    d3wdx3 = dlgradient(sum(d2wdx2, 'all'), dlxt(1, :), 'EnableHigherDerivatives', true);
    d4wdx4 = dlgradient(sum(d3wdx3, 'all'), dlxt(1, :));
    
    % Axial tension term (integral approximation)
    dwdx_squared = dwdx.^2;
    axialTension = beamProperties.EA / (2 * beamProperties.L) * mean(dwdx_squared);
    
    % PDE residual: rho*A*d2w/dt2 + EI*d4w/dx4 - Tension*d2w/dx2 = 0
    residual = beamProperties.rhoA * d2wdt2 + ...
               beamProperties.EI * d4wdx4 - ...
               axialTension * d2wdx2;
end
