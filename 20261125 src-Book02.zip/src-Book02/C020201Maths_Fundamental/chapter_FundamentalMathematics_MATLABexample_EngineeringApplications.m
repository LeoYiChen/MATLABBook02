%% chapter_FundamentalMathematics_MATLABexample_EngineeringApplications.m
% Matrices in engineering applications: structural dynamics example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_EngineeringApplications
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_7_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates matrix applications in engineering through
%              structural dynamics: computing natural frequencies and
%              mode shapes of a simple mass-spring system.

function demonstrateStructuralDynamics()
    fprintf('Matrices in Engineering: Structural Dynamics Example\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Simple 3-DOF mass-spring system
    demonstrateMassSpringSystem();
    
    % Part 2: Modal analysis
    demonstrateModalAnalysis();
    
    % Part 3: Forced vibration response
    demonstrateForcedResponse();
end

function demonstrateMassSpringSystem()
    % Analyse a 3-degree-of-freedom mass-spring system
    
    fprintf('Part 1: Three-DOF Mass-Spring System\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    fprintf('System description:\n');
    fprintf('Three masses connected by springs in series:\n');
    fprintf('  Fixed - [k1] - m1 - [k2] - m2 - [k3] - m3 - [k4] - Fixed\n\n');
    
    % System parameters
    m1 = 2.0; % kg
    m2 = 1.5; % kg
    m3 = 1.0; % kg
    
    k1 = 1000; % N/m
    k2 = 800;  % N/m
    k3 = 600;  % N/m
    k4 = 500;  % N/m
    
    fprintf('Masses: m₁ = %.1f kg, m₂ = %.1f kg, m₃ = %.1f kg\n', m1, m2, m3);
    fprintf('Springs: k₁ = %.0f N/m, k₂ = %.0f N/m, k₃ = %.0f N/m, k₄ = %.0f N/m\n\n', ...
            k1, k2, k3, k4);
    
    % Mass matrix M (diagonal for uncoupled masses)
    M = diag([m1, m2, m3]);
    
    fprintf('Mass matrix M:\n');
    disp(M);
    
    % Stiffness matrix K (assembled from element stiffnesses)
    % Equation: Mẍ + Kx = 0 for free vibration
    K = [k1+k2,   -k2,      0;
         -k2,    k2+k3,   -k3;
          0,      -k3,   k3+k4];
    
    fprintf('Stiffness matrix K:\n');
    disp(K);
    
    fprintf('Matrix properties:\n');
    fprintf('  K is symmetric: %s\n', mat2str(issymmetric(K)));
    fprintf('  K is positive definite: %s\n', ...
            mat2str(all(eig(K) > 0)));
    fprintf('  M is positive definite: %s\n\n', ...
            mat2str(all(eig(M) > 0)));
end

function demonstrateModalAnalysis()
    % Perform modal analysis: compute natural frequencies and mode shapes
    
    fprintf('Part 2: Modal Analysis\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % System parameters (same as Part 1)
    m1 = 2.0; m2 = 1.5; m3 = 1.0;
    k1 = 1000; k2 = 800; k3 = 600; k4 = 500;
    
    M = diag([m1, m2, m3]);
    K = [k1+k2, -k2, 0; -k2, k2+k3, -k3; 0, -k3, k3+k4];
    
    fprintf('Solving generalised eigenvalue problem: Kφ = ω²Mφ\n\n');
    
    % Solve generalised eigenvalue problem
    [modeShapes, omega2] = eig(K, M);
    
    % Extract and sort natural frequencies
    omega2_diag = diag(omega2);
    [omega2_sorted, sortIdx] = sort(omega2_diag);
    omega_sorted = sqrt(omega2_sorted); % Natural frequencies (rad/s)
    freq_sorted = omega_sorted / (2*pi); % Natural frequencies (Hz)
    
    modeShapes_sorted = modeShapes(:, sortIdx);
    
    % Normalise mode shapes (unit modal mass: φᵀMφ = 1)
    for k = 1:3
        phi = modeShapes_sorted(:, k);
        modalMass = phi' * M * phi;
        modeShapes_sorted(:, k) = phi / sqrt(modalMass);
    end
    
    % Display results
    fprintf('Natural Frequencies:\n');
    fprintf('%10*s %15*s %15*s\n', 'Mode', 'ω (rad/s)', 'f (Hz)');
    fprintf('%s\n', repmat('-', 1, 45));
    for k = 1:3
        fprintf('%10*d %15.4*f %15.4*f\n', k, omega_sorted(k), freq_sorted(k));
    end
    fprintf('\n');
    
    fprintf('Mode Shapes (columns of Φ, normalised to unit modal mass):\n');
    fprintf('Mode 1      Mode 2      Mode 3\n');
    fprintf('%s\n', repmat('-', 1, 40));
    for i = 1:3
        fprintf('%8.4*f    %8.4*f    %8.4*f\n', modeShapes_sorted(i, :));
    end
    fprintf('\n');
    
    % Verify orthogonality conditions
    fprintf('Verification of orthogonality conditions:\n');
    fprintf('Modal mass matrix Φ''MΦ (should be identity):\n');
    modalMassMatrix = modeShapes_sorted' * M * modeShapes_sorted;
    disp(modalMassMatrix);
    
    fprintf('Modal stiffness matrix Φ''KΦ (should be diagonal with ω²):\n');
    modalStiffnessMatrix = modeShapes_sorted' * K * modeShapes_sorted;
    disp(modalStiffnessMatrix);
    
    % Visualise mode shapes
    figure('Position', [100, 100, 1200, 400]);
    
    for k = 1:3
        subplot(1, 3, k);
        
        % Position coordinates
        positions = [0, 1, 2, 3, 4]; % Equilibrium positions
        % Displacements (including fixed ends at 0)
        displacements = [0; modeShapes_sorted(:, k); 0];
        
        % Plot equilibrium configuration
        plot(positions, zeros(size(positions)), 'k--', 'LineWidth', 1);
        hold on;
        
        % Plot deformed configuration
        plot(positions, displacements, 'b-o', 'LineWidth', 2, ...
             'MarkerSize', 10, 'MarkerFaceColor', 'b');
        
        % Mark masses
        plot(positions(2:4), displacements(2:4), 'ro', ...
             'MarkerSize', 12, 'MarkerFaceColor', 'r');
        
        grid on;
        xlabel('Position', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('Displacement', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('Mode %d: f = %.2f Hz', k, freq_sorted(k)), ...
              'Interpreter', 'latex', 'FontSize', 12);
        legend('Equilibrium', 'Deformed shape', 'Masses', ...
               'Interpreter', 'latex', 'Location', 'best', 'FontSize', 9);
        set(gca, 'FontSize', 10);
        axis equal;
        ylim([-1.5, 1.5]);
    end
    
    fprintf('Mode shapes visualised\n\n');
end

function demonstrateForcedResponse()
    % Demonstrate forced vibration response
    
    fprintf('Part 3: Forced Vibration Response\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % System parameters
    m1 = 2.0; m2 = 1.5; m3 = 1.0;
    k1 = 1000; k2 = 800; k3 = 600; k4 = 500;
    
    M = diag([m1, m2, m3]);
    K = [k1+k2, -k2, 0; -k2, k2+k3, -k3; 0, -k3, k3+k4];
    
    % Add proportional damping: C = αM + βK
    alpha = 0.1;
    beta = 0.0001;
    C = alpha * M + beta * K;
    
    fprintf('System with proportional damping: C = αM + βK\n');
    fprintf('α = %.2f, β = %.4f\n\n', alpha, beta);
    
    % Harmonic force applied to mass 2
    fprintf('Applying harmonic force F(t) = F₀sin(ωt) to mass 2\n');
    F0 = 100; % N
    fprintf('Force amplitude: F₀ = %.0f N\n\n', F0);
    
    % Frequency sweep
    [modeShapes, omega2] = eig(K, M);
    omega_natural = sqrt(sort(diag(omega2)));
    
    % Sweep from 0 to 2$\times$ highest natural frequency
    omega_sweep = linspace(0.1, 2*max(omega_natural), 500);
    
    % Compute steady-state amplitude for each frequency
    amplitude = zeros(3, length(omega_sweep));
    
    for idx = 1:length(omega_sweep)
        omega = omega_sweep(idx);
        
        % Frequency response: (-ω²M + iωC + K)*X = F
        Z = -omega^2 * M + 1*i*omega*C + K;
        F = [0; F0; 0]; % Force on mass 2
        
        X = Z \ F;
        amplitude(:, idx) = abs(X);
    end
    
    % Plot frequency response
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    for k = 1:3
        plot(omega_sweep/(2*pi), amplitude(k, :), 'LineWidth', 2, ...
             'DisplayName', sprintf('Mass %d', k));
        hold on;
    end
    
    % Mark natural frequencies
    for k = 1:3
        f_nat = omega_natural(k) / (2*pi);
        plot([f_nat, f_nat], ylim, 'k--', 'LineWidth', 1, ...
             'HandleVisibility', 'off');
    end
    
    grid on;
    xlabel('Excitation Frequency (Hz)', 'Interpreter', 'latex', ...
           'FontSize', 12);
    ylabel('Displacement Amplitude (m)', 'Interpreter', 'latex', ...
           'FontSize', 12);
    title('Frequency Response Functions', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'northeast', 'FontSize', 10);
    set(gca, 'FontSize', 11);
    
    % Log scale version
    subplot(1, 2, 2);
    for k = 1:3
        semilogy(omega_sweep/(2*pi), amplitude(k, :), 'LineWidth', 2, ...
                 'DisplayName', sprintf('Mass %d', k));
        hold on;
    end
    
    % Mark natural frequencies
    for k = 1:3
        f_nat = omega_natural(k) / (2*pi);
        plot([f_nat, f_nat], ylim, 'k--', 'LineWidth', 1, ...
             'HandleVisibility', 'off');
    end
    
    grid on;
    xlabel('Excitation Frequency (Hz)', 'Interpreter', 'latex', ...
           'FontSize', 12);
    ylabel('Displacement Amplitude (m, log scale)', ...
           'Interpreter', 'latex', 'FontSize', 12);
    title('Frequency Response (Log Scale)', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'northeast', 'FontSize', 10);
    set(gca, 'FontSize', 11);
    
    fprintf('Frequency response plotted\n');
    fprintf('Peaks occur near natural frequencies: %.2f, %.2f, %.2f Hz\n', ...
            omega_natural / (2*pi));
    fprintf('Damping prevents infinite response at resonance\n');
end
