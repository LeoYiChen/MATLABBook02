%% chapter_AI_Mechanics_Problem8_windowing_syntax.m
% Sequence windowing for time series syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem8_windowing_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create overlapping sequences for LSTM training
% data: (numSamples   numFeatures) time series matrix
% lookback: number of past time steps to use as input
% horizon: number of future time steps to predict

function [XTrain, YTrain] = createSequences(data, lookback, horizon)
    numSamples = size(data, 1);
    numFeatures = size(data, 2);
    
    % Preallocate cell arrays
    numSequences = numSamples - lookback - horizon + 1;
    XTrain = cell(numSequences, 1);
    YTrain = cell(numSequences, 1);
    
    for i = 1:numSequences
        % Input: lookback   numFeatures
        XTrain{i} = data(i:i+lookback-1, :)';
        
        % Output: horizon   numFeatures (or just first channel)
        YTrain{i} = data(i+lookback:i+lookback+horizon-1, 1)';  % Forecast channel 1
    end
end

% Normalisation (min-max scaling to [0,1])
dataMin = min(data, [], 1);
dataMax = max(data, [], 1);
dataNorm = (data - dataMin) ./ (dataMax - dataMin + 1e-8);

% Create sequences
lookback = 720;  % 30 days
horizon = 168;   % 7 days
[XTrain, YTrain] = createSequences(dataNorm, lookback, horizon);
