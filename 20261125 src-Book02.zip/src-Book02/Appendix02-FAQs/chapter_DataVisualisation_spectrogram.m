%% chapter_DataVisualisation_spectrogram.m
% Spectrogram Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_spectrogram
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createSpectrogram(signal, fs)
% Create figure
h = figure('Position', [100 100 1000 600]);

% Calculate spectrogram
window = hamming(256);
noverlap = 128;
nfft = 512;

[s,f,t] = spectrogram(signal, window, noverlap, nfft, fs, ...
                     'yaxis');

% Plot spectrogram
surf(t, f, 10*log10(abs(s)), 'EdgeColor', 'none');
view(0, 90);

% Customize appearance
colormap('jet');
c = colorbar;
c.Label.String = 'Power/Frequency (dB/Hz)';

xlabel('Time (s)');
ylabel('Frequency (Hz)');
title('Time-Frequency Analysis');

% Export figure
exportFigure(h, 'spectrogram');

end
