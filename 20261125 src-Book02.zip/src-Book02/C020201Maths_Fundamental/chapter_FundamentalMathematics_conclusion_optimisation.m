%% chapter_FundamentalMathematics_conclusion_optimisation.m
% Optimisation methods for finding extrema.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_conclusion_optimisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateOptimisationMethods();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateOptimisationMethods()
    % DEMONSTRATEOPTIMISATIONMETHODS Optimisation algorithms overview
    %   Explores unconstrained and constrained optimisation
    
    fprintf('Optimisation: Finding Optima in Complex Landscapes\n');
    fprintf('===================================================\n\n');
    
    %% Unconstrained Optimisation
    fprintf('UNCONSTRAINED OPTIMISATION\n');
    fprintf('-----\n\n');
    
    fprintf(['Finding minima of multi-dimensional functions\n', ...
        'using gradient-based methods.\n\n']);
    
    % Rosenbrock function (classic test problem)
    % f(x,y) = (1-x)^2 + 100*(y-x^2)^2
    % Global minimum at (1,1) with f(1,1) = 0
    
    rosenbrock = @(x) (1 - x(1))^2 + 100 * (x(2) - x(1)^2)^2;
    
    fprintf('Test function: Rosenbrock function\n');
    fprintf('  f(x,y) = (1-x)^2 + 100*(y-x^2)^2\n');
    fprintf('  Known minimum: (1, 1) with f=0\n\n');
    
    % Starting point
    x0 = [-1.5; 2];
    
    fprintf('Starting point: (%.2f, %.2f)\n', x0(1), x0(2));
    fprintf('Initial function value: %.6f\n\n', rosenbrock(x0));
    
    % Optimisation using fminunc
    options = optimset('Display', 'off', 'MaxIter', 1000);
    [x_opt, f_opt, exitflag, output] = fminunc(rosenbrock, x0, options);
    
    fprintf('Optimisation Results:\n');
    fprintf('  Optimal point: (%.6f, %.6f)\n', x_opt(1), x_opt(2));
    fprintf('  Optimal value: %.10f\n', f_opt);
    fprintf('  Iterations: %d\n', output.iterations);
    fprintf('  Function evaluations: %d\n\n', output.funcCount);
    
    %% Visualise Optimisation Path
    fprintf('VISUALISATION: OPTIMISATION TRAJECTORY\n');
    fprintf('-------\n\n');
    
    % Create contour plot
    [X, Y] = meshgrid(-2:0.05:2, -1:0.05:3);
    Z = zeros(size(X));
    
    for i = 1:numel(X)
        Z(i) = rosenbrock([X(i); Y(i)]);
    end
    
    figure('Position', [100, 100, 1400, 600]);
    
    subplot(1, 2, 1);
    contour(X, Y, log10(Z + 1), 50);
    colorbar;
    hold on;
    plot(1, 1, 'r*', 'MarkerSize', 15, 'LineWidth', 3);
    plot(x0(1), x0(2), 'go', 'MarkerSize', 12, 'MarkerFaceColor', 'g');
    
    xlabel('x');
    ylabel('y');
    title('Rosenbrock Function (log scale)');
    grid on;
    
    fprintf('Visualisation shows characteristic "banana-shaped valley"\n');
    fprintf('of Rosenbrock function, presenting challenges for optimisation.\n\n');
    
    %% Constrained Optimisation
    fprintf('CONSTRAINED OPTIMISATION\n');
    fprintf('----\n\n');
    
    fprintf(['Minimising objective function subject to constraints\n', ...
        'using interior-point or active-set methods.\n\n']);
    
    % Simple problem: minimise (x-3)^2 + (y-2)^2
    % subject to: x + y <= 5, x >= 0, y >= 0
    
    objective = @(x) (x(1) - 3)^2 + (x(2) - 2)^2;
    
    % Linear inequality constraints: A*x <= b
    A = [1, 1];
    b = 5;
    
    % Bounds
    lb = [0; 0];
    ub = [Inf; Inf];
    
    x0_constrained = [1; 1];
    
    fprintf('Objective: f(x,y) = (x-3)^2 + (y-2)^2\n');
    fprintf('Constraints: x + y <= 5, x >= 0, y >= 0\n\n');
    
    % Solve constrained problem
    options_constrained = optimoptions('fmincon', 'Display', 'off');
    [x_const, f_const] = fmincon(objective, x0_constrained, A, b, [], [], ...
        lb, ub, [], options_constrained);
    
    fprintf('Constrained Optimisation Results:\n');
    fprintf('  Optimal point: (%.4f, %.4f)\n', x_const(1), x_const(2));
    fprintf('  Optimal value: %.6f\n', f_const);
    fprintf('  Constraint x+y: %.4f (limit: %.1f)\n\n', ...
        sum(x_const), b);
    
    % Compare with unconstrained optimum
    x_unconst = [3; 2];
    f_unconst = objective(x_unconst);
    
    fprintf('Comparison with Unconstrained Optimum:\n');
    fprintf('  Unconstrained point: (%.1f, %.1f)\n', x_unconst(1), x_unconst(2));
    fprintf('  Unconstrained value: %.6f\n', f_unconst);
    fprintf('  Constraint x+y: %.1f (VIOLATES limit)\n\n', sum(x_unconst));
    
    % Visualisation
    subplot(1, 2, 2);
    [X_c, Y_c] = meshgrid(0:0.1:5, 0:0.1:5);
    Z_c = (X_c - 3).^2 + (Y_c - 2).^2;
    
    contour(X_c, Y_c, Z_c, 20);
    colorbar;
    hold on;
    
    % Plot constraint boundary
    x_constraint = [0, 5];
    y_constraint = [5, 0];
    plot(x_constraint, y_constraint, 'r-', 'LineWidth', 3, ...
        'DisplayName', 'Constraint: x+y=5');
    
    % Mark optima
    plot(x_unconst(1), x_unconst(2), 'b*', 'MarkerSize', 15, 'LineWidth', 3, ...
        'DisplayName', 'Unconstrained Optimum');
    plot(x_const(1), x_const(2), 'ro', 'MarkerSize', 12, ...
        'MarkerFaceColor', 'r', 'DisplayName', 'Constrained Optimum');
    
    xlabel('x');
    ylabel('y');
    title('Constrained Optimisation');
    legend('Location', 'best');
    grid on;
    xlim([0, 5]);
    ylim([0, 5]);
    
    fprintf('Constraints modify the optimisation landscape,\n');
    fprintf('forcing solutions to feasible regions.\n\n');
end

% Added missing local function (book correction)
function [f, g] = rosenbrock(x)
f = 100*(x(2)-x(1)^2)^2 + (1-x(1))^2;
if nargout > 1, g = [-400*x(1)*(x(2)-x(1)^2)-2*(1-x(1)); 200*(x(2)-x(1)^2)]; end
end
