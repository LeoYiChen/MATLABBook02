%% C020202Maths_Advanced_code_197.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020202Maths_Advanced/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Kernel PCA implementation
gamma = 0.5;  % RBF kernel parameter
numSamples = size(dataMatrix, 2);

% Compute RBF kernel matrix
kernelMatrix = zeros(numSamples, numSamples);
for idx1 = 1:numSamples
    for idx2 = 1:numSamples
        difference = dataMatrix(:, idx1) - dataMatrix(:, idx2);
        kernelMatrix(idx1, idx2) = exp(-gamma * norm(difference)^2);
    end
end

% Centre kernel matrix
onesMatrix = ones(numSamples) / numSamples;
kernelCentred = kernelMatrix - onesMatrix * kernelMatrix - ...
    kernelMatrix * onesMatrix + onesMatrix * kernelMatrix * onesMatrix;

% Eigendecomposition of centred kernel
[kernelEigenvectors, kernelEigenvalues] = eig(kernelCentred);
[~, sortIdx] = sort(diag(kernelEigenvalues), 'descend');
kernelPCs = kernelEigenvectors(:, sortIdx);
