%% listing_problem7_mrac.m
% Problem 7: Model reference adaptive control for DC motor with unknown inertia and friction, showing parameter convergence under persistent excitation and tracking performance comparison against fixed-gain controller.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem7_mrac
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 7 - Model Reference Adaptive Control
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: MRAC for DC motor with unknown J and B. Demonstrates
%              parameter convergence, persistent excitation effects,
%              and comparison with fixed-gain control.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 7: Model Reference Adaptive Control for DC Motor\n');
fprintf('==================================================================\n\n');

%% DC Motor Parameters (True but Unknown)
fprintf('=== DC Motor Parameters (True Values) ===\n');

motor.R = 1.0;          % Armature resistance (Ohm)
motor.k = 0.05;         % Torque/back-EMF constant (N m/A or V s/rad)
motor.J = 0.02;         % Moment of inertia (kg m) - UNKNOWN
motor.B = 0.005;        % Viscous friction (N m s/rad) - UNKNOWN

% Derived parameters (unknown)
motor.a = (motor.B + motor.k^2/motor.R) / motor.J;
motor.b = motor.k / (motor.J * motor.R);

fprintf('Electrical:\n');
fprintf('  R = %.3f Ohm\n', motor.R);
fprintf('  k = %.4f N m/A\n', motor.k);

fprintf('Mechanical (UNKNOWN to controller):\n');
fprintf('  J = %.4f kg m\n', motor.J);
fprintf('  B = %.4f N m s/rad\n', motor.B);

fprintf('\nDerived coefficients:\n');
fprintf('  a = %.3f (damping)\n', motor.a);
fprintf('  b = %.3f (gain)\n\n', motor.b);

%% Reference Model Design
fprintf('=== Reference Model Design ===\n');

% Desired dynamics: first-order with time constant tau_m
tau_m = 0.5;         % Desired time constant (s)
ref_model.am = 1/tau_m;
ref_model.bm = ref_model.am;  % DC gain = 1

fprintf('Reference model: d _m/dt = -a_m* _m + b_m*r\n');
fprintf('  a_m = %.3f (pole at s = -%.3f)\n', ref_model.am, ref_model.am);
fprintf('  b_m = %.3f (DC gain = %.3f)\n', ref_model.bm, ref_model.bm/ref_model.am);
fprintf('  Time constant: %.3f s\n', tau_m);
fprintf('  Step response: 2%% settling ~%.2f s\n\n', 4*tau_m);

%% MRAC Controller Design
fprintf('=== MRAC Controller Parameters ===\n');

% Adaptation gain
mrac.gamma = 50;     % Larger = faster adaptation (but may cause oscillations)

% Initial parameter estimates (can start at zero or rough guess)
mrac.theta1_0 = 0;
mrac.theta2_0 = 0;

fprintf('Adaptation gain   = %.1f\n', mrac.gamma);
fprintf('Initial estimates:  (0) = %.2f,  (0) = %.2f\n\n', ...
    mrac.theta1_0, mrac.theta2_0);

% Ideal parameters (for reference, computed from known values)
theta1_ideal = (motor.a - ref_model.am) / motor.b;
theta2_ideal = ref_model.bm / motor.b;

fprintf('Ideal parameters (if a,b were known):\n');
fprintf('   * = %.3f\n', theta1_ideal);
fprintf('   * = %.3f\n\n', theta2_ideal);

%% Fixed-Gain Controller (for comparison)
fprintf('=== Fixed-Gain Controller Design ===\n');

% Use nominal (incorrect) parameter estimates
motor_nom.J_nom = 0.015;  % 25% error
motor_nom.B_nom = 0.004;  % 20% error
motor_nom.a_nom = (motor_nom.B_nom + motor.k^2/motor.R) / motor_nom.J_nom;
motor_nom.b_nom = motor.k / (motor_nom.J_nom * motor.R);

fixed.theta1 = (motor_nom.a_nom - ref_model.am) / motor_nom.b_nom;
fixed.theta2 = ref_model.bm / motor_nom.b_nom;

fprintf('Nominal estimates: J_nom = %.4f, B_nom = %.4f\n', ...
    motor_nom.J_nom, motor_nom.B_nom);
fprintf('Fixed controller gains:\n');
fprintf('    = %.3f (error = %.1f%%)\n', fixed.theta1, ...
    abs(fixed.theta1 - theta1_ideal)/abs(theta1_ideal)*100);
fprintf('    = %.3f (error = %.1f%%)\n\n', fixed.theta2, ...
    abs(fixed.theta2 - theta2_ideal)/abs(theta2_ideal)*100);

%% Reference Input Design
fprintf('=== Reference Input Scenarios ===\n');

% Scenario 1: Step input (NOT persistently exciting)
scenarios(1).name = 'Step Input (Not PE)';
scenarios(1).type = 'step';
scenarios(1).amp = 100;   % rad/s
scenarios(1).freq = 0;

% Scenario 2: Multi-step (better but not PE)
scenarios(2).name = 'Multi-Step (Not PE)';
scenarios(2).type = 'multistep';

% Scenario 3: Sinusoidal (Persistently Exciting)
scenarios(3).name = 'Sine Wave (PE)';
scenarios(3).type = 'sine';
scenarios(3).amp = 50;
scenarios(3).freq = 2;    % rad/s

% Scenario 4: Multi-sine (Rich PE)
scenarios(4).name = 'Multi-Sine (Rich PE)';
scenarios(4).type = 'multisine';

for i = 1:length(scenarios)
    fprintf('Scenario %d: %s\n', i, scenarios(i).name);
end
fprintf('\n');

%% Simulation Setup
Tsim = 20;          % Simulation time (s)
dt = 0.001;         % Time step (s)
t = 0:dt:Tsim;
Nt = length(t);

fprintf('=== Simulation Parameters ===\n');
fprintf('Duration: %.1f s\n', Tsim);
fprintf('Time step: %.4f s\n', dt);
fprintf('Samples: %d\n\n', Nt);

%% Run Simulations
results_mrac = cell(length(scenarios), 1);
results_fixed = cell(length(scenarios), 1);

for scen = 1:length(scenarios)
    fprintf('=== Scenario %d: %s ===\n', scen, scenarios(scen).name);
    
    % Generate reference input
    r = generate_reference(t, scenarios(scen));
    
    % Initial conditions
    omega0 = 0;
    omega_m0 = 0;
    theta1_init = mrac.theta1_0;
    theta2_init = mrac.theta2_0;
    
    % MRAC simulation
    fprintf('  Simulating MRAC...\n');
    [t_mrac, omega_mrac, omega_m_mrac, theta_mrac, u_mrac] = ...
        simulate_mrac(t, omega0, omega_m0, theta1_init, theta2_init, ...
        r, motor, ref_model, mrac);
    
    results_mrac{scen}.t = t_mrac;
    results_mrac{scen}.omega = omega_mrac;
    results_mrac{scen}.omega_m = omega_m_mrac;
    results_mrac{scen}.theta = theta_mrac;
    results_mrac{scen}.u = u_mrac;
    results_mrac{scen}.r = r;
    results_mrac{scen}.error = omega_mrac - omega_m_mrac;
    
    % Fixed-gain simulation
    fprintf('  Simulating Fixed-Gain...\n');
    [t_fixed, omega_fixed, omega_m_fixed, u_fixed] = ...
        simulate_fixed(t, omega0, omega_m0, r, motor, ref_model, fixed);
    
    results_fixed{scen}.t = t_fixed;
    results_fixed{scen}.omega = omega_fixed;
    results_fixed{scen}.omega_m = omega_m_fixed;
    results_fixed{scen}.u = u_fixed;
    results_fixed{scen}.r = r;
    results_fixed{scen}.error = omega_fixed - omega_m_fixed;
    
    % Performance metrics
    rms_mrac = sqrt(mean(results_mrac{scen}.error(Nt/2:end).^2));
    rms_fixed = sqrt(mean(results_fixed{scen}.error(Nt/2:end).^2));
    
    fprintf('  RMS tracking error (steady-state):\n');
    fprintf('    MRAC: %.4f rad/s\n', rms_mrac);
    fprintf('    Fixed: %.4f rad/s\n', rms_fixed);
    
    % Parameter convergence (final values)
    theta1_final = theta_mrac(1,end);
    theta2_final = theta_mrac(2,end);
    
    fprintf('  Final parameter estimates:\n');
    fprintf('     : %.3f (ideal = %.3f, error = %.2f%%)\n', ...
        theta1_final, theta1_ideal, ...
        abs(theta1_final - theta1_ideal)/abs(theta1_ideal)*100);
    fprintf('     : %.3f (ideal = %.3f, error = %.2f%%)\n\n', ...
        theta2_final, theta2_ideal, ...
        abs(theta2_final - theta2_ideal)/abs(theta2_ideal)*100);
end

%% Plot Results - Scenario 3 (PE case)
fprintf('=== Generating Plots ===\n');

scen = 3;  % Sine wave (PE)

figure('Position', [50, 50, 1400, 900]);

% Velocity tracking
subplot(3,3,1);
plot(t, results_mrac{scen}.r, 'k-', 'LineWidth', 1.5, 'DisplayName', 'Reference model');
hold on;
plot(results_mrac{scen}.t, results_mrac{scen}.omega_m, 'b:', ...
    'LineWidth', 1.5, 'DisplayName', '$\omega_m$');
plot(results_mrac{scen}.t, results_mrac{scen}.omega, 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'MRAC');
plot(results_fixed{scen}.t, results_fixed{scen}.omega, 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fixed');
grid on;
ylabel('$\omega$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('Velocity Tracking', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 9);

% Tracking error
subplot(3,3,2);
plot(results_mrac{scen}.t, results_mrac{scen}.error, 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'MRAC');
hold on;
plot(results_fixed{scen}.t, results_fixed{scen}.error, 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fixed');
grid on;
ylabel('$e = \omega - \omega_m$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('Tracking Error', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Control input
subplot(3,3,3);
plot(results_mrac{scen}.t, results_mrac{scen}.u, 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'MRAC');
hold on;
plot(results_fixed{scen}.t, results_fixed{scen}.u, 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fixed');
grid on;
ylabel('$u = v$ (V)', 'Interpreter', 'latex', 'FontSize', 10);
title('Control Voltage', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Parameter   evolution
subplot(3,3,4);
plot(results_mrac{scen}.t, results_mrac{scen}.theta(1,:), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', '$\hat{\theta}_1(t)$');
hold on;
yline(theta1_ideal, 'k-', 'LineWidth', 1.5, 'DisplayName', '$\theta_1^*$ (ideal)');
yline(fixed.theta1, 'r-', 'LineWidth', 1.5, 'DisplayName', '$\theta_1$ (fixed)');
grid on;
ylabel('$\theta_1$', 'Interpreter', 'latex', 'FontSize', 10);
title('Parameter $\theta_1$ Adaptation', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 9);

% Parameter   evolution
subplot(3,3,5);
plot(results_mrac{scen}.t, results_mrac{scen}.theta(2,:), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', '$\hat{\theta}_2(t)$');
hold on;
yline(theta2_ideal, 'k-', 'LineWidth', 1.5, 'DisplayName', '$\theta_2^*$ (ideal)');
yline(fixed.theta2, 'r-', 'LineWidth', 1.5, 'DisplayName', '$\theta_2$ (fixed)');
grid on;
ylabel('$\theta_2$', 'Interpreter', 'latex', 'FontSize', 10);
title('Parameter $\theta_2$ Adaptation', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 9);

% Parameter trajectory in  -  plane
subplot(3,3,6);
plot(results_mrac{scen}.theta(1,:), results_mrac{scen}.theta(2,:), 'b-', ...
    'LineWidth', 1.2);
hold on;
plot(theta1_ideal, theta2_ideal, 'ko', 'MarkerSize', 10, 'LineWidth', 2, ...
    'DisplayName', 'Ideal');
plot(mrac.theta1_0, mrac.theta2_0, 'bs', 'MarkerSize', 10, 'LineWidth', 2, ...
    'DisplayName', 'Initial');
plot(results_mrac{scen}.theta(1,end), results_mrac{scen}.theta(2,end), ...
    'bd', 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', 'Final');
grid on;
xlabel('$\theta_1$', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$\theta_2$', 'Interpreter', 'latex', 'FontSize', 10);
title('Parameter Trajectory', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Error vs time (log scale)
subplot(3,3,7);
semilogy(results_mrac{scen}.t, abs(results_mrac{scen}.error), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'MRAC');
hold on;
semilogy(results_fixed{scen}.t, abs(results_fixed{scen}.error), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fixed');
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$|e|$ (rad/s, log)', 'Interpreter', 'latex', 'FontSize', 10);
title('Error Magnitude (Log)', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Parameter error  
subplot(3,3,8);
plot(results_mrac{scen}.t, results_mrac{scen}.theta(1,:) - theta1_ideal, 'b-', ...
    'LineWidth', 1.2);
hold on;
yline(0, 'k-', 'LineWidth', 1);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$\tilde{\theta}_1 = \hat{\theta}_1 - \theta_1^*$', ...
    'Interpreter', 'latex', 'FontSize', 10);
title('Parameter Error $\theta_1$', 'Interpreter', 'latex', 'FontSize', 12);

% Parameter error  
subplot(3,3,9);
plot(results_mrac{scen}.t, results_mrac{scen}.theta(2,:) - theta2_ideal, 'b-', ...
    'LineWidth', 1.2);
hold on;
yline(0, 'k-', 'LineWidth', 1);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$\tilde{\theta}_2 = \hat{\theta}_2 - \theta_2^*$', ...
    'Interpreter', 'latex', 'FontSize', 10);
title('Parameter Error $\theta_2$', 'Interpreter', 'latex', 'FontSize', 12);

sgtitle(['Scenario 3: ' scenarios(3).name ' (MRAC with PE)'], ...
    'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem07_MRAC_PE.fig');
saveas(gcf, 'Problem07_MRAC_PE.eps', 'epsc');

%% Comparison: All Scenarios
figure('Position', [100, 100, 1400, 800]);

for scen = 1:length(scenarios)
    % Tracking error
    subplot(2,4,scen);
    plot(results_mrac{scen}.t, results_mrac{scen}.error, 'b-', ...
        'LineWidth', 1.2, 'DisplayName', 'MRAC');
    hold on;
    plot(results_fixed{scen}.t, results_fixed{scen}.error, 'r-', ...
        'LineWidth', 1.2, 'DisplayName', 'Fixed');
    grid on;
    ylabel('$e$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 9);
    title(scenarios(scen).name, 'Interpreter', 'latex', 'FontSize', 10);
    if scen == 1
        legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 8);
    end
    
    % Parameter convergence
    subplot(2,4,scen+4);
    plot(results_mrac{scen}.t, results_mrac{scen}.theta(1,:), 'b-', ...
        'LineWidth', 1.2, 'DisplayName', '$\hat{\theta}_1$');
    hold on;
    plot(results_mrac{scen}.t, results_mrac{scen}.theta(2,:), 'r-', ...
        'LineWidth', 1.2, 'DisplayName', '$\hat{\theta}_2$');
    yline(theta1_ideal, 'b-', 'LineWidth', 1);
    yline(theta2_ideal, 'r-', 'LineWidth', 1);
    grid on;
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 9);
    ylabel('$\theta$', 'Interpreter', 'latex', 'FontSize', 9);
    if scen == 1
        legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 8);
    end
end

sgtitle('PE Effect on Parameter Convergence', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem07_PE_Comparison.fig');
saveas(gcf, 'Problem07_PE_Comparison.eps', 'epsc');

fprintf('Plots saved.\n\n');
fprintf('=== Problem 7 Complete ===\n');

%% Simulation Functions

function r = generate_reference(t, scenario)
    % Generate reference input based on scenario type
    
    Nt = length(t);
    r = zeros(1, Nt);
    
    switch scenario.type
        case 'step'
            r(t >= 1) = scenario.amp;
            
        case 'multistep'
            r(t >= 1 & t < 6) = 80;
            r(t >= 6 & t < 11) = 40;
            r(t >= 11 & t < 16) = 100;
            r(t >= 16) = 60;
            
        case 'sine'
            r = scenario.amp * sin(scenario.freq * t);
            
        case 'multisine'
            r = 30*sin(1.5*t) + 20*sin(3*t) + 15*sin(5*t);
    end
end

function [t_out, omega, omega_m, theta, u] = simulate_mrac(t, omega0, omega_m0, ...
    theta1_0, theta2_0, r, motor, ref_model, mrac)
    % Simulate DC motor with MRAC
    
    dt = t(2) - t(1);
    Nt = length(t);
    
    % State initialization
    omega = zeros(1, Nt);
    omega_m = zeros(1, Nt);
    theta = zeros(2, Nt);
    u = zeros(1, Nt);
    
    omega(1) = omega0;
    omega_m(1) = omega_m0;
    theta(:,1) = [theta1_0; theta2_0];
    
    for i = 1:Nt-1
        % Current state
        w = omega(i);
        wm = omega_m(i);
        th1 = theta(1,i);
        th2 = theta(2,i);
        
        % Control law
        u(i) = th1 * w + th2 * r(i);
        
        % Plant dynamics: d /dt = -a*  + b*u
        omega_dot = -motor.a * w + motor.b * u(i);
        
        % Reference model: d _m/dt = -a_m* _m + b_m*r
        omega_m_dot = -ref_model.am * wm + ref_model.bm * r(i);
        
        % Tracking error
        e = w - wm;
        
        % Adaptation law: d /dt = -  * e * [ ; r]
        theta_dot = -mrac.gamma * e * [w; r(i)];
        
        % Integration (Euler)
        omega(i+1) = w + dt * omega_dot;
        omega_m(i+1) = wm + dt * omega_m_dot;
        theta(:,i+1) = theta(:,i) + dt * theta_dot;
    end
    
    % Final control
    u(end) = theta(1,end) * omega(end) + theta(2,end) * r(end);
    
    t_out = t;
end

function [t_out, omega, omega_m, u] = simulate_fixed(t, omega0, omega_m0, ...
    r, motor, ref_model, fixed)
    % Simulate DC motor with fixed-gain controller
    
    dt = t(2) - t(1);
    Nt = length(t);
    
    omega = zeros(1, Nt);
    omega_m = zeros(1, Nt);
    u = zeros(1, Nt);
    
    omega(1) = omega0;
    omega_m(1) = omega_m0;
    
    for i = 1:Nt-1
        w = omega(i);
        wm = omega_m(i);
        
        % Fixed control law
        u(i) = fixed.theta1 * w + fixed.theta2 * r(i);
        
        % Plant dynamics
        omega_dot = -motor.a * w + motor.b * u(i);
        
        % Reference model
        omega_m_dot = -ref_model.am * wm + ref_model.bm * r(i);
        
        % Integration
        omega(i+1) = w + dt * omega_dot;
        omega_m(i+1) = wm + dt * omega_m_dot;
    end
    
    u(end) = fixed.theta1 * omega(end) + fixed.theta2 * r(end);
    
    t_out = t;
end
