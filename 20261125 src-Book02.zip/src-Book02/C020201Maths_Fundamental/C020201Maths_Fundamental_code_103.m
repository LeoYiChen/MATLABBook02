%% C020201Maths_Fundamental_code_103.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Monte Carlo integration in high dimensions
numSamples = 1000000;
dimensionality = 10;

% Integrate exp(-||x||^2) over unit hypercube
randomPoints = rand(dimensionality, numSamples);
functionValues = exp(-sum(randomPoints.^2, 1));
integralMonteCarlo = mean(functionValues);

% Error estimate (central limit theorem)
errorEstimate = std(functionValues) / sqrt(numSamples);
