%% chapter_DataVisualisation_qq.m
% Q-Q Plot Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_qq
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createQQPlot(data)
% Create figure
h = figure('Position', [100 100 800 600]);

% Generate theoretical quantiles
n = length(data);
p = ((1:n)' - 0.5)/n;
theoretical_q = sqrt(2) * erfinv(2*p - 1);

% Sort the data
sorted_data = sort((data - mean(data))/std(data));

% Create Q-Q plot
plot(theoretical_q, sorted_data, 'b.', 'MarkerSize', 12);
hold on;

% Add reference line
xl = xlim;
yl = ylim;
plot(xl, xl, 'r--');

% Labels and title
xlabel('Theoretical Quantiles');
ylabel('Sample Quantiles');
title('Normal Q-Q Plot');
grid on;

% Export figure
exportFigure(h, 'qq_plot');

end
