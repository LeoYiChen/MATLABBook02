%% chapter_FundamentalMaths_example_Sampling.m
% Sampling theorem demonstration with aliasing and reconstruction.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_Sampling
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section6_example3.m
% Author: Dr Leo Chen
% Date: June 4, 2025
% MATLAB Version: R2025a
% Description: Comprehensive demonstration of sampling theorem, aliasing
% effects, and signal reconstruction techniques for digital signal processing

fprintf('=== Sampling Theory and Reconstruction Demonstration ===\n\n');

%% Signal Parameters and Generation
fundamentalFrequency = 5;      % Primary frequency component (Hz)
harmonicFrequency = 15;        % Harmonic frequency component (Hz)
signalDuration = 2;            % Signal duration (seconds)

% Generate high-resolution reference (approximates continuous-time)
timeReference = linspace(0, signalDuration, 10000);
continuousSignal = sin(2*pi*fundamentalFrequency*timeReference) + ...
                  0.5*sin(2*pi*harmonicFrequency*timeReference);

fprintf('Signal parameters:\n');
fprintf('  Frequency components: %d Hz, %d Hz\n', ...
    fundamentalFrequency, harmonicFrequency);
fprintf('  Maximum frequency: %d Hz\n', harmonicFrequency);
fprintf('  Nyquist rate: %d Hz\n', 2*harmonicFrequency);

%% Proper Sampling (Satisfying Nyquist Criterion)
properSamplingFrequency = 2.5 * harmonicFrequency;  % > 2*f_max
properSamplingPeriod = 1 / properSamplingFrequency;
properTimeIndices = 0:properSamplingPeriod:signalDuration;
properSampledSignal = sin(2*pi*fundamentalFrequency*properTimeIndices) + ...
                     0.5*sin(2*pi*harmonicFrequency*properTimeIndices);

fprintf('\nProper sampling:\n');
fprintf('  Sampling frequency: %.1f Hz\n', properSamplingFrequency);
fprintf('  Sampling period: %.4f s\n', properSamplingPeriod);
fprintf('  Number of samples: %d\n', length(properSampledSignal));

%% Aliased Sampling (Violating Nyquist Criterion)
aliasingSamplingFrequency = 0.8 * harmonicFrequency;  % < 2*f_max
aliasingSamplingPeriod = 1 / aliasingSamplingFrequency;
aliasingTimeIndices = 0:aliasingSamplingPeriod:signalDuration;
aliasedSampledSignal = sin(2*pi*fundamentalFrequency*aliasingTimeIndices) + ...
                      0.5*sin(2*pi*harmonicFrequency*aliasingTimeIndices);

fprintf('\nAliased sampling (Nyquist violation):\n');
fprintf('  Sampling frequency: %.1f Hz\n', aliasingSamplingFrequency);
fprintf('  Sampling period: %.4f s\n', aliasingSamplingPeriod);
fprintf('  Number of samples: %d\n', length(aliasedSampledSignal));

%% Visualisation: Sampling Effects
figure('Position', [100, 100, 1400, 900]);

% Subplot 1: Original continuous signal
subplot(3, 1, 1);
plot(timeReference, continuousSignal, 'b-', 'LineWidth', 1.5);
title('Original Continuous Signal', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Amplitude', 'Interpreter', 'latex');
grid on;
xlim([0, 2]);
ylim([-1.8, 1.8]);

% Subplot 2: Proper sampling
subplot(3, 1, 2);
plot(timeReference, continuousSignal, 'b-', 'LineWidth', 1, ...
    'Color', [0.7, 0.7, 0.7], 'DisplayName', 'Original');
hold on;
stem(properTimeIndices, properSampledSignal, 'ro-', 'LineWidth', 1.5, ...
    'MarkerFaceColor', 'r', 'DisplayName', 'Samples');
title(sprintf('Proper Sampling ($f_s = %.1f$ Hz $> 2*f_{max} = %d$ Hz)', ...
    properSamplingFrequency, 2*harmonicFrequency), 'Interpreter', 'latex', ...
    'FontSize', 12);
ylabel('Amplitude', 'Interpreter', 'latex');
legend('show', 'Interpreter', 'latex', 'Location', 'northeast');
grid on;
xlim([0, 2]);
ylim([-1.8, 1.8]);
hold off;

% Subplot 3: Aliasing demonstration
subplot(3, 1, 3);
plot(timeReference, continuousSignal, 'b-', 'LineWidth', 1, ...
    'Color', [0.7, 0.7, 0.7], 'DisplayName', 'Original');
hold on;
stem(aliasingTimeIndices, aliasedSampledSignal, 'mo-', 'LineWidth', 1.5, ...
    'MarkerFaceColor', 'm', 'DisplayName', 'Aliased Samples');
title(sprintf('Aliasing Effect ($f_s = %.1f$ Hz $< 2*f_{max} = %d$ Hz)', ...
    aliasingSamplingFrequency, 2*harmonicFrequency), 'Interpreter', 'latex', ...
    'FontSize', 12);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
legend('show', 'Interpreter', 'latex', 'Location', 'northeast');
grid on;
xlim([0, 2]);
ylim([-1.8, 1.8]);
hold off;

saveas(gcf, 'sampling_theorem_demonstration.png');

%% Frequency Domain Analysis
% Demonstrate aliasing in frequency domain

% Compute FFT for properly sampled signal
fftProper = fft(properSampledSignal);
frequencyVectorProper = (0:length(fftProper)-1) * ...
    properSamplingFrequency / length(fftProper);
magnitudeProper = abs(fftProper / length(fftProper));

% Compute FFT for aliased signal
fftAliased = fft(aliasedSampledSignal);
frequencyVectorAliased = (0:length(fftAliased)-1) * ...
    aliasingSamplingFrequency / length(fftAliased);
magnitudeAliased = abs(fftAliased / length(fftAliased));

figure('Position', [100, 100, 1400, 500]);

% Proper sampling spectrum
subplot(1, 2, 1);
stem(frequencyVectorProper(1:floor(length(frequencyVectorProper)/2)), ...
    magnitudeProper(1:floor(length(magnitudeProper)/2)), ...
    'r-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'r');
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('Magnitude', 'Interpreter', 'latex');
title('Frequency Spectrum (Proper Sampling)', 'Interpreter', 'latex', ...
    'FontSize', 12);
grid on;
xlim([0, 25]);

% Aliased sampling spectrum
subplot(1, 2, 2);
stem(frequencyVectorAliased(1:floor(length(frequencyVectorAliased)/2)), ...
    magnitudeAliased(1:floor(length(magnitudeAliased)/2)), ...
    'm-o', 'LineWidth', 1.5, 'MarkerFaceColor', 'm');
xlabel('Frequency (Hz)', 'Interpreter', 'latex');
ylabel('Magnitude', 'Interpreter', 'latex');
title('Frequency Spectrum (Aliased Sampling)', 'Interpreter', 'latex', ...
    'FontSize', 12);
grid on;
xlim([0, 25]);

saveas(gcf, 'sampling_frequency_domain.png');

%% Signal Reconstruction Demonstration
% Demonstrate ideal sinc interpolation vs practical methods

% Ideal reconstruction using Whittaker-Shannon interpolation
reconstructedSignal = zeros(size(timeReference));
samplingPeriod = properSamplingPeriod;

fprintf('\nPerforming ideal sinc interpolation...\n');
for sampleIndex = 1:length(properSampledSignal)
    sincFunction = sinc((timeReference - properTimeIndices(sampleIndex)) / ...
        samplingPeriod);
    reconstructedSignal = reconstructedSignal + ...
        properSampledSignal(sampleIndex) * sincFunction;
end

% Practical reconstruction methods for comparison
linearInterpolation = interp1(properTimeIndices, properSampledSignal, ...
    timeReference, 'linear', 'extrap');
splineInterpolation = interp1(properTimeIndices, properSampledSignal, ...
    timeReference, 'spline', 'extrap');

% Compute reconstruction errors
errorIdeal = continuousSignal - reconstructedSignal;
errorLinear = continuousSignal - linearInterpolation;
errorSpline = continuousSignal - splineInterpolation;

fprintf('Reconstruction error (RMS):\n');
fprintf('  Ideal sinc interpolation: %.6f\n', rms(errorIdeal));
fprintf('  Linear interpolation:     %.6f\n', rms(errorLinear));
fprintf('  Spline interpolation:     %.6f\n', rms(errorSpline));

figure('Position', [100, 100, 1400, 900]);

% Reconstruction comparison
subplot(2, 1, 1);
plot(timeReference, continuousSignal, 'b-', 'LineWidth', 2, ...
    'DisplayName', 'Original');
hold on;
plot(timeReference, reconstructedSignal, 'g--', 'LineWidth', 1.5, ...
    'DisplayName', 'Ideal Sinc');
plot(timeReference, linearInterpolation, 'r:', 'LineWidth', 1.5, ...
    'DisplayName', 'Linear');
plot(timeReference, splineInterpolation, 'm-.', 'LineWidth', 1.5, ...
    'DisplayName', 'Spline');
stem(properTimeIndices, properSampledSignal, 'ko', 'LineWidth', 1, ...
    'MarkerFaceColor', 'k', 'MarkerSize', 4, 'DisplayName', 'Samples');
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
title('Signal Reconstruction Methods Comparison', 'Interpreter', 'latex', ...
    'FontSize', 12);
legend('show', 'Interpreter', 'latex', 'Location', 'northeast');
grid on;
xlim([0, 1]);
hold off;

% Reconstruction errors
subplot(2, 1, 2);
plot(timeReference, errorIdeal, 'g-', 'LineWidth', 1.5, ...
    'DisplayName', 'Ideal Sinc Error');
hold on;
plot(timeReference, errorLinear, 'r-', 'LineWidth', 1.5, ...
    'DisplayName', 'Linear Error');
plot(timeReference, errorSpline, 'm-', 'LineWidth', 1.5, ...
    'DisplayName', 'Spline Error');
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Reconstruction Error', 'Interpreter', 'latex');
title('Reconstruction Error Analysis', 'Interpreter', 'latex', 'FontSize', 12);
legend('show', 'Interpreter', 'latex', 'Location', 'best');
grid on;
xlim([0, 1]);
hold off;

saveas(gcf, 'signal_reconstruction_comparison.png');

fprintf('\nSampling theorem demonstration complete.\n');
fprintf('Figures saved: sampling_theorem_demonstration.png, ');
fprintf('sampling_frequency_domain.png, signal_reconstruction_comparison.png\n');
