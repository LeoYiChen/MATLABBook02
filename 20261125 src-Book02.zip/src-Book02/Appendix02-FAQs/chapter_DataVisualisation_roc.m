%% chapter_DataVisualisation_roc.m
% ROC Curve Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_roc
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createROCCurve(true_labels, scores)
% Calculate ROC curve points
[X,Y,T,AUC] = perfcurve(true_labels, scores, 1);

% Create figure
h = figure('Position', [100 100 800 800]);

% Plot ROC curve
plot(X, Y, 'b-', 'LineWidth', 2);
hold on;

% Add diagonal reference line
plot([0 1], [0 1], 'r--');

% Add confidence intervals if available
if exist('perfcurve', 'file')
    [X,Y,T,AUC,OPTROCPT,SUBY,SUBYNAMES] = ...
        perfcurve(true_labels, scores, 1, 'NBoot', 1000);
    % Plot confidence intervals
    patch([X; flipud(X)], [SUBY(:,1); flipud(SUBY(:,2))], ...
          'b', 'FaceAlpha', 0.2, 'EdgeColor', 'none');
end

% Customize appearance
grid on;
xlabel('False Positive Rate');
ylabel('True Positive Rate');
title(sprintf('ROC Curve (AUC = %.3f)', AUC));
legend('ROC', 'Random Classifier', 'CI (95%)', ...
       'Location', 'southeast');

% Export figure
exportFigure(h, 'roc_curve');

end
