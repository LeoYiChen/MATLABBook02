%% chapter_Math_lab9_dynamics.m
% Two-Link Manipulator Dynamics
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab9_dynamics
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Core dynamics function

% Helper functions



% Visualisation functions




% Execute laboratory
Lab9_ManipulatorSimulation();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab9_ManipulatorSimulation()
    % LAB9_MANIPULATORSIMULATION Simulate two-link planar manipulator
    %   Comprehensive analysis including dynamics, phase portraits, and events
    
    fprintf('\\textbf{Laboratory 9: Robotic Manipulator Simulation}\n');
    fprintf('====================================================\n\n');
    
    % Define manipulator parameters
    params = struct();
    params.m1 = 1.0;      % Link 1 mass (kg)
    params.m2 = 0.8;      % Link 2 mass (kg)
    params.l1 = 0.5;      % Link 1 length (m)
    params.l2 = 0.4;      % Link 2 length (m)
    params.g = 9.81;      % Gravitational acceleration (m/s^2)
    params.damping = 0.1; % Damping coefficient
    
    fprintf('Manipulator Parameters:\n');
    fprintf('  Link 1: m=%.2f kg, l=%.2f m\n', params.m1, params.l1);
    fprintf('  Link 2: m=%.2f kg, l=%.2f m\n', params.m2, params.l2);
    fprintf('  Gravity: g=%.2f m/s^2\n', params.g);
    fprintf('  Damping: c=%.2f\n\n', params.damping);
    
    % Simulation 1: Free motion (no control input)
    simulateFreeMotion(params);
    
    % Simulation 2: Controlled motion with different torque inputs
    simulateControlledMotion(params);
    
    % Simulation 3: Phase portrait analysis
    analysePhasePortrait(params);
    
    % Simulation 4: Stability analysis at equilibrium
    analyseStability(params);
    
    % Simulation 5: Event detection for collision avoidance
    simulateWithCollisionDetection(params);
end

function simulateFreeMotion(params)
    % SIMULATEFREEMOTION Simulate manipulator with no applied torques
    
    fprintf('\\textbf{Simulation 1: Free Motion (No Control)}\n');
    fprintf('--------\n');
    
    % Initial conditions: [theta1, theta2, omega1, omega2]
    % Start with both links at 45 degrees, zero velocity
    theta1_0 = pi/4;
    theta2_0 = pi/4;
    omega1_0 = 0;
    omega2_0 = 0;
    
    y0 = [theta1_0; theta2_0; omega1_0; omega2_0];
    
    fprintf('Initial conditions:\n');
    fprintf('  theta1 = %.2f rad (%.1f deg)\n', theta1_0, rad2deg(theta1_0));
    fprintf('  theta2 = %.2f rad (%.1f deg)\n', theta2_0, rad2deg(theta2_0));
    fprintf('  omega1 = %.2f rad/s\n', omega1_0);
    fprintf('  omega2 = %.2f rad/s\n\n', omega2_0);
    
    % Time span
    tspan = [0, 5];  % 5 seconds
    
    % Control input function (zero torque)
    control_func = @(t) [0; 0];
    
    % ODE function handle
    ode_func = @(t, y) manipulatorDynamics(t, y, params, control_func);
    
    % Solve using ODE45
    fprintf('Solving with ODE45 (Dormand-Prince)...\n');
    options = odeset('RelTol', 1e-6, 'AbsTol', 1e-8);
    tic;
    [t, y] = ode45(ode_func, tspan, y0, options);
    time_ode45 = toc;
    fprintf('  Computation time: %.4f seconds\n', time_ode45);
    fprintf('  Number of time steps: %d\n', length(t));
    fprintf('  Average step size: %.6f seconds\n\n', mean(diff(t)));
    
    % Extract joint angles and velocities
    theta1 = y(:, 1);
    theta2 = y(:, 2);
    omega1 = y(:, 3);
    omega2 = y(:, 4);
    
    % Calculate total energy (should be conserved without damping)
    energy = zeros(length(t), 1);
    for i = 1:length(t)
        energy(i) = calculateEnergy(y(i, :), params);
    end
    
    energy_change = (energy(end) - energy(1)) / energy(1) * 100;
    fprintf('Energy Analysis:\n');
    fprintf('  Initial energy: %.6f J\n', energy(1));
    fprintf('  Final energy: %.6f J\n', energy(end));
    fprintf('  Relative change: %.4f%%\n\n', energy_change);
    
    % Visualise results
    visualiseManipulatorMotion(t, y, energy, params, 'Free Motion');
    
    % Create animation
    animateManipulator(t, y, params, 'Free Motion Animation');
end

function simulateControlledMotion(params)
    % SIMULATECONTROLLEDMOTION Test different control strategies
    
    fprintf('\\textbf{Simulation 2: Controlled Motion}\n');
    fprintf('-------\n');
    
    % Initial conditions: hanging down position
    y0 = [pi; 0; 0; 0];
    
    % Time span
    tspan = [0, 5];
    
    % Test three control strategies
    control_strategies = {...
        struct('name', 'Constant Torque', 'func', @(t) [0.5; 0.2]), ...
        struct('name', 'Sinusoidal Torque', 'func', @(t) [sin(2*pi*t); 0.5*sin(2*pi*t)]), ...
        struct('name', 'PD Control to Target', 'func', @(t) pdControl(t, params))...
    };
    
    results = cell(length(control_strategies), 1);
    
    for i = 1:length(control_strategies)
        strategy = control_strategies{i};
        fprintf('Testing: %s\n', strategy.name);
        
        ode_func = @(t, y) manipulatorDynamics(t, y, params, strategy.func);
        options = odeset('RelTol', 1e-6, 'AbsTol', 1e-8);
        
        tic;
        [t, y] = ode45(ode_func, tspan, y0, options);
        comp_time = toc;
        
        fprintf('  Computation time: %.4f seconds\n', comp_time);
        fprintf('  Final angles: theta1=%.2f rad, theta2=%.2f rad\n\n', ...
            y(end, 1), y(end, 2));
        
        results{i} = struct('t', t, 'y', y, 'name', strategy.name);
    end
    
    % Compare control strategies
    compareControlStrategies(results, params);
end

function tau = pdControl(t, params)
    % PDCONTROL Simple PD controller to reach target position
    %   Target: both joints at 0 (straight up)
    
    persistent theta_target omega_target;
    
    if isempty(theta_target)
        theta_target = [0; 0];  % Target angles
        omega_target = [0; 0];  % Target velocities
    end
    
    % PD gains (tuned for this system)
    Kp = [10; 8];   % Proportional gains
    Kd = [2; 1.5];  % Derivative gains
    
    % This is a simplified controller - in real implementation,
    % we'd need access to current state, which isn't available here
    % For demonstration, we'll use time-based decay
    tau = Kp .* exp(-t) .* [1; 0.5];
end

function analysePhasePortrait(params)
    % ANALYSEPHASEPORTRAIT Generate phase portraits for single joint
    
    fprintf('\\textbf{Simulation 3: Phase Portrait Analysis}\n');
    fprintf('---------\n');
    
    % Simplified single-joint system for phase portrait
    % (Two-joint system would require 4*D phase space)
    
    fprintf('Analysing single-joint dynamics (Link 1, Link 2 locked)...\n\n');
    
    % Effective parameters for single joint
    m_eff = params.m1 + params.m2;
    l_eff = params.l1;
    
    % ODE for single pendulum: theta'' + (g/l)*sin(theta) + c*theta' = 0
    single_joint_ode = @(t, y) [
        y(2);
        -(params.g/l_eff)*sin(y(1)) - params.damping*y(2)
    ];
    
    % Generate phase portrait with multiple initial conditions
    theta_range = linspace(-pi, pi, 10);
    omega_range = linspace(-3, 3, 10);
    
    figure('Position', [100, 100, 1200, 500], 'Name', 'Phase Portrait Analysis');
    
    % Subplot 1: Phase portrait
    subplot(1, 2, 1);
    hold on;
    
    for theta0 = theta_range
        for omega0 = omega_range
            y0 = [theta0; omega0];
            [t, y] = ode45(single_joint_ode, [0, 10], y0);
            plot(y(:, 1), y(:, 2), 'b-', 'LineWidth', 0.5);
        end
    end
    
    % Mark equilibrium points
    plot(0, 0, 'go', 'MarkerSize', 12, 'MarkerFaceColor', 'g', ...
        'DisplayName', 'Stable (down)');
    plot(pi, 0, 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r', ...
        'DisplayName', 'Unstable (up)');
    plot(-pi, 0, 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r', ...
        'HandleVisibility', 'off');
    
    xlabel('$\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Phase Portrait: Single Joint Pendulum', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    axis equal;
    xlim([-pi, pi]);
    ylim([-3, 3]);
    
    % Subplot 2: Vector field
    subplot(1, 2, 2);
    [Theta, Omega] = meshgrid(linspace(-pi, pi, 20), linspace(-3, 3, 20));
    dTheta = Omega;
    dOmega = -(params.g/l_eff)*sin(Theta) - params.damping*Omega;
    
    quiver(Theta, Omega, dTheta, dOmega, 'b');
    hold on;
    
    % Overlay some trajectories
    for i = 1:5
        theta0 = -pi + 2*pi*rand();
        omega0 = -3 + 6*rand();
        y0 = [theta0; omega0];
        [t, y] = ode45(single_joint_ode, [0, 10], y0);
        plot(y(:, 1), y(:, 2), 'r-', 'LineWidth', 1.5);
    end
    
    xlabel('$\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Vector Field and Sample Trajectories', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    axis equal;
    xlim([-pi, pi]);
    ylim([-3, 3]);
    
    fprintf('Phase portrait generated.\n');
    fprintf('Observations:\n');
    fprintf('  - Stable equilibrium at (0, 0): hanging down\n');
    fprintf('  - Unstable equilibrium at (±π, 0): inverted position\n');
    fprintf('  - Damping causes spiraling into stable equilibrium\n\n');
end

function analyseStability(params)
    % ANALYSESTABILITY Linearise around equilibrium and compute eigenvalues
    
    fprintf('\\textbf{Simulation 4: Stability Analysis}\n');
    fprintf('-------\n');
    
    % Equilibrium: hanging down position
    theta_eq = [pi; 0];  % Both links pointing down
    omega_eq = [0; 0];
    
    fprintf('Equilibrium point: theta1=%.2f, theta2=%.2f, omega1=%.2f, omega2=%.2f\n', ...
        theta_eq(1), theta_eq(2), omega_eq(1), omega_eq(2));
    
    % Linearise system around equilibrium
    % State vector: x = [theta1, theta2, omega1, omega2]
    % Dynamics: dx/dt = f(x)
    
    % Compute Jacobian numerically
    y_eq = [theta_eq; omega_eq];
    J = computeJacobian(y_eq, params);
    
    fprintf('\nJacobian matrix at equilibrium:\n');
    disp(J);
    
    % Compute eigenvalues
    eigenvalues = eig(J);
    
    fprintf('Eigenvalues:\n');
    for i = 1:length(eigenvalues)
        if isreal(eigenvalues(i))
            fprintf('  λ%d = %.6f\n', i, eigenvalues(i));
        else
            fprintf('  λ%d = %.6f %+.6fi\n', i, real(eigenvalues(i)), imag(eigenvalues(i)));
        end
    end
    
    % Stability assessment
    max_real_part = max(real(eigenvalues));
    
    fprintf('\nStability Assessment:\n');
    fprintf('  Maximum real part: %.6f\n', max_real_part);
    
    if max_real_part < 0
        fprintf('  Result: STABLE (all eigenvalues have negative real parts)\n');
    elseif max_real_part == 0
        fprintf('  Result: MARGINALLY STABLE\n');
    else
        fprintf('  Result: UNSTABLE (at least one eigenvalue has positive real part)\n');
    end
    
    fprintf('\n');
end

function J = computeJacobian(y0, params)
    % COMPUTEJACOBIAN Numerical Jacobian computation
    %   Uses finite differences
    
    n = length(y0);
    J = zeros(n, n);
    epsilon = 1e-7;
    
    % No control input for stability analysis
    control_func = @(t) [0; 0];
    
    % Reference function evaluation
    f0 = manipulatorDynamics(0, y0, params, control_func);
    
    % Compute each column of Jacobian
    for i = 1:n
        y_perturbed = y0;
        y_perturbed(i) = y_perturbed(i) + epsilon;
        
        f_perturbed = manipulatorDynamics(0, y_perturbed, params, control_func);
        
        J(:, i) = (f_perturbed - f0) / epsilon;
    end
end

function simulateWithCollisionDetection(params)
    % SIMULATEWITHCOLLISIONDETECTION Use event detection for obstacles
    
    fprintf('\\textbf{Simulation 5: Event Detection (Collision Avoidance)}\n');
    fprintf('-----------\n');
    
    % Define obstacle position
    obstacle_x = 0.3;
    obstacle_y = 0.2;
    obstacle_radius = 0.05;
    
    fprintf('Obstacle at (%.2f, %.2f) with radius %.2f m\n\n', ...
        obstacle_x, obstacle_y, obstacle_radius);
    
    % Initial conditions: motion that will intersect obstacle
    y0 = [pi/6; pi/4; 1.0; 0.5];
    
    % Control function
    control_func = @(t) [0.2*sin(t); 0.1*sin(2*t)];
    
    % ODE function
    ode_func = @(t, y) manipulatorDynamics(t, y, params, control_func);
    
    % Event function for collision detection
    event_func = @(t, y) collisionEvent(t, y, params, obstacle_x, ...
        obstacle_y, obstacle_radius);
    
    % Options with event detection
    options = odeset('RelTol', 1e-6, 'AbsTol', 1e-8, ...
        'Events', event_func);
    
    % Solve
    tspan = [0, 10];
    fprintf('Simulating with event detection...\n');
    [t, y, te, ye, ie] = ode45(ode_func, tspan, y0, options);
    
    if isempty(te)
        fprintf('  No collision detected.\n\n');
    else
        fprintf('  Collision detected at t=%.4f seconds!\n', te(1));
        fprintf('  End-effector position at collision:\n');
        
        [x_ee, y_ee] = forwardKinematics(ye(1, 1), ye(1, 2), params);
        fprintf('    x = %.4f m, y = %.4f m\n', x_ee, y_ee);
        
        distance = sqrt((x_ee - obstacle_x)^2 + (y_ee - obstacle_y)^2);
        fprintf('  Distance to obstacle center: %.4f m\n\n', distance);
    end
    
    % Visualise trajectory with obstacle
    visualiseWithObstacle(t, y, params, obstacle_x, obstacle_y, ...
        obstacle_radius, te, ye);
end

function dydt = manipulatorDynamics(t, y, params, control_func)
    % MANIPULATORDYNAMICS Equations of motion for two-link manipulator
    %   State: y = [theta1, theta2, omega1, omega2]
    %   Returns: dydt = [omega1, omega2, alpha1, alpha2]
    
    % Extract state variables
    theta1 = y(1);
    theta2 = y(2);
    omega1 = y(3);
    omega2 = y(4);
    
    % Parameters
    m1 = params.m1;
    m2 = params.m2;
    l1 = params.l1;
    l2 = params.l2;
    g = params.g;
    c = params.damping;
    
    % Control torques
    tau = control_func(t);
    tau1 = tau(1);
    tau2 = tau(2);
    
    % Mass matrix elements
    M11 = (m1 + m2)*l1^2 + m2*l2^2 + 2*m2*l1*l2*cos(theta2);
    M12 = m2*l2^2 + m2*l1*l2*cos(theta2);
    M21 = M12;
    M22 = m2*l2^2;
    
    % Mass matrix
    M = [M11, M12; M21, M22];
    
    % Coriolis and centrifugal terms
    C1 = -m2*l1*l2*sin(theta2)*(2*omega1*omega2 + omega2^2);
    C2 = m2*l1*l2*sin(theta2)*omega1^2;
    
    % Gravity terms
    G1 = (m1 + m2)*g*l1*cos(theta1) + m2*g*l2*cos(theta1 + theta2);
    G2 = m2*g*l2*cos(theta1 + theta2);
    
    % Damping terms
    D1 = c*omega1;
    D2 = c*omega2;
    
    % Right-hand side vector
    RHS = [tau1 - C1 - G1 - D1;
           tau2 - C2 - G2 - D2];
    
    % Solve for angular accelerations
    alpha = M \ RHS;
    
    % Return state derivatives
    dydt = [omega1; omega2; alpha(1); alpha(2)];
end

function E = calculateEnergy(y, params)
    % CALCULATEENERGY Total mechanical energy
    
    theta1 = y(1);
    theta2 = y(2);
    omega1 = y(3);
    omega2 = y(4);
    
    m1 = params.m1;
    m2 = params.m2;
    l1 = params.l1;
    l2 = params.l2;
    g = params.g;
    
    % Kinetic energy
    T = 0.5*(m1 + m2)*l1^2*omega1^2 + ...
        0.5*m2*l2^2*omega2^2 + ...
        m2*l1*l2*omega1*omega2*cos(theta2);
    
    % Potential energy (reference at hanging down position)
    V = -(m1 + m2)*g*l1*cos(theta1) - m2*g*l2*cos(theta1 + theta2);
    
    E = T + V;
end

function [x, y] = forwardKinematics(theta1, theta2, params)
    % FORWARDKINEMATICS Compute end-effector position
    
    l1 = params.l1;
    l2 = params.l2;
    
    x = l1*sin(theta1) + l2*sin(theta1 + theta2);
    y = -l1*cos(theta1) - l2*cos(theta1 + theta2);
end

function [value, isterminal, direction] = collisionEvent(t, y, params, ...
    obs_x, obs_y, obs_r)
    % COLLISIONEVENT Event function for collision detection
    %   value = 0 when end-effector touches obstacle
    
    [x_ee, y_ee] = forwardKinematics(y(1), y(2), params);
    
    % Distance from end-effector to obstacle center
    distance = sqrt((x_ee - obs_x)^2 + (y_ee - obs_y)^2);
    
    % Event occurs when distance equals obstacle radius
    value = distance - obs_r;
    
    isterminal = 1;  % Stop integration
    direction = -1;  % Detect decreasing (approaching)
end

function visualiseManipulatorMotion(t, y, energy, params, titleStr)
    % VISUALISEMANIPULATORMOTION Plot joint angles, velocities, and energy
    
    figure('Position', [150, 150, 1400, 500], 'Name', titleStr);
    
    % Joint angles
    subplot(2, 3, 1);
    plot(t, rad2deg(y(:, 1)), 'b-', 'LineWidth', 2, 'DisplayName', '$\theta_1$');
    hold on;
    plot(t, rad2deg(y(:, 2)), 'r-', 'LineWidth', 2, 'DisplayName', '$\theta_2$');
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Angle (deg)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Joint Angles', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Joint velocities
    subplot(2, 3, 2);
    plot(t, y(:, 3), 'b-', 'LineWidth', 2, 'DisplayName', '$\omega_1$');
    hold on;
    plot(t, y(:, 4), 'r-', 'LineWidth', 2, 'DisplayName', '$\omega_2$');
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Angular Velocity (rad/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Joint Velocities', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Energy
    subplot(2, 3, 3);
    plot(t, energy, 'k-', 'LineWidth', 2);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Total Energy (J)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Mechanical Energy', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Phase portrait: Joint 1
    subplot(2, 3, 4);
    plot(y(:, 1), y(:, 3), 'b-', 'LineWidth', 1.5);
    xlabel('$\theta_1$ (rad)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\omega_1$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Phase Portrait: Joint 1', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Phase portrait: Joint 2
    subplot(2, 3, 5);
    plot(y(:, 2), y(:, 4), 'r-', 'LineWidth', 1.5);
    xlabel('$\theta_2$ (rad)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\omega_2$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Phase Portrait: Joint 2', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % End-effector trajectory
    subplot(2, 3, 6);
    x_ee = zeros(length(t), 1);
    y_ee = zeros(length(t), 1);
    
    for i = 1:length(t)
        [x_ee(i), y_ee(i)] = forwardKinematics(y(i, 1), y(i, 2), params);
    end
    
    plot(x_ee, y_ee, 'g-', 'LineWidth', 2);
    hold on;
    plot(x_ee(1), y_ee(1), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    plot(x_ee(end), y_ee(end), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    xlabel('x (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('y (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('End-Effector Trajectory', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Trajectory', 'Start', 'End', 'Interpreter', 'latex', 'Location', 'best');
    grid on;
    axis equal;
end

function animateManipulator(t, y, params, titleStr)
    % ANIMATEMANIPULATOR Create animation of manipulator motion
    
    figure('Position', [200, 200, 800, 600], 'Name', titleStr);
    
    l1 = params.l1;
    l2 = params.l2;
    
    % Downsample for smoother animation
    skip = max(1, floor(length(t) / 100));
    t_anim = t(1:skip:end);
    y_anim = y(1:skip:end, :);
    
    for i = 1:length(t_anim)
        clf;
        
        theta1 = y_anim(i, 1);
        theta2 = y_anim(i, 2);
        
        % Joint positions
        x0 = 0;
        y0 = 0;
        x1 = l1*sin(theta1);
        y1 = -l1*cos(theta1);
        x2 = x1 + l2*sin(theta1 + theta2);
        y2 = y1 - l2*cos(theta1 + theta2);
        
        % Plot links
        plot([x0, x1], [y0, y1], 'b-', 'LineWidth', 6);
        hold on;
        plot([x1, x2], [y1, y2], 'r-', 'LineWidth', 6);
        
        % Plot joints
        plot(x0, y0, 'ko', 'MarkerSize', 12, 'MarkerFaceColor', 'k');
        plot(x1, y1, 'go', 'MarkerSize', 12, 'MarkerFaceColor', 'g');
        plot(x2, y2, 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
        
        % Trace end-effector
        if i > 1
            x_trace = zeros(i, 1);
            y_trace = zeros(i, 1);
            for j = 1:i
                [x_trace(j), y_trace(j)] = forwardKinematics(...
                    y_anim(j, 1), y_anim(j, 2), params);
            end
            plot(x_trace, y_trace, 'm-', 'LineWidth', 1);
        end
        
        xlabel('x (m)', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('y (m)', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('Time: %.2f s', t_anim(i)), 'Interpreter', 'latex', 'FontSize', 14);
        grid on;
        axis equal;
        xlim([-1, 1]);
        ylim([-1, 0.5]);
        
        drawnow;
        pause(0.01);
    end
end

function compareControlStrategies(results, params)
    % COMPARECONTROLSTRATEGIES Visualise different control approaches
    
    figure('Position', [250, 250, 1400, 500], 'Name', 'Control Strategy Comparison');
    
    colors = {'b', 'r', 'g'};
    
    % Joint 1 angles
    subplot(1, 3, 1);
    hold on;
    for i = 1:length(results)
        plot(results{i}.t, rad2deg(results{i}.y(:, 1)), ...
            [colors{i}, '-'], 'LineWidth', 2, 'DisplayName', results{i}.name);
    end
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\theta_1$ (deg)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Joint 1 Angle', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Joint 2 angles
    subplot(1, 3, 2);
    hold on;
    for i = 1:length(results)
        plot(results{i}.t, rad2deg(results{i}.y(:, 2)), ...
            [colors{i}, '-'], 'LineWidth', 2, 'DisplayName', results{i}.name);
    end
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\theta_2$ (deg)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Joint 2 Angle', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % End-effector trajectories
    subplot(1, 3, 3);
    hold on;
    for i = 1:length(results)
        x_ee = zeros(length(results{i}.t), 1);
        y_ee = zeros(length(results{i}.t), 1);
        
        for j = 1:length(results{i}.t)
            [x_ee(j), y_ee(j)] = forwardKinematics(...
                results{i}.y(j, 1), results{i}.y(j, 2), params);
        end
        
        plot(x_ee, y_ee, [colors{i}, '-'], 'LineWidth', 2, ...
            'DisplayName', results{i}.name);
    end
    xlabel('x (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('y (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('End-Effector Trajectories', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    axis equal;
end

function visualiseWithObstacle(t, y, params, obs_x, obs_y, obs_r, te, ye)
    % VISUALISEWITHOBSTACLE Plot trajectory with obstacle
    
    figure('Position', [300, 300, 800, 600], 'Name', 'Collision Detection');
    
    % Compute end-effector trajectory
    x_ee = zeros(length(t), 1);
    y_ee = zeros(length(t), 1);
    
    for i = 1:length(t)
        [x_ee(i), y_ee(i)] = forwardKinematics(y(i, 1), y(i, 2), params);
    end
    
    % Plot trajectory
    plot(x_ee, y_ee, 'b-', 'LineWidth', 2, 'DisplayName', 'Trajectory');
    hold on;
    
    % Plot obstacle
    theta_circle = linspace(0, 2*pi, 100);
    x_circle = obs_x + obs_r*cos(theta_circle);
    y_circle = obs_y + obs_r*sin(theta_circle);
    fill(x_circle, y_circle, 'r', 'FaceAlpha', 0.3, 'DisplayName', 'Obstacle');
    
    % Mark collision point if detected
    if ~isempty(te)
        [x_collision, y_collision] = forwardKinematics(ye(1), ye(2), params);
        plot(x_collision, y_collision, 'rx', 'MarkerSize', 20, ...
            'LineWidth', 3, 'DisplayName', 'Collision Point');
    end
    
    % Mark start and end
    plot(x_ee(1), y_ee(1), 'go', 'MarkerSize', 12, 'MarkerFaceColor', 'g', ...
        'DisplayName', 'Start');
    plot(x_ee(end), y_ee(end), 'ko', 'MarkerSize', 12, 'MarkerFaceColor', 'k', ...
        'DisplayName', 'End');
    
    xlabel('x (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('y (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('End-Effector Trajectory with Obstacle', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    axis equal;
end
