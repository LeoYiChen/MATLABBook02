%% lst_conditional_filter.m
% Conditional Filtering via Nested Control Structures
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : lst:conditional_filter
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
result = [];
for i = 1:length(x)
    if x(i) > 3
        result = [result, x(i)];
    end
end
