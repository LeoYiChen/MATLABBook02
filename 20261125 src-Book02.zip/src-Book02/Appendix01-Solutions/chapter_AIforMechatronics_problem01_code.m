%% chapter_AIforMechatronics_problem01_code.m
% Custom CNN architecture for defect classification.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem01_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 1: CNN Architecture Design for Surface Defect Classification
% Author: Dr Yi Chen
% Purpose: Design and evaluate custom CNN architectures for defect detection
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox, Statistics and Machine Learning
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Generate synthetic defect dataset
fprintf('=== CNN Architecture Design for Defect Classification ===\n\n');
fprintf('Step 1: Generating synthetic defect dataset...\n');

% Dataset parameters
imageSize = [64, 64, 1]; % Grayscale images
numClasses = 5;
classNames = {'Scratch', 'Dent', 'Corrosion', 'Crack', 'NoDefect'};
samplesPerClass = 200;

% Generate synthetic images for each defect type
allImages = [];
allLabels = [];

for classIdx = 1:numClasses
    for sampleIdx = 1:samplesPerClass
        % Create base image with random texture
        baseImage = 0.5 + 0.1 * randn(imageSize(1), imageSize(2));
        
        switch classIdx
            case 1 % Scratch - linear features
                numScratches = randi([1, 3]);
                for scratchNum = 1:numScratches
                    startX = randi([1, imageSize(2)]);
                    startY = randi([1, imageSize(1)]);
                    angle = rand() * pi;
                    length = randi([10, 30]);
                    endX = round(startX + length * cos(angle));
                    endY = round(startY + length * sin(angle));
                    baseImage = insertShape(baseImage, 'Line', ...
                        [startX, startY, endX, endY], ...
                        'Color', 'white', 'LineWidth', 2);
                end
                
            case 2 % Dent - circular depression
                numDents = randi([1, 2]);
                for dentNum = 1:numDents
                    centreX = randi([10, imageSize(2)-10]);
                    centreY = randi([10, imageSize(1)-10]);
                    radius = randi([5, 12]);
                    [X, Y] = meshgrid(1:imageSize(2), 1:imageSize(1));
                    dentMask = ((X - centreX).^2 + (Y - centreY).^2) <= radius^2;
                    baseImage(dentMask) = baseImage(dentMask) - 0.3;
                end
                
            case 3 % Corrosion - speckled texture
                noiseDensity = 0.3;
                corrosionMask = rand(imageSize(1), imageSize(2)) < noiseDensity;
                baseImage(corrosionMask) = baseImage(corrosionMask) + ...
                    0.2 * randn(sum(corrosionMask(:)), 1);
                
            case 4 % Crack - branching structure
                numCracks = randi([1, 2]);
                for crackNum = 1:numCracks
                    startX = randi([10, imageSize(2)-10]);
                    startY = randi([1, imageSize(1)]);
                    crackPath = [startX, startY];
                    for step = 1:randi([15, 25])
                        angle = randn() * 0.5;
                        stepSize = 2;
                        newX = crackPath(end, 1) + stepSize * cos(angle);
                        newY = crackPath(end, 2) + stepSize * sin(angle);
                        crackPath = [crackPath; newX, newY];
                    end
                    for pathIdx = 1:size(crackPath, 1)-1
                        baseImage = insertShape(baseImage, 'Line', ...
                            [crackPath(pathIdx, :), crackPath(pathIdx+1, :)], ...
                            'Color', 'black', 'LineWidth', 1);
                    end
                end
                
            case 5 % No defect - clean surface
                % Keep base texture only
        end
        
        % Convert to grayscale and normalise
        if size(baseImage, 3) == 3
            baseImage = rgb2gray(baseImage);
        end
        baseImage = mat2gray(baseImage);
        
        % Store image and label
        allImages = cat(4, allImages, baseImage);
        allLabels = [allLabels; classIdx];
    end
end

% Convert labels to categorical
allLabels = categorical(allLabels, 1:numClasses, classNames);

fprintf('  Total images generated: %d\n', size(allImages, 4));
fprintf('  Image size: %d x %d x %d\n', imageSize);
fprintf('  Number of classes: %d\n', numClasses);

%% Step 2: Split dataset
fprintf('\nStep 2: Splitting dataset...\n');

% Split indices
numSamples = size(allImages, 4);
trainRatio = 0.70;
valRatio = 0.15;
testRatio = 0.15;

% Stratified random split
[trainIdx, valIdx, testIdx] = dividerand(numSamples, ...
    trainRatio, valRatio, testRatio);

% Create data stores
trainImages = allImages(:, :, :, trainIdx);
trainLabels = allLabels(trainIdx);
valImages = allImages(:, :, :, valIdx);
valLabels = allLabels(valIdx);
testImages = allImages(:, :, :, testIdx);
testLabels = allLabels(testIdx);

fprintf('  Training samples: %d\n', length(trainIdx));
fprintf('  Validation samples: %d\n', length(valIdx));
fprintf('  Testing samples: %d\n', length(testIdx));

%% Step 3: Define custom CNN architectures
fprintf('\nStep 3: Defining CNN architectures...\n');

% Architecture 1: Shallow network (3 conv layers)
layersShallow = [
    imageInputLayer(imageSize, 'Name', 'input', 'Normalization', 'none')
    
    convolution2dLayer(5, 16, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
    
    fullyConnectedLayer(128, 'Name', 'fc1')
    reluLayer('Name', 'relu_fc1')
    dropoutLayer(0.5, 'Name', 'dropout1')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc2')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

fprintf('  Shallow network: 3 convolutional layers\n');

% Architecture 2: Medium network (5 conv layers)
layersMedium = [
    imageInputLayer(imageSize, 'Name', 'input', 'Normalization', 'none')
    
    convolution2dLayer(5, 16, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')
    
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    
    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv4')
    batchNormalizationLayer('Name', 'bn4')
    reluLayer('Name', 'relu4')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool4')
    
    convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv5')
    batchNormalizationLayer('Name', 'bn5')
    reluLayer('Name', 'relu5')
    globalAveragePooling2dLayer('Name', 'gap')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

fprintf('  Medium network: 5 convolutional layers\n');

%% Step 4: Configure training options
fprintf('\nStep 4: Configuring training options...\n');

trainingOptions = trainingOptions('adam', ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 10, ...
    'MaxEpochs', 30, ...
    'MiniBatchSize', 32, ...
    'ValidationData', {valImages, valLabels}, ...
    'ValidationFrequency', 30, ...
    'Verbose', false, ...
    'Plots', 'none', ...
    'ExecutionEnvironment', 'auto');

fprintf('  Optimiser: Adam\n');
fprintf('  Initial learning rate: %.4f\n', 0.001);
fprintf('  Maximum epochs: %d\n', 30);
fprintf('  Mini-batch size: %d\n', 32);

%% Step 5: Train shallow network
fprintf('\nStep 5: Training shallow network...\n');

tic;
networkShallow = trainNetwork(trainImages, trainLabels, ...
    layersShallow, trainingOptions);
trainingTimeShallow = toc;

fprintf('  Training completed in %.2f seconds\n', trainingTimeShallow);

%% Step 6: Train medium network
fprintf('\nStep 6: Training medium network...\n');

tic;
networkMedium = trainNetwork(trainImages, trainLabels, ...
    layersMedium, trainingOptions);
trainingTimeMedium = toc;

fprintf('  Training completed in %.2f seconds\n', trainingTimeMedium);

%% Step 7: Evaluate networks
fprintf('\nStep 7: Evaluating network performance...\n');

% Evaluate shallow network
predictedLabelsShallow = classify(networkShallow, testImages);
accuracyShallow = sum(predictedLabelsShallow == testLabels) / ...
    numel(testLabels);
confMatShallow = confusionmat(testLabels, predictedLabelsShallow);

% Evaluate medium network
predictedLabelsMedium = classify(networkMedium, testImages);
accuracyMedium = sum(predictedLabelsMedium == testLabels) / ...
    numel(testLabels);
confMatMedium = confusionmat(testLabels, predictedLabelsMedium);

% Compute per-class metrics for medium network
precisionMedium = zeros(numClasses, 1);
recallMedium = zeros(numClasses, 1);
f1ScoreMedium = zeros(numClasses, 1);

for classIdx = 1:numClasses
    truePositive = confMatMedium(classIdx, classIdx);
    falsePositive = sum(confMatMedium(:, classIdx)) - truePositive;
    falseNegative = sum(confMatMedium(classIdx, :)) - truePositive;
    
    precisionMedium(classIdx) = truePositive / (truePositive + falsePositive);
    recallMedium(classIdx) = truePositive / (truePositive + falseNegative);
    f1ScoreMedium(classIdx) = 2 * precisionMedium(classIdx) * ...
        recallMedium(classIdx) / (precisionMedium(classIdx) + ...
        recallMedium(classIdx));
end

fprintf('\n  Shallow Network Performance:\n');
fprintf('    Test accuracy: %.2f%%\n', accuracyShallow * 100);

fprintf('\n  Medium Network Performance:\n');
fprintf('    Test accuracy: %.2f%%\n', accuracyMedium * 100);
fprintf('    Mean precision: %.2f%%\n', mean(precisionMedium) * 100);
fprintf('    Mean recall: %.2f%%\n', mean(recallMedium) * 100);
fprintf('    Mean F1-score: %.2f%%\n', mean(f1ScoreMedium) * 100);

%% Step 8: Compute model complexity
fprintf('\nStep 8: Analysing model complexity...\n');

% Count parameters (simplified approach)
paramsShallow = 0;
for layerIdx = 1:length(layersShallow)
    layer = layersShallow(layerIdx);
    if isa(layer, 'nnet.cnn.layer.Convolution2DLayer')
        paramsShallow = paramsShallow + ...
            prod(layer.FilterSize) * layer.NumChannels * layer.NumFilters;
    elseif isa(layer, 'nnet.cnn.layer.FullyConnectedLayer')
        paramsShallow = paramsShallow + layer.OutputSize * layer.InputSize;
    end
end

paramsMedium = 0;
for layerIdx = 1:length(layersMedium)
    layer = layersMedium(layerIdx);
    if isa(layer, 'nnet.cnn.layer.Convolution2DLayer')
        paramsMedium = paramsMedium + ...
            prod(layer.FilterSize) * layer.NumChannels * layer.NumFilters;
    elseif isa(layer, 'nnet.cnn.layer.FullyConnectedLayer')
        paramsMedium = paramsMedium + layer.OutputSize * layer.InputSize;
    end
end

fprintf('  Shallow network parameters: %d\n', paramsShallow);
fprintf('  Medium network parameters: %d\n', paramsMedium);

%% Step 9: Visualisation
fprintf('\nStep 9: Generating visualisations...\n');

% Plot confusion matrices
figure('Name', 'CNN Performance Analysis', ...
    'Position', [100, 100, 1200, 500]);

subplot(1, 2, 1);
confusionchart(confMatShallow, classNames);
title('Shallow Network Confusion Matrix', ...
    'Interpreter', 'latex', 'FontSize', 12);

subplot(1, 2, 2);
confusionchart(confMatMedium, classNames);
title('Medium Network Confusion Matrix', ...
    'Interpreter', 'latex', 'FontSize', 12);

suptitle('Defect Classification Performance Comparison', ...
    'Interpreter', 'latex', 'FontSize', 14);

% Plot per-class performance
figure('Name', 'Per-Class Performance Metrics', ...
    'Position', [100, 100, 800, 600]);
xPositions = 1:numClasses;
barWidth = 0.25;

hold on;
bar(xPositions - barWidth, precisionMedium, barWidth, ...
    'FaceColor', [0.2, 0.6, 0.8], 'DisplayName', 'Precision');
bar(xPositions, recallMedium, barWidth, ...
    'FaceColor', [0.8, 0.4, 0.2], 'DisplayName', 'Recall');
bar(xPositions + barWidth, f1ScoreMedium, barWidth, ...
    'FaceColor', [0.4, 0.8, 0.4], 'DisplayName', 'F1-Score');

set(gca, 'XTick', xPositions, 'XTickLabel', classNames);
xlabel('Defect Class', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Score', 'Interpreter', 'latex', 'FontSize', 12);
title('Medium Network Per-Class Performance', ...
    'Interpreter', 'latex', 'FontSize', 14);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
ylim([0, 1.1]);
hold off;

fprintf('\nProblem 1 completed successfully.\n');
