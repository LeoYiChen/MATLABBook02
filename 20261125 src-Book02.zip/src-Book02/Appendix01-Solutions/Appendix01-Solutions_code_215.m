%% Appendix01-Solutions_code_215.m
% Variational Autoencoder for Phase Space Reduction
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from scipy.spatial.distance import cdist

# ============================================================================
# Molecular Dynamics Simulation
# ============================================================================
class LennardJonesSimulation:
    """2D Lennard-Jones molecular dynamics"""
    
    def __init__(self, N=50, L=10.0, dt=0.001, epsilon=1.0, sigma=1.0):
        self.N = N
        self.L = L  # Box size
        self.dt = dt
        self.epsilon = epsilon
        self.sigma = sigma
        
    def initialize_positions(self, density=0.5):
        """Initialize on square lattice with noise"""
        n_side = int(np.ceil(np.sqrt(self.N)))
        spacing = self.L / n_side
        
        positions = []
        for i in range(n_side):
            for j in range(n_side):
                if len(positions) < self.N:
                    x = (i + 0.5) * spacing + np.random.uniform(-0.1, 0.1)
                    y = (j + 0.5) * spacing + np.random.uniform(-0.1, 0.1)
                    positions.append([x, y])
        
        return np.array(positions[:self.N])
    
    def initialize_velocities(self, T):
        """Maxwell-Boltzmann distribution"""
        velocities = np.random.normal(0, np.sqrt(T), (self.N, 2))
        # Remove center-of-mass motion
        velocities -= np.mean(velocities, axis=0)
        return velocities
    
    def compute_forces(self, positions):
        """Compute Lennard-Jones forces with periodic boundaries"""
        forces = np.zeros_like(positions)
        
        for i in range(self.N):
            for j in range(i+1, self.N):
                # Minimum image convention
                dr = positions[j] - positions[i]
                dr = dr - self.L * np.round(dr / self.L)
                
                r = np.linalg.norm(dr)
                
                if r < 3.0 * self.sigma:  # Cutoff
                    # Lennard-Jones force
                    f_mag = 24 * self.epsilon / r * (
                        2 * (self.sigma / r)**12 - (self.sigma / r)**6
                    )
                    f_vec = f_mag * dr / r
                    
                    forces[i] += f_vec
                    forces[j] -= f_vec
        
        return forces
    
    def step(self, positions, velocities):
        """Velocity Verlet integration"""
        # Compute initial forces
        forces = self.compute_forces(positions)
        accelerations = forces
        
        # Update positions
        positions_new = positions + velocities * self.dt + 0.5 * accelerations * self.dt**2
        
        # Apply periodic boundary conditions
        positions_new = positions_new % self.L
        
        # Compute new forces
        forces_new = self.compute_forces(positions_new)
        accelerations_new = forces_new
        
        # Update velocities
        velocities_new = velocities + 0.5 * (accelerations + accelerations_new) * self.dt
        
        return positions_new, velocities_new
    
    def run_simulation(self, T, n_equilibration=5000, n_production=1000, 
                      sample_interval=50):
        """Run MD simulation at temperature T"""
        # Initialize
        positions = self.initialize_positions()
        velocities = self.initialize_velocities(T)
        
        # Equilibration
        for _ in range(n_equilibration):
            positions, velocities = self.step(positions, velocities)
            
            # Thermostat (velocity rescaling every 10 steps)
            if _ % 10 == 0:
                current_T = np.mean(np.sum(velocities**2, axis=1)) / 2.0
                scale = np.sqrt(T / (current_T + 1e-10))
                velocities *= scale
        
        # Production run
        snapshots = []
        for step in range(n_production):
            positions, velocities = self.step(positions, velocities)
            
            if step % sample_interval == 0:
                # Store phase space snapshot (positions + velocities)
                snapshot = np.concatenate([positions.flatten(), 
                                          velocities.flatten()])
                snapshots.append(snapshot)
        
        return np.array(snapshots)

# ============================================================================
# Generate Training Data
# ============================================================================
print("="*70)
print("GENERATING MOLECULAR DYNAMICS TRAJECTORIES")
print("="*70)

simulator = LennardJonesSimulation(N=50, L=10.0, dt=0.001)

# Temperature range
temperatures = [0.5, 0.8, 1.0, 1.3, 1.6]
n_snapshots_per_T = 1000

all_snapshots = []
all_temperatures = []

for T in temperatures:
    print(f"\nSimulating T = {T:.1f}...")
    snapshots = simulator.run_simulation(T, n_equilibration=5000, 
                                         n_production=50000, 
                                         sample_interval=50)
    
    all_snapshots.append(snapshots)
    all_temperatures.extend([T] * len(snapshots))
    print(f"  Generated {len(snapshots)} snapshots")

# Combine data
X_data = np.vstack(all_snapshots).astype(np.float32)
T_data = np.array(all_temperatures).astype(np.float32)

print(f"\nTotal dataset size: {X_data.shape}")
print(f"Phase space dimension: {X_data.shape[1]}")
print(f"Temperature range: [{T_data.min():.1f}, {T_data.max():.1f}]")

# Normalize data
X_mean = X_data.mean(axis=0)
X_std = X_data.std(axis=0) + 1e-8
X_normalized = (X_data - X_mean) / X_std

# Train/validation/test split
from sklearn.model_selection import train_test_split

X_temp, X_test, T_temp, T_test = train_test_split(
    X_normalized, T_data, test_size=0.15, random_state=42
)
X_train, X_val, T_train, T_val = train_test_split(
    X_temp, T_temp, test_size=0.176, random_state=42
)

print(f"\nData splits:")
print(f"  Train: {X_train.shape[0]}")
print(f"  Val:   {X_val.shape[0]}")
print(f"  Test:  {X_test.shape[0]}")

# ============================================================================
# Variational Autoencoder Architecture
# ============================================================================
class VAE(nn.Module):
    """Variational Autoencoder for phase space compression"""
    
    def __init__(self, input_dim=200, hidden_dims=[100, 50], latent_dim=2):
        super(VAE, self).__init__()
        
        # Encoder
        self.encoder_layers = nn.ModuleList()
        prev_dim = input_dim
        for h_dim in hidden_dims:
            self.encoder_layers.append(nn.Linear(prev_dim, h_dim))
            prev_dim = h_dim
        
        # Latent space
        self.fc_mu = nn.Linear(hidden_dims[-1], latent_dim)
        self.fc_logvar = nn.Linear(hidden_dims[-1], latent_dim)
        
        # Decoder
        self.decoder_layers = nn.ModuleList()
        prev_dim = latent_dim
        for h_dim in reversed(hidden_dims):
            self.decoder_layers.append(nn.Linear(prev_dim, h_dim))
            prev_dim = h_dim
        self.decoder_layers.append(nn.Linear(prev_dim, input_dim))
    
    def encode(self, x):
        """Encoder: x -> mu, logvar"""
        h = x
        for layer in self.encoder_layers:
            h = F.relu(layer(h))
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar
    
    def reparameterize(self, mu, logvar):
        """Reparameterization trick: z = mu + sigma * epsilon"""
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        z = mu + eps * std
        return z
    
    def decode(self, z):
        """Decoder: z -> x_reconstructed"""
        h = z
        for i, layer in enumerate(self.decoder_layers[:-1]):
            h = F.relu(layer(h))
        x_recon = self.decoder_layers[-1](h)  # No activation on output
        return x_recon
    
    def forward(self, x):
        """Full forward pass"""
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        x_recon = self.decode(z)
        return x_recon, mu, logvar, z

def vae_loss(x_recon, x, mu, logvar, beta=0.5):
    """VAE loss = Reconstruction + KL divergence"""
    # Reconstruction loss (MSE)
    recon_loss = F.mse_loss(x_recon, x, reduction='sum')
    
    # KL divergence
    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    
    # Total loss
    total_loss = recon_loss + beta * kl_loss
    
    return total_loss, recon_loss, kl_loss

# ============================================================================
# Training Setup
# ============================================================================
# Hyperparameters
INPUT_DIM = 200  # 50 particles * 2 coords * 2 (position + velocity)
LATENT_DIM = 2
BATCH_SIZE = 128
NUM_EPOCHS = 50
LEARNING_RATE = 1e-3
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Create datasets
train_dataset = torch.utils.data.TensorDataset(
    torch.from_numpy(X_train), 
    torch.from_numpy(T_train)
)
val_dataset = torch.utils.data.TensorDataset(
    torch.from_numpy(X_val), 
    torch.from_numpy(T_val)
)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)

# Initialize model
model = VAE(input_dim=INPUT_DIM, hidden_dims=[100, 50], latent_dim=LATENT_DIM)
model = model.to(DEVICE)

optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

print("\n" + "="*70)
print("TRAINING VARIATIONAL AUTOENCODER")
print("="*70)
print(f"\nModel: {sum(p.numel() for p in model.parameters()):,} parameters")
print(f"Device: {DEVICE}")

# ============================================================================
# Training Loop with Beta Annealing
# ============================================================================
train_losses = []
val_losses = []
beta_schedule = []

for epoch in range(NUM_EPOCHS):
    # Beta annealing
    beta = min(0.5, epoch / 20 * 0.5)  # Linearly increase to 0.5 over 20 epochs
    beta_schedule.append(beta)
    
    # Training
    model.train()
    train_loss_epoch = 0
    train_recon_epoch = 0
    train_kl_epoch = 0
    
    for batch_x, _ in train_loader:
        batch_x = batch_x.to(DEVICE)
        
        # Forward pass
        x_recon, mu, logvar, z = model(batch_x)
        
        # Compute loss
        loss, recon_loss, kl_loss = vae_loss(x_recon, batch_x, mu, logvar, beta)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        train_loss_epoch += loss.item()
        train_recon_epoch += recon_loss.item()
        train_kl_epoch += kl_loss.item()
    
    train_loss_epoch /= len(train_loader.dataset)
    train_recon_epoch /= len(train_loader.dataset)
    train_kl_epoch /= len(train_loader.dataset)
    train_losses.append(train_loss_epoch)
    
    # Validation
    model.eval()
    val_loss_epoch = 0
    val_recon_epoch = 0
    val_kl_epoch = 0
    
    with torch.no_grad():
        for batch_x, _ in val_loader:
            batch_x = batch_x.to(DEVICE)
            x_recon, mu, logvar, z = model(batch_x)
            loss, recon_loss, kl_loss = vae_loss(x_recon, batch_x, mu, logvar, beta)
            
            val_loss_epoch += loss.item()
            val_recon_epoch += recon_loss.item()
            val_kl_epoch += kl_loss.item()
    
    val_loss_epoch /= len(val_loader.dataset)
    val_recon_epoch /= len(val_loader.dataset)
    val_kl_epoch /= len(val_loader.dataset)
    val_losses.append(val_loss_epoch)
    
    if (epoch + 1) % 5 == 0:
        print(f"Epoch [{epoch+1}/{NUM_EPOCHS}]  ={beta:.3f} | "
              f"Train Loss: {train_loss_epoch:.4f} "
              f"(Recon: {train_recon_epoch:.4f}, KL: {train_kl_epoch:.4f}) | "
              f"Val Loss: {val_loss_epoch:.4f}")

# ============================================================================
# Latent Space Analysis
# ============================================================================
print("\n" + "="*70)
print("LATENT SPACE ANALYSIS")
print("="*70)

model.eval()
with torch.no_grad():
    # Encode all data
    X_all = torch.from_numpy(X_normalized).to(DEVICE)
    mu_all, logvar_all = model.encode(X_all)
    z_all = mu_all.cpu().numpy()  # Use mean (deterministic encoding)

# Compute correlation between latent dimensions and temperature
corr_z1_T = np.corrcoef(z_all[:, 0], T_data)[0, 1]
corr_z2_T = np.corrcoef(z_all[:, 1], T_data)[0, 1]

print(f"\nLatent-Temperature Correlations:")
print(f"  z1 vs T: {corr_z1_T:.4f}")
print(f"  z2 vs T: {corr_z2_T:.4f}")

# Identify which dimension corresponds to temperature
if abs(corr_z1_T) > abs(corr_z2_T):
    T_dim = 0
    other_dim = 1
else:
    T_dim = 1
    other_dim = 0

print(f"\nPrimary temperature dimension: z{T_dim}")

# ============================================================================
# Visualization
# ============================================================================
print("\nGenerating visualizations...")

fig = plt.figure(figsize=(18, 12))

# Plot 1: Training curves
ax1 = plt.subplot(3, 3, 1)
ax1.plot(train_losses, label='Train Loss', linewidth=2)
ax1.plot(val_losses, label='Val Loss', linewidth=2)
ax1.set_xlabel('Epoch', fontsize=11)
ax1.set_ylabel('Loss', fontsize=11)
ax1.set_title('Training and Validation Loss', fontsize=13, fontweight='bold')
ax1.legend()
ax1.grid(True, alpha=0.3)
ax1.set_yscale('log')

# Plot 2: Beta annealing schedule
ax2 = plt.subplot(3, 3, 2)
ax2.plot(beta_schedule, linewidth=2, color='purple')
ax2.set_xlabel('Epoch', fontsize=11)
ax2.set_ylabel('  (KL weight)', fontsize=11)
ax2.set_title('Beta Annealing Schedule', fontsize=13, fontweight='bold')
ax2.grid(True, alpha=0.3)

# Plot 3: Latent space colored by temperature
ax3 = plt.subplot(3, 3, 3)
scatter = ax3.scatter(z_all[:, 0], z_all[:, 1], c=T_data, 
                     cmap='coolwarm', s=20, alpha=0.6, edgecolors='k', linewidth=0.3)
ax3.set_xlabel('$z_1$', fontsize=12)
ax3.set_ylabel('$z_2$', fontsize=12)
ax3.set_title('Latent Space (colored by Temperature)', 
             fontsize=13, fontweight='bold')
cbar = plt.colorbar(scatter, ax=ax3)
cbar.set_label('Temperature (T)', fontsize=11)
ax3.grid(True, alpha=0.3)

# Plot 4: Latent dimensions vs temperature
ax4 = plt.subplot(3, 3, 4)
ax4.scatter(T_data, z_all[:, T_dim], alpha=0.5, s=20, label=f'$z_{T_dim}$ (primary)')
ax4.scatter(T_data, z_all[:, other_dim], alpha=0.5, s=20, label=f'$z_{other_dim}$ (secondary)')
ax4.set_xlabel('Temperature (T)', fontsize=11)
ax4.set_ylabel('Latent Value', fontsize=11)
ax4.set_title('Latent Dimensions vs Temperature', fontsize=13, fontweight='bold')
ax4.legend()
ax4.grid(True, alpha=0.3)

# Plot 5: Reconstruction quality
ax5 = plt.subplot(3, 3, 5)
with torch.no_grad():
    sample_indices = np.random.choice(len(X_test), 5, replace=False)
    X_test_sample = torch.from_numpy(X_test[sample_indices]).to(DEVICE)
    X_recon_sample, _, _, _ = model(X_test_sample)
    X_recon_sample = X_recon_sample.cpu().numpy()

# Plot original vs reconstructed (first 100 dimensions for visibility)
for i in range(5):
    ax5.plot(X_test[sample_indices[i], :100], alpha=0.7, 
            label=f'Original {i+1}' if i == 0 else "")
    ax5.plot(X_recon_sample[i, :100], '-', alpha=0.7, 
            label=f'Reconstructed {i+1}' if i == 0 else "")

ax5.set_xlabel('Dimension', fontsize=11)
ax5.set_ylabel('Value (normalized)', fontsize=11)
ax5.set_title('Reconstruction Quality (100 dims)', fontsize=13, fontweight='bold')
ax5.legend(fontsize=8)
ax5.grid(True, alpha=0.3)

# Plot 6: Latent space interpolation
ax6 = plt.subplot(3, 3, 6)

# Select two points with different temperatures
idx_low_T = np.argmin(np.abs(T_data - 0.5))
idx_high_T = np.argmin(np.abs(T_data - 1.6))

z_low = z_all[idx_low_T]
z_high = z_all[idx_high_T]

# Linear interpolation in latent space
n_interp = 10
alphas = np.linspace(0, 1, n_interp)
z_interp = np.array([alpha * z_high + (1 - alpha) * z_low for alpha in alphas])

# Decode interpolated latents
with torch.no_grad():
    z_interp_torch = torch.from_numpy(z_interp.astype(np.float32)).to(DEVICE)
    x_interp = model.decode(z_interp_torch).cpu().numpy()

# Visualize particle positions from interpolated states
for i, alpha in enumerate([0, 0.5, 1.0]):
    idx = int(alpha * (n_interp - 1))
    positions = x_interp[idx, :100].reshape(50, 2)  # First 50 particles' positions
    
    ax6.scatter(positions[:, 0], positions[:, 1], 
               s=100, alpha=0.6, label=f' ={alpha:.1f}')

ax6.set_xlabel('x', fontsize=11)
ax6.set_ylabel('y', fontsize=11)
ax6.set_title('Latent Interpolation (Particle Positions)', 
             fontsize=13, fontweight='bold')
ax6.legend()
ax6.grid(True, alpha=0.3)
ax6.set_aspect('equal')

# Plot 7: KL divergence distribution
ax7 = plt.subplot(3, 3, 7)
with torch.no_grad():
    _, _, logvar_test = model.encode(torch.from_numpy(X_test).to(DEVICE))
    mu_test_np = model.encode(torch.from_numpy(X_test).to(DEVICE))[0].cpu().numpy()
    logvar_test_np = logvar_test.cpu().numpy()
    
    kl_per_sample = -0.5 * np.sum(1 + logvar_test_np - mu_test_np**2 - np.exp(logvar_test_np), axis=1)

ax7.hist(kl_per_sample, bins=30, color='orange', alpha=0.7, edgecolor='black')
ax7.set_xlabel('KL Divergence', fontsize=11)
ax7.set_ylabel('Frequency', fontsize=11)
ax7.set_title('KL Divergence Distribution (Test Set)', fontsize=13, fontweight='bold')
ax7.grid(True, alpha=0.3, axis='y')

# Plot 8: Latent space sampling
ax8 = plt.subplot(3, 3, 8)
with torch.no_grad():
    # Sample from prior
    z_samples = torch.randn(100, LATENT_DIM).to(DEVICE)
    x_samples = model.decode(z_samples).cpu().numpy()

# Check if generated samples are physically reasonable
# (positions should be within box)
sample_positions = x_samples[:, :100].reshape(100, 50, 2)
sample_positions = sample_positions * X_std[:100].reshape(50, 2) + X_mean[:100].reshape(50, 2)

# Plot a few generated configurations
for i in range(3):
    positions = sample_positions[i]
    ax8.scatter(positions[:, 0], positions[:, 1], s=50, alpha=0.6, label=f'Sample {i+1}')

ax8.set_xlabel('x', fontsize=11)
ax8.set_ylabel('y', fontsize=11)
ax8.set_title('Generated Samples from Prior', fontsize=13, fontweight='bold')
ax8.legend()
ax8.grid(True, alpha=0.3)
ax8.set_xlim(0, 10)
ax8.set_ylim(0, 10)

# Plot 9: Reconstruction error vs temperature
ax9 = plt.subplot(3, 3, 9)
with torch.no_grad():
    X_test_torch = torch.from_numpy(X_test).to(DEVICE)
    X_recon_test, _, _, _ = model(X_test_torch)
    recon_errors = torch.mean((X_recon_test - X_test_torch)**2, dim=1).cpu().numpy()

ax9.scatter(T_test, recon_errors, alpha=0.5, s=20)
ax9.set_xlabel('Temperature (T)', fontsize=11)
ax9.set_ylabel('Reconstruction Error (MSE)', fontsize=11)
ax9.set_title('Reconstruction Error vs Temperature', fontsize=13, fontweight='bold')
ax9.grid(True, alpha=0.3)

# Add trend line
z_fit = np.polyfit(T_test, recon_errors, 2)
p_fit = np.poly1d(z_fit)
T_plot = np.linspace(T_test.min(), T_test.max(), 100)
ax9.plot(T_plot, p_fit(T_plot), 'r-', linewidth=2, label='Quadratic Fit')
ax9.legend()

plt.tight_layout()
plt.savefig('vae_phase_space_results.png', dpi=300, bbox_inches='tight')
plt.show()

print("Visualization saved as 'vae_phase_space_results.png'")

# ============================================================================
# Final Analysis
# ============================================================================
print("\n" + "="*70)
print("FINAL ANALYSIS")
print("="*70)

print(f"\nLatent Space Properties:")
print(f"  Dimension: {LATENT_DIM}D")
print(f"  Primary order parameter: z{T_dim} (corr with T = {abs(corr_z1_T if T_dim == 0 else corr_z2_T):.4f})")
print(f"  Mean reconstruction error: {recon_errors.mean():.6f}")
print(f"  Mean KL divergence: {kl_per_sample.mean():.4f}")

print(f"\nPhase Space Compression:")
print(f"  Original: {INPUT_DIM}D   Latent: {LATENT_DIM}D")
print(f"  Compression ratio: {INPUT_DIM/LATENT_DIM:.1f} ")
print(f"  Information preserved: ~{100*(1 - recon_errors.mean()):.1f}%")

print("\n VAE successfully discovers temperature as emergent order parameter!")
print(" Smooth interpolation in latent space generates valid intermediate states")
print(" Latent space provides interpretable low-dimensional representation")
