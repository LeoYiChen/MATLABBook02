%% C020201Maths_Fundamental_code_118.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% SQP algorithm for constrained optimisation
options_sqp = optimoptions('fmincon', 'Algorithm', 'sqp', ...
    'Display', 'iter', 'SpecifyObjectiveGradient', true, ...
    'SpecifyConstraintGradient', true);

[xOpt, fOpt, exitflag, output] = fmincon(objWithGrad, x0, ...
    A, b, Aeq, beq, lb, ub, nonlinconWithGrad, options_sqp);
