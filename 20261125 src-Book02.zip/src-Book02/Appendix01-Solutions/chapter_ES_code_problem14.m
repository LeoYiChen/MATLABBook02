%% chapter_ES_code_problem14.m
% AI-Driven Optimal Design for Robotic Mobility Device
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem14
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem14
    % MATLABBook_ChapterES_Problem14.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2025-01-15
    % Modified: 2025-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   AI-driven optimal design for Toyota Walk Me-inspired robotic
    %   mobility device. Includes kinematic modeling, genetic algorithm
    %   optimization, RL-based gait learning, and multi-objective analysis.
    %
    % Dependencies: Global Optimization Toolbox (for ga)
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 14
    
    fprintf('\n=== Problem 14: AI-Driven Design for Robotic Mobility Device ===\n\n');
    
    %% Design Space Definition
    
    fprintf('=== Design Space Setup ===\n');
    
    % Design variables (per leg)
    % [l_femur, l_tibia, hip_offset, mass_distribution]
    %  (m)      (m)      (m)         (0-1, proximal vs distal)
    
    % Bounds
    lb = [0.20, 0.15, 0.10, 0.3];  % Lower bounds
    ub = [0.40, 0.35, 0.25, 0.7];  % Upper bounds
    
    % Fixed parameters
    m_user = 80;  % User mass (kg)
    m_chair_base = 25;  % Chair structure mass (kg)
    m_actuator = 1.2;  % Mass per actuator (kg) - 12 total
    g = 9.81;  % Gravity (m/s)
    
    % Target specifications
    max_step_height = 0.20;  % Standard stair riser (m)
    target_speed = 0.5;  % Walking speed (m/s)
    max_folded_volume = 0.055 * 0.40 * 0.23;  % Carry-on limit (m)
    
    fprintf('Design constraints:\n');
    fprintf('  Femur length: %.2f - %.2f m\n', lb(1), ub(1));
    fprintf('  Tibia length: %.2f - %.2f m\n', lb(2), ub(2));
    fprintf('  User mass: %.0f kg\n', m_user);
    fprintf('  Max step height: %.2f m\n', max_step_height);
    fprintf('  Folded volume limit: %.4f m\n\n', max_folded_volume);
    
    %% Baseline Design
    
    fprintf('=== Baseline Design Evaluation ===\n');
    
    % Initial design (heuristic proportions)
    design_baseline = [0.30, 0.25, 0.15, 0.5];
    
    % Evaluate baseline
    [obj_baseline, metrics_baseline] = evaluate_design(design_baseline, m_user, ...
                                                       m_chair_base, m_actuator);
    
    fprintf('Baseline design:\n');
    fprintf('  Femur: %.3f m, Tibia: %.3f m\n', design_baseline(1), design_baseline(2));
    fprintf('  Energy cost: %.2f J/m\n', metrics_baseline.energy_per_meter);
    fprintf('  Max speed: %.2f m/s\n', metrics_baseline.max_speed);
    fprintf('  Stability margin: %.3f m\n', metrics_baseline.stability_margin);
    fprintf('  Folded volume: %.4f m (%.1f%% of limit)\n', ...
            metrics_baseline.folded_volume, ...
            metrics_baseline.folded_volume/max_folded_volume*100);
    fprintf('  Total mass: %.1f kg\n\n', metrics_baseline.total_mass);
    
    %% Genetic Algorithm Optimization
    
    fprintf('=== Genetic Algorithm Optimization ===\n');
    
    % Multi-objective: minimize energy AND maximize speed
    % Convert to single objective via weighted sum
    w_energy = 0.6;
    w_speed = 0.4;
    
    fitness_function = @(x) objective_weighted(x, m_user, m_chair_base, ...
                                               m_actuator, w_energy, w_speed);
    
    % GA options
    options = optimoptions('ga', ...
                          'PopulationSize', 40, ...
                          'MaxGenerations', 50, ...
                          'Display', 'iter', ...
                          'PlotFcn', @gaplotbestf);
    
    fprintf('Running GA with %d individuals, %d generations...\n', ...
            options.PopulationSize, options.MaxGenerations);
    fprintf('Objective weights: Energy=%.1f, Speed=%.1f\n\n', w_energy, w_speed);
    
    % Run optimization
    [design_optimal, fval_optimal] = ga(fitness_function, 4, [], [], [], [], ...
                                       lb, ub, [], options);
    
    % Evaluate optimal design
    [~, metrics_optimal] = evaluate_design(design_optimal, m_user, ...
                                          m_chair_base, m_actuator);
    
    fprintf('\nOptimized design:\n');
    fprintf('  Femur: %.3f m, Tibia: %.3f m\n', design_optimal(1), design_optimal(2));
    fprintf('  Energy cost: %.2f J/m (%.1f%% reduction)\n', ...
            metrics_optimal.energy_per_meter, ...
            (1 - metrics_optimal.energy_per_meter/metrics_baseline.energy_per_meter)*100);
    fprintf('  Max speed: %.2f m/s (%.1f%% increase)\n', ...
            metrics_optimal.max_speed, ...
            (metrics_optimal.max_speed/metrics_baseline.max_speed - 1)*100);
    fprintf('  Stability margin: %.3f m\n', metrics_optimal.stability_margin);
    fprintf('  Folded volume: %.4f m\n', metrics_optimal.folded_volume);
    fprintf('  Total mass: %.1f kg\n\n', metrics_optimal.total_mass);
    
    %% Multi-Objective Pareto Analysis
    
    fprintf('=== Multi-Objective Pareto Front Generation ===\n');
    
    % Generate Pareto front by varying weight combinations
    n_weights = 20;
    weights_energy = linspace(0, 1, n_weights);
    weights_speed = 1 - weights_energy;
    
    pareto_designs = zeros(n_weights, 4);
    pareto_metrics = struct();
    
    fprintf('Generating %d Pareto-optimal designs...\n', n_weights);
    
    for i = 1:n_weights
        w_e = weights_energy(i);
        w_s = weights_speed(i);
        
        fitness = @(x) objective_weighted(x, m_user, m_chair_base, ...
                                         m_actuator, w_e, w_s);
        
        % Quick optimization (fewer generations)
        opts = optimoptions('ga', 'PopulationSize', 30, 'MaxGenerations', 30, ...
                           'Display', 'off');
        
        [design, ~] = ga(fitness, 4, [], [], [], [], lb, ub, [], opts);
        
        pareto_designs(i, :) = design;
        [~, metrics] = evaluate_design(design, m_user, m_chair_base, m_actuator);
        
        pareto_metrics(i).energy = metrics.energy_per_meter;
        pareto_metrics(i).speed = metrics.max_speed;
        pareto_metrics(i).mass = metrics.total_mass;
        pareto_metrics(i).volume = metrics.folded_volume;
        
        if mod(i, 5) == 0
            fprintf('  Progress: %d/%d designs\n', i, n_weights);
        end
    end
    
    fprintf('Pareto front generated.\n');
    fprintf('  Energy range: %.1f - %.1f J/m\n', ...
            min([pareto_metrics.energy]), max([pareto_metrics.energy]));
    fprintf('  Speed range: %.2f - %.2f m/s\n\n', ...
            min([pareto_metrics.speed]), max([pareto_metrics.speed]));
    
    %% Gait Parameter Optimization (Simplified RL)
    
    fprintf('=== Gait Parameter Optimization ===\n');
    
    % Gait parameters: [step_height, stride_length, duty_cycle]
    gait_baseline = [0.10, 0.30, 0.75];  % Conservative gait
    
    % Use hill climbing (simple optimization) for gait
    gait_optimal = optimize_gait(design_optimal, m_user + m_chair_base + ...
                                12*m_actuator, gait_baseline);
    
    fprintf('Baseline gait:\n');
    fprintf('  Step height: %.3f m, Stride: %.3f m, Duty cycle: %.2f\n', ...
            gait_baseline(1), gait_baseline(2), gait_baseline(3));
    
    fprintf('Optimized gait:\n');
    fprintf('  Step height: %.3f m, Stride: %.3f m, Duty cycle: %.2f\n', ...
            gait_optimal(1), gait_optimal(2), gait_optimal(3));
    
    % Evaluate energy savings
    energy_baseline_gait = simulate_gait(design_optimal, gait_baseline, ...
                                        m_user + m_chair_base + 12*m_actuator);
    energy_optimal_gait = simulate_gait(design_optimal, gait_optimal, ...
                                       m_user + m_chair_base + 12*m_actuator);
    
    fprintf('  Energy with baseline gait: %.2f J/m\n', energy_baseline_gait);
    fprintf('  Energy with optimized gait: %.2f J/m (%.1f%% reduction)\n\n', ...
            energy_optimal_gait, ...
            (1 - energy_optimal_gait/energy_baseline_gait)*100);
    
    %% Visualization
    
    fprintf('Generating visualizations...\n');
    
    % Figure 1: Design comparison
    figure('Position', [50 50 1400 800]);
    
    % Subplot 1: Leg geometry
    subplot(2, 3, 1);
    plot_leg_geometry(design_baseline, 'Baseline');
    
    subplot(2, 3, 2);
    plot_leg_geometry(design_optimal, 'Optimized');
    
    % Subplot 3: Performance radar chart
    subplot(2, 3, 3);
    metrics_names = {'Energy Eff.', 'Speed', 'Stability', 'Compactness'};
    
    % Normalize to 0-1 (invert energy - lower is better)
    baseline_norm = [1/metrics_baseline.energy_per_meter * 50, ...
                    metrics_baseline.max_speed / 0.8, ...
                    metrics_baseline.stability_margin / 0.2, ...
                    (1 - metrics_baseline.folded_volume/max_folded_volume)];
    
    optimal_norm = [1/metrics_optimal.energy_per_meter * 50, ...
                   metrics_optimal.max_speed / 0.8, ...
                   metrics_optimal.stability_margin / 0.2, ...
                   (1 - metrics_optimal.folded_volume/max_folded_volume)];
    
    angles = linspace(0, 2*pi, length(metrics_names)+1);
    
    polarplot(angles, [baseline_norm, baseline_norm(1)], 'b-o', 'LineWidth', 2);
    hold on;
    polarplot(angles, [optimal_norm, optimal_norm(1)], 'r-s', 'LineWidth', 2);
    hold off;
    
    thetaticks(rad2deg(angles(1:end-1)));
    thetaticklabels(metrics_names);
    title('Performance Comparison', 'Interpreter', 'latex');
    legend({'Baseline', 'Optimized'}, 'Location', 'best', 'Interpreter', 'latex');
    
    % Subplot 4: Pareto front
    subplot(2, 3, 4);
    energies = [pareto_metrics.energy];
    speeds = [pareto_metrics.speed];
    
    scatter(energies, speeds, 80, 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    plot(metrics_baseline.energy_per_meter, metrics_baseline.max_speed, ...
         'bs', 'MarkerSize', 12, 'LineWidth', 2);
    plot(metrics_optimal.energy_per_meter, metrics_optimal.max_speed, ...
         'rs', 'MarkerSize', 12, 'LineWidth', 2);
    hold off;
    
    xlabel('Energy Cost (J/m)', 'Interpreter', 'latex');
    ylabel('Max Speed (m/s)', 'Interpreter', 'latex');
    title('Multi-Objective Pareto Front', 'Interpreter', 'latex');
    legend({'Pareto Set', 'Baseline', 'GA Optimal'}, 'Location', 'best', ...
           'Interpreter', 'latex');
    grid on;
    
    % Subplot 5: Mass breakdown
    subplot(2, 3, 5);
    categories = {'User', 'Structure', 'Actuators', 'Battery'};
    
    mass_breakdown_baseline = [m_user, m_chair_base, 12*m_actuator, ...
                              estimate_battery_mass(metrics_baseline.energy_per_meter)];
    mass_breakdown_optimal = [m_user, m_chair_base, 12*m_actuator, ...
                             estimate_battery_mass(metrics_optimal.energy_per_meter)];
    
    bar(categorical(categories), [mass_breakdown_baseline; mass_breakdown_optimal]', ...
        'grouped');
    ylabel('Mass (kg)', 'Interpreter', 'latex');
    title('Mass Distribution', 'Interpreter', 'latex');
    legend({'Baseline', 'Optimized'}, 'Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 6: Gait simulation
    subplot(2, 3, 6);
    
    % Simulate one gait cycle
    t_gait = linspace(0, 1, 50);  % Normalized cycle time
    CoM_baseline = simulate_CoM_trajectory(design_baseline, gait_baseline, t_gait);
    CoM_optimal = simulate_CoM_trajectory(design_optimal, gait_optimal, t_gait);
    
    plot(t_gait, CoM_baseline(:, 3)*100, 'b-', 'LineWidth', 1.5);
    hold on;
    plot(t_gait, CoM_optimal(:, 3)*100, 'r-', 'LineWidth', 1.5);
    hold off;
    
    xlabel('Gait Cycle Phase', 'Interpreter', 'latex');
    ylabel('CoM Height (cm)', 'Interpreter', 'latex');
    title('Center of Mass Trajectory', 'Interpreter', 'latex');
    legend({'Baseline Gait', 'Optimized Gait'}, 'Location', 'best', ...
           'Interpreter', 'latex');
    grid on;
    
    sgtitle('AI-Driven Robotic Mobility Device Design Optimization', ...
            'Interpreter', 'latex', 'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Visualizations generated.\n\n');
    
    %% Helper Functions
    
    function [obj, metrics] = evaluate_design(design, m_u, m_c, m_a)
        % Evaluate design objectives and constraints
        
        l_femur = design(1);
        l_tibia = design(2);
        hip_offset = design(3);
        mass_dist = design(4);
        
        % Total mass
        m_legs = 4 * (l_femur + l_tibia) * 2.5;  % kg (aluminum density   volume estimate)
        m_battery = estimate_battery_mass(100);  % Initial estimate
        m_total = m_u + m_c + 12*m_a + m_legs + m_battery;
        
        % Energy per meter (simplified model)
        % Based on actuator torque requirements and stride efficiency
        stride_length = 0.8 * (l_femur + l_tibia);  % Heuristic
        step_height = 0.4 * l_tibia;  % Max clearance
        
        % Torque = Force   moment_arm
        tau_hip = m_total * g * l_femur * 1.5;  % Safety factor
        tau_knee = m_total * g * l_tibia * 1.2;
        
        % Energy per step (simplified)
        E_step = (tau_hip + tau_knee) * 0.5;  % Average over step
        energy_per_meter = E_step / stride_length;
        
        % Update battery mass based on energy
        m_battery = estimate_battery_mass(energy_per_meter);
        m_total = m_u + m_c + 12*m_a + m_legs + m_battery;
        
        % Max speed (limited by actuator velocity and stability)
        max_speed = min(0.8, stride_length / 1.5);  % Conservative
        
        % Stability margin (distance from CoM to support polygon edge)
        % Simplified: assume square stance, CoM at center
        stance_width = 2 * hip_offset;
        stability_margin = stance_width / 2 * 0.7;  % Safety margin
        
        % Folded volume (telescopic legs)
        % Assume legs fold to 40% of extended length
        l_folded = (l_femur + l_tibia) * 0.4;
        folded_volume = l_folded * stance_width * 0.30;  % Width   height estimate
        
        % Aggregate metrics
        metrics.energy_per_meter = energy_per_meter;
        metrics.max_speed = max_speed;
        metrics.stability_margin = stability_margin;
        metrics.folded_volume = folded_volume;
        metrics.total_mass = m_total;
        metrics.step_height = step_height;
        
        % Combined objective (for single-objective optimization)
        obj = energy_per_meter / max_speed;  % Minimize energy, maximize speed
    end
    
    function obj = objective_weighted(design, m_u, m_c, m_a, w_e, w_s)
        % Weighted sum of objectives
        [~, metrics] = evaluate_design(design, m_u, m_c, m_a);
        
        % Normalize objectives to similar scales
        energy_norm = metrics.energy_per_meter / 200;  % Typical range 50-250
        speed_norm = 1 / metrics.max_speed * 0.5;  % Invert (maximize   minimize)
        
        obj = w_e * energy_norm + w_s * speed_norm;
    end
    
    function m_bat = estimate_battery_mass(energy_per_m)
        % Estimate battery mass for 10 km range
        range_km = 10;
        total_energy = energy_per_m * range_km * 1000;  % Joules
        
        % Li-ion battery: 150 Wh/kg = 540 kJ/kg
        energy_density = 540e3;  % J/kg
        m_bat = total_energy / energy_density * 1.5;  % 50% depth of discharge
    end
    
    function plot_leg_geometry(design, title_str)
        % Plot leg configuration
        l_femur = design(1);
        l_tibia = design(2);
        hip_offset = design(3);
        
        % Front-right leg (simplified 2D projection)
        hip = [hip_offset, 0, 0.40];  % Hip joint
        knee = hip + [0, 0, -l_femur];  % Knee joint
        foot = knee + [0, 0, -l_tibia];  % Foot
        
        plot3([hip(1), knee(1), foot(1)], ...
              [hip(2), knee(2), foot(2)], ...
              [hip(3), knee(3), foot(3)], ...
              'b-o', 'LineWidth', 3, 'MarkerSize', 8);
        
        hold on;
        % Add ground plane
        [X, Y] = meshgrid(-0.2:0.1:0.4, -0.2:0.1:0.2);
        Z = zeros(size(X));
        surf(X, Y, Z, 'FaceAlpha', 0.2, 'EdgeColor', 'none', 'FaceColor', [0.7 0.7 0.7]);
        hold off;
        
        xlabel('x (m)', 'Interpreter', 'latex');
        ylabel('y (m)', 'Interpreter', 'latex');
        zlabel('z (m)', 'Interpreter', 'latex');
        title(title_str, 'Interpreter', 'latex');
        grid on;
        axis equal;
        view(45, 20);
    end
    
    function gait_opt = optimize_gait(design, m_total, gait_init)
        % Simple hill-climbing for gait parameters
        gait_current = gait_init;
        energy_current = simulate_gait(design, gait_current, m_total);
        
        step_size = [0.01, 0.02, 0.05];  % Parameter step sizes
        n_iter = 20;
        
        for iter = 1:n_iter
            % Try perturbations
            improvements = zeros(3, 2);  % [dim, direction]
            
            for dim = 1:3
                for dir = [-1, 1]
                    gait_test = gait_current;
                    gait_test(dim) = gait_test(dim) + dir * step_size(dim);
                    
                    % Enforce bounds
                    gait_test(1) = max(0.05, min(0.15, gait_test(1)));  % Step height
                    gait_test(2) = max(0.20, min(0.40, gait_test(2)));  % Stride
                    gait_test(3) = max(0.60, min(0.85, gait_test(3)));  % Duty cycle
                    
                    energy_test = simulate_gait(design, gait_test, m_total);
                    
                    if energy_test < energy_current
                        improvements(dim, (dir+3)/2) = energy_current - energy_test;
                    end
                end
            end
            
            % Apply best improvement
            [max_improve, idx] = max(improvements(:));
            if max_improve > 0
                [dim, dir_idx] = ind2sub(size(improvements), idx);
                dir = (dir_idx - 1.5) * 2;  % Convert back to -1 or 1
                
                gait_current(dim) = gait_current(dim) + dir * step_size(dim);
                energy_current = energy_current - max_improve;
            else
                break;  % No improvement found
            end
        end
        
        gait_opt = gait_current;
    end
    
    function energy = simulate_gait(design, gait_params, m_total)
        % Simplified gait energy calculation
        l_femur = design(1);
        l_tibia = design(2);
        
        step_height = gait_params(1);
        stride_length = gait_params(2);
        duty_cycle = gait_params(3);
        
        % Energy components
        % 1. Lifting legs
        m_leg = (l_femur + l_tibia) * 2.5;  % kg
        E_lift = 4 * m_leg * g * step_height;  % 4 legs
        
        % 2. Moving horizontally (simplified drag)
        E_horizontal = 0.1 * m_total * stride_length;
        
        % 3. Actuator inefficiency (duty cycle dependence)
        efficiency = 0.7 + 0.2 * (duty_cycle - 0.7);  % Peak at 0.75
        
        E_total = (E_lift + E_horizontal) / efficiency;
        energy = E_total / stride_length;  % J/m
    end
    
    function CoM_traj = simulate_CoM_trajectory(design, gait, t_normalized)
        % Simulate CoM height over one gait cycle
        l_femur = design(1);
        l_tibia = design(2);
        step_height = gait(1);
        duty_cycle = gait(3);
        
        n_points = length(t_normalized);
        CoM_traj = zeros(n_points, 3);
        
        % Nominal CoM height (standing)
        h_nom = 0.40;
        
        for i = 1:n_points
            phase = t_normalized(i);
            
            % CoM oscillates as legs swing
            % Peak when legs maximally flexed (mid-swing)
            if phase < duty_cycle
                % Stance phase - relatively stable
                h = h_nom - 0.01 * sin(pi * phase / duty_cycle);
            else
                % Swing phase - lifts slightly
                h = h_nom + step_height * 0.3 * sin(pi * (phase - duty_cycle) / (1 - duty_cycle));
            end
            
            CoM_traj(i, :) = [0, 0, h];
        end
    end
end
