%% chapter_CFDPrinciples_example_multiscale.m
% Multi-scale physics coupling framework.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_multiscale
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function coupledResults = solveMultiScaleProblem(domainConfig, physicsModels, ...
    couplingMethod, solverSettings)
    % SOLVEMULTISCALEPROBLEM Multi-scale multi-physics coupling solver
    % Handles scale-separated and strongly-coupled multi-physics problems
    %
    % Inputs:
    %   domainConfig   - Struct: computational domain configuration
    %   physicsModels  - Struct: individual physics models (fluid, thermal, etc.)
    %   couplingMethod - String: 'loose', 'tight', 'operator-split'
    %   solverSettings - Struct: numerical solver parameters
    %
    % Output:
    %   coupledResults - Multi-physics solution fields
    %
    % Author: Dr Leo Chen
    % Institution: University of Cambridge
    % Version: 3.0
    %
    % References:
    %   [1] Pope (2000) Turbulent Flows
    %   [2] Strang (1968) On the construction of splitting methods
    %   [3] Felippa et al. (2001) Partitioned analysis of coupled systems
    
    fprintf('=== Multi-Scale Physics Coupling ===\n\n');
    
    fprintf('Coupling method: %s\n', couplingMethod);
    
    % Initialise solution fields
    solution = initialiseMultiPhysicsSolution(domainConfig, physicsModels);
    
    % Time integration parameters
    if isfield(solverSettings, 'timeStep')
        dt = solverSettings.timeStep;
        numSteps = solverSettings.numTimeSteps;
        
        transient = true;
    else
        transient = false;
        numSteps = solverSettings.maxIterations;
    end
    
    % Coupling convergence criteria
    if isfield(solverSettings, 'couplingTolerance')
        couplingTol = solverSettings.couplingTolerance;
    else
        couplingTol = 1e-4;
    end
    
    fprintf('Transient: %s\n', string(transient));
    
    if transient
        fprintf('Time step: %.6e s\n', dt);
        fprintf('Number of steps: %d\n\n', numSteps);
    else
        fprintf('Steady-state coupling\n');
        fprintf('Maximum iterations: %d\n\n', numSteps);
    end
    
    % Main coupling loop
    for step = 1:numSteps
        if transient
            fprintf('Time step %d/%d (t = %.6e s)\n', step, numSteps, step*dt);
        else
            fprintf('Iteration %d/%d\n', step, numSteps);
        end
        
        % Store previous solution for convergence check
        solution_old = solution;
        
        % Apply coupling method
        switch lower(couplingMethod)
            case 'loose'
                solution = looselyCommonCoupling(solution, physicsModels, dt);
                
            case 'tight'
                solution = tightlyCoupledSolve(solution, physicsModels, dt, ...
                                              couplingTol);
                
            case 'operator-split'
                solution = operatorSplitCoupling(solution, physicsModels, dt);
                
            otherwise
                error('Unknown coupling method: %s', couplingMethod);
        end
        
        % Check coupling convergence
        if step > 1
            convergenceMetric = computeCouplingConvergence(solution, solution_old);
            
            fprintf('  Coupling convergence: %.6e\n', convergenceMetric);
            
            if ~transient && convergenceMetric < couplingTol
                fprintf('\n*** Coupling converged at iteration %d ***\n', step);
                break;
            end
        end
        
        fprintf('\n');
    end
    
    coupledResults = solution;
    coupledResults.numSteps = step;
    
    fprintf('Multi-scale coupling completed.\n');
end

function solution = looselyCommonCoupling(sol, models, dt)
    % Loosely coupled (staggered, one-way or weak two-way) solution
    % Each physics solved sequentially without sub-iteration
    
    % Solve fluid dynamics
    if isfield(models, 'fluid')
        sol.fluid = models.fluid.solve(sol.fluid, dt);
    end
    
    % Solve thermal (using updated fluid field)
    if isfield(models, 'thermal')
        % Transfer convection from fluid to thermal
        sol.thermal.convection = extractConvection(sol.fluid);
        
        sol.thermal = models.thermal.solve(sol.thermal, dt);
    end
    
    % Solve species transport (using updated fluid and thermal)
    if isfield(models, 'species')
        sol.species.velocity = sol.fluid.velocity;
        sol.species.temperature = sol.thermal.temperature;
        
        sol.species = models.species.solve(sol.species, dt);
    end
    
    % Update fluid properties based on thermal/species
    if isfield(sol, 'thermal')
        sol.fluid.density = computeDensity(sol.thermal.temperature, sol.fluid.pressure);
        sol.fluid.viscosity = computeViscosity(sol.thermal.temperature);
    end
end

function solution = tightlyCoupledSolve(sol, models, dt, tol)
    % Tightly coupled solution with sub-iteration convergence
    % All physics solved iteratively until interface conditions converge
    
    maxSubIterations = 20;
    
    for subIter = 1:maxSubIterations
        sol_prev = sol;
        
        % Solve all physics with current interface conditions
        if isfield(models, 'fluid')
            sol.fluid = models.fluid.solve(sol.fluid, dt);
        end
        
        if isfield(models, 'thermal')
            sol.thermal.convection = extractConvection(sol.fluid);
            sol.thermal = models.thermal.solve(sol.thermal, dt);
            
            % Update fluid properties
            sol.fluid.density = computeDensity(sol.thermal.temperature, ...
                                              sol.fluid.pressure);
            sol.fluid.viscosity = computeViscosity(sol.thermal.temperature);
        end
        
        if isfield(models, 'species')
            sol.species.velocity = sol.fluid.velocity;
            sol.species.temperature = sol.thermal.temperature;
            sol.species = models.species.solve(sol.species, dt);
        end
        
        % Check sub-iteration convergence
        subIterConvergence = computeCouplingConvergence(sol, sol_prev);
        
        if subIterConvergence < tol
            fprintf('    Sub-iteration converged at iteration %d\n', subIter);
            break;
        end
    end
    
    if subIter == maxSubIterations
        warning('Sub-iteration did not converge within %d iterations', maxSubIterations);
    end
end

function solution = operatorSplitCoupling(sol, models, dt)
    % Operator splitting (Strang splitting for 2nd order accuracy)
    % Split operators: advection, diffusion, source terms
    
    % Half-step of operator B (e.g., diffusion/source)
    if isfield(models, 'diffusion')
        sol = models.diffusion.solve(sol, dt/2);
    end
    
    % Full step of operator A (e.g., advection)
    if isfield(models, 'advection')
        sol = models.advection.solve(sol, dt);
    end
    
    % Half-step of operator B again
    if isfield(models, 'diffusion')
        sol = models.diffusion.solve(sol, dt/2);
    end
    
    % Note: Strang splitting minimises temporal splitting error to O(dt?)
end

function convergence = computeCouplingConvergence(sol_new, sol_old)
    % Compute coupling convergence metric
    
    convergence = 0;
    numFields = 0;
    
    fields = fieldnames(sol_new);
    
    for i = 1:length(fields)
        field = fields{i};
        
        if isstruct(sol_new.(field)) && isstruct(sol_old.(field))
            % Recursively check sub-fields
            subConv = computeCouplingConvergence(sol_new.(field), sol_old.(field));
            convergence = convergence + subConv;
            numFields = numFields + 1;
            
        elseif isnumeric(sol_new.(field)) && isnumeric(sol_old.(field))
            % Compute relative change
            diff = sol_new.(field) - sol_old.(field);
            
            if norm(sol_new.(field)(:)) > 1e-12
                relChange = norm(diff(:)) / norm(sol_new.(field)(:));
            else
                relChange = norm(diff(:));
            end
            
            convergence = convergence + relChange;
            numFields = numFields + 1;
        end
    end
    
    if numFields > 0
        convergence = convergence / numFields;
    end
end

function sol = initialiseMultiPhysicsSolution(config, models)
    % Initialise multi-physics solution structure
    
    sol = struct();
    
    if isfield(models, 'fluid')
        sol.fluid = struct();
        sol.fluid.velocity = zeros(config.numCells, 3);
        sol.fluid.pressure = zeros(config.numCells, 1);
        sol.fluid.density = ones(config.numCells, 1) * 1.225;  % Air at STP
        sol.fluid.viscosity = ones(config.numCells, 1) * 1.8e-5;
    end
    
    if isfield(models, 'thermal')
        sol.thermal = struct();
        sol.thermal.temperature = ones(config.numCells, 1) * 293.15;  % 20뿯½뿯½C
    end
    
    if isfield(models, 'species')
        sol.species = struct();
        sol.species.massFraction = zeros(config.numCells, models.species.numSpecies);
        sol.species.massFraction(:, 1) = 1.0;  % Pure species 1 initially
    end
end

function convection = extractConvection(fluidSol)
    % Extract convection terms from fluid solution
    
    convection = struct();
    convection.velocity = fluidSol.velocity;
    convection.density = fluidSol.density;
end

function rho = computeDensity(T, p)
    % Compute density from temperature and pressure (ideal gas)
    
    R_specific = 287.05;  % J/(kg뿯½뿯½K) for air
    rho = p ./ (R_specific * T);
end

function mu = computeViscosity(T)
    % Compute dynamic viscosity using Sutherland's law
    
    T_ref = 273.15;  % K
    mu_ref = 1.716e-5;  % Pa뿯½뿯½s
    S = 110.4;  % K
    
    mu = mu_ref * (T/T_ref).^1.5 .* (T_ref + S) ./ (T + S);
end
