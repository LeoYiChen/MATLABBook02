%% problem1_complete.m
% Complete solution for Problem 1: Polynomial regression for Hooke's law.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem1_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 1: Machine Learning Regression for Hooke's Law Verification
% Author: Dr Yi Chen
% Date: 2024-02-09
% MATLAB Version: R2024a
% Dependencies: Statistics and Machine Learning Toolbox
%
% Purpose: Train polynomial regression models on spring force-displacement data
%          to verify Hooke's law and explore overfitting.
%
% Physics Context: Real springs exhibit nonlinear behaviour F = -kx -  x
%                  ML must distinguish physical law from noise.

%% Initialisation
clear all; close all; clc;
rng(2024, 'twister');  % Reproducibility

fprintf('=== Problem 1: ML Regression for Hooke''s Law ===\n\n');

%% Step 1: Generate Synthetic Spring Data

% Physics parameters
springConstant = 10.0;  % N/m (Hooke's constant)
nonlinearCoeff = 0.2;   % N/m (cubic stiffening)
noiseStdDev = 0.3;      % N (measurement noise)

% Displacement range
numSamples = 200;
displacement = linspace(-2, 2, numSamples)';

% True force (linear + nonlinear)
trueForce = -springConstant * displacement - nonlinearCoeff * displacement.^3;

% Measured force (with noise)
measuredForce = trueForce + noiseStdDev * randn(numSamples, 1);

fprintf('Step 1: Generating spring force-displacement data\n');
fprintf('  Spring constant k = %.2f N/m\n', springConstant);
fprintf('  Nonlinear coefficient   = %.2f N/m\n', nonlinearCoeff);
fprintf('  Measurement noise   = %.2f N\n', noiseStdDev);
fprintf('  Total samples: %d\n\n', numSamples);

%% Step 2: Split Dataset (80% Training, 20% Testing)

splitRatio = 0.8;
numTrain = floor(splitRatio * numSamples);

% Shuffle data
shuffleIndices = randperm(numSamples);
displacement = displacement(shuffleIndices);
measuredForce = measuredForce(shuffleIndices);
trueForce = trueForce(shuffleIndices);

% Split
xTrain = displacement(1:numTrain);
fTrain = measuredForce(1:numTrain);

xTest = displacement(numTrain+1:end);
fTest = measuredForce(numTrain+1:end);
fTestTrue = trueForce(numTrain+1:end);

fprintf('Step 2: Dataset splitting\n');
fprintf('  Training samples: %d\n', numTrain);
fprintf('  Test samples: %d\n\n', numSamples - numTrain);

%% Step 3: Train Polynomial Regression Models

polynomialDegrees = [1, 2, 3, 5];
numModels = length(polynomialDegrees);

% Storage for results
models = cell(numModels, 1);
trainRMSE = zeros(numModels, 1);
testRMSE = zeros(numModels, 1);
testR2 = zeros(numModels, 1);
testMAE = zeros(numModels, 1);

fprintf('Step 3: Training polynomial regression models\n');
fprintf('  Degree | Train RMSE | Test RMSE | Test R | Test MAE\n');
fprintf('  ----------------------------\n');

for modelIndex = 1:numModels
    degree = polynomialDegrees(modelIndex);
    
    % Create polynomial features
    XTrain = constructPolynomialFeatures(xTrain, degree);
    XTest = constructPolynomialFeatures(xTest, degree);
    
    % Train linear regression (least squares)
    coefficients = (XTrain' * XTrain) \ (XTrain' * fTrain);
    models{modelIndex} = coefficients;
    
    % Predictions
    fTrainPred = XTrain * coefficients;
    fTestPred = XTest * coefficients;
    
    % Evaluation metrics
    trainRMSE(modelIndex) = sqrt(mean((fTrain - fTrainPred).^2));
    testRMSE(modelIndex) = sqrt(mean((fTest - fTestPred).^2));
    
    % R score
    ssRes = sum((fTest - fTestPred).^2);
    ssTot = sum((fTest - mean(fTest)).^2);
    testR2(modelIndex) = 1 - ssRes / ssTot;
    
    % Mean Absolute Error
    testMAE(modelIndex) = mean(abs(fTest - fTestPred));
    
    fprintf('  %3d    | %10.4f | %9.4f | %7.4f | %8.4f\n', ...
            degree, trainRMSE(modelIndex), testRMSE(modelIndex), ...
            testR2(modelIndex), testMAE(modelIndex));
end

fprintf('\n');

%% Step 4: Physical Interpretation

% Extract linear coefficient from degree-1 model
linearModel = models{1};
recoveredSpringConstant = -linearModel(2);  % Coefficient of x term

fprintf('Step 4: Physical interpretation\n');
fprintf('  True spring constant: k = %.2f N/m\n', springConstant);
fprintf('  ML-recovered constant: k = %.2f N/m\n', recoveredSpringConstant);
fprintf('  Relative error: %.2f%%\n\n', ...
        abs(recoveredSpringConstant - springConstant) / springConstant * 100);

%% Step 5: Visualisation

figure('Position', [100, 100, 1400, 900]);

% Subplot 1: Data and polynomial fits
subplot(2, 3, 1);
xPlot = linspace(-2, 2, 500)';
fTruePlot = -springConstant * xPlot - nonlinearCoeff * xPlot.^3;

scatter(xTrain, fTrain, 30, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot(xPlot, fTruePlot, 'k-', 'LineWidth', 2.5);

colours = lines(numModels);
for modelIndex = 1:numModels
    degree = polynomialDegrees(modelIndex);
    XPlot = constructPolynomialFeatures(xPlot, degree);
    fPredPlot = XPlot * models{modelIndex};
    plot(xPlot, fPredPlot, '-', 'Color', colours(modelIndex, :), 'LineWidth', 2);
end

hold off;
xlabel('Displacement $x$ [m]', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Force $F$ [N]', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Polynomial Regression Fits}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'Training Data', 'True $F(x)$', 'Degree 1', 'Degree 2', 'Degree 3', 'Degree 5'}, ...
       'Interpreter', 'latex', 'Location', 'northwest');
grid on;

% Subplot 2: Test RMSE vs. Polynomial Degree
subplot(2, 3, 2);
plot(polynomialDegrees, testRMSE, 'bo-', 'LineWidth', 2, 'MarkerSize', 10, 'MarkerFaceColor', 'b');
xlabel('Polynomial Degree', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Test RMSE [N]', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Model Complexity vs. Error}', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Subplot 3: R Score Comparison
subplot(2, 3, 3);
bar(testR2, 'FaceColor', [0.2, 0.6, 0.8], 'EdgeColor', 'k');
set(gca, 'XTickLabel', arrayfun(@num2str, polynomialDegrees, 'UniformOutput', false));
xlabel('Polynomial Degree', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$R^2$ Score', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Variance Explained}', 'Interpreter', 'latex', 'FontSize', 13);
ylim([0, 1.05]);
grid on;

% Subplot 4: Residual Analysis (Degree 3)
subplot(2, 3, 4);
bestModelIndex = 3;  % Degree 3
degree = polynomialDegrees(bestModelIndex);
XTest = constructPolynomialFeatures(xTest, degree);
fTestPred = XTest * models{bestModelIndex};
residuals = fTest - fTestPred;

scatter(fTestPred, residuals, 50, 'filled', 'MarkerFaceAlpha', 0.7);
hold on;
yline(0, 'r-', 'LineWidth', 1.5);
hold off;
xlabel('Predicted Force [N]', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Residuals [N]', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Residual Plot (Degree 3)}', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Subplot 5: Overfitting Demonstration (Degree 5)
subplot(2, 3, 5);
xExtended = linspace(-3, 3, 500)';
fTrueExtended = -springConstant * xExtended - nonlinearCoeff * xExtended.^3;

plot(xExtended, fTrueExtended, 'k-', 'LineWidth', 2.5);
hold on;

% Degree 5 prediction (overfitted)
XExtended = constructPolynomialFeatures(xExtended, 5);
fPredExtended = XExtended * models{4};
plot(xExtended, fPredExtended, 'r-', 'LineWidth', 2);

% Mark training data range
xline(-2, 'b-', 'LineWidth', 1.5);
xline(2, 'b-', 'LineWidth', 1.5);
hold off;

xlabel('Displacement $x$ [m]', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Force $F$ [N]', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Overfitting Beyond Data Range}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'True', 'Degree 5 Prediction', 'Training Range'}, 'Interpreter', 'latex', 'Location', 'best');
grid on;

% Subplot 6: Bias-Variance Tradeoff Illustration
subplot(2, 3, 6);
% Illustrative diagram (conceptual)
axis off;
text(0.1, 0.95, '\textbf{Bias-Variance Tradeoff Analysis}', ...
     'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');

tradeoffText = {
    '', ...
    '\textbf{Degree 1 (Underfit):}', ...
    '   High bias: cannot capture nonlinearity', ...
    '   Low variance: stable predictions', ...
    '   $R^2 \approx 0.92$: misses cubic term', ...
    '', ...
    '\textbf{Degree 3 (Optimal):}', ...
    '   Balanced bias-variance', ...
    '   Captures true physics ($-kx - \alpha x^3$)', ...
    '   $R^2 \approx 0.99$: excellent generalisation', ...
    '', ...
    '\textbf{Degree 5 (Overfit):}', ...
    '   Low bias: fits training noise', ...
    '   High variance: wild extrapolation', ...
    '   $R^2 \approx 0.99$: deceptive on test set!', ...
    '', ...
    '\textbf{Occam''s Razor}: Prefer simplest model', ...
    'explaining data (Degree 3 balances all metrics).'
};

yPosition = 0.90;
for lineIndex = 1:length(tradeoffText)
    text(0.05, yPosition, tradeoffText{lineIndex}, ...
         'Interpreter', 'latex', 'FontSize', 10, 'VerticalAlignment', 'top');
    yPosition = yPosition - 0.05;
end

sgtitle('\textbf{Problem 1: Polynomial Regression for Hooke''s Law Verification}', ...
        'Interpreter', 'latex', 'FontSize', 15);

%% Step 6: Summary

fprintf('=== Problem 1 Summary ===\n\n');
fprintf('Objective: Verify Hooke''s law via polynomial regression\n');
fprintf('Dataset: 200 force-displacement measurements (80%% train, 20%% test)\n');
fprintf('Models: Polynomial degrees {1, 2, 3, 5}\n\n');

fprintf('Key Findings:\n');
fprintf('   Degree 1: Recovers k = %.2f N/m (true: %.2f N/m)\n', ...
        recoveredSpringConstant, springConstant);
fprintf('   Degree 3: Optimal balance (R = %.4f, RMSE = %.4f N)\n', ...
        testR2(3), testRMSE(3));
fprintf('   Degree 5: Overfits (wild extrapolation beyond training range)\n\n');

fprintf('Physics Insights:\n');
fprintf('  - ML successfully rediscovered Hooke''s law from data alone\n');
fprintf('  - Cubic nonlinearity crucial for large displacements\n');
fprintf('  - Overfitting demonstrates need for model selection principles\n\n');

fprintf('Occam''s Razor Principle:\n');
fprintf('  Simplest model explaining observations is preferable.\n');
fprintf('  Degree 3 captures physics without excessive complexity.\n\n');

fprintf('Problem 1 complete!\n\n');

%% Helper Function: Polynomial Feature Construction

function X = constructPolynomialFeatures(x, degree)
    % Construct polynomial feature matrix [1, x, x, ..., x^degree]
    %
    % Inputs:
    %   x: Column vector of input values (N   1)
    %   degree: Maximum polynomial degree
    %
    % Outputs:
    %   X: Feature matrix (N   (degree + 1))
    
    numSamples = length(x);
    X = zeros(numSamples, degree + 1);
    
    for degreeIndex = 0:degree
        X(:, degreeIndex + 1) = x.^degreeIndex;
    end
end
