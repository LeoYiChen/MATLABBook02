%% Appendix02-FAQs_code_039.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLAB Code for Local Magnification of Line Plots

% Add magnify.m to MATLAB search path or current working directory
% After completing the basic drawing, enter the following two lines of code
magnify(gcf);

% Example usage with a line plot
clc;
clear;
close all;

% Data
x = linspace(0, 10, 100);
y = sin(x);

% Main axes
figure;
plot(x, y, 'LineWidth', 2);
xlabel('X-axis');
ylabel('Y-axis');
title('Line Plot with Local Magnification');

% Enable magnification
magnify(gcf);
