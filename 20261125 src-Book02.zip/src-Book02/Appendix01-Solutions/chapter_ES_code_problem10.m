%% chapter_ES_code_problem10.m
% Decentralised Gradient Descent
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem10
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem10
    % MATLABBook_ChapterES_Problem10.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Decentralised gradient descent for distributed optimization.
    %   Compares different network topologies and analyzes consensus
    %   dynamics, convergence rates, and communication efficiency.
    %
    % Dependencies: None (base MATLAB)
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 10
    
    fprintf('\n=== Problem 10: Decentralised Gradient Descent ===\n\n');
    
    %% Problem Setup
    
    % Number of agents and dimension
    n_agents = 20;
    dim = 10;
    
    % Generate random quadratic objectives for each agent
    % f_i(x) = 0.5 * x^T * A_i * x + b_i^T * x + c_i
    
    rng(42);  % Reproducibility
    
    A_agents = cell(n_agents, 1);
    b_agents = cell(n_agents, 1);
    c_agents = zeros(n_agents, 1);
    
    for i = 1:n_agents
        % Generate positive definite matrix (well-conditioned)
        Q = randn(dim, dim);
        A_agents{i} = Q' * Q + eye(dim);  % Ensure positive definite
        
        b_agents{i} = randn(dim, 1);
        c_agents(i) = randn();
    end
    
    % Global objective: average of local objectives
    A_global = zeros(dim, dim);
    b_global = zeros(dim, 1);
    c_global = 0;
    
    for i = 1:n_agents
        A_global = A_global + A_agents{i} / n_agents;
        b_global = b_global + b_agents{i} / n_agents;
        c_global = c_global + c_agents(i) / n_agents;
    end
    
    % Compute optimal solution (centralized)
    x_opt = -A_global \ b_global;
    f_opt = 0.5 * x_opt' * A_global * x_opt + b_global' * x_opt + c_global;
    
    fprintf('Problem setup:\n');
    fprintf('  Number of agents: %d\n', n_agents);
    fprintf('  Problem dimension: %d\n', dim);
    fprintf('  Optimal objective: %.4f\n\n', f_opt);
    
    % Compute problem characteristics
    eigs_A = eig(A_global);
    condition_number = max(eigs_A) / min(eigs_A);
    L_smooth = max(eigs_A);  % Lipschitz constant of gradient
    
    fprintf('Problem characteristics:\n');
    fprintf('  Condition number: %.2f\n', condition_number);
    fprintf('  Lipschitz constant: %.2f\n', L_smooth);
    fprintf('  Suggested step size (1/L): %.4f\n\n', 1/L_smooth);
    
    %% Graph Topologies
    
    fprintf('=== Graph Topologies ===\n');
    
    % Define multiple topologies for comparison
    topologies = {'ring', 'grid', 'complete', 'random'};
    n_topologies = length(topologies);
    
    adjacency_matrices = cell(n_topologies, 1);
    weight_matrices = cell(n_topologies, 1);
    spectral_gaps = zeros(n_topologies, 1);
    
    for t = 1:n_topologies
        topology = topologies{t};
        
        switch topology
            case 'ring'
                % Ring topology: each agent connects to 2 neighbors
                A = diag(ones(n_agents-1, 1), 1) + diag(ones(n_agents-1, 1), -1);
                A(1, n_agents) = 1;
                A(n_agents, 1) = 1;
                
            case 'grid'
                % 2D grid (approximate sqrt(n)   sqrt(n))
                grid_size = ceil(sqrt(n_agents));
                A = zeros(n_agents, n_agents);
                
                for i = 1:n_agents
                    row = floor((i-1) / grid_size);
                    col = mod(i-1, grid_size);
                    
                    % Right neighbor
                    if col < grid_size - 1 && i + 1 <= n_agents
                        A(i, i+1) = 1;
                        A(i+1, i) = 1;
                    end
                    
                    % Down neighbor
                    if row < grid_size - 1 && i + grid_size <= n_agents
                        A(i, i+grid_size) = 1;
                        A(i+grid_size, i) = 1;
                    end
                end
                
            case 'complete'
                % Complete graph: all agents connected
                A = ones(n_agents, n_agents) - eye(n_agents);
                
            case 'random'
                % Random graph (Erds-R nyi with p=0.3)
                p_edge = 0.3;
                A = rand(n_agents, n_agents) < p_edge;
                A = double(A | A');  % Make symmetric
                A = A - diag(diag(A));  % Remove self-loops
                
                % Ensure connectivity (add edges if needed)
                while ~is_connected(A)
                    % Add random edge
                    i = randi(n_agents);
                    j = randi(n_agents);
                    if i ~= j
                        A(i, j) = 1;
                        A(j, i) = 1;
                    end
                end
        end
        
        adjacency_matrices{t} = A;
        
        % Compute weight matrix (Metropolis-Hastings)
        W = compute_weight_matrix(A);
        weight_matrices{t} = W;
        
        % Compute spectral gap
        eigenvalues = sort(eig(W), 'descend');
        spectral_gaps(t) = 1 - eigenvalues(2);
        
        fprintf('%s topology:\n', upper(topology));
        fprintf('  Edges: %d\n', sum(A(:))/2);
        fprintf('  Average degree: %.1f\n', sum(A(:))/n_agents);
        fprintf('  Spectral gap: %.4f\n', spectral_gaps(t));
        fprintf('  Mixing time estimate: %.1f iterations\n\n', 1/spectral_gaps(t));
    end
    
    %% Centralized Gradient Descent (Baseline)
    
    fprintf('=== Method 1: Centralized Gradient Descent ===\n');
    
    max_iter = 500;
    step_size = 0.5 / L_smooth;  % Conservative step size
    
    % Initialize at origin
    x_cent = zeros(dim, 1);
    
    % Storage
    f_cent_hist = zeros(max_iter, 1);
    
    for k = 1:max_iter
        % Compute global gradient
        grad = A_global * x_cent + b_global;
        
        % Gradient descent step
        x_cent = x_cent - step_size * grad;
        
        % Evaluate objective
        f_cent_hist(k) = 0.5 * x_cent' * A_global * x_cent + ...
                         b_global' * x_cent + c_global;
    end
    
    fprintf('Centralized GD:\n');
    fprintf('  Final objective: %.6f\n', f_cent_hist(end));
    fprintf('  Optimality gap: %.2e\n\n', f_cent_hist(end) - f_opt);
    
    %% Decentralised Gradient Descent
    
    fprintf('=== Method 2: Decentralised Gradient Descent ===\n');
    
    % We'll run DGD for each topology
    
    x_decentral = cell(n_topologies, 1);
    f_decentral_hist = zeros(max_iter, n_topologies);
    consensus_error_hist = zeros(max_iter, n_topologies);
    
    for t = 1:n_topologies
        fprintf('Running DGD with %s topology...\n', topologies{t});
        
        W = weight_matrices{t};
        
        % Initialize each agent at random
        X = randn(dim, n_agents);
        
        for k = 1:max_iter
            % Store current state
            X_old = X;
            
            % Each agent updates
            for i = 1:n_agents
                % Consensus step: weighted average of neighbors
                x_consensus = zeros(dim, 1);
                for j = 1:n_agents
                    if W(i, j) > 0
                        x_consensus = x_consensus + W(i, j) * X_old(:, j);
                    end
                end
                
                % Local gradient
                grad_i = A_agents{i} * X_old(:, i) + b_agents{i};
                
                % Update
                X(:, i) = x_consensus - step_size * grad_i;
            end
            
            % Compute average of all agents' parameters
            x_avg = mean(X, 2);
            
            % Evaluate global objective at average
            f_decentral_hist(k, t) = 0.5 * x_avg' * A_global * x_avg + ...
                                     b_global' * x_avg + c_global;
            
            % Consensus error: average distance to mean
            consensus_error_hist(k, t) = 0;
            for i = 1:n_agents
                consensus_error_hist(k, t) = consensus_error_hist(k, t) + ...
                                             norm(X(:, i) - x_avg)^2;
            end
            consensus_error_hist(k, t) = sqrt(consensus_error_hist(k, t) / n_agents);
        end
        
        x_decentral{t} = mean(X, 2);
        
        fprintf('  Final objective: %.6f\n', f_decentral_hist(end, t));
        fprintf('  Final consensus error: %.2e\n', consensus_error_hist(end, t));
    end
    
    fprintf('\n');
    
    %% Communication Cost Analysis
    
    fprintf('=== Communication Cost Analysis ===\n');
    
    % Messages per iteration for each topology
    messages_per_iter = zeros(n_topologies, 1);
    
    for t = 1:n_topologies
        A = adjacency_matrices{t};
        messages_per_iter(t) = sum(A(:));  % Each edge = 2 messages (bidirectional)
    end
    
    fprintf('Messages per iteration:\n');
    for t = 1:n_topologies
        fprintf('  %s: %d messages (%.1f per agent)\n', ...
                upper(topologies{t}), messages_per_iter(t), ...
                messages_per_iter(t) / n_agents);
    end
    
    % Compare to centralized (star topology)
    messages_centralized = 2 * n_agents;  % All-to-one-to-all
    fprintf('  Centralized: %d messages (%.1f per agent)\n\n', ...
            messages_centralized, messages_centralized / n_agents);
    
    %% Convergence Rate Analysis
    
    fprintf('=== Convergence Rate Analysis ===\n');
    
    % Fit convergence rate: log(f - f_opt) vs log(k)
    k_range = 50:max_iter;
    
    for t = 1:n_topologies
        opt_gap = f_decentral_hist(k_range, t) - f_opt;
        opt_gap = max(opt_gap, 1e-12);  % Avoid log(0)
        
        % Linear fit in log-log scale
        p = polyfit(log(k_range), log(opt_gap), 1);
        empirical_rate = -p(1);  % Exponent
        
        fprintf('%s topology:\n', upper(topologies{t}));
        fprintf('  Empirical convergence rate: O(k^{%.2f})\n', empirical_rate);
        fprintf('  Theoretical rate: O(k^{-0.5}) for convex\n');
        fprintf('  Spectral gap: %.4f\n', spectral_gaps(t));
    end
    
    fprintf('\n');
    
    %% Visualization
    
    fprintf('Generating visualizations...\n');
    
    % Figure 1: Network topologies
    figure('Position', [50 50 1400 900]);
    
    for t = 1:n_topologies
        subplot(2, n_topologies, t);
        
        % Graph layout
        A = adjacency_matrices{t};
        G = graph(A);
        
        plot(G, 'Layout', 'force', 'NodeColor', [0.3 0.6 0.9], ...
             'EdgeColor', [0.5 0.5 0.5], 'LineWidth', 1.5, ...
             'MarkerSize', 8);
        
        title(sprintf('%s (Gap=%.3f)', upper(topologies{t}), spectral_gaps(t)), ...
              'Interpreter', 'latex');
        axis off;
        
        % Degree distribution
        subplot(2, n_topologies, n_topologies + t);
        degree = sum(A, 2);
        histogram(degree, 'BinWidth', 1, 'FaceColor', [0.8 0.4 0.4]);
        xlabel('Degree', 'Interpreter', 'latex');
        ylabel('Count', 'Interpreter', 'latex');
        title('Degree Distribution', 'Interpreter', 'latex');
        grid on;
    end
    
    sgtitle('Network Topologies and Properties', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    % Figure 2: Convergence comparison
    figure('Position', [100 100 1400 900]);
    
    % Subplot 1: Objective vs iterations (linear scale)
    subplot(2, 3, 1);
    plot(1:max_iter, f_cent_hist, 'k-', 'LineWidth', 2, 'DisplayName', 'Centralized');
    hold on;
    for t = 1:n_topologies
        plot(1:max_iter, f_decentral_hist(:, t), 'LineWidth', 1.5, ...
             'DisplayName', upper(topologies{t}));
    end
    yline(f_opt, 'r:', 'LineWidth', 1.5, 'DisplayName', 'Optimal');
    hold off;
    xlabel('Iteration', 'Interpreter', 'latex');
    ylabel('Objective Value', 'Interpreter', 'latex');
    title('Convergence (Linear Scale)', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 max_iter]);
    
    % Subplot 2: Optimality gap (log scale)
    subplot(2, 3, 2);
    semilogy(1:max_iter, max(f_cent_hist - f_opt, 1e-12), 'k-', 'LineWidth', 2, ...
             'DisplayName', 'Centralized');
    hold on;
    for t = 1:n_topologies
        semilogy(1:max_iter, max(f_decentral_hist(:, t) - f_opt, 1e-12), ...
                 'LineWidth', 1.5, 'DisplayName', upper(topologies{t}));
    end
    hold off;
    xlabel('Iteration', 'Interpreter', 'latex');
    ylabel('Optimality Gap', 'Interpreter', 'latex');
    title('Convergence (Log Scale)', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 max_iter]);
    
    % Subplot 3: Consensus error
    subplot(2, 3, 3);
    for t = 1:n_topologies
        semilogy(1:max_iter, consensus_error_hist(:, t), 'LineWidth', 1.5, ...
                 'DisplayName', upper(topologies{t}));
        hold on;
    end
    hold off;
    xlabel('Iteration', 'Interpreter', 'latex');
    ylabel('Consensus Error', 'Interpreter', 'latex');
    title('Consensus Dynamics', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 max_iter]);
    
    % Subplot 4: Spectral gap vs convergence speed
    subplot(2, 3, 4);
    
    % Compute convergence speed (iterations to reach 0.01 gap)
    convergence_iters = zeros(n_topologies, 1);
    for t = 1:n_topologies
        idx = find(f_decentral_hist(:, t) - f_opt < 0.01, 1, 'first');
        if ~isempty(idx)
            convergence_iters(t) = idx;
        else
            convergence_iters(t) = max_iter;
        end
    end
    
    scatter(spectral_gaps, convergence_iters, 100, 'filled');
    xlabel('Spectral Gap $\gamma$', 'Interpreter', 'latex');
    ylabel('Iterations to 0.01 Gap', 'Interpreter', 'latex');
    title('Spectral Gap vs Speed', 'Interpreter', 'latex');
    grid on;
    
    % Add topology labels
    for t = 1:n_topologies
        text(spectral_gaps(t), convergence_iters(t), sprintf('  %s', upper(topologies{t}(1))), ...
             'FontSize', 10);
    end
    
    % Subplot 5: Communication cost vs performance
    subplot(2, 3, 5);
    
    % Final optimality gap
    final_gaps = f_decentral_hist(end, :) - f_opt;
    
    scatter(messages_per_iter, final_gaps, 100, 'filled');
    xlabel('Messages per Iteration', 'Interpreter', 'latex');
    ylabel('Final Optimality Gap', 'Interpreter', 'latex');
    title('Communication Cost Trade-off', 'Interpreter', 'latex');
    grid on;
    set(gca, 'YScale', 'log');
    
    for t = 1:n_topologies
        text(messages_per_iter(t), final_gaps(t), sprintf('  %s', upper(topologies{t}(1))), ...
             'FontSize', 10);
    end
    
    % Subplot 6: Efficiency frontier
    subplot(2, 3, 6);
    
    % Compute total communication for convergence
    total_comm = messages_per_iter .* convergence_iters;
    
    bar(categorical(upper(topologies)), total_comm, 'FaceColor', [0.3 0.7 0.3]);
    ylabel('Total Messages to Convergence', 'Interpreter', 'latex');
    title('Communication Efficiency', 'Interpreter', 'latex');
    grid on;
    
    sgtitle('Decentralised Gradient Descent Analysis', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Figures generated.\n\n');
end

%% Helper Functions

function connected = is_connected(A)
    % Check if graph is connected using BFS
    n = size(A, 1);
    visited = false(n, 1);
    queue = 1;
    visited(1) = true;
    
    while ~isempty(queue)
        node = queue(1);
        queue(1) = [];
        
        neighbors = find(A(node, :));
        for j = 1:length(neighbors)
            if ~visited(neighbors(j))
                visited(neighbors(j)) = true;
                queue = [queue, neighbors(j)];
            end
        end
    end
    
    connected = all(visited);
end

function W = compute_weight_matrix(A)
    % Compute doubly stochastic weight matrix using Metropolis-Hastings
    n = size(A, 1);
    W = zeros(n, n);
    
    for i = 1:n
        degree_i = sum(A(i, :));
        
        for j = 1:n
            if i == j
                % Self-weight: 1 - sum of neighbor weights
                W(i, i) = 1 - sum(W(i, :));
            elseif A(i, j) == 1
                degree_j = sum(A(j, :));
                W(i, j) = 1 / (1 + max(degree_i, degree_j));
            end
        end
    end
    
    % Ensure exactly doubly stochastic (correct numerical errors)
    W = (W + W') / 2;  % Make symmetric
    row_sums = sum(W, 2);
    W = W ./ row_sums;  % Normalize rows
end
