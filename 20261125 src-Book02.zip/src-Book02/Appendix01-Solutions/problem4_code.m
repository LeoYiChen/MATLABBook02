%% problem4_code.m
% Adversarial Robustness for PV Fault Detection
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem4_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Adversarial Robustness Testing for PV Panel Fault Detection
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-17
% Description: Implements FGSM and PGD adversarial attacks against PV fault
%              classifier, evaluates robustness through adversarial training

clear; close all; clc;

%% 1. Synthetic PV I-V Curve Dataset Generation
fprintf('========================================\n');
fprintf('Adversarial Robustness - PV Fault Detection\n');
fprintf('========================================\n\n');

fprintf('Step 1: Generating synthetic PV I-V curve dataset...\n');

rng(789); % Reproducibility

numPanels = 500;
numPoints = 10; % I-V curve measurement points
faultTypes = {'Healthy', 'Partial Shading', 'Soiling', 'Hotspot', 'Cell Crack'};
numClasses = length(faultTypes);
samplesPerClass = numPanels / numClasses;

% Generate I-V curves for each fault type
voltagePoints = linspace(0, 40, numPoints); % Voltage range (V)

data = [];
labels = [];

for classIdx = 1:numClasses
    for sampleIdx = 1:samplesPerClass
        % Base I-V curve parameters
        Isc = 8 + 0.5 * randn(); % Short-circuit current (A)
        Voc = 38 + 2 * randn(); % Open-circuit voltage (V)
        
        % Fault-specific modifications
        switch classIdx
            case 1 % Healthy
                current = Isc * (1 - (voltagePoints / Voc).^1.2);
                
            case 2 % Partial Shading (reduced current, stepped)
                shadingFactor = 0.5 + 0.2 * rand();
                stepVoltage = 20 + 5 * randn();
                current = Isc * (1 - (voltagePoints / Voc).^1.2);
                current(voltagePoints > stepVoltage) = current(voltagePoints > stepVoltage) * shadingFactor;
                
            case 3 % Soiling (uniform current reduction)
                soilingFactor = 0.7 + 0.15 * rand();
                current = Isc * soilingFactor * (1 - (voltagePoints / Voc).^1.2);
                
            case 4 % Hotspot (localized current drop)
                current = Isc * (1 - (voltagePoints / Voc).^1.2);
                hotspotLocation = randi([3, 7]);
                current(hotspotLocation) = current(hotspotLocation) * (0.3 + 0.2 * rand());
                
            case 5 % Cell Crack (irregular current pattern)
                current = Isc * (1 - (voltagePoints / Voc).^1.2);
                crackNoise = 0.3 * randn(1, numPoints);
                current = current + crackNoise;
        end
        
        % Add measurement noise
        current = current + 0.1 * randn(1, numPoints);
        current = max(current, 0); % Ensure non-negative
        
        % Store data (current values as features)
        data = [data; current];
        labels = [labels; classIdx];
    end
end

fprintf('Generated %d I-V curves across %d fault types\n', numPanels, numClasses);
fprintf('Feature dimensionality: %d current measurements per curve\n\n', numPoints);

%% 2. Data Partitioning and Normalisation
fprintf('Step 2: Partitioning and normalising dataset...\n');

% Split into train (70%) and test (30%)
cv = cvpartition(labels, 'HoldOut', 0.3);
trainIdx = training(cv);
testIdx = test(cv);

XTrain = data(trainIdx, :);
YTrain = labels(trainIdx);
XTest = data(testIdx, :);
YTest = labels(testIdx);

% Normalise features (zero mean, unit variance)
[XTrain, muTrain, sigmaTrain] = zscore(XTrain);
XTest = (XTest - muTrain) ./ sigmaTrain;

fprintf('Training set: %d samples, Test set: %d samples\n\n', size(XTrain, 1), size(XTest, 1));

%% 3. Baseline Classifier Training
fprintf('Step 3: Training baseline neural network classifier...\n');

% Simple feedforward neural network
hiddenLayerSize = 20;

% Create network
net = feedforwardnet(hiddenLayerSize, 'trainlm');
net.trainParam.showWindow = false;
net.trainParam.epochs = 200;
net.divideParam.trainRatio = 0.8;
net.divideParam.valRatio = 0.2;
net.divideParam.testRatio = 0;

% Train network
[net, tr] = train(net, XTrain', YTrain');

% Evaluate on clean test data
YTestPred = net(XTest');
[~, YTestPredClass] = max(YTestPred, [], 1);
YTestPredClass = YTestPredClass';

cleanAccuracy = sum(YTestPredClass == YTest) / length(YTest);

fprintf('Baseline classifier trained (2-layer MLP, %d hidden units)\n', hiddenLayerSize);
fprintf('Clean test accuracy: %.2f%%\n\n', cleanAccuracy * 100);

%% 4. FGSM Attack Implementation
fprintf('Step 4: Implementing Fast Gradient Sign Method (FGSM) attack...\n');

% FGSM parameters
epsilonValues = [0.01, 0.05, 0.1, 0.2, 0.5];
numEpsilons = length(epsilonValues);

fgsmResults = struct();

for epsIdx = 1:numEpsilons
    epsilon = epsilonValues(epsIdx);
    
    % Generate adversarial examples for test set
    XTestAdv = zeros(size(XTest));
    
    for sampleIdx = 1:size(XTest, 1)
        x = XTest(sampleIdx, :)';
        yTrue = YTest(sampleIdx);
        
        % Forward pass
        yPred = net(x);
        
        % Create target vector (one-hot encoding)
        yTarget = zeros(numClasses, 1);
        yTarget(yTrue) = 1;
        
        % Compute gradient (numerical approximation)
        delta = 1e-6;
        gradient = zeros(size(x));
        
        for featureIdx = 1:length(x)
            xPerturbed = x;
            xPerturbed(featureIdx) = xPerturbed(featureIdx) + delta;
            yPerturbedPlus = net(xPerturbed);
            
            xPerturbed = x;
            xPerturbed(featureIdx) = xPerturbed(featureIdx) - delta;
            yPerturbedMinus = net(xPerturbed);
            
            % Loss gradient (cross-entropy)
            lossPlus = -sum(yTarget .* log(yPerturbedPlus + 1e-8));
            lossMinus = -sum(yTarget .* log(yPerturbedMinus + 1e-8));
            
            gradient(featureIdx) = (lossPlus - lossMinus) / (2 * delta);
        end
        
        % FGSM perturbation
        perturbation = epsilon * sign(gradient);
        xAdv = x + perturbation;
        
        XTestAdv(sampleIdx, :) = xAdv';
    end
    
    % Evaluate adversarial accuracy
    YTestAdvPred = net(XTestAdv');
    [~, YTestAdvPredClass] = max(YTestAdvPred, [], 1);
    YTestAdvPredClass = YTestAdvPredClass';
    
    advAccuracy = sum(YTestAdvPredClass == YTest) / length(YTest);
    
    fgsmResults(epsIdx).epsilon = epsilon;
    fgsmResults(epsIdx).advAccuracy = advAccuracy;
    fgsmResults(epsIdx).attackSuccess = 1 - advAccuracy;
    
    fprintf('  Epsilon = %.2f: Adversarial accuracy = %.2f%%, Attack success = %.2f%%\n', ...
            epsilon, advAccuracy * 100, (1 - advAccuracy) * 100);
end

fprintf('\n');

%% 5. PGD Attack Implementation
fprintf('Step 5: Implementing Projected Gradient Descent (PGD) attack...\n');

% PGD parameters
epsilonPGD = 0.1; % Perturbation budget
alphaStep = 0.02; % Step size
numIterations = 10;

pgdResults = struct();

% Generate PGD adversarial examples
XTestPGD = zeros(size(XTest));

for sampleIdx = 1:size(XTest, 1)
    x = XTest(sampleIdx, :)';
    yTrue = YTest(sampleIdx);
    
    % Initialize adversarial example with random perturbation
    xAdv = x + epsilonPGD * (2 * rand(size(x)) - 1);
    
    % Iterative refinement
    for iteration = 1:numIterations
        % Forward pass
        yPred = net(xAdv);
        
        % Target vector
        yTarget = zeros(numClasses, 1);
        yTarget(yTrue) = 1;
        
        % Compute gradient
        delta = 1e-6;
        gradient = zeros(size(xAdv));
        
        for featureIdx = 1:length(xAdv)
            xPerturbed = xAdv;
            xPerturbed(featureIdx) = xPerturbed(featureIdx) + delta;
            yPerturbedPlus = net(xPerturbed);
            
            xPerturbed = xAdv;
            xPerturbed(featureIdx) = xPerturbed(featureIdx) - delta;
            yPerturbedMinus = net(xPerturbed);
            
            lossPlus = -sum(yTarget .* log(yPerturbedPlus + 1e-8));
            lossMinus = -sum(yTarget .* log(yPerturbedMinus + 1e-8));
            
            gradient(featureIdx) = (lossPlus - lossMinus) / (2 * delta);
        end
        
        % Update adversarial example
        xAdv = xAdv + alphaStep * sign(gradient);
        
        % Project back to epsilon-ball
        perturbation = xAdv - x;
        perturbation = max(min(perturbation, epsilonPGD), -epsilonPGD);
        xAdv = x + perturbation;
    end
    
    XTestPGD(sampleIdx, :) = xAdv';
end

% Evaluate PGD adversarial accuracy
YTestPGDPred = net(XTestPGD');
[~, YTestPGDPredClass] = max(YTestPGDPred, [], 1);
YTestPGDPredClass = YTestPGDPredClass';

pgdAccuracy = sum(YTestPGDPredClass == YTest) / length(YTest);

pgdResults.epsilon = epsilonPGD;
pgdResults.advAccuracy = pgdAccuracy;
pgdResults.attackSuccess = 1 - pgdAccuracy;

fprintf('  PGD (epsilon=%.2f, %d iterations): Adversarial accuracy = %.2f%%\n', ...
        epsilonPGD, numIterations, pgdAccuracy * 100);
fprintf('  Attack success: %.2f%% (stronger than FGSM at same epsilon)\n\n', ...
        (1 - pgdAccuracy) * 100);

%% 6. Fault-Specific Vulnerability Analysis
fprintf('Step 6: Analysing adversarial vulnerability by fault type...\n');

vulnerabilityResults = struct();

% Use FGSM with epsilon = 0.1 for analysis
epsilonAnalysis = 0.1;

for classIdx = 1:numClasses
    classMask = YTest == classIdx;
    XTestClass = XTest(classMask, :);
    YTestClass = YTest(classMask);
    
    % Generate adversarial examples
    XTestClassAdv = zeros(size(XTestClass));
    
    for sampleIdx = 1:size(XTestClass, 1)
        x = XTestClass(sampleIdx, :)';
        yTrue = YTestClass(sampleIdx);
        
        yPred = net(x);
        yTarget = zeros(numClasses, 1);
        yTarget(yTrue) = 1;
        
        % Gradient computation (simplified)
        delta = 1e-6;
        gradient = zeros(size(x));
        
        for featureIdx = 1:length(x)
            xPerturbed = x;
            xPerturbed(featureIdx) = xPerturbed(featureIdx) + delta;
            yPerturbedPlus = net(xPerturbed);
            
            lossPlus = -sum(yTarget .* log(yPerturbedPlus + 1e-8));
            
            xPerturbed = x;
            xPerturbed(featureIdx) = xPerturbed(featureIdx) - delta;
            yPerturbedMinus = net(xPerturbed);
            
            lossMinus = -sum(yTarget .* log(yPerturbedMinus + 1e-8));
            
            gradient(featureIdx) = (lossPlus - lossMinus) / (2 * delta);
        end
        
        perturbation = epsilonAnalysis * sign(gradient);
        xAdv = x + perturbation;
        
        XTestClassAdv(sampleIdx, :) = xAdv';
    end
    
    % Evaluate class-specific adversarial accuracy
    YTestClassAdvPred = net(XTestClassAdv');
    [~, YTestClassAdvPredClass] = max(YTestClassAdvPred, [], 1);
    YTestClassAdvPredClass = YTestClassAdvPredClass';
    
    classAdvAccuracy = sum(YTestClassAdvPredClass == YTestClass) / length(YTestClass);
    
    vulnerabilityResults(classIdx).faultType = faultTypes{classIdx};
    vulnerabilityResults(classIdx).cleanAccuracy = sum(net(XTestClass') == YTestClass) / length(YTestClass);
    vulnerabilityResults(classIdx).advAccuracy = classAdvAccuracy;
    vulnerabilityResults(classIdx).vulnerabilityScore = 1 - classAdvAccuracy;
    
    fprintf('  %s: Clean = %.2f%%, Adversarial = %.2f%%, Vulnerability = %.2f%%\n', ...
            faultTypes{classIdx}, vulnerabilityResults(classIdx).cleanAccuracy * 100, ...
            classAdvAccuracy * 100, (1 - classAdvAccuracy) * 100);
end

fprintf('\n');

%% 7. Adversarial Training Defence
fprintf('Step 7: Implementing adversarial training defence...\n');

% Generate adversarial training data (augment with FGSM examples)
epsilonTrain = 0.1;
XTrainAdv = zeros(size(XTrain));

fprintf('Generating adversarial training examples...\n');

for sampleIdx = 1:size(XTrain, 1)
    x = XTrain(sampleIdx, :)';
    yTrue = YTrain(sampleIdx);
    
    yPred = net(x);
    yTarget = zeros(numClasses, 1);
    yTarget(yTrue) = 1;
    
    delta = 1e-6;
    gradient = zeros(size(x));
    
    for featureIdx = 1:length(x)
        xPerturbed = x;
        xPerturbed(featureIdx) = xPerturbed(featureIdx) + delta;
        yPerturbedPlus = net(xPerturbed);
        
        lossPlus = -sum(yTarget .* log(yPerturbedPlus + 1e-8));
        
        xPerturbed = x;
        xPerturbed(featureIdx) = xPerturbed(featureIdx) - delta;
        yPerturbedMinus = net(xPerturbed);
        
        lossMinus = -sum(yTarget .* log(yPerturbedMinus + 1e-8));
        
        gradient(featureIdx) = (lossPlus - lossMinus) / (2 * delta);
    end
    
    perturbation = epsilonTrain * sign(gradient);
    xAdv = x + perturbation;
    
    XTrainAdv(sampleIdx, :) = xAdv';
end

% Augment training set
XTrainAugmented = [XTrain; XTrainAdv];
YTrainAugmented = [YTrain; YTrain];

fprintf('Augmented training set: %d samples (50%% clean, 50%% adversarial)\n', ...
        size(XTrainAugmented, 1));

% Retrain network on augmented data
netRobust = feedforwardnet(hiddenLayerSize, 'trainlm');
netRobust.trainParam.showWindow = false;
netRobust.trainParam.epochs = 200;
netRobust.divideParam.trainRatio = 0.8;
netRobust.divideParam.valRatio = 0.2;
netRobust.divideParam.testRatio = 0;

fprintf('Training robust classifier...\n');
[netRobust, trRobust] = train(netRobust, XTrainAugmented', YTrainAugmented');

% Evaluate robust classifier
YTestPredRobust = netRobust(XTest');
[~, YTestPredRobustClass] = max(YTestPredRobust, [], 1);
YTestPredRobustClass = YTestPredRobustClass';

cleanAccuracyRobust = sum(YTestPredRobustClass == YTest) / length(YTest);

% Generate adversarial examples for robust classifier
XTestAdvRobust = zeros(size(XTest));

for sampleIdx = 1:size(XTest, 1)
    x = XTest(sampleIdx, :)';
    yTrue = YTest(sampleIdx);
    
    yPred = netRobust(x);
    yTarget = zeros(numClasses, 1);
    yTarget(yTrue) = 1;
    
    delta = 1e-6;
    gradient = zeros(size(x));
    
    for featureIdx = 1:length(x)
        xPerturbed = x;
        xPerturbed(featureIdx) = xPerturbed(featureIdx) + delta;
        yPerturbedPlus = netRobust(xPerturbed);
        
        lossPlus = -sum(yTarget .* log(yPerturbedPlus + 1e-8));
        
        xPerturbed = x;
        xPerturbed(featureIdx) = xPerturbed(featureIdx) - delta;
        yPerturbedMinus = netRobust(xPerturbed);
        
        lossMinus = -sum(yTarget .* log(yPerturbedMinus + 1e-8));
        
        gradient(featureIdx) = (lossPlus - lossMinus) / (2 * delta);
    end
    
    perturbation = epsilonAnalysis * sign(gradient);
    xAdv = x + perturbation;
    
    XTestAdvRobust(sampleIdx, :) = xAdv';
end

YTestAdvPredRobust = netRobust(XTestAdvRobust');
[~, YTestAdvPredRobustClass] = max(YTestAdvPredRobust, [], 1);
YTestAdvPredRobustClass = YTestAdvPredRobustClass';

advAccuracyRobust = sum(YTestAdvPredRobustClass == YTest) / length(YTest);

fprintf('\nRobust Classifier Performance:\n');
fprintf('  Clean accuracy: %.2f%% (baseline: %.2f%%)\n', ...
        cleanAccuracyRobust * 100, cleanAccuracy * 100);
fprintf('  Adversarial accuracy: %.2f%% (baseline: %.2f%%)\n', ...
        advAccuracyRobust * 100, fgsmResults(3).advAccuracy * 100);
fprintf('  Robustness improvement: +%.2f percentage points\n\n', ...
        (advAccuracyRobust - fgsmResults(3).advAccuracy) * 100);

%% 8. Visualisation
fprintf('Step 8: Generating visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: Attack Success Rates
fig1 = figure('Position', [100, 100, 1400, 600]);

subplot(1, 3, 1);
epsilonPlot = [fgsmResults.epsilon];
attackSuccessRates = [fgsmResults.attackSuccess] * 100;

plot(epsilonPlot, attackSuccessRates, 'ro-', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('Perturbation Budget $\varepsilon$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Attack Success Rate (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{FGSM Attack Effectiveness}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;
ylim([0, 100]);

subplot(1, 3, 2);
faultNames = categorical(faultTypes);
vulnerabilityScores = [vulnerabilityResults.vulnerabilityScore] * 100;

bar(faultNames, vulnerabilityScores, 'FaceColor', [0.8, 0.4, 0.4]);
ylabel('Vulnerability Score (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title({'\textbf{Fault-Specific Adversarial Vulnerability}', ...
           sprintf('($\\varepsilon = %.2f$)', epsilonAnalysis)}, 'Interpreter', 'latex', 'FontSize', 12);
grid on;
ylim([0, 100]);

subplot(1, 3, 3);
modelTypes = categorical({'Baseline', 'Adversarially Trained'});
cleanAcc = [cleanAccuracy, cleanAccuracyRobust] * 100;
advAcc = [fgsmResults(3).advAccuracy, advAccuracyRobust] * 100;

X = 1:2;
bar(X, [cleanAcc', advAcc']);
set(gca, 'XTickLabel', modelTypes);
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title({'\textbf{Adversarial Training Defence}', ...
           sprintf('($\\varepsilon = %.2f$)', epsilonAnalysis)}, 'Interpreter', 'latex', 'FontSize', 12);
legend('Clean', 'Adversarial', 'Interpreter', 'latex', 'Location', 'best');
grid on;
ylim([0, 100]);

sgtitle('\textbf{Adversarial Robustness Analysis - PV Fault Detection}', ...
        'Interpreter', 'latex', 'FontSize', 14);

saveas(fig1, 'figures/Problem4_Adversarial_Robustness.fig');
saveas(fig1, 'figures/Problem4_Adversarial_Robustness.eps', 'epsc');
saveas(fig1, 'figures/Problem4_Adversarial_Robustness.jpg');
fprintf('Saved: Problem4_Adversarial_Robustness\n');

% Figure 2: Example Adversarial Perturbation
fig2 = figure('Position', [150, 150, 1200, 500]);

% Select example from test set
exampleIdx = find(YTest == 1, 1, 'first'); % Healthy panel
xClean = XTest(exampleIdx, :);

% Generate adversarial example
x = xClean';
yTrue = YTest(exampleIdx);
yPred = net(x);
yTarget = zeros(numClasses, 1);
yTarget(yTrue) = 1;

delta = 1e-6;
gradient = zeros(size(x));

for featureIdx = 1:length(x)
    xPerturbed = x;
    xPerturbed(featureIdx) = xPerturbed(featureIdx) + delta;
    yPerturbedPlus = net(xPerturbed);
    
    lossPlus = -sum(yTarget .* log(yPerturbedPlus + 1e-8));
    
    xPerturbed = x;
    xPerturbed(featureIdx) = xPerturbed(featureIdx) - delta;
    yPerturbedMinus = net(xPerturbed);
    
    lossMinus = -sum(yTarget .* log(yPerturbedMinus + 1e-8));
    
    gradient(featureIdx) = (lossPlus - lossMinus) / (2 * delta);
end

epsilonViz = 0.1;
perturbation = epsilonViz * sign(gradient);
xAdv = x + perturbation;

subplot(1, 3, 1);
plot(1:numPoints, xClean, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Measurement Point', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Normalised Current', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Clean I-V Curve}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

subplot(1, 3, 2);
plot(1:numPoints, perturbation, 'r-s', 'LineWidth', 2, 'MarkerSize', 6);
xlabel('Measurement Point', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Perturbation Magnitude', 'Interpreter', 'latex', 'FontSize', 11);
title(sprintf('\\textbf{Adversarial Perturbation} ($\\varepsilon = %.2f$)', epsilonViz), ...
      'Interpreter', 'latex', 'FontSize', 12);
grid on;

subplot(1, 3, 3);
plot(1:numPoints, xClean, 'b-o', 'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Clean');
hold on;
plot(1:numPoints, xAdv, 'r-s', 'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Adversarial');
xlabel('Measurement Point', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Normalised Current', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Comparison}', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;

[~, predCleanClass] = max(net(xClean'));
[~, predAdvClass] = max(net(xAdv));

sgtitle({'\textbf{Adversarial Perturbation Visualisation}', ...
         sprintf('True: %s, Clean Pred: %s, Adv Pred: %s', ...
                 faultTypes{yTrue}, faultTypes{predCleanClass}, faultTypes{predAdvClass})}, ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig2, 'figures/Problem4_Perturbation_Example.fig');
saveas(fig2, 'figures/Problem4_Perturbation_Example.eps', 'epsc');
saveas(fig2, 'figures/Problem4_Perturbation_Example.jpg');
fprintf('Saved: Problem4_Perturbation_Example\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');
