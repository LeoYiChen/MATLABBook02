%% robust_interpolation.m
% Spline Interpolation for Data with Outliers
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : robust_interpolation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem9.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Generate a smooth test function
true_func = @(x) 2sin(x) + 0.2x.^2 - 0.1*x.^3;
x_true = linspace(0, 5, 1000);
y_true = true_func(x_true);

% Sample the function at discrete points
n_samples = 20;
x_samples = linspace(0, 5, n_samples);
y_samples_clean = true_func(x_samples);

% Add random noise and outliers
rng(42, 'twister'); % For reproducibility
noise_level = 0.2;
y_noisy = y_samples_clean + noise_level*randn(size(x_samples));

% Add deliberate outliers
n_outliers = 3;
outlier_indices = randperm(n_samples, n_outliers);
outlier_magnitude = 3; % How many standard deviations away
outlier_direction = sign(randn(1, n_outliers));
y_noisy(outlier_indices) = y_noisy(outlier_indices) + ...
outlier_direction .* outlier_magnitude * noise_level;

% Plot the data
figure;
plot(x_true, y_true, 'k-', 'LineWidth', 1.5, 'DisplayName', 'True Function');
hold on;
plot(x_samples, y_noisy, 'ro', 'MarkerSize', 8, 'DisplayName', 'Noisy Data with Outliers');
plot(x_samples(outlier_indices), y_noisy(outlier_indices), 'mo', 'MarkerSize', 10, ...
'MarkerFaceColor', 'm', 'DisplayName', 'Outliers');
xlabel('x');
ylabel('y');
title('Test Data with Noise and Outliers');
legend('show');
grid on;

% Apply different interpolation methods
% 1. Polynomial interpolation
degrees = [3, 5, n_samples-1];
poly_results = cell(length(degrees), 1);

figure('Position', [100, 100, 1200, 800]);

for i = 1:length(degrees)
degree = min(degrees(i), n_samples-1); % Ensure valid degree
p = polyfit(x_samples, y_noisy, degree);
y_poly = polyval(p, x_true);

poly_results{i} = struct('degree', degree, 'coeffs', p, 'y_fit', y_poly);

subplot(3, 2, i);
plot(x_true, y_true, 'k-', 'LineWidth', 1.5, 'DisplayName', 'True Function');
hold on;
plot(x_samples, y_noisy, 'ro', 'MarkerSize', 6, 'DisplayName', 'Noisy Data');
plot(x_true, y_poly, 'b-', 'LineWidth', 1.5, 'DisplayName', ['Polynomial (Degree ', num2str(degree), ')']);
xlabel('x');
ylabel('y');
title(['Polynomial Interpolation (Degree ', num2str(degree), ')']);
legend('show');
grid on;

% Calculate error
mse = mean((y_poly - y_true).^2);
fprintf('Polynomial (Degree %d) MSE: %.6f\n', degree, mse);

end

% 2. Cubic spline interpolation
y_spline = spline(x_samples, y_noisy, x_true);

subplot(3, 2, 4);
plot(x_true, y_true, 'k-', 'LineWidth', 1.5, 'DisplayName', 'True Function');
hold on;
plot(x_samples, y_noisy, 'ro', 'MarkerSize', 6, 'DisplayName', 'Noisy Data');
plot(x_true, y_spline, 'g-', 'LineWidth', 1.5, 'DisplayName', 'Cubic Spline');
xlabel('x');
ylabel('y');
title('Cubic Spline Interpolation');
legend('show');
grid on;

% Calculate error
mse_spline = mean((y_spline - y_true).^2);
fprintf('Cubic Spline MSE: %.6f\n', mse_spline);

% 3. PCHIP (shape-preserving) interpolation
y_pchip = pchip(x_samples, y_noisy, x_true);

subplot(3, 2, 5);
plot(x_true, y_true, 'k-', 'LineWidth', 1.5, 'DisplayName', 'True Function');
hold on;
plot(x_samples, y_noisy, 'ro', 'MarkerSize', 6, 'DisplayName', 'Noisy Data');
plot(x_true, y_pchip, 'm-', 'LineWidth', 1.5, 'DisplayName', 'PCHIP');
xlabel('x');
ylabel('y');
title('PCHIP Interpolation');
legend('show');
grid on;

% Calculate error
mse_pchip = mean((y_pchip - y_true).^2);
fprintf('PCHIP MSE: %.6f\n', mse_pchip);

% 4. Robust fitting approach
% First identify outliers using a simple approach
y_median = median(y_noisy);
y_mad = median(abs(y_noisy - y_median));
outlier_threshold = 2.5; % Number of MAD's for outlier detection
is_outlier = abs(y_noisy - y_median) > outlier_threshold * y_mad;

% Fit a polynomial to the data without outliers
degree_robust = 4;
p_robust = polyfit(x_samples(~is_outlier), y_noisy(~is_outlier), degree_robust);
y_robust = polyval(p_robust, x_true);

subplot(3, 2, 6);
plot(x_true, y_true, 'k-', 'LineWidth', 1.5, 'DisplayName', 'True Function');
hold on;
plot(x_samples, y_noisy, 'ro', 'MarkerSize', 6, 'DisplayName', 'Noisy Data');
plot(x_samples(is_outlier), y_noisy(is_outlier), 'mo', 'MarkerSize', 8, 'MarkerFaceColor', 'm', 'DisplayName', 'Detected Outliers');
plot(x_true, y_robust, 'c-', 'LineWidth', 1.5, 'DisplayName', 'Robust Polynomial');
xlabel('x');
ylabel('y');
title('Robust Polynomial Fitting');
legend('show');
grid on;

% Calculate error
mse_robust = mean((y_robust - y_true).^2);
fprintf('Robust Polynomial MSE: %.6f\n', mse_robust);

% 5. LOWESS (Locally Weighted Scatterplot Smoothing)
% Implement a simple version of LOWESS
y_lowess = zeros(size(x_true));
span = 0.3; % Fraction of points used in local regression

for i = 1:length(x_true)
% Calculate distances
distances = abs(x_samples - x_true(i));

% Compute weights using tri-cubic weighting function
max_dist = max(distances) * span;
weights = (1 - (distances/max_dist).^3).^3;
weights(distances > max_dist) = 0;

% Apply robust weighting to reduce influence of outliers
residuals = abs(y_noisy - median(y_noisy));
robust_weights = 1 ./ (1 + (residuals/median(residuals)).^2);

% Combine distance weights and robust weights
final_weights = weights .* robust_weights;

% Weighted least squares for local linear regression
X = [ones(length(x_samples), 1), x_samples'];
W = diag(final_weights);
beta = (X' * W * X) \ (X' * W * y_noisy');

% Predict at the current point
y_lowess(i) = [1, x_true(i)] * beta;

end

% Create a new figure for LOWESS results
figure;
plot(x_true, y_true, 'k-', 'LineWidth', 1.5, 'DisplayName', 'True Function');
hold on;
plot(x_samples, y_noisy, 'ro', 'MarkerSize', 6, 'DisplayName', 'Noisy Data');
plot(x_true, y_lowess, 'g-', 'LineWidth', 1.5, 'DisplayName', 'LOWESS');
xlabel('x');
ylabel('y');
title('LOWESS Smoothing');
legend('show');
grid on;

% Calculate error
mse_lowess = mean((y_lowess - y_true).^2);
fprintf('LOWESS MSE: %.6f\n', mse_lowess);

% Summary of results
methods = {'Polynomial (Degree 3)', 'Polynomial (Degree 5)', ['Polynomial (Degree ', num2str(n_samples-1), ')'], ...
'Cubic Spline', 'PCHIP', 'Robust Polynomial', 'LOWESS'};
mse_values = [mean((poly_results{1}.y_fit - y_true).^2), ...
mean((poly_results{2}.y_fit - y_true).^2), ...
mean((poly_results{3}.y_fit - y_true).^2), ...
mse_spline, mse_pchip, mse_robust, mse_lowess];

% Bar chart comparing MSE values
figure;
bar(mse_values);
set(gca, 'XTickLabel', methods);
xtickangle(45);
ylabel('Mean Squared Error');
title('Comparison of Interpolation Methods with Outliers Present');
grid on;

% Calculate percentage error reduction compared to high-degree polynomial
baseline_mse = mse_values(3); % Highest degree polynomial
error_reduction = 100 * (baseline_mse - mse_values) / baseline_mse;

% Display the error reduction
fprintf('\nError Reduction Compared to High-Degree Polynomial:\n');
for i = 1:length(methods)
fprintf('%s: %.2f%%\n', methods{i}, error_reduction(i));
end

% Test with varying outlier strengths
n_tests = 5;
outlier_strengths = linspace(1, 5, n_tests);
mse_vs_outlier = zeros(length(methods), n_tests);

for test = 1:n_tests
% Generate data with different outlier strength
y_test = y_samples_clean + noise_levelrandn(size(x_samples));
y_test(outlier_indices) = y_test(outlier_indices) + ...
outlier_direction . outlier_strengths(test) * noise_level;

% Apply all methods
% Polynomial degree 3
p3 = polyfit(x_samples, y_test, 3);
y_p3 = polyval(p3, x_true);
mse_vs_outlier(1, test) = mean((y_p3 - y_true).^2);

% Polynomial degree 5
p5 = polyfit(x_samples, y_test, 5);
y_p5 = polyval(p5, x_true);
mse_vs_outlier(2, test) = mean((y_p5 - y_true).^2);

% High degree polynomial
pn = polyfit(x_samples, y_test, n_samples-1);
y_pn = polyval(pn, x_true);
mse_vs_outlier(3, test) = mean((y_pn - y_true).^2);

% Cubic spline
y_sp = spline(x_samples, y_test, x_true);
mse_vs_outlier(4, test) = mean((y_sp - y_true).^2);

% PCHIP
y_pc = pchip(x_samples, y_test, x_true);
mse_vs_outlier(5, test) = mean((y_pc - y_true).^2);

% Robust polynomial
y_median = median(y_test);
y_mad = median(abs(y_test - y_median));
is_outlier = abs(y_test - y_median) > outlier_threshold * y_mad;
pr = polyfit(x_samples(~is_outlier), y_test(~is_outlier), degree_robust);
y_r = polyval(pr, x_true);
mse_vs_outlier(6, test) = mean((y_r - y_true).^2);

% LOWESS (simplified calculation for speed)
y_low = zeros(size(x_true));
for i = 1:100:length(x_true)  % Sample fewer points for speed
    distances = abs(x_samples - x_true(i));
    max_dist = max(distances) * span;
    weights = (1 - (distances/max_dist).^3).^3;
    weights(distances > max_dist) = 0;
    residuals = abs(y_test - median(y_test));
    robust_weights = 1 ./ (1 + (residuals/median(residuals)).^2);
    final_weights = weights .* robust_weights;
    X = [ones(length(x_samples), 1), x_samples'];
    W = diag(final_weights);
    beta = (X' * W * X) \ (X' * W * y_test');
    y_low(i) = [1, x_true(i)] * beta;
end
% Interpolate missing points
valid_indices = 1:100:length(x_true);
y_low(setdiff(1:length(x_true), valid_indices)) = interp1(x_true(valid_indices), y_low(valid_indices), ...
    x_true(setdiff(1:length(x_true), valid_indices)), 'pchip');
mse_vs_outlier(7, test) = mean((y_low - y_true).^2);

end

% Plot sensitivity to outlier strength
figure;
semilogy(outlier_strengths, mse_vs_outlier', 'LineWidth', 1.5);
xlabel('Outlier Strength (Multiple of Noise Level)');
ylabel('Mean Squared Error (log scale)');
title('Sensitivity of Interpolation Methods to Outlier Strength');
legend(methods, 'Location', 'northwest');
grid on;
