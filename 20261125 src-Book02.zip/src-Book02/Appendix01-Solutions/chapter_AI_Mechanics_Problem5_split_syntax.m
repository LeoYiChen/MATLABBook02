%% chapter_AI_Mechanics_Problem5_split_syntax.m
% Strain energy split (tension/compression) syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem5_split_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Compute strain tensor from displacement gradient
[ux_x, ux_y] = gradient(ux, dx, dy);
[uy_x, uy_y] = gradient(uy, dx, dy);

eps_xx = ux_x;
eps_yy = uy_y;
eps_xy = 0.5 * (ux_y + uy_x);

% Trace (volumetric strain)
tr_eps = eps_xx + eps_yy;

% Positive/negative split using Macaulay brackets
tr_eps_pos = max(tr_eps, 0);
tr_eps_neg = min(tr_eps, 0);

% Deviatoric strain (not split)
eps_dev_xx = eps_xx - tr_eps / 2;
eps_dev_yy = eps_yy - tr_eps / 2;
eps_dev_xy = eps_xy;

% Tensile energy (degraded by damage)
psi_plus = 0.5 * lambda * tr_eps_pos.^2 + ...
           mu * (eps_dev_xx.^2 + eps_dev_yy.^2 + 2*eps_dev_xy.^2);

% Compressive energy (not degraded)
psi_minus = 0.5 * lambda * tr_eps_neg.^2;
