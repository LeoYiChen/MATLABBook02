%% chapter_FundamentalMathematics_MATLABexample_FundamentalOperations.m
% Fundamental matrix and vector operations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_FundamentalOperations
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_1_3_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates fundamental matrix and vector operations
%              including arithmetic, element-wise, and reduction operations.

% Define sample matrices for operations
matrixA = [1, 2, 3; 4, 5, 6; 7, 8, 9];
matrixB = [9, 8, 7; 6, 5, 4; 3, 2, 1];
vectorX = [1; 2; 3];

disp('Matrix A:');
disp(matrixA);
disp('Matrix B:');
disp(matrixB);
disp('Vector x:');
disp(vectorX);

% Standard arithmetic operations
matrixSum = matrixA + matrixB;
disp('A + B (element-wise addition):');
disp(matrixSum);

matrixDifference = matrixA - matrixB;
disp('A - B (element-wise subtraction):');
disp(matrixDifference);

% Matrix multiplication (linear algebra definition)
matrixProduct = matrixA * matrixB;
disp('A * B (matrix multiplication):');
disp(matrixProduct);

% Matrix-vector multiplication
matrixVectorProduct = matrixA * vectorX;
disp('A * x (matrix-vector product):');
disp(matrixVectorProduct);

% Element-wise operations (note the dot notation)
elementwiseProduct = matrixA .* matrixB;
disp('A .* B (element-wise multiplication, Hadamard product):');
disp(elementwiseProduct);

elementwiseDiv = matrixA ./ matrixB;
disp('A ./ B (element-wise division):');
disp(elementwiseDiv);

elementwisePower = matrixA .^ 2;
disp('A .^ 2 (element-wise squaring):');
disp(elementwisePower);

% Scalar expansion in element-wise operations
scaledMatrix = 2 * matrixA;
disp('2 * A (scalar multiplication):');
disp(scaledMatrix);

% Transpose operations
transposeA = matrixA';
disp('A'' (transpose of A):');
disp(transposeA);

% For complex matrices, demonstrate difference
complexMatrix = [1+2*i, 3+4*i; 5+6*i, 7+8*i];
hermitianTranspose = complexMatrix';
nonConjugateTranspose = complexMatrix.';
disp('Complex Matrix:');
disp(complexMatrix);
disp('Hermitian Transpose (conjugate transpose):');
disp(hermitianTranspose);
disp('Non-conjugate Transpose:');
disp(nonConjugateTranspose);

% Reduction operations along different dimensions
columnSums = sum(matrixA); % Sum along columns (default)
disp('Sum along columns (returns row vector):');
disp(columnSums);

rowSums = sum(matrixA, 2); % Sum along rows
disp('Sum along rows (returns column vector):');
disp(rowSums);

totalSum = sum(matrixA, 'all'); % Sum all elements
disp(['Total sum of all elements: ', num2str(totalSum)]);

% Statistical operations
meanValues = mean(matrixA);
disp('Mean values along columns:');
disp(meanValues);

stdDeviation = std(matrixA);
disp('Standard deviation along columns:');
disp(stdDeviation);

% Min and max operations with indices
[minValues, minIndices] = min(matrixA);
disp('Minimum values along columns:');
disp(minValues);
disp('Indices of minimum values:');
disp(minIndices);

% Matrix power (repeated matrix multiplication)
matrixPower = matrixA ^ 2; % Equivalent to A * A
disp('A^2 (matrix power, not element-wise):');
disp(matrixPower);

% Demonstrate left division for solving linear systems
% Solve Ax = b where b is a column from B
rightHandSide = matrixB(:, 1);
solution = matrixA \ rightHandSide;
disp('Solution to Ax = b using backslash operator:');
disp(solution);

% Verify solution
residual = matrixA * solution - rightHandSide;
disp(['Residual norm: ', num2str(norm(residual))]);
