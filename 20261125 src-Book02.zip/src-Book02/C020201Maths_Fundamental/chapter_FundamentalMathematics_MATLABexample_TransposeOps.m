%% chapter_FundamentalMathematics_MATLABexample_TransposeOps.m
% Transpose operations and their applications.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_TransposeOps
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_3_1_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates transpose and conjugate transpose operations
%              with applications to symmetric and Hermitian matrices.

function demonstrateTransposeOperations()
    fprintf('Transpose Operations in Linear Algebra\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Real-valued matrix demonstration
    fprintf('Part 1: Real-valued Matrix Transpose\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    realMatrix = [1, 2, 3; 4, 5, 6];
    fprintf('Original matrix A (2$\times$3):\n');
    disp(realMatrix);
    
    % Transpose operation
    transposeMatrix = realMatrix';  % or realMatrix.'
    fprintf('Transposed matrix A'' (3$\times$2):\n');
    disp(transposeMatrix);
    
    % Verify dimensions
    fprintf('Original dimensions: %d $\times$ %d\n', size(realMatrix));
    fprintf('Transposed dimensions: %d $\times$ %d\n\n', size(transposeMatrix));
    
    % Complex-valued matrix demonstration
    fprintf('Part 2: Complex-valued Matrix Operations\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    complexMatrix = [1+2*i, 3-4*i; 5+6*i, 7-8*i];
    fprintf('Original complex matrix B:\n');
    disp(complexMatrix);
    
    % Conjugate transpose (Hermitian transpose)
    hermitianTranspose = complexMatrix';
    fprintf('Conjugate transpose B'' (Hermitian):\n');
    disp(hermitianTranspose);
    
    % Non-conjugated transpose
    plainTranspose = complexMatrix.';
    fprintf('Non-conjugated transpose B.'':\n');
    disp(plainTranspose);
    
    % Verify relationship
    fprintf('\nVerification: B'' = conj(B.'')\n');
    verificationError = norm(hermitianTranspose - conj(plainTranspose), 'fro');
    fprintf('Frobenius norm difference: %.10e\n\n', verificationError);
    
    % Symmetric matrix properties
    fprintf('Part 3: Symmetric Matrix Properties\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create symmetric matrix
    asymmetricMatrix = randn(4, 4);
    symmetricMatrix = (asymmetricMatrix + asymmetricMatrix') / 2;
    
    fprintf('Symmetric matrix S (constructed via S = (A + A'')/2):\n');
    fprintf('%.4f  %.4f  %.4f  %.4f\n', symmetricMatrix');
    
    % Verify symmetry
    symmetryError = norm(symmetricMatrix - symmetricMatrix', 'fro');
    fprintf('\nSymmetry verification: ||S - S''|| = %.10e\n', symmetryError);
    
    if symmetryError < 1e-10
        fprintf('Matrix is symmetric (within numerical precision)\n');
    end
    
    % Eigenvalue property of symmetric matrices
    eigenvalues = eig(symmetricMatrix);
    fprintf('\nEigenvalues of symmetric matrix (all real):\n');
    fprintf('  %.6f\n', eigenvalues);
    fprintf('Maximum imaginary part: %.10e\n', max(abs(imag(eigenvalues))));
    
    % Hermitian matrix properties
    fprintf('\nPart 4: Hermitian Matrix Properties\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create Hermitian matrix
    asymmetricComplex = randn(3, 3) + 1*i * randn(3, 3);
    hermitianMatrix = (asymmetricComplex + asymmetricComplex') / 2;
    
    fprintf('Hermitian matrix H (constructed via H = (A + A'')/2):\n');
    disp(hermitianMatrix);
    
    % Verify Hermitian property
    hermitianError = norm(hermitianMatrix - hermitianMatrix', 'fro');
    fprintf('Hermitian verification: ||H - H''|| = %.10e\n', hermitianError);
    
    % Eigenvalues of Hermitian matrices are real
    hermitianEigenvalues = eig(hermitianMatrix);
    fprintf('\nEigenvalues of Hermitian matrix (all real):\n');
    fprintf('  %.6f + %.6fi\n', [real(hermitianEigenvalues), ...
                                  imag(hermitianEigenvalues)]');
    fprintf('Maximum imaginary part: %.10e\n', ...
            max(abs(imag(hermitianEigenvalues))));
    
    % Application: Gram matrix
    demonstrateGramMatrix();
end

function demonstrateGramMatrix()
    % Demonstrate Gram matrix construction and properties
    % The Gram matrix G = A'*A is always symmetric positive semi-definite
    
    fprintf('\nPart 5: Gram Matrix Application\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create arbitrary matrix
    arbitraryMatrix = randn(5, 3);
    
    fprintf('Original matrix A (5$\times$3):\n');
    fprintf('%.4f  %.4f  %.4f\n', arbitraryMatrix');
    
    % Construct Gram matrix
    gramMatrix = arbitraryMatrix' * arbitraryMatrix;
    
    fprintf('\nGram matrix G = A''*A (3$\times$3):\n');
    fprintf('%.6f  %.6f  %.6f\n', gramMatrix');
    
    % Verify symmetry
    gramSymmetryError = norm(gramMatrix - gramMatrix', 'fro');
    fprintf('\nSymmetry verification: ||G - G''|| = %.10e\n', ...
            gramSymmetryError);
    
    % Verify positive semi-definiteness through eigenvalues
    gramEigenvalues = eig(gramMatrix);
    fprintf('\nEigenvalues of Gram matrix (all non-negative):\n');
    fprintf('  %.8f\n', gramEigenvalues);
    fprintf('Minimum eigenvalue: %.10e\n', min(gramEigenvalues));
    
    if min(gramEigenvalues) >= -1e-10
        fprintf('Matrix is positive semi-definite (λ_min ≥ 0)\n');
    end
    
    % Application: correlation and covariance matrices
    fprintf('\nApplication Note:\n');
    fprintf('Gram matrices appear in:\n');
    fprintf('  - Covariance matrices in statistics\n');
    fprintf('  - Kernel matrices in machine learning\n');
    fprintf('  - Normal equations in least squares problems\n');
    fprintf('  - Correlation matrices in signal processing\n');
end
