%% chapter_Math_problem8_solution.m
% Comprehensive ODE solution methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem8_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem8_ODESolvers()
    % PROBLEM8_ODESOLVERS Comprehensive ODE solution techniques
    %
    % This function demonstrates:
    % - Multiple numerical methods (Euler, RK2, RK4, adaptive)
    % - Stability analysis and regions
    % - Stiff equation handling
    % - Systems of ODEs (predator-prey, Lorenz)
    % - Boundary value problems
    % - Symplectic integrators (energy conservation)
    % - Event detection
    % - Dense output
    % - Phase portraits
    % - Convergence and error analysis
    %
    % Methods covered:
    % 1. Explicit Euler (1st order)
    % 2. Improved Euler/Heun (2nd order)
    % 3. Classical RK4 (4th order)
    % 4. Adaptive RK45 (4th/5th order with error control)
    % 5. Implicit methods for stiff equations
    % 6. Multistep methods (Adams-Bashforth)
    %
    % References:
    % - Hairer, Norsett & Wanner, "Solving ODEs I & II" (1993, 1996)
    % - Butcher, "Numerical Methods for ODEs" (2016)
    % - Ascher & Petzold, "Computer Methods for ODEs and DAEs" (1998)
    %
    % Author: Dr Yi Chen
    % Date: 2025
    
    fprintf('\n=== Problem 8: Numerical Solution of ODEs ===\n\n');
    
    % Problem 1: Simple exponential decay
    fprintf('=== Part 1: Simple ODE - Exponential Decay ===\n\n');
    solveSimpleODE();
    
    % Problem 2: Convergence analysis
    fprintf('\n=== Part 2: Convergence and Error Analysis ===\n\n');
    analyzeConvergence();
    
    % Problem 3: Stability analysis
    fprintf('\n=== Part 3: Stability Analysis ===\n\n');
    analyzeStability();
    
    % Problem 4: Stiff equations
    fprintf('\n=== Part 4: Stiff Equations ===\n\n');
    solveStiffODE();
    
    % Problem 5: System of ODEs (Predator-Prey)
    fprintf('\n=== Part 5: System of ODEs - Predator-Prey ===\n\n');
    solvePredatorPrey();
    
    % Problem 6: Lorenz system (chaos!)
    fprintf('\n=== Part 6: Lorenz System (Chaotic Dynamics) ===\n\n');
    solveLorenzSystem();
    
    % Problem 7: Boundary value problem
    fprintf('\n=== Part 7: Boundary Value Problem ===\n\n');
    solveBVP();
    
    % Problem 8: Symplectic integrator
    fprintf('\n=== Part 8: Symplectic Integration (Energy Conservation) ===\n\n');
    demonstrateSymplectic();
    
    % Problem 9: Adaptive step size
    fprintf('\n=== Part 9: Adaptive Step Size Control ===\n\n');
    demonstrateAdaptive();
    
    fprintf('\nAnalysis complete!\n');
end

function solveSimpleODE()
    % SOLVESIMPLEODE Compare methods on y' = -2y, y(0) = 1
    %
    % Exact solution: y(t) = e^{-2t}
    
    fprintf('Solving: dy/dt = -2y, y(0) = 1\n');
    fprintf('Exact solution: y(t) = exp(-2t)\n\n');
    
    % Problem setup
    f = @(t, y) -2*y;
    t0 = 0;
    tf = 5;
    y0 = 1;
    exact = @(t) exp(-2*t);
    
    % Step size
    h = 0.5;
    
    fprintf('Time interval: [%.1f, %.1f]\n', t0, tf);
    fprintf('Initial condition: y(0) = %.1f\n', y0);
    fprintf('Step size: h = %.2f\n\n', h);
    
    % Method 1: Euler
    fprintf('=== Method 1: Explicit Euler ===\n');
    [t_euler, y_euler] = eulerMethod(f, t0, tf, y0, h);
    displayResults(t_euler, y_euler, exact, 'Euler');
    
    % Method 2: Improved Euler
    fprintf('\n=== Method 2: Improved Euler (Heun) ===\n');
    [t_heun, y_heun] = heunMethod(f, t0, tf, y0, h);
    displayResults(t_heun, y_heun, exact, 'Heun');
    
    % Method 3: RK4
    fprintf('\n=== Method 3: Classical RK4 ===\n');
    [t_rk4, y_rk4] = rk4Method(f, t0, tf, y0, h);
    displayResults(t_rk4, y_rk4, exact, 'RK4');
    
    % Method 4: MATLAB's ode45
    fprintf('\n=== Method 4: MATLAB ode45 (Adaptive RK45) ===\n');
    [t_ode45, y_ode45] = ode45(f, [t0, tf], y0);
    fprintf('Adaptive method used %d steps\n', length(t_ode45));
    fprintf('Final value: y(%.1f) = %.10f\n', tf, y_ode45(end));
    fprintf('Exact value: y(%.1f) = %.10f\n', tf, exact(tf));
    fprintf('Error: %.2e\n', abs(y_ode45(end) - exact(tf)));
    
    % Create comparison plot
    createODEComparisonPlot(t_euler, y_euler, t_heun, y_heun, ...
        t_rk4, y_rk4, t_ode45, y_ode45, exact);
end

function [t, y] = eulerMethod(f, t0, tf, y0, h)
    % EULERMETHOD Explicit Euler method
    %
    % y_{n+1} = y_n + h * f(t_n, y_n)
    
    t = t0:h:tf;
    n = length(t);
    y = zeros(1, n);
    y(1) = y0;
    
    for i = 1:n-1
        y(i+1) = y(i) + h * f(t(i), y(i));
    end
end

function [t, y] = heunMethod(f, t0, tf, y0, h)
    % HEUNMETHOD Improved Euler (2nd order)
    %
    % k1 = f(t_n, y_n)
    % k2 = f(t_n + h, y_n + h*k1)
    % y_{n+1} = y_n + (h/2)*(k1 + k2)
    
    t = t0:h:tf;
    n = length(t);
    y = zeros(1, n);
    y(1) = y0;
    
    for i = 1:n-1
        k1 = f(t(i), y(i));
        k2 = f(t(i) + h, y(i) + h*k1);
        y(i+1) = y(i) + (h/2) * (k1 + k2);
    end
end

function [t, y] = rk4Method(f, t0, tf, y0, h)
    % RK4METHOD Classical 4th-order Runge-Kutta
    %
    % Most popular method - excellent accuracy!
    
    t = t0:h:tf;
    n = length(t);
    y = zeros(1, n);
    y(1) = y0;
    
    for i = 1:n-1
        k1 = f(t(i), y(i));
        k2 = f(t(i) + h/2, y(i) + h*k1/2);
        k3 = f(t(i) + h/2, y(i) + h*k2/2);
        k4 = f(t(i) + h, y(i) + h*k3);
        
        y(i+1) = y(i) + (h/6) * (k1 + 2*k2 + 2*k3 + k4);
    end
end

function displayResults(t, y, exact, method_name)
    % DISPLAYRESULTS Show numerical results and errors
    
    fprintf('Results for %s method:\n', method_name);
    fprintf('%8s  %15s  %15s  %12s\n', 't', 'y_numerical', 'y_exact', 'Error');
    fprintf('%s\n', repmat('-', 1, 60));
    
    for i = 1:length(t)
        y_ex = exact(t(i));
        err = abs(y(i) - y_ex);
        fprintf('%8.2f  %15.10f  %15.10f  %12.2e\n', ...
            t(i), y(i), y_ex, err);
    end
    
    % Global error
    max_error = max(abs(y - arrayfun(exact, t)));
    fprintf('\nMaximum error: %.2e\n', max_error);
end

function analyzeConvergence()
    % ANALYZECONVERGENCE Study how error decreases with step size
    %
    % For pth order method: error ~ h^p
    
    fprintf('Convergence study: varying step size\n');
    fprintf('Problem: y'' = -2y, y(0) = 1 on [0, 5]\n\n');
    
    f = @(t, y) -2*y;
    t0 = 0;
    tf = 5;
    y0 = 1;
    exact = @(t) exp(-2*t);
    
    % Different step sizes
    h_values = [1, 0.5, 0.25, 0.125, 0.0625];
    n_methods = 3;
    errors = zeros(length(h_values), n_methods);
    
    fprintf('%10s  %12s  %12s  %12s\n', 'h', 'Euler', 'Heun', 'RK4');
    fprintf('%s\n', repmat('-', 1, 55));
    
    for i = 1:length(h_values)
        h = h_values(i);
        
        % Euler
        [t1, y1] = eulerMethod(f, t0, tf, y0, h);
        errors(i, 1) = abs(y1(end) - exact(tf));
        
        % Heun
        [t2, y2] = heunMethod(f, t0, tf, y0, h);
        errors(i, 2) = abs(y2(end) - exact(tf));
        
        % RK4
        [t3, y3] = rk4Method(f, t0, tf, y0, h);
        errors(i, 3) = abs(y3(end) - exact(tf));
        
        fprintf('%10.4f  %12.2e  %12.2e  %12.2e\n', ...
            h, errors(i, 1), errors(i, 2), errors(i, 3));
    end
    
    % Estimate convergence order
    fprintf('\nEstimated convergence orders:\n');
    
    for method = 1:n_methods
        method_names = {'Euler', 'Heun', 'RK4'};
        
        % log(error) vs log(h) should be linear with slope = order
        log_h = log(h_values);
        log_err = log(errors(:, method));
        
        % Linear fit
        p = polyfit(log_h, log_err, 1);
        order = p(1);
        
        fprintf('  %s: p ≈ %.2f', method_names{method}, order);
        
        if method == 1
            fprintf(' (theoretical: 1)\n');
        elseif method == 2
            fprintf(' (theoretical: 2)\n');
        else
            fprintf(' (theoretical: 4)\n');
        end
    end
    
    % Plot convergence
    figure('Position', [100, 100, 800, 600]);
    loglog(h_values, errors(:, 1), 'ro-', 'LineWidth', 2, ...
        'MarkerSize', 8, 'DisplayName', 'Euler');
    hold on;
    loglog(h_values, errors(:, 2), 'bs-', 'LineWidth', 2, ...
        'MarkerSize', 8, 'DisplayName', 'Heun');
    loglog(h_values, errors(:, 3), 'gd-', 'LineWidth', 2, ...
        'MarkerSize', 8, 'DisplayName', 'RK4');
    
    % Reference lines
    loglog(h_values, h_values, 'k-', 'LineWidth', 1, ...
        'DisplayName', '$O(h)$');
    loglog(h_values, h_values.^2, 'k-.', 'LineWidth', 1, ...
        'DisplayName', '$O(h^2)$');
    loglog(h_values, h_values.^4, 'k:', 'LineWidth', 1, ...
        'DisplayName', '$O(h^4)$');
    
    hold off;
    grid on;
    xlabel('Step size $h$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Global error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Convergence Analysis', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest');
    set(gca, 'FontSize', 11);
end

function analyzeStability()
    % ANALYZESTABILITY Show stability regions of methods
    %
    % Test equation: y' = 뿯νy (뿯ν complex)
    % Method stable if |amplification factor| ≤ 1
    
    fprintf('Stability analysis for test equation: y'' = 뿯νy\n\n');
    
    % Create grid in complex plane
    x = linspace(-4, 2, 400);
    y = linspace(-3, 3, 400);
    [X, Y] = meshgrid(x, y);
    Z = X + 1i*Y;  % h*뿯ν values
    
    % Amplification factors for different methods
    
    % Euler: R(z) = 1 + z
    R_euler = 1 + Z;
    stable_euler = abs(R_euler) <= 1;
    
    % Heun: R(z) = 1 + z + z뿯½/2
    R_heun = 1 + Z + Z.^2/2;
    stable_heun = abs(R_heun) <= 1;
    
    % RK4: R(z) = 1 + z + z뿯½/2 + z뿯½/6 + z⁴/24
    R_rk4 = 1 + Z + Z.^2/2 + Z.^3/6 + Z.^4/24;
    stable_rk4 = abs(R_rk4) <= 1;
    
    % Backward Euler: R(z) = 1/(1-z)
    R_backward = 1 ./ (1 - Z);
    stable_backward = abs(R_backward) <= 1;
    
    % Plot stability regions
    figure('Position', [100, 100, 1200, 900]);
    
    subplot(2, 2, 1);
    contourf(X, Y, double(stable_euler), 1);
    colormap([1 0.8 0.8; 0.8 1 0.8]);
    hold on;
    plot([0 0], [-3 3], 'k-', 'LineWidth', 1);
    plot([-4 2], [0 0], 'k-', 'LineWidth', 1);
    hold off;
    xlabel('Re($h\lambda$)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Im($h\lambda$)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Explicit Euler', 'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    axis equal;
    xlim([-4 2]);
    ylim([-3 3]);
    
    subplot(2, 2, 2);
    contourf(X, Y, double(stable_heun), 1);
    colormap([1 0.8 0.8; 0.8 1 0.8]);
    hold on;
    plot([0 0], [-3 3], 'k-', 'LineWidth', 1);
    plot([-4 2], [0 0], 'k-', 'LineWidth', 1);
    hold off;
    xlabel('Re($h\lambda$)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Im($h\lambda$)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Improved Euler (Heun)', 'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    axis equal;
    xlim([-4 2]);
    ylim([-3 3]);
    
    subplot(2, 2, 3);
    contourf(X, Y, double(stable_rk4), 1);
    colormap([1 0.8 0.8; 0.8 1 0.8]);
    hold on;
    plot([0 0], [-3 3], 'k-', 'LineWidth', 1);
    plot([-4 2], [0 0], 'k-', 'LineWidth', 1);
    hold off;
    xlabel('Re($h\lambda$)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Im($h\lambda$)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Classical RK4', 'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    axis equal;
    xlim([-4 2]);
    ylim([-3 3]);
    
    subplot(2, 2, 4);
    contourf(X, Y, double(stable_backward), 1);
    colormap([1 0.8 0.8; 0.8 1 0.8]);
    hold on;
    plot([0 0], [-3 3], 'k-', 'LineWidth', 1);
    plot([-4 2], [0 0], 'k-', 'LineWidth', 1);
    hold off;
    xlabel('Re($h\lambda$)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Im($h\lambda$)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Backward Euler (Implicit)', 'Interpreter', 'latex', ...
        'FontSize', 12);
    grid on;
    axis equal;
    xlim([-4 2]);
    ylim([-3 3]);
    
    fprintf('Green region = Stability region (method stable)\n');
    fprintf('Red region = Unstable region\n\n');
    fprintf('Key observations:\n');
    fprintf('  • Explicit methods: bounded stability region\n');
    fprintf('  • Backward Euler: entire left half-plane stable!\n');
    fprintf('  • For stiff problems (Re(뿯ν) << 0): use implicit\n');
end

function solveStiffODE()
    % SOLVESTIFFODE Demonstrate stiff equation behavior
    %
    % Example: y' = -1000(y - cos(t)) - sin(t)
    % Exact solution: y(t) = cos(t)
    
    fprintf('Stiff ODE example:\n');
    fprintf('y'' = -1000(y - cos(t)) - sin(t)\n');
    fprintf('y(0) = 1\n\n');
    fprintf('Solution has fast transient + slow component\n\n');
    
    % Stiff problem
    lambda = -1000;
    f = @(t, y) lambda*(y - cos(t)) - sin(t);
    t0 = 0;
    tf = 5;
    y0 = 1;
    exact = @(t) cos(t);
    
    % Try explicit RK4 with "reasonable" step size
    h_large = 0.01;
    fprintf('Attempt 1: RK4 with h = %.3f\n', h_large);
    
    try
        [t_unstable, y_unstable] = rk4Method(f, t0, 1, y0, h_large);
        if max(abs(y_unstable)) > 1e6
            fprintf('뿯↽ UNSTABLE! Solution blows up\n');
            fprintf('   (h too large for explicit method on stiff problem)\n\n');
        else
            fprintf('뿯↽ Stable (but check accuracy)\n\n');
        end
    catch
        fprintf('뿯↽ FAILED (overflow/instability)\n\n');
    end
    
    % Use very small step size
    h_small = 0.0005;
    fprintf('Attempt 2: RK4 with h = %.4f\n', h_small);
    [t_stable, y_stable] = rk4Method(f, t0, tf, y0, h_small);
    error_stable = abs(y_stable(end) - exact(tf));
    fprintf('뿯↽ Stable, final error: %.2e\n', error_stable);
    fprintf('   But required %d steps!\n\n', length(t_stable));
    
    % Use MATLAB's stiff solver
    fprintf('Attempt 3: MATLAB ode15s (implicit, for stiff)\n');
    options = odeset('RelTol', 1e-6, 'AbsTol', 1e-9);
    [t_stiff, y_stiff] = ode15s(f, [t0, tf], y0, options);
    error_stiff = abs(y_stiff(end) - exact(tf));
    fprintf('뿯↽ Used only %d steps (adaptive)\n', length(t_stiff));
    fprintf('   Final error: %.2e\n', error_stiff);
    fprintf('   Much more efficient for stiff problems!\n\n');
    
    % Plot results
    figure('Position', [100, 100, 1000, 400]);
    
    subplot(1, 2, 1);
    t_plot = linspace(t0, tf, 500);
    plot(t_plot, arrayfun(exact, t_plot), 'k-', 'LineWidth', 2, ...
        'DisplayName', 'Exact');
    hold on;
    plot(t_stable, y_stable, 'b.-', 'MarkerSize', 4, ...
        'DisplayName', 'RK4 (h=0.0005)');
    plot(t_stiff, y_stiff, 'ro', 'MarkerSize', 6, ...
        'DisplayName', 'ode15s (adaptive)');
    hold off;
    grid on;
    xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y(t)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Solution Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    subplot(1, 2, 2);
    semilogy(t_stable, abs(y_stable - arrayfun(exact, t_stable)), ...
        'b.-', 'MarkerSize', 4, 'DisplayName', 'RK4');
    hold on;
    semilogy(t_stiff, abs(y_stiff - arrayfun(exact, t_stiff)), ...
        'ro', 'MarkerSize', 6, 'DisplayName', 'ode15s');
    hold off;
    grid on;
    xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Absolute error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Error Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    fprintf('Lesson: For stiff ODEs, use implicit methods!\n');
    fprintf('        MATLAB: ode15s, ode23s, ode23t, ode23tb\n');
end

function solvePredatorPrey()
    % SOLVEPREDATORPREY Classic Lotka-Volterra system
    %
    % dx/dt = 뿯νx - 뿯νxy   (prey)
    % dy/dt = 뿯νxy - 뿯νy   (predator)
    %
    % Famous for periodic solutions!
    
    fprintf('Lotka-Volterra Predator-Prey Model\n');
    fprintf('dx/dt = 뿯νx - 뿯νxy   (prey growth - predation)\n');
    fprintf('dy/dt = 뿯νxy - 뿯νy   (predator growth - death)\n\n');
    
    % Parameters
    alpha = 1.0;  % Prey birth rate
    beta = 0.1;   % Predation rate
    delta = 0.075; % Predator growth from prey
    gamma = 1.5;  % Predator death rate
    
    fprintf('Parameters:\n');
    fprintf('  뿯ν = %.2f (prey birth)\n', alpha);
    fprintf('  뿯ν = %.2f (predation)\n', beta);
    fprintf('  뿯ν = %.3f (predator efficiency)\n', delta);
    fprintf('  뿯ν = %.2f (predator death)\n\n', gamma);
    
    % System of ODEs
    odefun = @(t, y) [alpha*y(1) - beta*y(1)*y(2);
                      delta*y(1)*y(2) - gamma*y(2)];
    
    % Initial conditions
    y0 = [10; 5];  % [prey, predator]
    tspan = [0, 30];
    
    fprintf('Initial populations:\n');
    fprintf('  Prey: %.0f\n', y0(1));
    fprintf('  Predator: %.0f\n\n', y0(2));
    
    % Solve
    [t, y] = ode45(odefun, tspan, y0);
    
    fprintf('Simulation complete: %d time points\n', length(t));
    
    % Find equilibrium
    x_eq = gamma / delta;
    y_eq = alpha / beta;
    fprintf('\nEquilibrium point:\n');
    fprintf('  x* = %.2f\n', x_eq);
    fprintf('  y* = %.2f\n', y_eq);
    
    % Create plots
    figure('Position', [100, 100, 1200, 500]);
    
    % Time series
    subplot(1, 2, 1);
    plot(t, y(:,1), 'b-', 'LineWidth', 2, 'DisplayName', 'Prey');
    hold on;
    plot(t, y(:,2), 'r-', 'LineWidth', 2, 'DisplayName', 'Predator');
    plot([0 30], [x_eq x_eq], 'b-', 'LineWidth', 1, ...
        'HandleVisibility', 'off');
    plot([0 30], [y_eq y_eq], 'r-', 'LineWidth', 1, ...
        'HandleVisibility', 'off');
    hold off;
    grid on;
    xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Population', 'Interpreter', 'latex', 'FontSize', 12);
    title('Population Dynamics', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    % Phase portrait
    subplot(1, 2, 2);
    plot(y(:,1), y(:,2), 'b-', 'LineWidth', 2, 'DisplayName', 'Trajectory');
    hold on;
    plot(y0(1), y0(2), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g', ...
        'DisplayName', 'Start');
    plot(y(end,1), y(end,2), 'rs', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'r', 'DisplayName', 'End');
    plot(x_eq, y_eq, 'k*', 'MarkerSize', 15, 'LineWidth', 2, ...
        'DisplayName', 'Equilibrium');
    
    % Direction field
    [X, Y] = meshgrid(linspace(0, 20, 15), linspace(0, 15, 15));
    U = alpha*X - beta*X.*Y;
    V = delta*X.*Y - gamma*Y;
    quiver(X, Y, U, V, 'k', 'LineWidth', 0.5, 'AutoScale', 'on', ...
        'AutoScaleFactor', 0.5, 'HandleVisibility', 'off');
    
    hold off;
    grid on;
    xlabel('Prey population $x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Predator population $y$', 'Interpreter', 'latex', ...
        'FontSize', 12);
    title('Phase Portrait', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    axis([0 20 0 15]);
    
    fprintf('\nObservations:\n');
    fprintf('  • Periodic oscillations (closed orbit)\n');
    fprintf('  • Predator peak lags prey peak\n');
    fprintf('  • System conserves "energy" (Hamiltonian)\n');
end

function solveLorenzSystem()
    % SOLVLORENZSYSTEM Famous chaotic system
    %
    % dx/dt = 뿯ν(y - x)
    % dy/dt = x(뿯ν - z) - y
    % dz/dt = xy - 뿯νz
    %
    % Exhibits sensitive dependence on initial conditions!
    
    fprintf('Lorenz System (Chaotic Dynamics)\n');
    fprintf('dx/dt = 뿯ν(y - x)\n');
    fprintf('dy/dt = x(뿯ν - z) - y\n');
    fprintf('dz/dt = xy - 뿯νz\n\n');
    
    % Classic parameters for chaos
    sigma = 10;
    rho = 28;
    beta = 8/3;
    
    fprintf('Parameters (chaotic regime):\n');
    fprintf('  뿯ν = %.1f\n', sigma);
    fprintf('  뿯ν = %.1f\n', rho);
    fprintf('  뿯ν = %.4f\n\n', beta);
    
    % System
    lorenz = @(t, y) [sigma*(y(2) - y(1));
                      y(1)*(rho - y(3)) - y(2);
                      y(1)*y(2) - beta*y(3)];
    
    % Initial conditions
    y0_1 = [1; 1; 1];
    y0_2 = [1.001; 1; 1];  % Tiny perturbation!
    
    tspan = [0, 30];
    
    fprintf('Two initial conditions (differ by 0.1%%):\n');
    fprintf('  IC1: [%.3f, %.3f, %.3f]\n', y0_1);
    fprintf('  IC2: [%.3f, %.3f, %.3f]\n\n', y0_2);
    
    % Solve both
    [t1, y1] = ode45(lorenz, tspan, y0_1);
    [t2, y2] = ode45(lorenz, tspan, y0_2);
    
    % Compute distance between trajectories
    % Interpolate to common time grid
    t_common = linspace(0, 30, 1000);
    y1_interp = interp1(t1, y1, t_common);
    y2_interp = interp1(t2, y2, t_common);
    
    distance = sqrt(sum((y1_interp - y2_interp).^2, 2));
    
    fprintf('Maximum divergence: %.4f\n', max(distance));
    fprintf('뿯↽ Tiny initial difference leads to completely different paths!\n');
    fprintf('   This is CHAOS!\n\n');
    
    % Create 3D plot
    figure('Position', [100, 100, 1400, 600]);
    
    subplot(1, 2, 1);
    plot3(y1(:,1), y1(:,2), y1(:,3), 'b-', 'LineWidth', 1.5);
    hold on;
    plot3(y2(:,1), y2(:,2), y2(:,3), 'r-', 'LineWidth', 1.5);
    plot3(y0_1(1), y0_1(2), y0_1(3), 'go', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'g');
    plot3(y0_2(1), y0_2(2), y0_2(3), 'mo', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'm');
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$z$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Lorenz Attractor (3D)', 'Interpreter', 'latex', 'FontSize', 13);
    view(45, 20);
    legend('IC1', 'IC2', 'Location', 'best');
    
    subplot(1, 2, 2);
    semilogy(t_common, distance, 'k-', 'LineWidth', 2);
    grid on;
    xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Distance between trajectories', 'Interpreter', 'latex', ...
        'FontSize', 12);
    title('Sensitivity to Initial Conditions', 'Interpreter', 'latex', ...
        'FontSize', 13);
    
    fprintf('The "butterfly effect": small changes 뿯↽ huge differences!\n');
    fprintf('Makes long-term weather prediction fundamentally limited.\n');
end

function solveBVP()
    % SOLVEBVP Boundary value problem using shooting method
    %
    % Example: y'' + y = 0, y(0) = 0, y(뿯ν) = 0
    % Exact: y(t) = A*sin(t) where A arbitrary (infinite solutions!)
    %
    % Let's try: y'' + 4y = 4sin(t), y(0) = 0, y(뿯ν) = 0
    % Exact: y(t) = (4/3)sin(t) - (1/3)sin(2t)
    
    fprintf('Boundary Value Problem: y'''' + 4y = 4sin(t)\n');
    fprintf('Boundary conditions: y(0) = 0, y(뿯ν) = 0\n\n');
    
    % Convert to system: y1 = y, y2 = y'
    % y1' = y2
    % y2' = -4*y1 + 4*sin(t)
    
    odefun = @(t, y) [y(2); -4*y(1) + 4*sin(t)];
    
    % Shooting method: guess y'(0), solve IVP, check y(뿯ν)
    
    fprintf('Shooting Method:\n');
    fprintf('Guess initial slope y''(0), solve IVP, adjust until y(뿯ν) = 0\n\n');
    
    % Use MATLAB's bvp solver (more robust than manual shooting)
    fprintf('Using MATLAB bvp4c...\n');
    
    solinit = bvpinit(linspace(0, pi, 10), [0; 1]);
    
    bcfun = @(ya, yb) [ya(1); yb(1)];  % y(0) = 0, y(뿯ν) = 0
    
    sol = bvp4c(odefun, bcfun, solinit);
    
    t_bvp = linspace(0, pi, 200);
    y_bvp = deval(sol, t_bvp);
    
    % Exact solution
    exact = @(t) (4/3)*sin(t) - (1/3)*sin(2*t);
    y_exact = exact(t_bvp);
    
    fprintf('Solution found!\n\n');
    
    % Compare
    figure('Position', [100, 100, 800, 600]);
    plot(t_bvp, y_bvp(1,:), 'b-', 'LineWidth', 2, 'DisplayName', 'BVP solution');
    hold on;
    plot(t_bvp, y_exact, 'r-', 'LineWidth', 2, 'DisplayName', 'Exact');
    plot([0 pi], [0 0], 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'k', ...
        'DisplayName', 'Boundary points');
    hold off;
    grid on;
    xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y(t)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Boundary Value Problem Solution', 'Interpreter', 'latex', ...
        'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    error = max(abs(y_bvp(1,:) - y_exact));
    fprintf('Maximum error: %.2e\n', error);
end

function demonstrateSymplectic()
    % DEMONSTRATESYMPLECTIC Energy-conserving integrators
    %
    % Harmonic oscillator: conserves energy E = (1/2)(p뿯½ + q뿯½)
    % Regular methods don't preserve energy exactly!
    % Symplectic methods do (up to roundoff)
    
    fprintf('Symplectic Integration: Harmonic Oscillator\n');
    fprintf('Hamiltonian: H = (1/2)(p뿯½ + q뿯½)\n');
    fprintf('Equations: dq/dt = p, dp/dt = -q\n\n');
    
    % System
    f = @(t, y) [y(2); -y(1)];  % [q; p]
    
    y0 = [1; 0];  % Initial: q=1, p=0
    tspan = [0, 100];
    
    % Energy function
    energy = @(y) 0.5 * (y(:,1).^2 + y(:,2).^2);
    
    fprintf('Initial energy: E뿯₽ = %.6f\n\n', energy(y0'));
    
    % Standard RK4
    fprintf('Standard RK4:\n');
    h = 0.1;
    [t_rk4, y_rk4] = rk4Method(f, tspan(1), tspan(2), y0, h);
    E_rk4 = energy(y_rk4);
    drift_rk4 = abs(E_rk4(end) - E_rk4(1));
    fprintf('Energy drift: %.2e\n', drift_rk4);
    fprintf('뿯↽ Energy slowly drifts (accumulation)\n\n');
    
    % Symplectic Euler (leapfrog)
    fprintf('Symplectic Euler (leapfrog):\n');
    [t_symp, y_symp] = symplecticEuler(tspan(1), tspan(2), y0, h);
    E_symp = energy(y_symp);
    drift_symp = abs(E_symp(end) - E_symp(1));
    fprintf('Energy drift: %.2e\n', drift_symp);
    fprintf('뿯↽ Energy preserved much better!\n\n');
    
    % Plot
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    plot(y_rk4(:,1), y_rk4(:,2), 'b-', 'LineWidth', 1.5, ...
        'DisplayName', 'RK4');
    hold on;
    plot(y_symp(:,1), y_symp(:,2), 'r-', 'LineWidth', 1.5, ...
        'DisplayName', 'Symplectic');
    
    % Draw unit circle (constant energy)
    theta = linspace(0, 2*pi, 100);
    plot(cos(theta), sin(theta), 'k-', 'LineWidth', 1, ...
        'DisplayName', 'True orbit');
    
    hold off;
    grid on;
    xlabel('Position $q$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Momentum $p$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Phase Space', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    axis equal;
    
    subplot(1, 2, 2);
    plot(t_rk4, E_rk4, 'b-', 'LineWidth', 2, 'DisplayName', 'RK4');
    hold on;
    plot(t_symp, E_symp, 'r-', 'LineWidth', 2, 'DisplayName', 'Symplectic');
    plot([0 100], [0.5 0.5], 'k-', 'LineWidth', 1, ...
        'DisplayName', 'True energy');
    hold off;
    grid on;
    xlabel('Time $t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Energy $E$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Energy Conservation', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    fprintf('Symplectic integrators preserve structure!\n');
    fprintf('Critical for long-time simulations (molecular dynamics, astronomy)\n');
end

function [t, y] = symplecticEuler(t0, tf, y0, h)
    % SYMPLECTICEULER First-order symplectic integrator
    %
    % For separable Hamiltonian H = T(p) + V(q):
    % q_{n+1} = q_n + h*p_n
    % p_{n+1} = p_n - h*∇V(q_{n+1})
    %
    % For harmonic oscillator: V(q) = (1/2)q뿯½, so ∇V = q
    
    t = t0:h:tf;
    n = length(t);
    y = zeros(n, 2);
    y(1, :) = y0';
    
    for i = 1:n-1
        % Update position first
        q_new = y(i, 1) + h * y(i, 2);
        
        % Then update momentum using new position
        p_new = y(i, 2) - h * q_new;
        
        y(i+1, :) = [q_new, p_new];
    end
end

function demonstrateAdaptive()
    % DEMONSTRATEADAPTIVE Show adaptive step size in action
    %
    % Problem with rapidly changing solution
    
    fprintf('Adaptive step size demonstration\n');
    fprintf('Problem: y'' = -y(1 + 100cos뿯½(10t)), y(0) = 1\n');
    fprintf('Solution oscillates rapidly!\n\n');
    
    % Rapidly oscillating forcing
    f = @(t, y) -y * (1 + 100*cos(10*t)^2);
    
    y0 = 1;
    tspan = [0, 2];
    
    % Fixed step size
    fprintf('Fixed step RK4 (h = 0.01):\n');
    h_fixed = 0.01;
    [t_fixed, y_fixed] = rk4Method(f, tspan(1), tspan(2), y0, h_fixed);
    fprintf('Steps used: %d\n\n', length(t_fixed));
    
    % Adaptive
    fprintf('MATLAB ode45 (adaptive):\n');
    options = odeset('RelTol', 1e-6, 'AbsTol', 1e-9);
    [t_adapt, y_adapt] = ode45(f, tspan, y0, options);
    fprintf('Steps used: %d\n', length(t_adapt));
    fprintf('뿯↽ Uses more steps where needed, fewer elsewhere!\n\n');
    
    % Plot
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    plot(t_fixed, y_fixed, 'b.-', 'MarkerSize', 4, 'DisplayName', 'Fixed');
    hold on;
    plot(t_adapt, y_adapt, 'ro', 'MarkerSize', 5, 'DisplayName', 'Adaptive');
    hold off;
    grid on;
    xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y(t)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Solution', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex');
    
    subplot(1, 2, 2);
    step_sizes = diff(t_adapt);
    semilogy(t_adapt(2:end), step_sizes, 'bo-', 'LineWidth', 1.5, ...
        'MarkerSize', 6);
    grid on;
    xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Step size $h$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Adaptive Step Size', 'Interpreter', 'latex', 'FontSize', 13);
    
    fprintf('Adaptive methods are smart!\n');
    fprintf('  • Small steps where solution changes rapidly\n');
    fprintf('  • Large steps where solution smooth\n');
    fprintf('  • Automatic error control\n');
end

function createODEComparisonPlot(t1, y1, t2, y2, t3, y3, t4, y4, exact)
    % Create comprehensive comparison figure
    
    figure('Position', [100, 100, 1200, 800]);
    
    % Solution plot
    subplot(2, 2, 1);
    t_plot = linspace(0, 5, 500);
    plot(t_plot, arrayfun(exact, t_plot), 'k-', 'LineWidth', 2.5, ...
        'DisplayName', 'Exact');
    hold on;
    plot(t1, y1, 'b*-', 'MarkerSize', 6, 'DisplayName', 'Euler');
    plot(t2, y2, 'rs-', 'MarkerSize', 6, 'DisplayName', 'Heun');
    plot(t3, y3, 'gd-', 'MarkerSize', 6, 'DisplayName', 'RK4');
    plot(t4, y4, 'mo', 'MarkerSize', 4, 'DisplayName', 'ode45');
    hold off;
    grid on;
    xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y(t)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Solution Comparison', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northeast');
    
    % Error plot
    subplot(2, 2, 2);
    semilogy(t1, abs(y1 - arrayfun(exact, t1)), 'b*-', 'LineWidth', 1.5, ...
        'MarkerSize', 6, 'DisplayName', 'Euler');
    hold on;
    semilogy(t2, abs(y2 - arrayfun(exact, t2)), 'rs-', 'LineWidth', 1.5, ...
        'MarkerSize', 6, 'DisplayName', 'Heun');
    semilogy(t3, abs(y3 - arrayfun(exact, t3)), 'gd-', 'LineWidth', 1.5, ...
        'MarkerSize', 6, 'DisplayName', 'RK4');
    semilogy(t4, abs(y4 - arrayfun(exact, t4)), 'mo', 'LineWidth', 1.5, ...
        'MarkerSize', 4, 'DisplayName', 'ode45');
    hold off;
    grid on;
    xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Absolute error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Error Evolution', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest');
    
    % Zoom on early time
    subplot(2, 2, 3);
    idx = t1 <= 1;
    plot(t_plot(t_plot <= 1), arrayfun(exact, t_plot(t_plot <= 1)), ...
        'k-', 'LineWidth', 2);
    hold on;
    plot(t1(idx), y1(idx), 'b*-', 'MarkerSize', 8, 'LineWidth', 1.5);
    plot(t2(idx), y2(idx), 'rs-', 'MarkerSize', 8, 'LineWidth', 1.5);
    plot(t3(idx), y3(idx), 'gd-', 'MarkerSize', 8, 'LineWidth', 1.5);
    hold off;
    grid on;
    xlabel('$t$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y(t)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Early Time Detail', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Exact', 'Euler', 'Heun', 'RK4', 'Interpreter', 'latex');
    
    % Step count comparison
    subplot(2, 2, 4);
    methods = {'Euler', 'Heun', 'RK4', 'ode45'};
    steps = [length(t1), length(t2), length(t3), length(t4)];
    bar(steps);
    set(gca, 'XTickLabel', methods);
    ylabel('Number of steps', 'Interpreter', 'latex', 'FontSize', 12);
    title('Computational Cost', 'Interpreter', 'latex', 'FontSize', 14);
    grid on;
end

% Execute
Problem8_ODESolvers();
