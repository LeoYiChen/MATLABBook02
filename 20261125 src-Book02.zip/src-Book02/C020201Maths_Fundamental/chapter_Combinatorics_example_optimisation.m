%% chapter_Combinatorics_example_optimisation.m
% Modern computational approaches to combinatorial optimisation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Combinatorics_example_optimisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateCombinatorialOptimisation();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateCombinatorialOptimisation()
    % DEMONSTRATECOMBINATORIALOPTIMISATION Modern optimisation methods
    %   Compares exhaustive search with intelligent sampling approaches
    
    fprintf('Modern Combinatorial Optimisation\n');
    fprintf('==================================\n\n');
    
    %% Computational Complexity Challenge
    fprintf('COMPUTATIONAL COMPLEXITY\n');
    fprintf('----\n\n');
    
    fprintf('Combinatorial explosion limits exhaustive search:\n\n');
    
    problem_sizes = [5, 10, 15, 20, 25];
    
    fprintf('%-15*s  %-25*s  %-20*s\n', 'Problem Size', ...
        'Combinations', 'Years at 1*B ops/sec');
    fprintf('%s\n', repmat('-', 1, 65));
    
    for n = problem_sizes
        if n <= 20
            fact_n = factorial(n);
            seconds = fact_n / 1e9;
            years = seconds / (365.25 * 24 * 3600);
            
            fprintf('%-15*d  %-25.2*e  %20.2*e\n', n, fact_n, years);
        else
            fprintf('%-15*d  %-25*s  %20*s\n', n, 'Too large', 'Infeasible');
        end
    end
    fprintf('\n');
    
    fprintf(['Even modest-sized problems exceed computational feasibility\n', ...
        'for exhaustive enumeration.\n\n']);
    
    %% Knapsack Problem
    fprintf('KNAPSACK PROBLEM DEMONSTRATION\n');
    fprintf('-----\n\n');
    
    fprintf(['The 0-1 knapsack problem: select items to maximise value\n', ...
        'whilst respecting weight capacity constraint.\n\n']);
    
    % Define items (value, weight)
    items = [
        60, 10;   % Item 1
        100, 20;  % Item 2
        120, 30;  % Item 3
        80, 15;   % Item 4
        90, 25;   % Item 5
        70, 18;   % Item 6
        110, 22;  % Item 7
        50, 12;   % Item 8
    ];
    
    capacity = 50;
    num_items = size(items, 1);
    
    fprintf('Items available:\n');
    fprintf('%-8*s  %-10*s  %-10*s\n', 'Item', 'Value', 'Weight');
    fprintf('%s\n', repmat('-', 1, 32));
    
    for i = 1:num_items
        fprintf('%-8*d  %-10.0*f  %-10.0*f\n', i, items(i, 1), items(i, 2));
    end
    
    fprintf('\nKnapsack capacity: %d\n\n', capacity);
    
    % Method 1: Exhaustive search (only feasible for small problems)
    fprintf('METHOD 1: Exhaustive Search\n');
    fprintf('------\n\n');
    
    total_combinations = 2^num_items;
    fprintf('Total combinations to evaluate: %d\n\n', total_combinations);
    
    tic;
    best_value_exhaustive = 0;
    best_selection_exhaustive = [];
    
    for i = 0:(total_combinations - 1)
        % Binary representation indicates item selection
        selection = de2bi(i, num_items);
        
        total_weight = sum(selection .* items(:, 2)');
        total_value = sum(selection .* items(:, 1)');
        
        if total_weight <= capacity && total_value > best_value_exhaustive
            best_value_exhaustive = total_value;
            best_selection_exhaustive = selection;
        end
    end
    
    time_exhaustive = toc;
    
    fprintf('Best solution found:\n');
    fprintf('  Selected items: [%s]\n', ...
        num2str(find(best_selection_exhaustive)));
    fprintf('  Total value: %.0f\n', best_value_exhaustive);
    fprintf('  Total weight: %.0f / %d\n', ...
        sum(best_selection_exhaustive .* items(:, 2)'), capacity);
    fprintf('  Computation time: %.6f seconds\n\n', time_exhaustive);
    
    % Method 2: Greedy heuristic (value-to-weight ratio)
    fprintf('METHOD 2: Greedy Heuristic\n');
    fprintf('-----\n\n');
    
    fprintf('Strategy: Select items by best value-to-weight ratio.\n\n');
    
    tic;
    value_weight_ratio = items(:, 1) ./ items(:, 2);
    [~, sorted_indices] = sort(value_weight_ratio, 'descend');
    
    greedy_selection = zeros(1, num_items);
    current_weight = 0;
    
    for idx = sorted_indices'
        if current_weight + items(idx, 2) <= capacity
            greedy_selection(idx) = 1;
            current_weight = current_weight + items(idx, 2);
        end
    end
    
    greedy_value = sum(greedy_selection .* items(:, 1)');
    greedy_weight = sum(greedy_selection .* items(:, 2)');
    time_greedy = toc;
    
    fprintf('Greedy solution:\n');
    fprintf('  Selected items: [%s]\n', num2str(find(greedy_selection)));
    fprintf('  Total value: %.0f\n', greedy_value);
    fprintf('  Total weight: %.0f / %d\n', greedy_weight, capacity);
    fprintf('  Computation time: %.6f seconds\n\n', time_greedy);
    
    fprintf('Solution quality: %.2f%% of optimal\n', ...
        greedy_value / best_value_exhaustive * 100);
    fprintf('Speedup: %.2fx faster\n\n', time_exhaustive / time_greedy);
    
    % Method 3: Random sampling with multiple trials
    fprintf('METHOD 3: Monte Carlo Sampling\n');
    fprintf('-----\n\n');
    
    num_trials = 10000;
    fprintf('Strategy: Random sampling with %d trials.\n\n', num_trials);
    
    rng(42);
    tic;
    
    best_value_mc = 0;
    best_selection_mc = [];
    
    for trial = 1:num_trials
        % Random selection
        selection = randi([0, 1], 1, num_items);
        
        total_weight = sum(selection .* items(:, 2)');
        total_value = sum(selection .* items(:, 1)');
        
        if total_weight <= capacity && total_value > best_value_mc
            best_value_mc = total_value;
            best_selection_mc = selection;
        end
    end
    
    time_mc = toc;
    
    fprintf('Monte Carlo solution:\n');
    fprintf('  Selected items: [%s]\n', num2str(find(best_selection_mc)));
    fprintf('  Total value: %.0f\n', best_value_mc);
    fprintf('  Total weight: %.0f / %d\n', ...
        sum(best_selection_mc .* items(:, 2)'), capacity);
    fprintf('  Computation time: %.6f seconds\n\n', time_mc);
    
    fprintf('Solution quality: %.2f%% of optimal\n', ...
        best_value_mc / best_value_exhaustive * 100);
    fprintf('Trials evaluated: %d (vs %d exhaustive)\n\n', ...
        num_trials, total_combinations);
    
    %% Travelling Salesman Problem (Small Instance)
    fprintf('TRAVELLING SALESMAN PROBLEM\n');
    fprintf('------\n\n');
    
    fprintf(['Find the shortest route visiting all cities exactly once\n', ...
        'and returning to the starting city.\n\n']);
    
    % Generate random city coordinates
    rng(123);
    num_cities = 8;
    cities = rand(num_cities, 2) * 100;
    
    fprintf('Number of cities: %d\n', num_cities);
    fprintf('Possible tours: %.0f\n\n', factorial(num_cities - 1) / 2);
    
    % Compute distance matrix
    dist_matrix = zeros(num_cities, num_cities);
    for i = 1:num_cities
        for j = 1:num_cities
            dist_matrix(i, j) = norm(cities(i, :) - cities(j, :));
        end
    end
    
    % Greedy nearest neighbour heuristic
    fprintf('Greedy Nearest Neighbour Heuristic:\n');
    
    tic;
    current_city = 1;
    unvisited = 2:num_cities;
    greedy_tour = [current_city];
    greedy_distance = 0;
    
    while ~isempty(unvisited)
        distances_to_unvisited = dist_matrix(current_city, unvisited);
        [min_dist, min_idx] = min(distances_to_unvisited);
        
        next_city = unvisited(min_idx);
        greedy_tour = [greedy_tour, next_city];
        greedy_distance = greedy_distance + min_dist;
        
        current_city = next_city;
        unvisited(min_idx) = [];
    end
    
    % Return to start
    greedy_distance = greedy_distance + ...
        dist_matrix(greedy_tour(end), greedy_tour(1));
    greedy_tour = [greedy_tour, greedy_tour(1)];
    
    time_tsp_greedy = toc;
    
    fprintf('  Tour: [%s]\n', num2str(greedy_tour));
    fprintf('  Distance: %.2f\n', greedy_distance);
    fprintf('  Computation time: %.6f seconds\n\n', time_tsp_greedy);
    
    % Random sampling improvement
    fprintf('Random Sampling with Local Improvement:\n');
    
    num_trials_tsp = 1000;
    tic;
    
    best_tour = greedy_tour;
    best_distance = greedy_distance;
    
    for trial = 1:num_trials_tsp
        % Random permutation
        tour = [1, randperm(num_cities - 1) + 1, 1];
        
        % Calculate distance
        distance = 0;
        for i = 1:(length(tour) - 1)
            distance = distance + dist_matrix(tour(i), tour(i + 1));
        end
        
        if distance < best_distance
            best_distance = distance;
            best_tour = tour;
        end
    end
    
    time_tsp_random = toc;
    
    fprintf('  Best tour: [%s]\n', num2str(best_tour));
    fprintf('  Distance: %.2f\n', best_distance);
    fprintf('  Computation time: %.6f seconds\n', time_tsp_random);
    fprintf('  Improvement: %.2f%%\n\n', ...
        (greedy_distance - best_distance) / greedy_distance * 100);
    
    %% Visualisation
    visualiseKnapsackSolutions(items, capacity, best_selection_exhaustive, ...
        greedy_selection, best_selection_mc);
    visualiseTSP(cities, greedy_tour, best_tour);
end

function selection_binary = de2bi(decimal, num_bits)
    % Convert decimal to binary representation
    selection_binary = zeros(1, num_bits);
    for i = 1:num_bits
        selection_binary(i) = mod(decimal, 2);
        decimal = floor(decimal / 2);
    end
end

function visualiseKnapsackSolutions(items, capacity, optimal, greedy, monte_carlo)
    % Visualise different knapsack solutions
    
    figure('Position', [100, 100, 1400, 500]);
    
    num_items = size(items, 1);
    
    % Optimal solution
    subplot(1, 3, 1);
    bar_data = [items(:, 2) .* optimal', items(:, 1) .* optimal'];
    bar(bar_data);
    xlabel('Item');
    ylabel('Value');
    title('Optimal Solution (Exhaustive Search)');
    legend('Weight', 'Value', 'Location', 'best');
    grid on;
    
    total_weight_opt = sum(optimal .* items(:, 2)');
    total_value_opt = sum(optimal .* items(:, 1)');
    text(num_items * 0.5, max(items(:, 1)) * 0.9, ...
        sprintf('Weight: %.0f/%d\nValue: %.0f', ...
        total_weight_opt, capacity, total_value_opt), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, ...
        'BackgroundColor', 'white');
    
    % Greedy solution
    subplot(1, 3, 2);
    bar_data = [items(:, 2) .* greedy', items(:, 1) .* greedy'];
    bar(bar_data);
    xlabel('Item');
    ylabel('Value');
    title('Greedy Solution');
    legend('Weight', 'Value', 'Location', 'best');
    grid on;
    
    total_weight_greedy = sum(greedy .* items(:, 2)');
    total_value_greedy = sum(greedy .* items(:, 1)');
    text(num_items * 0.5, max(items(:, 1)) * 0.9, ...
        sprintf('Weight: %.0f/%d\nValue: %.0f\n(%.1f%% optimal)', ...
        total_weight_greedy, capacity, total_value_greedy, ...
        total_value_greedy / total_value_opt * 100), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, ...
        'BackgroundColor', 'white');
    
    % Monte Carlo solution
    subplot(1, 3, 3);
    bar_data = [items(:, 2) .* monte_carlo', items(:, 1) .* monte_carlo'];
    bar(bar_data);
    xlabel('Item');
    ylabel('Value');
    title('Monte Carlo Solution');
    legend('Weight', 'Value', 'Location', 'best');
    grid on;
    
    total_weight_mc = sum(monte_carlo .* items(:, 2)');
    total_value_mc = sum(monte_carlo .* items(:, 1)');
    text(num_items * 0.5, max(items(:, 1)) * 0.9, ...
        sprintf('Weight: %.0f/%d\nValue: %.0f\n(%.1f%% optimal)', ...
        total_weight_mc, capacity, total_value_mc, ...
        total_value_mc / total_value_opt * 100), ...
        'HorizontalAlignment', 'center', 'FontSize', 10, ...
        'BackgroundColor', 'white');
end

function visualiseTSP(cities, greedy_tour, best_tour)
    % Visualise travelling salesman problem solutions
    
    figure('Position', [100, 100, 1200, 500]);
    
    % Greedy solution
    subplot(1, 2, 1);
    plot(cities(:, 1), cities(:, 2), 'ro', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'r');
    hold on;
    
    for i = 1:(length(greedy_tour) - 1)
        city1 = greedy_tour(i);
        city2 = greedy_tour(i + 1);
        plot([cities(city1, 1), cities(city2, 1)], ...
            [cities(city1, 2), cities(city2, 2)], 'b-', 'LineWidth', 2);
    end
    
    for i = 1:size(cities, 1)
        text(cities(i, 1) + 2, cities(i, 2) + 2, num2str(i), ...
            'FontSize', 12, 'FontWeight', 'bold');
    end
    
    xlabel('X Coordinate');
    ylabel('Y Coordinate');
    title('Greedy Nearest Neighbour Solution');
    grid on;
    axis equal;
    
    % Best solution
    subplot(1, 2, 2);
    plot(cities(:, 1), cities(:, 2), 'ro', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'r');
    hold on;
    
    for i = 1:(length(best_tour) - 1)
        city1 = best_tour(i);
        city2 = best_tour(i + 1);
        plot([cities(city1, 1), cities(city2, 1)], ...
            [cities(city1, 2), cities(city2, 2)], 'g-', 'LineWidth', 2);
    end
    
    for i = 1:size(cities, 1)
        text(cities(i, 1) + 2, cities(i, 2) + 2, num2str(i), ...
            'FontSize', 12, 'FontWeight', 'bold');
    end
    
    xlabel('X Coordinate');
    ylabel('Y Coordinate');
    title('Best Solution Found (Random Sampling)');
    grid on;
    axis equal;
end
