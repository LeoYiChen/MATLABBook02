%% chapter_AI_Mechanics_Problem7_NSGAII_syntax.m
% NSGA-II multi-objective optimisation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem7_NSGAII_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% NSGA-II using MATLAB's Global Optimization Toolbox
% objectiveFcn: handle to function returning [f1, f2, ..., fn]
% nvars: number of design variables
% lb, ub: lower/upper bounds
% options: algorithm parameters

options = optimoptions('gamultiobj', ...
    'PopulationSize', 100, ...
    'MaxGenerations', 50, ...
    'PlotFcn', {@gaplotpareto}, ...
    'Display', 'iter', ...
    'UseParallel', true);

% Bounds for 8 plies (symmetric   16-ply laminate)
% Each variable: 1=0 , 2=45 , 3=-45 , 4=90 
nvars = 8;
lb = ones(1, nvars);
ub = 4 * ones(1, nvars);

% Integer constraints
IntCon = 1:nvars;

% Run optimization
[paretoSet, paretoFront] = gamultiobj(@objectiveFcn, nvars, ...
    [], [], [], [], lb, ub, [], IntCon, options);

% paretoSet: (numSolutions   nvars) optimal designs
% paretoFront: (numSolutions   numObjectives) objective values
