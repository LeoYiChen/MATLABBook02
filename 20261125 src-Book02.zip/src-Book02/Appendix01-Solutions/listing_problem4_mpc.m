%% listing_problem4_mpc.m
% Problem 4: Model Predictive Control for constrained CSTR temperature regulation with QP optimization, receding horizon implementation, and comprehensive comparison against unconstrained LQR showing explicit constraint handling and setpoint tracking.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem4_mpc
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 4 - Model Predictive Control (MPC)
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: MPC for CSTR temperature control with input/output/rate
%              constraints. QP formulation, receding horizon, comparison
%              with LQR. Demonstrates constraint handling and tracking.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 4: Model Predictive Control for Constrained CSTR\n');
fprintf('==================================================================\n\n');

%% System Parameters and Linearization
fprintf('=== CSTR Model Parameters ===\n');

% Physical parameters
V = 100;           % Reactor volume (m^3)
rho = 1000;        % Density (kg/m^3)
Cp = 4.184;        % Heat capacity (kJ/(kg*K))
q = 100;           % Flow rate (m^3/h)
CA0 = 1.0;         % Feed concentration (kmol/m^3)
T0 = 350;          % Feed temperature (K)
DH = -2e5;         % Heat of reaction (kJ/kmol, exothermic)
k0 = 7.2e10;       % Pre-exponential factor (1/h)
EoverR = 8750;     % E/R (K)
UA = 5e4;          % Heat transfer coeff * area (kJ/(h*K))

fprintf('Reactor volume: %.0f m^3\n', V);
fprintf('Flow rate: %.0f m^3/h\n', q);
fprintf('Heat of reaction: %.2e kJ/kmol\n', DH);

% Steady-state operating point
CAss = 0.50;       % Steady-state concentration (kmol/m^3)
Tss = 373;         % Steady-state temperature (K)
Tcss = 300;        % Steady-state coolant temp (K)

fprintf('\nSteady-state operating point:\n');
fprintf('  CA_ss = %.2f kmol/m^3\n', CAss);
fprintf('  T_ss = %.0f K (%.0f C)\n', Tss, Tss - 273);
fprintf('  Tc_ss = %.0f K (%.0f C)\n\n', Tcss, Tcss - 273);

% Linearization (Jacobian at steady state)
kss = k0 * exp(-EoverR / Tss);

a11 = -q/V - kss;
a12 = -k0 * CAss * exp(-EoverR/Tss) * EoverR / (Tss^2);
a21 = -DH / (rho * Cp) * kss;
a22 = -q/V - DH / (rho * Cp) * k0 * CAss * exp(-EoverR/Tss) * EoverR / (Tss^2) ...
      - UA / (V * rho * Cp);

b1 = 0;
b2 = UA / (V * rho * Cp);

% Continuous-time state-space
Ac = [a11 a12; a21 a22];
Bc = [b1; b2];
Cc = [0 1];  % Output is temperature only
Dc = 0;

fprintf('Continuous-time linearized model:\n');
fprintf('A = [%8.4f %8.4f]\n', Ac(1,1), Ac(1,2));
fprintf('    [%8.4f %8.4f]\n', Ac(2,1), Ac(2,2));
fprintf('B = [%8.4f]\n', Bc(1));
fprintf('    [%8.4f]\n', Bc(2));
fprintf('C = [%8.4f %8.4f]\n\n', Cc(1), Cc(2));

% Eigenvalues (continuous)
eigs_cont = eig(Ac);
fprintf('Continuous eigenvalues:\n');
for idx = 1:length(eigs_cont)
    fprintf('  lambda_%d = %.4f (time const = %.2f h)\n', idx, eigs_cont(idx), -1/eigs_cont(idx));
end
fprintf('\n');

% Discretization
Ts = 0.1;  % Sampling time (h) = 6 minutes
sysc = ss(Ac, Bc, Cc, Dc);
sysd = c2d(sysc, Ts, 'zoh');

[Ad, Bd, Cd, Dd] = ssdata(sysd);

fprintf('Discrete-time model (Ts = %.2f h = %.0f min):\n', Ts, Ts*60);
fprintf('Ad = [%8.4f %8.4f]\n', Ad(1,1), Ad(1,2));
fprintf('     [%8.4f %8.4f]\n', Ad(2,1), Ad(2,2));
fprintf('Bd = [%8.6f]\n', Bd(1));
fprintf('     [%8.6f]\n', Bd(2));
fprintf('Cd = [%8.4f %8.4f]\n\n', Cd(1), Cd(2));

% Check controllability and observability
Co = ctrb(Ad, Bd);
Ob = obsv(Ad, Cd);

fprintf('Controllability matrix rank: %d (system dim: %d)\n', rank(Co), size(Ad,1));
fprintf('Observability matrix rank: %d (system dim: %d)\n\n', rank(Ob), size(Ad,1));

%% MPC Design Parameters
fprintf('=== MPC Design Parameters ===\n');

Np = 20;    % Prediction horizon (samples)
Nc = 5;     % Control horizon (samples)
Q = 100;    % Output weight
R = 1;      % Control move weight

fprintf('Prediction horizon (Np): %d samples = %.1f h\n', Np, Np*Ts);
fprintf('Control horizon (Nc): %d samples = %.1f h\n', Nc, Nc*Ts);
fprintf('Output weight (Q): %.0f\n', Q);
fprintf('Control move weight (R): %.0f\n\n', R);

% Constraints
umin = 280 - Tcss;   % Minimum coolant temp (deviation)
umax = 370 - Tcss;   % Maximum coolant temp (deviation)
ymax = 400 - Tss;    % Maximum reactor temp (deviation)
dumax = 10;          % Maximum control move (K)

fprintf('Constraints (deviation variables):\n');
fprintf('  Input: [%.0f, %.0f] K -> Tc in [%.0f, %.0f] K\n', umin, umax, umin+Tcss, umax+Tcss);
fprintf('  Output: y <= %.0f K -> T <= %.0f K\n', ymax, ymax+Tss);
fprintf('  Rate: |du| <= %.0f K/sample\n\n', dumax);

%% Build MPC Matrices
fprintf('=== Building MPC Prediction Matrices ===\n');

% Prediction matrix F (free response)
F = zeros(Np, size(Ad,1));
for i = 1:Np
    F(i,:) = Cd * (Ad^i);
end

% Control influence matrix Phi
Phi = zeros(Np, Nc);
for i = 1:Np
    for j = 1:min(i, Nc)
        Phi(i,j) = Cd * (Ad^(i-j)) * Bd;
    end
end

fprintf('Matrix dimensions:\n');
fprintf('  F: %dx%d\n', size(F,1), size(F,2));
fprintf('  Phi: %dx%d\n\n', size(Phi,1), size(Phi,2));

% Cost function matrices
Qbar = Q * eye(Np);
Rbar = R * eye(Nc);

H = 2 * (Phi' * Qbar * Phi + Rbar);  % Hessian

fprintf('Hessian H: %dx%d (must be positive definite)\n', size(H,1), size(H,2));
fprintf('  Minimum eigenvalue: %.6f (>0 confirms PD)\n\n', min(eig(H)));

%% Constraint Matrices
fprintf('=== Building Constraint Matrices ===\n');

% Input constraints: umin <= u(k-1) + sum(du) <= umax
% Since u(k+i) = u(k-1) + sum_{j=0}^{i} du(k+j)
% We need: umin <= u(k-1) + M*DU <= umax
% where M is lower triangular matrix of ones

M = tril(ones(Nc, Nc));

% Output constraints: ymin <= Fx + Phi*DU <= ymax
% For one-sided constraint (T <= Tmax only): Phi*DU <= ymax - Fx

% Rate constraints: -dumax <= du(k+i) <= dumax

% Stack all constraints into Aineq * DU <= bineq
% Note: bineq depends on current state x(k) and previous input u(k-1)

fprintf('Constraint matrix construction:\n');
fprintf('  Input constraint rows: %d\n', 2*Nc);
fprintf('  Output constraint rows: %d\n', Np);
fprintf('  Rate constraint rows: %d\n', 2*Nc);
fprintf('  Total inequality constraints: %d\n\n', 2*Nc + Np + 2*Nc);

%% Simulation Setup
fprintf('=== Simulation Setup ===\n');

Tsim = 10;  % Simulation time (hours)
Nsim = round(Tsim / Ts);

fprintf('Simulation time: %.1f h (%d samples)\n', Tsim, Nsim);

% Initial condition (deviation from steady state)
x0 = [0; 5];  % Start 5K above steady state

fprintf('Initial condition: CA = %.2f, T = %.0f K\n', CAss + x0(1), Tss + x0(2));

% Reference trajectory (setpoint changes)
r = zeros(Nsim, 1);
r(1:40) = 0;         % First 4 h: stay at nominal
r(41:70) = 10;       % Next 3 h: increase to 383 K
r(71:end) = -5;      % Rest: decrease to 368 K

fprintf('\nReference trajectory:\n');
fprintf('  t in [0, 4h]: T_ref = %.0f K\n', Tss);
fprintf('  t in [4, 7h]: T_ref = %.0f K\n', Tss + 10);
fprintf('  t in [7, 10h]: T_ref = %.0f K\n\n', Tss - 5);

%% MPC Simulation
fprintf('=== Running MPC Simulation ===\n');

x_mpc = zeros(2, Nsim+1);
y_mpc = zeros(Nsim, 1);
u_mpc = zeros(Nsim, 1);
du_mpc = zeros(Nsim, 1);
J_mpc = zeros(Nsim, 1);

x_mpc(:,1) = x0;
u_prev = 0;  % Previous control (deviation)

for k = 1:Nsim
    % Current state
    xk = x_mpc(:,k);
    
    % Reference over prediction horizon
    if k + Np <= Nsim
        rk = r(k : k+Np-1);
    else
        rk = [r(k:end); repmat(r(end), Np - (Nsim - k + 1), 1)];
    end
    
    % Gradient (state-dependent part of cost)
    fk = 2 * Phi' * Qbar * (F * xk - rk);
    
    % Constraint vector (state-dependent)
    bineq = [
        % Input upper: M*DU <= umax - u(k-1)
        (umax - u_prev) * ones(Nc, 1);
        % Input lower: -M*DU <= -umin + u(k-1)
        (u_prev - umin) * ones(Nc, 1);
        % Output upper: Phi*DU <= ymax - F*xk
        (ymax - F*xk) * ones(Np, 1);
        % Rate upper: DU <= dumax
        dumax * ones(Nc, 1);
        % Rate lower: -DU <= dumax
        dumax * ones(Nc, 1)
    ];
    
    % Constraint matrix
    Aineq = [
        M;          % Input upper
        -M;         % Input lower
        Phi;        % Output upper
        eye(Nc);    % Rate upper
        -eye(Nc)    % Rate lower
    ];
    
    % Solve QP
    options = optimoptions('quadprog', 'Display', 'off');
    [DU_opt, fval, exitflag] = quadprog(H, fk, Aineq, bineq, [], [], [], [], [], options);
    
    if exitflag < 0
        warning('QP solver failed at k=%d, using zero control move', k);
        DU_opt = zeros(Nc, 1);
    end
    
    % Apply first control move
    du_mpc(k) = DU_opt(1);
    u_mpc(k) = u_prev + du_mpc(k);
    u_prev = u_mpc(k);
    
    % Store cost
    J_mpc(k) = fval;
    
    % Simulate system
    x_mpc(:,k+1) = Ad * xk + Bd * u_mpc(k);
    y_mpc(k) = Cd * xk;
    
    % Progress indicator
    if mod(k, 20) == 0
        fprintf('  k = %3d/%d (t = %.1f h)\n', k, Nsim, k*Ts);
    end
end

fprintf('MPC simulation complete.\n\n');

%% LQR Simulation (for comparison)
fprintf('=== Running LQR Simulation (unconstrained) ===\n');

% LQR design
QLQR = Cd' * Q * Cd;  % State weight (penalize only temperature)
RLQR = R;

[KLQR, ~, ~] = dlqr(Ad, Bd, QLQR, RLQR);

fprintf('LQR gain: K = [%.4f, %.4f]\n\n', KLQR(1), KLQR(2));

x_lqr = zeros(2, Nsim+1);
y_lqr = zeros(Nsim, 1);
u_lqr = zeros(Nsim, 1);

x_lqr(:,1) = x0;

for k = 1:Nsim
    % LQR control law (tracking)
    u_lqr(k) = -KLQR * x_lqr(:,k);  % For regulation to origin
    
    % Simulate
    x_lqr(:,k+1) = Ad * x_lqr(:,k) + Bd * u_lqr(k);
    y_lqr(k) = Cd * x_lqr(:,k);
end

fprintf('LQR simulation complete.\n\n');

%% Performance Analysis
fprintf('=== Performance Analysis ===\n');

% Time vector
t = (0:Nsim-1) * Ts;

% Convert to absolute values
T_mpc = Tss + y_mpc;
T_lqr = Tss + y_lqr;
T_ref = Tss + r;
Tc_mpc = Tcss + u_mpc;
Tc_lqr = Tcss + u_lqr;

% Tracking error
e_mpc = r - y_mpc;
e_lqr = r - y_lqr;

% RMS tracking error
rms_mpc = sqrt(mean(e_mpc.^2));
rms_lqr = sqrt(mean(e_lqr.^2));

fprintf('RMS tracking error:\n');
fprintf('  MPC: %.4f K\n', rms_mpc);
fprintf('  LQR: %.4f K\n\n', rms_lqr);

% Control effort (total variation)
tv_mpc = sum(abs(du_mpc));
tv_lqr = sum(abs(diff([0; u_lqr])));

fprintf('Total control variation:\n');
fprintf('  MPC: %.2f K\n', tv_mpc);
fprintf('  LQR: %.2f K\n\n', tv_lqr);

% Constraint violations
viol_u_mpc = sum(u_mpc < umin | u_mpc > umax);
viol_u_lqr = sum(u_lqr < umin | u_lqr > umax);
viol_y_mpc = sum(y_mpc > ymax);
viol_y_lqr = sum(y_lqr > ymax);
viol_du_mpc = sum(abs(du_mpc) > dumax + 1e-6);  % Small tolerance
viol_du_lqr = sum(abs(diff([0; u_lqr])) > dumax);

fprintf('Constraint violations:\n');
fprintf('  MPC - Input: %d, Output: %d, Rate: %d\n', viol_u_mpc, viol_y_mpc, viol_du_mpc);
fprintf('  LQR - Input: %d, Output: %d, Rate: %d\n\n', viol_u_lqr, viol_y_lqr, viol_du_lqr);

%% Visualization
fprintf('=== Generating Plots ===\n');

figure('Position', [50, 50, 1400, 900]);

% Temperature tracking
subplot(3,2,1);
plot(t, T_ref, 'k-', 'LineWidth', 1.5, 'DisplayName', 'Reference');
hold on;
plot(t, T_mpc, 'b-', 'LineWidth', 1.2, 'DisplayName', 'MPC');
plot(t, T_lqr, 'r-', 'LineWidth', 1.2, 'DisplayName', 'LQR');
yline(Tss + ymax, 'r-', 'Safety Limit', 'LineWidth', 1, 'DisplayName', 'Constraint');
grid on;
xlabel('Time (h)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Temperature (K)', 'Interpreter', 'latex', 'FontSize', 11);
title('Reactor Temperature Tracking', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');

% Coolant temperature (control input)
subplot(3,2,2);
plot(t, Tc_mpc, 'b-', 'LineWidth', 1.2, 'DisplayName', 'MPC');
hold on;
plot(t, Tc_lqr, 'r-', 'LineWidth', 1.2, 'DisplayName', 'LQR');
yline(280, 'k-', 'LineWidth', 1, 'DisplayName', 'Lower Limit');
yline(370, 'k-', 'LineWidth', 1, 'DisplayName', 'Upper Limit');
grid on;
xlabel('Time (h)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Coolant Temperature (K)', 'Interpreter', 'latex', 'FontSize', 11);
title('Control Input: $T_c$', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');
ylim([270 380]);

% Control moves
subplot(3,2,3);
stairs(t, du_mpc, 'b-', 'LineWidth', 1.2, 'DisplayName', 'MPC');
hold on;
stairs(t, [0; diff(u_lqr)], 'r-', 'LineWidth', 1.2, 'DisplayName', 'LQR');
yline(dumax, 'k-', 'LineWidth', 1, 'DisplayName', 'Rate Limit');
yline(-dumax, 'k-', 'LineWidth', 1);
grid on;
xlabel('Time (h)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Control Move (K)', 'Interpreter', 'latex', 'FontSize', 11);
title('Rate of Change: $\Delta T_c$', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');

% Tracking error
subplot(3,2,4);
plot(t, e_mpc, 'b-', 'LineWidth', 1.2, 'DisplayName', 'MPC');
hold on;
plot(t, e_lqr, 'r-', 'LineWidth', 1.2, 'DisplayName', 'LQR');
yline(0, 'k-', 'LineWidth', 0.5);
grid on;
xlabel('Time (h)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Tracking Error (K)', 'Interpreter', 'latex', 'FontSize', 11);
title('Temperature Tracking Error', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');

% Cost evolution (MPC only)
subplot(3,2,5);
plot(t, J_mpc, 'b-', 'LineWidth', 1.2);
grid on;
xlabel('Time (h)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Cost Function Value', 'Interpreter', 'latex', 'FontSize', 11);
title('MPC Cost Evolution', 'Interpreter', 'latex', 'FontSize', 13);

% State trajectory
subplot(3,2,6);
plot(x_mpc(1,:), x_mpc(2,:), 'b-', 'LineWidth', 1.2, 'DisplayName', 'MPC');
hold on;
plot(x_lqr(1,:), x_lqr(2,:), 'r-', 'LineWidth', 1.2, 'DisplayName', 'LQR');
plot(0, 0, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'g', 'DisplayName', 'Origin');
grid on;
xlabel('$\tilde{C}_A$ (kmol/m$^3$)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$\tilde{T}$ (K)', 'Interpreter', 'latex', 'FontSize', 11);
title('State-Space Trajectory', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');

saveas(gcf, 'Problem04_MPC_Simulation.fig');
saveas(gcf, 'Problem04_MPC_Simulation.eps', 'epsc');
saveas(gcf, 'Problem04_MPC_Simulation.jpg');
fprintf('Saved: Problem04_MPC_Simulation.fig/.eps/.jpg\n\n');

%% Detailed Constraint Analysis
fprintf('=== Detailed Constraint Analysis ===\n');

figure('Position', [100, 100, 1400, 500]);

subplot(1,3,1);
histogram(u_mpc, 20, 'FaceColor', 'b', 'EdgeColor', 'k', 'FaceAlpha', 0.7);
hold on;
xline(umin, 'r-', 'LineWidth', 2, 'DisplayName', 'Lower Limit');
xline(umax, 'r-', 'LineWidth', 2, 'DisplayName', 'Upper Limit');
xlabel('Control Input $u$ (K)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
title('MPC: Input Constraint Distribution', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex');
grid on;

subplot(1,3,2);
histogram(y_mpc, 20, 'FaceColor', 'b', 'EdgeColor', 'k', 'FaceAlpha', 0.7);
hold on;
xline(ymax, 'r-', 'LineWidth', 2, 'DisplayName', 'Safety Limit');
xlabel('Output $y$ (K)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
title('MPC: Output Constraint Distribution', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex');
grid on;

subplot(1,3,3);
histogram(du_mpc, 20, 'FaceColor', 'b', 'EdgeColor', 'k', 'FaceAlpha', 0.7);
hold on;
xline(dumax, 'r-', 'LineWidth', 2, 'DisplayName', 'Upper Limit');
xline(-dumax, 'r-', 'LineWidth', 2, 'DisplayName', 'Lower Limit');
xlabel('Control Move $\Delta u$ (K)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
title('MPC: Rate Constraint Distribution', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex');
grid on;

saveas(gcf, 'Problem04_Constraint_Analysis.fig');
saveas(gcf, 'Problem04_Constraint_Analysis.eps', 'epsc');
saveas(gcf, 'Problem04_Constraint_Analysis.jpg');
fprintf('Saved: Problem04_Constraint_Analysis.fig/.eps/.jpg\n\n');

fprintf('=== Problem 4 Complete ===\n');
