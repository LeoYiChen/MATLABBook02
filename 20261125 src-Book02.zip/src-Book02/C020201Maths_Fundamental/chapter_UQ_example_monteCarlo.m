%% chapter_UQ_example_monteCarlo.m
% Monte Carlo uncertainty propagation for cantilever beam deflection, with Latin Hypercube variance reduction and Wilson score intervals for exceedance probability.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_UQ_example_monteCarlo
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Monte Carlo uncertainty propagation: cantilever beam tip deflection
%  Model:  delta = F*L^3 / (3*E*I),   I = b*h^3/12
%  Requires: base MATLAB, R2016b or later. No toolboxes required.
%
%  Usage example:
%     >> chapter_UQ_example_monteCarlo     % run as a script
%
%  Expected output: mean tip deflection near 8.0 mm, coefficient of
%  variation near 8 per cent, and an exceedance probability below 1e-3
%  against a 15 mm serviceability limit.

clearvars; close all; clc;
rng(42, 'twister');                      % reproducible random stream

runCantileverUncertaintyStudy();

%% --------- local functions -----------
function runCantileverUncertaintyStudy()

    % -- Stage 1: uncertainty model (lognormal marginals, all positive) --
    inputNames  = {'Force F [N]', 'Length L [m]', 'Modulus E [Pa]', ...
                   'Width b [m]', 'Height h [m]'};
    inputMeans  = [1000,  2.00,  200e9, 0.050, 0.100];
    inputStdDev = [  50,  0.01,   10e9, 0.001, 0.002];

    fprintf('Cantilever beam: Monte Carlo uncertainty propagation\n');
    fprintf('===================================================\n\n');
    fprintf('%-16s %13s %13s %9s\n', 'Input', 'Mean', 'Std dev', 'CoV [%]');
    for inputIndex = 1:numel(inputNames)
        fprintf('%-16s %13.4g %13.4g %9.2f\n', inputNames{inputIndex}, ...
            inputMeans(inputIndex), inputStdDev(inputIndex), ...
            100 * inputStdDev(inputIndex) / inputMeans(inputIndex));
    end

    % -- Stage 2: crude Monte Carlo propagation ----------
    numSamples   = 20000;
    inputSamples = drawLognormalSamples(inputMeans, inputStdDev, numSamples);
    deflectionMm = 1e3 * cantileverDeflection(inputSamples);

    meanDeflection = mean(deflectionMm);
    stdDeflection  = std(deflectionMm);
    standardError  = stdDeflection / sqrt(numSamples);

    fprintf('\nOutput summary (N = %d):\n', numSamples);
    fprintf('  Mean deflection      : %.4f mm\n', meanDeflection);
    fprintf('  Standard deviation   : %.4f mm\n', stdDeflection);
    fprintf('  Coefficient of var.  : %.2f %%\n', ...
        100 * stdDeflection / meanDeflection);
    fprintf('  Standard error of mean: %.5f mm\n', standardError);
    fprintf('  95%% CI for the mean  : [%.4f, %.4f] mm\n', ...
        meanDeflection - 1.96 * standardError, ...
        meanDeflection + 1.96 * standardError);

    quantileLevels = [5 25 50 75 95 99];
    quantileValues = empiricalPercentile(deflectionMm, quantileLevels);
    fprintf('  Percentiles [mm]     :');
    fprintf(' P%d=%.3f', [quantileLevels; quantileValues]);
    fprintf('\n');

    % -- Stage 3: exact analytical benchmark ----------
    % A product/quotient of independent lognormals is exactly lognormal.
    % Hence  1 + CoV_delta^2 = prod(1 + CoV_i^2)  with h entering cubed.
    inputCoV      = inputStdDev ./ inputMeans;
    exponentVector = [1, 3, -1, -1, -3];        % powers of F, L, E, b, h
    logVariance   = sum((exponentVector.^2) .* log(1 + inputCoV.^2));
    exactCoV      = sqrt(exp(logVariance) - 1);

    fprintf('\nExact lognormal benchmark:\n');
    fprintf('  Analytical CoV       : %.4f\n', exactCoV);
    fprintf('  Monte Carlo CoV      : %.4f\n', stdDeflection / meanDeflection);
    fprintf('  Relative discrepancy : %.2f %%\n', ...
        100 * abs(stdDeflection / meanDeflection - exactCoV) / exactCoV);

    % -- Stage 4: serviceability assessment with a Wilson interval ---
    designLimitMm  = 15;
    numExceedances = sum(deflectionMm > designLimitMm);
    exceedanceRate = numExceedances / numSamples;
    [wilsonLow, wilsonHigh] = wilsonScoreInterval(numExceedances, ...
        numSamples, 1.959964);

    fprintf('\nServiceability assessment (limit = %.1f mm):\n', designLimitMm);
    fprintf('  Exceedances observed : %d of %d\n', numExceedances, numSamples);
    fprintf('  Point estimate       : %.3e\n', exceedanceRate);
    fprintf('  95%% Wilson interval : [%.3e, %.3e]\n', wilsonLow, wilsonHigh);
    fprintf('  (Wald intervals are unreliable at this rate; see Brown 2001)\n');

    % -- Stage 5: convergence diagnostics -----------
    runningCount = (1:numSamples)';
    runningMean  = cumsum(deflectionMm) ./ runningCount;
    runningVar   = (cumsum(deflectionMm.^2) - ...
                    runningCount .* runningMean.^2) ./ max(runningCount-1, 1);
    runningStd   = sqrt(max(runningVar, 0));

    % -- Stage 6: does Latin Hypercube Sampling actually help? -----
    % Variance reduction concerns the ESTIMATOR, so replicate the study.
    numReplicates = 40;
    sampleBudget  = 500;
    crudeEstimates = zeros(numReplicates, 1);
    lhsEstimates   = zeros(numReplicates, 1);

    for replicateIndex = 1:numReplicates
        crudeSamples = drawLognormalSamples(inputMeans, inputStdDev, ...
            sampleBudget);
        crudeEstimates(replicateIndex) = ...
            mean(1e3 * cantileverDeflection(crudeSamples));

        unitLhs    = latinHypercubeUniform(sampleBudget, numel(inputMeans));
        lhsSamples = lognormalQuantile(unitLhs, inputMeans, inputStdDev);
        lhsEstimates(replicateIndex) = ...
            mean(1e3 * cantileverDeflection(lhsSamples));
    end

    varianceRatio = var(crudeEstimates) / var(lhsEstimates);

    fprintf('\nVariance reduction study (%d replicates of N = %d):\n', ...
        numReplicates, sampleBudget);
    fprintf('  Crude MC estimator std : %.5f mm\n', std(crudeEstimates));
    fprintf('  LHS estimator std      : %.5f mm\n', std(lhsEstimates));
    fprintf('  Variance ratio         : %.2f (efficiency gain)\n', ...
        varianceRatio);
    fprintf('  Equivalent crude budget: %d samples\n', ...
        round(varianceRatio * sampleBudget));

    % -- Stage 7: visualisation ---------------
    visualiseMonteCarloStudy(deflectionMm, designLimitMm, meanDeflection, ...
        stdDeflection, runningCount, runningMean, runningStd, ...
        crudeEstimates, lhsEstimates);
end

function deflection = cantileverDeflection(inputMatrix)
    % Tip deflection of a rectangular-section cantilever under an end load.
    appliedForce = inputMatrix(:, 1);
    beamLength   = inputMatrix(:, 2);
    youngModulus = inputMatrix(:, 3);
    sectionWidth = inputMatrix(:, 4);
    sectionDepth = inputMatrix(:, 5);

    secondMoment = sectionWidth .* sectionDepth.^3 / 12;
    deflection   = (appliedForce .* beamLength.^3) ./ ...
                   (3 * youngModulus .* secondMoment);
end

function [muLog, sigmaLog] = lognormalParameters(meanVector, stdVector)
    % Method-of-moments mapping from (mean, std) to lognormal parameters.
    sigmaLog = sqrt(log(1 + (stdVector ./ meanVector).^2));
    muLog    = log(meanVector) - 0.5 * sigmaLog.^2;
end

function sampleMatrix = drawLognormalSamples(meanVector, stdVector, numSamples)
    [muLog, sigmaLog] = lognormalParameters(meanVector, stdVector);
    standardNormal    = randn(numSamples, numel(meanVector));
    sampleMatrix      = exp(standardNormal .* sigmaLog + muLog);
end

function sampleMatrix = lognormalQuantile(unitMatrix, meanVector, stdVector)
    % Inverse-transform sampling; norminv replaced by its erfcinv identity.
    [muLog, sigmaLog] = lognormalParameters(meanVector, stdVector);
    standardNormal    = -sqrt(2) * erfcinv(2 * unitMatrix);
    sampleMatrix      = exp(standardNormal .* sigmaLog + muLog);
end

function unitMatrix = latinHypercubeUniform(numSamples, numDimensions)
    % Latin Hypercube design on the unit hypercube, without lhsdesign.
    unitMatrix = zeros(numSamples, numDimensions);
    for dimensionIndex = 1:numDimensions
        stratumOrder = randperm(numSamples)';
        unitMatrix(:, dimensionIndex) = ...
            (stratumOrder - rand(numSamples, 1)) / numSamples;
    end
end

function quantileValues = empiricalPercentile(dataVector, percentLevels)
    % Percentiles via mid-point plotting positions; replaces prctile.
    sortedData      = sort(dataVector(:));
    numObservations = numel(sortedData);
    plottingPosition = ((1:numObservations)' - 0.5) / numObservations;
    quantileValues  = interp1(plottingPosition, sortedData, ...
        percentLevels(:) / 100, 'linear', 'extrap')';
end

function [lowerBound, upperBound] = wilsonScoreInterval(numSuccess, ...
    numTrials, criticalValue)
    % Wilson (1927) score interval: far superior to Wald for small rates.
    proportion  = numSuccess / numTrials;
    denominator = 1 + criticalValue^2 / numTrials;
    centre      = (proportion + criticalValue^2 / (2 * numTrials)) / denominator;
    halfWidth   = (criticalValue / denominator) * ...
        sqrt(proportion * (1 - proportion) / numTrials + ...
             criticalValue^2 / (4 * numTrials^2));
    lowerBound  = max(0, centre - halfWidth);
    upperBound  = min(1, centre + halfWidth);
end

function densityValues = standardNormalPdf(zValues)
    densityValues = exp(-0.5 * zValues.^2) / sqrt(2*pi);
end

function visualiseMonteCarloStudy(deflectionMm, designLimitMm, ...
    meanDeflection, stdDeflection, runningCount, runningMean, ...
    runningStd, crudeEstimates, lhsEstimates)

    figure('Position', [100, 100, 1400, 850], 'Name', 'Monte Carlo study');

    % (a) Output histogram with normal and lognormal overlays
    subplot(2, 3, 1);
    histogram(deflectionMm, 60, 'Normalization', 'pdf', ...
        'FaceColor', [0.35 0.60 0.85], 'EdgeColor', 'none');
    hold on;
    gridPoints = linspace(min(deflectionMm), max(deflectionMm), 400);
    plot(gridPoints, standardNormalPdf((gridPoints - meanDeflection) / ...
        stdDeflection) / stdDeflection, 'r-', 'LineWidth', 2);
    [muLog, sigmaLog] = lognormalParameters(meanDeflection, stdDeflection);
    plot(gridPoints, standardNormalPdf((log(gridPoints) - muLog) / ...
        sigmaLog) ./ (gridPoints * sigmaLog), 'k--', 'LineWidth', 2);
    xline(designLimitMm, 'm-', 'LineWidth', 2);
    xlabel('Tip deflection [mm]'); ylabel('Probability density');
    title('(a) Output distribution');
    legend('Samples', 'Normal fit', 'Lognormal fit', 'Design limit', ...
        'Location', 'northeast');
    grid on;

    % (b) Empirical CDF on a probability scale
    subplot(2, 3, 2);
    sortedDeflection = sort(deflectionMm);
    empiricalCdf = ((1:numel(sortedDeflection))' - 0.5) / ...
        numel(sortedDeflection);
    semilogy(sortedDeflection, 1 - empiricalCdf, 'b-', 'LineWidth', 1.6);
    hold on; xline(designLimitMm, 'm-', 'LineWidth', 2);
    xlabel('Tip deflection [mm]'); ylabel('Exceedance probability');
    title('(b) Complementary CDF'); grid on;

    % (c) Normal quantile-quantile plot of the LOG deflection
    subplot(2, 3, 3);
    plotNormalQuantileQuantile(log(deflectionMm));
    title('(c) Q-Q plot of log deflection');

    % (d) Convergence of the mean with a shrinking confidence band
    subplot(2, 3, 4);
    thinIndex = round(logspace(1, log10(numel(runningMean)), 400));
    plot(runningCount(thinIndex), runningMean(thinIndex), 'b-', ...
        'LineWidth', 1.6);
    hold on;
    upperBand = meanDeflection + 1.96 * stdDeflection ./ ...
        sqrt(runningCount(thinIndex));
    lowerBand = meanDeflection - 1.96 * stdDeflection ./ ...
        sqrt(runningCount(thinIndex));
    fill([runningCount(thinIndex); flipud(runningCount(thinIndex))], ...
         [upperBand; flipud(lowerBand)], 'r', 'FaceAlpha', 0.15, ...
         'EdgeColor', 'none');
    set(gca, 'XScale', 'log');
    xlabel('Sample count N'); ylabel('Running mean [mm]');
    title('(d) Convergence of the mean'); grid on;

    % (e) Empirical versus theoretical error decay
    subplot(2, 3, 5);
    absoluteError = abs(runningMean(thinIndex) - meanDeflection);
    loglog(runningCount(thinIndex), absoluteError, 'b-', 'LineWidth', 1.2);
    hold on;
    loglog(runningCount(thinIndex), ...
        stdDeflection ./ sqrt(runningCount(thinIndex)), 'r--', ...
        'LineWidth', 2);
    xlabel('Sample count N'); ylabel('Absolute error [mm]');
    title('(e) O(N^{-1/2}) error decay');
    legend('Observed', 'Theoretical', 'Location', 'southwest'); grid on;

    % (f) Estimator scatter: crude Monte Carlo versus Latin Hypercube
    subplot(2, 3, 6);
    boxplotSurrogate([crudeEstimates, lhsEstimates], ...
        {'Crude MC', 'Latin Hypercube'});
    ylabel('Estimated mean deflection [mm]');
    title('(f) Estimator variance at fixed budget'); grid on;
end

function plotNormalQuantileQuantile(dataVector)
    % Deliberately NOT named qqplot, to avoid shadowing the Toolbox function.
    sortedData       = sort(dataVector(:));
    numObservations  = numel(sortedData);
    plottingPosition = ((1:numObservations)' - 0.5) / numObservations;
    theoreticalZ     = -sqrt(2) * erfcinv(2 * plottingPosition);

    plot(theoreticalZ, sortedData, '.', 'MarkerSize', 6); hold on;
    referenceSlope     = std(sortedData);
    referenceIntercept = mean(sortedData);
    plot(theoreticalZ, referenceIntercept + referenceSlope * theoreticalZ, ...
        'r-', 'LineWidth', 1.8);
    xlabel('Standard normal quantile'); ylabel('Sample quantile');
    grid on;
end

function boxplotSurrogate(dataMatrix, groupLabels)
    % Compact five-number summary without the Statistics Toolbox boxplot.
    numGroups = size(dataMatrix, 2);
    hold on;
    for groupIndex = 1:numGroups
        columnData = dataMatrix(:, groupIndex);
        fiveNumber = empiricalPercentile(columnData, [5 25 50 75 95]);
        plot(groupIndex * [1 1], fiveNumber([1 5]), 'k-', 'LineWidth', 1);
        patchX = groupIndex + 0.22 * [-1 1 1 -1];
        patchY = fiveNumber([2 2 4 4]);
        patch(patchX, patchY, [0.45 0.75 0.90], 'EdgeColor', 'k');
        plot(groupIndex + 0.22 * [-1 1], fiveNumber([3 3]), 'r-', ...
            'LineWidth', 2);
    end
    set(gca, 'XTick', 1:numGroups, 'XTickLabel', groupLabels);
    xlim([0.5, numGroups + 0.5]);
end

% -----------------------
% Computational complexity. Crude propagation costs O(N d) operations and
% O(N d) memory for d inputs; the model itself is O(1) per sample, so the
% study is sampling-bound. Convergence diagnostics reuse cumulative sums
% at O(N), avoiding an O(N^2) recomputation. The Latin Hypercube design
% costs O(N d) through randperm. Standard error falls as O(N^{-1/2}),
% independently of d, so accuracy is bought at quadratic cost. Note that
% the cumsum variance recursion is numerically delicate for large N;
% Welford's algorithm is preferable when N exceeds roughly 1e8.
% -----------------------
