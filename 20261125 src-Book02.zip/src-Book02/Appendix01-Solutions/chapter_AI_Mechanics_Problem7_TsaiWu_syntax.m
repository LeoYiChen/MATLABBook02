%% chapter_AI_Mechanics_Problem7_TsaiWu_syntax.m
% Tsai-Wu failure criterion syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem7_TsaiWu_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Tsai-Wu failure criterion
% sigma: [sigma_1; sigma_2; tau_12] stress in ply coordinates
% XT, XC: tensile/compressive strength in fibre direction
% YT, YC: tensile/compressive strength transverse to fibre
% S: shear strength

function FI = tsaiWu(sigma, XT, XC, YT, YC, S)
    % Tsai-Wu coefficients
    F1 = 1/XT - 1/XC;
    F2 = 1/YT - 1/YC;
    F11 = 1/(XT * XC);
    F22 = 1/(YT * YC);
    F66 = 1/S^2;
    F12 = -0.5 * sqrt(F11 * F22);  % Interaction term (typically -0.5)
    
    % Failure index
    FI = F1*sigma(1) + F2*sigma(2) + ...
         F11*sigma(1)^2 + F22*sigma(2)^2 + F66*sigma(3)^2 + ...
         2*F12*sigma(1)*sigma(2);
    
    % FI < 1: safe, FI = 1: failure, FI > 1: failed
end
