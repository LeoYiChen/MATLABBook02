%% Appendix01-Solutions_code_252.m
% Physics-Informed Neural Networks for System Modeling
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Physics-Informed Neural Networks (PINNs)
% Problem 18: System Modeling with Physical Constraints
% Author: Control Systems Course
% Description: Complete PINN implementation for ODEs and chaotic systems
% Requires: Deep Learning Toolbox (R2020b or later)

clear all; close all; clc;
rng(42);

fprintf('=== Physics-Informed Neural Networks (PINNs) ===\n\n');

%% Part 1: Damped Harmonic Oscillator

fprintf('PART 1: DAMPED HARMONIC OSCILLATOR\n');
fprintf('===================================\n\n');

% System parameters
omega_n = 2*pi;     % Natural frequency (rad/s)
zeta = 0.1;         % Damping ratio
x0 = 1.0;           % Initial position (m)
v0 = 0.0;           % Initial velocity (m/s)

fprintf('True System Parameters:\n');
fprintf('  Natural frequency  _n: %.2f rad/s (%.2f Hz)\n', omega_n, omega_n/(2*pi));
fprintf('  Damping ratio  : %.2f\n', zeta);
fprintf('  Initial conditions: x = %.1f m, v = %.1f m/s\n\n', x0, v0);

% Time domain
t_span = [0, 5];
t_data = linspace(t_span(1), t_span(2), 100)';

% Generate ground truth data using analytical solution
omega_d = omega_n * sqrt(1 - zeta^2);  % Damped frequency
A = sqrt(x0^2 + ((v0 + zeta*omega_n*x0)/omega_d)^2);
phi = atan2(-(v0 + zeta*omega_n*x0)/omega_d, x0);
x_true = A * exp(-zeta*omega_n*t_data) .* cos(omega_d*t_data + phi);
v_true = gradient(x_true, t_data);

% Add noise to create observations
noise_level = 0.05;
x_obs = x_true + noise_level * std(x_true) * randn(size(x_true));

% Sparse sampling for training
n_data_points = 20;
data_indices = sort(randperm(length(t_data), n_data_points));
t_train = t_data(data_indices);
x_train = x_obs(data_indices);

fprintf('Data Generation:\n');
fprintf('  Total time points: %d\n', length(t_data));
fprintf('  Training data points: %d (sparse sampling)\n', n_data_points);
fprintf('  Noise level: %.1f%%\n\n', noise_level*100);

%% Build PINN for Damped Oscillator

fprintf('Building PINN architecture...\n');

% Network architecture
layers_osc = [
    featureInputLayer(1, 'Name', 'time', 'Normalization', 'none')
    fullyConnectedLayer(32, 'Name', 'fc1')
    tanhLayer('Name', 'tanh1')
    fullyConnectedLayer(32, 'Name', 'fc2')
    tanhLayer('Name', 'tanh2')
    fullyConnectedLayer(32, 'Name', 'fc3')
    tanhLayer('Name', 'tanh3')
    fullyConnectedLayer(1, 'Name', 'displacement')
];

net_osc = dlnetwork(layers_osc);

fprintf('  Architecture: 1-32-32-32-1 (tanh activations)\n');
fprintf('  Total parameters: %d\n\n', numel(net_osc.Learnables.Value));

%% Training Setup

% Hyperparameters
params_osc = struct();
params_osc.lr = 0.01;
params_osc.epochs = 5000;
params_osc.lambda_data = 1.0;     % Weight for data loss
params_osc.lambda_physics = 0.1;   % Weight for physics loss
params_osc.lambda_ic = 10.0;       % Weight for initial conditions
params_osc.n_collocation = 200;    % Collocation points for physics

% Generate collocation points
t_colloc = linspace(t_span(1), t_span(2), params_osc.n_collocation)';

fprintf('Training Configuration:\n');
fprintf('  Learning rate: %.4f\n', params_osc.lr);
fprintf('  Epochs: %d\n', params_osc.epochs);
fprintf('  Loss weights - Data: %.1f, Physics: %.2f, IC: %.1f\n', ...
        params_osc.lambda_data, params_osc.lambda_physics, params_osc.lambda_ic);
fprintf('  Collocation points: %d\n\n', params_osc.n_collocation);

% Initialize Adam optimizer
avg_grad_osc = [];
avg_grad_sq_osc = [];

% Training history
history_osc = struct();
history_osc.loss_total = zeros(params_osc.epochs, 1);
history_osc.loss_data = zeros(params_osc.epochs, 1);
history_osc.loss_physics = zeros(params_osc.epochs, 1);
history_osc.loss_ic = zeros(params_osc.epochs, 1);

%% Training Loop for Damped Oscillator

fprintf('Training PINN for damped oscillator...\n');
tic;

for epoch = 1:params_osc.epochs
    % Compute losses and gradients
    [loss_total, loss_data, loss_physics, loss_ic, grads] = ...
        dlfeval(@oscillator_loss, net_osc, t_train, x_train, t_colloc, ...
                omega_n, zeta, x0, v0, params_osc);
    
    % Update network using Adam
    [net_osc, avg_grad_osc, avg_grad_sq_osc] = ...
        adamupdate(net_osc, grads, avg_grad_osc, avg_grad_sq_osc, epoch, params_osc.lr);
    
    % Store history
    history_osc.loss_total(epoch) = double(extractdata(loss_total));
    history_osc.loss_data(epoch) = double(extractdata(loss_data));
    history_osc.loss_physics(epoch) = double(extractdata(loss_physics));
    history_osc.loss_ic(epoch) = double(extractdata(loss_ic));
    
    % Display progress
    if mod(epoch, 500) == 0 || epoch == 1
        fprintf('Epoch %5d/%d | Total: %.6f | Data: %.6f | Physics: %.6f | IC: %.6f\n', ...
                epoch, params_osc.epochs, history_osc.loss_total(epoch), ...
                history_osc.loss_data(epoch), history_osc.loss_physics(epoch), ...
                history_osc.loss_ic(epoch));
    end
end

training_time_osc = toc;
fprintf('Training completed in %.1f seconds\n\n', training_time_osc);

%% Evaluate Damped Oscillator PINN

fprintf('Evaluating trained model...\n');

% Predict on full time domain
t_test = linspace(t_span(1), t_span(2), 500)';
t_test_dl = dlarray(t_test', 'CB');
x_pred = extractdata(predict(net_osc, t_test_dl))';

% Compute errors
x_test_true = A * exp(-zeta*omega_n*t_test) .* cos(omega_d*t_test + phi);
mse = mean((x_pred - x_test_true).^2);
rmse = sqrt(mse);
mae = mean(abs(x_pred - x_test_true));

fprintf('  RMSE: %.6f\n', rmse);
fprintf('  MAE: %.6f\n', mae);
fprintf('  Relative error: %.2f%%\n\n', 100*rmse/std(x_test_true));

%% Loss Function for Damped Oscillator

function [loss_total, loss_data, loss_physics, loss_ic, grads] = ...
         oscillator_loss(net, t_data, x_data, t_colloc, omega_n, zeta, x0, v0, params)
    
    % Convert to dlarray
    t_data_dl = dlarray(t_data', 'CB');
    x_data_dl = dlarray(x_data', 'CB');
    t_colloc_dl = dlarray(t_colloc', 'CB');
    
    %% Data Loss
    x_pred_data = predict(net, t_data_dl);
    loss_data = mean((x_pred_data - x_data_dl).^2);
    
    %% Physics Loss
    % Forward pass at collocation points
    x_colloc = predict(net, t_colloc_dl);
    
    % Compute first derivative using automatic differentiation
    x_dot = dlgradient(sum(x_colloc), t_colloc_dl, 'EnableHigherDerivatives', true);
    
    % Compute second derivative
    x_ddot = dlgradient(sum(x_dot), t_colloc_dl);
    
    % Physics residual: x'' + 2*zeta*omega_n*x' + omega_n^2*x = 0
    residual = x_ddot + 2*zeta*omega_n*x_dot + omega_n^2*x_colloc;
    loss_physics = mean(residual.^2);
    
    %% Initial Condition Loss
    t_ic = dlarray(0, 'CB');
    x_ic = predict(net, t_ic);
    x_dot_ic = dlgradient(sum(x_ic), t_ic);
    
    loss_ic = (x_ic - x0)^2 + (x_dot_ic - v0)^2;
    
    %% Total Loss
    loss_total = params.lambda_data * loss_data + ...
                 params.lambda_physics * loss_physics + ...
                 params.lambda_ic * loss_ic;
    
    % Compute gradients
    grads = dlgradient(loss_total, net.Learnables);
end

%% Visualization for Damped Oscillator

fprintf('Generating visualizations...\n');

figure('Position', [100, 100, 1400, 900]);

% Training curves
subplot(2,3,1);
semilogy(history_osc.loss_total, 'LineWidth', 2);
grid on;
xlabel('Epoch');
ylabel('Total Loss (log scale)');
title('Training Loss');

subplot(2,3,2);
semilogy(1:params_osc.epochs, history_osc.loss_data, 'LineWidth', 1.5);
hold on;
semilogy(1:params_osc.epochs, history_osc.loss_physics, 'LineWidth', 1.5);
semilogy(1:params_osc.epochs, history_osc.loss_ic, 'LineWidth', 1.5);
grid on;
xlabel('Epoch');
ylabel('Loss Components (log scale)');
legend('Data', 'Physics', 'Initial Cond.', 'Location', 'best');
title('Loss Components');

% Prediction vs truth
subplot(2,3,3);
plot(t_test, x_test_true, 'b-', 'LineWidth', 2);
hold on;
plot(t_test, x_pred, 'r-', 'LineWidth', 2);
plot(t_train, x_train, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'g');
grid on;
xlabel('Time (s)');
ylabel('Displacement (m)');
legend('Ground Truth', 'PINN Prediction', 'Training Data', 'Location', 'best');
title('PINN Prediction');

% Prediction error
subplot(2,3,4);
plot(t_test, abs(x_pred - x_test_true), 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Absolute Error');
title('Prediction Error');

% Phase portrait
v_pred = gradient(x_pred, t_test);
v_test_true = gradient(x_test_true, t_test);
subplot(2,3,5);
plot(x_test_true, v_test_true, 'b-', 'LineWidth', 2);
hold on;
plot(x_pred, v_pred, 'r-', 'LineWidth', 2);
grid on;
xlabel('Displacement (m)');
ylabel('Velocity (m/s)');
legend('Ground Truth', 'PINN', 'Location', 'best');
title('Phase Portrait');

% Residual check
subplot(2,3,6);
t_residual_dl = dlarray(t_test', 'CB');
x_residual = predict(net_osc, t_residual_dl);
x_dot_residual = dlgradient(sum(x_residual), t_residual_dl, 'EnableHigherDerivatives', true);
x_ddot_residual = dlgradient(sum(x_dot_residual), t_residual_dl);
residual_vals = extractdata(x_ddot_residual + 2*zeta*omega_n*x_dot_residual + omega_n^2*x_residual);
plot(t_test, residual_vals, 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Physics Residual');
title('Physics Equation Residual');

sgtitle('Damped Harmonic Oscillator - PINN Results', 'FontSize', 14, 'FontWeight', 'bold');

%% Part 2: Inverse Problem - Parameter Identification

fprintf('\nPART 2: INVERSE PROBLEM (PARAMETER IDENTIFICATION)\n');
fprintf('===================================================\n\n');

fprintf('Scenario: Unknown damping and frequency\n');
fprintf('Task: Identify   and  _n from sparse noisy observations\n\n');

% Use the same noisy data
% Initialize parameters as learnable variables (random initialization)
zeta_init = 0.05 + 0.1*rand();  % Initialize near true value
omega_n_init = omega_n * (0.8 + 0.4*rand());

fprintf('Initial Guesses:\n');
fprintf('   _init: %.4f (true: %.2f)\n', zeta_init, zeta);
fprintf('   _n_init: %.4f (true: %.2f)\n\n', omega_n_init, omega_n);

% Network for inverse problem (same architecture)
net_inv = dlnetwork(layers_osc);

% Learnable parameters
zeta_learned = dlarray(zeta_init);
omega_n_learned = dlarray(omega_n_init);

% Training parameters
params_inv = params_osc;
params_inv.epochs = 8000;
params_inv.lr = 0.005;
params_inv.lr_params = 0.001;  % Learning rate for physical parameters

avg_grad_inv = [];
avg_grad_sq_inv = [];
avg_grad_zeta = [];
avg_grad_sq_zeta = [];
avg_grad_omega = [];
avg_grad_sq_omega = [];

% History
history_inv = struct();
history_inv.loss = zeros(params_inv.epochs, 1);
history_inv.zeta = zeros(params_inv.epochs, 1);
history_inv.omega_n = zeros(params_inv.epochs, 1);

fprintf('Training inverse problem PINN...\n');
tic;

for epoch = 1:params_inv.epochs
    % Compute loss and gradients
    [loss, grads_net, grad_zeta, grad_omega] = ...
        dlfeval(@inverse_loss, net_inv, zeta_learned, omega_n_learned, ...
                t_train, x_train, t_colloc, x0, v0, params_inv);
    
    % Update network
    [net_inv, avg_grad_inv, avg_grad_sq_inv] = ...
        adamupdate(net_inv, grads_net, avg_grad_inv, avg_grad_sq_inv, epoch, params_inv.lr);
    
    % Update parameters
    [zeta_learned, avg_grad_zeta, avg_grad_sq_zeta] = ...
        adamupdate(zeta_learned, grad_zeta, avg_grad_zeta, avg_grad_sq_zeta, ...
                  epoch, params_inv.lr_params);
    
    [omega_n_learned, avg_grad_omega, avg_grad_sq_omega] = ...
        adamupdate(omega_n_learned, grad_omega, avg_grad_omega, avg_grad_sq_omega, ...
                  epoch, params_inv.lr_params);
    
    % Ensure physical constraints (positive values)
    zeta_learned = max(zeta_learned, dlarray(0.001));
    omega_n_learned = max(omega_n_learned, dlarray(0.1));
    
    % Store history
    history_inv.loss(epoch) = double(extractdata(loss));
    history_inv.zeta(epoch) = double(extractdata(zeta_learned));
    history_inv.omega_n(epoch) = double(extractdata(omega_n_learned));
    
    if mod(epoch, 1000) == 0 || epoch == 1
        fprintf('Epoch %5d | Loss: %.6f |  : %.4f |  _n: %.4f\n', ...
                epoch, history_inv.loss(epoch), history_inv.zeta(epoch), ...
                history_inv.omega_n(epoch));
    end
end

training_time_inv = toc;

% Final identified parameters
zeta_final = double(extractdata(zeta_learned));
omega_n_final = double(extractdata(omega_n_learned));

fprintf('\nParameter Identification Results:\n');
fprintf('  Damping ratio  :\n');
fprintf('    True value: %.4f\n', zeta);
fprintf('    Identified: %.4f\n', zeta_final);
fprintf('    Error: %.2f%%\n', 100*abs(zeta_final - zeta)/zeta);
fprintf('  Natural frequency  _n:\n');
fprintf('    True value: %.4f rad/s\n', omega_n);
fprintf('    Identified: %.4f rad/s\n', omega_n_final);
fprintf('    Error: %.2f%%\n\n', 100*abs(omega_n_final - omega_n)/omega_n);

%% Loss Function for Inverse Problem

function [loss, grads_net, grad_zeta, grad_omega] = ...
         inverse_loss(net, zeta, omega_n, t_data, x_data, t_colloc, x0, v0, params)
    
    t_data_dl = dlarray(t_data', 'CB');
    x_data_dl = dlarray(x_data', 'CB');
    t_colloc_dl = dlarray(t_colloc', 'CB');
    
    % Data loss
    x_pred = predict(net, t_data_dl);
    loss_data = mean((x_pred - x_data_dl).^2);
    
    % Physics loss
    x_colloc = predict(net, t_colloc_dl);
    x_dot = dlgradient(sum(x_colloc), t_colloc_dl, 'EnableHigherDerivatives', true);
    x_ddot = dlgradient(sum(x_dot), t_colloc_dl);
    residual = x_ddot + 2*zeta*omega_n*x_dot + omega_n^2*x_colloc;
    loss_physics = mean(residual.^2);
    
    % Initial conditions
    t_ic = dlarray(0, 'CB');
    x_ic = predict(net, t_ic);
    x_dot_ic = dlgradient(sum(x_ic), t_ic);
    loss_ic = (x_ic - x0)^2 + (x_dot_ic - v0)^2;
    
    % Total loss
    loss = params.lambda_data * loss_data + ...
           params.lambda_physics * loss_physics + ...
           params.lambda_ic * loss_ic;
    
    % Gradients
    grads_net = dlgradient(loss, net.Learnables);
    grad_zeta = dlgradient(loss, zeta);
    grad_omega = dlgradient(loss, omega_n);
end

%% Visualization for Inverse Problem

figure('Position', [100, 100, 1400, 600]);

subplot(1,3,1);
semilogy(history_inv.loss, 'LineWidth', 2);
grid on;
xlabel('Epoch');
ylabel('Total Loss (log scale)');
title('Inverse Problem Training Loss');

subplot(1,3,2);
plot(history_inv.zeta, 'b-', 'LineWidth', 2);
hold on;
yline(zeta, 'r-', 'LineWidth', 2);
grid on;
xlabel('Epoch');
ylabel('Damping Ratio  ');
legend('Learned', 'True', 'Location', 'best');
title('Parameter Learning: Damping Ratio');

subplot(1,3,3);
plot(history_inv.omega_n, 'b-', 'LineWidth', 2);
hold on;
yline(omega_n, 'r-', 'LineWidth', 2);
grid on;
xlabel('Epoch');
ylabel('Natural Frequency  _n (rad/s)');
legend('Learned', 'True', 'Location', 'best');
title('Parameter Learning: Natural Frequency');

sgtitle('Inverse Problem: Parameter Identification', 'FontSize', 14, 'FontWeight', 'bold');

%% Part 3: Lorenz System (Chaotic Dynamics)

fprintf('\nPART 3: LORENZ SYSTEM (CHAOTIC DYNAMICS)\n');
fprintf('==========================================\n\n');

% Lorenz parameters
sigma = 10;
rho = 28;
beta = 8/3;

fprintf('Lorenz System Parameters:\n');
fprintf('    (Prandtl): %.1f\n', sigma);
fprintf('    (Rayleigh): %.1f\n', rho);
fprintf('    (geometric): %.4f\n\n', beta);

% Time domain
t_lorenz_span = [0, 10];
t_lorenz = linspace(t_lorenz_span(1), t_lorenz_span(2), 1000)';

% Generate ground truth using ode45
lorenz_ode = @(t, y) [sigma*(y(2)-y(1)); 
                      y(1)*(rho-y(3))-y(2); 
                      y(1)*y(2)-beta*y(3)];
ic_lorenz = [1; 1; 1];
[~, xyz_true] = ode45(lorenz_ode, t_lorenz, ic_lorenz);

% Sparse and noisy observations
n_lorenz_data = 50;
data_idx_lorenz = sort(randperm(length(t_lorenz), n_lorenz_data));
t_lorenz_train = t_lorenz(data_idx_lorenz);
xyz_lorenz_obs = xyz_true(data_idx_lorenz, :) + ...
                 0.02 * std(xyz_true) .* randn(n_lorenz_data, 3);

fprintf('Data Configuration:\n');
fprintf('  Time span: [%.1f, %.1f] s\n', t_lorenz_span);
fprintf('  Total points: %d\n', length(t_lorenz));
fprintf('  Training points: %d\n\n', n_lorenz_data);

%% Build PINN for Lorenz System

fprintf('Building Lorenz PINN...\n');

layers_lorenz = [
    featureInputLayer(1, 'Name', 'time', 'Normalization', 'none')
    fullyConnectedLayer(64, 'Name', 'fc1')
    tanhLayer('Name', 'tanh1')
    fullyConnectedLayer(64, 'Name', 'fc2')
    tanhLayer('Name', 'tanh2')
    fullyConnectedLayer(64, 'Name', 'fc3')
    tanhLayer('Name', 'tanh3')
    fullyConnectedLayer(64, 'Name', 'fc4')
    tanhLayer('Name', 'tanh4')
    fullyConnectedLayer(3, 'Name', 'xyz')
];

net_lorenz = dlnetwork(layers_lorenz);

fprintf('  Architecture: 1-64-64-64-64-3\n');
fprintf('  Parameters: %d\n\n', numel(net_lorenz.Learnables.Value));

% Training parameters
params_lorenz = struct();
params_lorenz.lr = 0.001;
params_lorenz.epochs = 10000;
params_lorenz.lambda_data = 1.0;
params_lorenz.lambda_physics = 0.05;
params_lorenz.lambda_ic = 5.0;
params_lorenz.n_collocation = 500;

t_colloc_lorenz = linspace(t_lorenz_span(1), t_lorenz_span(2), params_lorenz.n_collocation)';

avg_grad_lorenz = [];
avg_grad_sq_lorenz = [];

history_lorenz = struct();
history_lorenz.loss_total = zeros(params_lorenz.epochs, 1);

fprintf('Training Lorenz PINN...\n');
fprintf('(This may take a while due to chaotic dynamics...)\n');
tic;

for epoch = 1:params_lorenz.epochs
    [loss, grads] = dlfeval(@lorenz_loss, net_lorenz, t_lorenz_train, ...
                            xyz_lorenz_obs, t_colloc_lorenz, ic_lorenz, ...
                            sigma, rho, beta, params_lorenz);
    
    [net_lorenz, avg_grad_lorenz, avg_grad_sq_lorenz] = ...
        adamupdate(net_lorenz, grads, avg_grad_lorenz, avg_grad_sq_lorenz, ...
                  epoch, params_lorenz.lr);
    
    history_lorenz.loss_total(epoch) = double(extractdata(loss));
    
    if mod(epoch, 1000) == 0 || epoch == 1
        fprintf('Epoch %5d/%d | Loss: %.6f\n', epoch, params_lorenz.epochs, ...
                history_lorenz.loss_total(epoch));
    end
end

training_time_lorenz = toc;
fprintf('Training completed in %.1f seconds\n\n', training_time_lorenz);

%% Evaluate Lorenz PINN

t_test_lorenz = linspace(t_lorenz_span(1), t_lorenz_span(2), 2000)';
t_test_lorenz_dl = dlarray(t_test_lorenz', 'CB');
xyz_pred = extractdata(predict(net_lorenz, t_test_lorenz_dl))';

% Ground truth at test points
[~, xyz_test_true] = ode45(lorenz_ode, t_test_lorenz, ic_lorenz);

% Errors
rmse_lorenz = sqrt(mean((xyz_pred - xyz_test_true).^2, 1));

fprintf('Lorenz System RMSE:\n');
fprintf('  x: %.4f\n', rmse_lorenz(1));
fprintf('  y: %.4f\n', rmse_lorenz(2));
fprintf('  z: %.4f\n\n', rmse_lorenz(3));

%% Loss Function for Lorenz System

function [loss, grads] = lorenz_loss(net, t_data, xyz_data, t_colloc, ic, ...
                                     sigma, rho, beta, params)
    
    t_data_dl = dlarray(t_data', 'CB');
    xyz_data_dl = dlarray(xyz_data', 'CB');
    t_colloc_dl = dlarray(t_colloc', 'CB');
    
    % Data loss
    xyz_pred = predict(net, t_data_dl);
    loss_data = mean(sum((xyz_pred - xyz_data_dl).^2, 1));
    
    % Physics loss
    xyz_colloc = predict(net, t_colloc_dl);
    x = xyz_colloc(1, :);
    y = xyz_colloc(2, :);
    z = xyz_colloc(3, :);
    
    % Compute time derivatives
    x_dot = dlgradient(sum(x), t_colloc_dl);
    y_dot = dlgradient(sum(y), t_colloc_dl);
    z_dot = dlgradient(sum(z), t_colloc_dl);
    
    % Lorenz equations residuals
    r_x = x_dot - sigma*(y - x);
    r_y = y_dot - x.*(rho - z) + y;
    r_z = z_dot - x.*y + beta*z;
    
    loss_physics = mean(r_x.^2 + r_y.^2 + r_z.^2);
    
    % Initial conditions
    t_ic = dlarray(0, 'CB');
    xyz_ic = predict(net, t_ic);
    ic_dl = dlarray(ic, 'CB');
    loss_ic = mean((xyz_ic - ic_dl).^2);
    
    % Total loss
    loss = params.lambda_data * loss_data + ...
           params.lambda_physics * loss_physics + ...
           params.lambda_ic * loss_ic;
    
    grads = dlgradient(loss, net.Learnables);
end

%% Visualization for Lorenz System

figure('Position', [100, 100, 1400, 1000]);

% Training loss
subplot(2,3,1);
semilogy(history_lorenz.loss_total, 'LineWidth', 2);
grid on;
xlabel('Epoch');
ylabel('Total Loss (log scale)');
title('Lorenz PINN Training');

% Time series comparison
subplot(2,3,2);
plot(t_test_lorenz, xyz_test_true(:,1), 'b-', 'LineWidth', 1.5);
hold on;
plot(t_test_lorenz, xyz_pred(:,1), 'r-', 'LineWidth', 1.5);
plot(t_lorenz_train, xyz_lorenz_obs(:,1), 'ko', 'MarkerSize', 4);
grid on;
xlabel('Time (s)');
ylabel('x');
legend('True', 'PINN', 'Data', 'Location', 'best');
title('x Component');

subplot(2,3,3);
plot(t_test_lorenz, xyz_test_true(:,2), 'b-', 'LineWidth', 1.5);
hold on;
plot(t_test_lorenz, xyz_pred(:,2), 'r-', 'LineWidth', 1.5);
plot(t_lorenz_train, xyz_lorenz_obs(:,2), 'ko', 'MarkerSize', 4);
grid on;
xlabel('Time (s)');
ylabel('y');
legend('True', 'PINN', 'Data', 'Location', 'best');
title('y Component');

% 3D attractor
subplot(2,3,4);
plot3(xyz_test_true(:,1), xyz_test_true(:,2), xyz_test_true(:,3), 'b-', 'LineWidth', 1);
hold on;
plot3(xyz_pred(:,1), xyz_pred(:,2), xyz_pred(:,3), 'r-', 'LineWidth', 1);
plot3(xyz_lorenz_obs(:,1), xyz_lorenz_obs(:,2), xyz_lorenz_obs(:,3), ...
      'ko', 'MarkerSize', 6, 'MarkerFaceColor', 'g');
grid on;
xlabel('x');
ylabel('y');
zlabel('z');
legend('True', 'PINN', 'Data', 'Location', 'best');
title('Lorenz Attractor (3D)');
view(45, 30);

% xy projection
subplot(2,3,5);
plot(xyz_test_true(:,1), xyz_test_true(:,2), 'b-', 'LineWidth', 1);
hold on;
plot(xyz_pred(:,1), xyz_pred(:,2), 'r-', 'LineWidth', 1);
grid on;
xlabel('x');
ylabel('y');
legend('True', 'PINN', 'Location', 'best');
title('xy Projection');
axis equal;

% xz projection
subplot(2,3,6);
plot(xyz_test_true(:,1), xyz_test_true(:,3), 'b-', 'LineWidth', 1);
hold on;
plot(xyz_pred(:,1), xyz_pred(:,3), 'r-', 'LineWidth', 1);
grid on;
xlabel('x');
ylabel('z');
legend('True', 'PINN', 'Location', 'best');
title('xz Projection');

sgtitle('Lorenz System - PINN Results', 'FontSize', 14, 'FontWeight', 'bold');

%% Comparison: PINN vs Pure Data-Driven

fprintf('\nPART 4: COMPARISON WITH PURE DATA-DRIVEN APPROACH\n');
fprintf('===================================================\n\n');

% Train a pure data-driven network (no physics)
net_dd = dlnetwork(layers_osc);
params_dd = params_osc;
params_dd.lambda_physics = 0;  % No physics loss
params_dd.lambda_ic = 0;       % No IC loss

avg_grad_dd = [];
avg_grad_sq_dd = [];

fprintf('Training pure data-driven network (no physics)...\n');
tic;

for epoch = 1:params_dd.epochs
    [loss, ~, ~, ~, grads] = ...
        dlfeval(@oscillator_loss, net_dd, t_train, x_train, t_colloc, ...
                omega_n, zeta, x0, v0, params_dd);
    
    [net_dd, avg_grad_dd, avg_grad_sq_dd] = ...
        adamupdate(net_dd, grads, avg_grad_dd, avg_grad_sq_dd, epoch, params_dd.lr);
    
    if mod(epoch, 1000) == 0
        fprintf('Epoch %d | Loss: %.6f\n', epoch, double(extractdata(loss)));
    end
end

training_time_dd = toc;
fprintf('Training completed in %.1f seconds\n\n', training_time_dd);

% Predictions
x_pred_dd = extractdata(predict(net_dd, t_test_dl))';

% Errors
rmse_pinn = sqrt(mean((x_pred - x_test_true).^2));
rmse_dd = sqrt(mean((x_pred_dd - x_test_true).^2));

fprintf('Performance Comparison:\n');
fprintf('  PINN RMSE: %.6f\n', rmse_pinn);
fprintf('  Data-driven RMSE: %.6f\n', rmse_dd);
fprintf('  Improvement: %.1f%%\n\n', 100*(rmse_dd - rmse_pinn)/rmse_dd);

% Extrapolation test
t_extrap = linspace(5, 10, 500)';
t_extrap_dl = dlarray(t_extrap', 'CB');
x_extrap_true = A * exp(-zeta*omega_n*t_extrap) .* cos(omega_d*t_extrap + phi);
x_extrap_pinn = extractdata(predict(net_osc, t_extrap_dl))';
x_extrap_dd = extractdata(predict(net_dd, t_extrap_dl))';

rmse_extrap_pinn = sqrt(mean((x_extrap_pinn - x_extrap_true).^2));
rmse_extrap_dd = sqrt(mean((x_extrap_dd - x_extrap_true).^2));

fprintf('Extrapolation Performance (t   [5, 10]):\n');
fprintf('  PINN RMSE: %.6f\n', rmse_extrap_pinn);
fprintf('  Data-driven RMSE: %.6f\n', rmse_extrap_dd);
fprintf('  PINN advantage: %.1fx better\n\n', rmse_extrap_dd/rmse_extrap_pinn);

%% Final Comparison Visualization

figure('Position', [100, 100, 1400, 600]);

subplot(1,2,1);
plot(t_test, x_test_true, 'k-', 'LineWidth', 2);
hold on;
plot(t_test, x_pred, 'b-', 'LineWidth', 2);
plot(t_test, x_pred_dd, 'r:', 'LineWidth', 2);
plot(t_train, x_train, 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g');
xline(5, 'k-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Displacement (m)');
legend('Ground Truth', 'PINN', 'Data-Driven', 'Training Data', 'Extrap. Start', ...
       'Location', 'best');
title('Interpolation and Extrapolation');

subplot(1,2,2);
semilogy(t_test, abs(x_pred - x_test_true), 'b-', 'LineWidth', 2);
hold on;
semilogy(t_test, abs(x_pred_dd - x_test_true), 'r-', 'LineWidth', 2);
xline(5, 'k-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Absolute Error (log scale)');
legend('PINN', 'Data-Driven', 'Extrap. Start', 'Location', 'best');
title('Error Comparison');

sgtitle('PINN vs Pure Data-Driven: Extrapolation Test', 'FontSize', 14, 'FontWeight', 'bold');

%% Summary

fprintf('\n=== Summary ===\n\n');
fprintf('PINN Advantages Demonstrated:\n');
fprintf('  1. Data Efficiency: Learned from only %d/%d points (%.1f%%)\n', ...
        n_data_points, length(t_data), 100*n_data_points/length(t_data));
fprintf('  2. Noise Robustness: Handled %.1f%% measurement noise\n', noise_level*100);
fprintf('  3. Better Extrapolation: %.1fx improvement over data-driven\n', ...
        rmse_extrap_dd/rmse_extrap_pinn);
fprintf('  4. Parameter Identification: Recovered   and  _n within %.1f%% error\n', ...
        max(100*abs(zeta_final - zeta)/zeta, 100*abs(omega_n_final - omega_n)/omega_n));
fprintf('  5. Chaotic Systems: Successfully modeled Lorenz attractor\n\n');

fprintf('Key Takeaways:\n');
fprintf('   Physics constraints act as powerful regularization\n');
fprintf('   Automatic differentiation enables derivative computation\n');
fprintf('   Multi-objective loss balancing is critical\n');
fprintf('   PINNs excel when data is sparse or noisy\n');
fprintf('   Can solve forward and inverse problems simultaneously\n');
fprintf('   Trade-off: More complex training vs. better generalization\n\n');

fprintf('Applications:\n');
fprintf('   System identification from limited measurements\n');
fprintf('   Digital twins for real-time monitoring\n');
fprintf('   Soft sensors for unmeasurable variables\n');
fprintf('   Reduced-order modeling of complex systems\n');
fprintf('   Multi-physics simulation and optimization\n\n');

fprintf('All simulations complete!\n');
