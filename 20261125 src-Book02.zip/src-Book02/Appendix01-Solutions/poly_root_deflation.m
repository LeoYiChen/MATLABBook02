%% poly_root_deflation.m
% Polynomial Root Finding with Deflation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : poly_root_deflation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Problem3.m
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: September 2023

% Define the polynomial p(x) = x^5 - 3x^4 - 3x^3 + 11x^2 + 4x - 8
p = [1 -3 -3 11 4 -8];

% Plot the polynomial for visualization
x = linspace(-4, 4, 1000);
y = polyval(p, x);
figure;
plot(x, y, 'LineWidth', 2);
grid on;
xlabel('x');
ylabel('p(x)');
title('Polynomial p(x) = x^5 - 3x^4 - 3x^3 + 11x^2 + 4x - 8');
yline(0, '-');

% Find all roots using deflation and Newton-Raphson
fprintf('Finding roots using deflation and Newton-Raphson method:\n');
roots_found = find_all_roots(p);

% Verify by comparing with MATLAB's roots function
matlab_roots = roots(p);
fprintf('\nRoots found by MATLAB''s roots function:\n');
disp(matlab_roots');

% Verify by reconstructing the polynomial
fprintf('\nReconstructing the polynomial from found roots...\n');
reconstructed_poly = reconstruct_poly(roots_found);
fprintf('Original coefficients: ');
fprintf('%10.6f ', p);
fprintf('\nReconstructed coefficients:');
fprintf('%10.6f ', reconstructed_poly);
fprintf('\n');

% Calculate error in reconstruction
coef_error = norm(p - reconstructed_poly) / norm(p);
fprintf('Relative error in coefficients: %.2e\n', coef_error);

% Function to find all roots using deflation
function all_roots = find_all_roots(p)
% Parameters
tol = 1e-10;
max_iter = 100;
n = length(p) - 1; % Polynomial degree

% Starting points for Newton's method
start_points = [-3, -2, -1, 0, 1, 2, 3] + 1i*[-1, 0, 1];

all_roots = [];
current_p = p;

for k = 1:n
    % Try different starting points
    found_new_root = false;
    
    for j = 1:length(start_points)
        [root, converged] = newton_poly(current_p, start_points(j), tol, max_iter);
        
        % Check if this is a new root
        if converged && all(abs(root - all_roots) > tol * 10)
            fprintf('Root %d: %s\n', k, format_complex(root));
            all_roots = [all_roots, root];
            
            % Deflate the polynomial
            current_p = deflate_poly(current_p, root);
            found_new_root = true;
            break;
        end
    end
    
    if ~found_new_root
        fprintf('Warning: Could not find additional roots.\n');
        break;
    end
end

end

% Newton-Raphson method for polynomial root finding
function [root, converged] = newton_poly(p, x0, tol, max_iter)
x = x0;
converged = false;

for iter = 1:max_iter
    % Evaluate polynomial and its derivative
    [px, dpx] = poly_and_deriv(p, x);
    
    % Newton update
    if abs(dpx) < tol
        % Handle the case where derivative is close to zero
        x = x + 0.1;
        continue;
    end
    
    dx = -px / dpx;
    x = x + dx;
    
    % Check for convergence
    if abs(dx) < tol && abs(px) < tol
        converged = true;
        break;
    end
end

% Final polish with high precision
for i = 1:5
    [px, dpx] = poly_and_deriv(p, x);
    x = x - px / dpx;
end

root = x;

end

% Evaluate polynomial and its derivative
function [p_x, dp_x] = poly_and_deriv(p, x)
n = length(p);
p_x = p(1);
dp_x = 0;

for i = 2:n
    dp_x = dp_x * x + p_x;
    p_x = p_x * x + p(i);
end

end

% Deflate polynomial after finding a root
function q = deflate_poly(p, root)
n = length(p);
q = zeros(1, n-1);

q(1) = p(1);
for i = 2:n-1
    q(i) = p(i) + q(i-1) * root;
end

% Check remainder (should be close to zero)
remainder = p(n) + q(n-1) * root;
if abs(remainder) > 1e-8
    fprintf('Warning: Remainder after deflation is large: %.2e\n', abs(remainder));
end

end

% Format complex number for display
function str = format_complex(z)
if abs(imag(z)) < 1e-10
str = sprintf('%.10f', real(z));
else
if imag(z) > 0
str = sprintf('%.10f + %.10fi', real(z), imag(z));
else
str = sprintf('%.10f - %.10fi', real(z), -imag(z));
end
end
end

% Reconstruct polynomial from roots
function p = reconstruct_poly(roots)
n = length(roots);
p = [1];

for i = 1:n
    p = conv(p, [1, -roots(i)]);
end

% Clean up numerical noise
p(abs(p) < 1e-10) = 0;

end
