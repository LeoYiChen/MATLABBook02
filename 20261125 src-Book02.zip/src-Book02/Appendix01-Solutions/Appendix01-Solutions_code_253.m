%% Appendix01-Solutions_code_253.m
% Digital Twin with Real-Time Parameter Adaptation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Digital Twin with Real-Time Parameter Adaptation
% Problem 19: Advanced State and Parameter Estimation
% Author: Control Systems Course
% Description: Complete digital twin framework with multiple adaptation methods
% Requires: Control System Toolbox

clear all; close all; clc;
rng(42);

fprintf('=== Digital Twin with Real-Time Parameter Adaptation ===\n\n');

%% Part 1: DC Motor Digital Twin

fprintf('PART 1: DC MOTOR WITH DEGRADATION\n');
fprintf('===================================\n\n');

% Motor nominal parameters
params_motor = struct();
params_motor.Ra0 = 1.0;        % Nominal armature resistance (Ohm)
params_motor.L = 0.5;          % Armature inductance (H)
params_motor.Ke = 0.01;        % Back-EMF constant (V.s/rad)
params_motor.Kt = 0.01;        % Torque constant (N.m/A)
params_motor.J = 0.01;         % Inertia (kg.m^2)
params_motor.B0 = 0.1;         % Nominal friction (N.m.s/rad)

% Degradation parameters
params_motor.alpha = 0.05;     % Resistance degradation rate (1/time)
params_motor.beta = 0.03;      % Friction degradation rate (1/time)

fprintf('Nominal Motor Parameters:\n');
fprintf('  Ra0: %.2f  \n', params_motor.Ra0);
fprintf('  L: %.2f H\n', params_motor.L);
fprintf('  B0: %.3f N.m.s/rad\n', params_motor.B0);
fprintf('  J: %.3f kg.m\n\n', params_motor.J);

fprintf('Degradation Rates:\n');
fprintf('  Resistance: %.3f per unit time\n', params_motor.alpha);
fprintf('  Friction: %.3f per unit time\n\n', params_motor.beta);

% Simulation setup
dt = 0.01;              % Time step (s)
t_end = 100;            % Simulation duration
t = 0:dt:t_end;
N = length(t);

% Control input (varying voltage)
Va = 12 * (0.5 + 0.3*sin(0.1*t) + 0.2*sin(0.5*t));

% Load torque (varying)
TL = 0.5 * (1 + 0.5*sin(0.05*t));

% Initialize true system states
ia_true = zeros(N, 1);
omega_true = zeros(N, 1);
Ra_true = zeros(N, 1);
B_true = zeros(N, 1);

% Initial conditions
ia_true(1) = 0;
omega_true(1) = 0;
Ra_true(1) = params_motor.Ra0;
B_true(1) = params_motor.B0;

fprintf('Simulating true motor with degradation...\n');

% Simulate true system with degradation
for k = 1:N-1
    % Time-varying parameters
    Ra_true(k+1) = params_motor.Ra0 * (1 + params_motor.alpha * t(k));
    B_true(k+1) = params_motor.B0 * (1 + params_motor.beta * t(k));
    
    % State derivatives
    dia_dt = (Va(k) - Ra_true(k)*ia_true(k) - params_motor.Ke*omega_true(k)) / params_motor.L;
    domega_dt = (params_motor.Kt*ia_true(k) - B_true(k)*omega_true(k) - TL(k)) / params_motor.J;
    
    % Euler integration
    ia_true(k+1) = ia_true(k) + dia_dt * dt;
    omega_true(k+1) = omega_true(k) + domega_dt * dt;
end

% Add measurement noise
sigma_ia = 0.1;         % Current measurement noise std
sigma_omega = 0.5;      % Speed measurement noise std

ia_meas = ia_true + sigma_ia * randn(N, 1);
omega_meas = omega_true + sigma_omega * randn(N, 1);

fprintf('Simulation complete.\n');
fprintf('  Final resistance: %.3f   (%.1f%% increase)\n', ...
        Ra_true(end), 100*(Ra_true(end)/Ra_true(1) - 1));
fprintf('  Final friction: %.3f N.m.s/rad (%.1f%% increase)\n\n', ...
        B_true(end), 100*(B_true(end)/B_true(1) - 1));

%% Extended Kalman Filter for Dual Estimation

fprintf('Implementing Extended Kalman Filter (EKF)...\n');

% Augmented state: [ia, omega, Ra, B]
x_ekf = zeros(4, N);
x_ekf(:, 1) = [ia_meas(1); omega_meas(1); params_motor.Ra0; params_motor.B0];

% Covariance matrix
P_ekf = diag([sigma_ia^2, sigma_omega^2, 0.1^2, 0.01^2]);

% Process noise
Q_ekf = diag([0.01, 0.1, 1e-5, 1e-6]);  % Small for states, very small for parameters

% Measurement noise
R_ekf = diag([sigma_ia^2, sigma_omega^2]);

% Storage for analysis
P_history_ekf = zeros(4, 4, N);
innovation_ekf = zeros(2, N);

for k = 1:N-1
    % === PREDICTION STEP ===
    
    % Extract states
    ia = x_ekf(1, k);
    omega = x_ekf(2, k);
    Ra = x_ekf(3, k);
    B = x_ekf(4, k);
    
    % State prediction (with parameter values)
    dia_dt = (Va(k) - Ra*ia - params_motor.Ke*omega) / params_motor.L;
    domega_dt = (params_motor.Kt*ia - B*omega - TL(k)) / params_motor.J;
    
    % Parameters assumed constant (or random walk)
    dRa_dt = 0;
    dB_dt = 0;
    
    % Predicted state
    x_pred = x_ekf(:, k) + dt * [dia_dt; domega_dt; dRa_dt; dB_dt];
    
    % Jacobian of state equation
    F = eye(4);
    F(1,1) = 1 - dt * Ra / params_motor.L;
    F(1,2) = -dt * params_motor.Ke / params_motor.L;
    F(1,3) = -dt * ia / params_motor.L;
    F(2,1) = dt * params_motor.Kt / params_motor.J;
    F(2,2) = 1 - dt * B / params_motor.J;
    F(2,4) = -dt * omega / params_motor.J;
    
    % Predicted covariance
    P_pred = F * P_ekf * F' + Q_ekf;
    
    % === UPDATE STEP ===
    
    % Measurement prediction
    y_pred = [x_pred(1); x_pred(2)];  % Measure ia and omega
    
    % Measurement Jacobian
    H = [1, 0, 0, 0;
         0, 1, 0, 0];
    
    % Innovation
    innovation = [ia_meas(k+1); omega_meas(k+1)] - y_pred;
    innovation_ekf(:, k+1) = innovation;
    
    % Innovation covariance
    S = H * P_pred * H' + R_ekf;
    
    % Kalman gain
    K = P_pred * H' / S;
    
    % State update
    x_ekf(:, k+1) = x_pred + K * innovation;
    
    % Covariance update
    P_ekf = (eye(4) - K * H) * P_pred;
    P_history_ekf(:, :, k+1) = P_ekf;
end

fprintf('EKF estimation complete.\n\n');

%% Recursive Least Squares (RLS) for Parameter Estimation

fprintf('Implementing Recursive Least Squares (RLS)...\n');

% RLS for parameter estimation only (assume states are measured)
% Model: y = Phi' * theta + noise
% For motor: [ia_dot; omega_dot] = f(ia, omega, Va, TL; Ra, B)

theta_rls = [params_motor.Ra0; params_motor.B0];
P_rls = 10 * eye(2);  % Initial covariance
lambda_rls = 0.99;    % Forgetting factor

theta_rls_history = zeros(2, N);
theta_rls_history(:, 1) = theta_rls;

for k = 2:N
    % Compute state derivatives from measurements (using finite differences)
    dia_dt_meas = (ia_meas(k) - ia_meas(k-1)) / dt;
    domega_dt_meas = (omega_meas(k) - omega_meas(k-1)) / dt;
    
    % Regression vectors
    % From: dia/dt = (Va - Ra*ia - Ke*omega)/L
    %       domega/dt = (Kt*ia - B*omega - TL)/J
    
    % Rearrange to linear form:
    % dia/dt * L = Va - Ra*ia - Ke*omega
    % domega/dt * J = Kt*ia - B*omega - TL
    
    % For Ra: dia/dt * L + Ke*omega - Va = -Ra*ia
    % For B: domega/dt * J + TL - Kt*ia = -B*omega
    
    % Build regression vector and output
    phi_Ra = -ia_meas(k);
    y_Ra = dia_dt_meas * params_motor.L + params_motor.Ke * omega_meas(k) - Va(k);
    
    phi_B = -omega_meas(k);
    y_B = domega_dt_meas * params_motor.J + TL(k) - params_motor.Kt * ia_meas(k);
    
    % Stack for both parameters
    Phi = [phi_Ra, 0; 0, phi_B];
    Y = [y_Ra; y_B];
    
    % RLS update for each parameter separately (simplified)
    % Update Ra
    if abs(phi_Ra) > 0.01  % Only update if regressor is informative
        K_Ra = P_rls(1,1) * phi_Ra / (lambda_rls + phi_Ra * P_rls(1,1) * phi_Ra);
        theta_rls(1) = theta_rls(1) + K_Ra * (y_Ra - phi_Ra * theta_rls(1));
        P_rls(1,1) = (1 - K_Ra * phi_Ra) * P_rls(1,1) / lambda_rls;
    end
    
    % Update B
    if abs(phi_B) > 0.01
        K_B = P_rls(2,2) * phi_B / (lambda_rls + phi_B * P_rls(2,2) * phi_B);
        theta_rls(2) = theta_rls(2) + K_B * (y_B - phi_B * theta_rls(2));
        P_rls(2,2) = (1 - K_B * phi_B) * P_rls(2,2) / lambda_rls;
    end
    
    theta_rls_history(:, k) = theta_rls;
end

fprintf('RLS estimation complete.\n\n');

%% Anomaly Detection

fprintf('Performing anomaly detection...\n');

% Compute normalized innovation squared (chi-squared statistic)
chi2_stat = zeros(N, 1);
for k = 2:N
    S = R_ekf;  % Simplified: use measurement noise
    chi2_stat(k) = innovation_ekf(:, k)' * (S \ innovation_ekf(:, k));
end

% Chi-squared threshold (95% confidence, 2 DOF)
chi2_threshold = chi2inv(0.95, 2);

anomaly_detected = chi2_stat > chi2_threshold;
anomaly_times = t(anomaly_detected);

fprintf('  Chi-squared threshold (95%%): %.2f\n', chi2_threshold);
fprintf('  Anomalies detected: %d / %d time points\n', sum(anomaly_detected), N);
fprintf('  First anomaly at t = %.1f s\n\n', min([anomaly_times, inf]));

%% Remaining Useful Life (RUL) Prediction

fprintf('Predicting Remaining Useful Life (RUL)...\n');

% Define failure thresholds
Ra_max = 2.0;  % Maximum acceptable resistance
B_max = 0.25;  % Maximum acceptable friction

% Fit degradation models to estimated parameters
t_fit = t(N/2:end);  % Use second half for fitting
Ra_ekf_fit = x_ekf(3, N/2:end);
B_ekf_fit = x_ekf(4, N/2:end);

% Linear fit for resistance
p_Ra = polyfit(t_fit, Ra_ekf_fit, 1);
Ra_trend = @(t_future) polyval(p_Ra, t_future);

% Linear fit for friction
p_B = polyfit(t_fit, B_ekf_fit, 1);
B_trend = @(t_future) polyval(p_B, t_future);

% Predict when thresholds are crossed
if p_Ra(1) > 0
    t_fail_Ra = (Ra_max - p_Ra(2)) / p_Ra(1);
else
    t_fail_Ra = inf;
end

if p_B(1) > 0
    t_fail_B = (B_max - p_B(2)) / p_B(1);
else
    t_fail_B = inf;
end

t_fail = min(t_fail_Ra, t_fail_B);
RUL = t_fail - t(end);

fprintf('  Failure Thresholds:\n');
fprintf('    Ra_max: %.2f  \n', Ra_max);
fprintf('    B_max: %.3f N.m.s/rad\n', B_max);
fprintf('  Predicted Failure Times:\n');
fprintf('    Resistance: t = %.1f s\n', t_fail_Ra);
fprintf('    Friction: t = %.1f s\n', t_fail_B);
fprintf('  Overall failure: t = %.1f s\n', t_fail);
fprintf('  Remaining Useful Life: %.1f s\n\n', RUL);

%% Visualization for DC Motor Digital Twin

fprintf('Generating visualizations...\n');

figure('Position', [100, 100, 1600, 1000]);

% Current estimation
subplot(3,3,1);
plot(t, ia_true, 'k-', 'LineWidth', 2);
hold on;
plot(t, ia_meas, 'r.', 'MarkerSize', 2);
plot(t, x_ekf(1,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Current (A)');
legend('True', 'Measured', 'EKF', 'Location', 'best');
title('Armature Current Estimation');

% Speed estimation
subplot(3,3,2);
plot(t, omega_true, 'k-', 'LineWidth', 2);
hold on;
plot(t, omega_meas, 'r.', 'MarkerSize', 2);
plot(t, x_ekf(2,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Speed (rad/s)');
legend('True', 'Measured', 'EKF', 'Location', 'best');
title('Motor Speed Estimation');

% Resistance adaptation
subplot(3,3,3);
plot(t, Ra_true, 'k-', 'LineWidth', 2);
hold on;
plot(t, x_ekf(3,:), 'b-', 'LineWidth', 1.5);
plot(t, theta_rls_history(1,:), 'r-', 'LineWidth', 1.5);
yline(Ra_max, 'r-', 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Resistance ( )');
legend('True', 'EKF', 'RLS', 'Threshold', 'Location', 'best');
title('Resistance Parameter Adaptation');

% Friction adaptation
subplot(3,3,4);
plot(t, B_true, 'k-', 'LineWidth', 2);
hold on;
plot(t, x_ekf(4,:), 'b-', 'LineWidth', 1.5);
plot(t, theta_rls_history(2,:), 'r-', 'LineWidth', 1.5);
yline(B_max, 'r-', 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Friction (N.m.s/rad)');
legend('True', 'EKF', 'RLS', 'Threshold', 'Location', 'best');
title('Friction Parameter Adaptation');

% Parameter errors
subplot(3,3,5);
semilogy(t, abs(x_ekf(3,:) - Ra_true'), 'b-', 'LineWidth', 1.5);
hold on;
semilogy(t, abs(theta_rls_history(1,:) - Ra_true'), 'r-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Absolute Error');
legend('EKF', 'RLS', 'Location', 'best');
title('Resistance Estimation Error');

subplot(3,3,6);
semilogy(t, abs(x_ekf(4,:) - B_true'), 'b-', 'LineWidth', 1.5);
hold on;
semilogy(t, abs(theta_rls_history(2,:) - B_true'), 'r-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Absolute Error');
legend('EKF', 'RLS', 'Location', 'best');
title('Friction Estimation Error');

% Anomaly detection
subplot(3,3,7);
plot(t, chi2_stat, 'b-', 'LineWidth', 1.5);
hold on;
yline(chi2_threshold, 'r-', 'LineWidth', 2);
plot(t(anomaly_detected), chi2_stat(anomaly_detected), 'ro', 'MarkerSize', 6);
grid on;
xlabel('Time (s)');
ylabel('  Statistic');
legend('Innovation', 'Threshold', 'Anomaly', 'Location', 'best');
title('Anomaly Detection');

% RUL prediction
subplot(3,3,8);
plot(t, Ra_true, 'k-', 'LineWidth', 2);
hold on;
plot(t, x_ekf(3,:), 'b-', 'LineWidth', 1.5);
t_future = t(end):dt:min(t_fail_Ra, 200);
plot(t_future, Ra_trend(t_future), 'b-', 'LineWidth', 1.5);
yline(Ra_max, 'r-', 'LineWidth', 2);
xline(t_fail_Ra, 'r:', 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Resistance ( )');
legend('True', 'Estimated', 'Predicted', 'Threshold', 'Location', 'best');
title('RUL Prediction (Resistance)');
xlim([0, min(200, t_fail_Ra+20)]);

% Uncertainty bands
subplot(3,3,9);
Ra_std = squeeze(sqrt(P_history_ekf(3,3,:)));
fill([t, fliplr(t)], [x_ekf(3,:) + 2*Ra_std', fliplr(x_ekf(3,:) - 2*Ra_std')], ...
     'b', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
hold on;
plot(t, Ra_true, 'k-', 'LineWidth', 2);
plot(t, x_ekf(3,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Resistance ( )');
legend('95% Confidence', 'True', 'Estimate', 'Location', 'best');
title('Uncertainty Quantification');

sgtitle('DC Motor Digital Twin - Real-Time Adaptation', 'FontSize', 14, 'FontWeight', 'bold');

%% Part 2: Battery Digital Twin

fprintf('\nPART 2: LITHIUM-ION BATTERY AGING\n');
fprintf('===================================\n\n');

% Battery parameters
params_batt = struct();
params_batt.Q0 = 10;           % Initial capacity (Ah)
params_batt.R0_0 = 0.05;       % Initial resistance (Ohm)
params_batt.R1 = 0.02;         % RC resistance
params_batt.C1 = 2000;         % RC capacitance (F)
params_batt.gamma_Q = 0.01;    % Capacity fade rate
params_batt.gamma_R = 0.008;   % Resistance growth rate

fprintf('Battery Parameters:\n');
fprintf('  Initial capacity: %.1f Ah\n', params_batt.Q0);
fprintf('  Initial resistance: %.3f  \n', params_batt.R0_0);
fprintf('  Capacity fade rate: %.4f\n', params_batt.gamma_Q);
fprintf('  Resistance growth rate: %.4f\n\n', params_batt.gamma_R);

% OCV-SOC relationship (simplified)
OCV_func = @(soc) 3.0 + 1.2*soc;  % Linear approximation

% Time setup
dt_batt = 1;  % 1 second time step
t_batt_end = 5000;  % Longer simulation for aging
t_batt = 0:dt_batt:t_batt_end;
N_batt = length(t_batt);

% Current profile (charge/discharge cycles)
I_batt = 5 * sin(2*pi*t_batt/500);  % Sinusoidal cycling

% Initialize true states
SOC_true = zeros(N_batt, 1);
V1_true = zeros(N_batt, 1);
V_true = zeros(N_batt, 1);
Q_true = zeros(N_batt, 1);
R0_true = zeros(N_batt, 1);
SOH_true = zeros(N_batt, 1);

% Initial conditions
SOC_true(1) = 0.8;  % 80% SOC
V1_true(1) = 0;
Q_true(1) = params_batt.Q0;
R0_true(1) = params_batt.R0_0;
SOH_true(1) = 1.0;

fprintf('Simulating battery with aging...\n');

% Simulate battery
for k = 1:N_batt-1
    % Aging (exponential models)
    Q_true(k+1) = params_batt.Q0 * exp(-params_batt.gamma_Q * t_batt(k)/1000);
    R0_true(k+1) = params_batt.R0_0 * exp(params_batt.gamma_R * t_batt(k)/1000);
    
    % State dynamics
    dSOC_dt = -I_batt(k) / (3600 * Q_true(k));  % Convert to 1/s
    dV1_dt = -V1_true(k)/(params_batt.R1*params_batt.C1) + I_batt(k)/params_batt.C1;
    
    % Update states
    SOC_true(k+1) = SOC_true(k) + dSOC_dt * dt_batt;
    V1_true(k+1) = V1_true(k) + dV1_dt * dt_batt;
    
    % Limit SOC
    SOC_true(k+1) = max(0.1, min(0.9, SOC_true(k+1)));
    
    % Terminal voltage
    V_true(k+1) = OCV_func(SOC_true(k+1)) - I_batt(k+1)*R0_true(k+1) - V1_true(k+1);
    
    % SOH
    SOH_true(k+1) = Q_true(k+1) / params_batt.Q0;
end

% Add measurement noise
sigma_V = 0.01;  % Voltage noise
V_meas = V_true + sigma_V * randn(N_batt, 1);

fprintf('Simulation complete.\n');
fprintf('  Final capacity: %.2f Ah (SOH: %.1f%%)\n', Q_true(end), 100*SOH_true(end));
fprintf('  Final resistance: %.4f   (%.1f%% increase)\n\n', ...
        R0_true(end), 100*(R0_true(end)/R0_true(1) - 1));

%% EKF for Battery State and Parameter Estimation

fprintf('Implementing Battery EKF...\n');

% Augmented state: [SOC, V1, Q, R0]
x_batt_ekf = zeros(4, N_batt);
x_batt_ekf(:, 1) = [SOC_true(1); V1_true(1); Q_true(1); R0_true(1)];

P_batt_ekf = diag([0.01^2, 0.1^2, 0.5^2, 0.01^2]);
Q_batt_ekf = diag([1e-6, 1e-4, 1e-8, 1e-9]);
R_batt_ekf = sigma_V^2;

for k = 1:N_batt-1
    % Extract states
    SOC = x_batt_ekf(1, k);
    V1 = x_batt_ekf(2, k);
    Q = x_batt_ekf(3, k);
    R0 = x_batt_ekf(4, k);
    
    % Prediction
    dSOC_dt = -I_batt(k) / (3600 * Q);
    dV1_dt = -V1/(params_batt.R1*params_batt.C1) + I_batt(k)/params_batt.C1;
    
    x_pred = x_batt_ekf(:, k) + dt_batt * [dSOC_dt; dV1_dt; 0; 0];
    
    % Linearization
    F = eye(4);
    F(1,1) = 1;
    F(1,3) = dt_batt * I_batt(k) / (3600 * Q^2);
    F(2,2) = 1 - dt_batt/(params_batt.R1*params_batt.C1);
    
    P_pred = F * P_batt_ekf * F' + Q_batt_ekf;
    
    % Measurement prediction
    OCV = OCV_func(x_pred(1));
    V_pred = OCV - I_batt(k+1)*x_pred(4) - x_pred(2);
    
    % Measurement Jacobian
    dOCV_dSOC = 1.2;  % Derivative of linear OCV
    H = [dOCV_dSOC, -1, 0, -I_batt(k+1)];
    
    % Update
    innovation = V_meas(k+1) - V_pred;
    S = H * P_pred * H' + R_batt_ekf;
    K = P_pred * H' / S;
    
    x_batt_ekf(:, k+1) = x_pred + K * innovation;
    P_batt_ekf = (eye(4) - K * H) * P_pred;
    
    % Constraints
    x_batt_ekf(1, k+1) = max(0.1, min(0.9, x_batt_ekf(1, k+1)));
    x_batt_ekf(3, k+1) = max(1, x_batt_ekf(3, k+1));
    x_batt_ekf(4, k+1) = max(0.01, x_batt_ekf(4, k+1));
end

% Compute estimated SOH
SOH_est = x_batt_ekf(3,:) / params_batt.Q0;

fprintf('Battery EKF complete.\n\n');

%% Battery RUL Prediction

fprintf('Predicting battery RUL...\n');

% SOH threshold for end-of-life
SOH_threshold = 0.8;

% Fit capacity fade model
t_fit_batt = t_batt(N_batt/2:end);
Q_fit = x_batt_ekf(3, N_batt/2:end);

% Exponential fit: Q(t) = a * exp(-b*t)
ft = fittype('a*exp(-b*x)', 'independent', 'x');
f_Q = fit(t_fit_batt', Q_fit', ft, 'StartPoint', [params_batt.Q0, params_batt.gamma_Q/1000]);

% Predict when SOH < threshold
Q_threshold = SOH_threshold * params_batt.Q0;
if f_Q.b > 0
    t_fail_batt = -log(Q_threshold / f_Q.a) / f_Q.b;
    RUL_batt = t_fail_batt - t_batt(end);
else
    t_fail_batt = inf;
    RUL_batt = inf;
end

fprintf('  SOH threshold: %.0f%%\n', SOH_threshold*100);
fprintf('  Predicted end-of-life: t = %.0f s\n', t_fail_batt);
fprintf('  RUL: %.0f s\n\n', RUL_batt);

%% Visualization for Battery Digital Twin

figure('Position', [100, 100, 1600, 900]);

% SOC estimation
subplot(2,3,1);
plot(t_batt, SOC_true, 'k-', 'LineWidth', 2);
hold on;
plot(t_batt, x_batt_ekf(1,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('SOC');
legend('True', 'Estimated', 'Location', 'best');
title('State of Charge Estimation');

% Voltage
subplot(2,3,2);
plot(t_batt, V_true, 'k-', 'LineWidth', 2);
hold on;
plot(t_batt, V_meas, 'r.', 'MarkerSize', 1);
% Reconstruct estimated voltage
V_est = zeros(N_batt, 1);
for k = 1:N_batt
    V_est(k) = OCV_func(x_batt_ekf(1,k)) - I_batt(k)*x_batt_ekf(4,k) - x_batt_ekf(2,k);
end
plot(t_batt, V_est, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Voltage (V)');
legend('True', 'Measured', 'Estimated', 'Location', 'best');
title('Terminal Voltage');

% Capacity tracking
subplot(2,3,3);
plot(t_batt, Q_true, 'k-', 'LineWidth', 2);
hold on;
plot(t_batt, x_batt_ekf(3,:), 'b-', 'LineWidth', 1.5);
yline(Q_threshold, 'r-', 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Capacity (Ah)');
legend('True', 'Estimated', 'Threshold', 'Location', 'best');
title('Capacity Fade');

% Resistance tracking
subplot(2,3,4);
plot(t_batt, R0_true, 'k-', 'LineWidth', 2);
hold on;
plot(t_batt, x_batt_ekf(4,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Resistance ( )');
legend('True', 'Estimated', 'Location', 'best');
title('Internal Resistance Growth');

% SOH tracking
subplot(2,3,5);
plot(t_batt, SOH_true, 'k-', 'LineWidth', 2);
hold on;
plot(t_batt, SOH_est, 'b-', 'LineWidth', 1.5);
yline(SOH_threshold, 'r-', 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('SOH');
legend('True', 'Estimated', 'EOL Threshold', 'Location', 'best');
title('State of Health');
ylim([0.7, 1.05]);

% RUL prediction
subplot(2,3,6);
plot(t_batt, Q_true, 'k-', 'LineWidth', 2);
hold on;
plot(t_batt, x_batt_ekf(3,:), 'b-', 'LineWidth', 1.5);
t_future_batt = t_batt(end):dt_batt:min(t_fail_batt+500, 10000);
Q_predicted = f_Q.a * exp(-f_Q.b * t_future_batt);
plot(t_future_batt, Q_predicted, 'b-', 'LineWidth', 1.5);
yline(Q_threshold, 'r-', 'LineWidth', 2);
xline(t_fail_batt, 'r:', 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Capacity (Ah)');
legend('True', 'Estimated', 'Predicted', 'EOL', 'Location', 'best');
title('RUL Prediction');
xlim([0, min(t_fail_batt+1000, 10000)]);

sgtitle('Battery Digital Twin - Aging Prediction', 'FontSize', 14, 'FontWeight', 'bold');

%% Performance Comparison

fprintf('\nPART 3: PERFORMANCE COMPARISON\n');
fprintf('===============================\n\n');

% Motor parameter estimation errors
error_Ra_ekf = sqrt(mean((x_ekf(3,:) - Ra_true').^2));
error_B_ekf = sqrt(mean((x_ekf(4,:) - B_true').^2));
error_Ra_rls = sqrt(mean((theta_rls_history(1,:) - Ra_true').^2));
error_B_rls = sqrt(mean((theta_rls_history(2,:) - B_true').^2));

fprintf('DC Motor Estimation Performance:\n');
fprintf('  Resistance RMSE:\n');
fprintf('    EKF: %.4f  \n', error_Ra_ekf);
fprintf('    RLS: %.4f  \n', error_Ra_rls);
fprintf('  Friction RMSE:\n');
fprintf('    EKF: %.5f N.m.s/rad\n', error_B_ekf);
fprintf('    RLS: %.5f N.m.s/rad\n\n', error_B_rls);

% Battery estimation errors
error_SOC = sqrt(mean((x_batt_ekf(1,:) - SOC_true').^2));
error_Q = sqrt(mean((x_batt_ekf(3,:) - Q_true').^2));
error_R0 = sqrt(mean((x_batt_ekf(4,:) - R0_true').^2));

fprintf('Battery Estimation Performance:\n');
fprintf('  SOC RMSE: %.4f\n', error_SOC);
fprintf('  Capacity RMSE: %.4f Ah\n', error_Q);
fprintf('  Resistance RMSE: %.5f  \n\n', error_R0);

%% Summary

fprintf('=== Digital Twin Summary ===\n\n');

fprintf('Key Capabilities Demonstrated:\n');
fprintf('  1. Real-time state estimation with noisy measurements\n');
fprintf('  2. Online parameter adaptation as system degrades\n');
fprintf('  3. Anomaly detection using innovation statistics\n');
fprintf('  4. RUL prediction based on parameter trends\n');
fprintf('  5. Uncertainty quantification (confidence bounds)\n');
fprintf('  6. Multiple adaptation algorithms (EKF, RLS)\n\n');

fprintf('Applications:\n');
fprintf('   Condition-based maintenance\n');
fprintf('   Performance optimization under degradation\n');
fprintf('   Virtual sensors for unmeasurable states\n');
fprintf('   Fault diagnosis and prognosis\n');
fprintf('   Digital twin for Industry 4.0\n\n');

fprintf('Advantages of Parameter Adaptation:\n');
fprintf('   Maintains accuracy as system changes\n');
fprintf('   Early detection of degradation\n');
fprintf('   Predictive capabilities\n');
fprintf('   Enables proactive decision-making\n\n');

fprintf('Challenges:\n');
fprintf('   Parameter identifiability\n');
fprintf('   Trade-off: tracking vs. noise filtering\n');
fprintf('   Computational requirements for real-time\n');
fprintf('   Model validation and verification\n\n');

fprintf('All simulations complete!\n');
