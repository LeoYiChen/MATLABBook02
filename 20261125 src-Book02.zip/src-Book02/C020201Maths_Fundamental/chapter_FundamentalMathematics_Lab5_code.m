%% chapter_FundamentalMathematics_Lab5_code.m
% Laboratory5: Optimisation methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_Lab5_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory exercise
laboratoryExercise5_Optimisation();

% Local functions (moved to end so this listing is a valid MATLAB script)
function laboratoryExercise5_Optimisation()
    % LABORATORYEXERCISE5_OPTIMISATION Numerical optimisation techniques
    %   Comprehensive exploration of optimisation algorithms
    %
    %   Author: Dr Leo Chen
    %   Created: December 2024
    %   Version: 1.0
    %   MATLAB Version: R2023b or later
    
    fprintf('\\textbf{Laboratory5: Optimisation Methods}\n');
    fprintf('====================================================\n\n');
    
    %% Part A: Unconstrained Optimisation
    fprintf('\\textbf{PART A: UNCONSTRAINED OPTIMISATION}\n');
    fprintf('--------\n\n');
    
    fprintf(['Historical Context: Fermat (1630*s) developed analytic\n', ...
        'methods for finding extrema; modern numerical methods\n', ...
        'enable optimisation of complex non-convex functions.\n\n']);
    
    % Define Rosenbrock function (classic test case)
    % f(x,y) = (1-x)^2 + 100*(y-x^2)^2
    % Global minimum at (1,1) with f(1,1) = 0
    rosenbrockFunc = @(x) (1 - x(1))^2 + 100 * (x(2) - x(1)^2)^2;
    
    % Gradient of Rosenbrock function
    rosenbrockGrad = @(x) [-2*(1-x(1)) - 400*x(1)*(x(2)-x(1)^2); ...
                           200*(x(2)-x(1)^2)];
    
    fprintf('\\textbf{Test Function}: Rosenbrock (Banana) Function\n');
    fprintf('  $f(x,y) = (1-x)^2 + 100*(y-x^2)^2$\n');
    fprintf('  Global minimum: $(x^*, y^*) = (1, 1)$, $f(x^*) = 0$\n');
    fprintf('  Characteristics: Narrow curved valley, challenging\n\n');
    
    % Initial point
    x0 = [-1.2; 1.0];
    fprintf('  Initial point: $(x_0, y_0) = (%.1f, %.1f)$\n', x0(1), x0(2));
    fprintf('  Initial value: $f(x_0) = %.4f$\n\n', rosenbrockFunc(x0));
    
    % Method 1: Nelder-Mead simplex (gradient-free)
    fprintf('\\textbf{Method 1: Nelder-Mead Simplex} (gradient-free)\n');
    
    options_nm = optimset('Display', 'off', 'TolX', 1e-8, ...
        'TolFun', 1e-8, 'MaxFunEvals', 10000);
    
    tic;
    [x_nm, fval_nm, exitflag_nm, output_nm] = fminsearch(...
        rosenbrockFunc, x0, options_nm);
    time_nm = toc;
    
    fprintf('  Solution: $(x^*, y^*) = (%.6f, %.6f)$\n', x_nm(1), x_nm(2));
    fprintf('  Function value: $f(x^*) = %.2e$\n', fval_nm);
    fprintf('  Function evaluations: %d\n', output_nm.funcCount);
    fprintf('  Iterations: %d\n', output_nm.iterations);
    fprintf('  Computation time: %.4f seconds\n', time_nm);
    fprintf('  Exit flag: %d (%s)\n\n', exitflag_nm, ...
        getExitMessage(exitflag_nm));
    
    % Method 2: BFGS quasi-Newton (gradient-based)
    fprintf('\\textbf{Method 2: BFGS Quasi-Newton} (gradient-based)\n');
    
    options_bfgs = optimoptions('fminunc', 'Display', 'off', ...
        'Algorithm', 'quasi-newton', 'SpecifyObjectiveGradient', true, ...
        'OptimalityTolerance', 1e-8, 'StepTolerance', 1e-8);
    
    objWithGrad = @(x) deal(rosenbrockFunc(x), rosenbrockGrad(x));
    
    tic;
    [x_bfgs, fval_bfgs, exitflag_bfgs, output_bfgs] = fminunc(...
        objWithGrad, x0, options_bfgs);
    time_bfgs = toc;
    
    fprintf('  Solution: $(x^*, y^*) = (%.6f, %.6f)$\n', ...
        x_bfgs(1), x_bfgs(2));
    fprintf('  Function value: $f(x^*) = %.2e$\n', fval_bfgs);
    fprintf('  Function evaluations: %d\n', output_bfgs.funcCount);
    fprintf('  Iterations: %d\n', output_bfgs.iterations);
    fprintf('  Computation time: %.4f seconds\n', time_bfgs);
    fprintf('  Exit flag: %d (%s)\n\n', exitflag_bfgs, ...
        getExitMessage(exitflag_bfgs));
    
    % Method 3: Gradient descent (custom implementation)
    fprintf('\\textbf{Method 3: Gradient Descent} (custom implementation)\n');
    
    [x_gd, fval_gd, iter_gd, history_gd] = gradientDescent(...
        rosenbrockFunc, rosenbrockGrad, x0, 0.001, 1e-6, 10000);
    
    fprintf('  Solution: $(x^*, y^*) = (%.6f, %.6f)$\n', x_gd(1), x_gd(2));
    fprintf('  Function value: $f(x^*) = %.2e$\n', fval_gd);
    fprintf('  Iterations: %d\n', iter_gd);
    fprintf('  Final gradient norm: $||\\nabla f|| = %.2e$\n\n', ...
        norm(rosenbrockGrad(x_gd)));
    
    % Performance comparison
    fprintf('\\textbf{Performance Comparison}:\n');
    fprintf('%-20*s  %-12*s  %-12*s  %-15*s\n', 'Method', 'Func Evals', ...
        'Time (s)', 'Final Error');
    fprintf('%s\n', repmat('-', 1, 65));
    
    trueMin = [1; 1];
    error_nm = norm(x_nm - trueMin);
    error_bfgs = norm(x_bfgs - trueMin);
    error_gd = norm(x_gd - trueMin);
    
    fprintf('%-20*s  %-12*d  %-12.4*f  %-15.2*e\n', 'Nelder-Mead', ...
        output_nm.funcCount, time_nm, error_nm);
    fprintf('%-20*s  %-12*d  %-12.4*f  %-15.2*e\n', 'BFGS', ...
        output_bfgs.funcCount, time_bfgs, error_bfgs);
    fprintf('%-20*s  %-12*d  %-12.4*f  %-15.2*e\n\n', 'Gradient Descent', ...
        iter_gd, 0, error_gd);
    
    %% Part B: Constrained Optimisation
    fprintf('\\textbf{PART B: CONSTRAINED OPTIMISATION}\n');
    fprintf('-------\n\n');
    
    fprintf(['Historical Context: Lagrange (1788) developed method\n', ...
        'of multipliers for constrained optimisation; Karush-\n', ...
        'Kuhn-Tucker (1951) generalised to inequality constraints.\n\n']);
    
    % Define quadratic objective
    % Minimize: f(x,y) = (x-3)^2 + (y-2)^2
    % Subject to: x + y <= 5 (inequality)
    %             x >= 0, y >= 0 (bounds)
    
    objFunc = @(x) (x(1) - 3)^2 + (x(2) - 2)^2;
    
    fprintf('\\textbf{Problem Formulation}:\n');
    fprintf('  Minimise: $f(x,y) = (x-3)^2 + (y-2)^2$\n');
    fprintf('  Subject to:\n');
    fprintf('    $x + y \\leq 5$ (linear inequality)\n');
    fprintf('    $x \\geq 0, y \\geq 0$ (non-negativity)\n\n');
    
    fprintf('  Unconstrained minimum: $(3, 2)$, $f = 0$\n');
    fprintf('  (Violates constraint: $3 + 2 = 5$ is on boundary)\n\n');
    
    % Linear inequality constraint: A*x <= b
    A = [1, 1];
    b = 5;
    
    % Bounds
    lb = [0; 0];
    ub = [Inf; Inf];
    
    % Initial point (feasible)
    x0_const = [1; 1];
    
    % Solve constrained problem
    options_const = optimoptions('fmincon', 'Display', 'off', ...
        'Algorithm', 'interior-point', 'OptimalityTolerance', 1e-8);
    
    [x_const, fval_const, exitflag_const, output_const, ...
        lambda_const] = fmincon(objFunc, x0_const, A, b, [], [], ...
        lb, ub, [], options_const);
    
    fprintf('\\textbf{Solution Results}:\n');
    fprintf('  Optimal point: $(x^*, y^*) = (%.6f, %.6f)$\n', ...
        x_const(1), x_const(2));
    fprintf('  Optimal value: $f(x^*) = %.6f$\n', fval_const);
    fprintf('  Constraint value: $x^* + y^* = %.6f$ (should be $\\leq 5$)\n', ...
        sum(x_const));
    fprintf('  Iterations: %d\n', output_const.iterations);
    fprintf('  Function evaluations: %d\n\n', output_const.funcCount);
    
    % Lagrange multipliers (dual variables)
    fprintf('\\textbf{Lagrange Multipliers} (sensitivity analysis):\n');
    fprintf('  Inequality constraint: $\\lambda = %.6f$\n', ...
        lambda_const.ineqlin);
    
    if lambda_const.ineqlin > 1e-6
        fprintf('    (Constraint is active/binding)\n');
        fprintf(['    Interpretation: Relaxing constraint by 1 unit\n', ...
            '    decreases objective by approximately %.4f\n'], ...
            lambda_const.ineqlin);
    else
        fprintf('    (Constraint is inactive)\n');
    end
    fprintf('\n');
    
    % Nonlinear constraint example
    fprintf('\\textbf{Nonlinear Constraint Example}:\n');
    fprintf('  Minimise: $f(x,y) = x^2 + y^2$\n');
    fprintf('  Subject to: $(x-1)^2 + (y-1)^2 \\geq 1$ (circle)\n\n');
    
    objSimple = @(x) x(1)^2 + x(2)^2;
    
    % Nonlinear inequality: c(x) <= 0
    % Here: -(x-1)^2 - (y-1)^2 + 1 <= 0  or  (x-1)^2 + (y-1)^2 >= 1
    nonlincon = @(x) deal(1 - (x(1)-1)^2 - (x(2)-1)^2, []);
    
    x0_nonlin = [2; 2];
    
    [x_nonlin, fval_nonlin, exitflag_nonlin, output_nonlin, ...
        lambda_nonlin] = fmincon(objSimple, x0_nonlin, [], [], ...
        [], [], [], [], nonlincon, options_const);
    
    fprintf('  Solution: $(x^*, y^*) = (%.6f, %.6f)$\n', ...
        x_nonlin(1), x_nonlin(2));
    fprintf('  Objective value: $f(x^*) = %.6f$\n', fval_nonlin);
    fprintf('  Distance from origin: $r = %.6f$\n', norm(x_nonlin));
    fprintf('  Constraint check: $(x-1)^2 + (y-1)^2 = %.6f$ ($\\geq 1$)\n', ...
        (x_nonlin(1)-1)^2 + (x_nonlin(2)-1)^2);
    fprintf('  Lagrange multiplier: $\\lambda = %.6f$\n\n', ...
        lambda_nonlin.ineqnonlin);
    
    %% Part C: Global Optimisation
    fprintf('\\textbf{PART C: GLOBAL OPTIMISATION}\n');
    fprintf('-------\n\n');
    
    fprintf(['Historical Context: Rastrigin (1974) and others developed\n', ...
        'highly multimodal test functions; evolutionary algorithms\n', ...
        '(Holland, 1975) inspired by natural selection.\n\n']);
    
    % Rastrigin function: highly multimodal
    % f(x,y) = 20 + x^2 + y^2 - 10*(cos(2π x) + cos(2π y))
    % Global minimum at (0,0) with f = 0
    % Many local minima throughout search space
    
    rastriginFunc = @(x) 20 + x(1)^2 + x(2)^2 - ...
        10*(cos(2*pi*x(1)) + cos(2*pi*x(2)));
    
    fprintf('\\textbf{Test Function}: Rastrigin Function\n');
    fprintf('  $f(x,y) = 20 + x^2 + y^2 - 10*(\\cos(2\\pi x) + \\cos(2\\pi y))$\n');
    fprintf('  Global minimum: $(0, 0)$, $f = 0$\n');
    fprintf('  Characteristics: Highly multimodal, many local minima\n');
    fprintf('  Search domain: $[-5.12, 5.12]^2$\n\n');
    
    % Local optimisation (likely finds local minimum)
    fprintf('\\textbf{Method 1: Local Optimisation} (fminunc)\n');
    
    x0_local = [4; 4];
    options_local = optimoptions('fminunc', 'Display', 'off', ...
        'Algorithm', 'quasi-newton');
    
    tic;
    [x_local, fval_local, ~, output_local] = fminunc(...
        rastriginFunc, x0_local, options_local);
    time_local = toc;
    
    fprintf('  Starting point: $(%.1f, %.1f)$\n', x0_local(1), x0_local(2));
    fprintf('  Solution found: $(%.4f, %.4f)$\n', x_local(1), x_local(2));
    fprintf('  Function value: $f = %.4f$\n', fval_local);
    fprintf('  Computation time: %.4f seconds\n', time_local);
    fprintf('  (Likely trapped in local minimum)\n\n');
    
    % Genetic algorithm (global optimisation)
    fprintf('\\textbf{Method 2: Genetic Algorithm}\n');
    
    lb_global = [-5.12; -5.12];
    ub_global = [5.12; 5.12];
    
    options_ga = optimoptions('ga', 'Display', 'off', ...
        'PopulationSize', 100, 'MaxGenerations', 200, ...
        'FunctionTolerance', 1e-8);
    
    tic;
    [x_ga, fval_ga, exitflag_ga, output_ga] = ga(rastriginFunc, 2, ...
        [], [], [], [], lb_global, ub_global, [], options_ga);
    time_ga = toc;
    
    fprintf('  Solution found: $(%.6f, %.6f)$\n', x_ga(1), x_ga(2));
    fprintf('  Function value: $f = %.4e$\n', fval_ga);
    fprintf('  Generations: %d\n', output_ga.generations);
    fprintf('  Function evaluations: %d\n', output_ga.funccount);
    fprintf('  Computation time: %.4f seconds\n', time_ga);
    fprintf('  Error from global minimum: $\\epsilon = %.4e$\n\n', fval_ga);
    
    % Multi-start optimisation
    fprintf('\\textbf{Method 3: Multi-Start Local Optimisation}\n');
    
    numStarts = 50;
    
    problem = createOptimProblem('fminunc', 'objective', rastriginFunc, ...
        'x0', x0_local, 'options', options_local);
    
    ms = MultiStart('Display', 'off', 'UseParallel', false);
    
    tic;
    [x_ms, fval_ms, exitflag_ms, output_ms, solutions_ms] = ...
        run(ms, problem, numStarts);
    time_ms = toc;
    
    fprintf('  Number of start points: %d\n', numStarts);
    fprintf('  Local minima found: %d\n', length(solutions_ms));
    fprintf('  Best solution: $(%.6f, %.6f)$\n', x_ms(1), x_ms(2));
    fprintf('  Best function value: $f = %.4e$\n', fval_ms);
    fprintf('  Total function evaluations: %d\n', output_ms.funcCount);
    fprintf('  Computation time: %.4f seconds\n', time_ms);
    fprintf('  Error from global minimum: $\\epsilon = %.4e$\n\n', fval_ms);
    
    % Performance comparison
    fprintf('\\textbf{Global Optimisation Comparison}:\n');
    fprintf('%-20*s  %-18*s  %-12*s  %-15*s\n', 'Method', ...
        'Solution Found', 'Time (s)', 'Final Error');
    fprintf('%s\n', repmat('-', 1, 70));
    
    fprintf('%-20*s  (%.4f, %.4f)  %-12.4*f  %-15.4*e\n', 'Local (fminunc)', ...
        x_local(1), x_local(2), time_local, fval_local);
    fprintf('%-20*s  (%.4f, %.4f)  %-12.4*f  %-15.4*e\n', ...
        'Genetic Algorithm', x_ga(1), x_ga(2), time_ga, fval_ga);
    fprintf('%-20*s  (%.4f, %.4f)  %-12.4*f  %-15.4*e\n\n', 'Multi-Start', ...
        x_ms(1), x_ms(2), time_ms, fval_ms);
    
    %% Visualisations
    createOptimisationPlots(rosenbrockFunc, history_gd, x_const, ...
        objFunc, A, b, rastriginFunc, x_local, x_ga, x_ms, solutions_ms);
    
    fprintf('\\textbf{Exercise Complete}\n\n');
    fprintf(['Key Insights:\n', ...
        '1. Gradient-based methods converge faster for smooth functions\n', ...
        '2. Gradient-free methods work when derivatives unavailable\n', ...
        '3. Constrained optimisation enforces feasibility requirements\n', ...
        '4. Lagrange multipliers reveal constraint sensitivity\n', ...
        '5. Global optimisation essential for multimodal functions\n']);
end

function [xOpt, fOpt, iter, history] = gradientDescent(f, grad, x0, ...
    alpha, tol, maxIter)
    % GRADIENTDESCENT Custom gradient descent implementation
    
    x = x0;
    history = zeros(maxIter, 3);  % iteration, x, y, f(x,y)
    
    for iter = 1:maxIter
        g = grad(x);
        
        % Store history
        history(iter, :) = [x(1), x(2), f(x)];
        
        % Convergence check
        if norm(g) < tol
            history = history(1:iter, :);
            break;
        end
        
        % Gradient descent update
        x = x - alpha * g;
    end
    
    xOpt = x;
    fOpt = f(x);
end

function msg = getExitMessage(flag)
    % GETEXITMESSAGE Convert exit flag to readable message
    
    switch flag
        case 1
            msg = 'First-order optimality satisfied';
        case 0
            msg = 'Maximum iterations/evaluations reached';
        case -1
            msg = 'Stopped by output function';
        case -2
            msg = 'No feasible point found';
        case -3
            msg = 'Objective unbounded below';
        otherwise
            msg = sprintf('Exit flag %d', flag);
    end
end

function createOptimisationPlots(rosenFunc, gdHistory, xConst, ...
    objFunc, A, b, rastrFunc, xLocal, xGA, xMS, solsMS)
    % CREATEOPTIMISATIONPLOTS Generate comprehensive visualisations
    
    figure('Position', [100, 100, 1600, 1000]);
    
    % Rosenbrock contour with gradient descent path
    subplot(2, 3, 1);
    [X, Y] = meshgrid(linspace(-2, 2, 200), linspace(-1, 3, 200));
    Z = arrayfun(@(x,y) rosenFunc([x;y]), X, Y);
    
    contour(X, Y, log10(Z), 50);
    hold on;
    plot(gdHistory(:,1), gdHistory(:,2), 'r-o', 'LineWidth', 2, ...
        'MarkerSize', 4);
    plot(1, 1, 'g*', 'MarkerSize', 15, 'LineWidth', 2);
    
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    title('Rosenbrock: Gradient Descent Path', 'Interpreter', 'latex');
    colorbar;
    grid on;
    
    % Convergence history
    subplot(2, 3, 2);
    semilogy(1:size(gdHistory,1), gdHistory(:,3), 'b-', 'LineWidth', 2);
    xlabel('Iteration', 'Interpreter', 'latex');
    ylabel('$f(x)$ (log scale)', 'Interpreter', 'latex');
    title('Gradient Descent Convergence', 'Interpreter', 'latex');
    grid on;
    
    % Constrained optimisation visualisation
    subplot(2, 3, 3);
    [X2, Y2] = meshgrid(linspace(-0.5, 5, 100), linspace(-0.5, 5, 100));
    Z2 = arrayfun(@(x,y) objFunc([x;y]), X2, Y2);
    
    contour(X2, Y2, Z2, 30);
    hold on;
    
    % Plot constraint boundary
    xLine = linspace(0, 5, 100);
    yLine = b - A(1) * xLine;
    plot(xLine, yLine, 'r-', 'LineWidth', 2.5, 'DisplayName', ...
        'Constraint: $x+y=5$');
    
    % Fill feasible region
    xFill = [0, 5, 0, 0];
    yFill = [0, 0, 5, 0];
    fill(xFill, yFill, 'g', 'FaceAlpha', 0.1, 'DisplayName', ...
        'Feasible Region');
    
    % Plot unconstrained and constrained optima
    plot(3, 2, 'b*', 'MarkerSize', 15, 'LineWidth', 2, ...
        'DisplayName', 'Unconstrained Min');
    plot(xConst(1), xConst(2), 'r*', 'MarkerSize', 15, 'LineWidth', 2, ...
        'DisplayName', 'Constrained Min');
    
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    title('Constrained Optimisation', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    axis([0, 5, 0, 5]);
    
    % Rastrigin surface
    subplot(2, 3, 4);
    [X3, Y3] = meshgrid(linspace(-5.12, 5.12, 200), ...
        linspace(-5.12, 5.12, 200));
    Z3 = arrayfun(@(x,y) rastrFunc([x;y]), X3, Y3);
    
    surf(X3, Y3, Z3, 'EdgeColor', 'none');
    hold on;
    plot3(0, 0, 0, 'r*', 'MarkerSize', 20, 'LineWidth', 3);
    
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$f(x,y)$', 'Interpreter', 'latex');
    title('Rastrigin Function (3*D)', 'Interpreter', 'latex');
    colormap('jet');
    view(45, 30);
    
    % Rastrigin contour with solutions
    subplot(2, 3, 5);
    contour(X3, Y3, Z3, 50);
    hold on;
    
    % Plot all local minima found by multi-start
    for idx = 1:length(solsMS)
        sol = solsMS(idx).X;
        plot(sol(1), sol(2), 'ko', 'MarkerSize', 6, 'LineWidth', 1);
    end
    
    % Plot solutions from different methods
    plot(xLocal(1), xLocal(2), 'bs', 'MarkerSize', 12, 'LineWidth', 2, ...
        'DisplayName', 'Local Method');
    plot(xGA(1), xGA(2), 'gd', 'MarkerSize', 12, 'LineWidth', 2, ...
        'DisplayName', 'Genetic Algorithm');
    plot(xMS(1), xMS(2), 'r^', 'MarkerSize', 12, 'LineWidth', 2, ...
        'DisplayName', 'Multi-Start');
    plot(0, 0, 'r*', 'MarkerSize', 20, 'LineWidth', 3, ...
        'DisplayName', 'Global Minimum');
    
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    title('Rastrigin: Global Optimisation Comparison', ...
        'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    colorbar;
    grid on;
    
    % Function evaluation distribution (multi-start)
    subplot(2, 3, 6);
    fvals = arrayfun(@(s) s.Fval, solsMS);
    histogram(fvals, 20, 'FaceColor', [0.3, 0.6, 0.9]);
    xlabel('Function Value', 'Interpreter', 'latex');
    ylabel('Frequency', 'Interpreter', 'latex');
    title('Multi-Start: Local Minima Distribution', 'Interpreter', 'latex');
    grid on;
end
