%% Appendix01-Solutions_code_244.m
% Genetic Algorithm for PID Parameter Optimisation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Genetic Algorithm for PID Parameter Optimisation
% Problem 11: AI-Driven PID Tuning
% Author: Control Systems Course
% Description: Complete GA implementation for optimal PID design

clear all; close all; clc;

%% System Definition
fprintf('=== GA-Based PID Optimisation for DC Motor ===\n\n');

% DC Motor Transfer Function: G(s) = K/(s(Js+b))
J = 0.01;   % Moment of inertia (kg*m^2)
b = 0.1;    % Viscous friction (N*m*s)
K = 0.01;   % Motor torque constant (N*m/A)

% Transfer function
num = K;
den = [J, b, 0];
G = tf(num, den);

fprintf('DC Motor Transfer Function:\n');
fprintf('G(s) = %.2f / (s(%.2fs + %.1f))\n', K, J, b);
fprintf('    = 1 / (s(s + 10))\n\n');

% Discretization
Ts = 0.01;  % Sampling time (10ms)
Gz = c2d(G, Ts, 'zoh');

fprintf('Sampling time: %.3f s\n', Ts);

%% GA Parameters
ga_params = struct();

% Population
ga_params.pop_size = 50;        % Population size
ga_params.n_generations = 100;   % Number of generations
ga_params.n_elite = 2;          % Elitism: preserve best individuals

% Genetic operators
ga_params.p_crossover = 0.8;    % Crossover probability
ga_params.p_mutation = 0.1;     % Mutation probability
ga_params.crossover_type = 'arithmetic';  % 'single', 'uniform', 'arithmetic', 'blx'
ga_params.mutation_type = 'gaussian';     % 'uniform', 'gaussian', 'adaptive'
ga_params.selection_type = 'tournament';  % 'roulette', 'tournament', 'rank'
ga_params.tournament_size = 3;  % For tournament selection

% Mutation parameters
ga_params.mutation_range = 0.2;     % For uniform mutation
ga_params.mutation_sigma = 0.1;     % For Gaussian mutation
ga_params.adaptive_power = 2;       % For adaptive mutation

% Search space bounds
ga_params.Kp_min = 0;
ga_params.Kp_max = 100;
ga_params.Ki_min = 0;
ga_params.Ki_max = 50;
ga_params.Kd_min = 0;
ga_params.Kd_max = 20;

fprintf('GA Configuration:\n');
fprintf('  Population size: %d\n', ga_params.pop_size);
fprintf('  Generations: %d\n', ga_params.n_generations);
fprintf('  Crossover probability: %.2f\n', ga_params.p_crossover);
fprintf('  Mutation probability: %.2f\n', ga_params.p_mutation);
fprintf('  Selection: %s\n', ga_params.selection_type);
fprintf('  Crossover: %s\n', ga_params.crossover_type);
fprintf('  Mutation: %s\n\n', ga_params.mutation_type);

%% Fitness Function Parameters
fitness_params = struct();
fitness_params.Ts = Ts;
fitness_params.T_sim = 5;               % Simulation time (s)
fitness_params.setpoint = 1;            % Unit step reference

% Multi-objective weights
fitness_params.w_itae = 1.0;            % ITAE weight
fitness_params.w_overshoot = 10.0;      % Overshoot penalty weight
fitness_params.w_settling = 2.0;        % Settling time weight
fitness_params.w_control = 0.01;        % Control effort weight
fitness_params.w_steady_state = 50.0;   % Steady-state error weight

% Constraints
fitness_params.max_overshoot = 15;      % Maximum allowed overshoot (%)
fitness_params.max_control = 100;       % Maximum control signal
fitness_params.settling_threshold = 0.02; % 2% settling criterion

fprintf('Fitness Function:\n');
fprintf('  Simulation time: %.1f s\n', fitness_params.T_sim);
fprintf('  ITAE weight: %.2f\n', fitness_params.w_itae);
fprintf('  Overshoot penalty: %.2f\n', fitness_params.w_overshoot);
fprintf('  Max overshoot allowed: %.1f%%\n', fitness_params.max_overshoot);

%% Initialize Population
fprintf('\nInitializing population...\n');

population = zeros(ga_params.pop_size, 3);
for i = 1:ga_params.pop_size
    population(i, 1) = ga_params.Kp_min + rand()*(ga_params.Kp_max - ga_params.Kp_min);
    population(i, 2) = ga_params.Ki_min + rand()*(ga_params.Ki_max - ga_params.Ki_min);
    population(i, 3) = ga_params.Kd_min + rand()*(ga_params.Kd_max - ga_params.Kd_min);
end

fprintf('Initial population generated.\n');

%% Storage for Evolution History
best_fitness_history = zeros(ga_params.n_generations, 1);
avg_fitness_history = zeros(ga_params.n_generations, 1);
best_individual_history = zeros(ga_params.n_generations, 3);
diversity_history = zeros(ga_params.n_generations, 1);

%% Genetic Algorithm Main Loop
fprintf('\nStarting GA optimisation...\n');
fprintf('Generation | Best Fitness | Avg Fitness | Best [Kp, Ki, Kd]\n');
fprintf('------|-------|-------|----------\n');

tic;
for gen = 1:ga_params.n_generations
    
    % Evaluate fitness for entire population
    fitness = zeros(ga_params.pop_size, 1);
    for i = 1:ga_params.pop_size
        Kp = population(i, 1);
        Ki = population(i, 2);
        Kd = population(i, 3);
        
        fitness(i) = evaluate_pid_fitness(Kp, Ki, Kd, Gz, fitness_params);
    end
    
    % Track statistics
    [best_fitness, best_idx] = max(fitness);
    avg_fitness = mean(fitness);
    best_individual = population(best_idx, :);
    
    best_fitness_history(gen) = best_fitness;
    avg_fitness_history(gen) = avg_fitness;
    best_individual_history(gen, :) = best_individual;
    
    % Calculate population diversity (standard deviation)
    diversity_history(gen) = mean(std(population));
    
    % Display progress
    if mod(gen, 10) == 0 || gen == 1
        fprintf('%10d | %12.6f | %11.6f | [%.2f, %.2f, %.2f]\n', ...
                gen, best_fitness, avg_fitness, best_individual);
    end
    
    % Elitism: preserve best individuals
    [~, elite_indices] = maxk(fitness, ga_params.n_elite);
    elite = population(elite_indices, :);
    
    % Create new population
    new_population = zeros(ga_params.pop_size, 3);
    new_population(1:ga_params.n_elite, :) = elite;
    
    % Generate offspring
    for i = ga_params.n_elite+1:2:ga_params.pop_size
        % Selection
        parent1 = select_parent(population, fitness, ga_params);
        parent2 = select_parent(population, fitness, ga_params);
        
        % Crossover
        if rand() < ga_params.p_crossover
            [child1, child2] = crossover(parent1, parent2, ga_params);
        else
            child1 = parent1;
            child2 = parent2;
        end
        
        % Mutation
        if rand() < ga_params.p_mutation
            child1 = mutate(child1, ga_params, gen);
        end
        if rand() < ga_params.p_mutation
            child2 = mutate(child2, ga_params, gen);
        end
        
        % Apply bounds
        child1 = apply_bounds(child1, ga_params);
        child2 = apply_bounds(child2, ga_params);
        
        % Add to new population
        new_population(i, :) = child1;
        if i+1 <= ga_params.pop_size
            new_population(i+1, :) = child2;
        end
    end
    
    % Replace population
    population = new_population;
end

elapsed_time = toc;
fprintf('\nGA optimisation completed in %.2f seconds.\n', elapsed_time);

%% Extract Best Solution
[~, best_gen] = max(best_fitness_history);
best_pid = best_individual_history(best_gen, :);
Kp_ga = best_pid(1);
Ki_ga = best_pid(2);
Kd_ga = best_pid(3);

fprintf('\n=== Optimal PID Parameters (GA) ===\n');
fprintf('Kp = %.4f\n', Kp_ga);
fprintf('Ki = %.4f\n', Ki_ga);
fprintf('Kd = %.4f\n', Kd_ga);
fprintf('Best fitness: %.6f (generation %d)\n', best_fitness_history(best_gen), best_gen);

%% Comparison: Ziegler-Nichols Tuning
fprintf('\n=== Ziegler-Nichols Tuning (for comparison) ===\n');

% Find ultimate gain and period using Routh-Hurwitz
% For G(s) = 1/(s(s+10)), closed-loop with P controller
% Characteristic equation: s^2 + 10s + Ku = 0
% Routh array: Ku must be > 0 for stability
% Marginally stable when s^2 + 10s + Ku has roots on imaginary axis
% s^2 + 10s + Ku = 0 => s = -5 +/- j*sqrt(Ku - 25)
% For sustained oscillation: Ku = 25 (when sqrt term = 0, not quite right)

% Better: Use frequency response
[Gm, Pm, Wcg, Wcp] = margin(G);
Ku = Gm;        % Ultimate gain
Pu = 2*pi/Wcp;  % Ultimate period

fprintf('Ultimate gain (Ku): %.4f\n', Ku);
fprintf('Ultimate period (Pu): %.4f s\n', Pu);

% Ziegler-Nichols PID tuning rules
Kp_zn = 0.6 * Ku;
Ki_zn = 1.2 * Ku / Pu;
Kd_zn = 0.075 * Ku * Pu;

fprintf('Ziegler-Nichols PID:\n');
fprintf('  Kp = %.4f\n', Kp_zn);
fprintf('  Ki = %.4f\n', Ki_zn);
fprintf('  Kd = %.4f\n', Kd_zn);

%% Simulate and Compare Responses
fprintf('\nSimulating closed-loop responses...\n');

T_sim = 5;
N = T_sim / Ts;
time = 0:Ts:T_sim;
r = ones(1, length(time));  % Unit step reference

% GA-optimized PID response
[y_ga, u_ga, e_ga] = simulate_pid_response(Gz, Kp_ga, Ki_ga, Kd_ga, r, Ts);

% Ziegler-Nichols PID response
[y_zn, u_zn, e_zn] = simulate_pid_response(Gz, Kp_zn, Ki_zn, Kd_zn, r, Ts);

% Manual tuning (for reference)
Kp_manual = 50;
Ki_manual = 10;
Kd_manual = 5;
[y_manual, u_manual, e_manual] = simulate_pid_response(Gz, Kp_manual, Ki_manual, Kd_manual, r, Ts);

%% Performance Metrics
fprintf('\n=== Performance Comparison ===\n');

% GA controller
metrics_ga = calculate_performance_metrics(y_ga, u_ga, r, Ts);
fprintf('GA-Optimized PID:\n');
print_metrics(metrics_ga);

% Z-N controller
metrics_zn = calculate_performance_metrics(y_zn, u_zn, r, Ts);
fprintf('\nZiegler-Nichols PID:\n');
print_metrics(metrics_zn);

% Manual controller
metrics_manual = calculate_performance_metrics(y_manual, u_manual, r, Ts);
fprintf('\nManual PID:\n');
print_metrics(metrics_manual);

%% Visualization
% Figure 1: Step responses comparison
figure('Position', [100 100 1200 800]);

subplot(3,1,1);
plot(time, r, 'k-', 'LineWidth', 1.5); hold on;
plot(time, y_ga, 'b-', 'LineWidth', 2);
plot(time, y_zn, 'r:', 'LineWidth', 2);
plot(time, y_manual, 'g-.', 'LineWidth', 1.5);
grid on;
ylabel('Output Position');
title('Step Response Comparison');
legend('Reference', 'GA-PID', 'Z-N PID', 'Manual PID', 'Location', 'southeast');
ylim([0 1.5]);

subplot(3,1,2);
plot(time, u_ga, 'b-', 'LineWidth', 2); hold on;
plot(time, u_zn, 'r:', 'LineWidth', 2);
plot(time, u_manual, 'g-.', 'LineWidth', 1.5);
yline(fitness_params.max_control, 'k-', 'u_{max}');
grid on;
ylabel('Control Signal');
title('Control Effort');
legend('GA-PID', 'Z-N PID', 'Manual PID', 'Limit', 'Location', 'northeast');

subplot(3,1,3);
plot(time, e_ga, 'b-', 'LineWidth', 2); hold on;
plot(time, e_zn, 'r:', 'LineWidth', 2);
plot(time, e_manual, 'g-.', 'LineWidth', 1.5);
grid on;
ylabel('Tracking Error');
xlabel('Time (s)');
title('Error Signal');
legend('GA-PID', 'Z-N PID', 'Manual PID', 'Location', 'northeast');

sgtitle('PID Controller Comparison: GA vs Ziegler-Nichols vs Manual', ...
        'FontSize', 14, 'FontWeight', 'bold');

% Figure 2: GA Evolution
figure('Position', [150 150 1200 600]);

subplot(2,2,1);
plot(1:ga_params.n_generations, best_fitness_history, 'b-', 'LineWidth', 2); hold on;
plot(1:ga_params.n_generations, avg_fitness_history, 'r-', 'LineWidth', 1.5);
grid on;
xlabel('Generation');
ylabel('Fitness');
title('Fitness Evolution');
legend('Best', 'Average', 'Location', 'southeast');

subplot(2,2,2);
plot(1:ga_params.n_generations, best_individual_history(:,1), 'r-', 'LineWidth', 2); hold on;
plot(1:ga_params.n_generations, best_individual_history(:,2), 'g-', 'LineWidth', 2);
plot(1:ga_params.n_generations, best_individual_history(:,3), 'b-', 'LineWidth', 2);
grid on;
xlabel('Generation');
ylabel('Parameter Value');
title('Best Individual Evolution');
legend('K_p', 'K_i', 'K_d', 'Location', 'best');

subplot(2,2,3);
plot(1:ga_params.n_generations, diversity_history, 'k-', 'LineWidth', 2);
grid on;
xlabel('Generation');
ylabel('Population Diversity (std)');
title('Population Diversity');

subplot(2,2,4);
convergence_rate = diff(best_fitness_history);
plot(2:ga_params.n_generations, convergence_rate, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Generation');
ylabel('Fitness Improvement');
title('Convergence Rate');

sgtitle('Genetic Algorithm Evolution Analysis', 'FontSize', 14, 'FontWeight', 'bold');

% Figure 3: PID Parameter Space (2D projections)
figure('Position', [200 200 1000 400]);

subplot(1,3,1);
scatter(best_individual_history(:,1), best_individual_history(:,2), 30, ...
        1:ga_params.n_generations, 'filled');
xlabel('K_p'); ylabel('K_i');
title('K_p vs K_i Evolution');
colorbar; colormap('jet');
grid on;

subplot(1,3,2);
scatter(best_individual_history(:,1), best_individual_history(:,3), 30, ...
        1:ga_params.n_generations, 'filled');
xlabel('K_p'); ylabel('K_d');
title('K_p vs K_d Evolution');
colorbar; colormap('jet');
grid on;

subplot(1,3,3);
scatter(best_individual_history(:,2), best_individual_history(:,3), 30, ...
        1:ga_params.n_generations, 'filled');
xlabel('K_i'); ylabel('K_d');
title('K_i vs K_d Evolution');
colorbar; colormap('jet');
grid on;

sgtitle('GA Search Trajectory in Parameter Space', 'FontSize', 13, 'FontWeight', 'bold');

% Figure 4: Robustness Analysis
fprintf('\nPerforming robustness analysis...\n');

% Test with parameter variations (+/- 30%)
param_variations = [0.7, 0.85, 1.0, 1.15, 1.3];
n_var = length(param_variations);

figure('Position', [250 250 1000 600]);
colors = jet(n_var);

for i = 1:n_var
    % Vary plant parameters
    J_var = J * param_variations(i);
    b_var = b * param_variations(i);
    
    num_var = K;
    den_var = [J_var, b_var, 0];
    G_var = tf(num_var, den_var);
    Gz_var = c2d(G_var, Ts, 'zoh');
    
    % Simulate with GA-tuned controller
    [y_var, ~, ~] = simulate_pid_response(Gz_var, Kp_ga, Ki_ga, Kd_ga, r, Ts);
    
    subplot(2,1,1);
    plot(time, y_var, 'Color', colors(i,:), 'LineWidth', 1.5); hold on;
    
    % Simulate with Z-N controller
    [y_zn_var, ~, ~] = simulate_pid_response(Gz_var, Kp_zn, Ki_zn, Kd_zn, r, Ts);
    
    subplot(2,1,2);
    plot(time, y_zn_var, 'Color', colors(i,:), 'LineWidth', 1.5); hold on;
end

subplot(2,1,1);
plot(time, r, 'k-', 'LineWidth', 2);
grid on; ylabel('Output');
title('GA-PID Robustness to Parameter Variations');
legend_str = arrayfun(@(x) sprintf('%.0f%%', x*100), param_variations, 'UniformOutput', false);
legend([legend_str, {'Reference'}], 'Location', 'southeast');
ylim([0 1.5]);

subplot(2,1,2);
plot(time, r, 'k-', 'LineWidth', 2);
grid on; ylabel('Output'); xlabel('Time (s)');
title('Z-N PID Robustness to Parameter Variations');
legend([legend_str, {'Reference'}], 'Location', 'southeast');
ylim([0 1.5]);

sgtitle('Robustness Comparison: +/-30% Parameter Variations', ...
        'FontSize', 13, 'FontWeight', 'bold');

fprintf('\n=== GA-Based PID Optimisation Complete ===\n');

%% Helper Functions

function fitness = evaluate_pid_fitness(Kp, Ki, Kd, Gz, params)
    % Evaluate fitness of PID controller
    
    Ts = params.Ts;
    T_sim = params.T_sim;
    time = 0:Ts:T_sim;
    r = params.setpoint * ones(1, length(time));
    
    % Simulate closed-loop response
    [y, u, e] = simulate_pid_response(Gz, Kp, Ki, Kd, r, Ts);
    
    % Calculate performance metrics
    
    % 1. ITAE (Integral of Time-weighted Absolute Error)
    t_vec = time';
    ITAE = Ts * sum(t_vec .* abs(e'));
    
    % 2. Overshoot
    overshoot = max(0, (max(y) - r(end)) / r(end) * 100);
    
    % 3. Settling time (2% criterion)
    final_value = y(end);
    settling_band = params.settling_threshold * abs(final_value);
    settled = abs(y - final_value) <= settling_band;
    settling_idx = find(settled, 1, 'first');
    if isempty(settling_idx)
        settling_time = T_sim;  % Did not settle
    else
        settling_time = time(settling_idx);
    end
    
    % 4. Steady-state error
    steady_state_error = abs(r(end) - y(end));
    
    % 5. Control effort
    control_effort = Ts * sum(u.^2);
    
    % Penalty for constraint violations
    penalty = 0;
    
    % Overshoot penalty
    if overshoot > params.max_overshoot
        penalty = penalty + params.w_overshoot * (overshoot - params.max_overshoot)^2;
    end
    
    % Control saturation penalty
    control_violations = sum(abs(u) > params.max_control);
    penalty = penalty + 1000 * control_violations;
    
    % Stability check
    if any(isnan(y)) || any(isinf(y)) || max(abs(y)) > 100
        fitness = 0;
        return;
    end
    
    % Total cost (to be minimized)
    J = params.w_itae * ITAE + ...
        params.w_settling * settling_time + ...
        params.w_control * control_effort + ...
        params.w_steady_state * steady_state_error + ...
        penalty;
    
    % Convert to fitness (to be maximized)
    fitness = 1 / (1 + J);
end

function [y, u, e] = simulate_pid_response(Gz, Kp, Ki, Kd, r, Ts)
    % Simulate closed-loop PID response
    
    N = length(r);
    y = zeros(1, N);
    u = zeros(1, N);
    e = zeros(1, N);
    
    % PID state variables
    integral = 0;
    prev_error = 0;
    prev_derivative = 0;
    
    % Derivative filter coefficient
    N_filter = 10;
    tau_d = Kd / N_filter;
    
    % Simulate
    x = zeros(size(Gz.A, 1), 1);  % State vector
    
    for k = 1:N
        % Output
        y(k) = Gz.C * x;
        
        % Error
        e(k) = r(k) - y(k);
        
        % PID components
        proportional = Kp * e(k);
        
        integral = integral + Ki * Ts * e(k);
        % Anti-windup
        integral = max(-100, min(100, integral));
        
        % Filtered derivative
        derivative = (tau_d / (tau_d + N_filter * Ts)) * prev_derivative + ...
                     (Kd * N_filter / (tau_d + N_filter * Ts)) * (e(k) - prev_error);
        
        % Control signal
        u(k) = proportional + integral + derivative;
        
        % Saturation
        u(k) = max(-100, min(100, u(k)));
        
        % Update plant state
        if k < N
            x = Gz.A * x + Gz.B * u(k);
        end
        
        % Update previous values
        prev_error = e(k);
        prev_derivative = derivative;
    end
end

function parent = select_parent(population, fitness, params)
    % Select parent based on selection method
    
    switch params.selection_type
        case 'roulette'
            % Roulette wheel selection
            total_fitness = sum(fitness);
            if total_fitness == 0
                parent = population(randi(size(population,1)), :);
            else
                probabilities = fitness / total_fitness;
                cumsum_prob = cumsum(probabilities);
                r = rand();
                idx = find(cumsum_prob >= r, 1, 'first');
                parent = population(idx, :);
            end
            
        case 'tournament'
            % Tournament selection
            tournament_idx = randperm(size(population,1), params.tournament_size);
            [~, winner] = max(fitness(tournament_idx));
            parent = population(tournament_idx(winner), :);
            
        case 'rank'
            % Rank-based selection
            [~, sorted_idx] = sort(fitness);
            ranks = zeros(size(fitness));
            ranks(sorted_idx) = 1:length(fitness);
            probabilities = ranks / sum(ranks);
            cumsum_prob = cumsum(probabilities);
            r = rand();
            idx = find(cumsum_prob >= r, 1, 'first');
            parent = population(idx, :);
    end
end

function [child1, child2] = crossover(parent1, parent2, params)
    % Crossover operation
    
    switch params.crossover_type
        case 'single'
            % Single-point crossover
            point = randi([1, length(parent1)-1]);
            child1 = [parent1(1:point), parent2(point+1:end)];
            child2 = [parent2(1:point), parent1(point+1:end)];
            
        case 'uniform'
            % Uniform crossover
            mask = rand(size(parent1)) > 0.5;
            child1 = parent1;
            child2 = parent2;
            child1(mask) = parent2(mask);
            child2(mask) = parent1(mask);
            
        case 'arithmetic'
            % Arithmetic crossover
            alpha = rand();
            child1 = alpha * parent1 + (1 - alpha) * parent2;
            child2 = (1 - alpha) * parent1 + alpha * parent2;
            
        case 'blx'
            % BLX-alpha crossover
            alpha = 0.5;
            for i = 1:length(parent1)
                cmin = min(parent1(i), parent2(i));
                cmax = max(parent1(i), parent2(i));
                I = cmax - cmin;
                child1(i) = cmin - alpha*I + rand()*(1 + 2*alpha)*I;
                child2(i) = cmin - alpha*I + rand()*(1 + 2*alpha)*I;
            end
    end
end

function child = mutate(individual, params, generation)
    % Mutation operation
    
    child = individual;
    
    switch params.mutation_type
        case 'uniform'
            % Uniform mutation
            for i = 1:length(individual)
                if rand() < 1/length(individual)
                    range = params.mutation_range * (params.Kp_max - params.Kp_min);
                    child(i) = child(i) + (2*rand()-1) * range;
                end
            end
            
        case 'gaussian'
            % Gaussian mutation
            for i = 1:length(individual)
                if rand() < 1/length(individual)
                    sigma = params.mutation_sigma * (params.Kp_max - params.Kp_min);
                    child(i) = child(i) + randn() * sigma;
                end
            end
            
        case 'adaptive'
            % Adaptive non-uniform mutation
            max_gen = params.n_generations;
            for i = 1:length(individual)
                if rand() < 1/length(individual)
                    if i == 1
                        param_max = params.Kp_max;
                    elseif i == 2
                        param_max = params.Ki_max;
                    else
                        param_max = params.Kd_max;
                    end
                    
                    r = rand();
                    delta = (param_max - child(i)) * (1 - r^((1-generation/max_gen)^params.adaptive_power));
                    if rand() > 0.5
                        child(i) = child(i) + delta;
                    else
                        child(i) = child(i) - delta;
                    end
                end
            end
    end
end

function individual = apply_bounds(individual, params)
    % Apply parameter bounds
    
    individual(1) = max(params.Kp_min, min(params.Kp_max, individual(1)));
    individual(2) = max(params.Ki_min, min(params.Ki_max, individual(2)));
    individual(3) = max(params.Kd_min, min(params.Kd_max, individual(3)));
end

function metrics = calculate_performance_metrics(y, u, r, Ts)
    % Calculate performance metrics
    
    time = (0:length(y)-1) * Ts;
    e = r - y;
    
    % Rise time (10% to 90%)
    final_value = y(end);
    idx_10 = find(y >= 0.1*final_value, 1, 'first');
    idx_90 = find(y >= 0.9*final_value, 1, 'first');
    if ~isempty(idx_10) && ~isempty(idx_90)
        metrics.rise_time = time(idx_90) - time(idx_10);
    else
        metrics.rise_time = NaN;
    end
    
    % Overshoot
    metrics.overshoot = max(0, (max(y) - final_value) / final_value * 100);
    
    % Settling time (2%)
    settling_band = 0.02 * abs(final_value);
    settled = abs(y - final_value) <= settling_band;
    settling_idx = find(settled, 1, 'first');
    if ~isempty(settling_idx)
        metrics.settling_time = time(settling_idx);
    else
        metrics.settling_time = time(end);
    end
    
    % Steady-state error
    metrics.steady_state_error = abs(r(end) - y(end));
    
    % IAE, ISE, ITAE, ITSE
    metrics.IAE = Ts * sum(abs(e));
    metrics.ISE = Ts * sum(e.^2);
    metrics.ITAE = Ts * sum(time' .* abs(e'));
    metrics.ITSE = Ts * sum(time' .* e'.^2);
    
    % Control effort
    metrics.control_effort = Ts * sum(u.^2);
    metrics.max_control = max(abs(u));
end

function print_metrics(metrics)
    % Print performance metrics
    
    fprintf('  Rise time: %.3f s\n', metrics.rise_time);
    fprintf('  Overshoot: %.2f%%\n', metrics.overshoot);
    fprintf('  Settling time: %.3f s\n', metrics.settling_time);
    fprintf('  Steady-state error: %.4f\n', metrics.steady_state_error);
    fprintf('  IAE: %.4f\n', metrics.IAE);
    fprintf('  ISE: %.4f\n', metrics.ISE);
    fprintf('  ITAE: %.4f\n', metrics.ITAE);
    fprintf('  Control effort: %.4f\n', metrics.control_effort);
    fprintf('  Max control: %.2f\n', metrics.max_control);
end
