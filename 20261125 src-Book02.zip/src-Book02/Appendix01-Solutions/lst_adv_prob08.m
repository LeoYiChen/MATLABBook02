%% lst_adv_prob08.m
% Quality control statistical analysis
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob08
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem08.m
%  Quality Control Using Statistical Analysis
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. Generate Sample Data --
rng(42);  % reproducibility
sampleSize     = 50;
targetDiameter = 10.00;  % mm
boltDiameters  = 10.02 + 0.15 * randn(sampleSize, 1);

%% -- 2. Descriptive Statistics --
sampleMean   = mean(boltDiameters);
sampleMedian = median(boltDiameters);
sampleStd    = std(boltDiameters);
quartiles    = quantile(boltDiameters, [0.25 0.50 0.75]);

fprintf('-- Descriptive Statistics --\n');
fprintf('  Sample size  = %d\n', sampleSize);
fprintf('  Mean         = %.4f mm\n', sampleMean);
fprintf('  Median       = %.4f mm\n', sampleMedian);
fprintf('  Std dev      = %.4f mm\n', sampleStd);
fprintf('  Q1           = %.4f mm\n', quartiles(1));
fprintf('  Q2 (median)  = %.4f mm\n', quartiles(2));
fprintf('  Q3           = %.4f mm\n', quartiles(3));
fprintf('  IQR          = %.4f mm\n', quartiles(3)-quartiles(1));

%% -- 3. One-Sample t-Test --
[rejectNull, pValue, confidenceInterval, testStatistics] = ...
    ttest(boltDiameters, targetDiameter, 'Alpha', 0.05);

fprintf('\n-- One-Sample t-Test (H0: mu = %.2f) --\n', ...
    targetDiameter);
fprintf('  t-statistic  = %.4f\n', testStatistics.tstat);
fprintf('  Degrees of freedom = %d\n', testStatistics.df);
fprintf('  p-value      = %.4f\n', pValue);
fprintf('  95%% CI       = [%.4f, %.4f] mm\n', ...
    confidenceInterval(1), confidenceInterval(2));
if rejectNull
    fprintf('  Decision: REJECT H0 (significant difference)\n');
else
    fprintf('  Decision: FAIL TO REJECT H0\n');
end

%% -- 4. Process Capability --
upperSpecLimit = 10.50;  % mm
lowerSpecLimit = 9.50;   % mm
cpUpper = (upperSpecLimit - sampleMean) / (3 * sampleStd);
cpLower = (sampleMean - lowerSpecLimit) / (3 * sampleStd);
cProcessCapability = min(cpUpper, cpLower);

fprintf('\n-- Process Capability --\n');
fprintf('  USL = %.2f mm, LSL = %.2f mm\n', ...
    upperSpecLimit, lowerSpecLimit);
fprintf('  C_pu = %.4f\n', cpUpper);
fprintf('  C_pl = %.4f\n', cpLower);
fprintf('  C_pk = %.4f\n', cProcessCapability);
if cProcessCapability >= 1.33
    fprintf('  Assessment: CAPABLE (C_pk >= 1.33)\n');
elseif cProcessCapability >= 1.00
    fprintf('  Assessment: MARGINALLY CAPABLE\n');
else
    fprintf('  Assessment: INCAPABLE (C_pk < 1.00)\n');
end

%% -- 5. Visualisation --
figHandle = figure('Position', [80 80 1200 500]);

subplot(1,2,1);
histogram(boltDiameters, 12, 'Normalization', 'pdf', ...
    'FaceColor', [0.5 0.7 1.0]); hold on;
xRange = linspace(min(boltDiameters)-0.3, ...
                  max(boltDiameters)+0.3, 200);
normalPDF = normpdf(xRange, sampleMean, sampleStd);
plot(xRange, normalPDF, 'r-', 'LineWidth', 2);
xline(targetDiameter, 'g-', 'LineWidth', 2);
xline(upperSpecLimit, 'k-', 'LineWidth', 1.5);
xline(lowerSpecLimit, 'k-', 'LineWidth', 1.5);
xlabel('Bolt diameter (mm)', 'Interpreter', 'latex');
ylabel('Probability density', 'Interpreter', 'latex');
title('Histogram with Normal Fit', 'Interpreter', 'latex');
legend({'Data', 'Normal fit', 'Target', 'Spec limits'}, ...
       'Interpreter', 'latex');
grid on;

subplot(1,2,2);
qqplot(boltDiameters);
title('Q-Q Plot (Normality Assessment)', ...
      'Interpreter', 'latex');
xlabel('Standard normal quantiles', 'Interpreter', 'latex');
ylabel('Sample quantiles (mm)', 'Interpreter', 'latex');
grid on;

savefig(figHandle, 'Problem08_QualityControl.fig');
exportgraphics(figHandle, 'Problem08_QualityControl.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem08_QualityControl.jpg', ...
               'Resolution', 300);

fprintf('\n-- Problem 8 Complete --\n');
% Computational Complexity:
% Descriptive statistics (mean, std, median) each require O(n)
% operations.  Sorting for quantiles and the Q-Q plot costs
% O(n log n).  The t-test computation is O(n) for the test
% statistic plus O(1) for the p-value lookup.  Histogram
% binning is O(n).  Overall complexity: O(n log n), dominated
% by sorting.  Space complexity is O(n) for the sample and
% O(numBins) for the histogram.  All operations are negligible
% for n=50.
