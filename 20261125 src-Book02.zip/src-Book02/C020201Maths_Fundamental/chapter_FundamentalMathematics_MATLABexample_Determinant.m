%% chapter_FundamentalMathematics_MATLABexample_Determinant.m
% Determinant computation and geometric interpretation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_Determinant
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_3_2_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates determinant calculation and its geometric
%              interpretation through volume scaling visualisation.

function demonstrateDeterminantOperations()
    fprintf('Matrix Determinant: Computation and Interpretation\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Basic determinant calculation
    fprintf('Part 1: Basic Determinant Calculations\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % 2$\times$2 matrix example
    matrix2x2 = [3, 1; 2, 4];
    det2x2 = det(matrix2x2);
    
    fprintf('2$\times$2 Matrix:\n');
    disp(matrix2x2);
    fprintf('Determinant = %.4f\n', det2x2);
    fprintf('Manual calculation: (3)(4) - (1)(2) = %.4f\n\n', ...
            3*4 - 1*2);
    
    % 3$\times$3 matrix example
    matrix3x3 = [2, -1, 3; 1, 4, -2; 3, 1, 5];
    det3x3 = det(matrix3x3);
    
    fprintf('3$\times$3 Matrix:\n');
    disp(matrix3x3);
    fprintf('Determinant = %.4f\n\n', det3x3);
    
    % Determinant properties demonstration
    fprintf('Part 2: Fundamental Properties\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    matrixA = randn(4, 4);
    matrixB = randn(4, 4);
    
    % Property 1: det(AB) = det(A)det(B)
    detA = det(matrixA);
    detB = det(matrixB);
    detAB = det(matrixA * matrixB);
    productDets = detA * detB;
    
    fprintf('Multiplicativity Property: det(AB) = det(A)·det(B)\n');
    fprintf('  det(A) = %.6f\n', detA);
    fprintf('  det(B) = %.6f\n', detB);
    fprintf('  det(A)·det(B) = %.6f\n', productDets);
    fprintf('  det(AB) = %.6f\n', detAB);
    fprintf('  Difference: %.10e\n\n', abs(detAB - productDets));
    
    % Property 2: det(A^T) = det(A)
    detAT = det(matrixA');
    fprintf('Transpose Invariance: det(A'') = det(A)\n');
    fprintf('  det(A) = %.6f\n', detA);
    fprintf('  det(A'') = %.6f\n', detAT);
    fprintf('  Difference: %.10e\n\n', abs(detA - detAT));
    
    % Property 3: Singular matrix has zero determinant
    singularMatrix = [1, 2, 3; 4, 5, 6; 7, 8, 9]; % Linearly dependent rows
    detSingular = det(singularMatrix);
    
    fprintf('Singular Matrix (linearly dependent rows):\n');
    disp(singularMatrix);
    fprintf('Determinant = %.10e (should be ≈ 0)\n', detSingular);
    fprintf('Matrix rank = %d (full rank would be %d)\n\n', ...
            rank(singularMatrix), size(singularMatrix, 1));
    
    % Geometric interpretation in 2*D
    visualiseDeterminantGeometry2D();
    
    % Geometric interpretation in 3*D
    visualiseDeterminantGeometry3D();
    
    % Invertibility and determinant relationship
    demonstrateInvertibilityRelation();
end

function visualiseDeterminantGeometry2D()
    % Visualise geometric interpretation in 2*D
    
    fprintf('Part 3: Geometric Interpretation (2*D)\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define transformation matrix
    transformMatrix = [2, 1; 0.5, 1.5];
    detTransform = det(transformMatrix);
    
    fprintf('Transformation matrix:\n');
    disp(transformMatrix);
    fprintf('Determinant = %.4f (area scaling factor)\n\n', detTransform);
    
    % Create unit square
    unitSquare = [0, 1, 1, 0, 0; 0, 0, 1, 1, 0];
    
    % Apply transformation
    transformedSquare = transformMatrix * unitSquare;
    
    % Visualise
    figure('Position', [100, 100, 1200, 500]);
    
    % Original square
    subplot(1, 2, 1);
    fill(unitSquare(1, :), unitSquare(2, :), [0.7, 0.9, 1.0], ...
         'EdgeColor', 'b', 'LineWidth', 2);
    hold on;
    quiver(0, 0, 1, 0, 0, 'r', 'LineWidth', 2, 'MaxHeadSize', 0.5);
    quiver(0, 0, 0, 1, 0, 'g', 'LineWidth', 2, 'MaxHeadSize', 0.5);
    axis equal;
    grid on;
    xlim([-0.5, 2]);
    ylim([-0.5, 2]);
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Unit Square (Area = 1)', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Unit Square', 'Basis Vector $\mathbf{e}_1$', ...
           'Basis Vector $\mathbf{e}_2$', ...
           'Interpreter', 'latex', 'Location', 'northwest');
    set(gca, 'FontSize', 11);
    
    % Transformed square
    subplot(1, 2, 2);
    fill(transformedSquare(1, :), transformedSquare(2, :), ...
         [1.0, 0.9, 0.7], 'EdgeColor', 'b', 'LineWidth', 2);
    hold on;
    
    % Show transformed basis vectors
    col1 = transformMatrix(:, 1);
    col2 = transformMatrix(:, 2);
    quiver(0, 0, col1(1), col1(2), 0, 'r', 'LineWidth', 2, ...
           'MaxHeadSize', 0.5);
    quiver(0, 0, col2(1), col2(2), 0, 'g', 'LineWidth', 2, ...
           'MaxHeadSize', 0.5);
    
    axis equal;
    grid on;
    xlim([-0.5, 3.5]);
    ylim([-0.5, 3.5]);
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    titleText = sprintf('Transformed Parallelogram (Area = %.2f)', ...
                       abs(detTransform));
    title(titleText, 'Interpreter', 'latex', 'FontSize', 13);
    legend('Transformed Region', 'Transformed $\mathbf{e}_1$', ...
           'Transformed $\mathbf{e}_2$', ...
           'Interpreter', 'latex', 'Location', 'northwest');
    set(gca, 'FontSize', 11);
    
    fprintf('Visualisation created: 2*D area scaling demonstration\n');
    fprintf('Area of transformed region / Area of original = %.4f\n', ...
            abs(detTransform));
    fprintf('This equals |det(A)| as predicted by theory\n\n');
end

function visualiseDeterminantGeometry3D()
    % Visualise geometric interpretation in 3*D
    
    fprintf('Part 4: Geometric Interpretation (3*D)\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define 3*D transformation matrix
    transform3D = [2, 0, 0.5; 0, 1.5, 0; 0.5, 0, 2];
    det3D = det(transform3D);
    
    fprintf('3*D Transformation matrix:\n');
    disp(transform3D);
    fprintf('Determinant = %.4f (volume scaling factor)\n\n', det3D);
    
    % Create unit cube vertices
    unitCubeVertices = [0, 1, 1, 0, 0, 1, 1, 0;
                       0, 0, 1, 1, 0, 0, 1, 1;
                       0, 0, 0, 0, 1, 1, 1, 1];
    
    % Apply transformation
    transformedCubeVertices = transform3D * unitCubeVertices;
    
    % Visualise both
    figure('Position', [100, 100, 1200, 500]);
    
    % Original cube
    subplot(1, 2, 1);
    plotCube(unitCubeVertices, [0.7, 0.9, 1.0]);
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$z$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Unit Cube (Volume = 1)', 'Interpreter', 'latex', ...
          'FontSize', 13);
    axis equal;
    grid on;
    view(45, 30);
    set(gca, 'FontSize', 11);
    
    % Transformed parallelepiped
    subplot(1, 2, 2);
    plotCube(transformedCubeVertices, [1.0, 0.9, 0.7]);
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$z$', 'Interpreter', 'latex', 'FontSize', 12);
    titleText = sprintf('Transformed Parallelepiped (Volume = %.2f)', ...
                       abs(det3D));
    title(titleText, 'Interpreter', 'latex', 'FontSize', 13);
    axis equal;
    grid on;
    view(45, 30);
    set(gca, 'FontSize', 11);
    
    fprintf('Visualisation created: 3*D volume scaling demonstration\n');
    fprintf('Volume of transformed region / Volume of original = %.4f\n', ...
            abs(det3D));
    fprintf('This equals |det(A)| as predicted by theory\n\n');
end

function plotCube(vertices, faceColour)
    % Helper function to plot cube/parallelepiped
    
    % Define faces (each row specifies vertex indices for one face)
    faces = [1, 2, 6, 5;  % bottom
             2, 3, 7, 6;  % right
             3, 4, 8, 7;  % top
             4, 1, 5, 8;  % left
             1, 2, 3, 4;  % front
             5, 6, 7, 8]; % back
    
    % Plot each face
    for faceIdx = 1:size(faces, 1)
        faceVertices = vertices(:, faces(faceIdx, :));
        patch(faceVertices(1, :), faceVertices(2, :), faceVertices(3, :), ...
              faceColour, 'EdgeColor', 'b', 'LineWidth', 1.5, ...
              'FaceAlpha', 0.7);
        hold on;
    end
    
    hold off;
end

function demonstrateInvertibilityRelation()
    % Demonstrate relationship between determinant and invertibility
    
    fprintf('Part 5: Determinant and Matrix Invertibility\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Invertible matrix
    invertibleMatrix = [2, 1, 0; 0, 3, 1; 1, 0, 2];
    detInvertible = det(invertibleMatrix);
    
    fprintf('Invertible Matrix:\n');
    disp(invertibleMatrix);
    fprintf('Determinant = %.6f (non-zero → matrix is invertible)\n', ...
            detInvertible);
    
    % Compute inverse
    inverseMatrix = inv(invertibleMatrix);
    fprintf('\nInverse Matrix:\n');
    disp(inverseMatrix);
    
    % Verify: det(A^-1) = 1/det(A)
    detInverse = det(inverseMatrix);
    fprintf('det(A^{-1}) = %.6f\n', detInverse);
    fprintf('1/det(A) = %.6f\n', 1/detInvertible);
    fprintf('Difference: %.10e\n\n', abs(detInverse - 1/detInvertible));
    
    % Verify: A * A^-1 = I
    identityCheck = invertibleMatrix * inverseMatrix;
    identityError = norm(identityCheck - eye(size(invertibleMatrix)), 'fro');
    fprintf('||A·A^{-1} - I||_F = %.10e\n\n', identityError);
    
    % Singular matrix
    singularMatrix = [1, 2, 3; 2, 4, 6; 1, 1, 2];
    detSingular = det(singularMatrix);
    
    fprintf('Singular Matrix (third row ≠ linear combination of first two):\n');
    disp(singularMatrix);
    fprintf('Determinant = %.10e (≈ 0 → matrix is singular)\n', detSingular);
    fprintf('Rank = %d (full rank would be %d)\n', ...
            rank(singularMatrix), size(singularMatrix, 1));
    fprintf('Matrix is NOT invertible\n');
end
