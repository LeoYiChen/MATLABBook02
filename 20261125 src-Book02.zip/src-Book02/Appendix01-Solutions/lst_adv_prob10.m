%% lst_adv_prob10.m
% Suspension bridge cable analysis
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob10
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem10.m
%  Integrated Challenge: Suspension Bridge Cable Analysis
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% ============================================================
%  PART (a): Root-Finding for Parameter a
%  ============================================================
bridgeSpan   = 200;   % m (total)
towerHeight  = 50;    % m
halfSpan     = bridgeSpan / 2;

catenaryEquation = @(a) a .* cosh(halfSpan ./ a) - a - towerHeight;
parameterA = fzero(catenaryEquation, 100);

fprintf('=== Part (a): Root-Finding ===\n');
fprintf('  Cable parameter a = %.6f m\n', parameterA);
fprintf('  Verification: y(100) = %.6f m (target: 50)\n', ...
    parameterA * cosh(halfSpan/parameterA) - parameterA);

%% ============================================================
%  PART (b): Cable Length via Numerical Integration
%  ============================================================
arcLengthIntegrand = @(x) cosh(x / parameterA);
halfCableLength = integral(arcLengthIntegrand, 0, halfSpan);
totalCableLength = 2 * halfCableLength;

% Analytical: L = 2*a*sinh(halfSpan/a)
analyticalLength = 2 * parameterA * sinh(halfSpan / parameterA);

fprintf('\n=== Part (b): Cable Length ===\n');
fprintf('  Numerical length  = %.6f m\n', totalCableLength);
fprintf('  Analytical length = %.6f m\n', analyticalLength);
fprintf('  Difference        = %.2e m\n', ...
    abs(totalCableLength - analyticalLength));

%% ============================================================
%  PART (c): Slope at Towers
%  ============================================================
slopeAnalytical = sinh(halfSpan / parameterA);
angleAtTower = atan(slopeAnalytical) * 180 / pi;

% Central difference verification
deltaX = 0.001;
cableShape = @(x) parameterA * cosh(x/parameterA) - parameterA;
slopeNumerical = (cableShape(halfSpan + deltaX) ...
                  - cableShape(halfSpan - deltaX)) / (2*deltaX);

fprintf('\n=== Part (c): Slope at Towers ===\n');
fprintf('  Analytical slope  = %.6f\n', slopeAnalytical);
fprintf('  Numerical slope   = %.6f\n', slopeNumerical);
fprintf('  Angle at tower    = %.4f degrees\n', angleAtTower);

%% ============================================================
%  PART (d): Cable Dynamics Under Wind Loading
%  ============================================================
dampingRatio    = 0.05;
naturalFreqWn   = 0.5;   % rad/s
windForce = @(t) 10 * sin(0.3 * t);

dynamicsODE = @(t, state) [state(2); ...
    windForce(t) - 2*dampingRatio*naturalFreqWn*state(2) ...
    - naturalFreqWn^2*state(1)];

dynamicsTimeSpan = [0 200];
initialDynamicsState = [0; 0];
dynamicsOptions = odeset('RelTol', 1e-8, 'AbsTol', 1e-10);

[timeDyn, stateDyn] = ode45(dynamicsODE, dynamicsTimeSpan, ...
    initialDynamicsState, dynamicsOptions);

displacementDyn = stateDyn(:, 1);
maxDisplacement = max(abs(displacementDyn));

fprintf('\n=== Part (d): Dynamic Response ===\n');
fprintf('  Max displacement  = %.6f m\n', maxDisplacement);
fprintf('  Forcing frequency = 0.3 rad/s\n');
fprintf('  Frequency ratio   = %.4f\n', 0.3/naturalFreqWn);

%% ============================================================
%  PART (e): Eigenvalue Analysis (Discretised Cable)
%  ============================================================
numSegments = 5;
segmentLength = bridgeSpan / (numSegments + 1);
cableTension = 1e6;    % N (assumed)
cableMassPerLength = 100; % kg/m

% Tridiagonal stiffness and mass matrices
stiffnessCoeff = cableTension / segmentLength;
massCoeff = cableMassPerLength * segmentLength;

stiffnessCable = stiffnessCoeff * ...
    (2*eye(numSegments) - diag(ones(numSegments-1,1),1) ...
     - diag(ones(numSegments-1,1),-1));
massCable = massCoeff * eye(numSegments);

[cableModes, cableEigenvalues] = eig(stiffnessCable, massCable);
cableOmega = sqrt(diag(cableEigenvalues));
[cableOmega, sortIdx] = sort(cableOmega);
cableModes = cableModes(:, sortIdx);

fprintf('\n=== Part (e): Eigenvalue Analysis ===\n');
for modeIdx = 1:numSegments
    fprintf('  Mode %d: omega = %.4f rad/s, f = %.4f Hz\n', ...
        modeIdx, cableOmega(modeIdx), ...
        cableOmega(modeIdx)/(2*pi));
end

%% ============================================================
%  PART (f): Optimise Cable Pre-Tension
%  ============================================================
tensionObjective = @(preTension) simulateMaxDisplacement( ...
    preTension, dampingRatio, windForce, dynamicsTimeSpan);

optimalTension = fminbnd(tensionObjective, 1e4, 1e7);
optimalMaxDisp = tensionObjective(optimalTension);

fprintf('\n=== Part (f): Optimal Pre-Tension ===\n');
fprintf('  Optimal tension   = %.2f N\n', optimalTension);
fprintf('  Min max-disp      = %.6f m\n', optimalMaxDisp);

%% ============================================================
%  PART (g): Polynomial Fit to Cable Shape
%  ============================================================
xDiscrete = linspace(-halfSpan, halfSpan, 21);
yDiscrete = parameterA * cosh(xDiscrete / parameterA) ...
            - parameterA;

polyDegree = 4;
cablePolyCoeffs = polyfit(xDiscrete, yDiscrete, polyDegree);
xFine = linspace(-halfSpan, halfSpan, 500);
yPolyFit = polyval(cablePolyCoeffs, xFine);
yCatenaryFine = parameterA * cosh(xFine / parameterA) ...
                - parameterA;
fitRMSE = sqrt(mean((yPolyFit - yCatenaryFine).^2));

fprintf('\n=== Part (g): Polynomial Fit ===\n');
fprintf('  Degree = %d polynomial\n', polyDegree);
fprintf('  RMSE   = %.6f m\n', fitRMSE);

%% ============================================================
%  PART (h): Statistical Uncertainty Analysis
%  ============================================================
rng(42);
numTrials = 10000;
nominalE  = 200e9;    % Pa (steel)
uncertaintyPercent = 5;
sampledE = nominalE * (1 + (uncertaintyPercent/100) * ...
           randn(numTrials, 1));

% a is proportional to sqrt(E) for simplicity
sampledA = parameterA * sqrt(sampledE / nominalE);
meanA = mean(sampledA);
stdA  = std(sampledA);

fprintf('\n=== Part (h): Uncertainty Analysis ===\n');
fprintf('  Nominal a     = %.4f m\n', parameterA);
fprintf('  Mean a        = %.4f m\n', meanA);
fprintf('  Std dev of a  = %.4f m\n', stdA);
fprintf('  CoV           = %.4f %%\n', 100*stdA/meanA);

%% ============================================================
%  VISUALISATION
%  ============================================================
figMain = figure('Position', [50 50 1400 900]);

subplot(2,3,1);
plot(xFine, yCatenaryFine, 'b-', 'LineWidth', 1.5);
xlabel('$x$ (m)', 'Interpreter', 'latex');
ylabel('$y$ (m)', 'Interpreter', 'latex');
title('(a) Catenary Cable Shape', 'Interpreter', 'latex');
grid on;

subplot(2,3,2);
plot(timeDyn, displacementDyn, 'b-', 'LineWidth', 1);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Displacement (m)', 'Interpreter', 'latex');
title('(d) Dynamic Wind Response', 'Interpreter', 'latex');
grid on;

subplot(2,3,3);
nodePlot = linspace(0, 1, numSegments);
for modeIdx = 1:min(3, numSegments)
    plot(nodePlot, cableModes(:, modeIdx), '-o', ...
         'LineWidth', 1.3); hold on;
end
xlabel('Normalised position', 'Interpreter', 'latex');
ylabel('Mode amplitude', 'Interpreter', 'latex');
title('(e) First Three Vibration Modes', ...
      'Interpreter', 'latex');
legend({'Mode 1','Mode 2','Mode 3'}, 'Interpreter', 'latex');
grid on;

subplot(2,3,4);
plot(xFine, yCatenaryFine, 'b-', 'LineWidth', 1.5); hold on;
plot(xFine, yPolyFit, 'r-', 'LineWidth', 1.2);
plot(xDiscrete, yDiscrete, 'ko', 'MarkerSize', 6);
xlabel('$x$ (m)', 'Interpreter', 'latex');
ylabel('$y$ (m)', 'Interpreter', 'latex');
title('(g) Polynomial Fit', 'Interpreter', 'latex');
legend({'Catenary', 'Degree-4 poly', 'Data'}, ...
       'Interpreter', 'latex');
grid on;

subplot(2,3,5);
histogram(sampledA, 40, 'Normalization', 'pdf', ...
    'FaceColor', [0.5 0.7 1]);
xlabel('Cable parameter $a$ (m)', 'Interpreter', 'latex');
ylabel('PDF', 'Interpreter', 'latex');
title('(h) Uncertainty in $a$', 'Interpreter', 'latex');
grid on;

subplot(2,3,6);
tensionTest = linspace(1e4, 1e7, 50);
dispTest = arrayfun(tensionObjective, tensionTest);
plot(tensionTest/1e6, dispTest, 'b-', 'LineWidth', 1.3); hold on;
plot(optimalTension/1e6, optimalMaxDisp, 'r*', ...
     'MarkerSize', 12, 'LineWidth', 2);
xlabel('Pre-tension (MN)', 'Interpreter', 'latex');
ylabel('Max displacement (m)', 'Interpreter', 'latex');
title('(f) Tension Optimisation', 'Interpreter', 'latex');
grid on;

savefig(figMain, 'Problem10_SuspensionBridge.fig');
exportgraphics(figMain, 'Problem10_SuspensionBridge.eps', ...
               'ContentType', 'vector');
exportgraphics(figMain, 'Problem10_SuspensionBridge.jpg', ...
               'Resolution', 300);

%% -- Animation (MP4 Video) --
videoWriter = VideoWriter('Problem10_SuspensionBridge.mp4', ...
                          'MPEG-4');
videoWriter.FrameRate = 30;
videoWriter.Quality   = 95;
open(videoWriter);
figAnim = figure('Position', [100 100 900 400]);

animTimeIndices = round(linspace(1, numel(timeDyn), 300));
for frameIdx = 1:numel(animTimeIndices)
    idx = animTimeIndices(frameIdx);
    clf;
    currentDisp = displacementDyn(idx);
    yAnimated = yCatenaryFine + currentDisp * ...
        sin(pi * (xFine + halfSpan) / bridgeSpan);
    plot(xFine, yCatenaryFine, 'b-', 'LineWidth', 1); hold on;
    plot(xFine, yAnimated, 'r-', 'LineWidth', 2);
    ylim([-5 65]);
    xlabel('$x$ (m)', 'Interpreter', 'latex');
    ylabel('$y$ (m)', 'Interpreter', 'latex');
    title(sprintf('Cable Dynamics $t = %.1f$ s', ...
          timeDyn(idx)), 'Interpreter', 'latex');
    legend({'Static', 'Dynamic'}, 'Interpreter', 'latex');
    grid on;
    drawnow;
    writeVideo(videoWriter, getframe(figAnim));
end
close(videoWriter);
close(figAnim);

fprintf('\n-- Problem 10 Complete --\n');

%% ============================================================
%  LOCAL FUNCTION
%  ============================================================
function maxDisp = simulateMaxDisplacement(preTension, ...
    dampingRatio, windForce, timeSpan)
    % Compute natural frequency from pre-tension
    % (simplified model: omega_n proportional to sqrt(T))
    cableMass = 100 * 200;  % mass_per_length * span
    omegaN = sqrt(preTension / cableMass);
    odeFunc = @(t, s) [s(2); ...
        windForce(t) - 2*dampingRatio*omegaN*s(2) ...
        - omegaN^2*s(1)];
    opts = odeset('RelTol', 1e-6);
    [~, stateOut] = ode45(odeFunc, timeSpan, [0;0], opts);
    maxDisp = max(abs(stateOut(:,1)));
end
% Computational Complexity:
% This integrated problem combines multiple sub-routines.
% Root-finding (part a): O(k) with k~50 iterations.
% Integration (part b): O(n) adaptive quadrature evaluations.
% Differentiation (part c): O(1) for central difference.
% ODE solving (part d): O(N_steps * 2) per Runge-Kutta step.
% Eigenvalue analysis (part e): O(m^3) for m segments.
% Optimisation (part f): O(k * ODE_cost) per fminbnd call.
% Polynomial fitting (part g): O(n * d^2).
% Monte Carlo (part h): O(numTrials).  Overall, the
% optimisation loop dominates at O(k * N_steps).
