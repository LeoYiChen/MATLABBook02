%% chapter_AIforMechatronics_problem09_code.m
% Uncertainty quantification in neural network predictions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem09_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 9: Uncertainty Quantification in Neural Network Predictions
% Author: Dr Yi Chen
% Purpose: Implement and compare uncertainty quantification methods
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox, Statistics Toolbox
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Generate synthetic dataset with heteroscedastic noise
fprintf('=== Uncertainty Quantification in Neural Networks ===\n\n');
fprintf('Step 1: Generating dataset with heteroscedastic noise...\n');

% Input range
numSamples = 1000;
xMin = -5;
xMax = 5;
XData = (xMax - xMin) * rand(numSamples, 1) + xMin;

% True function: non-linear with varying noise
trueMean = @(x) sin(x) .* exp(-x.^2 / 10) + 0.5 * x;

% Heteroscedastic noise: variance depends on input location
noiseStd = @(x) 0.05 + 0.15 * abs(x) / max(abs(x));

% Generate noisy observations
YData = zeros(numSamples, 1);
trueStd = zeros(numSamples, 1);

for i = 1:numSamples
    YData(i) = trueMean(XData(i)) + noiseStd(XData(i)) * randn();
    trueStd(i) = noiseStd(XData(i));
end

fprintf('  Generated %d samples\n', numSamples);
fprintf('  Input range: [%.1f, %.1f]\n', xMin, xMax);
fprintf('  Noise type: Heteroscedastic (input-dependent variance)\n');

%% Step 2: Split dataset
fprintf('\nStep 2: Splitting dataset...\n');

% Random shuffle
randIdx = randperm(numSamples);
XData = XData(randIdx);
YData = YData(randIdx);
trueStd = trueStd(randIdx);

% 70% train, 15% validation, 15% test
trainRatio = 0.70;
valRatio = 0.15;

trainIdx = 1:floor(trainRatio * numSamples);
valIdx = (max(trainIdx) + 1):floor((trainRatio + valRatio) * numSamples);
testIdx = (max(valIdx) + 1):numSamples;

XTrain = XData(trainIdx);
YTrain = YData(trainIdx);

XVal = XData(valIdx);
YVal = YData(valIdx);

XTest = XData(testIdx);
YTest = YData(testIdx);
trueStdTest = trueStd(testIdx);

fprintf('  Training samples: %d\n', length(trainIdx));
fprintf('  Validation samples: %d\n', length(valIdx));
fprintf('  Test samples: %d\n', length(testIdx));

%% Step 3: Implement standard deterministic network
fprintf('\nStep 3: Implementing standard deterministic network...\n');

% Network architecture
hiddenUnits = [50, 50];

layersStandard = [
    featureInputLayer(1, 'Name', 'input')
    fullyConnectedLayer(hiddenUnits(1), 'Name', 'fc1')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(hiddenUnits(2), 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    fullyConnectedLayer(1, 'Name', 'output')
    regressionLayer('Name', 'loss')];

fprintf('  Architecture: [%d, %d] hidden units\n', hiddenUnits);

%% Step 4: Train standard network
fprintf('\nStep 4: Training standard deterministic network...\n');

optionsStandard = trainingOptions('adam', ...
    'MaxEpochs', 200, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.01, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 100, ...
    'LearnRateDropFactor', 0.5, ...
    'ValidationData', {XVal, YVal}, ...
    'ValidationFrequency', 30, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
netStandard = trainNetwork(XTrain, YTrain, layersStandard, optionsStandard);
trainingTimeStandard = toc;

% Test predictions
YPredStandard = predict(netStandard, XTest);
rmseStandard = sqrt(mean((YTest - YPredStandard).^2));

fprintf('  Training completed in %.2f seconds\n', trainingTimeStandard);
fprintf('  Test RMSE: %.4f\n', rmseStandard);

%% Step 5: Implement network with MC Dropout
fprintf('\nStep 5: Implementing MC Dropout network...\n');

% Network with dropout layers
dropoutProb = 0.2;

layersDropout = [
    featureInputLayer(1, 'Name', 'input')
    fullyConnectedLayer(hiddenUnits(1), 'Name', 'fc1')
    reluLayer('Name', 'relu1')
    dropoutLayer(dropoutProb, 'Name', 'dropout1')
    fullyConnectedLayer(hiddenUnits(2), 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    dropoutLayer(dropoutProb, 'Name', 'dropout2')
    fullyConnectedLayer(1, 'Name', 'output')
    regressionLayer('Name', 'loss')];

fprintf('  Dropout probability: %.2f\n', dropoutProb);

%% Step 6: Train MC Dropout network
fprintf('\nStep 6: Training MC Dropout network...\n');

optionsDropout = trainingOptions('adam', ...
    'MaxEpochs', 200, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.01, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropPeriod', 100, ...
    'LearnRateDropFactor', 0.5, ...
    'ValidationData', {XVal, YVal}, ...
    'ValidationFrequency', 30, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
netDropout = trainNetwork(XTrain, YTrain, layersDropout, optionsDropout);
trainingTimeDropout = toc;

fprintf('  Training completed in %.2f seconds\n', trainingTimeDropout);

%% Step 7: Perform MC Dropout inference
fprintf('\nStep 7: Performing MC Dropout inference...\n');

numMCsamples = 100;
MCpredictions = zeros(length(testIdx), numMCsamples);

% Multiple forward passes with dropout enabled
for mcIdx = 1:numMCsamples
    MCpredictions(:, mcIdx) = predict(netDropout, XTest);
end

% Compute predictive mean and uncertainty
YPredMC = mean(MCpredictions, 2);
YStdMC = std(MCpredictions, 0, 2); % Epistemic uncertainty

rmseMC = sqrt(mean((YTest - YPredMC).^2));

fprintf('  MC samples: %d\n', numMCsamples);
fprintf('  Test RMSE: %.4f\n', rmseMC);
fprintf('  Mean epistemic uncertainty: %.4f\n', mean(YStdMC));

%% Step 8: Implement deep ensemble
fprintf('\nStep 8: Implementing deep ensemble...\n');

numEnsembleMembers = 5;
ensembleNets = cell(numEnsembleMembers, 1);

fprintf('  Training %d ensemble members...\n', numEnsembleMembers);

for ensIdx = 1:numEnsembleMembers
    fprintf('    Training member %d/%d...', ensIdx, numEnsembleMembers);
    
    % Each member has same architecture but different initialisation
    layersEnsemble = [
        featureInputLayer(1, 'Name', 'input')
        fullyConnectedLayer(hiddenUnits(1), 'Name', 'fc1')
        reluLayer('Name', 'relu1')
        fullyConnectedLayer(hiddenUnits(2), 'Name', 'fc2')
        reluLayer('Name', 'relu2')
        fullyConnectedLayer(1, 'Name', 'output')
        regressionLayer('Name', 'loss')];
    
    optionsEnsemble = trainingOptions('adam', ...
        'MaxEpochs', 200, ...
        'MiniBatchSize', 32, ...
        'InitialLearnRate', 0.01, ...
        'LearnRateSchedule', 'piecewise', ...
        'LearnRateDropPeriod', 100, ...
        'LearnRateDropFactor', 0.5, ...
        'Verbose', false, ...
        'Plots', 'none');
    
    ensembleNets{ensIdx} = trainNetwork(XTrain, YTrain, ...
        layersEnsemble, optionsEnsemble);
    
    fprintf(' Done\n');
end

fprintf('  All ensemble members trained\n');

%% Step 9: Perform ensemble inference
fprintf('\nStep 9: Performing ensemble inference...\n');

ensemblePredictions = zeros(length(testIdx), numEnsembleMembers);

for ensIdx = 1:numEnsembleMembers
    ensemblePredictions(:, ensIdx) = predict(ensembleNets{ensIdx}, XTest);
end

% Compute predictive mean and uncertainty
YPredEnsemble = mean(ensemblePredictions, 2);
YStdEnsemble = std(ensemblePredictions, 0, 2);

rmseEnsemble = sqrt(mean((YTest - YPredEnsemble).^2));

fprintf('  Ensemble size: %d\n', numEnsembleMembers);
fprintf('  Test RMSE: %.4f\n', rmseEnsemble);
fprintf('  Mean epistemic uncertainty: %.4f\n', mean(YStdEnsemble));

%% Step 10: Uncertainty calibration analysis
fprintf('\nStep 10: Analysing uncertainty calibration...\n');

% For MC Dropout: check if true values fall within predicted intervals
% 95% confidence interval
confidenceLevel = 0.95;
zScore = norminv((1 + confidenceLevel) / 2); % ~1.96

% MC Dropout calibration
lowerBoundMC = YPredMC - zScore * YStdMC;
upperBoundMC = YPredMC + zScore * YStdMC;
coverageMC = mean((YTest >= lowerBoundMC) & (YTest <= upperBoundMC));

% Ensemble calibration
lowerBoundEns = YPredEnsemble - zScore * YStdEnsemble;
upperBoundEns = YPredEnsemble + zScore * YStdEnsemble;
coverageEns = mean((YTest >= lowerBoundEns) & (YTest <= upperBoundEns));

fprintf('  MC Dropout 95%% coverage: %.2f%% (ideal: 95%%)\n', coverageMC * 100);
fprintf('  Ensemble 95%% coverage: %.2f%% (ideal: 95%%)\n', coverageEns * 100);

% Uncertainty quality: correlation between uncertainty and error
absErrorMC = abs(YTest - YPredMC);
absErrorEns = abs(YTest - YPredEnsemble);

corrMC = corr(YStdMC, absErrorMC);
corrEns = corr(YStdEnsemble, absErrorEns);

fprintf('  MC Dropout uncertainty-error correlation: %.3f\n', corrMC);
fprintf('  Ensemble uncertainty-error correlation: %.3f\n', corrEns);

%% Step 11: Out-of-distribution detection
fprintf('\nStep 11: Testing out-of-distribution detection...\n');

% Generate OOD samples (outside training range)
XOod = [linspace(-10, xMin-1, 50)'; linspace(xMax+1, 10, 50)'];
numOod = length(XOod);

% MC Dropout on OOD
MCpredictionsOod = zeros(numOod, numMCsamples);
for mcIdx = 1:numMCsamples
    MCpredictionsOod(:, mcIdx) = predict(netDropout, XOod);
end
YStdMC_ood = std(MCpredictionsOod, 0, 2);

% Ensemble on OOD
ensemblePredictionsOod = zeros(numOod, numEnsembleMembers);
for ensIdx = 1:numEnsembleMembers
    ensemblePredictionsOod(:, ensIdx) = predict(ensembleNets{ensIdx}, XOod);
end
YStdEnsemble_ood = std(ensemblePredictionsOod, 0, 2);

% Compare in-distribution vs OOD uncertainty
meanUncertaintyMC_id = mean(YStdMC);
meanUncertaintyMC_ood = mean(YStdMC_ood);

meanUncertaintyEns_id = mean(YStdEnsemble);
meanUncertaintyEns_ood = mean(YStdEnsemble_ood);

fprintf('  MC Dropout: In-dist=%.4f, OOD=%.4f (ratio=%.2f)\n', ...
    meanUncertaintyMC_id, meanUncertaintyMC_ood, ...
    meanUncertaintyMC_ood / meanUncertaintyMC_id);
fprintf('  Ensemble: In-dist=%.4f, OOD=%.4f (ratio=%.2f)\n', ...
    meanUncertaintyEns_id, meanUncertaintyEns_ood, ...
    meanUncertaintyEns_ood / meanUncertaintyEns_id);

%% Step 12: Visualisation
fprintf('\nStep 12: Generating visualisations...\n');

figure('Name', 'Uncertainty Quantification Analysis', ...
    'Position', [100, 100, 1400, 900]);

% Ground truth function with data
subplot(2, 3, 1);
xPlot = linspace(xMin, xMax, 200)';
yTruePlot = trueMean(xPlot);
scatter(XTrain, YTrain, 20, 'k', 'filled', 'MarkerFaceAlpha', 0.3);
hold on;
plot(xPlot, yTruePlot, 'r-', 'LineWidth', 2, 'DisplayName', 'True Function');
xlabel('Input $x$', 'Interpreter', 'latex');
ylabel('Output $y$', 'Interpreter', 'latex');
title('Training Data', 'Interpreter', 'latex');
legend('Interpreter', 'latex');
grid on;
hold off;

% Standard network predictions
subplot(2, 3, 2);
[XTestSorted, sortIdx] = sort(XTest);
YTestSorted = YTest(sortIdx);
YPredStandardSorted = YPredStandard(sortIdx);

scatter(XTest, YTest, 30, 'k', 'filled', 'MarkerFaceAlpha', 0.5, ...
    'DisplayName', 'Test Data');
hold on;
plot(XTestSorted, YPredStandardSorted, 'b-', 'LineWidth', 2, ...
    'DisplayName', 'Prediction');
xlabel('Input $x$', 'Interpreter', 'latex');
ylabel('Output $y$', 'Interpreter', 'latex');
title('Standard Network (No Uncertainty)', 'Interpreter', 'latex');
legend('Interpreter', 'latex');
grid on;
hold off;

% MC Dropout predictions with uncertainty
subplot(2, 3, 3);
YPredMCSorted = YPredMC(sortIdx);
YStdMCSorted = YStdMC(sortIdx);

scatter(XTest, YTest, 30, 'k', 'filled', 'MarkerFaceAlpha', 0.5, ...
    'DisplayName', 'Test Data');
hold on;
plot(XTestSorted, YPredMCSorted, 'b-', 'LineWidth', 2, ...
    'DisplayName', 'MC Prediction');
fill([XTestSorted; flipud(XTestSorted)], ...
    [YPredMCSorted - 2*YStdMCSorted; flipud(YPredMCSorted + 2*YStdMCSorted)], ...
    'b', 'FaceAlpha', 0.2, 'EdgeColor', 'none', ...
    'DisplayName', '95\% Confidence');
xlabel('Input $x$', 'Interpreter', 'latex');
ylabel('Output $y$', 'Interpreter', 'latex');
title('MC Dropout (with Uncertainty)', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Ensemble predictions with uncertainty
subplot(2, 3, 4);
YPredEnsSorted = YPredEnsemble(sortIdx);
YStdEnsSorted = YStdEnsemble(sortIdx);

scatter(XTest, YTest, 30, 'k', 'filled', 'MarkerFaceAlpha', 0.5, ...
    'DisplayName', 'Test Data');
hold on;
plot(XTestSorted, YPredEnsSorted, 'g-', 'LineWidth', 2, ...
    'DisplayName', 'Ensemble Prediction');
fill([XTestSorted; flipud(XTestSorted)], ...
    [YPredEnsSorted - 2*YStdEnsSorted; flipud(YPredEnsSorted + 2*YStdEnsSorted)], ...
    'g', 'FaceAlpha', 0.2, 'EdgeColor', 'none', ...
    'DisplayName', '95\% Confidence');
xlabel('Input $x$', 'Interpreter', 'latex');
ylabel('Output $y$', 'Interpreter', 'latex');
title('Deep Ensemble (with Uncertainty)', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

% Uncertainty vs error scatter
subplot(2, 3, 5);
scatter(YStdMC, absErrorMC, 50, 'b', 'filled', 'MarkerFaceAlpha', 0.5, ...
    'DisplayName', 'MC Dropout');
hold on;
scatter(YStdEnsemble, absErrorEns, 50, 'g', 'filled', 'MarkerFaceAlpha', 0.5, ...
    'DisplayName', 'Ensemble');
xlabel('Predicted Uncertainty', 'Interpreter', 'latex');
ylabel('Absolute Error', 'Interpreter', 'latex');
title('Uncertainty Quality', 'Interpreter', 'latex');
legend('Interpreter', 'latex');
grid on;
hold off;

% OOD detection
subplot(2, 3, 6);
xExtended = [-10; XTest; 10];
uncertaintyMC_extended = [YStdMC_ood(1:50); YStdMC; YStdMC_ood(51:end)];
uncertaintyEns_extended = [YStdEnsemble_ood(1:50); YStdEnsemble; YStdEnsemble_ood(51:end)];

[xExtSorted, sortIdxExt] = sort(xExtended);
uncMCSorted = uncertaintyMC_extended(sortIdxExt);
uncEnsSorted = uncertaintyEns_extended(sortIdxExt);

plot(xExtSorted, uncMCSorted, 'b-', 'LineWidth', 2, 'DisplayName', 'MC Dropout');
hold on;
plot(xExtSorted, uncEnsSorted, 'g-', 'LineWidth', 2, 'DisplayName', 'Ensemble');
xline(xMin, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Training Range');
xline(xMax, 'r-', 'LineWidth', 1.5, 'HandleVisibility', 'off');
xlabel('Input $x$', 'Interpreter', 'latex');
ylabel('Predicted Uncertainty', 'Interpreter', 'latex');
title('Out-of-Distribution Detection', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
hold off;

suptitle('Uncertainty Quantification in Neural Networks', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 9 completed successfully.\n');
