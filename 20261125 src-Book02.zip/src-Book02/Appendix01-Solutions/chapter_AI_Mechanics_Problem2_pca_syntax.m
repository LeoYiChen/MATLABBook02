%% chapter_AI_Mechanics_Problem2_pca_syntax.m
% PCA using economy SVD syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem2_pca_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Perform economy SVD on snapshot matrix
% X: (numSpatialPoints   numSnapshots)
[U, S, V] = svd(snapshotMatrix, 'econ');

% Extract singular values
singularValues = diag(S);

% Compute cumulative energy
cumulativeEnergy = cumsum(singularValues.^2) / sum(singularValues.^2);

% Find number of modes for 95% energy
k95 = find(cumulativeEnergy >= 0.95, 1, 'first');

% Temporal coefficients (modal amplitudes)
temporalCoefficients = V * S;  % Or simply: X' * U

% Reconstruct flow field using k modes
kModes = 50;
reconstructed = U(:, 1:kModes) * S(1:kModes, 1:kModes) * V(:, 1:kModes)';
