%% lst_C01_Lab02.m
% Basic neural network classification using Fisher's iris dataset
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : lst:C01_Lab02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% C0201_demo_basicneuralnetworkclassification.m
% Demonstrates basic neural network classification in MATLAB
% Using the classic Fisher's iris dataset
% Author: Dr Leo Chen
% Date: 2026-Feb-01

%% Load Fisher's iris dataset
load fisheriris.mat  % Contains 'meas' (features) and 'species' (labels)

% Dataset has 150 samples, 4 features, 3 classes
fprintf('Dataset loaded: %d samples, %d features, %d classes\n', ...
    size(meas,1), size(meas,2), length(unique(species)));

%% Prepare data for neural network
X = meas;  % Features: sepal length/width, petal length/width
species_unique = unique(species);

% Convert species to one-hot encoding (required for NN output)
T = zeros(length(species), length(species_unique));
for i = 1:length(species)
    T(i, strcmp(species(i), species_unique)) = 1;
end

%% Split data: 70% training, 30% testing
rng(42);  % Set random seed for reproducibility
idx = randperm(size(X, 1));
splitPoint = round(0.7 * length(idx));
trainInd = idx(1:splitPoint);
testInd = idx(splitPoint+1:end);

XTrain = X(trainInd, :);
TTrain = T(trainInd, :);
XTest = X(testInd, :);
TTest = T(testInd, :);

fprintf('Training samples: %d, Testing samples: %d\n', ...
    size(XTrain,1), size(XTest,1));

%% Create and configure neural network
hiddenSizes = [10 5];  % Two hidden layers: 10 neurons, then 5 neurons
net = patternnet(hiddenSizes);

% Configure training parameters
net.trainParam.showWindow = true;  % Show training GUI
net.trainParam.epochs = 100;  % Maximum epochs
net.trainParam.goal = 1e-5;  % Performance goal

% Configure data division
net.divideParam.trainRatio = 0.7;  % 70% for training
net.divideParam.valRatio = 0.15;  % 15% for validation
net.divideParam.testRatio = 0.15;  % 15% for testing

fprintf('\nNeural network architecture:\n');
fprintf('Input layer: %d neurons (features)\n', size(XTrain,2));
fprintf('Hidden layers: %s\n', mat2str(hiddenSizes));
fprintf('Output layer: %d neurons (classes)\n', length(species_unique));

%% Train the network
fprintf('\nTraining network... (this may take a minute)\n');
[net, tr] = train(net, XTrain', TTrain');

%% Evaluate on test set
YTest = net(XTest');
performance = perform(net, TTest', YTest);

% Convert from one-hot to class indices
[~, classTest] = max(TTest, [], 2);
[~, classPred] = max(YTest, [], 1);
classPred = classPred';

% Calculate accuracy
accuracy = sum(classTest == classPred) / length(classTest);

%% Display results
fprintf('\n=== Results ===\n');
fprintf('Network performance (cross-entropy): %.4f\n', performance);
fprintf('Classification accuracy: %.2f%%\n', accuracy*100);

%% Visualise results
% Confusion matrix
figure('Name', 'Confusion Matrix', 'Position', [100, 100, 600, 500]);
confusionchart(classTest, classPred);
title('Confusion Matrix for Iris Classification');

% Network architecture
figure('Name', 'Network Architecture', 'Position', [150, 150, 700, 500]);
view(net);
title('Neural Network Architecture');

% Feature importance from weights
firstLayerWeights = net.IW{1};  % Input weights
absWeights = mean(abs(firstLayerWeights), 1);  % Average absolute weight per feature

figure('Name', 'Feature Importance', 'Position', [200, 200, 600, 400]);
bar(absWeights);
title('Feature Importance Based on Neural Network Weights');
xlabel('Feature Index');
ylabel('Importance (Avg. Absolute Weight)');
xticks(1:4);
xticklabels({'Sepal Length', 'Sepal Width', 'Petal Length', 'Petal Width'});
grid on;

fprintf('\nLaboratory Exercise 2 completed successfully.\n');
fprintf('Key observations:\n');
fprintf('1. Neural networks learn nonlinear decision boundaries\n');
fprintf('2. Multiple hidden layers enable hierarchical feature learning\n');
fprintf('3. Weight magnitudes indicate feature importance\n');
