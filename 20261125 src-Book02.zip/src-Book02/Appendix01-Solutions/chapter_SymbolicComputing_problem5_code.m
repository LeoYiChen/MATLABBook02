%% chapter_SymbolicComputing_problem5_code.m
% Advanced circuit analysis with comprehensive symbolic methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_SymbolicComputing_problem5_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter_SymbolicComputing_Problem05.m
%
% Advanced Circuit Analysis with Symbolic Methods
%
% Author: Dr Yi Chen
% Institution: University Engineering Department
% Date: 2024
% Version: 1.0
% MATLAB Version: R2024a
%
% Description: Comprehensive electronic circuit analysis using symbolic
% computation for linear/nonlinear circuits and frequency response analysis

function advanced_circuit_analysis_system()
    %ADVANCED_CIRCUIT_ANALYSIS_SYSTEM Symbolic circuit analyser
    %   Comprehensive analysis of linear and nonlinear electronic circuits
    
    clear; clc;
    
    % Display system header
    fprintf('Advanced Circuit Analysis with Symbolic Methods\n');
    fprintf('===============================================\n\n');
    
    % Problem 1: Mixed-signal circuit with op-amps
    analyse_mixed_signal_circuit();
    
    % Problem 2: Nonlinear circuit with diodes and transistors
    analyse_nonlinear_circuit();
    
    % Problem 3: Filter design optimisation
    optimise_filter_design();
    
    % Problem 4: Power electronics converter analysis
    analyse_power_converter();
    
    % Advanced demonstrations
    demonstrate_advanced_circuit_techniques();
    
end

function analyse_mixed_signal_circuit()
    %ANALYSE_MIXED_SIGNAL_CIRCUIT Op-amp circuit symbolic analysis
    %   Analyses mixed-signal circuit with operational amplifiers
    
    fprintf('Problem 1: Mixed-Signal Circuit with Operational Amplifiers\n');
    fprintf('==========================================================\n');
    
    syms s R1 R2 R3 R4 C1 C2 real positive
    syms Vin Vout V1 V2 V3 real
    syms A_ol R_in R_out real positive  % Op-amp parameters
    
    fprintf('Mixed-Signal Circuit Configuration:\n');
    fprintf(' Input stage: Non-inverting amplifier with feedback\n');
    fprintf(' Filter stage: Active low-pass filter\n');
    fprintf(' Output stage: Unity-gain buffer\n\n');
    
    % Stage 1: Non-inverting amplifier
    fprintf('Stage 1: Non-inverting Amplifier Analysis\n');
    fprintf('--------------------\n');
    
    % Ideal op-amp assumptions
    fprintf('Ideal op-amp assumptions:\n');
    fprintf(' Infinite input impedance\n');
    fprintf(' Zero output impedance\n');
    fprintf(' Infinite open-loop gain\n');
    fprintf(' Zero input offset\n\n');
    
    % Voltage divider in feedback network
    beta_feedback = R1 / (R1 + R2);  % Feedback factor
    gain_noninv = 1 + R2/R1;         % Closed-loop gain
    
    fprintf('Feedback factor:   = R/(R + R) = %s\n', char(beta_feedback));
    fprintf('Closed-loop gain: A_cl = 1 + R/R = %s\n', char(gain_noninv));
    
    % Transfer function
    H1_s = gain_noninv;
    fprintf('Transfer function: H(s) = %s\n', char(H1_s));
    
    % Stage 2: Active low-pass filter (Sallen-Key topology)
    fprintf('\nStage 2: Active Low-Pass Filter (Sallen-Key)\n');
    fprintf('----------------------\n');
    
    % Sallen-Key transfer function derivation
    % Using nodal analysis at key nodes
    
    omega_0 = 1 / sqrt(R3 * R4 * C1 * C2);  % Natural frequency
    Q_factor = sqrt(R3 * R4 * C1 * C2) / (C1 * (R3 + R4));  % Quality factor
    
    fprintf('Natural frequency:   = 1/ (RRCC) = %s\n', char(omega_0));
    fprintf('Quality factor: Q =  (RRCC)/(C(R + R)) = %s\n', char(Q_factor));
    
    % Second-order low-pass transfer function
    H2_s = omega_0^2 / (s^2 + (omega_0/Q_factor)*s + omega_0^2);
    H2_s = simplify(H2_s);
    
    fprintf('Transfer function: H(s) = %s\n', char(H2_s));
    
    % Overall transfer function
    H_total = H1_s * H2_s;
    H_total = simplify(H_total);
    
    fprintf('\nOverall Transfer Function:\n');
    fprintf('H(s) = H(s)   H(s) = %s\n', char(H_total));
    
    % Frequency response analysis
    fprintf('\nFrequency Response Characteristics:\n');
    fprintf('DC Gain: |H(0)| = %s\n', char(abs(subs(H_total, s, 0))));
    fprintf('3-dB frequency:  dB     (for Q = 1/ 2)\n');
    fprintf('High-frequency roll-off: -40 dB/decade\n\n');
    
    % Sensitivity analysis
    perform_sensitivity_analysis(H_total, [R1, R2, R3, R4, C1, C2]);
    
end

function perform_sensitivity_analysis(transfer_function, parameters)
    %PERFORM_SENSITIVITY_ANALYSIS Symbolic sensitivity computation
    %   Computes parameter sensitivities for design optimisation
    
    fprintf('Sensitivity Analysis:\n');
    fprintf('----------\n');
    
    fprintf('Parameter sensitivities S_p^H = (p/H)(H/p):\n');
    
    for param_idx = 1:length(parameters)
        param = parameters(param_idx);
        
        % Compute sensitivity
        dH_dp = diff(transfer_function, param);
        sensitivity = (param / transfer_function) * dH_dp;
        sensitivity = simplify(sensitivity);
        
        fprintf('S_%s^H = %s\n', char(param), char(sensitivity));
    end
    
    fprintf('\nSensitivity interpretation:\n');
    fprintf(' |S_p^H| >> 1: High sensitivity to parameter p\n');
    fprintf(' |S_p^H| << 1: Low sensitivity to parameter p\n');
    fprintf(' Used for tolerance allocation and robust design\n\n');
end

function analyse_nonlinear_circuit()
    %ANALYSE_NONLINEAR_CIRCUIT Symbolic nonlinear circuit analysis
    %   Analyses circuits with diodes, transistors, and nonlinear elements
    
    fprintf('Problem 2: Nonlinear Circuit with Diodes and Transistors\n');
    fprintf('========================================================\n');
    
    syms V_D I_D V_T I_S real positive  % Diode parameters
    syms V_BE V_CE I_C I_B I_E beta_F real  % Transistor parameters
    syms R_B R_C R_E V_CC V_BB real positive  % Circuit parameters
    syms v_in v_out real  % Signal variables
    
    fprintf('Nonlinear Circuit Components:\n');
    fprintf(' PN junction diodes with exponential I-V characteristic\n');
    fprintf(' Bipolar junction transistors (BJT) in amplifier configuration\n');
    fprintf(' Nonlinear feedback networks\n\n');
    
    % Diode model
    fprintf('1. Diode Model Analysis:\n');
    fprintf('------------\n');
    
    % Shockley diode equation
    diode_current = I_S * (exp(V_D/V_T) - 1);
    
    fprintf('Shockley equation: I_D = I_S(e^{V_D/V_T} - 1)\n');
    fprintf('Where:\n');
    fprintf(' I_S = reverse saturation current\n');
    fprintf(' V_T = thermal voltage   26 mV at room temperature\n\n');
    
    % Small-signal model
    fprintf('Small-signal analysis:\n');
    
    % Dynamic resistance
    r_d = diff(V_D, I_D);  % This should be dV_D/dI_D
    r_d = V_T / (I_S * exp(V_D/V_T));  % Correct expression
    r_d = simplify(r_d);
    
    fprintf('Dynamic resistance: r_d = dV_D/dI_D = %s\n', char(r_d));
    
    % For forward-biased diode at operating point
    fprintf('At operating point I_D0: r_d = V_T/I_D0\n\n');
    
    % BJT amplifier analysis
    fprintf('2. BJT Amplifier Analysis:\n');
    fprintf('-------------\n');
    
    % Ebers-Moll model (simplified)
    fprintf('BJT Ebers-Moll relationships:\n');
    fprintf('I_C =  _F   I_B (active region)\n');
    fprintf('I_E = I_C + I_B = ( _F + 1)   I_B\n');
    fprintf('V_BE   0.7 V (silicon, forward-biased)\n\n');
    
    % DC bias analysis
    fprintf('DC Bias Analysis (Common-Emitter Configuration):\n');
    
    % Base circuit equation
    V_BE_eq = V_BB - I_B * R_B;
    fprintf('Base circuit: V_BE = V_BB - I_B   R_B\n');
    
    % Collector circuit equation  
    V_CE_eq = V_CC - I_C * R_C - I_E * R_E;
    fprintf('Collector circuit: V_CE = V_CC - I_C   R_C - I_E   R_E\n');
    
    % Substituting BJT relationships
    V_CE_bias = V_CC - beta_F * I_B * R_C - (beta_F + 1) * I_B * R_E;
    V_CE_bias = simplify(V_CE_bias);
    
    fprintf('With BJT model: V_CE = %s\n', char(V_CE_bias));
    
    % Small-signal analysis
    fprintf('\nSmall-Signal Analysis:\n');
    
    % Hybrid-  model parameters
    syms g_m r_pi r_o real positive
    
    g_m_expr = I_C / V_T;  % Transconductance
    r_pi_expr = beta_F / g_m_expr;  % Input resistance
    
    fprintf('Small-signal parameters:\n');
    fprintf('Transconductance: g_m = I_C/V_T = %s\n', char(g_m_expr));
    fprintf('Input resistance: r_  =  _F/g_m = %s\n', char(r_pi_expr));
    
    % Small-signal gain
    A_v_small = -g_m * (R_C * r_o) / (R_C + r_o);  % Voltage gain
    A_v_simplified = -g_m * R_C;  % Assuming r_o >> R_C
    
    fprintf('Voltage gain: A_v = -g_m   R_C || r_o   %s\n', char(A_v_simplified));
    
    % Operating point analysis
    fprintf('\nOperating Point Determination:\n');
    fprintf('Solve nonlinear system:\n');
    fprintf(' I_B = (V_BB - V_BE)/R_B\n');
    fprintf(' I_C =  _F   I_B\n');
    fprintf(' V_CE = V_CC - I_C(R_C + R_E/ _F)\n');
    fprintf('Typically requires iterative numerical solution\n\n');
    
    % Demonstrate numerical solution
    demonstrate_bjt_bias_solution();
end

function demonstrate_bjt_bias_solution()
    %DEMONSTRATE_BJT_BIAS_SOLUTION Numerical bias point calculation
    %   Shows numerical solution for BJT bias point
    
    fprintf('Numerical BJT Bias Point Calculation:\n');
    fprintf('------------------\n');
    
    % Circuit parameters
    V_CC_val = 12;      % Supply voltage (V)
    V_BB_val = 2;       % Base bias voltage (V) 
    R_B_val = 100e3;    % Base resistance ( )
    R_C_val = 2.2e3;    % Collector resistance ( )
    R_E_val = 1e3;      % Emitter resistance ( )
    beta_F_val = 100;   % Current gain
    V_BE_val = 0.7;     % Base-emitter voltage (V)
    V_T_val = 0.026;    % Thermal voltage (V)
    
    fprintf('Circuit parameters:\n');
    fprintf('V_CC = %.1f V, V_BB = %.1f V\n', V_CC_val, V_BB_val);
    fprintf('R_B = %.0f k , R_C = %.1f k , R_E = %.1f k \n', ...
           R_B_val/1e3, R_C_val/1e3, R_E_val/1e3);
    fprintf(' _F = %d, V_BE = %.1f V\n\n', beta_F_val, V_BE_val);
    
    % Solve for bias currents
    I_B_val = (V_BB_val - V_BE_val) / R_B_val;
    I_C_val = beta_F_val * I_B_val;
    I_E_val = (beta_F_val + 1) * I_B_val;
    
    % Solve for bias voltages
    V_CE_val = V_CC_val - I_C_val * R_C_val - I_E_val * R_E_val;
    V_E_val = I_E_val * R_E_val;
    V_C_val = V_CE_val + V_E_val;
    
    fprintf('Bias point solution:\n');
    fprintf('I_B = %.2f  A\n', I_B_val * 1e6);
    fprintf('I_C = %.2f mA\n', I_C_val * 1e3);
    fprintf('I_E = %.2f mA\n', I_E_val * 1e3);
    fprintf('V_CE = %.2f V\n', V_CE_val);
    fprintf('V_C = %.2f V\n', V_C_val);
    fprintf('V_E = %.2f V\n', V_E_val);
    
    % Small-signal parameters
    g_m_val = I_C_val / V_T_val;
    r_pi_val = beta_F_val / g_m_val;
    A_v_val = -g_m_val * R_C_val;
    
    fprintf('\nSmall-signal parameters:\n');
    fprintf('g_m = %.1f mS\n', g_m_val * 1e3);
    fprintf('r_  = %.1f k \n', r_pi_val / 1e3);
    fprintf('A_v = %.1f\n', A_v_val);
    
    % Verify operating region
    if V_CE_val > 0.2 && V_BE_val > 0.5
        fprintf('\n Transistor in active region (valid for amplification)\n');
    else
        fprintf('\n Transistor not in active region\n');
    end
    
    fprintf('\n');
end

function optimise_filter_design()
    %OPTIMISE_FILTER_DESIGN Symbolic filter design optimisation
    %   Optimises filter characteristics using symbolic frequency response
    
    fprintf('Problem 3: Filter Design Optimisation\n');
    fprintf('=====================================\n');
    
    syms s omega R C L Q omega_0 real positive
    syms H_LP H_HP H_BP H_BR real  % Transfer functions
    
    fprintf('Filter Design Optimisation Using Symbolic Methods\n');
    fprintf('Objective: Design filters with specified characteristics\n');
    fprintf(' Cutoff frequencies\n');
    fprintf(' Passband ripple\n');
    fprintf(' Stopband attenuation\n');
    fprintf(' Group delay characteristics\n\n');
    
    % Low-pass filter design
    fprintf('1. Low-Pass Filter Design:\n');
    fprintf('-------------\n');
    
    % Second-order Sallen-Key low-pass
    H_LP = omega_0^2 / (s^2 + (omega_0/Q)*s + omega_0^2);
    
    fprintf('Transfer function: H_LP(s) = %s\n', char(H_LP));
    fprintf('Design parameters:\n');
    fprintf('   = 1/ (LC) or 1/(RC) (depending on topology)\n');
    fprintf(' Q = quality factor (determines peaking)\n\n');
    
    % Frequency response characteristics
    fprintf('Frequency response analysis:\n');
    
    % Magnitude response at key frequencies
    H_LP_dc = subs(H_LP, s, 0);
    H_LP_omega0 = subs(H_LP, s, 1i*omega_0);
    H_LP_magnitude_omega0 = abs(H_LP_omega0);
    
    fprintf('DC gain: |H_LP(0)| = %s\n', char(H_LP_dc));
    fprintf('Gain at  : |H_LP(j )| = %s\n', char(H_LP_magnitude_omega0));
    
    % For Q = 1/ 2 (Butterworth response)
    Q_butterworth = 1/sqrt(2);
    H_LP_butterworth = subs(H_LP, Q, Q_butterworth);
    magnitude_at_omega0_butterworth = abs(subs(H_LP_butterworth, s, 1i*omega_0));
    magnitude_db = 20*log10(magnitude_at_omega0_butterworth)/log(10);
    
    fprintf('Butterworth response (Q = 1/ 2):\n');
    fprintf('|H(j )| = %.3f = %.1f dB (3-dB point)\n', ...
           double(magnitude_at_omega0_butterworth), double(magnitude_db));
    
    % Design equations for specific topologies
    fprintf('\nDesign Equations for Common Topologies:\n');
    
    % Sallen-Key unity-gain
    fprintf('Sallen-Key unity-gain:\n');
    fprintf('  = 1/(RRCC)^{1/2}\n');
    fprintf('Q = (RRCC)^{1/2}/(C(R + R))\n');
    
    % Multiple feedback
    fprintf('Multiple feedback:\n');
    fprintf('  = 1/ (RRCC)\n');
    fprintf('Q =  (RRCC)/(RC + RC + RC)\n\n');
    
    % High-pass filter design
    fprintf('2. High-Pass Filter Design:\n');
    fprintf('-------------\n');
    
    H_HP = s^2 / (s^2 + (omega_0/Q)*s + omega_0^2);
    
    fprintf('Transfer function: H_HP(s) = %s\n', char(H_HP));
    fprintf('Characteristics:\n');
    fprintf(' High-frequency gain: 0 dB\n');
    fprintf(' Low-frequency roll-off: +40 dB/decade\n');
    fprintf(' 3-dB frequency:   (for Q = 1/ 2)\n\n');
    
    % Band-pass filter design
    fprintf('3. Band-Pass Filter Design:\n');
    fprintf('-------------\n');
    
    H_BP = (omega_0/Q)*s / (s^2 + (omega_0/Q)*s + omega_0^2);
    
    fprintf('Transfer function: H_BP(s) = %s\n', char(H_BP));
    
    % Bandwidth calculation
    bandwidth = omega_0 / Q;
    
    fprintf('Center frequency:  \n');
    fprintf('Bandwidth: BW =  /Q = %s\n', char(bandwidth));
    fprintf('Lower 3-dB frequency:       - BW/2\n');
    fprintf('Upper 3-dB frequency:       + BW/2\n\n');
    
    % Design optimisation example
    demonstrate_filter_optimisation();
end

function demonstrate_filter_optimisation()
    %DEMONSTRATE_FILTER_OPTIMISATION Example filter optimisation
    %   Shows numerical optimisation for specific filter requirements
    
    fprintf('Filter Design Optimisation Example:\n');
    fprintf('-----------------\n');
    
    % Design requirements
    f_cutoff = 1000;        % Cutoff frequency (Hz)
    A_pass_max = 1;         % Maximum passband attenuation (dB)
    A_stop_min = 40;        % Minimum stopband attenuation (dB)
    f_stop = 3000;          % Stopband frequency (Hz)
    
    fprintf('Design requirements:\n');
    fprintf('Cutoff frequency: %.0f Hz\n', f_cutoff);
    fprintf('Passband ripple:   %.1f dB\n', A_pass_max);
    fprintf('Stopband attenuation:   %.0f dB\n', A_stop_min);
    fprintf('Stopband frequency: %.0f Hz\n\n', f_stop);
    
    % Convert to angular frequency
    omega_c = 2 * pi * f_cutoff;
    omega_s = 2 * pi * f_stop;
    
    % Filter order determination
    % For Butterworth filter: n   log(10^(A_s/10) - 1) / (2*log( _s/ _c))
    A_s_linear = 10^(A_stop_min/10) - 1;
    frequency_ratio = omega_s / omega_c;
    filter_order = log10(A_s_linear) / (2 * log10(frequency_ratio));
    filter_order_required = ceil(filter_order);
    
    fprintf('Filter order calculation:\n');
    fprintf('Frequency ratio:  _s/ _c = %.2f\n', frequency_ratio);
    fprintf('Required order: n   %.2f\n', filter_order);
    fprintf('Selected order: n = %d\n\n', filter_order_required);
    
    % Component value calculation for Sallen-Key topology
    fprintf('Component Value Calculation (Sallen-Key, n=2):\n');
    
    % Choose C1 = C2 = C (equal capacitor design)
    C_chosen = 100e-9;  % 100 nF
    
    % For equal R design with Butterworth response
    Q_butterworth = 1/sqrt(2);
    R_calculated = 1 / (omega_c * C_chosen);
    
    fprintf('Chosen capacitor: C = C = %.0f nF\n', C_chosen * 1e9);
    fprintf('Calculated resistor: R = R = %.1f k \n', R_calculated / 1e3);
    
    % Verify design
    omega_0_actual = 1 / (R_calculated * C_chosen);
    f_0_actual = omega_0_actual / (2 * pi);
    
    fprintf('\nDesign verification:\n');
    fprintf('Actual cutoff frequency: %.1f Hz\n', f_0_actual);
    fprintf('Error: %.2f%%\n', abs(f_0_actual - f_cutoff) / f_cutoff * 100);
    
    % Sensitivity analysis for component tolerances
    fprintf('\nComponent Tolerance Analysis:\n');
    tolerance_R = 0.05;  % 5% resistor tolerance
    tolerance_C = 0.10;  % 10% capacitor tolerance
    
    % Frequency sensitivity to component values
    % S_R^f = -1, S_C^f = -1 for f = 1/(2 RC)
    freq_sensitivity_R = -1;
    freq_sensitivity_C = -1;
    
    % Worst-case frequency variation
    freq_variation_worst = abs(freq_sensitivity_R) * tolerance_R + ...
                          abs(freq_sensitivity_C) * tolerance_C;
    
    fprintf('Frequency sensitivity to R: S_R^f = %d\n', freq_sensitivity_R);
    fprintf('Frequency sensitivity to C: S_C^f = %d\n', freq_sensitivity_C);
    fprintf('Worst-case frequency variation:  %.1f%%\n', freq_variation_worst * 100);
    
    fprintf('\n');
end

function analyse_power_converter()
    %ANALYSE_POWER_CONVERTER Power electronics symbolic analysis
    %   Analyses switching power converters using symbolic methods
    
    fprintf('Problem 4: Power Electronics Converter Analysis\n');
    fprintf('===============================================\n');
    
    syms D T_s V_in V_out L C R real positive  % Converter parameters
    syms i_L v_C real  % State variables
    syms t real
    
    fprintf('Buck Converter Symbolic Analysis\n');
    fprintf('Topology: Input voltage   Switch   Inductor   Output\n');
    fprintf('Control: PWM with duty cycle D\n\n');
    
    % Operating principle
    fprintf('Operating Principle:\n');
    fprintf('Switch ON (0   t < DT_s): v_L = V_in - V_out\n');
    fprintf('Switch OFF (DT_s   t < T_s): v_L = -V_out\n\n');
    
    % Steady-state analysis
    fprintf('Steady-State Analysis:\n');
    fprintf('-----------\n');
    
    % Volt-second balance on inductor
    fprintf('Volt-second balance:  ^T v_L dt = 0\n');
    fprintf('(V_in - V_out)DT_s + (-V_out)(1-D)T_s = 0\n');
    
    % Solve for output voltage
    V_out_steady = solve((V_in - V_out)*D + (-V_out)*(1-D) == 0, V_out);
    V_out_steady = simplify(V_out_steady);
    
    fprintf('Output voltage: V_out = %s\n', char(V_out_steady));
    fprintf('Voltage conversion ratio: M = V_out/V_in = D\n\n');
    
    % Current ripple analysis
    fprintf('Current Ripple Analysis:\n');
    fprintf('-----------\n');
    
    % Inductor current ripple
    delta_i_L = (V_in - V_out) * D * T_s / L;
    delta_i_L = subs(delta_i_L, V_out, D * V_in);  % Substitute steady-state relation
    delta_i_L = simplify(delta_i_L);
    
    fprintf('Inductor current ripple:  i_L = %s\n', char(delta_i_L));
    
    % Capacitor voltage ripple  
    delta_v_C = delta_i_L * T_s / (8 * C);  % Approximation for continuous mode
    delta_v_C = simplify(delta_v_C);
    
    fprintf('Capacitor voltage ripple:  v_C   %s\n', char(delta_v_C));
    
    % Critical inductance for continuous conduction
    fprintf('\nContinuous Conduction Mode:\n');
    fprintf('-------------\n');
    
    % Average output current
    I_out_avg = V_out_steady / R;
    I_out_avg = subs(I_out_avg, V_out, D * V_in);
    
    % Critical inductance
    L_critical = (V_in * D * (1 - D) * T_s) / (2 * I_out_avg);
    L_critical = subs(L_critical, I_out_avg, D * V_in / R);
    L_critical = simplify(L_critical);
    
    fprintf('Critical inductance: L_crit = %s\n', char(L_critical));
    fprintf('For CCM: L > L_crit\n\n');
    
    % Small-signal analysis
    fprintf('Small-Signal Analysis:\n');
    fprintf('-----------\n');
    
    syms d_hat v_out_hat i_L_hat real  % Small-signal perturbations
    
    fprintf('Linearised small-signal model around operating point:\n');
    
    % Control-to-output transfer function
    fprintf('Control-to-output transfer function derivation:\n');
    fprintf('Linearise around D, perturb with d(s)\n');
    
    % For buck converter in CCM
    syms omega_0 Q_factor real positive
    omega_0_buck = 1 / sqrt(L * C);
    Q_factor_buck = R * sqrt(C / L);
    
    fprintf('Natural frequency:   = 1/ (LC) = %s\n', char(omega_0_buck));
    fprintf('Quality factor: Q = R (C/L) = %s\n', char(Q_factor_buck));
    
    % Control-to-output transfer function
    G_vd = V_in / (s^2 * L * C + s * L / R + 1);
    G_vd = simplify(G_vd);
    
    fprintf('G_{vd}(s) = v_out/d = %s\n', char(G_vd));
    
    % Express in standard second-order form
    G_vd_standard = V_in * omega_0_buck^2 / (s^2 + (omega_0_buck/Q_factor_buck)*s + omega_0_buck^2);
    
    fprintf('Standard form: G_{vd}(s) = %s\n', char(G_vd_standard));
    
    % Stability considerations
    fprintf('\nStability and Control Design:\n');
    fprintf('--------------\n');
    fprintf(' RHP zeros: None for buck converter\n');
    fprintf(' Dominant poles: Complex pair at  \n');
    fprintf(' Crossover frequency: f_c < f_s/10 (switching frequency)\n');
    fprintf(' Phase margin: >45  for stability\n\n');
    
    % Demonstrate numerical example
    demonstrate_buck_converter_example();
end

function demonstrate_buck_converter_example()
    %DEMONSTRATE_BUCK_CONVERTER_EXAMPLE Numerical converter analysis
    %   Shows numerical analysis for specific buck converter design
    
    fprintf('Numerical Buck Converter Example:\n');
    fprintf('----------------\n');
    
    % Specifications
    V_in_val = 12;      % Input voltage (V)
    V_out_val = 5;      % Output voltage (V)
    I_out_val = 2;      % Output current (A)
    f_s_val = 100e3;    % Switching frequency (Hz)
    ripple_current = 0.2;  % 20% current ripple
    ripple_voltage = 0.01; % 1% voltage ripple
    
    fprintf('Specifications:\n');
    fprintf('V_in = %.0f V, V_out = %.0f V\n', V_in_val, V_out_val);
    fprintf('I_out = %.1f A, f_s = %.0f kHz\n', I_out_val, f_s_val/1e3);
    fprintf('Current ripple: %.0f%%, Voltage ripple: %.1f%%\n\n', ...
           ripple_current*100, ripple_voltage*100);
    
    % Design calculations
    D_val = V_out_val / V_in_val;
    T_s_val = 1 / f_s_val;
    R_load_val = V_out_val / I_out_val;
    
    fprintf('Design calculations:\n');
    fprintf('Duty cycle: D = %.3f\n', D_val);
    fprintf('Switching period: T_s = %.1f  s\n', T_s_val * 1e6);
    fprintf('Load resistance: R = %.2f  \n\n', R_load_val);
    
    % Inductor design
    delta_i_L_max = ripple_current * I_out_val;
    L_min = (V_in_val - V_out_val) * D_val * T_s_val / delta_i_L_max;
    L_chosen = 1.5 * L_min;  % 50% margin
    
    fprintf('Inductor design:\n');
    fprintf('Minimum inductance: L_min = %.1f  H\n', L_min * 1e6);
    fprintf('Chosen inductance: L = %.1f  H\n', L_chosen * 1e6);
    
    % Actual current ripple
    delta_i_L_actual = (V_in_val - V_out_val) * D_val * T_s_val / L_chosen;
    ripple_percent_actual = delta_i_L_actual / I_out_val * 100;
    
    fprintf('Actual current ripple: %.2f A (%.1f%%)\n\n', ...
           delta_i_L_actual, ripple_percent_actual);
    
    % Capacitor design
    delta_v_C_max = ripple_voltage * V_out_val;
    C_min = delta_i_L_actual * T_s_val / (8 * delta_v_C_max);
    C_chosen = 2 * C_min;  % 100% margin
    
    fprintf('Capacitor design:\n');
    fprintf('Minimum capacitance: C_min = %.1f  F\n', C_min * 1e6);
    fprintf('Chosen capacitance: C = %.1f  F\n', C_chosen * 1e6);
    
    % Actual voltage ripple
    delta_v_C_actual = delta_i_L_actual * T_s_val / (8 * C_chosen);
    ripple_v_percent_actual = delta_v_C_actual / V_out_val * 100;
    
    fprintf('Actual voltage ripple: %.1f mV (%.2f%%)\n\n', ...
           delta_v_C_actual * 1e3, ripple_v_percent_actual);
    
    % Small-signal parameters
    omega_0_val = 1 / sqrt(L_chosen * C_chosen);
    f_0_val = omega_0_val / (2 * pi);
    Q_val = R_load_val * sqrt(C_chosen / L_chosen);
    
    fprintf('Small-signal parameters:\n');
    fprintf('Natural frequency: f = %.1f kHz\n', f_0_val / 1e3);
    fprintf('Quality factor: Q = %.2f\n', Q_val);
    
    % Control bandwidth recommendation
    f_crossover_max = f_s_val / 10;
    fprintf('Recommended crossover: f_c < %.0f kHz\n', f_crossover_max / 1e3);
    
    fprintf('\n');
end

function demonstrate_advanced_circuit_techniques()
    %DEMONSTRATE_ADVANCED_CIRCUIT_TECHNIQUES Show sophisticated methods
    %   Demonstrates advanced symbolic circuit analysis techniques
    
    fprintf('Advanced Circuit Analysis Techniques\n');
    fprintf('===================================\n');
    
    % Technique 1: Symbolic nodal analysis
    fprintf('1. Automated Symbolic Nodal Analysis:\n');
    fprintf(' Automatic generation of node equations\n');
    fprintf(' Matrix formulation: Y V = I\n');
    fprintf(' Symbolic solution: V = Y I\n');
    fprintf(' Handles arbitrary circuit topology\n\n');
    
    % Technique 2: S-parameter analysis
    fprintf('2. S-Parameter Analysis:\n');
    fprintf(' Scattering matrix representation\n');
    fprintf(' High-frequency circuit characterisation\n');
    fprintf(' Symbolic extraction from Y or Z parameters\n');
    fprintf(' Network cascade analysis\n\n');
    
    % Technique 3: Noise analysis
    fprintf('3. Symbolic Noise Analysis:\n');
    fprintf(' Thermal noise: v = 4kTR f\n');
    fprintf(' Shot noise: i = 2qI f\n');
    fprintf(' Flicker noise: v = KfV/f\n');
    fprintf(' Total noise calculation using symbolic methods\n\n');
    
    % Technique 4: Distortion analysis
    fprintf('4. Harmonic Distortion Analysis:\n');
    fprintf(' Volterra series expansion\n');
    fprintf(' Symbolic computation of intermodulation products\n');
    fprintf(' Third-order intercept point calculation\n');
    fprintf(' Weakly nonlinear analysis techniques\n\n');
    
    % Technique 5: Electromagnetic compatibility
    fprintf('5. EMC Analysis:\n');
    fprintf(' Transmission line models\n');
    fprintf(' Crosstalk analysis using symbolic methods\n');
    fprintf(' Ground bounce and power supply noise\n');
    fprintf(' Symbolic susceptibility analysis\n\n');
    
    fprintf('Advanced circuit analysis demonstration complete.\n\n');
end
