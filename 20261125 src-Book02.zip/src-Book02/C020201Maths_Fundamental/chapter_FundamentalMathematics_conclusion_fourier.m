%% chapter_FundamentalMathematics_conclusion_fourier.m
% Fourier analysis for signal processing.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_conclusion_fourier
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateFourierAnalysis();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateFourierAnalysis()
    % DEMONSTRATEFOURIERANALYSIS Fourier transform applications
    %   Explores frequency-domain analysis of signals
    
    fprintf('Fourier Analysis: From Heat Conduction to Signal Processing\n');
    fprintf('============================================================\n\n');
    
    %% Composite Signal Construction
    fprintf('COMPOSITE SIGNAL CONSTRUCTION\n');
    fprintf('-----\n\n');
    
    fprintf(['Building a composite signal from multiple frequency components\n', ...
        'to demonstrate Fourier decomposition.\n\n']);
    
    % Sampling parameters
    fs = 1000;                    % sampling frequency (Hz)
    t_duration = 2;               % duration (seconds)
    t = 0:1/fs:(t_duration - 1/fs);  % time vector
    N = length(t);
    
    % Frequency components
    f1 = 50;   % 50 Hz component
    f2 = 120;  % 120 Hz component
    f3 = 200;  % 200 Hz component
    
    % Construct composite signal
    signal = 2 * sin(2 * pi * f1 * t) + ...
             1.5 * sin(2 * pi * f2 * t) + ...
             0.8 * sin(2 * pi * f3 * t);
    
    % Add noise
    rng(42);
    noise = 0.5 * randn(size(t));
    signal_noisy = signal + noise;
    
    fprintf('Signal components:\n');
    fprintf('  f1 = %d Hz (amplitude 2.0)\n', f1);
    fprintf('  f2 = %d Hz (amplitude 1.5)\n', f2);
    fprintf('  f3 = %d Hz (amplitude 0.8)\n', f3);
    fprintf('  Plus Gaussian noise (std = 0.5)\n\n');
    
    %% Fast Fourier Transform
    fprintf('FAST FOURIER TRANSFORM ANALYSIS\n');
    fprintf('------\n\n');
    
    % Compute FFT
    signal_fft = fft(signal_noisy);
    
    % Compute power spectral density
    power = abs(signal_fft / N).^2;
    
    % Frequency axis (only positive frequencies)
    freq_axis = fs * (0:(N/2)) / N;
    power_single_sided = power(1:(N/2 + 1));
    power_single_sided(2:end-1) = 2 * power_single_sided(2:end-1);
    
    fprintf('FFT computation complete.\n');
    fprintf('Frequency resolution: %.2f Hz\n\n', fs / N);
    
    % Find peaks in frequency domain
    [peaks, locs] = findpeaks(power_single_sided, freq_axis, ...
        'MinPeakHeight', max(power_single_sided) * 0.1, ...
        'SortStr', 'descend', 'NPeaks', 5);
    
    fprintf('Detected frequency peaks:\n');
    fprintf('%-15*s  %-20*s\n', 'Frequency (Hz)', 'Power');
    fprintf('%s\n', repmat('-', 1, 40));
    
    for i = 1:min(length(locs), 3)
        fprintf('%-15.2*f  %-20.6*f\n', locs(i), peaks(i));
    end
    fprintf('\n');
    
    %% Visualisation
    figure('Position', [100, 100, 1400, 800]);
    
    % Time domain - clean signal
    subplot(3, 2, 1);
    plot(t(1:1000), signal(1:1000), 'b-', 'LineWidth', 1.5);
    xlabel('Time (s)');
    ylabel('Amplitude');
    title('Clean Signal (First Second)');
    grid on;
    
    % Time domain - noisy signal
    subplot(3, 2, 2);
    plot(t(1:1000), signal_noisy(1:1000), 'r-', 'LineWidth', 1);
    xlabel('Time (s)');
    ylabel('Amplitude');
    title('Noisy Signal (First Second)');
    grid on;
    
    % Frequency domain - full spectrum
    subplot(3, 2, 3);
    plot(freq_axis, 10 * log10(power_single_sided), 'b-', 'LineWidth', 1.5);
    xlabel('Frequency (Hz)');
    ylabel('Power (dB)');
    title('Power Spectral Density');
    grid on;
    xlim([0, 400]);
    
    % Frequency domain - zoomed to component region
    subplot(3, 2, 4);
    plot(freq_axis, power_single_sided, 'b-', 'LineWidth', 1.5);
    hold on;
    plot(locs(1:3), peaks(1:3), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    
    for i = 1:3
        text(locs(i), peaks(i) * 1.1, sprintf('%.1f Hz', locs(i)), ...
            'HorizontalAlignment', 'center', 'FontSize', 10, ...
            'FontWeight', 'bold');
    end
    
    xlabel('Frequency (Hz)');
    ylabel('Power');
    title('Identified Frequency Components');
    grid on;
    xlim([0, 300]);
    
    % Spectrogram (time-frequency representation)
    subplot(3, 2, [5, 6]);
    window_size = 256;
    overlap = 128;
    
    spectrogram(signal_noisy, hamming(window_size), overlap, [], fs, 'yaxis');
    title('Spectrogram: Time-Frequency Representation');
    ylim([0, 0.4]);
    
    fprintf('Fourier analysis successfully decomposed the composite signal,\n');
    fprintf('identifying constituent frequencies despite significant noise.\n\n');
end
