%% prob8_complete.m
% Problem 8: Transfer Learning Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob8_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 8: Transfer Learning and Fine-tuning Dynamics
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Comprehensive analysis of transfer learning strategies,
%              layer-wise fine-tuning, domain adaptation, and few-shot learning

%% Initialization
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 8: Transfer Learning and Fine-tuning Dynamics\n');
fprintf('================================================================\n\n');

%% Pre-trained Model Configuration
sourceDataset = 'ImageNet';
sourceDatasetSize = 1.2e6;  % 1.2 million images
sourceClasses = 1000;

targetDataset = 'Caltech-101';
targetDatasetSize = 9144;
targetClasses = 101;

fprintf('Transfer Learning Setup:\n');
fprintf('  Source dataset: %s (%s images, %d classes)\n', ...
        sourceDataset, formatNumber(sourceDatasetSize), sourceClasses);
fprintf('  Target dataset: %s (%s images, %d classes)\n\n', ...
        targetDataset, formatNumber(targetDatasetSize), targetClasses);

%% Pre-trained Network Architecture (ResNet-50)
networkLayers = {'Conv1 (64 filters)', 'Conv2_x (256 filters)', ...
                 'Conv3_x (512 filters)', 'Conv4_x (1024 filters)', ...
                 'Conv5_x (2048 filters)', 'FC (1000 units)', ...
                 'New FC (101 units)'};

layerDepth = [1, 3, 4, 6, 3, 1, 1];  % Layer groups
totalLayers = sum(layerDepth);
cumulativeLayers = [0, cumsum(layerDepth)];

fprintf('Pre-trained Model: ResNet-50\n');
fprintf('  Total layers: %d (organized in %d blocks)\n', ...
        totalLayers, length(layerDepth));
fprintf('  Parameters: %s\n', formatNumber(25.6e6));
fprintf('  Pre-training dataset: %s\n\n', sourceDataset);

%% Part (a): Fine-tuning Strategy Comparison

strategies = {'From Scratch', 'Feature Extraction', ...
              'Full Fine-tuning', 'Progressive Unfreezing', ...
              'Discriminative LR'};

% Simulated results with different target data percentages
dataPercentages = [10, 25, 50, 100];

% Accuracy results: [strategy   data_percentage]
accuracyResults = [
    45.2, 58.3, 68.5, 75.2;  % From Scratch
    72.5, 78.8, 82.1, 84.3;  % Feature Extraction
    78.9, 84.2, 87.5, 89.8;  % Full Fine-tuning
    81.2, 86.5, 89.2, 91.5;  % Progressive Unfreezing
    83.5, 88.1, 90.8, 92.7   % Discriminative LR
];

% Training time (hours)
trainingTime = [
    12.0, 18.0, 28.0, 42.0;  % From Scratch
    2.5, 3.2, 4.5, 6.0;      % Feature Extraction
    4.5, 6.5, 9.0, 13.0;     % Full Fine-tuning
    5.5, 7.5, 10.5, 15.0;    % Progressive Unfreezing
    5.0, 7.0, 10.0, 14.5     % Discriminative LR
];

fprintf('========================================\n');
fprintf('(a) Fine-tuning Strategy Performance\n');
fprintf('========================================\n\n');

for dataIdx = 1:length(dataPercentages)
    fprintf('Target Data: %d%% (%d images)\n', ...
            dataPercentages(dataIdx), ...
            round(targetDatasetSize * dataPercentages(dataIdx) / 100));
    fprintf('%s\n', repmat('-', 1, 75));
    fprintf('%-25s %-20s %-25s\n', 'Strategy', 'Accuracy (%%)', ...
            'Training Time (hrs)');
    fprintf('%s\n', repmat('-', 1, 75));
    
    for stratIdx = 1:length(strategies)
        fprintf('%-25s %-20.1f %-25.1f\n', ...
                strategies{stratIdx}, ...
                accuracyResults(stratIdx, dataIdx), ...
                trainingTime(stratIdx, dataIdx));
    end
    fprintf('\n');
end

% Find best strategy for each data regime
fprintf('OPTIMAL STRATEGIES:\n');
for dataIdx = 1:length(dataPercentages)
    [bestAcc, bestIdx] = max(accuracyResults(:, dataIdx));
    
    fprintf('  %d%% data: %s (%.1f%% acc, %.1f hrs)\n', ...
            dataPercentages(dataIdx), strategies{bestIdx}, ...
            bestAcc, trainingTime(bestIdx, dataIdx));
end
fprintf('\n');

%% Part (b): Layer-wise Learning Rate Analysis

% Learning rate multipliers for each layer group (discriminative LR)
baseLR = 0.001;
lrMultipliers = [0.01, 0.05, 0.1, 0.3, 0.5, 0.8, 1.0];  % Early   Late
effectiveLRs = baseLR * lrMultipliers;

fprintf('========================================\n');
fprintf('(b) Layer-wise Learning Rate Schedule\n');
fprintf('========================================\n');
fprintf('%-25s %-15s %-25s %-20s\n', 'Layer Block', 'Depth', ...
        'LR Multiplier', 'Effective LR');
fprintf('%s\n', repmat('-', 1, 88));

for i = 1:length(networkLayers)
    fprintf('%-25s %-15d %-25.2f %-20.6f\n', ...
            networkLayers{i}, layerDepth(i), ...
            lrMultipliers(i), effectiveLRs(i));
end
fprintf('\n');

fprintf('RATIONALE:\n');
fprintf('  - Early layers (Conv1): 0.01x LR (preserve generic features)\n');
fprintf('  - Middle layers (Conv2-4): 0.05-0.3x LR (moderate adaptation)\n');
fprintf('  - Late layers (Conv5, FC): 0.5-1.0x LR (task-specific learning)\n');
fprintf('  - New classifier: 1.0x LR (full learning from scratch)\n\n');

%% Part (c): Progressive Unfreezing Dynamics

unfreezingSchedule = [
    struct('epoch', 0, 'unfrozenLayers', [7], 'accuracy', 72.5);
    struct('epoch', 10, 'unfrozenLayers', [6,7], 'accuracy', 78.2);
    struct('epoch', 20, 'unfrozenLayers', [5,6,7], 'accuracy', 83.5);
    struct('epoch', 30, 'unfrozenLayers', [4,5,6,7], 'accuracy', 87.1);
    struct('epoch', 40, 'unfrozenLayers', [3,4,5,6,7], 'accuracy', 89.8);
    struct('epoch', 50, 'unfrozenLayers', [2,3,4,5,6,7], 'accuracy', 90.9);
    struct('epoch', 60, 'unfrozenLayers', [1,2,3,4,5,6,7], 'accuracy', 91.5);
];

fprintf('========================================\n');
fprintf('(c) Progressive Unfreezing Schedule\n');
fprintf('========================================\n');
fprintf('%-15s %-30s %-20s\n', 'Epoch', 'Unfrozen Layers', 'Val Accuracy (%)');
fprintf('%s\n', repmat('-', 1, 68));

for i = 1:length(unfreezingSchedule)
    layerStr = sprintf('%d ', unfreezingSchedule(i).unfrozenLayers);
    
    fprintf('%-15d %-30s %-20.1f\n', ...
            unfreezingSchedule(i).epoch, layerStr, ...
            unfreezingSchedule(i).accuracy);
end
fprintf('\n');

fprintf('PROGRESSIVE UNFREEZING BENEFITS:\n');
fprintf('  1. Prevents catastrophic forgetting of pre-trained features\n');
fprintf('  2. Stabilizes training with gradual capacity increase\n');
fprintf('  3. Achieves %.1f%% accuracy (vs %.1f%% from full fine-tuning)\n\n', ...
        unfreezingSchedule(end).accuracy, accuracyResults(3, 4));

%% Part (d): Domain Similarity Impact

domainPairs = {
    'ImageNet   Caltech-101 (similar)', ...
    'ImageNet   CIFAR-10 (moderate)', ...
    'ImageNet   Medical X-ray (distant)', ...
    'ImageNet   Satellite (very distant)', ...
    'Random Init   Caltech-101 (baseline)'
};

domainSimilarity = [0.85, 0.60, 0.25, 0.15, 0.0];
transferAccuracy = [92.7, 88.5, 76.3, 68.9, 75.2];
scratchAccuracy = [75.2, 72.8, 71.5, 70.2, 75.2];
transferGain = transferAccuracy - scratchAccuracy;

fprintf('========================================\n');
fprintf('(d) Domain Adaptation Analysis\n');
fprintf('========================================\n');
fprintf('%-40s %-15s %-20s %-18s %-15s\n', 'Domain Transfer', ...
        'Similarity', 'Transfer Acc (%%)', 'Scratch Acc (%%)', 'Gain (%)');
fprintf('%s\n', repmat('-', 1, 112));

for i = 1:length(domainPairs)
    fprintf('%-40s %-15.2f %-20.1f %-18.1f ', ...
            domainPairs{i}, domainSimilarity(i), ...
            transferAccuracy(i), scratchAccuracy(i));
    
    if transferGain(i) > 0
        fprintf('%-15s\n', sprintf('+%.1f', transferGain(i)));
    else
        fprintf('%-15s\n', sprintf('%.1f', transferGain(i)));
    end
end
fprintf('\n');

% Fit power law: gain ~ similarity^ 
validIdx = domainSimilarity > 0;
p = polyfit(log(domainSimilarity(validIdx)), ...
            log(transferGain(validIdx) + 1), 1);
alpha = p(1);

fprintf('DOMAIN SIMILARITY POWER LAW:\n');
fprintf('  Transfer Gain   k   (Similarity)^%.2f\n', alpha);
fprintf('  Interpretation: Strong dependency on domain similarity\n');
fprintf('  Recommendation: Use domain adaptation for similarity < 0.5\n\n');

%% Part (e): Few-shot Learning Performance

fewShotSamples = [1, 5, 10, 25, 50, 100];  % Samples per class
fewShotAccuracy_scratch = [8.5, 15.2, 22.8, 38.5, 51.2, 62.5];
fewShotAccuracy_transfer = [42.3, 58.7, 68.5, 79.2, 85.8, 89.5];

fprintf('========================================\n');
fprintf('(e) Few-shot Learning Analysis\n');
fprintf('========================================\n');
fprintf('%-20s %-25s %-25s %-20s\n', 'Samples/Class', ...
        'From Scratch (%%)', 'Transfer Learning (%%)', 'Improvement (%)');
fprintf('%s\n', repmat('-', 1, 95));

for i = 1:length(fewShotSamples)
    improvement = fewShotAccuracy_transfer(i) - fewShotAccuracy_scratch(i);
    
    fprintf('%-20d %-25.1f %-25.1f %-20.1f\n', ...
            fewShotSamples(i), fewShotAccuracy_scratch(i), ...
            fewShotAccuracy_transfer(i), improvement);
end
fprintf('\n');

fprintf('FEW-SHOT INSIGHTS:\n');
fprintf('  - With only 5 samples/class: Transfer achieves %.1f%% vs %.1f%% scratch\n', ...
        fewShotAccuracy_transfer(2), fewShotAccuracy_scratch(2));
fprintf('  - Transfer with 10 samples   Scratch with 100 samples\n');
fprintf('  - Data efficiency gain: ~10x reduction in required samples\n\n');

%% Part (f): Catastrophic Forgetting Analysis

epochs = 0:5:100;
pretrainedFeatureRetention = [100, 98, 95, 88, 75, 58, 38, 22, 12, 8, 5, 3, 2, 1.5, 1.2, 1.0, 0.8, 0.7, 0.5, 0.4, 0.3];
targetTaskAccuracy = [72, 78, 84, 88, 90, 91.5, 92, 92.2, 92.3, 92.35, 92.38, 92.4, 92.41, 92.42, 92.42, 92.42, 92.42, 92.42, 92.42, 92.42, 92.42];

fprintf('========================================\n');
fprintf('(f) Catastrophic Forgetting Dynamics\n');
fprintf('========================================\n');
fprintf('%-15s %-30s %-25s\n', 'Epoch', 'Pre-trained Features (%%)', ...
        'Target Accuracy (%)');
fprintf('%s\n', repmat('-', 1, 73));

for i = 1:5:length(epochs)
    fprintf('%-15d %-30.1f %-25.2f\n', ...
            epochs(i), pretrainedFeatureRetention(i), ...
            targetTaskAccuracy(i));
end
fprintf('\n');

fprintf('MITIGATION STRATEGIES:\n');
fprintf('  1. Lower learning rates for pre-trained layers (0.01-0.1x)\n');
fprintf('  2. L2 regularization anchored to pre-trained weights\n');
fprintf('  3. Elastic Weight Consolidation (EWC) for critical parameters\n');
fprintf('  4. Progressive unfreezing to preserve early features\n\n');

%% Part (g): Computational Cost Analysis

totalParams = 25.6e6;
trainableParams_strategies = [
    totalParams;              % From Scratch
    targetClasses * 2048;     % Feature Extraction (only FC)
    totalParams;              % Full Fine-tuning
    totalParams;              % Progressive Unfreezing
    totalParams               % Discriminative LR
];

memoryUsage_GB = [8.5, 2.1, 8.5, 8.5, 8.5];
trainingThroughput_imgs_per_sec = [120, 280, 125, 130, 128];

fprintf('========================================\n');
fprintf('(g) Computational Resource Requirements\n');
fprintf('========================================\n');
fprintf('%-25s %-22s %-18s %-25s\n', 'Strategy', 'Trainable Params', ...
        'Memory (GB)', 'Throughput (imgs/s)');
fprintf('%s\n', repmat('-', 1, 95));

for i = 1:length(strategies)
    fprintf('%-25s %-22s %-18.1f %-25.0f\n', ...
            strategies{i}, formatNumber(trainableParams_strategies(i)), ...
            memoryUsage_GB(i), trainingThroughput_imgs_per_sec(i));
end
fprintf('\n');

fprintf('RESOURCE OPTIMIZATION:\n');
fprintf('  Most efficient: Feature Extraction (2.1 GB, 280 imgs/s)\n');
fprintf('  Best accuracy: Discriminative LR (%.1f%% with full resources)\n', ...
        accuracyResults(5, 4));
fprintf('  Balanced choice: Progressive Unfreezing\n\n');

%% Visualization: Comprehensive Transfer Learning Analysis

figure('Position', [50, 50, 1800, 1000], 'Color', 'w');

% Panel 1: Strategy Comparison Across Data Regimes
subplot(2, 4, 1);
for stratIdx = 1:length(strategies)
    plot(dataPercentages, accuracyResults(stratIdx, :), '-o', ...
         'LineWidth', 2.5, 'MarkerSize', 10, ...
         'DisplayName', strategies{stratIdx});
    hold on;
end

xlabel('Target Dataset Size (\%)', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Validation Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(a) Data Efficiency}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend('Interpreter', 'latex', 'Location', 'southeast', 'FontSize', 9);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 2: Layer-wise Learning Rates
subplot(2, 4, 2);
bar(effectiveLRs, 'FaceColor', [0.4, 0.6, 0.8], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);
set(gca, 'YScale', 'log');

ylabel('Effective Learning Rate (log scale)', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(b) Discriminative LR}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', {'C1', 'C2', 'C3', 'C4', 'C5', 'FC', 'New'}, ...
         'FontSize', 11);
grid on; box on;

% Panel 3: Progressive Unfreezing
subplot(2, 4, 3);
unfreezeEpochs = [unfreezingSchedule.epoch];
unfreezeAccs = [unfreezingSchedule.accuracy];

stairs(unfreezeEpochs, unfreezeAccs, 'b-', 'LineWidth', 3);
hold on;
plot(unfreezeEpochs, unfreezeAccs, 'ro', 'MarkerSize', 10, ...
     'MarkerFaceColor', 'r');

xlabel('Training Epoch', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Validation Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(c) Progressive Unfreezing}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 4: Domain Similarity Impact
subplot(2, 4, 4);
scatter(domainSimilarity(validIdx), transferGain(validIdx), 200, 'filled', ...
        'MarkerFaceColor', [0.8, 0.4, 0.2], 'MarkerEdgeColor', 'k');
hold on;

% Fit curve
simFit = linspace(min(domainSimilarity(validIdx)), ...
                  max(domainSimilarity(validIdx)), 100);
gainFit = exp(polyval(p, log(simFit)));
plot(simFit, gainFit, 'b-', 'LineWidth', 2.5);

xlabel('Domain Similarity', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Transfer Gain (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(d) Domain Adaptation}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend({'Observed', sprintf('Fit: $\\sim s^{%.2f}$', alpha)}, ...
       'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 5: Few-shot Learning
subplot(2, 4, 5);
semilogx(fewShotSamples, fewShotAccuracy_scratch, 'r-o', ...
         'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', 'r', ...
         'DisplayName', 'From Scratch');
hold on;
semilogx(fewShotSamples, fewShotAccuracy_transfer, 'b-s', ...
         'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', 'b', ...
         'DisplayName', 'Transfer Learning');

xlabel('Samples per Class (log scale)', 'Interpreter', 'latex', ...
       'FontSize', 13);
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(e) Few-shot Performance}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend('Interpreter', 'latex', 'Location', 'southeast', 'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 6: Catastrophic Forgetting
subplot(2, 4, 6);
yyaxis left
plot(epochs, pretrainedFeatureRetention, 'b-o', 'LineWidth', 2.5, ...
     'MarkerSize', 8);
ylabel('Pre-trained Features (\%)', 'Interpreter', 'latex', 'FontSize', 13);

yyaxis right
plot(epochs, targetTaskAccuracy, 'r-s', 'LineWidth', 2.5, 'MarkerSize', 8);
ylabel('Target Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);

xlabel('Training Epoch', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(f) Catastrophic Forgetting}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 7: Training Time Comparison
subplot(2, 4, 7);
bar(trainingTime(:, 4), 'FaceColor', [0.5, 0.7, 0.5], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);

ylabel('Training Time (hours)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(g) Computational Cost (100\% data)}', ...
      'Interpreter', 'latex', 'FontSize', 15);
set(gca, 'XTickLabel', {'Scratch', 'FeatExt', 'FullFT', 'ProgUnf', 'DiscLR'}, ...
         'FontSize', 11);
grid on; box on;

% Panel 8: Memory-Accuracy Trade-off
subplot(2, 4, 8);
scatter(memoryUsage_GB, accuracyResults(:, 4), 250, ...
        trainingTime(:, 4), 'filled', 'MarkerEdgeColor', 'k');
colorbar;
colormap('jet');

xlabel('Memory Usage (GB)', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(h) Resource-Accuracy Trade-off}', ...
      'Interpreter', 'latex', 'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

%% Summary Recommendations

fprintf('========================================\n');
fprintf('PRACTICAL RECOMMENDATIONS\n');
fprintf('========================================\n\n');

fprintf('SCENARIO 1: Limited Data (< 1000 samples)\n');
fprintf('  Strategy: Feature Extraction or Few-shot Meta-learning\n');
fprintf('  Expected accuracy: %.1f%%\n', fewShotAccuracy_transfer(3));
fprintf('  Training time: %.1f hours\n', trainingTime(2, 1));
fprintf('  Key: Preserve all pre-trained features\n\n');

fprintf('SCENARIO 2: Moderate Data (1000-10000 samples)\n');
fprintf('  Strategy: Progressive Unfreezing\n');
fprintf('  Expected accuracy: %.1f%%\n', accuracyResults(4, 3));
fprintf('  Training time: %.1f hours\n', trainingTime(4, 3));
fprintf('  Key: Gradual adaptation prevents forgetting\n\n');

fprintf('SCENARIO 3: Large Data (> 10000 samples)\n');
fprintf('  Strategy: Discriminative Learning Rates\n');
fprintf('  Expected accuracy: %.1f%%\n', accuracyResults(5, 4));
fprintf('  Training time: %.1f hours\n', trainingTime(5, 4));
fprintf('  Key: Full fine-tuning with layer-wise LR\n\n');

fprintf('SCENARIO 4: Very Different Domain\n');
fprintf('  Strategy: Domain Adaptation + Progressive Unfreezing\n');
fprintf('  Expected improvement: +%.1f%% over scratch\n', transferGain(3));
fprintf('  Techniques: CORAL, MMD, Adversarial Adaptation\n\n');

fprintf('GENERAL BEST PRACTICES:\n');
fprintf('  1. Always start with feature extraction baseline\n');
fprintf('  2. Use discriminative LR: 0.01x for early, 1.0x for late layers\n');
fprintf('  3. Monitor pre-trained feature retention during training\n');
fprintf('  4. Apply progressive unfreezing for stability\n');
fprintf('  5. Use data augmentation to maximize limited data\n');
fprintf('  6. Consider ensemble of different unfreezing schedules\n\n');

%% Helper Function
function str = formatNumber(num)
    if num >= 1e9
        str = sprintf('%.2fB', num/1e9);
    elseif num >= 1e6
        str = sprintf('%.2fM', num/1e6);
    elseif num >= 1e3
        str = sprintf('%.2fK', num/1e3);
    else
        str = sprintf('%d', num);
    end
end
