%% chapter_DataVisualisation_radar.m
% Radar Chart Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_radar
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createRadarChart(P, labels)
% P: Matrix where each row represents a case
% labels: Cell array of variable names

angles = linspace(0, 2*pi, size(P,2)+1);
P = [P P(:,1)]; % Close the plot

figure('Position', [100 100 800 800]);
polarplot(angles, P, 'LineWidth', 2);

% Set the labels
thetalim([0 360]);
rlim([0 1]);
thetaticks(linspace(0, 360, length(labels)));
thetaticklabels(labels);

legend('Case 1', 'Case 2', 'Case 3');
title('Multivariate Comparison Analysis');

% Export figure in multiple formats
exportFigure(gca, 'RadarChart_plot');

end
