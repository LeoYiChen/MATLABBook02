%% chapter_Math_example_linalg.m
% Matrix and linear algebra functions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_linalg
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create sample matrix
A = magic(4);  % 4*x4 magic square

% Basic matrix operations
transpose_A = A';           % Transpose
inverse_A = inv(A);         % Inverse (if non-singular)
determinant = det(A);       % Determinant
rank_A = rank(A);           % Rank

% Eigenvalues and eigenvectors
[eigenvectors, eigenvalues] = eig(A);

% Singular value decomposition
[U, S, V] = svd(A);

% Matrix norms
norm1 = norm(A, 1);         % 1-norm
norm2 = norm(A, 2);         % 2-norm (spectral norm)
normInf = norm(A, inf);     % Infinity norm
normFro = norm(A, 'fro');   % Frobenius norm

% Linear system solving
b = [1; 2; 3; 4];
x = A \ b;                  % Solve Ax = b (backslash operator)

% Matrix exponential
expA = expm(A);             % Matrix exponential (different from exp(A))

% Matrix properties
trace_A = trace(A);         % Trace (sum of diagonal elements)
cond_A = cond(A);           % Condition number
