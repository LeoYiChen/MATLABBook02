%% ch08_prob6_code.m
% Autoencoder anomaly detection (MATLABBook02_Chapter08_Problem6.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob6_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem6.m
% --------------------------------
% Purpose : Anomaly detection in big sensor data via autoencoder.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later; Deep Learning Toolbox required
% --------------------------------
clc; clear; close all;

%% Step 1 – Generate synthetic sensor data with anomalies
fprintf('=== Step 1: Generating sensor data with anomalies ===\n');
rng(42, 'twister');
numSamples   = 100000;
numSensors   = 6;
anomalyRate  = 0.05;  % 5 % anomalies

normalData   = randn(numSamples, numSensors) .* ...
               [2 3 1.5 4 2.5 1] + [10 50 30 20 60 5];
numAnomalies = round(anomalyRate * numSamples);
anomalyIdx   = randperm(numSamples, numAnomalies);
trueLabels   = zeros(numSamples, 1);  % 0 = normal, 1 = anomaly
trueLabels(anomalyIdx) = 1;

% Inject anomalies as large deviations
normalData(anomalyIdx, :) = normalData(anomalyIdx, :) + ...
    randn(numAnomalies, numSensors) .* 15;
fprintf('  Samples: %d | Anomalies: %d (%.1f%%)\n', ...
    numSamples, numAnomalies, anomalyRate*100);

%% Step 2 – Split: train on normal data only
normalMask     = (trueLabels == 0);
trainData      = normalData(normalMask, :);
testData       = normalData;
testLabels     = trueLabels;

% Normalise using training statistics
trainMean = mean(trainData, 1);
trainStd  = std(trainData, 0, 1);
trainDataNorm = (trainData - trainMean) ./ trainStd;
testDataNorm  = (testData  - trainMean) ./ trainStd;
fprintf('  Training samples (normal): %d\n', size(trainData,1));

%% Step 3 – Build and train autoencoder
fprintf('\n=== Step 3: Training autoencoder ===\n');
bottleneckSize = 3;
autoEncoder = trainAutoencoder(trainDataNorm', bottleneckSize, ...
    'MaxEpochs',         200, ...
    'L2WeightRegularization', 0.001, ...
    'SparsityRegularization', 4, ...
    'SparsityProportion',     0.10, ...
    'ScaleData',              false);
fprintf('  Autoencoder trained (bottleneck = %d).\n', bottleneckSize);

%% Step 4 – Compute reconstruction errors
reconstructedTest = predict(autoEncoder, testDataNorm');
reconstructedTest = reconstructedTest';
reconstructionError = sum((testDataNorm - reconstructedTest).^2, 2);

% Training reconstruction error for threshold
reconstructedTrain = predict(autoEncoder, trainDataNorm');
reconstructedTrain = reconstructedTrain';
trainReconError    = sum((trainDataNorm - reconstructedTrain).^2, 2);

%% Step 5 – Determine threshold
errorMean   = mean(trainReconError);
errorStdDev = std(trainReconError);
threshold   = errorMean + 3 * errorStdDev;
fprintf('  Threshold (mu + 3*sigma): %.4f\n', threshold);

%% Step 6 – Flag anomalies and evaluate
predictedAnomalies = (reconstructionError > threshold);
truePositives  = sum(predictedAnomalies & testLabels);
falsePositives = sum(predictedAnomalies & ~testLabels);
falseNegatives = sum(~predictedAnomalies & testLabels);
precision = truePositives / (truePositives + falsePositives + eps);
recall    = truePositives / (truePositives + falseNegatives + eps);
f1Score   = 2 * precision * recall / (precision + recall + eps);
fprintf('  Precision: %.4f | Recall: %.4f | F1: %.4f\n', ...
    precision, recall, f1Score);

%% Step 7 – Visualise reconstruction error
figAnomaly = figure('Name','Anomaly Detection', ...
    'Position',[100 100 1200 500]);
sampleRange = 1:min(10000, numSamples);
plot(sampleRange, reconstructionError(sampleRange), ...
    'b.', 'MarkerSize', 2); hold on;
yline(threshold, 'r-', 'LineWidth', 2);
detectedInRange = sampleRange(predictedAnomalies(sampleRange) == 1);
plot(detectedInRange, ...
    reconstructionError(detectedInRange), ...
    'ro', 'MarkerSize', 5);
xlabel('Sample Index', 'Interpreter','latex');
ylabel('Reconstruction Error', 'Interpreter','latex');
title('\textbf{Autoencoder Anomaly Detection}', ...
    'Interpreter','latex', 'FontSize', 13);
legend({'Normal','Threshold','Detected Anomaly'}, ...
    'Interpreter','latex', 'Location','northwest');
grid on;

savefig(figAnomaly, 'Ch08_Problem6_AnomalyDetection.fig');
exportgraphics(figAnomaly, 'Ch08_Problem6_AnomalyDetection.eps', ...
    'ContentType','vector');
exportgraphics(figAnomaly, 'Ch08_Problem6_AnomalyDetection.jpg', ...
    'Resolution', 300);

%% Step 8 – Animate detection and save MP4
fprintf('\n=== Step 8: Animating detection ===\n');
figAnim = figure('Name','Anomaly Animation', ...
    'Position',[100 100 1000 500]);
vidWriter = VideoWriter('Ch08_Problem6_AnomalyAnimation.mp4','MPEG-4');
vidWriter.FrameRate = 24;
vidWriter.Quality   = 90;
open(vidWriter);

windowSize = 500;
stepSize   = 50;
totalSteps = floor((min(10000,numSamples) - windowSize) / stepSize);
for stepIdx = 0:totalSteps
    startIdx = 1 + stepIdx * stepSize;
    endIdx   = startIdx + windowSize - 1;
    cla;
    plot(startIdx:endIdx, reconstructionError(startIdx:endIdx), ...
        'b.', 'MarkerSize', 3); hold on;
    yline(threshold, 'r-', 'LineWidth', 2);
    windowAnom = find(predictedAnomalies(startIdx:endIdx)) ...
                 + startIdx - 1;
    plot(windowAnom, reconstructionError(windowAnom), ...
        'ro', 'MarkerSize', 6);
    xlim([startIdx endIdx]);
    ylim([0 max(reconstructionError(1:10000))*1.1]);
    xlabel('Sample Index', 'Interpreter','latex');
    ylabel('Reconstruction Error', 'Interpreter','latex');
    title(sprintf('\\textbf{Sliding Window [%d - %d]}', ...
        startIdx, endIdx), 'Interpreter','latex');
    grid on; drawnow;
    writeVideo(vidWriter, getframe(figAnim));
end
close(vidWriter);
fprintf('  Video saved: Ch08_Problem6_AnomalyAnimation.mp4\n');

fprintf('\n=== Problem 6 Complete ===\n');
% --------------------------------
% Computational Complexity:
% Data generation is O(N * D). Training the autoencoder for E
% epochs with N_train samples is O(E * N_train * D * B), where B
% is the bottleneck size. Reconstruction of all N samples is
% O(N * D * B). Threshold computation is O(N_train). Evaluation
% (precision/recall) is O(N). The animation loop is O(totalSteps)
% and I/O-bound. Memory is O(N * D) for the full dataset.
% --------------------------------
