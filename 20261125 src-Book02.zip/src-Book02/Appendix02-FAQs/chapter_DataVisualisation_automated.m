%% chapter_DataVisualisation_automated.m
% Automated Generation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_automated
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function generateStudyFigures(data_struct, output_dir)
% Input validation
if ~exist(output_dir, 'dir')
mkdir(output_dir);
end

% Figure generation loop
field_names = fieldnames(data_struct);
for i = 1:length(field_names)
    % Create figure
    h = figure('Visible', 'off');
    
    % Plot data
    current_data = data_struct.(field_names{i});
    visualiseData(current_data);
    
    % Apply research standards
    customiseResearchPlot(h);
    
    % Save figure
    filename = fullfile(output_dir, ...
                      [field_names{i} '.eps']);
    print(h, filename, '-depsc2', '-r300');
    close(h);
end

end

function visualiseData(data)
% Select appropriate visualization based on data
if isvector(data)
histogram(data, 'Normalization', 'probability');
elseif ismatrix(data)
imagesc(data);
colorbar;
else
error('Unsupported data dimension');
end
end
