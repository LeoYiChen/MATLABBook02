%% prob6_complete.m
% Problem 6: Dropout Regularization Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob6_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 6: Dropout Regularization and Model Capacity
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Comprehensive analysis of dropout's impact on model capacity,
%              overfitting, and generalization performance
%
% Revision History:
%   v1.0 (15-Jan-2025): Initial implementation
%   v1.1 (15-Jan-2025): Added layer-wise dropout analysis

%% Initialization
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 6: Dropout Regularization and Model Capacity\n');
fprintf('================================================================\n\n');

%% Network Configuration
networkConfig = struct();
networkConfig.inputSize = 784;        % MNIST: 28x28 images
networkConfig.hiddenSizes = [512, 256, 128];
networkConfig.outputSize = 10;        % 10 classes
networkConfig.totalParams = calculateTotalParams(networkConfig);

fprintf('Network Architecture:\n');
fprintf('  Input layer: %d units\n', networkConfig.inputSize);
fprintf('  Hidden layers: [%s] units\n', ...
        num2str(networkConfig.hiddenSizes));
fprintf('  Output layer: %d units\n', networkConfig.outputSize);
fprintf('  Total parameters: %s\n\n', ...
        formatNumber(networkConfig.totalParams));

%% Experimental Setup: Varying Dropout Rates
dropoutRates = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6];
numEpochs = 100;
batchSize = 128;
learningRate = 0.001;

% Simulated training results (in practice, run actual training)
% These would come from running your deep learning framework
trainingAccuracy = [99.5, 98.8, 97.5, 96.2, 94.5, 92.0, 88.5];
validationAccuracy = [97.2, 97.8, 98.1, 98.3, 98.2, 97.6, 96.5];
trainingLoss = [0.015, 0.035, 0.075, 0.115, 0.165, 0.240, 0.345];
validationLoss = [0.085, 0.065, 0.055, 0.050, 0.053, 0.070, 0.105];
convergenceEpochs = [30, 35, 42, 50, 58, 65, 75];

fprintf('Experimental Configuration:\n');
fprintf('  Dropout rates tested: %d configurations\n', ...
        length(dropoutRates));
fprintf('  Training epochs: %d\n', numEpochs);
fprintf('  Batch size: %d\n', batchSize);
fprintf('  Learning rate: %.4f\n\n', learningRate);

%% Part (a): Effective Network Capacity Analysis

fprintf('========================================\n');
fprintf('(a) Effective Network Capacity\n');
fprintf('========================================\n');

% Calculate expected active units per layer
fprintf('%-12s %-20s %-25s %-22s\n', 'Dropout p', 'Active Units (%%)', ...
        'Approx. Sub-networks', 'Capacity Factor');
fprintf('%s\n', repmat('-', 1, 82));

for i = 1:length(dropoutRates)
    p = dropoutRates(i);
    activePercent = (1 - p) * 100;
    
    % Number of possible sub-networks (simplified for hidden layer 1)
    n_units = networkConfig.hiddenSizes(1);
    % For computational reasons, show log of sub-networks
    logSubNetworks = n_units * log2(2);  % 2^n_units
    
    % Effective capacity (compound effect across layers)
    capacityFactor = (1 - p)^length(networkConfig.hiddenSizes);
    
    fprintf('%-12.1f %-20.1f %-25.1f %-22.3f\n', ...
            p, activePercent, logSubNetworks, capacityFactor);
end
fprintf('\n');

fprintf('INTERPRETATION:\n');
fprintf('  - With p=0.5, only 12.5%% of original capacity is active per pass\n');
fprintf('  - This forces learning of robust, redundant features\n');
fprintf('  - Effectively trains an ensemble of 2^n models\n\n');

%% Part (b): Overfitting Analysis

generalizationGap = trainingAccuracy - validationAccuracy;
overfittingScore = (trainingLoss - validationLoss) ./ trainingLoss * 100;

fprintf('========================================\n');
fprintf('(b) Overfitting and Generalization\n');
fprintf('========================================\n');
fprintf('%-12s %-18s %-20s %-25s %-20s\n', 'Dropout p', ...
        'Train Acc (%%)', 'Val Acc (%%)', 'Generalization Gap (%%)', 'Overfitting');
fprintf('%s\n', repmat('-', 1, 100));

for i = 1:length(dropoutRates)
    fprintf('%-12.1f %-18.1f %-20.1f %-25.2f ', ...
            dropoutRates(i), trainingAccuracy(i), ...
            validationAccuracy(i), generalizationGap(i));
    
    if generalizationGap(i) > 2
        fprintf('%-20s\n', 'HIGH');
    elseif generalizationGap(i) > 0.5
        fprintf('%-20s\n', 'MODERATE');
    else
        fprintf('%-20s\n', 'LOW');
    end
end
fprintf('\n');

% Find optimal dropout rate (minimize generalization gap while maintaining accuracy)
[~, optimalIdx] = max(validationAccuracy);
optimalDropout = dropoutRates(optimalIdx);

fprintf('OPTIMAL CONFIGURATION:\n');
fprintf('  Best dropout rate: %.1f\n', optimalDropout);
fprintf('  Validation accuracy: %.1f%%\n', validationAccuracy(optimalIdx));
fprintf('  Generalization gap: %.2f%%\n', generalizationGap(optimalIdx));
fprintf('  Training epochs to converge: %d\n\n', ...
        convergenceEpochs(optimalIdx));

%% Part (c): Training Dynamics

fprintf('========================================\n');
fprintf('(c) Training Convergence Dynamics\n');
fprintf('========================================\n');
fprintf('%-12s %-22s %-25s %-20s\n', 'Dropout p', ...
        'Convergence Time (epochs)', 'Slowdown vs No Dropout', 'Final Val Loss');
fprintf('%s\n', repmat('-', 1, 82));

baselineConvergence = convergenceEpochs(1);
for i = 1:length(dropoutRates)
    slowdown = convergenceEpochs(i) / baselineConvergence;
    
    fprintf('%-12.1f %-22d %-25.2fx %-20.4f\n', ...
            dropoutRates(i), convergenceEpochs(i), ...
            slowdown, validationLoss(i));
end
fprintf('\n');

fprintf('OBSERVATION:\n');
fprintf('  - Dropout increases training time by up to %.1fx\n', ...
        max(convergenceEpochs) / baselineConvergence);
fprintf('  - Trade-off: slower convergence for better generalization\n');
fprintf('  - Optimal p=%.1f balances speed and accuracy\n\n', optimalDropout);

%% Part (d): Gradient Variance Analysis

% Simulate gradient variance (higher dropout   higher variance)
gradientVariance = [1.0, 1.2, 1.5, 2.0, 2.8, 4.0, 6.5];
effectiveLearningRate = learningRate ./ sqrt(gradientVariance);

fprintf('========================================\n');
fprintf('(d) Gradient Variance and Learning Rate\n');
fprintf('========================================\n');
fprintf('%-12s %-25s %-28s %-25s\n', 'Dropout p', ...
        'Gradient Var (relative)', 'Effective LR (adjusted)', ...
        'LR Scaling Factor');
fprintf('%s\n', repmat('-', 1, 95));

for i = 1:length(dropoutRates)
    lrScaling = effectiveLearningRate(i) / learningRate;
    
    fprintf('%-12.1f %-25.2f %-28.6f %-25.3f\n', ...
            dropoutRates(i), gradientVariance(i), ...
            effectiveLearningRate(i), lrScaling);
end
fprintf('\n');

fprintf('IMPLICATION:\n');
fprintf('  - Higher dropout increases gradient noise\n');
fprintf('  - May require learning rate adjustment or longer training\n');
fprintf('  - Variance reduction techniques (gradient clipping) can help\n\n');

%% Part (e): Layer-wise Dropout Strategy

layerTypes = {'Input', 'Hidden-1', 'Hidden-2', 'Hidden-3', 'Output'};
recommendedDropout = [0.2, 0.5, 0.5, 0.5, 0.0];
reasoning = {'Light dropout for input features', ...
             'Standard dropout for capacity control', ...
             'Standard dropout for capacity control', ...
             'Standard dropout for capacity control', ...
             'No dropout to preserve predictions'};

fprintf('========================================\n');
fprintf('(e) Layer-wise Dropout Recommendations\n');
fprintf('========================================\n');
fprintf('%-15s %-20s %-50s\n', 'Layer', 'Dropout Rate', 'Reasoning');
fprintf('%s\n', repmat('-', 1, 88));

for i = 1:length(layerTypes)
    fprintf('%-15s %-20.1f %-50s\n', ...
            layerTypes{i}, recommendedDropout(i), reasoning{i});
end
fprintf('\n');

fprintf('BEST PRACTICES:\n');
fprintf('  1. Fully connected layers: p = 0.5 (standard)\n');
fprintf('  2. Convolutional layers: p = 0.1-0.2 (lower due to weight sharing)\n');
fprintf('  3. Recurrent layers: Apply to connections, not states\n');
fprintf('  4. Batch normalization layers: p = 0 (redundant regularization)\n');
fprintf('  5. Output layer: p = 0 (preserve prediction quality)\n\n');

%% Part (f): Comparison with Other Regularization Techniques

regularizationMethods = {'No Regularization', 'Dropout (p=0.5)', ...
                         'L2 Decay ( =1e-4)', 'L1 Sparsity ( =1e-4)', ...
                         'Data Augmentation', 'Early Stopping', ...
                         'Dropout + L2'};

% Simulated comparison results
valAccuracies = [97.2, 98.3, 97.8, 97.5, 98.5, 97.9, 98.7];
trainingTimes = [1.0, 1.8, 1.1, 1.2, 2.5, 0.8, 2.0];
implementationComplexity = {'Simple', 'Simple', 'Simple', 'Moderate', ...
                            'Complex', 'Simple', 'Moderate'};

fprintf('========================================\n');
fprintf('(f) Regularization Technique Comparison\n');
fprintf('========================================\n');
fprintf('%-25s %-18s %-22s %-20s\n', 'Method', 'Val Acc (%%)', ...
        'Training Time (rel.)', 'Complexity');
fprintf('%s\n', repmat('-', 1, 88));

for i = 1:length(regularizationMethods)
    fprintf('%-25s %-18.1f %-22.1fx %-20s\n', ...
            regularizationMethods{i}, valAccuracies(i), ...
            trainingTimes(i), implementationComplexity{i});
end
fprintf('\n');

fprintf('RECOMMENDATION:\n');
fprintf('  Best single method: Data Augmentation (%.1f%% accuracy)\n', ...
        max(valAccuracies));
fprintf('  Best combined: Dropout + L2 (%.1f%% accuracy)\n', ...
        valAccuracies(end));
fprintf('  Fastest: Early Stopping (%.1fx training time)\n', ...
        trainingTimes(6));
fprintf('  Production choice: Dropout + Data Aug + Early Stopping\n\n');

%% Visualization: Comprehensive Analysis

figure('Position', [50, 50, 1600, 900], 'Color', 'w');

% Panel 1: Accuracy vs Dropout Rate
subplot(2, 3, 1);
plot(dropoutRates, trainingAccuracy, 'b-o', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'MarkerFaceColor', 'b');
hold on;
plot(dropoutRates, validationAccuracy, 'r-s', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'MarkerFaceColor', 'r');
plot(optimalDropout, validationAccuracy(optimalIdx), 'g*', ...
     'MarkerSize', 20, 'LineWidth', 3);

xlabel('Dropout Rate $p$', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(a) Accuracy vs Dropout}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend({'Training', 'Validation', 'Optimal'}, 'Interpreter', 'latex', ...
       'Location', 'southwest', 'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);
xlim([0, 0.65]);

% Panel 2: Generalization Gap
subplot(2, 3, 2);
bar(dropoutRates, generalizationGap, 'FaceColor', [0.8, 0.4, 0.2], ...
    'EdgeColor', 'k', 'LineWidth', 1.5);
hold on;
yline(0, 'g-', 'LineWidth', 2);

xlabel('Dropout Rate $p$', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Generalization Gap (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(b) Overfitting Reduction}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 3: Training Convergence
subplot(2, 3, 3);
yyaxis left
plot(dropoutRates, convergenceEpochs, 'b-o', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'MarkerFaceColor', 'b');
ylabel('Epochs to Converge', 'Interpreter', 'latex', 'FontSize', 13);

yyaxis right
plot(dropoutRates, validationLoss, 'r-s', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'MarkerFaceColor', 'r');
ylabel('Validation Loss', 'Interpreter', 'latex', 'FontSize', 13);

xlabel('Dropout Rate $p$', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(c) Convergence Dynamics}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 4: Gradient Variance
subplot(2, 3, 4);
semilogy(dropoutRates, gradientVariance, 'b-o', 'LineWidth', 2.5, ...
         'MarkerSize', 10, 'MarkerFaceColor', 'b');

xlabel('Dropout Rate $p$', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Gradient Variance (log scale)', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(d) Gradient Noise}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 5: Effective Learning Rate
subplot(2, 3, 5);
plot(dropoutRates, effectiveLearningRate, 'g-o', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'MarkerFaceColor', 'g');
hold on;
yline(learningRate, 'r-', 'LineWidth', 2, 'Label', 'Base LR', ...
      'Interpreter', 'latex');

xlabel('Dropout Rate $p$', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Effective Learning Rate', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(e) LR Adjustment}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 6: Method Comparison
subplot(2, 3, 6);
bar(valAccuracies, 'FaceColor', [0.3, 0.6, 0.3], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);

ylabel('Validation Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(f) Regularization Comparison}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', {'None', 'Drop', 'L2', 'L1', 'Aug', 'ES', 'D+L2'}, ...
         'FontSize', 11);
grid on; box on;
ylim([96.5, 99]);

%% Helper Functions

function totalParams = calculateTotalParams(config)
    totalParams = 0;
    
    % Input to first hidden
    totalParams = totalParams + config.inputSize * config.hiddenSizes(1);
    
    % Hidden to hidden
    for i = 1:length(config.hiddenSizes)-1
        totalParams = totalParams + ...
            config.hiddenSizes(i) * config.hiddenSizes(i+1);
    end
    
    % Last hidden to output
    totalParams = totalParams + ...
        config.hiddenSizes(end) * config.outputSize;
    
    % Add biases
    totalParams = totalParams + sum(config.hiddenSizes) + config.outputSize;
end

function str = formatNumber(num)
    if num >= 1e9
        str = sprintf('%.2fB', num/1e9);
    elseif num >= 1e6
        str = sprintf('%.2fM', num/1e6);
    elseif num >= 1e3
        str = sprintf('%.2fK', num/1e3);
    else
        str = sprintf('%d', num);
    end
end
