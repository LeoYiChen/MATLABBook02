%% chapter_DataVisualisation_advanced.m
% Advanced Customisation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_advanced
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function customiseResearchPlot(h)
% Input: handle to figure
% Set consistent fonts
set(findall(h, 'Type', 'text'), ...
    'FontName', 'Times New Roman', ...
    'FontSize', 10);

% Enhance axes
ax = findall(h, 'Type', 'axes');
for i = 1:length(ax)
    % Set box properties
    set(ax(i), 'Box', 'on', ...
               'LineWidth', 1.5, ...
               'TickDir', 'out', ...
               'TickLength', [0.02 0.02]);
    
    % Adjust tick labels
    set(ax(i), 'TickLabelInterpreter', 'latex');
    
    % Set aspect ratio
    pbaspect(ax(i), [1 1 1]);
    
    % Add minor grid
    grid(ax(i), 'minor');
    set(ax(i), 'Layer', 'top');
end

% Export settings
set(h, 'PaperPositionMode', 'auto');
set(h, 'InvertHardcopy', 'off');
end
