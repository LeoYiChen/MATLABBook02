%% ch08_prob7_code.m
% Parallel vs.\ serial feature extraction benchmark (MATLABBook02_Chapter08_Problem7.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob7_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem7.m
% --------------------------------
% Purpose : Benchmark parfor vs for loop for feature extraction.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later; Parallel Computing Toolbox required
% --------------------------------
clc; clear; close all;

%% Step 1 - Generate synthetic signal segments
fprintf('=== Step 1: Generating synthetic signal segments ===\n');
rng(42, 'twister');
numSegments    = 50000;
samplesPerSeg  = 1024;
signalSegments = cell(numSegments, 1);

for segIdx = 1:numSegments
    frequency = 5 + rand * 45;          % 5-50 Hz
    noiseLevel = 0.1 + rand * 0.9;
    timeVector = linspace(0, 1, samplesPerSeg);
    signalSegments{segIdx} = sin(2*pi*frequency*timeVector) + ...
        noiseLevel * randn(1, samplesPerSeg);
end
fprintf('  Generated %d segments (%d samples each).\n', ...
    numSegments, samplesPerSeg);

%% Step 2 - Define feature-extraction function
% (Embedded as a local function at end of script; see below.)

%% Step 3 - Serial feature extraction
fprintf('\n=== Step 3: Serial feature extraction (for loop) ===\n');
serialFeatures = zeros(numSegments, 4);
tic;
for segIdx = 1:numSegments
    serialFeatures(segIdx, :) = ...
        extractSignalFeatures(signalSegments{segIdx});
end
serialTime = toc;
fprintf('  Serial time: %.4f seconds\n', serialTime);

%% Step 4 - Parallel feature extraction
fprintf('\n=== Step 4: Parallel feature extraction (parfor) ===\n');
currentPool = gcp('nocreate');
if isempty(currentPool)
    currentPool = parpool('local');
end
fprintf('  Parallel pool: %d workers\n', currentPool.NumWorkers);

parallelFeatures = zeros(numSegments, 4);
tic;
parfor segIdx = 1:numSegments
    parallelFeatures(segIdx, :) = ...
        extractSignalFeatures(signalSegments{segIdx});
end
parallelTime = toc;
fprintf('  Parallel time: %.4f seconds\n', parallelTime);

%% Step 5 - Compute speed-up ratio
speedUpRatio = serialTime / parallelTime;
fprintf('\n=== Step 5: Speed-up ratio ===\n');
fprintf('  Speed-up: %.2fx (with %d workers)\n', ...
    speedUpRatio, currentPool.NumWorkers);

%% Step 6 - Verify results match
maxDifference = max(abs(serialFeatures(:) - parallelFeatures(:)));
fprintf('\n=== Step 6: Verification ===\n');
fprintf('  Max absolute difference: %.2e\n', maxDifference);
if maxDifference < 1e-10
    fprintf('  PASS: Serial and parallel results are identical.\n');
else
    fprintf('  WARNING: Results differ beyond tolerance.\n');
end

%% Step 7 - Display sample features
fprintf('\n-- Sample Features (first 5 segments) --\n');
fprintf('  %8s  %10s  %10s  %10s  %10s\n', ...
    'Segment', 'Mean', 'Variance', 'Skewness', 'Kurtosis');
for segIdx = 1:5
    fprintf('  %8d  %10.4f  %10.4f  %10.4f  %10.4f\n', ...
        segIdx, parallelFeatures(segIdx, 1), ...
        parallelFeatures(segIdx, 2), ...
        parallelFeatures(segIdx, 3), ...
        parallelFeatures(segIdx, 4));
end

%% Step 8 - Visualise benchmark comparison
figBenchmark = figure('Name', 'Parallel Benchmark', ...
    'Position', [100 100 900 500]);

subplot(1, 2, 1);
barData = [serialTime, parallelTime];
barHandle = bar(barData, 0.5);
barHandle.FaceColor = 'flat';
barHandle.CData(1, :) = [0.85 0.33 0.10];
barHandle.CData(2, :) = [0.00 0.45 0.74];
set(gca, 'XTickLabel', {'Serial (\texttt{for})', ...
    'Parallel (\texttt{parfor})'}, ...
    'TickLabelInterpreter', 'latex');
ylabel('Elapsed Time (s)', 'Interpreter', 'latex');
title('\textbf{Execution Time Comparison}', ...
    'Interpreter', 'latex', 'FontSize', 12);
grid on;
text(1, serialTime * 1.05, sprintf('%.2f s', serialTime), ...
    'HorizontalAlignment', 'center', 'FontSize', 10);
text(2, parallelTime * 1.05, sprintf('%.2f s', parallelTime), ...
    'HorizontalAlignment', 'center', 'FontSize', 10);

subplot(1, 2, 2);
barSpeedUp = bar(speedUpRatio, 0.4);
barSpeedUp.FaceColor = [0.47 0.67 0.19];
set(gca, 'XTickLabel', {'Speed-Up'}, ...
    'TickLabelInterpreter', 'latex');
ylabel('Speed-Up Ratio ($S$)', 'Interpreter', 'latex');
title(sprintf('\\textbf{Speed-Up: %.2f$\\times$ (%d Workers)}', ...
    speedUpRatio, currentPool.NumWorkers), ...
    'Interpreter', 'latex', 'FontSize', 12);
grid on;
text(1, speedUpRatio * 1.05, sprintf('%.2fx', speedUpRatio), ...
    'HorizontalAlignment', 'center', 'FontSize', 11, ...
    'FontWeight', 'bold');

sgtitle('\textbf{Serial vs.\ Parallel Feature Extraction}', ...
    'Interpreter', 'latex', 'FontSize', 14);

savefig(figBenchmark, 'Ch08_Problem7_ParallelBenchmark.fig');
exportgraphics(figBenchmark, ...
    'Ch08_Problem7_ParallelBenchmark.eps', 'ContentType', 'vector');
exportgraphics(figBenchmark, ...
    'Ch08_Problem7_ParallelBenchmark.jpg', 'Resolution', 300);
fprintf('\n=== Figures saved (.fig, .eps, .jpg) ===\n');

fprintf('\n=== Problem 7 Complete ===\n');

%% Local function
function featureVector = extractSignalFeatures(signalData)
% extractSignalFeatures  Compute four statistical features.
%   featureVector = extractSignalFeatures(signalData)
%   Returns [mean, variance, skewness, kurtosis].
    featureVector = [ mean(signalData), ...
                      var(signalData), ...
                      skewness(signalData), ...
                      kurtosis(signalData) ];
end
% --------------------------------
% Computational Complexity:
% Each feature-extraction call processes S samples, computing four
% statistics each in O(S). For N segments the serial loop is
% O(N * S). The parfor distributes iterations across W workers,
% yielding wall-clock O(N * S / W) plus overhead for data transfer
% and task scheduling. Amdahl's Law limits the achievable speed-up
% to S_max = 1 / (f + (1-f)/W), where f is the serial fraction
% (here near zero). Memory: O(N * S) for storing all segments.
% --------------------------------
