%% chapter_DataVisualisation_network.m
% Network Visualization Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_network
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create sample adjacency matrix
n = 10;
A = rand(n) < 0.3;
A = triu(A,1) + triu(A,1)';

% Plot network
figure('Position', [100 100 800 800]);
G = graph(A);
plot(G, 'Layout', 'force', ...
'NodeColor', 'b', ...
'EdgeColor', 'k', ...
'LineWidth', 2);
title('Network Structure Analysis');

% Export figure in multiple formats
exportFigure(gca, 'Network_plot');

