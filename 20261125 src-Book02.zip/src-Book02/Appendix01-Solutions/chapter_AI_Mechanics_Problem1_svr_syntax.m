%% chapter_AI_Mechanics_Problem1_svr_syntax.m
% Support Vector Regression syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem1_svr_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Train SVR with RBF kernel
svrModel = fitrsvm(featuresTrain, targetTrain, ...
    'KernelFunction', 'rbf', ...       % Radial basis function kernel
    'KernelScale', 'auto', ...         % Automatic sigma estimation
    'BoxConstraint', 10, ...           % C parameter (regularisation)
    'Epsilon', 0.01, ...               % Epsilon for epsilon-SVR
    'Standardize', true);              % Standardise predictors

% Predict
predictionsSVR = predict(svrModel, featuresTest);
