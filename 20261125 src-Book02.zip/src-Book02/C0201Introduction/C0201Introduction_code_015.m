%% C0201Introduction_code_015.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Diagnosis
A = [1, 2, 3; 2, 4, 6; 3, 6, 9];  % Singular (rows are multiples)
det_A = det(A);  % Returns ~0
rank_A = rank(A);  % Returns < size(A,1)
cond_A = cond(A);  % Returns Inf

% Solutions:
% 1. Check for linear dependencies
fprintf('Matrix rank: %d (should be %d)\n', rank_A, size(A,1));

% 2. Use pseudo-inverse for least-squares solution
x = pinv(A) * b;

% 3. Add regularisation (Ridge regression)
lambda = 1e-6;
x = (A'*A + lambda*eye(size(A,2))) \ (A'*b);

% 4. Singular Value Decomposition
[U, S, V] = svd(A);
fprintf('Singular values: ');
fprintf('%.2e ', diag(S));
fprintf('\n');

% Remove near-zero singular values
tolerance = 1e-10;
S_inv = diag(1./diag(S));
S_inv(S_inv > 1/tolerance) = 0;
x = V * S_inv * U' * b;
