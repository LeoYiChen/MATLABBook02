%% chapter_Math_example_rootFinding.m
% Root-finding methods implementation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_rootFinding
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Implement bisection method for root finding

% Implement Newton's method

% Demonstration: find roots of f(x) = x^3 - 2*x - 5
% This function has one real root near x = 2

% Define function and derivative
f = @(x) x.^3 - 2*x - 5;
df = @(x) 3*x.^2 - 2;

fprintf('Root Finding Demonstration\n');
fprintf('==========================\n\n');

% Bisection method
fprintf('Bisection Method:\n');
[root1, iter1] = bisectionMethod(f, 1, 3, 1e-6);
fprintf('  Root: %.10f\n', root1);
fprintf('  Iterations: %d\n', iter1);
fprintf('  f(root): %.2e\n\n', f(root1));

% Newton's method
fprintf('Newtons Method:\n');
[root2, iter2] = newtonMethod(f, df, 2, 1e-10, 100);
fprintf('  Root: %.10f\n', root2);
fprintf('  Iterations: %d\n', iter2);
fprintf('  f(root): %.2e\n\n', f(root2));

% Visualise function and roots
figure('Position', [100, 100, 800, 600]);
x = linspace(1, 3, 1000);
y = f(x);

plot(x, y, 'b-', 'LineWidth', 2);
hold on;
plot(x, zeros(size(x)), 'k--', 'LineWidth', 1);
plot(root1, f(root1), 'ro', 'MarkerSize', 12, 'LineWidth', 2);
plot(root2, f(root2), 'gs', 'MarkerSize', 12, 'LineWidth', 2);

xlabel('x');
ylabel('f(x)');
title('Root Finding: f(x) = x^3 - 2*x - 5');
legend('f(x)', 'y=0', 'Bisection Root', 'Newton Root', ...
    'Location', 'best');
grid on;

% Compare with MATLAB's built-in function
root_builtin = fzero(f, 2);
fprintf('MATLAB fzero result: %.10f\n', root_builtin);
fprintf('f(root): %.2e\n', f(root_builtin));

% Local functions (moved to end so this listing is a valid MATLAB script)
function [root, iterations] = bisectionMethod(func, a, b, tolerance)
    % BISECTIONMETHOD Find root of function using bisection
    %   [root, iterations] = bisectionMethod(func, a, b, tolerance)
    %   finds root of func in interval [a, b] to specified tolerance
    %
    %   Inputs:
    %       func - function handle or anonymous function
    %       a, b - interval endpoints (func(a) and func(b) must have opposite signs)
    %       tolerance - desired accuracy
    %   Outputs:
    %       root - approximate root
    %       iterations - number of iterations performed
    
    % Verify opposite signs
    if func(a) * func(b) > 0
        error('Function must have opposite signs at interval endpoints');
    end
    
    iterations = 0;
    maxIterations = 1000;
    
    while (b - a) / 2 > tolerance && iterations < maxIterations
        % Compute midpoint
        c = (a + b) / 2;
        
        % Evaluate function at midpoint
        fc = func(c);
        
        % Update interval
        if fc == 0
            % Found exact root
            root = c;
            return;
        elseif func(a) * fc < 0
            % Root in left half
            b = c;
        else
            % Root in right half
            a = c;
        end
        
        iterations = iterations + 1;
    end
    
    root = (a + b) / 2;
end

function [root, iterations] = newtonMethod(func, dfunc, x0, tolerance, maxIter)
    % NEWTONMETHOD Find root using Newton's method
    %   [root, iterations] = newtonMethod(func, dfunc, x0, tolerance, maxIter)
    %   finds root starting from x0
    %
    %   Inputs:
    %       func - function handle
    %       dfunc - derivative function handle
    %       x0 - initial guess
    %       tolerance - desired accuracy
    %       maxIter - maximum iterations
    
    x = x0;
    iterations = 0;
    
    while iterations < maxIter
        % Evaluate function and derivative
        fx = func(x);
        dfx = dfunc(x);
        
        % Check for convergence
        if abs(fx) < tolerance
            root = x;
            return;
        end
        
        % Check for zero derivative
        if abs(dfx) < eps
            error('Derivative too small - method fails');
        end
        
        % Newton iteration
        x = x - fx / dfx;
        iterations = iterations + 1;
    end
    
    root = x;
    warning('Maximum iterations reached');
end
