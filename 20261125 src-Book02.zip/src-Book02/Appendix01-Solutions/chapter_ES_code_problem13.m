%% chapter_ES_code_problem13.m
% RL for Wind Farm Control
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem13
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem13
    % MATLABBook_ChapterES_Problem13.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Reinforcement learning for wind farm power optimization.
    %   Implements DQN agent, wake modeling, multi-turbine coordination,
    %   and comparison with baseline control strategies.
    %
    % Dependencies: Reinforcement Learning Toolbox (for rlDQNAgent)
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 13
    
    fprintf('\n=== Problem 13: RL for Wind Farm Optimization ===\n\n');
    
    %% Wind Farm Configuration
    
    % Number of turbines
    N_turbines = 5;
    
    % Turbine layout (5 turbines in a row, spaced 5D apart)
    D_rotor = 80;  % Rotor diameter (m)
    spacing = 5 * D_rotor;  % Turbine spacing
    
    turbine_x = (0:N_turbines-1) * spacing;
    turbine_y = zeros(1, N_turbines);
    
    fprintf('Wind farm setup:\n');
    fprintf('  Number of turbines: %d\n', N_turbines);
    fprintf('  Layout: Linear array, %.0f m spacing\n', spacing);
    fprintf('  Rotor diameter: %.0f m\n\n', D_rotor);
    
    %% Physical Parameters
    
    % Air properties
    rho = 1.225;  % Air density (kg/m)
    
    % Turbine properties
    P_rated = 5e6;  % Rated power (5 MW)
    U_rated = 11;  % Rated wind speed (m/s)
    U_cutin = 3;  % Cut-in wind speed (m/s)
    U_cutout = 25;  % Cut-out wind speed (m/s)
    
    % Wake parameters (Jensen model)
    C_T = 0.8;  % Thrust coefficient
    alpha_wake = 0.04;  % Wake expansion coefficient
    
    fprintf('Turbine specifications:\n');
    fprintf('  Rated power: %.1f MW\n', P_rated/1e6);
    fprintf('  Operating range: %.0f - %.0f m/s\n', U_cutin, U_cutout);
    fprintf('  Thrust coefficient: %.2f\n\n', C_T);
    
    %% Baseline Power Curve
    
    % Power coefficient (simplified model)
    % C_P as function of tip-speed ratio and pitch (Gaussian approximation)
    C_P_max = 0.45;  % Maximum power coefficient
    
    % Power curve (function of wind speed, ignoring pitch for simplicity)
    compute_power = @(U) min(P_rated, ...
                             0.5 * rho * pi * (D_rotor/2)^2 * C_P_max * U.^3) .* ...
                         (U >= U_cutin) .* (U <= U_cutout);
    
    %% Wake Model Implementation
    
    function U_eff = compute_wake_effects(U_inf, theta_wind, yaw_angles)
        % Compute effective wind speed at each turbine considering wakes
        
        % Initialize effective velocities
        U_eff = U_inf * ones(1, N_turbines);
        
        % Wind direction (0 = aligned with turbine row)
        cos_theta = cosd(theta_wind);
        sin_theta = sind(theta_wind);
        
        % For each turbine, check if it's in wake of upstream turbines
        for i = 1:N_turbines
            for j = 1:N_turbines
                if i ~= j
                    % Vector from turbine j to i (in wind reference frame)
                    dx = turbine_x(i) - turbine_x(j);
                    dy = turbine_y(i) - turbine_y(j);
                    
                    % Downwind and crosswind distances
                    x_down = dx * cos_theta + dy * sin_theta;
                    y_cross = -dx * sin_theta + dy * cos_theta;
                    
                    % Check if i is downwind of j
                    if x_down > 0
                        % Yaw of turbine j (wake deflection)
                        gamma_j = yaw_angles(j);
                        
                        % Wake deflection due to yaw
                        delta_y = x_down * tand(gamma_j);
                        
                        % Lateral distance from wake centerline
                        y_wake = abs(y_cross - delta_y);
                        
                        % Wake radius at distance x_down
                        r_wake = D_rotor/2 + alpha_wake * x_down;
                        
                        % Check if turbine i is within wake
                        if y_wake < r_wake
                            % Velocity deficit (Jensen model)
                            a = 0.5 * (1 - sqrt(1 - C_T * cosd(gamma_j)^2));
                            U_deficit = U_inf * (1 - 2*a / (1 + alpha_wake * x_down / D_rotor)^2);
                            
                            % Partial wake overlap (Gaussian weighting)
                            overlap = exp(-(y_wake / r_wake)^2);
                            
                            % Accumulate deficit (quadratic sum)
                            U_eff(i) = U_eff(i) - sqrt((U_inf - U_deficit)^2 * overlap);
                        end
                    end
                end
            end
        end
        
        % Ensure non-negative
        U_eff = max(U_eff, 0);
    end
    
    %% Environment Setup (Simplified for Demonstration)
    
    fprintf('=== Environment Setup ===\n');
    
    % State: [U_inf, theta_wind, P_1, ..., P_N, yaw_1, ..., yaw_N]
    % Action: Discretized yaw adjustments for each turbine
    
    % Wind conditions (will vary during episodes)
    U_inf_mean = 10;  % Mean wind speed (m/s)
    theta_wind = 0;  % Wind direction (deg, aligned with turbine row)
    
    % Action space: yaw adjustments {-10 , 0 , +10 } for each turbine
    yaw_actions = [-10, 0, 10];
    n_actions_per_turbine = length(yaw_actions);
    n_actions_total = n_actions_per_turbine ^ N_turbines;  % Combinatorial
    
    fprintf('State space dimension: %d (wind + power + yaw)\n', 2 + 2*N_turbines);
    fprintf('Action space: %d discrete actions (%d^%d combinations)\n\n', ...
            n_actions_total, n_actions_per_turbine, N_turbines);
    
    % For tractability, simplify to controlling only first turbine
    % (Generalize to multi-agent RL for full control)
    fprintf('Simplified control: Yaw of first turbine only\n');
    fprintf('Action space reduced to: %d actions\n\n', n_actions_per_turbine);
    
    %% Baseline Control Strategies
    
    fprintf('=== Baseline Control Strategies ===\n');
    
    % Strategy 1: Greedy (all turbines at yaw=0, aligned with wind)
    yaw_greedy = zeros(1, N_turbines);
    
    % Strategy 2: Static optimal (pre-computed optimal yaw for this layout)
    % For linear array with wind aligned, optimal is slight yaw of upstream
    yaw_optimal = [25, 0, 0, 0, 0];  % Empirical (would optimize offline)
    
    % Evaluate baselines
    U_greedy = compute_wake_effects(U_inf_mean, theta_wind, yaw_greedy);
    P_greedy = compute_power(U_greedy);
    P_total_greedy = sum(P_greedy);
    
    U_optimal = compute_wake_effects(U_inf_mean, theta_wind, yaw_optimal);
    P_optimal = compute_power(U_optimal);
    P_total_optimal = sum(P_optimal);
    
    fprintf('Greedy (yaw=0 ):\n');
    fprintf('  Total power: %.2f MW\n', P_total_greedy/1e6);
    fprintf('  Turbine powers: ');
    fprintf('%.2f ', P_greedy/1e6);
    fprintf('MW\n');
    
    fprintf('Static optimal (yaw=[25,0,0,0,0] ):\n');
    fprintf('  Total power: %.2f MW\n', P_total_optimal/1e6);
    fprintf('  Improvement: %.1f%%\n', (P_total_optimal/P_total_greedy - 1)*100);
    fprintf('  Turbine powers: ');
    fprintf('%.2f ', P_optimal/1e6);
    fprintf('MW\n\n');
    
    %% Q-Learning (Tabular - Simplified)
    
    fprintf('=== Q-Learning Training ===\n');
    
    % Discretize state space
    % State: [U_inf (discretized), yaw_1 (discretized)]
    U_bins = [5, 8, 10, 12, 15];  % Wind speed bins
    yaw_bins = -30:10:30;  % Yaw angle bins
    
    n_states = length(U_bins) * length(yaw_bins);
    n_actions = n_actions_per_turbine;
    
    % Initialize Q-table
    Q = zeros(n_states, n_actions);
    
    % Hyperparameters
    alpha = 0.1;  % Learning rate
    gamma_rl = 0.95;  % Discount factor
    epsilon = 0.1;  % Exploration rate
    
    n_episodes = 500;
    max_steps = 50;
    
    % Tracking
    rewards_per_episode = zeros(n_episodes, 1);
    
    fprintf('Training Q-learning agent:\n');
    fprintf('  Episodes: %d, Steps per episode: %d\n', n_episodes, max_steps);
    fprintf('  Learning rate: %.2f, Discount: %.2f, Epsilon: %.2f\n\n', ...
            alpha, gamma_rl, epsilon);
    
    for ep = 1:n_episodes
        % Reset environment (random initial wind speed)
        U_inf = U_bins(randi(length(U_bins)));
        yaw_current = yaw_bins(randi(length(yaw_bins)));
        
        % State index
        [~, u_idx] = min(abs(U_bins - U_inf));
        [~, yaw_idx] = min(abs(yaw_bins - yaw_current));
        s = (u_idx-1) * length(yaw_bins) + yaw_idx;
        
        ep_reward = 0;
        
        for step = 1:max_steps
            % Epsilon-greedy action selection
            if rand() < epsilon
                a = randi(n_actions);  % Explore
            else
                [~, a] = max(Q(s, :));  % Exploit
            end
            
            % Execute action (adjust yaw of first turbine)
            yaw_delta = yaw_actions(a);
            yaw_new = yaw_current + yaw_delta;
            yaw_new = max(-30, min(30, yaw_new));  % Clamp to limits
            
            % Update farm configuration
            yaw_farm = [yaw_new, zeros(1, N_turbines-1)];
            
            % Compute wake effects and power
            U_eff = compute_wake_effects(U_inf, theta_wind, yaw_farm);
            P_turbines = compute_power(U_eff);
            P_total = sum(P_turbines);
            
            % Reward: normalized total power
            r = P_total / (N_turbines * P_rated);
            
            % Add penalty for excessive yaw (wear)
            r = r - 0.01 * abs(yaw_delta) / 10;
            
            ep_reward = ep_reward + r;
            
            % Next state (wind may change)
            if rand() < 0.1  % 10% chance of wind speed change
                U_inf = U_bins(randi(length(U_bins)));
            end
            
            [~, u_idx_next] = min(abs(U_bins - U_inf));
            [~, yaw_idx_next] = min(abs(yaw_bins - yaw_new));
            s_next = (u_idx_next-1) * length(yaw_bins) + yaw_idx_next;
            
            % Q-learning update
            Q(s, a) = Q(s, a) + alpha * (r + gamma_rl * max(Q(s_next, :)) - Q(s, a));
            
            % Transition
            s = s_next;
            yaw_current = yaw_new;
        end
        
        rewards_per_episode(ep) = ep_reward;
        
        if mod(ep, 100) == 0
            fprintf('Episode %d: Average reward = %.3f\n', ep, mean(rewards_per_episode(ep-99:ep)));
        end
    end
    
    fprintf('\nTraining completed.\n');
    fprintf('Final 100-episode average reward: %.3f\n\n', mean(rewards_per_episode(end-99:end)));
    
    %% Evaluation
    
    fprintf('=== Policy Evaluation ===\n');
    
    % Extract learned policy
    [~, policy] = max(Q, [], 2);
    
    % Test on fixed wind condition
    U_test = 10;  % m/s
    yaw_init = 0;
    
    [~, u_idx] = min(abs(U_bins - U_test));
    [~, yaw_idx] = min(abs(yaw_bins - yaw_init));
    s_test = (u_idx-1) * length(yaw_bins) + yaw_idx;
    
    a_learned = policy(s_test);
    yaw_learned = yaw_init + yaw_actions(a_learned);
    
    yaw_farm_learned = [yaw_learned, zeros(1, N_turbines-1)];
    U_learned = compute_wake_effects(U_test, theta_wind, yaw_farm_learned);
    P_learned = compute_power(U_learned);
    P_total_learned = sum(P_learned);
    
    fprintf('Learned policy (yaw=[%.0f,0,0,0,0] ):\n', yaw_learned);
    fprintf('  Total power: %.2f MW\n', P_total_learned/1e6);
    fprintf('  vs Greedy: %.1f%%\n', (P_total_learned/P_total_greedy - 1)*100);
    fprintf('  vs Static optimal: %.1f%%\n\n', (P_total_learned/P_total_optimal - 1)*100);
    
    %% Visualization
    
    fprintf('Generating visualizations...\n');
    
    % Figure 1: Learning curve
    figure('Position', [50 50 1400 600]);
    
    subplot(1, 2, 1);
    plot(1:n_episodes, rewards_per_episode, 'b-', 'LineWidth', 1);
    hold on;
    % Moving average
    window = 50;
    rewards_smooth = movmean(rewards_per_episode, window);
    plot(1:n_episodes, rewards_smooth, 'r-', 'LineWidth', 2);
    hold off;
    xlabel('Episode', 'Interpreter', 'latex');
    ylabel('Total Reward', 'Interpreter', 'latex');
    title('Q-Learning Training Progress', 'Interpreter', 'latex');
    legend({'Raw', sprintf('%d-episode MA', window)}, 'Location', 'southeast', ...
           'Interpreter', 'latex');
    grid on;
    
    % Figure 2: Power comparison
    subplot(1, 2, 2);
    strategies = {'Greedy', 'Static Opt.', 'RL Learned'};
    powers = [P_total_greedy, P_total_optimal, P_total_learned] / 1e6;
    
    bar(categorical(strategies), powers, 'FaceColor', [0.3 0.6 0.9]);
    ylabel('Total Power (MW)', 'Interpreter', 'latex');
    title('Control Strategy Comparison', 'Interpreter', 'latex');
    grid on;
    
    % Add percentage labels
    for i = 1:length(powers)
        text(i, powers(i), sprintf('%.2f MW', powers(i)), ...
             'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom');
    end
    
    sgtitle('Reinforcement Learning for Wind Farm Control', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    % Figure 2: Wake visualization
    figure('Position', [100 100 1200 800]);
    
    % Define grid for wake field
    x_grid = linspace(0, max(turbine_x) + 500, 200);
    y_grid = linspace(-500, 500, 100);
    [X_grid, Y_grid] = meshgrid(x_grid, y_grid);
    
    % Compute wake field for each strategy
    strategies_yaw = {yaw_greedy, yaw_optimal, yaw_farm_learned};
    strategy_names = {'Greedy (yaw=0 )', 'Static Optimal', 'RL Learned'};
    
    for s_idx = 1:3
        subplot(3, 1, s_idx);
        
        yaw_config = strategies_yaw{s_idx};
        
        % Initialize velocity field
        U_field = U_test * ones(size(X_grid));
        
        % Subtract wake deficits
        for i = 1:N_turbines
            for ix = 1:length(x_grid)
                for iy = 1:length(y_grid)
                    dx = x_grid(ix) - turbine_x(i);
                    dy = y_grid(iy) - turbine_y(i);
                    
                    if dx > 0  % Downwind
                        % Wake deflection
                        delta_y = dx * tand(yaw_config(i));
                        y_wake = abs(dy - delta_y);
                        
                        % Wake radius
                        r_wake = D_rotor/2 + alpha_wake * dx;
                        
                        if y_wake < r_wake
                            a = 0.5 * (1 - sqrt(1 - C_T * cosd(yaw_config(i))^2));
                            U_deficit = U_test * 2*a / (1 + alpha_wake * dx / D_rotor)^2;
                            overlap = exp(-(y_wake / r_wake)^2);
                            
                            U_field(iy, ix) = U_field(iy, ix) - U_deficit * overlap;
                        end
                    end
                end
            end
        end
        
        % Plot velocity field
        contourf(X_grid, Y_grid, U_field, 20, 'LineStyle', 'none');
        colormap(jet);
        colorbar;
        hold on;
        
        % Plot turbines
        scatter(turbine_x, turbine_y, 200, 'k', 'filled', 'MarkerEdgeColor', 'w', 'LineWidth', 2);
        
        % Show yaw angles (arrows)
        for i = 1:N_turbines
            arrow_len = 50;
            dx_arrow = arrow_len * cosd(yaw_config(i));
            dy_arrow = arrow_len * sind(yaw_config(i));
            quiver(turbine_x(i), turbine_y(i), dx_arrow, dy_arrow, 0, ...
                   'r', 'LineWidth', 2, 'MaxHeadSize', 0.5);
        end
        
        hold off;
        xlabel('x (m)', 'Interpreter', 'latex');
        ylabel('y (m)', 'Interpreter', 'latex');
        title(sprintf('%s: P_{total} = %.2f MW', strategy_names{s_idx}, powers(s_idx)), ...
              'Interpreter', 'latex');
        axis equal tight;
    end
    
    sgtitle('Wake Structure Comparison', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Visualizations generated.\n\n');
end
