%% chapter_DataVisualisation_confusion.m
% Confusion Matrix Plot
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_confusion
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createConfusionMatrix(true_labels, predicted_labels, class_names)
% Calculate confusion matrix
cm = confusionmat(true_labels, predicted_labels);

% Create figure
h = figure('Position', [100 100 800 600]);

% Normalize matrix
cm_normalized = cm ./ sum(cm, 2);

% Create heatmap
imagesc(cm_normalized);
colormap('copper');
colorbar;

% Add text annotations
[m,n] = size(cm);
for i = 1:m
    for j = 1:n
        text(j, i, sprintf('%.1f%%\n(%d)', ...
             cm_normalized(i,j)*100, cm(i,j)), ...
             'HorizontalAlignment', 'center', ...
             'Color', 'white');
    end
end

% Customize appearance
set(gca, 'XTick', 1:length(class_names), ...
        'XTickLabel', class_names, ...
        'YTick', 1:length(class_names), ...
        'YTickLabel', class_names);
xtickangle(45);

xlabel('Predicted Class');
ylabel('True Class');
title('Confusion Matrix');

% Export figure
exportFigure(h, 'confusion_matrix');


end
