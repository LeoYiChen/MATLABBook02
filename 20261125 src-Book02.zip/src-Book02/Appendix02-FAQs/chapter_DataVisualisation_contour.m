%% chapter_DataVisualisation_contour.m
% Advanced Contour Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_contour
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createAdvancedContour(X, Y, Z)
% Create figure
h = figure('Position', [100 100 1000 800]);

% Create subplot layout
subplot(2,2,[1 3])

% Main contour plot
[C,h1] = contourf(X, Y, Z, 20);
colormap(jet);
colorbar;

% Add streamlines
hold on;
[dx,dy] = gradient(Z);
streamslice(X, Y, -dx, -dy, 2);

% Customize appearance
xlabel('x');
ylabel('y');
title('Field Visualization');

% Side views
subplot(2,2,2)
surf(X, Y, Z, 'EdgeColor', 'none');
view(45, 45);
colorbar;
title('3D Surface View');

subplot(2,2,4)
contour3(X, Y, Z, 20);
view(45, 45);
grid on;
title('3D Contour View');

% Add global title
sgtitle('Multi-perspective Field Analysis');

% Export figure
exportFigure(h, 'advanced_contour');

end
