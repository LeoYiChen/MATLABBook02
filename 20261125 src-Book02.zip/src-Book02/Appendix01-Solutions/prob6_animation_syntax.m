%% prob6_animation_syntax.m
% Animation generation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob6_animation_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create figure and axes
figure;
% Loop through time steps
for i = 1:numSteps
    % Update plot data
    plot(x, y(i,:));
    % Capture frame
    frame(i) = getframe(gcf);
    pause(0.05); % Control animation speed
end
% Save as video
video = VideoWriter('animation.avi');
writeVideo(video, frame);
close(video);
