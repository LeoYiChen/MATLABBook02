%% chapter_AI_Mechanics_Problem9_constitutive_syntax.m
% Hyperelastic constitutive model implementation syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem9_constitutive_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Compute Cauchy stress from Mooney-Rivlin model
% lambda: principal stretch (e.g., lambda = 1 + engineering_strain)
% C10, C01: Mooney-Rivlin parameters (Pa)
% Assumes incompressibility: lambda_1 * lambda_2 * lambda_3 = 1

function sigma = mooneyRivlinStress(lambda, C10, C01)
    % Uniaxial loading: lambda_1 = lambda, lambda_2 = lambda_3 = 1/sqrt(lambda)
    lambda1 = lambda;
    lambda2 = 1 / sqrt(lambda);
    lambda3 = lambda2;
    
    % Invariants
    I1 = lambda1^2 + lambda2^2 + lambda3^2;
    I2 = lambda1^2*lambda2^2 + lambda2^2*lambda3^2 + lambda3^2*lambda1^2;
    
    % Derivatives (for incompressible case)
    dW_dI1 = C10;
    dW_dI2 = C01;
    
    % Cauchy stress (engineering stress = sigma / lambda for uniaxial)
    sigma_cauchy = 2 * (dW_dI1 + I1*dW_dI2) * lambda1^2 - ...
                   2 * dW_dI2 * lambda1^4 - ...
                   2 * (dW_dI1 + I2*dW_dI2);  % Hydrostatic term cancels
    
    % Engineering stress
    sigma = sigma_cauchy / lambda;
end

% Vectorised for multiple stretch values
stretch_vec = linspace(1.0, 2.5, 50);
stress_vec = arrayfun(@(lam) mooneyRivlinStress(lam, C10, C01), stretch_vec);
