%% chapter_DataVisualisation_boxplot.m
% Box Plot Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_boxplot
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Generate sample data
rng(42); % For reproducibility
data = randn(100,3);
groups = {'Control', 'Treatment A', 'Treatment B'};

% Create box plot
figure('Position', [100 100 800 600]);
boxplot(data, 'Labels', groups, 'Notch', 'on');
title('\textbf{Distribution Analysis}');
ylabel('Response Variable');
grid on;

% Add statistical annotations
h = findobj(gca, 'Tag', 'Box');
for j=1:length(h)
patch(get(h(j), 'XData'), get(h(j), 'YData'), ...
'blue', 'FaceAlpha', 0.1);
end

% Export figure in multiple formats
exportFigure(h, 'boxplot_figures');

