%% lst_adv_prob02.m
% Work done by variable force.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob02
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem02.m
%  Computing Work Done by Variable Force (Numerical Integration)
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. Define Force and Analytical Result --
springConstant1 = 100;   % k1 (N/m)
springConstant2 = 50;    % k2 (N/m^3)
forceFunction = @(x) -springConstant1*x - springConstant2*x.^3;
analyticalWork = -50*(0.5)^2 - 12.5*(0.5)^4;  % -13.28125 J
fprintf('Analytical work = %.5f J\n\n', analyticalWork);

%% -- 2. Numerical Integration --
subIntervals = [4, 10, 20, 50, 100, 1000];
numTests = numel(subIntervals);
resultsTrap = zeros(numTests, 1);
resultsSimpson = zeros(numTests, 1);
timeTrap = zeros(numTests, 1);
timeSimpson = zeros(numTests, 1);

lowerBound = 0;  upperBound = 0.5;

for testIndex = 1:numTests
    numSub = subIntervals(testIndex);
    xPoints = linspace(lowerBound, upperBound, numSub + 1);
    fValues = forceFunction(xPoints);
    stepH = (upperBound - lowerBound) / numSub;

    % Trapezoidal rule
    tic;
    resultsTrap(testIndex) = stepH * (fValues(1)/2 ...
                             + sum(fValues(2:end-1)) + fValues(end)/2);
    timeTrap(testIndex) = toc;

    % Simpson's rule (ensure even number of sub-intervals)
    numSubEven = numSub + mod(numSub, 2);
    xSimpson = linspace(lowerBound, upperBound, numSubEven + 1);
    fSimpson = forceFunction(xSimpson);
    hSimpson = (upperBound - lowerBound) / numSubEven;
    tic;
    resultsSimpson(testIndex) = (hSimpson/3) * (fSimpson(1) ...
        + 4*sum(fSimpson(2:2:end-1)) ...
        + 2*sum(fSimpson(3:2:end-2)) + fSimpson(end));
    timeSimpson(testIndex) = toc;

    fprintf('n = %4d | Trap = %12.8f J (err = %.2e) | ', ...
        numSub, resultsTrap(testIndex), ...
        abs(resultsTrap(testIndex) - analyticalWork));
    fprintf('Simp = %12.8f J (err = %.2e)\n', ...
        resultsSimpson(testIndex), ...
        abs(resultsSimpson(testIndex) - analyticalWork));
end

% MATLAB integral
tic;
resultAdaptive = integral(forceFunction, lowerBound, upperBound);
timeAdaptive = toc;
fprintf('\nintegral() = %12.8f J (err = %.2e, time = %.6f s)\n', ...
    resultAdaptive, abs(resultAdaptive - analyticalWork), timeAdaptive);

%% -- 3. Visualisation --
figHandle = figure('Position', [100 100 1000 450]);
xPlot = linspace(0, 0.5, 200);
fPlot = forceFunction(xPlot);

subplot(1,2,1);
area(xPlot, fPlot, 'FaceColor', [0.6 0.8 1.0], ...
     'EdgeColor', 'b', 'LineWidth', 1.5);
xlabel('$x$ (m)', 'Interpreter', 'latex');
ylabel('$F(x)$ (N)', 'Interpreter', 'latex');
title('Force-Displacement and Work Done', 'Interpreter', 'latex');
grid on;

subplot(1,2,2);
loglog(subIntervals, abs(resultsTrap - analyticalWork), ...
       'ro-', 'LineWidth', 1.2); hold on;
loglog(subIntervals, abs(resultsSimpson - analyticalWork), ...
       'bs-', 'LineWidth', 1.2);
xlabel('Number of sub-intervals $n$', 'Interpreter', 'latex');
ylabel('Absolute error (J)', 'Interpreter', 'latex');
title('Error Convergence', 'Interpreter', 'latex');
legend({'Trapezoidal $O(h^2)$', 'Simpson $O(h^4)$'}, ...
       'Interpreter', 'latex', 'Location', 'southwest');
grid on;

savefig(figHandle, 'Problem02_WorkDone.fig');
exportgraphics(figHandle, 'Problem02_WorkDone.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem02_WorkDone.jpg', ...
               'Resolution', 300);

fprintf('\n-- Problem 2 Complete --\n');
% Computational Complexity:
% Both the trapezoidal and Simpson's rules evaluate F(x) at
% n+1 points and perform O(n) arithmetic operations.  Simpson's
% rule achieves O(h^4) error versus O(h^2) for the trapezoidal
% rule, providing far superior accuracy per function evaluation.
% MATLAB's integral() uses adaptive Gauss-Kronrod quadrature,
% automatically subdividing the interval.  Its complexity is
% problem-dependent but typically O(n log n) for the requested
% tolerance.  Space complexity is O(n) for all methods.
