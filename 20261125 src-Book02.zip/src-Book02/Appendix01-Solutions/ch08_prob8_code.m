%% ch08_prob8_code.m
% LSTM streaming prediction with animation (MATLABBook02_Chapter08_Problem8.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob8_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem8.m
% --------------------------------
% Purpose : LSTM one-step-ahead prediction on streaming data.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later; Deep Learning Toolbox required
% --------------------------------
clc; clear; close all;

%% Step 1 - Generate synthetic vibration time-series
fprintf('=== Step 1: Generating synthetic time-series ===\n');
rng(42, 'twister');
numTimeSteps = 5000;
timeVector   = (1:numTimeSteps)';
% Deterministic: sum of sinusoids with slow drift
vibrationSignal = 2.0 * sin(2*pi*timeVector/200) + ...
                  1.5 * sin(2*pi*timeVector/50)  + ...
                  0.5 * sin(2*pi*timeVector/15)  + ...
                  0.01 * timeVector + ...
                  0.8 * randn(numTimeSteps, 1);
fprintf('  Time-series length: %d samples.\n', numTimeSteps);

%% Step 2 - Partition into training and test
trainRatio = 0.8;
numTrain   = round(trainRatio * numTimeSteps);
trainData  = vibrationSignal(1:numTrain);
testData   = vibrationSignal(numTrain+1:end);
fprintf('  Training: %d | Test: %d\n', numel(trainData), ...
    numel(testData));

%% Step 3 - Normalise
dataMean = mean(trainData);
dataStd  = std(trainData);
trainDataNorm = (trainData - dataMean) / dataStd;
testDataNorm  = (testData  - dataMean) / dataStd;

% Prepare sequences: predict next value from current
trainInput  = trainDataNorm(1:end-1)';
trainTarget = trainDataNorm(2:end)';

%% Step 4 - Define LSTM network
fprintf('\n=== Step 4: Defining LSTM architecture ===\n');
numHiddenUnits = 128;
lstmLayers = [ ...
    sequenceInputLayer(1, 'Name', 'input')
    lstmLayer(numHiddenUnits, 'Name', 'lstm1', ...
        'OutputMode', 'sequence')
    dropoutLayer(0.2, 'Name', 'dropout')
    fullyConnectedLayer(1, 'Name', 'fc')
    regressionLayer('Name', 'output')];
fprintf('  LSTM hidden units: %d\n', numHiddenUnits);

%% Step 5 - Training options and train
trainingOpts = trainingOptions('adam', ...
    'MaxEpochs',          50, ...
    'MiniBatchSize',      128, ...
    'InitialLearnRate',   0.005, ...
    'GradientThreshold',  1, ...
    'Shuffle',            'never', ...
    'Verbose',            true, ...
    'Plots',              'training-progress');

fprintf('\n=== Step 5: Training LSTM ===\n');
trainedLSTM = trainNetwork(trainInput, trainTarget, ...
    lstmLayers, trainingOpts);

%% Step 6 - Streaming (closed-loop) prediction on test set
fprintf('\n=== Step 6: Streaming prediction ===\n');
% Initialise state using training data
streamNet = predictAndUpdateState(trainedLSTM, trainInput);

numTestSteps     = numel(testDataNorm);
predictedNorm    = zeros(numTestSteps, 1);
currentInput     = trainDataNorm(end);

for stepIdx = 1:numTestSteps
    [streamNet, predictedValue] = ...
        predictAndUpdateState(streamNet, currentInput);
    predictedNorm(stepIdx) = predictedValue;
    % Closed-loop: feed prediction back (or use actual for open-loop)
    currentInput = testDataNorm(stepIdx);  % open-loop variant
end

% De-normalise
predictedSignal = predictedNorm * dataStd + dataMean;
actualSignal    = testData;

% Compute RMSE
rmseValue = sqrt(mean((actualSignal - predictedSignal).^2));
fprintf('  RMSE on test set: %.4f\n', rmseValue);

%% Step 7 - Static visualisation
testTimeVec = (numTrain+1:numTimeSteps)';

figPrediction = figure('Name', 'LSTM Prediction', ...
    'Position', [100 100 1200 500]);
plot(timeVector(1:numTrain), trainData, 'b-', 'LineWidth', 0.8);
hold on;
plot(testTimeVec, actualSignal, 'k-', 'LineWidth', 1.0);
plot(testTimeVec, predictedSignal, 'r-', 'LineWidth', 1.2);
xline(numTrain, 'g-', 'LineWidth', 1.5);
xlabel('Time Step', 'Interpreter', 'latex');
ylabel('Vibration Amplitude', 'Interpreter', 'latex');
title('\textbf{LSTM One-Step-Ahead Prediction}', ...
    'Interpreter', 'latex', 'FontSize', 13);
legend({'Training Data', 'Actual (Test)', ...
    'Predicted (Test)', 'Train/Test Split'}, ...
    'Interpreter', 'latex', 'Location', 'northwest');
grid on;

savefig(figPrediction, 'Ch08_Problem8_LSTMPrediction.fig');
exportgraphics(figPrediction, ...
    'Ch08_Problem8_LSTMPrediction.eps', 'ContentType', 'vector');
exportgraphics(figPrediction, ...
    'Ch08_Problem8_LSTMPrediction.jpg', 'Resolution', 300);

%% Step 8 - Animate streaming prediction and save MP4
fprintf('\n=== Step 8: Animating streaming prediction ===\n');
figStream = figure('Name', 'Streaming Animation', ...
    'Position', [100 100 1100 500]);

vidWriter = VideoWriter('Ch08_Problem8_StreamingLSTM.mp4', 'MPEG-4');
vidWriter.FrameRate = 30;
vidWriter.Quality   = 90;
open(vidWriter);

windowDisplay = 200;
for stepIdx = 1:numTestSteps
    cla;
    dispStart = max(1, stepIdx - windowDisplay + 1);
    % Plot actual
    plot(dispStart:stepIdx, ...
        actualSignal(dispStart:stepIdx), ...
        'k-', 'LineWidth', 1.2); hold on;
    % Plot predicted
    plot(dispStart:stepIdx, ...
        predictedSignal(dispStart:stepIdx), ...
        'r-', 'LineWidth', 1.4);
    % Current prediction marker
    plot(stepIdx, predictedSignal(stepIdx), ...
        'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    xlim([dispStart, dispStart + windowDisplay]);
    ylim([min(actualSignal)*1.2, max(actualSignal)*1.2]);
    xlabel('Test Step', 'Interpreter', 'latex');
    ylabel('Amplitude', 'Interpreter', 'latex');
    title(sprintf('\\textbf{Streaming LSTM - Step %d/%d}', ...
        stepIdx, numTestSteps), 'Interpreter', 'latex');
    legend({'Actual', 'Predicted', 'Current'}, ...
        'Interpreter', 'latex', 'Location', 'northeast');
    grid on;
    drawnow;

    if mod(stepIdx, 2) == 0  % write every 2nd frame for speed
        writeVideo(vidWriter, getframe(figStream));
    end
end
close(vidWriter);
fprintf('  Video saved: Ch08_Problem8_StreamingLSTM.mp4\n');

fprintf('\n=== Problem 8 Complete ===\n');
% --------------------------------
% Computational Complexity:
% LSTM training for E epochs over T time steps with H hidden units
% is O(E * T * H^2) per epoch (dominated by gate matrix products).
% Streaming inference calls predictAndUpdateState() once per step:
% O(H^2) per call, O(N_test * H^2) total. The animation loop is
% O(N_test) and I/O-bound. Memory during training is O(T * H) for
% the unrolled hidden states. Normalisation is O(N).
% --------------------------------
