%% lst_adv_prob09.m
% Chemical reactor temperature root-finding
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob09
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem09.m
%  Chemical Reactor Design: Finding Operating Temperature
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. Parameters and Function --
rateConstant0   = 5e10;
rateConstant1   = 2e8;
activationEa    = 80000;    % J/mol
activationEb    = 100000;   % J/mol
gasConstant     = 8.314;    % J/(mol*K)

conversionEfficiency = @(T) 100 * rateConstant0 * ...
    exp(-activationEa ./ (gasConstant*T)) ./ ...
    (1 + rateConstant1 * exp(-activationEb ./ ...
    (gasConstant*T))) - 75;

targetEfficiency = 15;
rootFunction = @(T) conversionEfficiency(T) - targetEfficiency;

%% -- 2. Visualise to Locate Roots --
tempRange = linspace(300, 800, 5000);
etaValues = conversionEfficiency(tempRange);

figHandle = figure('Position', [80 80 1200 500]);
subplot(1,2,1);
plot(tempRange, etaValues, 'b-', 'LineWidth', 1.5); hold on;
yline(targetEfficiency, 'r-', 'LineWidth', 1.5);
xlabel('Temperature $T$ (K)', 'Interpreter', 'latex');
ylabel('$\eta(T)$ (\%)', 'Interpreter', 'latex');
title('Conversion Efficiency vs Temperature', ...
      'Interpreter', 'latex');
legend({'$\eta(T)$', '$\eta = 15\%$ target'}, ...
       'Interpreter', 'latex');
grid on;
xlim([350 420]);

%% -- 3. Bisection Method --
bisectionLower = 350;
bisectionUpper = 400;
bisectionTolerance = 1e-10;
maxBisectionIter = 100;
bisectionHistory = zeros(maxBisectionIter, 1);

fprintf('-- Bisection Method --\n');
for iterIndex = 1:maxBisectionIter
    midPoint = (bisectionLower + bisectionUpper) / 2;
    bisectionHistory(iterIndex) = midPoint;

    if rootFunction(midPoint) * rootFunction(bisectionLower) < 0
        bisectionUpper = midPoint;
    else
        bisectionLower = midPoint;
    end

    if (bisectionUpper - bisectionLower) < bisectionTolerance
        fprintf('  Converged in %d iterations\n', iterIndex);
        fprintf('  T* = %.8f K\n', midPoint);
        break;
    end
end
bisectionIterations = iterIndex;
bisectionResult = midPoint;
bisectionHistory = bisectionHistory(1:bisectionIterations);

%% -- 4. Newton-Raphson Method --
newtonTemp = 400;
newtonTolerance = 1e-10;
maxNewtonIter = 50;
newtonHistory = zeros(maxNewtonIter, 1);
perturbation = 1e-6;

fprintf('\n-- Newton-Raphson Method --\n');
for iterIndex = 1:maxNewtonIter
    newtonHistory(iterIndex) = newtonTemp;
    fValue = rootFunction(newtonTemp);
    fDerivative = (rootFunction(newtonTemp + perturbation) ...
                   - rootFunction(newtonTemp - perturbation)) ...
                  / (2 * perturbation);
    newtonTempNew = newtonTemp - fValue / fDerivative;

    if abs(newtonTempNew - newtonTemp) < newtonTolerance
        fprintf('  Converged in %d iterations\n', iterIndex);
        fprintf('  T* = %.8f K\n', newtonTempNew);
        break;
    end
    newtonTemp = newtonTempNew;
end
newtonIterations = iterIndex;
newtonResult = newtonTempNew;
newtonHistory = newtonHistory(1:newtonIterations);

%% -- 5. Uniqueness Check --
fAtBoundaries = rootFunction([300, 800]);
fprintf('\nf(300) = %.4f, f(800) = %.4f\n', ...
    fAtBoundaries(1), fAtBoundaries(2));
signChanges = sum(diff(sign(rootFunction(tempRange))) ~= 0);
fprintf('Number of sign changes in [300, 800]: %d\n', ...
    signChanges);
fprintf('Conclusion: unique root in [300, 800] K\n');

%% -- 6. Convergence Plot --
subplot(1,2,2);
semilogy(1:bisectionIterations, ...
    abs(bisectionHistory - bisectionResult), 'bo-', ...
    'LineWidth', 1.2); hold on;
semilogy(1:newtonIterations, ...
    abs(newtonHistory - newtonResult), 'rs-', ...
    'LineWidth', 1.2);
xlabel('Iteration', 'Interpreter', 'latex');
ylabel('$|T_k - T^*|$ (K)', 'Interpreter', 'latex');
title('Convergence Comparison', 'Interpreter', 'latex');
legend({'Bisection (linear)', 'Newton-Raphson (quadratic)'}, ...
       'Interpreter', 'latex');
grid on;

savefig(figHandle, 'Problem09_ReactorTemperature.fig');
exportgraphics(figHandle, 'Problem09_ReactorTemperature.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem09_ReactorTemperature.jpg', ...
               'Resolution', 300);

fprintf('\n-- Problem 9 Complete --\n');
% Computational Complexity:
% Bisection requires O(log2((b-a)/epsilon)) iterations, each
% costing O(1) for one function evaluation; here approximately
% 50 iterations for tolerance 1e-10 over [350,400].  Newton-
% Raphson converges quadratically, typically requiring 6-10
% iterations, each costing O(1) for the function plus O(1) for
% the numerical derivative (2 function evaluations).  The
% initial plotting sweep over 5000 points costs O(5000).
% Space complexity is O(maxIter) for convergence histories.
