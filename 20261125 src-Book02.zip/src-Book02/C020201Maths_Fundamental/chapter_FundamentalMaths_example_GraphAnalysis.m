%% chapter_FundamentalMaths_example_GraphAnalysis.m
% Comprehensive graph creation and analysis in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_GraphAnalysis
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateGraphTheory();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateGraphTheory()
    % DEMONSTRATEGRAPHTHEORY Graph theory fundamentals
    %   Demonstrates graph creation, shortest paths, MST, centrality
    
    fprintf('Graph Theory and Network Analysis\n');
    fprintf('==================================\n\n');
    
    %% Historical Context: Seven Bridges of Konigsberg
    fprintf('HISTORICAL CONTEXT\n');
    fprintf('---\n\n');
    
    fprintf(['Euler''s Seven Bridges of Konigsberg (1736):\n', ...
        'The foundation of graph theory arose from a puzzle:\n', ...
        'Can one walk through Konigsberg crossing each bridge exactly once?\n', ...
        'Euler proved this impossible by abstracting the problem\n', ...
        'into a graph with nodes (land masses) and edges (bridges).\n\n']);
    
    % Recreate Konigsberg bridge problem
    fprintf('Konigsberg Bridge Graph:\n');
    
    % Nodes: A, B, C, D (land masses)
    % Edges represent the 7 bridges
    s_k = [1 1 1 2 2 3 3];  % Source nodes (A=1, B=2, C=3, D=4)
    t_k = [2 2 4 3 4 4 4];  % Target nodes
    
    G_konigsberg = graph(s_k, t_k);
    
    % Display degree of each node
    degrees = degree(G_konigsberg);
    fprintf('Node degrees: %s\n', num2str(degrees));
    fprintf(['Euler''s insight: A path crossing each edge once exists\n', ...
        'if and only if the graph has exactly 0 or 2 odd-degree vertices.\n']);
    fprintf('Konigsberg has %d odd-degree vertices - impossible!\n\n', ...
        sum(mod(degrees, 2) == 1));
    
    %% Modern Network Example
    fprintf('MODERN NETWORK ANALYSIS\n');
    fprintf('----\n\n');
    
    % Create a directed weighted graph representing a transport network
    fprintf('Creating directed weighted transport network...\n\n');
    
    % Define edges: source, target, weight (distance/cost)
    s = [1 1 1 2 2 3 3 4 4 5 5 6 7 8];
    t = [2 3 4 4 5 6 7 5 8 6 7 7 8 9];
    weights = [4.2 3.1 7.5 2.8 6.1 4.5 8.2 3.3 5.7 2.9 4.8 6.3 3.5 4.1];
    
    node_names = {'London', 'Birmingham', 'Manchester', 'Leeds', ...
        'Sheffield', 'Liverpool', 'Newcastle', 'Bristol', 'Southampton'};
    
    G = digraph(s, t, weights, node_names);
    
    fprintf('Network statistics:\n');
    fprintf('  Nodes: %d\n', numnodes(G));
    fprintf('  Edges: %d\n', numedges(G));
    fprintf('  Total network length: %.2f units\n\n', sum(G.Edges.Weight));
    
    %% Shortest Path Analysis (Dijkstra's Algorithm)
    fprintf('SHORTEST PATH ANALYSIS\n');
    fprintf('-----\n\n');
    
    start_node = 'London';
    end_node = 'Newcastle';
    
    fprintf('Finding shortest path from %s to %s...\n', start_node, end_node);
    fprintf('Using Dijkstra''s algorithm (1959)...\n\n');
    
    [path, distance] = shortestpath(G, start_node, end_node);
    
    fprintf('Shortest path: ');
    for i = 1:length(path)
        if i < length(path)
            fprintf('%s -> ', G.Nodes.Name{path(i)});
        else
            fprintf('%s\n', G.Nodes.Name{path(i)});
        end
    end
    fprintf('Total distance: %.2f units\n\n', distance);
    
    % Compute all shortest paths from London
    fprintf('All shortest paths from %s:\n', start_node);
    
    start_idx = findnode(G, start_node);
    for i = 1:numnodes(G)
        if i ~= start_idx
            [~, dist] = shortestpath(G, start_idx, i);
            fprintf('  to %s: %.2f units\n', G.Nodes.Name{i}, dist);
        end
    end
    fprintf('\n');
    
    %% Centrality Measures
    fprintf('CENTRALITY MEASURES\n');
    fprintf('----\n\n');
    
    fprintf(['Centrality measures quantify node importance:\n', ...
        '  - Degree: number of connections\n', ...
        '  - Betweenness: frequency on shortest paths\n', ...
        '  - Closeness: average distance to others\n', ...
        '  - PageRank: iterative importance (Google, 1998)\n\n']);
    
    % Compute various centrality measures
    degree_cent = centrality(G, 'degree');
    betweenness_cent = centrality(G, 'betweenness');
    closeness_cent = centrality(G, 'closeness');
    pagerank_cent = centrality(G, 'pagerank');
    
    fprintf('%-15*s %8*s %12*s %10*s %10*s\n', 'Node', 'Degree', ...
        'Betweenness', 'Closeness', 'PageRank');
    fprintf('%s\n', repmat('-', 1, 60));
    
    for i = 1:numnodes(G)
        fprintf('%-15*s %8.2*f %12.4*f %10.4*f %10.4*f\n', ...
            G.Nodes.Name{i}, degree_cent(i), betweenness_cent(i), ...
            closeness_cent(i), pagerank_cent(i));
    end
    fprintf('\n');
    
    % Identify most central node by each measure
    [~, idx_degree] = max(degree_cent);
    [~, idx_between] = max(betweenness_cent);
    [~, idx_close] = max(closeness_cent);
    [~, idx_pagerank] = max(pagerank_cent);
    
    fprintf('Most central nodes:\n');
    fprintf('  By degree: %s\n', G.Nodes.Name{idx_degree});
    fprintf('  By betweenness: %s (critical for connectivity)\n', ...
        G.Nodes.Name{idx_between});
    fprintf('  By closeness: %s (fastest information spread)\n', ...
        G.Nodes.Name{idx_close});
    fprintf('  By PageRank: %s (most "influential")\n\n', ...
        G.Nodes.Name{idx_pagerank});
    
    %% Minimum Spanning Tree
    fprintf('MINIMUM SPANNING TREE\n');
    fprintf('-----\n\n');
    
    fprintf(['The MST connects all nodes with minimum total weight,\n', ...
        'used in network design, clustering, and optimisation.\n', ...
        'Algorithms by Kruskal (1956) and Prim (1957).\n\n']);
    
    % Convert to undirected for MST
    G_undir = graph(s, t, weights, node_names);
    
    % Compute minimum spanning tree
    [T, pred] = minspantree(G_undir);
    
    fprintf('Original network total weight: %.2f units\n', ...
        sum(G_undir.Edges.Weight));
    fprintf('MST total weight: %.2f units\n', sum(T.Edges.Weight));
    fprintf('Reduction: %.2f units (%.1f%% saving)\n\n', ...
        sum(G_undir.Edges.Weight) - sum(T.Edges.Weight), ...
        (1 - sum(T.Edges.Weight)/sum(G_undir.Edges.Weight))*100);
    
    fprintf('MST edges:\n');
    for i = 1:numedges(T)
        fprintf('  %s - %s: %.2f units\n', ...
            T.Edges.EndNodes{i,1}, T.Edges.EndNodes{i,2}, ...
            T.Edges.Weight(i));
    end
    fprintf('\n');
    
    %% Graph Representations
    fprintf('GRAPH REPRESENTATIONS\n');
    fprintf('-----\n\n');
    
    % Adjacency matrix
    A = full(adjacency(G, 'weighted'));
    
    fprintf('Adjacency matrix (weighted, %.0f x %.0f):\n', ...
        size(A,1), size(A,2));
    fprintf('   ');
    for i = 1:min(5, numnodes(G))
        fprintf('%6*s ', G.Nodes.Name{i}(1:min(6,length(G.Nodes.Name{i}))));
    end
    fprintf('\n');
    
    for i = 1:min(5, numnodes(G))
        fprintf('%-3*s', G.Nodes.Name{i}(1:min(3,length(G.Nodes.Name{i}))));
        for j = 1:min(5, numnodes(G))
            if A(i,j) > 0
                fprintf('%6.1*f ', A(i,j));
            else
                fprintf('%6*s ', '-');
            end
        end
        fprintf('\n');
    end
    fprintf('(showing first 5*x5 submatrix)\n\n');
    
    fprintf('Memory usage:\n');
    fprintf('  Adjacency matrix: %d elements\n', numel(A));
    fprintf('  Edge list: %d edges\n', numedges(G));
    fprintf('  Sparsity: %.2f%% (only %.2f%% non-zero)\n\n', ...
        (1 - nnz(A)/numel(A))*100, nnz(A)/numel(A)*100);
    
    %% Connectivity Analysis
    fprintf('CONNECTIVITY ANALYSIS\n');
    fprintf('-----\n\n');
    
    % For undirected graph
    bins = conncomp(G_undir);
    num_components = max(bins);
    
    fprintf('Number of connected components: %d\n', num_components);
    
    if num_components == 1
        fprintf('Graph is fully connected.\n\n');
    else
        fprintf('Graph is disconnected.\n');
        fprintf('Component sizes:\n');
        for i = 1:num_components
            size_comp = sum(bins == i);
            fprintf('  Component %d: %d nodes\n', i, size_comp);
        end
        fprintf('\n');
    end
    
    % Cycles detection
    try
        cycles = allcycles(G);
        fprintf('Cycle detection:\n');
        fprintf('  Number of cycles: %d\n', length(cycles));
        
        if ~isempty(cycles)
            fprintf('  Example cycle: ');
            example_cycle = cycles{1};
            for i = 1:length(example_cycle)
                fprintf('%s', G.Nodes.Name{example_cycle(i)});
                if i < length(example_cycle)
                    fprintf(' -> ');
                end
            end
            fprintf('\n\n');
        end
    catch
        fprintf('  (Cycle detection available for smaller graphs)\n\n');
    end
    
    %% Network Efficiency
    fprintf('NETWORK EFFICIENCY\n');
    fprintf('---\n\n');
    
    % Compute average path length
    distances = distances(G);
    finite_distances = distances(isfinite(distances) & distances > 0);
    
    if ~isempty(finite_distances)
        avg_path_length = mean(finite_distances);
        fprintf('Average shortest path length: %.3f units\n', avg_path_length);
        
        % Network diameter (longest shortest path)
        diameter = max(finite_distances);
        fprintf('Network diameter: %.2f units\n', diameter);
        
        % Global efficiency (inverse of average path length)
        global_efficiency = 1 / avg_path_length;
        fprintf('Global efficiency: %.4f (higher = better)\n\n', ...
            global_efficiency);
    end
    
    %% Visualisation
    visualiseGraphs(G, G_undir, T, path, G_konigsberg, pagerank_cent);
end

function visualiseGraphs(G, G_undir, T, shortest_path, G_konig, pagerank)
    % Visualise graph analysis results
    
    figure('Position', [100, 100, 1400, 900]);
    
    % Konigsberg bridges
    subplot(2, 3, 1);
    h1 = plot(G_konig, 'Layout', 'force', 'LineWidth', 2, ...
        'MarkerSize', 10, 'NodeColor', [0.8, 0.2, 0.2]);
    h1.NodeLabel = {'A', 'B', 'C', 'D'};
    title('Euler''s Konigsberg Bridges (1736)');
    
    % Original directed graph
    subplot(2, 3, 2);
    h2 = plot(G, 'EdgeLabel', round(G.Edges.Weight, 1), ...
        'LineWidth', 1.5, 'MarkerSize', 8, 'ArrowSize', 10);
    title('Directed Weighted Network');
    
    % Shortest path highlighted
    subplot(2, 3, 3);
    h3 = plot(G, 'EdgeLabel', round(G.Edges.Weight, 1), ...
        'LineWidth', 1.5, 'MarkerSize', 8, 'ArrowSize', 10);
    highlight(h3, shortest_path, 'NodeColor', [1, 0.2, 0.2], ...
        'MarkerSize', 12);
    highlight(h3, shortest_path, 'EdgeColor', [1, 0.2, 0.2], 'LineWidth', 3);
    title('Shortest Path (Dijkstra''s Algorithm)');
    
    % Centrality visualisation (PageRank)
    subplot(2, 3, 4);
    h4 = plot(G, 'LineWidth', 1.5, 'MarkerSize', 8, 'ArrowSize', 10);
    
    % Scale node sizes by PageRank
    pagerank_scaled = pagerank / max(pagerank) * 15 + 5;
    h4.MarkerSize = pagerank_scaled;
    
    % Colour by PageRank
    colormap('jet');
    h4.NodeCData = pagerank;
    colorbar;
    title('PageRank Centrality (node size ∝ importance)');
    
    % Original undirected graph
    subplot(2, 3, 5);
    h5 = plot(G_undir, 'EdgeLabel', round(G_undir.Edges.Weight, 1), ...
        'LineWidth', 1.5, 'MarkerSize', 8);
    title('Undirected Network');
    
    % Minimum spanning tree
    subplot(2, 3, 6);
    h6 = plot(T, 'EdgeLabel', round(T.Edges.Weight, 1), ...
        'LineWidth', 2.5, 'MarkerSize', 10, 'EdgeColor', [0.2, 0.8, 0.2]);
    title('Minimum Spanning Tree');
end
