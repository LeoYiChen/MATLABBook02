%% C0201Introduction_code_016.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Common causes and fixes:

% 1. Off-by-one errors in loops
data = rand(10, 5);

% WRONG: Exceeds bounds
% for i = 1:length(data)
%     value = data(i, 6);  % Column 6 doesn't exist
% end

% CORRECT: Check dimensions
[rows, cols] = size(data);
for i = 1:rows
    for j = 1:cols
        value = data(i, j);
    end
end

% 2. Empty array indexing
emptyArray = [];
% WRONG: if emptyArray(1) > 0  % Error!
% CORRECT: Check if empty first
if ~isempty(emptyArray) && emptyArray(1) > 0
    fprintf('First element is positive\n');
end

% 3. Logical indexing with wrong dimensions
mask = rand(10, 1) > 0.5;  % Column vector
dataRow = rand(1, 10);     % Row vector
% WRONG: filtered = dataRow(mask);  % Dimension mismatch
% CORRECT: Ensure dimensions match
filtered = dataRow(mask');
