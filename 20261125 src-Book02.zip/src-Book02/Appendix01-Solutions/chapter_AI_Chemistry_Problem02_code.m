%% chapter_AI_Chemistry_Problem02_code.m
% Problem 2: Bayesian Optimisation for Reaction Yield (Abbreviated)
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Chemistry_Problem02_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Script: Problem 2 - Bayesian Optimisation for Reaction Yield
% Author: Dr Yi Chen | Newcastle University | January 2025
% Description: Optimise cross-coupling reaction yield using Bayesian
%              optimisation with Gaussian Process surrogate models
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialisation
clear all; close all; clc;
rng(2025, 'twister');

fprintf('========================================\n');
fprintf('Problem 2: Bayesian Optimisation for Reaction Yield\n');
fprintf('========================================\n\n');

%% Step 1: Define True Yield Function (Unknown to Optimiser)
% Parameters: [Temperature ( C), Catalyst (mol%), Base (eq), Time (h)]
trueYieldFunction = @(params) simulateReactionYield(params);

paramBounds = [25, 150;    % Temperature range
               0.1, 5.0;   % Catalyst loading range
               1.0, 4.0;   % Base equivalents range
               1.0, 24.0]; % Reaction time range

paramNames = {'Temperature ($^\circ$C)', 'Catalyst (mol\%)', ...
             'Base (eq)', 'Time (h)'};

%% Step 2: Initialisation - Random Exploration
numInitial = 5;
numIterations = 20;

% Generate random initial experiments
initialParams = rand(numInitial, 4);
for dim = 1:4
    initialParams(:, dim) = paramBounds(dim, 1) + ...
                           initialParams(:, dim) * (paramBounds(dim, 2) - paramBounds(dim, 1));
end

% Conduct initial experiments
initialYields = zeros(numInitial, 1);
for expIdx = 1:numInitial
    initialYields(expIdx) = trueYieldFunction(initialParams(expIdx, :));
end

fprintf('Initial exploration complete: %d random experiments\n', numInitial);
fprintf('  Best initial yield: %.2f%%\n\n', max(initialYields) * 100);

% Cumulative dataset
allParams = initialParams;
allYields = initialYields;

%% Step 3: Bayesian Optimisation Loop
fprintf('Starting Bayesian optimisation (%d iterations)...\n', numIterations);

bestYieldHistory = zeros(numIterations + numInitial, 1);
bestYieldHistory(1:numInitial) = max(initialYields) * ones(numInitial, 1);

% Setup video writer for animation
videoWriter = VideoWriter('Problem02_OptimisationProgress.mp4', 'MPEG-4');
videoWriter.FrameRate = 2;
open(videoWriter);

figAnimation = figure('Name', 'Optimisation Progress', 'Position', [100, 100, 1200, 800]);

for iterIdx = 1:numIterations
    % Fit Gaussian Process to current data
    gpModel = fitrgp(allParams, allYields, 'KernelFunction', 'squaredexponential', ...
                    'Standardize', true, 'Sigma', 0.05, 'Verbose', 0);
    
    % Calculate Expected Improvement across parameter space
    numCandidates = 5000;
    candidateParams = rand(numCandidates, 4);
    for dim = 1:4
        candidateParams(:, dim) = paramBounds(dim, 1) + ...
                                 candidateParams(:, dim) * (paramBounds(dim, 2) - paramBounds(dim, 1));
    end
    
    [predYields, predStd] = predict(gpModel, candidateParams);
    
    % Expected Improvement calculation
    bestYieldSoFar = max(allYields);
    improvement = predYields - bestYieldSoFar;
    Z = improvement ./ (predStd + 1e-9);
    expectedImprovement = improvement .* normcdf(Z) + predStd .* normpdf(Z);
    
    % Select next experiment (max EI)
    [~, bestCandidateIdx] = max(expectedImprovement);
    nextParams = candidateParams(bestCandidateIdx, :);
    
    % Conduct simulated experiment
    nextYield = trueYieldFunction(nextParams);
    
    % Update dataset
    allParams = [allParams; nextParams];
    allYields = [allYields; nextYield];
    
    bestYieldHistory(numInitial + iterIdx) = max(allYields);
    
    % Visualisation for animation
    clf(figAnimation);
    
    subplot(2, 2, 1);
    plot(1:(numInitial + iterIdx), bestYieldHistory(1:(numInitial + iterIdx)) * 100, ...
         'b-o', 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'b');
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Best Yield (\%)', 'Interpreter', 'latex', 'FontSize', 11);
    title(sprintf('Optimisation Progress (Iter %d/%d)', iterIdx, numIterations), ...
          'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    xlim([1, numInitial + numIterations]);
    ylim([0, 100]);
    
    subplot(2, 2, 2);
    scatter(allParams(1:numInitial, 1), allYields(1:numInitial) * 100, 80, 'r', 'filled');
    hold on;
    scatter(allParams(numInitial+1:end, 1), allYields(numInitial+1:end) * 100, 80, 'b', 'filled');
    hold off;
    xlabel(paramNames{1}, 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Yield (\%)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Temperature vs. Yield', 'Interpreter', 'latex', 'FontSize', 12);
    legend({'Initial', 'BO Selected'}, 'Location', 'best', 'Interpreter', 'latex');
    grid on;
    
    subplot(2, 2, 3);
    scatter3(allParams(:, 1), allParams(:, 2), allYields * 100, 80, allYields * 100, 'filled');
    colorbar;
    colormap('jet');
    xlabel(paramNames{1}, 'Interpreter', 'latex', 'FontSize', 10);
    ylabel(paramNames{2}, 'Interpreter', 'latex', 'FontSize', 10);
    zlabel('Yield (\%)', 'Interpreter', 'latex', 'FontSize', 10);
    title('3D Parameter Space Exploration', 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    view(45, 30);
    
    subplot(2, 2, 4);
    histogram(allYields * 100, 15, 'FaceColor', [0.3, 0.6, 0.9], 'EdgeColor', 'k');
    xlabel('Yield (\%)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
    title('Yield Distribution', 'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    
    drawnow;
    frame = getframe(figAnimation);
    writeVideo(videoWriter, frame);
    
    fprintf('  Iteration %d: Yield = %.2f%%, Best = %.2f%%\n', ...
            iterIdx, nextYield * 100, max(allYields) * 100);
end

close(videoWriter);
saveas(figAnimation, 'Problem02_FinalState.fig');
saveas(figAnimation, 'Problem02_FinalState.eps', 'epsc');
saveas(figAnimation, 'Problem02_FinalState.jpg');

fprintf('Bayesian optimisation complete\n');
fprintf('  Final best yield: %.2f%%\n', max(allYields) * 100);
fprintf('  Animation saved: Problem02_OptimisationProgress.mp4\n\n');

%% Step 4: Comparison with Random Search
fprintf('Running random search baseline for comparison...\n');

randomParams = rand(numIterations, 4);
for dim = 1:4
    randomParams(:, dim) = paramBounds(dim, 1) + ...
                          randomParams(:, dim) * (paramBounds(dim, 2) - paramBounds(dim, 1));
end

randomYields = zeros(numIterations, 1);
for expIdx = 1:numIterations
    randomYields(expIdx) = trueYieldFunction(randomParams(expIdx, :));
end

randomBestHistory = cummax(randomYields);

% Comparison plot
figure('Name', 'BO vs Random Search', 'Position', [100, 100, 1000, 600]);
plot(1:numIterations, bestYieldHistory(numInitial+1:end) * 100, 'b-o', ...
     'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'b');
hold on;
plot(1:numIterations, randomBestHistory * 100, 'r-s', ...
     'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', 'r');
hold off;
xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Best Yield (\%)', 'Interpreter', 'latex', 'FontSize', 12);
title('Bayesian Optimisation vs. Random Search', 'Interpreter', 'latex', 'FontSize', 14);
legend({'Bayesian Optimisation', 'Random Search'}, 'Location', 'southeast', ...
       'Interpreter', 'latex', 'FontSize', 11);
grid on;

saveas(gcf, 'Problem02_Comparison.fig');
saveas(gcf, 'Problem02_Comparison.eps', 'epsc');
saveas(gcf, 'Problem02_Comparison.jpg');

fprintf('  Random search best yield: %.2f%%\n', max(randomYields) * 100);
fprintf('  Bayesian optimisation improvement: +%.2f%%\n', ...
        (max(allYields) - max(randomYields)) * 100);

%% Summary
fprintf('\n========================================\n');
fprintf('Problem 2 Complete: Optimal Conditions Found\n');
fprintf('========================================\n\n');

[optimalYield, optimalIdx] = max(allYields);
optimalConditions = allParams(optimalIdx, :);

fprintf('Optimal Reaction Conditions:\n');
for dim = 1:4
    fprintf('  %s: %.2f\n', strrep(paramNames{dim}, ' ($^\circ$C)', ' C'), ...
            optimalConditions(dim));
end
fprintf('  Yield: %.2f%%\n\n', optimalYield * 100);

fprintf('========================================\n');

%% Helper Function: Simulate Reaction Yield
function yield = simulateReactionYield(params)
    % Simulated yield function (unknown to optimiser)
    % params = [Temperature, Catalyst, Base, Time]
    
    temp = params(1);
    cat = params(2);
    base = params(3);
    time = params(4);
    
    % Optimal conditions (hidden): T=110 C, Cat=2.5%, Base=2.5eq, Time=12h
    optimalTemp = 110;
    optimalCat = 2.5;
    optimalBase = 2.5;
    optimalTime = 12;
    
    % Gaussian response surface with noise
    yieldBase = exp(-((temp - optimalTemp)^2 / 1000 + ...
                     (cat - optimalCat)^2 / 3 + ...
                     (base - optimalBase)^2 / 2 + ...
                     (time - optimalTime)^2 / 50));
    
    % Add experimental noise
    noise = 0.05 * randn();
    
    yield = max(0, min(1, yieldBase + noise));
end
