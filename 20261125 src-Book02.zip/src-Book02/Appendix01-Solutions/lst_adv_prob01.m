%% lst_adv_prob01.m
% Rocket velocity analysis via numerical differentiation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem01.m
%  Rocket Velocity Analysis Using Numerical Differentiation
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. Define Functions --
altitudeFunction     = @(t) 0.5*t.^3 - 2*t.^2 + 150*t;
velocityAnalytical   = @(t) 1.5*t.^2 - 4*t + 150;
accelerationAnalytical = @(t) 3*t - 4;

%% -- 2. Step-Size Study --
stepSizes = [0.1, 0.5, 1.0, 2.0, 5.0];
numSteps  = numel(stepSizes);

errorForward  = zeros(numSteps, 1);
errorBackward = zeros(numSteps, 1);
errorCentral  = zeros(numSteps, 1);

for stepIndex = 1:numSteps
    deltaT     = stepSizes(stepIndex);
    timePoints = 0:deltaT:100;
    altitude   = altitudeFunction(timePoints);
    numPoints  = numel(timePoints);
    velocityTrue = velocityAnalytical(timePoints);

    % Forward difference  (indices 1 to N-1)
    velForward = diff(altitude) / deltaT;
    errF = abs(velForward - velocityTrue(1:end-1));

    % Backward difference (indices 2 to N)
    velBackward = diff(altitude) / deltaT;
    errB = abs(velBackward - velocityTrue(2:end));

    % Central difference  (indices 2 to N-1)
    velCentral = (altitude(3:end) - altitude(1:end-2)) / (2*deltaT);
    errC = abs(velCentral - velocityTrue(2:end-1));

    errorForward(stepIndex)  = max(errF);
    errorBackward(stepIndex) = max(errB);
    errorCentral(stepIndex)  = max(errC);

    fprintf('Step size = %5.1f s | Max error: Fwd = %10.4f, ' ...
            'Bwd = %10.4f, Cen = %10.4f m/s\n', ...
            deltaT, errorForward(stepIndex), ...
            errorBackward(stepIndex), errorCentral(stepIndex));
end

%% -- 3. Detailed Profile (dt = 0.1 s) --
deltaT   = 0.1;
timeFine = 0:deltaT:100;
altFine  = altitudeFunction(timeFine);

velCentralFine = (altFine(3:end) - altFine(1:end-2)) / (2*deltaT);
timeCentral    = timeFine(2:end-1);

accCentralFine = (altFine(3:end) - 2*altFine(2:end-1) ...
                  + altFine(1:end-2)) / deltaT^2;

%% -- 4. Visualisation --
figHandle = figure('Position', [100 100 1200 500]);

subplot(1,2,1);
plot(timeCentral, velCentralFine, 'b-', 'LineWidth', 1.2); hold on;
plot(timeCentral, velocityAnalytical(timeCentral), 'r-', ...
     'LineWidth', 1.2);
xlabel('$t$ (s)', 'Interpreter', 'latex');
ylabel('$v(t)$ (m/s)', 'Interpreter', 'latex');
title('Velocity Profile', 'Interpreter', 'latex');
legend({'Central difference', 'Analytical'}, ...
       'Interpreter', 'latex', 'Location', 'northwest');
grid on;

subplot(1,2,2);
loglog(stepSizes, errorForward, 'ro-', 'LineWidth', 1.2); hold on;
loglog(stepSizes, errorBackward, 'bs-', 'LineWidth', 1.2);
loglog(stepSizes, errorCentral, 'g^-', 'LineWidth', 1.2);
xlabel('$\Delta t$ (s)', 'Interpreter', 'latex');
ylabel('Max absolute error (m/s)', 'Interpreter', 'latex');
title('Error Convergence', 'Interpreter', 'latex');
legend({'Forward $O(\Delta t)$', 'Backward $O(\Delta t)$', ...
        'Central $O(\Delta t^2)$'}, ...
       'Interpreter', 'latex', 'Location', 'northwest');
grid on;

%% -- 5. Save Outputs --
savefig(figHandle, 'Problem01_RocketVelocity.fig');
exportgraphics(figHandle, 'Problem01_RocketVelocity.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem01_RocketVelocity.jpg', ...
               'Resolution', 300);

fprintf('\n-- Problem 1 Complete --\n');
% Computational Complexity:
% Each finite-difference scheme traverses n data points once,
% giving O(n) time per scheme.  The step-size loop adds a
% factor of m (number of step sizes), yielding O(m*n) overall.
% Space complexity is O(n).  Central differencing achieves
% O(dt^2) truncation error versus O(dt) for forward/backward
% methods, delivering superior accuracy at identical
% computational cost.
