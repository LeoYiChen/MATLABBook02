%% chapter_FundamentalMathematics_example_PCA.m
% Principal Component Analysis using eigendecomposition.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_PCA
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Principal Component Analysis using Eigendecomposition
% Demonstrates dimensionality reduction technique

% Generate sample high-dimensional data
numSamples = 100;
numFeatures = 5;
rng(42);  % Set random seed for reproducibility
dataMatrix = randn(numSamples, numFeatures);

% Add correlation structure
correlationMatrix = [1, 0.8, 0.6, 0.3, 0.1; ...
                     0.8, 1, 0.7, 0.4, 0.2; ...
                     0.6, 0.7, 1, 0.5, 0.3; ...
                     0.3, 0.4, 0.5, 1, 0.6; ...
                     0.1, 0.2, 0.3, 0.6, 1];
dataMatrix = dataMatrix * chol(correlationMatrix);

% Centre the data (zero mean)
centredData = dataMatrix - mean(dataMatrix);

% Compute covariance matrix
covarianceMatrix = (centredData' * centredData) / (numSamples - 1);

% Perform eigendecomposition
[eigenvectors, eigenvalueMatrix] = eig(covarianceMatrix);
eigenvalues = diag(eigenvalueMatrix);

% Sort by descending eigenvalues
[sortedEigenvalues, sortIndices] = sort(eigenvalues, 'descend');
sortedEigenvectors = eigenvectors(:, sortIndices);

% Calculate explained variance ratio
explainedVariance = sortedEigenvalues / sum(sortedEigenvalues);
cumulativeVariance = cumsum(explainedVariance);

% Display results
fprintf('Explained variance by component:\n');
for componentIdx = 1:numFeatures
    fprintf('PC%d: %.2f%% (cumulative: %.2f%%)\n', ...
        componentIdx, explainedVariance(componentIdx)*100, ...
        cumulativeVariance(componentIdx)*100);
end

% Project data onto first two principal components
numComponentsToKeep = 2;
principalComponents = sortedEigenvectors(:, 1:numComponentsToKeep);
reducedData = centredData * principalComponents;

fprintf('\nOriginal dimensionality: %d\n', numFeatures);
fprintf('Reduced dimensionality: %d\n', numComponentsToKeep);
fprintf('Variance retained: %.2f%%\n', ...
    cumulativeVariance(numComponentsToKeep)*100);
