%% chapter_Combinatorics_example_decision.m
% Combinatorial analysis for multi-factor decision-making.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Combinatorics_example_decision
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateDecisionCombinatorics();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateDecisionCombinatorics()
    % DEMONSTRATEDECISIONCOMBINATORICS Multi-factor decision analysis
    %   Uses combinatorial methods to analyse decisions with multiple factors
    
    fprintf('Combinatorial Decision Analysis\n');
    fprintf('================================\n\n');
    
    %% Investment Decision Framework
    fprintf('INVESTMENT DECISION FRAMEWORK\n');
    fprintf('-----\n\n');
    
    fprintf(['Charlie Munger: "I use a multidisciplinary approach to\n', ...
        'thinking, trying to use basic ideas from different fields to\n', ...
        'create a latticework of mental models."\n\n']);
    
    % Define investment factors and their possible states
    factors = struct();
    factors.management = {'Excellent', 'Good', 'Average', 'Poor'};
    factors.competitive_position = {'Dominant', 'Strong', 'Weak'};
    factors.market_conditions = {'Growing', 'Stable', 'Declining'};
    factors.valuation = {'Cheap', 'Fair', 'Expensive'};
    
    fprintf('Investment factors considered:\n');
    fprintf('  1. Management quality: %d levels\n', ...
        length(factors.management));
    fprintf('  2. Competitive position: %d levels\n', ...
        length(factors.competitive_position));
    fprintf('  3. Market conditions: %d levels\n', ...
        length(factors.market_conditions));
    fprintf('  4. Valuation: %d levels\n\n', ...
        length(factors.valuation));
    
    % Calculate total possible combinations
    total_combinations = length(factors.management) * ...
        length(factors.competitive_position) * ...
        length(factors.market_conditions) * ...
        length(factors.valuation);
    
    fprintf('Total possible combinations: %d\n\n', total_combinations);
    
    fprintf(['Not all combinations are equally likely or equally attractive.\n', ...
        'Combinatorial analysis helps identify optimal configurations.\n\n']);
    
    %% Product Design Scenario
    fprintf('PRODUCT DESIGN SCENARIO\n');
    fprintf('----\n\n');
    
    fprintf('Product attributes to optimise:\n');
    
    % Define product attributes
    attributes = struct();
    attributes.performance = [1, 2, 3, 4, 5];  % 1=low, 5=high
    attributes.price = [1, 2, 3, 4, 5];         % 1=low, 5=high
    attributes.ease_of_use = [1, 2, 3, 4, 5];  % 1=difficult, 5=easy
    attributes.features = [1, 2, 3, 4, 5];     % 1=minimal, 5=extensive
    
    fprintf('  Performance: %d levels\n', length(attributes.performance));
    fprintf('  Price: %d levels\n', length(attributes.price));
    fprintf('  Ease of use: %d levels\n', length(attributes.ease_of_use));
    fprintf('  Features: %d levels\n\n', length(attributes.features));
    
    total_configs = length(attributes.performance) * ...
        length(attributes.price) * length(attributes.ease_of_use) * ...
        length(attributes.features);
    
    fprintf('Total possible configurations: %d\n\n', total_configs);
    
    % Define utility function (simplified model)
    fprintf('Evaluating configurations with utility function...\n\n');
    
    best_utility = -inf;
    best_config = [];
    utility_distribution = [];
    
    for perf = attributes.performance
        for price = attributes.price
            for ease = attributes.ease_of_use
                for feat = attributes.features
                    % Simplified utility: value creation minus cost
                    % Higher performance and ease increase utility
                    % Higher price and features increase cost
                    utility = (perf * 2 + ease * 1.5) - (price * 1.8 + feat * 0.8);
                    
                    utility_distribution = [utility_distribution; utility];
                    
                    if utility > best_utility
                        best_utility = utility;
                        best_config = [perf, price, ease, feat];
                    end
                end
            end
        end
    end
    
    fprintf('Optimal configuration found:\n');
    fprintf('  Performance: %d/5\n', best_config(1));
    fprintf('  Price: %d/5\n', best_config(2));
    fprintf('  Ease of use: %d/5\n', best_config(3));
    fprintf('  Features: %d/5\n', best_config(4));
    fprintf('  Utility score: %.2f\n\n', best_utility);
    
    fprintf('Note: This optimal configuration is not necessarily maximal\n');
    fprintf('in any single dimension but maximises the combination.\n\n');
    
    %% Portfolio Construction
    fprintf('PORTFOLIO CONSTRUCTION PROBLEM\n');
    fprintf('-----\n\n');
    
    % Simplified portfolio selection
    num_assets = 8;
    portfolio_size = 4;
    
    fprintf('Selecting %d assets from %d available assets:\n', ...
        portfolio_size, num_assets);
    
    num_portfolios = nchoosek(num_assets, portfolio_size);
    fprintf('  Number of possible portfolios: %d\n\n', num_portfolios);
    
    % Simulate asset returns (mean and covariance)
    rng(42);
    expected_returns = 0.05 + 0.10 * rand(num_assets, 1);
    
    fprintf('Expected annual returns for each asset:\n');
    for i = 1:num_assets
        fprintf('  Asset %d: %.2f%%\n', i, expected_returns(i) * 100);
    end
    fprintf('\n');
    
    % Generate all possible portfolios
    all_portfolios = nchoosek(1:num_assets, portfolio_size);
    
    fprintf('Evaluating portfolio combinations...\n\n');
    
    portfolio_returns = zeros(num_portfolios, 1);
    
    for i = 1:num_portfolios
        % Equal-weighted portfolio
        selected_assets = all_portfolios(i, :);
        portfolio_returns(i) = mean(expected_returns(selected_assets));
    end
    
    [max_return, best_idx] = max(portfolio_returns);
    best_portfolio = all_portfolios(best_idx, :);
    
    fprintf('Best equal-weighted portfolio:\n');
    fprintf('  Assets: [%s]\n', num2str(best_portfolio));
    fprintf('  Expected return: %.2f%%\n\n', max_return * 100);
    
    %% Clinical Trial Design
    fprintf('CLINICAL TRIAL DESIGN\n');
    fprintf('-----\n\n');
    
    fprintf(['Combinatorial analysis in experimental design ensures\n', ...
        'comprehensive testing whilst managing resource constraints.\n\n']);
    
    % Treatment combinations
    drug_doses = [10, 20, 30];  % mg
    frequency = [1, 2, 3];       % times per day
    duration = [7, 14, 28];      % days
    
    total_protocols = length(drug_doses) * length(frequency) * ...
        length(duration);
    
    fprintf('Treatment protocol factors:\n');
    fprintf('  Drug doses: [%s] mg\n', num2str(drug_doses));
    fprintf('  Frequency: [%s] times/day\n', num2str(frequency));
    fprintf('  Duration: [%s] days\n\n', num2str(duration));
    
    fprintf('Total possible protocols: %d\n\n', total_protocols);
    
    fprintf('With limited resources (e.g., 100 patients), researchers must:\n');
    fprintf('  1. Select most promising combinations\n');
    fprintf('  2. Use factorial or fractional factorial designs\n');
    fprintf('  3. Apply sequential testing strategies\n\n');
    
    fprintf('Full factorial design requires testing all %d combinations.\n', ...
        total_protocols);
    fprintf(['Fractional factorial or optimal design reduces this whilst\n', ...
        'preserving statistical power for main effects.\n\n']);
    
    %% Visualisation
    visualiseUtilityDistribution(utility_distribution);
    visualisePortfolioReturns(portfolio_returns, expected_returns);
    visualiseFactorialDesign(drug_doses, frequency, duration);
end

function visualiseUtilityDistribution(utility_values)
    % Visualise distribution of utility across configurations
    
    figure('Position', [100, 100, 1200, 400]);
    
    subplot(1, 3, 1);
    histogram(utility_values, 30, 'FaceColor', [0.2, 0.6, 0.8]);
    xlabel('Utility Score');
    ylabel('Frequency');
    title('Distribution of Configuration Utilities');
    grid on;
    
    subplot(1, 3, 2);
    sorted_utilities = sort(utility_values, 'descend');
    plot(1:length(sorted_utilities), sorted_utilities, 'b-', 'LineWidth', 2);
    xlabel('Configuration Rank');
    ylabel('Utility Score');
    title('Ranked Configuration Utilities');
    grid on;
    
    subplot(1, 3, 3);
    percentiles = prctile(utility_values, [10, 25, 50, 75, 90]);
    bar(percentiles);
    set(gca, 'XTickLabel', {'10*th', '25*th', '50*th', '75*th', '90*th'});
    ylabel('Utility Score');
    title('Utility Distribution Percentiles');
    grid on;
end

function visualisePortfolioReturns(portfolio_returns, asset_returns)
    % Visualise portfolio return distribution
    
    figure('Position', [100, 100, 1200, 400]);
    
    subplot(1, 3, 1);
    histogram(portfolio_returns * 100, 25, 'FaceColor', [0.3, 0.7, 0.3]);
    xlabel('Expected Portfolio Return (%)');
    ylabel('Number of Portfolios');
    title('Portfolio Return Distribution');
    grid on;
    
    subplot(1, 3, 2);
    scatter(1:length(asset_returns), asset_returns * 100, 100, 'filled');
    xlabel('Asset Number');
    ylabel('Expected Return (%)');
    title('Individual Asset Returns');
    grid on;
    
    subplot(1, 3, 3);
    sorted_returns = sort(portfolio_returns * 100, 'descend');
    plot(sorted_returns, 'r-', 'LineWidth', 2);
    hold on;
    yline(mean(sorted_returns), 'b-', 'Mean', 'LineWidth', 1.5);
    xlabel('Portfolio Rank');
    ylabel('Expected Return (%)');
    title('Ranked Portfolio Returns');
    grid on;
    legend('Portfolio Returns', 'Average', 'Location', 'best');
end

function visualiseFactorialDesign(doses, frequencies, durations)
    % Visualise factorial design space
    
    figure('Position', [100, 100, 800, 600]);
    
    [D, F, T] = meshgrid(doses, frequencies, durations);
    
    % Create 3*D scatter plot of all treatment combinations
    scatter3(D(:), F(:), T(:), 100, 'filled', 'MarkerFaceAlpha', 0.6);
    xlabel('Dose (mg)');
    ylabel('Frequency (times/day)');
    zlabel('Duration (days)');
    title('Full Factorial Design Space');
    grid on;
    view(45, 30);
end
