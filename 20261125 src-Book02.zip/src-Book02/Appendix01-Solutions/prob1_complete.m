%% prob1_complete.m
% Problem 1: Complete Amdahl's Law Analysis for Deep Learning.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob1_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 1: Amdahl's Law Application to Deep Learning Training
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Analyses speedup, efficiency, and scalability limits for
%              distributed deep learning using Amdahl's Law framework
%
% Revision History:
%   v1.0 (15-Jan-2025): Initial implementation with visualisation
%   v1.1 (15-Jan-2025): Added efficiency degradation analysis

%% Initialisation
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 1: Amdahl''s Law Application to Deep Learning Training\n');
fprintf('================================================================\n\n');

%% Define Workload Parameters
% Training pipeline time distribution
dataLoadingFraction = 0.15;      % Serial: I/O bound operations
forwardPropFraction = 0.40;      % Parallel: Forward pass computation
backwardPropFraction = 0.35;     % Parallel: Gradient computation
gradientSyncFraction = 0.10;     % Serial: All-reduce communication

% Aggregate fractions
serialFraction = dataLoadingFraction + gradientSyncFraction;
parallelFraction = forwardPropFraction + backwardPropFraction;

% Validation
assert(abs((serialFraction + parallelFraction) - 1.0) < 1e-10, ...
       'Fractions must sum to 1.0');

fprintf('Workload Composition Analysis:\n');
fprintf('  Data loading (serial):      %5.1f%%\n', dataLoadingFraction * 100);
fprintf('  Forward propagation (||):   %5.1f%%\n', forwardPropFraction * 100);
fprintf('  Backward propagation (||):  %5.1f%%\n', backwardPropFraction * 100);
fprintf('  Gradient sync (serial):     %5.1f%%\n', gradientSyncFraction * 100);
fprintf('  --------------------\n');
fprintf('  Total serial:               %5.1f%%\n', serialFraction * 100);
fprintf('  Total parallel:             %5.1f%%\n\n', parallelFraction * 100);

% Baseline training configuration
baselineTime_hours = 100;
fprintf('Baseline single-GPU training time: %.0f hours\n\n', baselineTime_hours);

%% Part (a): Maximum Theoretical Speedup
maxSpeedup = 1 / serialFraction;
minTrainingTime_hours = baselineTime_hours / maxSpeedup;

fprintf('========================================\n');
fprintf('(a) Maximum Theoretical Speedup\n');
fprintf('========================================\n');
fprintf('Using Amdahl''s Law for infinite processors:\n');
fprintf('  $$S_{\\mathrm{max}} = \\frac{1}{1-P} = \\frac{1}{%.2f} = %.3f\\times$$\n', ...
        parallelFraction, maxSpeedup);
fprintf('  Minimum possible training time: %.2f hours\n', minTrainingTime_hours);
fprintf('  Maximum time reduction: %.1f%%\n\n', (1 - 1/maxSpeedup) * 100);

%% Part (b): Speedup for Specific GPU Configurations
gpuCounts = [4, 8, 16, 32];
numConfigs = length(gpuCounts);

% Pre-allocate result arrays
speedups = zeros(1, numConfigs);
trainingTimes = zeros(1, numConfigs);
efficiencies = zeros(1, numConfigs);
timeReductions = zeros(1, numConfigs);

fprintf('========================================\n');
fprintf('(b) Speedup for Specific GPU Counts\n');
fprintf('========================================\n');
fprintf('%-8s %-10s %-18s %-15s %-18s\n', 'GPUs', 'Speedup', ...
        'Time (hours)', 'Efficiency', 'Time Reduction');
fprintf('%s\n', repmat('-', 1, 75));

for i = 1:numConfigs
    N = gpuCounts(i);
    
    % Calculate speedup using Amdahl's Law
    speedups(i) = calculateAmdahlSpeedup(parallelFraction, N);
    
    % Derive training time
    trainingTimes(i) = baselineTime_hours / speedups(i);
    
    % Calculate parallel efficiency
    efficiencies(i) = (speedups(i) / N) * 100;
    
    % Time reduction percentage
    timeReductions(i) = (1 - trainingTimes(i)/baselineTime_hours) * 100;
    
    fprintf('%-8d %-10.4f %-18.2f %-15.2f%% %-18.1f%%\n', ...
            N, speedups(i), trainingTimes(i), efficiencies(i), ...
            timeReductions(i));
end
fprintf('\n');

%% Part (c): Parallel Efficiency Analysis
fprintf('========================================\n');
fprintf('(c) Parallel Efficiency Analysis\n');
fprintf('========================================\n');
fprintf('Efficiency degradation with scaling:\n');
for i = 1:numConfigs
    idealSpeedup = gpuCounts(i);
    actualSpeedup = speedups(i);
    wastedResources = idealSpeedup - actualSpeedup;
    
    fprintf('  %2d GPUs: %.1f%% efficient | %.2fx actual vs %.0fx ideal | ', ...
            gpuCounts(i), efficiencies(i), actualSpeedup, idealSpeedup);
    fprintf('%.2fx wasted\n', wastedResources);
end
fprintf('\n');

% Identify optimal configuration (best efficiency above 50%)
optimalIdx = find(efficiencies >= 50, 1, 'last');
if ~isempty(optimalIdx)
    fprintf('Recommended configuration: %d GPUs (%.1f%% efficient, %.2fx speedup)\n\n', ...
            gpuCounts(optimalIdx), efficiencies(optimalIdx), speedups(optimalIdx));
else
    fprintf('Warning: All configurations below 50%% efficiency\n\n');
end

%% Part (d): Feasibility of 10x Speedup
targetSpeedup = 10;

fprintf('========================================\n');
fprintf('(d) Feasibility of %.0fx Speedup\n', targetSpeedup);
fprintf('========================================\n');

if targetSpeedup <= maxSpeedup
    % Solve Amdahl's equation: target = 1 / (s + p/N)
    % Rearranged: N = p / (1/target - s)
    requiredGPUs_exact = parallelFraction / (1/targetSpeedup - serialFraction);
    requiredGPUs_ceil = ceil(requiredGPUs_exact);
    
    actualSpeedup = calculateAmdahlSpeedup(parallelFraction, requiredGPUs_ceil);
    
    fprintf('Target speedup: %.0fx\n', targetSpeedup);
    fprintf('Theoretical GPUs required: %.2f\n', requiredGPUs_exact);
    fprintf('Practical minimum: %d GPUs\n', requiredGPUs_ceil);
    fprintf('Achieved speedup with %d GPUs: %.4fx\n\n', ...
            requiredGPUs_ceil, actualSpeedup);
else
    fprintf('CONCLUSION: %.0fx speedup is IMPOSSIBLE\n', targetSpeedup);
    fprintf('Reason: Serial fraction (%.0f%%) limits maximum speedup to %.2fx\n', ...
            serialFraction * 100, maxSpeedup);
    fprintf('Gap: Requested %.2fx exceeds theoretical limit by %.2fx\n\n', ...
            targetSpeedup, targetSpeedup - maxSpeedup);
    
    fprintf('Recommendations to approach %.0fx speedup:\n', targetSpeedup);
    fprintf('  1. Reduce serial fraction through asynchronous data loading\n');
    fprintf('  2. Implement gradient compression to reduce sync time\n');
    fprintf('  3. Use pipeline parallelism to overlap computation and communication\n');
    fprintf('  4. Consider model parallelism for very large models\n\n');
end

%% Visualisation: Three-Panel Analysis
figure('Position', [100, 100, 1400, 450], 'Color', 'w');

% Panel 1: Speedup vs GPU Count (with Amdahl curve)
subplot(1, 3, 1);
gpuRange = 1:64;
speedupCurve = arrayfun(@(n) calculateAmdahlSpeedup(parallelFraction, n), ...
                        gpuRange);

plot(gpuRange, speedupCurve, 'b-', 'LineWidth', 2.5);
hold on;
plot(gpuCounts, speedups, 'ro', 'MarkerSize', 12, 'LineWidth', 2.5, ...
     'MarkerFaceColor', 'r');
plot(gpuRange, gpuRange, 'k-', 'LineWidth', 1.5);
yline(maxSpeedup, 'r-', 'LineWidth', 2, ...
      'Label', sprintf('$S_{\\mathrm{max}} = %.2f\\times$', maxSpeedup), ...
      'Interpreter', 'latex', 'FontSize', 11, ...
      'LabelHorizontalAlignment', 'left');

grid on; box on;
xlabel('Number of GPUs', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Speedup Factor', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(a) Speedup vs GPU Count}', 'Interpreter', 'latex', ...
      'FontSize', 14);
legend({'Amdahl''s Law', 'Evaluated Points', 'Ideal Linear Scaling'}, ...
       'Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 10);
xlim([0, 64]); ylim([0, 12]);
set(gca, 'FontSize', 11);

% Panel 2: Parallel Efficiency Degradation
subplot(1, 3, 2);
efficiencyCurve = (speedupCurve ./ gpuRange) * 100;

plot(gpuRange, efficiencyCurve, 'b-', 'LineWidth', 2.5);
hold on;
plot(gpuCounts, efficiencies, 'ro', 'MarkerSize', 12, 'LineWidth', 2.5, ...
     'MarkerFaceColor', 'r');
yline(50, 'k-', 'LineWidth', 1.5, 'Label', '50\% Threshold', ...
      'Interpreter', 'latex', 'FontSize', 10);

grid on; box on;
xlabel('Number of GPUs', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Parallel Efficiency (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(b) Efficiency Degradation}', 'Interpreter', 'latex', ...
      'FontSize', 14);
xlim([0, 64]); ylim([0, 110]);
set(gca, 'FontSize', 11);

% Panel 3: Training Time Reduction (log scale)
subplot(1, 3, 3);
trainingTimeCurve = baselineTime_hours ./ speedupCurve;

semilogy(gpuRange, trainingTimeCurve, 'b-', 'LineWidth', 2.5);
hold on;
semilogy(gpuCounts, trainingTimes, 'ro', 'MarkerSize', 12, 'LineWidth', 2.5, ...
         'MarkerFaceColor', 'r');
yline(minTrainingTime_hours, 'r-', 'LineWidth', 2, ...
      'Label', sprintf('Minimum: %.1f hrs', minTrainingTime_hours), ...
      'Interpreter', 'latex', 'FontSize', 10, ...
      'LabelHorizontalAlignment', 'right');

grid on; box on;
xlabel('Number of GPUs', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Training Time (hours)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(c) Training Time Reduction}', 'Interpreter', 'latex', ...
      'FontSize', 14);
xlim([0, 64]);
set(gca, 'FontSize', 11);

%% Summary Statistics Table
fprintf('========================================\n');
fprintf('Summary Statistics\n');
fprintf('========================================\n');
fprintf('Maximum achievable speedup:     %.3fx\n', maxSpeedup);
fprintf('Best practical configuration:   %d GPUs (%.1f%% efficient)\n', ...
        gpuCounts(optimalIdx), efficiencies(optimalIdx));
fprintf('Time savings with optimal:      %.1f%% (%.1f hours saved)\n', ...
        timeReductions(optimalIdx), ...
        baselineTime_hours - trainingTimes(optimalIdx));
fprintf('Diminishing returns threshold:  ~8 GPUs (efficiency < 50%%)\n');
fprintf('========================================\n\n');

%% Helper Function
function speedup = calculateAmdahlSpeedup(parallelFraction, numProcessors)
    % CALCULATEAMDAHLSPEEDUP Computes theoretical speedup using Amdahl's Law
    %
    % Syntax:
    %   speedup = calculateAmdahlSpeedup(parallelFraction, numProcessors)
    %
    % Inputs:
    %   parallelFraction - Fraction of workload that can be parallelised [0,1]
    %   numProcessors - Number of parallel processing units (GPUs)
    %
    % Output:
    %   speedup - Theoretical speedup factor relative to serial execution
    %
    % Mathematical formulation:
    %   S(N) = 1 / ((1-P) + P/N)
    %   where P = parallelFraction, N = numProcessors
    %
    % Author: Dr Yi Chen, Newcastle University
    % Date: 15 January 2025
    
    % Input validation
    assert(parallelFraction >= 0 && parallelFraction <= 1, ...
           'Parallel fraction must be in range [0, 1]');
    assert(numProcessors >= 1, 'Number of processors must be >= 1');
    
    % Calculate serial fraction
    serialFraction = 1 - parallelFraction;
    
    % Apply Amdahl's Law
    speedup = 1 / (serialFraction + parallelFraction / numProcessors);
end
