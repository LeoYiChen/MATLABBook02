%% C020201Maths_Fundamental_code_099.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Richardson extrapolation for derivatives
h = 0.1;
D1 = (testFunction(x + h) - testFunction(x - h)) / (2 * h);
D2 = (testFunction(x + h/2) - testFunction(x - h/2)) / h;

% Extrapolated derivative (eliminates h^2 term)
derivativeRichardson = (4 * D2 - D1) / 3;
