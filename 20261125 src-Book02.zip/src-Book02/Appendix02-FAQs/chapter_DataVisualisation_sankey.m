%% chapter_DataVisualisation_sankey.m
% Sankey Diagram Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_sankey
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createSankeyDiagram(sources, targets, values, labels)
% Validate inputs
if ~(length(sources) == length(targets) && ...
length(sources) == length(values))
error('Input vectors must have equal length');
end

figure('Position', [100 100 1000 600]);
hold on;

% Calculate node positions
[unique_nodes, ~, ic] = unique([sources, targets]);
n_nodes = length(unique_nodes);
node_y = linspace(0.1, 0.9, n_nodes);

% Draw flows
max_value = max(values);
for i = 1:length(sources)
    source_idx = ic(sources(i));
    target_idx = ic(targets(i) + n_nodes);
    
    % Calculate flow width
    width = 0.05 * values(i)/max_value;
    
    % Draw flow path
    x = [0.2, 0.8];  % Horizontal positions
    y1 = node_y(source_idx);
    y2 = node_y(target_idx);
    
    % Bezier curve control points
    cx1 = 0.4;  % First control point x
    cx2 = 0.6;  % Second control point x
    
    % Generate Bezier curve points
    t = linspace(0, 1, 100);
    x_curve = (1-t).^3 * x(1) + ...
             3*(1-t).^2.*t * cx1 + ...
             3*(1-t).*t.^2 * cx2 + ...
             t.^3 * x(2);
    y_curve = (1-t).^3 * y1 + ...
             3*(1-t).^2.*t * y1 + ...
             3*(1-t).*t.^2 * y2 + ...
             t.^3 * y2;
             
    % Plot flow
    fill([x_curve, fliplr(x_curve)], ...
         [y_curve+width, fliplr(y_curve-width)], ...
         'b', 'FaceAlpha', 0.3);
end

% Add node labels
for i = 1:length(unique_nodes)
    text(0.15, node_y(i), labels{unique_nodes(i)}, ...
         'HorizontalAlignment', 'right');
    text(0.85, node_y(i), labels{unique_nodes(i)}, ...
         'HorizontalAlignment', 'left');
end

axis off;
title('System Flow Analysis');


% Export figure in multiple formats
exportFigure(gca, 'SankeyDiagram_plot');

end
