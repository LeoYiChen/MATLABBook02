%% chapter_Problems_sol4_matlab.m
% MATLAB script for Python integration
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Problems_sol4_matlab
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Check if Python is configured properly
try
pe = pyenv;
fprintf('Python environment is configured:\n');
fprintf(' Version: %s\n', pe.Version);
fprintf(' Executable: %s\n', pe.Executable);
fprintf(' Library: %s\n', pe.Library);
fprintf(' Home: %s\n', pe.Home);
catch ME
error('Python environment is not properly configured. Please run pyenv to set it up.');
end

% Generate synthetic data in MATLAB
fprintf('Generating synthetic dataset in MATLAB...\n');

% Set random seed for reproducibility
rng(42);

% Number of data points and features
n_samples = 1000;
n_features = 5;

% Generate features with correlation structure
mu = zeros(1, n_features);
sigma = eye(n_features);

% Add correlation between some features
sigma(1, 2) = 0.7;
sigma(2, 1) = 0.7;
sigma(3, 4) = -0.5;
sigma(4, 3) = -0.5;

% Generate multivariate normal data
X = mvnrnd(mu, sigma, n_samples);

% Generate target variable with nonlinear relationship
% y = x1^2 + x2x3 - 2x4 + noise
y = X(:,1).^2 + X(:,2).X(:,3) - 2X(:,4) + 0.5*randn(n_samples, 1);

% Display basic statistics of the generated data
fprintf('Data generated with %d samples and %d features.\n', n_samples, n_features);
fprintf('Feature correlation matrix:\n');
disp(corr(X));

fprintf('First 5 samples of X:\n');
disp(X(1:5,:));

fprintf('First 5 values of y:\n');
disp(y(1:5));

% Export data to CSV for Python
fprintf('Exporting data to CSV...\n');
data_table = array2table([X y], 'VariableNames', {'X1', 'X2', 'X3', 'X4', 'X5', 'y'});
writetable(data_table, 'matlab_data.csv');

% Create Python script for data processing
fprintf('Creating Python script for data processing...\n');
python_script = [
'import numpy as np\n',...
'import pandas as pd\n',...
'from sklearn.preprocessing import StandardScaler\n',...
'from sklearn.decomposition import PCA\n',...
'from sklearn.ensemble import RandomForestRegressor\n',...
'from sklearn.model_selection import train_test_split\n',...
'from sklearn.metrics import mean_squared_error, r2_score\n',...
'\n',...
'def process_data(input_file, output_file):\n',...
' # Load data\n',...
' print("Loading data from", input_file)\n',...
' data = pd.read_csv(input_file)\n',...
' \n',...
' # Split features and target\n',...
' X = data.drop("y", axis=1).values\n',...
' y = data["y"].values\n',...
' \n',...
' # Split into training and testing sets\n',...
' X_train, X_test, y_train, y_test = train_test_split(\n',...
' X, y, test_size=0.3, random_state=42)\n',...
' \n',...
' # Standardize features\n',...
' scaler = StandardScaler()\n',...
' X_train_scaled = scaler.fit_transform(X_train)\n',...
' X_test_scaled = scaler.transform(X_test)\n',...
' \n',...
' # PCA for dimensionality reduction\n',...
' pca = PCA(n_components=3)\n',...
' X_train_pca = pca.fit_transform(X_train_scaled)\n',...
' X_test_pca = pca.transform(X_test_scaled)\n',...
' \n',...
' # Train a Random Forest model\n',...
' model = RandomForestRegressor(n_estimators=100, random_state=42)\n',...
' model.fit(X_train_scaled, y_train)\n',...
' \n',...
' # Make predictions\n',...
' y_pred = model.predict(X_test_scaled)\n',...
' \n',...
' # Calculate model performance\n',...
' mse = mean_squared_error(y_test, y_pred)\n',...
' r2 = r2_score(y_test, y_pred)\n',...
' \n',...
' # Feature importance\n',...
' feature_importance = model.feature_importances_\n',...
' \n',...
' # Prepare results\n',...
' results = {\n',...
' "mse": mse,\n',...
' "r2": r2,\n',...
' "feature_importance": feature_importance,\n',...
' "explained_variance_ratio": pca.explained_variance_ratio_,\n',...
' "pca_components": pca.components_,\n',...
' "X_test_indices": np.arange(len(y_test)),\n',...
' "y_test": y_test,\n',...
' "y_pred": y_pred\n',...
' }\n',...
' \n',...
' # Save results to CSV\n',...
' print("Saving results to", output_file)\n',...
' result_df = pd.DataFrame({\n',...
' "X_test_index": np.arange(len(y_test)),\n',...
' "y_test": y_test,\n',...
' "y_pred": y_pred\n',...
' })\n',...
' result_df.to_csv(output_file, index=False)\n',...
' \n',...
' # Also save feature importance and PCA results\n',...
' pd.DataFrame({\n',...
' "feature": ["X1", "X2", "X3", "X4", "X5"],\n',...
' "importance": feature_importance\n',...
' }).to_csv("feature_importance.csv", index=False)\n',...
' \n',...
' pd.DataFrame({\n',...
' "component": ["PC1", "PC2", "PC3"],\n',...
' "explained_variance": pca.explained_variance_ratio_\n',...
' }).to_csv("pca_variance.csv", index=False)\n',...
' \n',...
' pd.DataFrame(\n',...
' pca.components_,\n',...
' columns=["X1", "X2", "X3", "X4", "X5"],\n',...
' index=["PC1", "PC2", "PC3"]\n',...
' ).to_csv("pca_components.csv")\n',...
' \n',...
' return results\n',...
'\n',...
'if name == "main":\n',...
' import sys\n',...
' if len(sys.argv) >= 3:\n',...
' process_data(sys.argv[1], sys.argv[2])\n',...
' else:\n',...
' process_data("matlab_data.csv", "python_results.csv")\n'
];

% Write Python script to file
fid = fopen('process_data.py', 'w');
fprintf(fid, '%s', python_script);
fclose(fid);

% Execute Python script from MATLAB
fprintf('Executing Python script from MATLAB...\n');
try
% Method 1: Using system command
tic;
system_cmd = sprintf('python process_data.py matlab_data.csv python_results.csv');
[status, cmdout] = system(system_cmd);
system_time = toc;

if status ~= 0
    fprintf('Error executing Python script via system command:\n%s\n', cmdout);
else
    fprintf('Python script executed successfully via system command in %.2f seconds.\n', system_time);
    fprintf('Python output:\n%s\n', cmdout);
end

% Method 2: Using MATLAB Engine API for Python
tic;
py_module = py.importlib.import_module('process_data');
results_py = py_module.process_data('matlab_data.csv', 'python_results_api.csv');
engine_time = toc;

fprintf('Python script executed successfully via MATLAB Engine API in %.2f seconds.\n', engine_time);

% Extract results from Python
mse = double(results_py{'mse'});
r2 = double(results_py{'r2'});
feature_importance = double(py.array.array('d', results_py{'feature_importance'}));
explained_variance_ratio = double(py.array.array('d', results_py{'explained_variance_ratio'}));
y_test = double(py.array.array('d', results_py{'y_test'}));
y_pred = double(py.array.array('d', results_py{'y_pred'}));

fprintf('Results from Python:\n');
fprintf('  Mean Squared Error: %.4f\n', mse);
fprintf('  RScore: %.4f\n', r2);
fprintf('  Feature Importance:\n');
for i = 1:length(feature_importance)
    fprintf('    X%d: %.4f\n', i, feature_importance(i));
end
fprintf('  PCA Explained Variance Ratio:\n');
for i = 1:length(explained_variance_ratio)
    fprintf('    PC%d: %.4f\n', i, explained_variance_ratio(i));
end

% Compare with MATLAB implementation
fprintf('\nImplementing similar analysis in MATLAB for comparison...\n');

% Load the data
tic;
data_matlab = readtable('matlab_data.csv');
X_matlab = data_matlab{:, 1:5};
y_matlab = data_matlab{:, 6};

% Split into training and testing sets
cv = cvpartition(length(y_matlab), 'HoldOut', 0.3, 'Stratify', false);
X_train_matlab = X_matlab(cv.training, :);
y_train_matlab = y_matlab(cv.training);
X_test_matlab = X_matlab(cv.test, :);
y_test_matlab = y_matlab(cv.test);

% Standardize features
X_train_mean = mean(X_train_matlab);
X_train_std = std(X_train_matlab);
X_train_scaled = (X_train_matlab - X_train_mean) ./ X_train_std;
X_test_scaled = (X_test_matlab - X_train_mean) ./ X_train_std;

% PCA
[coeff, score, latent, ~, explained] = pca(X_train_scaled);
X_train_pca = X_train_scaled * coeff(:, 1:3);
X_test_pca = X_test_scaled * coeff(:, 1:3);

% Train a regression model (using TreeBagger as an equivalent to RandomForest)
mdl = TreeBagger(100, X_train_scaled, y_train_matlab, 'Method', 'regression', 'OOBPrediction', 'on');

% Make predictions
y_pred_matlab = predict(mdl, X_test_scaled);
y_pred_matlab = str2double(y_pred_matlab);  % Convert from cell array of strings

% Calculate model performance
mse_matlab = mean((y_test_matlab - y_pred_matlab).^2);
r2_matlab = 1 - sum((y_test_matlab - y_pred_matlab).^2) / sum((y_test_matlab - mean(y_test_matlab)).^2);

% Calculate feature importance
feature_importance_matlab = mdl.OOBPermutedPredictorDeltaError;
feature_importance_matlab = feature_importance_matlab / sum(feature_importance_matlab);  % Normalize

matlab_time = toc;

fprintf('MATLAB analysis completed in %.2f seconds.\n', matlab_time);

fprintf('Results from MATLAB:\n');
fprintf('  Mean Squared Error: %.4f\n', mse_matlab);
fprintf('  RScore: %.4f\n', r2_matlab);
fprintf('  Feature Importance:\n');
for i = 1:length(feature_importance_matlab)
    fprintf('    X%d: %.4f\n', i, feature_importance_matlab(i));
end
fprintf('  PCA Explained Variance Ratio:\n');
for i = 1:3
    fprintf('    PC%d: %.4f\n', i, explained(i)/100);
end

% Performance comparison
speedup = matlab_time / engine_time;
fprintf('\nPerformance Comparison:\n');
fprintf('  MATLAB Execution Time: %.2f seconds\n', matlab_time);
fprintf('  Python Execution Time: %.2f seconds\n', engine_time);
fprintf('  Speed Ratio (MATLAB/Python): %.2f\n', speedup);

% Create a comprehensive visualization comparing results
figure('Position', [100, 100, 1200, 800]);

% Subplot 1: Predictions comparison
subplot(2, 3, 1);
plot(y_test, y_pred, 'bo', 'MarkerSize', 4);
hold on;
plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], 'r-', 'LineWidth', 2);
title('Python: Actual vs Predicted');
xlabel('Actual Values');
ylabel('Predicted Values');
grid on;

% Subplot 2: Predictions comparison for MATLAB
subplot(2, 3, 2);
plot(y_test_matlab, y_pred_matlab, 'bo', 'MarkerSize', 4);
hold on;
plot([min(y_test_matlab), max(y_test_matlab)], [min(y_test_matlab), max(y_test_matlab)], 'r-', 'LineWidth', 2);
title('MATLAB: Actual vs Predicted');
xlabel('Actual Values');
ylabel('Predicted Values');
grid on;

% Subplot 3: Feature importance comparison
subplot(2, 3, 3);
bardata = [feature_importance; feature_importance_matlab']';
bar(bardata);
title('Feature Importance Comparison');
xlabel('Feature');
ylabel('Importance');
set(gca, 'XTickLabel', {'X1', 'X2', 'X3', 'X4', 'X5'});
legend('Python', 'MATLAB');
grid on;

% Subplot 4: PCA explained variance
subplot(2, 3, 4);
bar([explained_variance_ratio; explained(1:3)'/100]');
title('PCA Explained Variance');
xlabel('Principal Component');
ylabel('Explained Variance Ratio');
set(gca, 'XTickLabel', {'PC1', 'PC2', 'PC3'});
legend('Python', 'MATLAB');
grid on;

% Subplot 5: Performance comparison
subplot(2, 3, 5);
metrics = [mse, mse_matlab; r2, r2_matlab];
bar(metrics);
title('Model Performance Metrics');
set(gca, 'XTickLabel', {'MSE', 'R'});
legend('Python', 'MATLAB');
grid on;

% Subplot 6: Execution time comparison
subplot(2, 3, 6);
bar([engine_time, matlab_time]);
title('Execution Time Comparison');
ylabel('Time (seconds)');
set(gca, 'XTickLabel', {'Python', 'MATLAB'});
grid on;

sgtitle('MATLAB-Python Integration for Data Science: Results Comparison', 'FontSize', 14, 'FontWeight', 'bold');

% Save the figure
saveas(gcf, 'matlab_python_comparison.png');
fprintf('Comparison figure saved as matlab_python_comparison.png\n');

% Create a report summarizing the workflow and results
fprintf('\nGenerating summary report...\n');

% Create a table summarizing the comparison
summary = table(...
    {'Python via System Command'; 'Python via Engine API'; 'MATLAB Implementation'}, ...
    [system_time; engine_time; matlab_time], ...
    [mse; mse; mse_matlab], ...
    [r2; r2; r2_matlab], ...
    'VariableNames', {'Implementation', 'ExecutionTime_sec', 'MSE', 'R2'});

% Display the summary
disp('Workflow Summary:');
disp(summary);

% Save the summary to a CSV file
writetable(summary, 'workflow_summary.csv');
fprintf('Summary report saved as workflow_summary.csv\n');

fprintf('\nWorkflow completed successfully!\n');

catch ME
fprintf('Error in MATLAB-Python integration:\n%s\n', ME.message);
fprintf('Stack trace:\n');
disp(getReport(ME, 'extended'));
end
