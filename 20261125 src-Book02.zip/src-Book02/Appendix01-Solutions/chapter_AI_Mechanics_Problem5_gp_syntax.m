%% chapter_AI_Mechanics_Problem5_gp_syntax.m
% Gaussian Process surrogate model syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem5_gp_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Train GP regression model
% X: (numSimulations   numFeatures) - e.g., [Gc, a0, theta]
% Y: (numSimulations   1) - target (e.g., final crack length)

gpModel = fitrgp(X_train, Y_train, ...
    'KernelFunction', 'matern52', ...     % Mat rn 5/2 kernel
    'Standardize', true, ...               % Standardise inputs
    'OptimizeHyperparameters', 'auto', ...
    'HyperparameterOptimizationOptions', ...
        struct('ShowPlots', false, 'Verbose', 0));

% Predict on test data with uncertainty
[Y_pred, Y_std, Y_interval] = predict(gpModel, X_test);

% 95% confidence intervals
CI_lower = Y_interval(:, 1);
CI_upper = Y_interval(:, 2);
