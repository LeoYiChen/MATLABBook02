%% prob10_dashboard_syntax.m
% Multi-panel dashboard syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob10_dashboard_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Traditional subplot
subplot(m, n, p);

% Modern tiledlayout (recommended)
tiledlayout(m, n, 'TileSpacing', 'compact');
nexttile;

% Spanning multiple tiles
nexttile([rows, cols]);
