%% prob8_code.m
% Statistical distribution and probability plot analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob8_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Statistical Visualisation: Weibull Failure Time Analysis
% File: MATLABBook02_Chapter07_Problem08.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Comprehensive statistical visualisation including distribution
%              fitting, probability plots, and reliability analysis
% =========================================================================

function MATLABBook02_Chapter07_Problem08()
    % Main function for Problem 8: Statistical Distribution Analysis
    
    clc; clear; close all;
    
    % Generate failure time data
    [failureData, trueParams] = generateFailureTimeData();
    
    % Fit Weibull distribution
    [fittedDist, estimatedParams] = fitWeibullDistribution(failureData);
    
    % Create histogram with fitted distribution
    createHistogramWithFit(failureData, fittedDist);
    
    % Generate Weibull probability plot
    createWeibullProbabilityPlot(failureData, fittedDist);
    
    % Create Q-Q plot
    createQQPlot(failureData, fittedDist);
    
    % Plot empirical vs theoretical CDF
    createECDFComparison(failureData, fittedDist);
    
    % Perform goodness-of-fit tests
    performGoodnessOfFitTests(failureData, fittedDist);
    
    % Create reliability analysis visualisation
    createReliabilityAnalysis(fittedDist, failureData);
    
    % Compare parameter estimates
    compareParameters(trueParams, estimatedParams);
    
    % Create comprehensive summary panel
    createComprehensiveSummaryPanel(failureData, fittedDist, trueParams);
end

function [data, params] = generateFailureTimeData()
    % GENERATEFAILURETIMEDATA - Creates synthetic Weibull failure times
    
    rng(147);
    
    % True Weibull parameters
    params.shape = 2.5;     % Shape parameter (beta)
    params.scale = 1000;    % Scale parameter (eta) in hours
    
    % Generate random samples
    numSamples = 200;
    data = wblrnd(params.scale, params.shape, numSamples, 1);
end

function [pd, params] = fitWeibullDistribution(data)
    % FITWEIBULLDISTRIBUTION - Estimates Weibull parameters
    
    % Fit Weibull distribution using maximum likelihood estimation
    pd = fitdist(data, 'Weibull');
    
    % Extract parameters
    params.scale = pd.A;  % Scale parameter (eta)
    params.shape = pd.B;  % Shape parameter (beta)
    
    fprintf('\n========================================\n');
    fprintf('   WEIBULL DISTRIBUTION FITTING\n');
    fprintf('========================================\n');
    fprintf('Estimated Parameters:\n');
    fprintf('  Shape ( ):  %.4f\n', params.shape);
    fprintf('  Scale ( ):  %.2f hours\n', params.scale);
    fprintf('========================================\n');
end

function createHistogramWithFit(data, pd)
    % CREATEHISTOGRAMWITHFIT - Histogram with overlaid PDF
    
    figure('Name', 'Histogram with Fitted Distribution', ...
           'Position', [50, 50, 900, 600]);
    
    % Create histogram
    histogram(data, 20, 'Normalization', 'pdf', 'FaceColor', [0.7, 0.7, 0.9], ...
             'EdgeColor', 'k', 'FaceAlpha', 0.7, 'DisplayName', 'Observed Data');
    hold on;
    
    % Overlay fitted PDF
    x_range = linspace(min(data)*0.5, max(data)*1.2, 500);
    y_pdf = pdf(pd, x_range);
    plot(x_range, y_pdf, 'r-', 'LineWidth', 3, ...
        'DisplayName', sprintf('Fitted Weibull ( =%.2f,  =%.0f)', pd.B, pd.A));
    
    % Add mean and median lines
    mean_val = mean(pd);
    median_val = median(pd);
    xline(mean_val, 'b-', 'LineWidth', 2, 'DisplayName', ...
         sprintf('Mean = %.0f hrs', mean_val));
    xline(median_val, 'g-', 'LineWidth', 2, 'DisplayName', ...
         sprintf('Median = %.0f hrs', median_val));
    
    % Formatting
    xlabel('Failure Time (hours)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Probability Density', 'Interpreter', 'latex', 'FontSize', 12);
    title('Histogram with Fitted Weibull Distribution', ...
          'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    
    legend('Location', 'northeast', 'Interpreter', 'latex', 'FontSize', 10);
    grid on;
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    hold off;
end

function createWeibullProbabilityPlot(data, pd)
    % CREATEWEIBULLPROBABILITYPLOT - Linearised Weibull probability plot
    
    figure('Name', 'Weibull Probability Plot', 'Position', [100, 100, 800, 700]);
    
    % Sort data
    sorted_data = sort(data);
    n = length(sorted_data);
    
    % Calculate plotting positions (median rank approximation)
    plotting_pos = ((1:n)' - 0.3) / (n + 0.4);
    
    % Weibull transformation: ln(ln(1/(1-F)))
    weibull_y = log(log(1 ./ (1 - plotting_pos)));
    weibull_x = log(sorted_data);
    
    % Plot data points
    plot(weibull_x, weibull_y, 'bo', 'MarkerSize', 6, 'MarkerFaceColor', 'b', ...
        'DisplayName', 'Observed Data');
    hold on;
    
    % Theoretical line
    x_range_log = linspace(min(weibull_x), max(weibull_x), 100);
    y_theoretical = pd.B * (x_range_log - log(pd.A));
    plot(x_range_log, y_theoretical, 'r-', 'LineWidth', 2.5, ...
        'DisplayName', 'Fitted Weibull Line');
    
    % Formatting
    xlabel('$\ln$(Failure Time)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\ln\ln\left(\frac{1}{1-F}\right)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Weibull Probability Plot (Linearised)', 'Interpreter', 'latex', ...
          'FontSize', 13, 'FontWeight', 'bold');
    
    legend('Location', 'southeast', 'Interpreter', 'latex', 'FontSize', 10);
    grid on;
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    
    % Add R-squared value
    % Calculate correlation coefficient
    R = corrcoef(weibull_x, weibull_y);
    R_squared = R(1,2)^2;
    text(0.05, 0.95, sprintf('$R^2 = %.4f$', R_squared), ...
        'Units', 'normalized', 'Interpreter', 'latex', 'FontSize', 11, ...
        'BackgroundColor', 'w', 'EdgeColor', 'k');
    
    hold off;
end

function createQQPlot(data, pd)
    % CREATEQQPLOT - Quantile-quantile diagnostic plot
    
    figure('Name', 'Q-Q Plot', 'Position', [150, 150, 700, 700]);
    
    % Compute empirical and theoretical quantiles
    sorted_data = sort(data);
    n = length(sorted_data);
    empirical_quantiles = sorted_data;
    
    % Theoretical quantiles from fitted distribution
    probabilities = ((1:n)' - 0.5) / n;
    theoretical_quantiles = icdf(pd, probabilities);
    
    % Plot Q-Q points
    plot(theoretical_quantiles, empirical_quantiles, 'bo', ...
        'MarkerSize', 7, 'MarkerFaceColor', 'b', 'DisplayName', 'Data');
    hold on;
    
    % Perfect fit reference line
    min_val = min([theoretical_quantiles; empirical_quantiles]);
    max_val = max([theoretical_quantiles; empirical_quantiles]);
    plot([min_val, max_val], [min_val, max_val], 'r-', 'LineWidth', 2.5, ...
        'DisplayName', 'Perfect Fit');
    
    % Confidence bands (approximate)
    alpha = 0.05;
    se = std(data) / sqrt(n);
    upper_band = theoretical_quantiles + 1.96 * se;
    lower_band = theoretical_quantiles - 1.96 * se;
    plot(theoretical_quantiles, upper_band, 'g:', 'LineWidth', 1.5, ...
        'DisplayName', '95\% Confidence');
    plot(theoretical_quantiles, lower_band, 'g:', 'LineWidth', 1.5, ...
        'HandleVisibility', 'off');
    
    % Formatting
    xlabel('Theoretical Quantiles (Weibull)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Empirical Quantiles (Data)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Q-Q Plot: Data vs. Fitted Distribution', 'Interpreter', 'latex', ...
          'FontSize', 13, 'FontWeight', 'bold');
    
    legend('Location', 'southeast', 'Interpreter', 'latex', 'FontSize', 10);
    grid on;
    axis equal;
    xlim([min_val, max_val]);
    ylim([min_val, max_val]);
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    hold off;
end

function createECDFComparison(data, pd)
    % CREATEECDFCOMPARISON - Empirical vs theoretical CDF
    
    figure('Name', 'ECDF Comparison', 'Position', [200, 200, 900, 600]);
    
    % Plot empirical CDF
    [f, x] = ecdf(data);
    stairs(x, f, 'b-', 'LineWidth', 2.5, 'DisplayName', 'Empirical CDF');
    hold on;
    
    % Plot theoretical CDF
    x_range = linspace(min(data)*0.5, max(data)*1.2, 500);
    F_theoretical = cdf(pd, x_range);
    plot(x_range, F_theoretical, 'r-', 'LineWidth', 2.5, ...
        'DisplayName', 'Fitted Weibull CDF');
    
    % Formatting
    xlabel('Failure Time (hours)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Cumulative Probability, $F(t)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Empirical vs. Theoretical Cumulative Distribution Function', ...
          'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    
    legend('Location', 'southeast', 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'LineWidth', 1.2, 'FontSize', 11);
    xlim([0, max(data)*1.1]);
    ylim([0, 1]);
    hold off;
end

function performGoodnessOfFitTests(data, pd)
    % PERFORMGOODNESSOFFITTESTS - Statistical hypothesis testing
    
    fprintf('\n========================================\n');
    fprintf('   GOODNESS-OF-FIT TESTS\n');
    fprintf('========================================\n');
    
    % Kolmogorov-Smirnov test
    [h_ks, p_ks, ks_stat] = kstest(data, 'CDF', pd, 'Alpha', 0.05);
    
    fprintf('Kolmogorov-Smirnov Test:\n');
    fprintf('  Test Statistic (D): %.4f\n', ks_stat);
    fprintf('  p-value: %.4f\n', p_ks);
    if h_ks == 0
        fprintf('  Result: ACCEPT null hypothesis (Weibull is good fit)\n');
    else
        fprintf('  Result: REJECT null hypothesis (poor fit)\n');
    end
    
    % Anderson-Darling test (using built-in if available)
    % Note: Statistics Toolbox required
    try
        [h_ad, p_ad, ad_stat] = adtest(data, 'Distribution', pd);
        fprintf('\nAnderson-Darling Test:\n');
        fprintf('  Test Statistic (A): %.4f\n', ad_stat);
        fprintf('  p-value: %.4f\n', p_ad);
        if h_ad == 0
            fprintf('  Result: ACCEPT null hypothesis (Weibull is good fit)\n');
        else
            fprintf('  Result: REJECT null hypothesis (poor fit)\n');
        end
    catch
        fprintf('\nAnderson-Darling test requires Statistics Toolbox\n');
    end
    
    fprintf('========================================\n');
end

function createReliabilityAnalysis(pd, data)
    % CREATERELIABILITYANALYSIS - Plots reliability functions
    
    figure('Name', 'Reliability Analysis', 'Position', [50, 50, 1400, 800]);
    
    t = linspace(0, max(data)*1.5, 500);
    
    % Subplot 1: Reliability function R(t) = 1 - F(t)
    subplot(2, 2, 1);
    R = 1 - cdf(pd, t);
    plot(t, R, 'b-', 'LineWidth', 2.5);
    hold on;
    % Mark median life (R = 0.5)
    median_life = median(pd);
    plot(median_life, 0.5, 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
    text(median_life*1.1, 0.5, sprintf('Median: %.0f hrs', median_life), ...
        'Interpreter', 'latex', 'FontSize', 10);
    xlabel('Time (hours)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Reliability, $R(t)$', 'Interpreter', 'latex', 'FontSize', 11);
    title('(a) Reliability Function', 'Interpreter', 'latex', 'FontSize', 12);
    grid on; set(gca, 'FontSize', 10);
    ylim([0, 1]);
    hold off;
    
    % Subplot 2: Hazard function h(t) = f(t) / R(t)
    subplot(2, 2, 2);
    f = pdf(pd, t);
    h = f ./ R;
    plot(t, h, 'r-', 'LineWidth', 2.5);
    xlabel('Time (hours)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Hazard Rate, $h(t)$', 'Interpreter', 'latex', 'FontSize', 11);
    title('(b) Hazard Function (Failure Rate)', 'Interpreter', 'latex', 'FontSize', 12);
    grid on; set(gca, 'FontSize', 10);
    
    % Subplot 3: Cumulative hazard function H(t)
    subplot(2, 2, 3);
    H = -log(R);
    plot(t, H, 'g-', 'LineWidth', 2.5);
    xlabel('Time (hours)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Cumulative Hazard, $H(t)$', 'Interpreter', 'latex', 'FontSize', 11);
    title('(c) Cumulative Hazard Function', 'Interpreter', 'latex', 'FontSize', 12);
    grid on; set(gca, 'FontSize', 10);
    
    % Subplot 4: PDF with characteristic life marked
    subplot(2, 2, 4);
    plot(t, f, 'm-', 'LineWidth', 2.5);
    hold on;
    % Mark characteristic life (scale parameter)
    char_life = pd.A;
    f_char = pdf(pd, char_life);
    plot(char_life, f_char, 'ko', 'MarkerSize', 12, 'MarkerFaceColor', 'k');
    text(char_life*1.1, f_char, sprintf('  = %.0f hrs', char_life), ...
        'Interpreter', 'latex', 'FontSize', 10);
    xlabel('Time (hours)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('PDF, $f(t)$', 'Interpreter', 'latex', 'FontSize', 11);
    title('(d) Probability Density Function', 'Interpreter', 'latex', 'FontSize', 12);
    grid on; set(gca, 'FontSize', 10);
    hold off;
    
    sgtitle('Comprehensive Reliability Analysis', 'Interpreter', 'latex', ...
           'FontSize', 13, 'FontWeight', 'bold');
end

function compareParameters(trueParams, estimatedParams)
    % COMPAREPARAMETERS - Validates parameter estimation
    
    fprintf('\n========================================\n');
    fprintf('   PARAMETER ESTIMATION ACCURACY\n');
    fprintf('========================================\n');
    
    fprintf('Shape Parameter ( ):\n');
    fprintf('  True Value:      %.4f\n', trueParams.shape);
    fprintf('  Estimated Value: %.4f\n', estimatedParams.shape);
    fprintf('  Relative Error:  %.2f%%\n', ...
           100*abs(estimatedParams.shape - trueParams.shape)/trueParams.shape);
    
    fprintf('\nScale Parameter ( ):\n');
    fprintf('  True Value:      %.2f hours\n', trueParams.scale);
    fprintf('  Estimated Value: %.2f hours\n', estimatedParams.scale);
    fprintf('  Relative Error:  %.2f%%\n', ...
           100*abs(estimatedParams.scale - trueParams.scale)/trueParams.scale);
    
    fprintf('========================================\n');
end

function createComprehensiveSummaryPanel(data, pd, trueParams)
    % CREATECOMPREHENSIVESUMMARYPANEL - All-in-one visualisation
    
    figure('Name', 'Comprehensive Statistical Summary', ...
           'Position', [50, 50, 1400, 1000]);
    
    % Panel 1: Histogram with fit
    subplot(3, 2, 1);
    histogram(data, 20, 'Normalization', 'pdf', 'FaceColor', [0.7, 0.7, 0.9], ...
             'EdgeColor', 'k', 'FaceAlpha', 0.7);
    hold on;
    x_range = linspace(0, max(data)*1.2, 200);
    plot(x_range, pdf(pd, x_range), 'r-', 'LineWidth', 2);
    title('(a) Histogram \& PDF', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('Failure Time (hrs)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Density', 'Interpreter', 'latex', 'FontSize', 10);
    grid on; set(gca, 'FontSize', 9);
    hold off;
    
    % Panel 2: ECDF
    subplot(3, 2, 2);
    [f, x] = ecdf(data);
    stairs(x, f, 'b-', 'LineWidth', 2);
    hold on;
    plot(x_range, cdf(pd, x_range), 'r-', 'LineWidth', 2);
    title('(b) Empirical CDF', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('Failure Time (hrs)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$F(t)$', 'Interpreter', 'latex', 'FontSize', 10);
    legend('Empirical', 'Fitted', 'Location', 'southeast', 'Interpreter', 'latex');
    grid on; set(gca, 'FontSize', 9);
    hold off;
    
    % Panel 3: Weibull probability plot
    subplot(3, 2, 3);
    sorted_data = sort(data);
    n = length(sorted_data);
    plotting_pos = ((1:n)' - 0.3) / (n + 0.4);
    weibull_y = log(log(1 ./ (1 - plotting_pos)));
    weibull_x = log(sorted_data);
    plot(weibull_x, weibull_y, 'bo', 'MarkerSize', 5);
    hold on;
    x_range_log = linspace(min(weibull_x), max(weibull_x), 100);
    y_theoretical = pd.B * (x_range_log - log(pd.A));
    plot(x_range_log, y_theoretical, 'r-', 'LineWidth', 2);
    title('(c) Weibull Probability Plot', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('$\ln(t)$', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$\ln\ln(1/(1-F))$', 'Interpreter', 'latex', 'FontSize', 10);
    grid on; set(gca, 'FontSize', 9);
    hold off;
    
    % Panel 4: Q-Q plot
    subplot(3, 2, 4);
    probabilities = ((1:n)' - 0.5) / n;
    theoretical_quantiles = icdf(pd, probabilities);
    plot(theoretical_quantiles, sorted_data, 'bo', 'MarkerSize', 5);
    hold on;
    min_val = min([theoretical_quantiles; sorted_data]);
    max_val = max([theoretical_quantiles; sorted_data]);
    plot([min_val, max_val], [min_val, max_val], 'r-', 'LineWidth', 2);
    title('(d) Q-Q Plot', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('Theoretical Quantiles', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Sample Quantiles', 'Interpreter', 'latex', 'FontSize', 10);
    grid on; axis equal; set(gca, 'FontSize', 9);
    hold off;
    
    % Panel 5: Reliability function
    subplot(3, 2, 5);
    t = linspace(0, max(data)*1.5, 300);
    R = 1 - cdf(pd, t);
    plot(t, R, 'b-', 'LineWidth', 2);
    title('(e) Reliability Function', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('Time (hrs)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$R(t)$', 'Interpreter', 'latex', 'FontSize', 10);
    grid on; set(gca, 'FontSize', 9);
    
    % Panel 6: Hazard function
    subplot(3, 2, 6);
    f = pdf(pd, t);
    h = f ./ R;
    plot(t, h, 'r-', 'LineWidth', 2);
    title('(f) Hazard Function', 'Interpreter', 'latex', 'FontSize', 11);
    xlabel('Time (hrs)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$h(t)$', 'Interpreter', 'latex', 'FontSize', 10);
    grid on; set(gca, 'FontSize', 9);
    
    sgtitle(sprintf('Weibull Analysis Summary:  =%.2f,  =%.0f hrs', pd.B, pd.A), ...
           'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
end
