%% chapter_AI_Mechanics_Problem7_ABD_syntax.m
% ABD matrix calculation using CLT syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem7_ABD_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Calculate ABD matrix for laminate
% layup: vector of ply angles in degrees (e.g., [0 45 -45 90 90 -45 45 0])
% t_ply: thickness of each ply (m)
% Q: 3 3 reduced stiffness matrix for unidirectional ply

function [A, B, D] = calculateABD(layup, t_ply, Q)
    N_plies = length(layup);
    A = zeros(3, 3);
    B = zeros(3, 3);
    D = zeros(3, 3);
    
    % Thickness coordinates
    h = N_plies * t_ply;
    z = linspace(-h/2, h/2, N_plies + 1);
    
    for k = 1:N_plies
        theta = layup(k) * pi / 180;  % Convert to radians
        
        % Transformation matrix
        m = cos(theta);
        n = sin(theta);
        T = [m^2, n^2, 2*m*n;
             n^2, m^2, -2*m*n;
             -m*n, m*n, m^2 - n^2];
        
        % Transformed stiffness
        Qbar = T * Q * T';
        
        % Integrate contributions
        dz = z(k+1) - z(k);
        z_mid = (z(k+1) + z(k)) / 2;
        
        A = A + Qbar * dz;
        B = B + Qbar * z_mid * dz;
        D = D + Qbar * (z(k+1)^3 - z(k)^3) / 3;
    end
end
