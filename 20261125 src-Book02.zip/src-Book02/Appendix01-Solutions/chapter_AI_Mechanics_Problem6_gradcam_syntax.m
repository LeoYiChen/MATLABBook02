%% chapter_AI_Mechanics_Problem6_gradcam_syntax.m
% Grad-CAM saliency map syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem6_gradcam_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Generate Grad-CAM saliency map
% net: trained network
% img: input image
% targetLayer: name of convolutional layer (e.g., 'relu_conv3')

% Forward pass to get activations
act = activations(net, img, targetLayer);

% Compute gradients
scores = predict(net, img);
gradients = dlgradient(scores, act);

% Pool gradients (global average pooling)
weights = mean(mean(gradients, 1), 2);

% Weighted combination of activation maps
cam = sum(act .* reshape(weights, [1, 1, size(act, 3)]), 3);

% ReLU + normalise
cam = max(cam, 0);
cam = cam / max(cam(:));

% Resize to image dimensions
camResized = imresize(cam, [size(img, 1), size(img, 2)]);

% Overlay on original image
figure;
imshow(img);
hold on;
imagesc(camResized, 'AlphaData', 0.5);
colormap jet;
colorbar;
title('Grad-CAM Heatmap', 'Interpreter', 'latex');
