%% listing_problem5_hinf.m
% Problem 5: H-infinity robust control for aircraft pitch with mixed-sensitivity design, uncertainty modeling, and comparison against LQG showing improved robustness margins and worst-case performance.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem5_hinf
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 5 - H-infinity Robust Control
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: H-infinity control for aircraft pitch with parametric
%              uncertainty. Mixed-sensitivity formulation, Riccati solution,
%              robustness analysis vs LQG.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 5: H-infinity Robust Control for Aircraft Pitch\n');
fprintf('==================================================================\n\n');

%% Nominal Plant Model
fprintf('=== Nominal Aircraft Short-Period Dynamics ===\n');

% State-space matrices (linearized at cruise: M=0.6, h=20000 ft)
A = [-0.313  56.7   0;
     -0.0139 -0.426  0;
      0       1      0];

B = [0.232; 0.0203; 0];

C = [0 0 1];  % Output: pitch angle theta

D = 0;

% Create state-space model
G_nom = ss(A, B, C, D);
G_nom.StateName = {'alpha', 'q', 'theta'};
G_nom.StateUnit = {'rad', 'rad/s', 'rad'};
G_nom.InputName = {'delta_e'};
G_nom.InputUnit = {'rad'};
G_nom.OutputName = {'theta'};
G_nom.OutputUnit = {'rad'};

fprintf('State: x = [alpha; q; theta]\n');
fprintf('Input: u = delta_e (elevator deflection)\n');
fprintf('Output: y = theta (pitch angle)\n\n');

fprintf('A matrix:\n');
disp(A);
fprintf('B vector:\n');
disp(B);
fprintf('C vector:\n');
disp(C);

% Check stability
eigs_plant = eig(A);
fprintf('Open-loop eigenvalues:\n');
for i = 1:length(eigs_plant)
    if imag(eigs_plant(i)) == 0
        fprintf('  lambda_%d = %.4f\n', i, real(eigs_plant(i)));
    else
        fprintf('  lambda_%d = %.4f %+.4fi (|lambda| = %.4f, zeta = %.3f)\n', ...
            i, real(eigs_plant(i)), imag(eigs_plant(i)), ...
            abs(eigs_plant(i)), -real(eigs_plant(i))/abs(eigs_plant(i)));
    end
end

if all(real(eigs_plant) < 0)
    fprintf('Open-loop system is STABLE\n\n');
else
    fprintf('Open-loop system is UNSTABLE\n\n');
end

% Bode plot of nominal plant
figure('Position', [50, 50, 800, 600]);
bode(G_nom, {0.01, 100});
grid on;
title('Bode Plot: Nominal Plant $G(s)$', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem05_NominalPlant_Bode.fig');
saveas(gcf, 'Problem05_NominalPlant_Bode.eps', 'epsc');

%% Weighting Function Design
fprintf('=== Weighting Function Design ===\n');

% Sensitivity weight Ws (tracking, disturbance rejection)
% Low-freq gain = 100 (1% ss error), bandwidth = 2 rad/s
s = tf('s');
Ws = (s + 3) / (s + 0.02);
Ws.InputName = 'e';
Ws.OutputName = 'z1';

fprintf('Sensitivity weight Ws:\n');
fprintf('  DC gain: %.1f (%.1f dB)\n', dcgain(Ws), 20*log10(dcgain(Ws)));
fprintf('  Bandwidth: ~2 rad/s\n\n');

% Complementary sensitivity weight Wt (noise, robustness)
% High-freq gain = 10 (robustness margin), roll-off above 2 rad/s
Wt = (s + 1.33) / (0.1*s + 2);
Wt.InputName = 'u';
Wt.OutputName = 'z2';

fprintf('Complementary sensitivity weight Wt:\n');
fprintf('  Low-freq gain: %.3f (%.1f dB)\n', dcgain(Wt), 20*log10(dcgain(Wt)));
fprintf('  High-freq gain: %.1f (%.1f dB)\n', 10, 20*log10(10));
fprintf('  Crossover: ~2 rad/s\n\n');

% Control sensitivity weight Wu (actuator effort)
% Limit control above 5 rad/s
Wu = (s + 2.5) / (0.05*s + 5);
Wu.InputName = 'u';
Wu.OutputName = 'z3';

fprintf('Control weight Wu:\n');
fprintf('  DC gain: %.3f (%.1f dB)\n', dcgain(Wu), 20*log10(dcgain(Wu)));
fprintf('  Emphasizes freq above 5 rad/s\n\n');

% Plot weights
figure('Position', [100, 100, 1200, 400]);

subplot(1,3,1);
bodemag(Ws, {0.001, 100});
grid on;
title('$W_S(s)$ - Sensitivity', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Magnitude (dB)', 'Interpreter', 'latex');

subplot(1,3,2);
bodemag(Wt, {0.001, 100});
grid on;
title('$W_T(s)$ - Complementary', 'Interpreter', 'latex', 'FontSize', 12);

subplot(1,3,3);
bodemag(Wu, {0.001, 100});
grid on;
title('$W_U(s)$ - Control', 'Interpreter', 'latex', 'FontSize', 12);

saveas(gcf, 'Problem05_Weights.fig');
saveas(gcf, 'Problem05_Weights.eps', 'epsc');

%% Build Generalized Plant
fprintf('=== Constructing Generalized Plant P(s) ===\n');

% Inputs: w = [r; d; n] (reference, disturbance, noise)
% Outputs: z = [z1; z2; z3] (weighted errors)
%          y = theta_meas (measurement)

% Build interconnection
sumblk1 = sumblk('e = r - theta');
sumblk2 = sumblk('theta_meas = theta + n');

% Connect: r -> e -> Ws -> z1
%         e -> G -> theta
%         d -> G (additive disturbance at plant input)
%         theta + n -> y

% Alternative: Use augmented plant formulation
% For mixed sensitivity:
% P11: w to z, P12: u to z, P21: w to y, P22: u to y

% Construct using append and connect
systemnames = 'G_nom Ws Wt Wu';
inputvar = '[r; d; n]';
outputvar = '[Ws; Wt; Wu; r - G_nom - n]';
input_to_G_nom = '[d + u]';
input_to_Ws = '[r - G_nom]';
input_to_Wt = '[u]';
input_to_Wu = '[u]';
cleanupsysic = 'yes';

% Using sysic for interconnection
P = sysic;

fprintf('Generalized plant P:\n');
fprintf('  States: %d\n', size(P.A, 1));
fprintf('  Inputs: w (%d), u (%d)\n', 3, 1);
fprintf('  Outputs: z (%d), y (%d)\n\n', 3, 1);

%% H-infinity Synthesis
fprintf('=== H-infinity Controller Synthesis ===\n');

nmeas = 1;  % Number of measurements
ncont = 1;  % Number of control inputs

% Synthesize H-infinity controller
[K_hinf, CL_hinf, gamma_opt] = hinfsyn(P, nmeas, ncont);

fprintf('H-infinity synthesis completed!\n');
fprintf('  Optimal gamma: %.4f (%.2f dB)\n', gamma_opt, 20*log10(gamma_opt));
fprintf('  Controller order: %d\n', order(K_hinf));
fprintf('  Controller poles:\n');

poles_K = pole(K_hinf);
for i = 1:length(poles_K)
    if imag(poles_K(i)) == 0
        fprintf('    p_%d = %.4f\n', i, real(poles_K(i)));
    else
        fprintf('    p_%d = %.4f %+.4fi\n', i, real(poles_K(i)), imag(poles_K(i)));
    end
end
fprintf('\n');

% Verify ||T_zw||_inf < gamma
norm_CL = norm(CL_hinf, inf);
fprintf('Closed-loop H-inf norm: %.4f\n', norm_CL);
fprintf('Achieved gamma/optimal: %.4f (should be ~1)\n\n', norm_CL / gamma_opt);

%% Controller Reduction
fprintf('=== Controller Order Reduction ===\n');

% Balanced truncation to reduce order
[K_red, info_red] = balred(K_hinf, 3);

fprintf('Reduced controller order: %d -> %d\n', order(K_hinf), order(K_red));
fprintf('Hankel singular values:\n');
disp(info_red.HSV);

% Re-close loop with reduced controller
CL_red = lft(P, K_red);
norm_CL_red = norm(CL_red, inf);

fprintf('Reduced CL H-inf norm: %.4f\n', norm_CL_red);
fprintf('Performance degradation: %.2f%%\n\n', ...
    (norm_CL_red - norm_CL) / norm_CL * 100);

% Use full-order controller for analysis (typically marginal degradation)
K = K_hinf;
CL = CL_hinf;

%% Closed-Loop Analysis
fprintf('=== Closed-Loop Transfer Functions ===\n');

% Form closed-loop system for analysis
% Sensitivity S = 1 / (1 + GK)
% Complementary T = GK / (1 + GK)
% Control sensitivity KS = K / (1 + GK)

L_hinf = G_nom * K;  % Loop transfer function
S_hinf = feedback(1, L_hinf);
T_hinf = feedback(L_hinf, 1);
KS_hinf = K * S_hinf;

fprintf('Sensitivity function S:\n');
fprintf('  DC gain: %.4f (%.2f dB)\n', dcgain(S_hinf), 20*log10(abs(dcgain(S_hinf))));
fprintf('  Peak gain: %.4f (%.2f dB) at %.2f rad/s\n', ...
    getPeakGain(S_hinf), 20*log10(getPeakGain(S_hinf)), bandwidth(S_hinf));

fprintf('Complementary sensitivity T:\n');
fprintf('  DC gain: %.4f (%.2f dB)\n', dcgain(T_hinf), 20*log10(abs(dcgain(T_hinf))));
fprintf('  Bandwidth (-3dB): %.2f rad/s\n\n', bandwidth(T_hinf));

%% LQG Design for Comparison
fprintf('=== LQG Controller Design (for comparison) ===\n');

% LQG weights
Q_lqg = C' * 100 * C;  % Output weight (theta)
R_lqg = 1;             % Control weight

% Process and measurement noise covariances
W_lqg = 0.01 * eye(3);  % Process noise
V_lqg = 0.01;           % Measurement noise

% Design LQG controller
K_lqg = lqg(G_nom, Q_lqg, R_lqg, W_lqg, V_lqg);

fprintf('LQG controller order: %d\n', order(K_lqg));
fprintf('LQG controller poles:\n');

poles_lqg = pole(K_lqg);
for i = 1:length(poles_lqg)
    if imag(poles_lqg(i)) == 0
        fprintf('    p_%d = %.4f\n', i, real(poles_lqg(i)));
    else
        fprintf('    p_%d = %.4f %+.4fi\n', i, real(poles_lqg(i)), imag(poles_lqg(i)));
    end
end
fprintf('\n');

% LQG closed-loop
L_lqg = G_nom * K_lqg;
S_lqg = feedback(1, L_lqg);
T_lqg = feedback(L_lqg, 1);
KS_lqg = K_lqg * S_lqg;

%% Frequency Response Comparison
fprintf('=== Frequency Response Comparison ===\n');

figure('Position', [150, 150, 1400, 900]);

% Sensitivity function
subplot(3,2,1);
bodemag(S_hinf, S_lqg, 1/Ws, {0.001, 100});
grid on;
legend('$S_{H\infty}$', '$S_{LQG}$', '$1/W_S$ (spec)', ...
    'Interpreter', 'latex', 'Location', 'best');
title('Sensitivity Function $S(s)$', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Magnitude (dB)', 'Interpreter', 'latex');

% Complementary sensitivity
subplot(3,2,2);
bodemag(T_hinf, T_lqg, 1/Wt, {0.001, 100});
grid on;
legend('$T_{H\infty}$', '$T_{LQG}$', '$1/W_T$ (spec)', ...
    'Interpreter', 'latex', 'Location', 'best');
title('Complementary Sensitivity $T(s)$', 'Interpreter', 'latex', 'FontSize', 13);

% Control sensitivity
subplot(3,2,3);
bodemag(KS_hinf, KS_lqg, 1/Wu, {0.001, 100});
grid on;
legend('$KS_{H\infty}$', '$KS_{LQG}$', '$1/W_U$ (spec)', ...
    'Interpreter', 'latex', 'Location', 'best');
title('Control Sensitivity $K(s)S(s)$', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Magnitude (dB)', 'Interpreter', 'latex');
xlabel('Frequency (rad/s)', 'Interpreter', 'latex');

% Loop transfer function
subplot(3,2,4);
margin(L_hinf);
grid on;
title('Loop Transfer $L_{H\infty}(s) = GK$', 'Interpreter', 'latex', 'FontSize', 13);

subplot(3,2,5);
margin(L_lqg);
grid on;
title('Loop Transfer $L_{LQG}(s) = GK$', 'Interpreter', 'latex', 'FontSize', 13);
xlabel('Frequency (rad/s)', 'Interpreter', 'latex');

% Nyquist plot
subplot(3,2,6);
nyquist(L_hinf, L_lqg, {0.001, 100});
grid on;
legend('$L_{H\infty}$', '$L_{LQG}$', 'Interpreter', 'latex');
title('Nyquist Plot', 'Interpreter', 'latex', 'FontSize', 13);

saveas(gcf, 'Problem05_FreqResponse.fig');
saveas(gcf, 'Problem05_FreqResponse.eps', 'epsc');

%% Stability Margins
fprintf('=== Stability Margins ===\n');

[Gm_hinf, Pm_hinf, Wcg_hinf, Wcp_hinf] = margin(L_hinf);
[Gm_lqg, Pm_lqg, Wcg_lqg, Wcp_lqg] = margin(L_lqg);

fprintf('H-infinity controller:\n');
fprintf('  Gain margin: %.2f dB at %.2f rad/s\n', 20*log10(Gm_hinf), Wcg_hinf);
fprintf('  Phase margin: %.2f deg at %.2f rad/s\n', Pm_hinf, Wcp_hinf);

fprintf('LQG controller:\n');
fprintf('  Gain margin: %.2f dB at %.2f rad/s\n', 20*log10(Gm_lqg), Wcg_lqg);
fprintf('  Phase margin: %.2f deg at %.2f rad/s\n\n', Pm_lqg, Wcp_lqg);

%% Time-Domain Simulation
fprintf('=== Time-Domain Simulation ===\n');

% Simulation parameters
Tsim = 20;  % seconds
dt = 0.01;
t = 0:dt:Tsim;
Nt = length(t);

% Reference command (step changes in pitch angle)
r_sig = zeros(Nt, 1);
r_sig(t >= 2 & t < 8) = deg2rad(10);   % 10 deg step at t=2s
r_sig(t >= 10 & t < 16) = deg2rad(-5); % -5 deg step at t=10s

% Disturbance (wind gust affecting alpha)
d_sig = zeros(Nt, 1);
d_sig(t >= 5 & t < 5.5) = deg2rad(5);  % 5 deg gust

% Measurement noise
rng(42);  % For reproducibility
n_sig = deg2rad(0.1) * randn(Nt, 1);   % 0.1 deg RMS noise

% Closed-loop systems
% H-infinity: theta = T_hinf * r + S_hinf * d - T_hinf * n
% where we model d as entering at plant output (simplification)

fprintf('Simulating H-infinity closed-loop...\n');
theta_hinf = lsim(T_hinf, r_sig, t) + lsim(S_hinf*G_nom, d_sig, t) ...
             - lsim(T_hinf, n_sig, t);
u_hinf = lsim(K*S_hinf, r_sig, t) - lsim(K*S_hinf*G_nom, d_sig, t) ...
         - lsim(K*T_hinf, n_sig, t);

fprintf('Simulating LQG closed-loop...\n');
theta_lqg = lsim(T_lqg, r_sig, t) + lsim(S_lqg*G_nom, d_sig, t) ...
            - lsim(T_lqg, n_sig, t);
u_lqg = lsim(K_lqg*S_lqg, r_sig, t) - lsim(K_lqg*S_lqg*G_nom, d_sig, t) ...
        - lsim(K_lqg*T_lqg, n_sig, t);

fprintf('Simulation complete.\n\n');

% Performance metrics
e_hinf = rad2deg(r_sig - theta_hinf);
e_lqg = rad2deg(r_sig - theta_lqg);

rms_hinf = sqrt(mean(e_hinf.^2));
rms_lqg = sqrt(mean(e_lqg.^2));

fprintf('RMS tracking error:\n');
fprintf('  H-infinity: %.4f deg\n', rms_hinf);
fprintf('  LQG: %.4f deg\n\n', rms_lqg);

max_u_hinf = max(abs(rad2deg(u_hinf)));
max_u_lqg = max(abs(rad2deg(u_lqg)));

fprintf('Maximum control effort:\n');
fprintf('  H-infinity: %.2f deg\n', max_u_hinf);
fprintf('  LQG: %.2f deg\n\n', max_u_lqg);

%% Time-Domain Plots
figure('Position', [200, 200, 1400, 800]);

subplot(3,1,1);
plot(t, rad2deg(r_sig), 'k-', 'LineWidth', 1.5, 'DisplayName', 'Reference');
hold on;
plot(t, rad2deg(theta_hinf), 'b-', 'LineWidth', 1.2, 'DisplayName', '$H_\infty$');
plot(t, rad2deg(theta_lqg), 'r-', 'LineWidth', 1.2, 'DisplayName', 'LQG');
grid on;
ylabel('Pitch Angle (deg)', 'Interpreter', 'latex', 'FontSize', 11);
title('Pitch Angle Tracking with Disturbance \& Noise', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');

subplot(3,1,2);
plot(t, rad2deg(u_hinf), 'b-', 'LineWidth', 1.2, 'DisplayName', '$H_\infty$');
hold on;
plot(t, rad2deg(u_lqg), 'r-', 'LineWidth', 1.2, 'DisplayName', 'LQG');
yline(25, 'k-', 'Saturation', 'LineWidth', 1);
yline(-25, 'k-', 'LineWidth', 1);
grid on;
ylabel('Elevator (deg)', 'Interpreter', 'latex', 'FontSize', 11);
title('Control Input $\delta_e$', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');
ylim([-30 30]);

subplot(3,1,3);
plot(t, rad2deg(d_sig), 'g-', 'LineWidth', 1.2, 'DisplayName', 'Disturbance');
hold on;
plot(t, rad2deg(n_sig), 'm-', 'LineWidth', 0.8, 'DisplayName', 'Noise');
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('deg', 'Interpreter', 'latex', 'FontSize', 11);
title('External Signals', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');

saveas(gcf, 'Problem05_TimeResponse.fig');
saveas(gcf, 'Problem05_TimeResponse.eps', 'epsc');

%% Robustness Analysis - Parametric Uncertainty
fprintf('=== Robustness Analysis: Parametric Uncertainty ===\n');

% Create uncertain model: M_alpha has +/-20% uncertainty
delta_M = 0.2;
M_alpha_nom = A(1,1);
M_alpha_unc = ureal('M_alpha_unc', M_alpha_nom, 'Percentage', delta_M*100);

A_unc = A;
A_unc(1,1) = M_alpha_unc;
G_unc = ss(A_unc, B, C, D);

fprintf('Uncertain parameter: M_alpha in [%.3f, %.3f]\n', ...
    M_alpha_nom*(1-delta_M), M_alpha_nom*(1+delta_M));

% Closed-loop with uncertainty
T_unc_hinf = feedback(G_unc * K_hinf, 1);
T_unc_lqg = feedback(G_unc * K_lqg, 1);

% Robust stability analysis
[stabmarg_hinf, wcu_hinf] = robstab(T_unc_hinf);
[stabmarg_lqg, wcu_lqg] = robstab(T_unc_lqg);

fprintf('\nRobust stability margins:\n');
fprintf('H-infinity:\n');
fprintf('  Lower bound: %.4f (robust stable if > 1)\n', stabmarg_hinf.LowerBound);
fprintf('  Upper bound: %.4f\n', stabmarg_hinf.UpperBound);

fprintf('LQG:\n');
fprintf('  Lower bound: %.4f\n', stabmarg_lqg.LowerBound);
fprintf('  Upper bound: %.4f\n\n', stabmarg_lqg.UpperBound);

if stabmarg_hinf.LowerBound > 1
    fprintf('H-inf controller: ROBUST STABLE for all uncertainty\n');
else
    fprintf('H-inf controller: May be unstable for some uncertainty\n');
end

if stabmarg_lqg.LowerBound > 1
    fprintf('LQG controller: ROBUST STABLE for all uncertainty\n');
else
    fprintf('LQG controller: May be unstable for some uncertainty\n');
end

fprintf('\n');

%% Worst-Case Performance
fprintf('=== Worst-Case Performance Analysis ===\n');

[perfmarg_hinf, wcu_perf_hinf] = robgain(T_unc_hinf);
[perfmarg_lqg, wcu_perf_lqg] = robgain(T_unc_lqg);

fprintf('Worst-case gain (H-inf norm over uncertainty):\n');
fprintf('H-infinity:\n');
fprintf('  Lower bound: %.4f\n', perfmarg_hinf.LowerBound);
fprintf('  Upper bound: %.4f\n', perfmarg_hinf.UpperBound);

fprintf('LQG:\n');
fprintf('  Lower bound: %.4f\n', perfmarg_lqg.LowerBound);
fprintf('  Upper bound: %.4f\n\n', perfmarg_lqg.UpperBound);

%% Monte Carlo Simulation
fprintf('=== Monte Carlo Simulation ===\n');

Nmc = 50;  % Number of Monte Carlo samples
fprintf('Running %d samples with random M_alpha...\n', Nmc);

% Storage
poles_mc_hinf = zeros(3, Nmc);
poles_mc_lqg = zeros(3, Nmc);
stable_hinf = true(Nmc, 1);
stable_lqg = true(Nmc, 1);

for i = 1:Nmc
    % Random M_alpha within uncertainty range
    M_alpha_sample = M_alpha_nom * (1 + delta_M * (2*rand - 1));
    
    A_sample = A;
    A_sample(1,1) = M_alpha_sample;
    G_sample = ss(A_sample, B, C, D);
    
    % Closed-loop poles
    CL_sample_hinf = feedback(G_sample * K_hinf, 1);
    CL_sample_lqg = feedback(G_sample * K_lqg, 1);
    
    poles_mc_hinf(:,i) = pole(CL_sample_hinf);
    poles_mc_lqg(:,i) = pole(CL_sample_lqg);
    
    stable_hinf(i) = all(real(poles_mc_hinf(:,i)) < 0);
    stable_lqg(i) = all(real(poles_mc_lqg(:,i)) < 0);
    
    if mod(i, 10) == 0
        fprintf('  Sample %d/%d\n', i, Nmc);
    end
end

fprintf('\nMonte Carlo results:\n');
fprintf('H-infinity: %d/%d stable (%.1f%%)\n', sum(stable_hinf), Nmc, ...
    sum(stable_hinf)/Nmc*100);
fprintf('LQG: %d/%d stable (%.1f%%)\n\n', sum(stable_lqg), Nmc, ...
    sum(stable_lqg)/Nmc*100);

% Plot pole distributions
figure('Position', [250, 250, 1200, 500]);

subplot(1,2,1);
plot(real(poles_mc_hinf), imag(poles_mc_hinf), 'bx', 'MarkerSize', 8);
hold on;
plot([-10 0], [0 0], 'k-', 'LineWidth', 1.5);  % Imaginary axis
grid on;
xlabel('Real Part', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Imaginary Part', 'Interpreter', 'latex', 'FontSize', 11);
title('$H_\infty$: Closed-Loop Pole Distribution', 'Interpreter', 'latex', 'FontSize', 13);
axis equal;
xlim([-10 1]);
ylim([-10 10]);

subplot(1,2,2);
plot(real(poles_mc_lqg), imag(poles_mc_lqg), 'rx', 'MarkerSize', 8);
hold on;
plot([-10 0], [0 0], 'k-', 'LineWidth', 1.5);
grid on;
xlabel('Real Part', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Imaginary Part', 'Interpreter', 'latex', 'FontSize', 11);
title('LQG: Closed-Loop Pole Distribution', 'Interpreter', 'latex', 'FontSize', 13);
axis equal;
xlim([-10 1]);
ylim([-10 10]);

saveas(gcf, 'Problem05_MonteCarlo_Poles.fig');
saveas(gcf, 'Problem05_MonteCarlo_Poles.eps', 'epsc');

fprintf('Plots saved.\n\n');

fprintf('=== Problem 5 Complete ===\n');

%% Helper function
function peak = getPeakGain(sys)
    [mag, ~] = bode(sys, logspace(-3, 3, 1000));
    peak = max(mag(:));
end
