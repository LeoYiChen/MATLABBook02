%% problem3_code.m
% Differential Privacy for Distribution Network State Estimation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem3_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Differential Privacy Implementation for Smart Metre Aggregation
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-17
% Description: Implements Laplace, Gaussian, and exponential mechanisms for
%              privacy-preserving distribution network state estimation

clear; close all; clc;

%% 1. Synthetic Smart Metre Dataset Generation
fprintf('========================================\n');
fprintf('Differential Privacy - Distribution Network State Estimation\n');
fprintf('========================================\n\n');

fprintf('Step 1: Generating synthetic smart metre dataset...\n');

rng(456); % Reproducibility

numHouseholds = 200;
numHours = 168; % One week

% Household demographics
householdSize = randi([1, 5], numHouseholds, 1);
incomeLevel = randi([1, 3], numHouseholds, 1); % 1-Low, 2-Medium, 3-High
locationType = randi([1, 2], numHouseholds, 1); % 1-Urban, 2-Suburban

% Generate consumption patterns
% Base consumption depends on household size and income
baseConsumption = 0.5 * householdSize + 0.3 * incomeLevel;

% Time-varying pattern (higher during morning and evening)
hourOfWeek = (1:numHours)';
dayOfWeek = floor((hourOfWeek - 1) / 24) + 1;
hourOfDay = mod(hourOfWeek - 1, 24) + 1;

% Daily profile (peaks at 8am and 7pm)
dailyProfile = 0.3 + 0.4 * exp(-((hourOfDay - 8).^2) / 20) + ...
               0.5 * exp(-((hourOfDay - 19).^2) / 20);

% Weekend effect (flatter profile)
isWeekend = (dayOfWeek == 6) | (dayOfWeek == 7);
dailyProfile(isWeekend) = dailyProfile(isWeekend) * 0.9 + 0.1;

% Generate consumption data (kWh per hour per household)
consumption = zeros(numHouseholds, numHours);
for householdIdx = 1:numHouseholds
    householdProfile = baseConsumption(householdIdx) * dailyProfile';
    % Add random noise
    consumption(householdIdx, :) = householdProfile + ...
                                   0.2 * randn(1, numHours);
end

% Ensure non-negative consumption
consumption = max(consumption, 0);

fprintf('Generated consumption data for %d households over %d hours\n', ...
        numHouseholds, numHours);
fprintf('Mean household consumption: %.2f kWh/hour\n', mean(consumption(:)));
fprintf('Total network load range: [%.2f, %.2f] kWh/hour\n\n', ...
        min(sum(consumption, 1)), max(sum(consumption, 1)));

%% 2. Baseline Non-Private State Estimation
fprintf('Step 2: Computing baseline non-private statistics...\n');

% Aggregate statistics
trueMeanLoad = mean(sum(consumption, 1));
trueStdLoad = std(sum(consumption, 1));
[truePeakLoad, truePeakHour] = max(sum(consumption, 1));

fprintf('True Statistics (Non-Private):\n');
fprintf('  Mean aggregate load: %.2f kWh/hour\n', trueMeanLoad);
fprintf('  Std aggregate load: %.2f kWh/hour\n', trueStdLoad);
fprintf('  Peak load: %.2f kWh at hour %d\n\n', truePeakLoad, truePeakHour);

%% 3. Differential Privacy Mechanisms
fprintf('Step 3: Implementing differential privacy mechanisms...\n');

% Privacy budgets to evaluate
epsilonValues = [0.1, 0.5, 1.0, 5.0];
numEpsilons = length(epsilonValues);

% For Gaussian mechanism
delta = 1e-5;

% Query sensitivity
% For mean: removing one household changes sum by at most maxConsumption
maxConsumption = 10; % kWh/hour (upper bound on individual consumption)
sensitivityMean = maxConsumption / numHours;
sensitivitySum = maxConsumption;

% Storage for results
resultsLaplace = struct();
resultsGaussian = struct();

fprintf('Evaluating privacy budgets: epsilon = [%.1f, %.1f, %.1f, %.1f]\n\n', ...
        epsilonValues);

%% 4. Laplace Mechanism
fprintf('Step 4: Applying Laplace mechanism...\n');

for epsIdx = 1:numEpsilons
    epsilon = epsilonValues(epsIdx);
    
    % Laplace noise scale: Delta_f / epsilon
    % For mean computation over all hours
    aggregateLoad = sum(consumption, 1); % Aggregate per hour
    
    % Compute mean with Laplace noise
    trueMeanPerHour = mean(aggregateLoad);
    laplaceScale = sensitivitySum / epsilon;
    noisyMean = trueMeanPerHour + laprnd(1, 1, 0, laplaceScale);
    
    % Compute standard deviation with Laplace noise
    % Sensitivity of variance is more complex; use cautious bound
    sensitivityStd = 2 * maxConsumption;
    laplaceScaleStd = sensitivityStd / epsilon;
    noisyStd = trueStdLoad + laprnd(1, 1, 0, laplaceScaleStd);
    noisyStd = max(noisyStd, 0); % Ensure non-negative
    
    % Store results
    resultsLaplace(epsIdx).epsilon = epsilon;
    resultsLaplace(epsIdx).noisyMean = noisyMean;
    resultsLaplace(epsIdx).noisyStd = noisyStd;
    resultsLaplace(epsIdx).meanError = abs(noisyMean - trueMeanLoad);
    resultsLaplace(epsIdx).stdError = abs(noisyStd - trueStdLoad);
    
    fprintf('  Epsilon = %.2f: Mean error = %.2f kWh, Std error = %.2f kWh\n', ...
            epsilon, resultsLaplace(epsIdx).meanError, resultsLaplace(epsIdx).stdError);
end

fprintf('\n');

%% 5. Gaussian Mechanism
fprintf('Step 5: Applying Gaussian mechanism...\n');

for epsIdx = 1:numEpsilons
    epsilon = epsilonValues(epsIdx);
    
    % Gaussian noise scale: (Delta_f * sqrt(2 * log(1.25/delta))) / epsilon
    aggregateLoad = sum(consumption, 1);
    trueMeanPerHour = mean(aggregateLoad);
    
    gaussianScale = (sensitivitySum * sqrt(2 * log(1.25 / delta))) / epsilon;
    noisyMean = trueMeanPerHour + gaussianScale * randn(1, 1);
    
    % Standard deviation
    gaussianScaleStd = (2 * maxConsumption * sqrt(2 * log(1.25 / delta))) / epsilon;
    noisyStd = trueStdLoad + gaussianScaleStd * randn(1, 1);
    noisyStd = max(noisyStd, 0);
    
    % Store results
    resultsGaussian(epsIdx).epsilon = epsilon;
    resultsGaussian(epsIdx).noisyMean = noisyMean;
    resultsGaussian(epsIdx).noisyStd = noisyStd;
    resultsGaussian(epsIdx).meanError = abs(noisyMean - trueMeanLoad);
    resultsGaussian(epsIdx).stdError = abs(noisyStd - trueStdLoad);
    
    fprintf('  Epsilon = %.2f: Mean error = %.2f kWh, Std error = %.2f kWh\n', ...
            epsilon, resultsGaussian(epsIdx).meanError, resultsGaussian(epsIdx).stdError);
end

fprintf('\n');

%% 6. Exponential Mechanism (Peak Hour Selection)
fprintf('Step 6: Applying exponential mechanism for peak hour selection...\n');

aggregateLoad = sum(consumption, 1);

resultsExponential = struct();

for epsIdx = 1:numEpsilons
    epsilon = epsilonValues(epsIdx);
    
    % Utility function: negative distance from true peak
    % Sensitivity: changing one household changes utility by at most maxConsumption
    utilityScores = -abs((1:numHours) - truePeakHour);
    sensitivityUtility = 1; % Changing peak hour by 1
    
    % Exponential mechanism probabilities
    probabilities = exp((epsilon * utilityScores) / (2 * sensitivityUtility));
    probabilities = probabilities / sum(probabilities);
    
    % Sample peak hour
    cumulativeProb = cumsum(probabilities);
    randomValue = rand();
    selectedPeakHour = find(cumulativeProb >= randomValue, 1, 'first');
    
    % Store results
    resultsExponential(epsIdx).epsilon = epsilon;
    resultsExponential(epsIdx).selectedPeakHour = selectedPeakHour;
    resultsExponential(epsIdx).peakError = abs(selectedPeakHour - truePeakHour);
    
    fprintf('  Epsilon = %.2f: Selected hour = %d (True: %d), Error = %d hours\n', ...
            epsilon, selectedPeakHour, truePeakHour, resultsExponential(epsIdx).peakError);
end

fprintf('\n');

%% 7. Demographic Bias Analysis
fprintf('Step 7: Analysing differential privacy bias across demographics...\n');

% Focus on medium privacy budget (epsilon = 1.0)
epsilonTest = 1.0;
numTrials = 100;

% Stratify by income level
incomeLevels = [1, 2, 3];
incomeLabels = {'Low', 'Medium', 'High'};

biasResults = struct();

for incomeIdx = 1:length(incomeLevels)
    incomeMask = incomeLevel == incomeLevels(incomeIdx);
    
    % True mean for this income group
    trueGroupMean = mean(sum(consumption(incomeMask, :), 1));
    
    % Estimate with differential privacy (multiple trials)
    noisyEstimates = zeros(numTrials, 1);
    
    for trial = 1:numTrials
        laplaceScale = sensitivitySum / epsilonTest;
        noisyEstimates(trial) = trueGroupMean + laprnd(1, 1, 0, laplaceScale);
    end
    
    % Compute bias (systematic error)
    bias = mean(noisyEstimates - trueGroupMean);
    variance = var(noisyEstimates);
    mse = mean((noisyEstimates - trueGroupMean).^2);
    
    biasResults(incomeIdx).incomeLevel = incomeLabels{incomeIdx};
    biasResults(incomeIdx).trueValue = trueGroupMean;
    biasResults(incomeIdx).bias = bias;
    biasResults(incomeIdx).variance = variance;
    biasResults(incomeIdx).mse = mse;
    
    fprintf('  Income %s: True=%.2f, Bias=%.2f, Variance=%.2f, MSE=%.2f\n', ...
            incomeLabels{incomeIdx}, trueGroupMean, bias, variance, mse);
end

fprintf('\n');

%% 8. Privacy Budget Composition
fprintf('Step 8: Analysing privacy budget composition under sequential queries...\n');

% Simulate 10 sequential queries
numQueries = 10;
epsilonPerQuery = 0.5;

% Basic composition: total epsilon = sum of individual epsilons
basicCompositionEpsilon = numQueries * epsilonPerQuery;

% Advanced composition (tighter bound)
% epsilon_total = sqrt(2 * k * log(1/delta)) * epsilon + k * epsilon * (e^epsilon - 1)
% Simplified approximation
advancedCompositionEpsilon = sqrt(2 * numQueries * log(1/delta)) * epsilonPerQuery;

fprintf('Sequential queries: %d queries, epsilon per query: %.2f\n', ...
        numQueries, epsilonPerQuery);
fprintf('  Basic composition: Total epsilon = %.2f\n', basicCompositionEpsilon);
fprintf('  Advanced composition: Total epsilon = %.2f (%.1f%% reduction)\n', ...
        advancedCompositionEpsilon, ...
        (1 - advancedCompositionEpsilon / basicCompositionEpsilon) * 100);

fprintf('\n');

%% 9. Visualisation
fprintf('Step 9: Generating visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: Privacy-Utility Trade-off
fig1 = figure('Position', [100, 100, 1400, 600]);

subplot(1, 3, 1);
epsilonPlot = [resultsLaplace.epsilon];
meanErrorsLaplace = [resultsLaplace.meanError];
meanErrorsGaussian = [resultsGaussian.meanError];

semilogx(epsilonPlot, meanErrorsLaplace, 'bo-', 'LineWidth', 2, ...
         'MarkerSize', 8, 'DisplayName', 'Laplace');
hold on;
semilogx(epsilonPlot, meanErrorsGaussian, 'rs-', 'LineWidth', 2, ...
         'MarkerSize', 8, 'DisplayName', 'Gaussian');
xlabel('Privacy Budget $\varepsilon$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Mean Estimation Error (kWh)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Privacy-Utility Trade-off: Mean Load}', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
set(gca, 'XScale', 'log');

subplot(1, 3, 2);
stdErrorsLaplace = [resultsLaplace.stdError];
stdErrorsGaussian = [resultsGaussian.stdError];

semilogx(epsilonPlot, stdErrorsLaplace, 'bo-', 'LineWidth', 2, ...
         'MarkerSize', 8, 'DisplayName', 'Laplace');
hold on;
semilogx(epsilonPlot, stdErrorsGaussian, 'rs-', 'LineWidth', 2, ...
         'MarkerSize', 8, 'DisplayName', 'Gaussian');
xlabel('Privacy Budget $\varepsilon$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Std Estimation Error (kWh)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Privacy-Utility Trade-off: Load Variability}', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
set(gca, 'XScale', 'log');

subplot(1, 3, 3);
peakErrors = [resultsExponential.peakError];

semilogx(epsilonPlot, peakErrors, 'go-', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('Privacy Budget $\varepsilon$', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Peak Hour Error (hours)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Exponential Mechanism: Peak Detection}', 'Interpreter', 'latex');
grid on;
set(gca, 'XScale', 'log');

sgtitle('\textbf{Differential Privacy Mechanisms - State Estimation Accuracy}', ...
        'Interpreter', 'latex', 'FontSize', 14);

saveas(fig1, 'figures/Problem3_DP_Privacy_Utility.fig');
saveas(fig1, 'figures/Problem3_DP_Privacy_Utility.eps', 'epsc');
saveas(fig1, 'figures/Problem3_DP_Privacy_Utility.jpg');
fprintf('Saved: Problem3_DP_Privacy_Utility\n');

% Figure 2: Demographic Bias Analysis
fig2 = figure('Position', [150, 150, 1000, 600]);

subplot(1, 2, 1);
incomeCategories = categorical(incomeLabels);
biasValues = [biasResults.bias];
bar(incomeCategories, abs(biasValues));
ylabel('Absolute Bias (kWh)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{DP Bias Across Income Levels}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

subplot(1, 2, 2);
mseValues = [biasResults.mse];
bar(incomeCategories, mseValues, 'FaceColor', [0.8, 0.4, 0.4]);
ylabel('Mean Squared Error (kWh$^2$)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{DP Estimation Error Across Income Levels}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle({'\textbf{Differential Privacy Demographic Fairness}', ...
         sprintf('($\\varepsilon = %.1f$, %d trials)', epsilonTest, numTrials)}, ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig2, 'figures/Problem3_DP_Demographic_Bias.fig');
saveas(fig2, 'figures/Problem3_DP_Demographic_Bias.eps', 'epsc');
saveas(fig2, 'figures/Problem3_DP_Demographic_Bias.jpg');
fprintf('Saved: Problem3_DP_Demographic_Bias\n');

% Figure 3: Load Profile with Privacy Protection
fig3 = figure('Position', [200, 200, 1200, 500]);

% True aggregate load over week
trueAggregateLoad = sum(consumption, 1);

% Add Laplace noise for visualization (epsilon = 1.0)
epsilonViz = 1.0;
laplaceScaleViz = maxConsumption / epsilonViz;
noisyAggregateLoad = trueAggregateLoad + laprnd(1, numHours, 0, laplaceScaleViz);

plot(1:numHours, trueAggregateLoad, 'b-', 'LineWidth', 2, 'DisplayName', 'True Load');
hold on;
plot(1:numHours, noisyAggregateLoad, 'r-', 'LineWidth', 1.5, 'DisplayName', ...
     sprintf('DP Load ($\\varepsilon = %.1f$)', epsilonViz));

% Mark day boundaries
for day = 1:7
    xline(day * 24, 'k:', 'LineWidth', 0.8, 'HandleVisibility', 'off');
end

xlabel('Hour of Week', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Aggregate Load (kWh)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Weekly Load Profile: True vs Differential Privacy Protected}', ...
      'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
xlim([1, numHours]);

saveas(fig3, 'figures/Problem3_DP_Load_Profile.fig');
saveas(fig3, 'figures/Problem3_DP_Load_Profile.eps', 'epsc');
saveas(fig3, 'figures/Problem3_DP_Load_Profile.jpg');
fprintf('Saved: Problem3_DP_Load_Profile\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');

%% Helper Function: Laplace Random Number Generator
function r = laprnd(m, n, mu, b)
    % Generate Laplace-distributed random numbers
    % m, n: dimensions
    % mu: location parameter
    % b: scale parameter
    
    u = rand(m, n) - 0.5;
    r = mu - b * sign(u) .* log(1 - 2 * abs(u));
end
