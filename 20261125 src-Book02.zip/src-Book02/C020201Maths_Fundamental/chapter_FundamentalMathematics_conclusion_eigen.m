%% chapter_FundamentalMathematics_conclusion_eigen.m
% Eigenvalue analysis demonstrating linear algebra fundamentals.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_conclusion_eigen
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateEigenAnalysis();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateEigenAnalysis()
    % DEMONSTRATEEIGENANALYSIS Eigenvalue decomposition applications
    %   Illustrates fundamental linear algebra concepts through eigenanalysis
    
    fprintf('Eigenvalue Analysis: From Theory to Application\n');
    fprintf('================================================\n\n');
    
    %% Historical Context
    fprintf('HISTORICAL BACKGROUND\n');
    fprintf('-----\n\n');
    fprintf(['Augustin-Louis Cauchy (1821): First rigorous treatment\n', ...
        'of eigenvalues for symmetric matrices.\n\n', ...
        'Modern Applications: Principal Component Analysis, stability\n', ...
        'analysis, quantum mechanics, PageRank algorithm.\n\n']);
    
    %% Symmetric Matrix Example
    fprintf('SYMMETRIC MATRIX EIGENANALYSIS\n');
    fprintf('-----\n\n');
    
    % Create symmetric positive definite matrix (covariance-like)
    rng(42);
    A_raw = randn(4, 4);
    A = A_raw' * A_raw;  % Ensures positive definite
    
    fprintf('Symmetric positive definite matrix A:\n');
    disp(A);
    
    % Compute eigenvalues and eigenvectors
    [eigenvectors, eigenvalue_matrix] = eig(A);
    eigenvalues = diag(eigenvalue_matrix);
    
    fprintf('Eigenvalues (sorted descending):\n');
    [eigenvalues_sorted, sort_idx] = sort(eigenvalues, 'descend');
    eigenvectors_sorted = eigenvectors(:, sort_idx);
    
    for i = 1:length(eigenvalues_sorted)
        fprintf('  lambda_%d = %.4f\n', i, eigenvalues_sorted(i));
    end
    fprintf('\n');
    
    %% Verification of Eigenvalue Equation
    fprintf('VERIFICATION: A*v = lambda*v\n');
    fprintf('------\n\n');
    
    for i = 1:2  % Show first two eigenpairs
        v = eigenvectors_sorted(:, i);
        lambda = eigenvalues_sorted(i);
        
        Av = A * v;
        lambda_v = lambda * v;
        
        fprintf('Eigenpair %d:\n', i);
        fprintf('  A*v     = [%.4f, %.4f, %.4f, %.4f]^T\n', Av);
        fprintf('  lambda*v = [%.4f, %.4f, %.4f, %.4f]^T\n', lambda_v);
        fprintf('  Difference norm: %.2e\n\n', norm(Av - lambda_v));
    end
    
    %% Principal Component Analysis Application
    fprintf('APPLICATION: PRINCIPAL COMPONENT ANALYSIS\n');
    fprintf('-------\n\n');
    
    fprintf(['PCA reduces dimensionality by projecting data onto\n', ...
        'principal directions (eigenvectors of covariance matrix).\n\n']);
    
    % Generate correlated 2*D data
    num_samples = 1000;
    mean_vec = [0; 0];
    cov_matrix = [2, 1.5; 1.5, 2];
    
    data = mvnrnd(mean_vec, cov_matrix, num_samples)';
    
    % Compute sample covariance
    data_centred = data - mean(data, 2);
    sample_cov = (data_centred * data_centred') / (num_samples - 1);
    
    fprintf('Sample covariance matrix:\n');
    disp(sample_cov);
    
    % Eigenanalysis for PCA
    [pca_vectors, pca_values] = eig(sample_cov);
    [pca_eigenvalues, pca_idx] = sort(diag(pca_values), 'descend');
    pca_eigenvectors = pca_vectors(:, pca_idx);
    
    fprintf('Principal component eigenvalues:\n');
    fprintf('  PC1: %.4f (%.1f%% variance)\n', pca_eigenvalues(1), ...
        pca_eigenvalues(1) / sum(pca_eigenvalues) * 100);
    fprintf('  PC2: %.4f (%.1f%% variance)\n\n', pca_eigenvalues(2), ...
        pca_eigenvalues(2) / sum(pca_eigenvalues) * 100);
    
    %% Visualisation
    figure('Position', [100, 100, 1400, 500]);
    
    % Original data
    subplot(1, 3, 1);
    scatter(data(1, :), data(2, :), 20, 'b', 'filled', 'MarkerFaceAlpha', 0.3);
    hold on;
    
    % Plot eigenvectors scaled by eigenvalues
    scale_factor = 2;
    for i = 1:2
        vec = pca_eigenvectors(:, i) * sqrt(pca_eigenvalues(i)) * scale_factor;
        quiver(0, 0, vec(1), vec(2), 0, 'r', 'LineWidth', 3, ...
            'MaxHeadSize', 2);
        text(vec(1)*1.2, vec(2)*1.2, sprintf('PC%d', i), ...
            'FontSize', 12, 'FontWeight', 'bold', 'Color', 'r');
    end
    
    axis equal;
    grid on;
    xlabel('x_1');
    ylabel('x_2');
    title('Original Data with Principal Components');
    
    % Projected data (1*D)
    subplot(1, 3, 2);
    projected_1d = pca_eigenvectors(:, 1)' * data_centred;
    histogram(projected_1d, 50, 'FaceColor', [0.3, 0.6, 0.9]);
    xlabel('Projection on PC1');
    ylabel('Frequency');
    title('1*D Projection (Maximum Variance Direction)');
    grid on;
    
    % Reconstruction from PC1 only
    subplot(1, 3, 3);
    reconstructed = pca_eigenvectors(:, 1) * projected_1d;
    scatter(reconstructed(1, :), reconstructed(2, :), 20, 'g', ...
        'filled', 'MarkerFaceAlpha', 0.3);
    hold on;
    scatter(data(1, :), data(2, :), 10, 'b', 'filled', 'MarkerFaceAlpha', 0.1);
    
    axis equal;
    grid on;
    xlabel('x_1');
    ylabel('x_2');
    title('Reconstruction from PC1');
    legend('Reconstructed', 'Original', 'Location', 'best');
    
    %% Dynamical Systems Stability
    fprintf('APPLICATION: DYNAMICAL SYSTEMS STABILITY\n');
    fprintf('--------\n\n');
    
    fprintf(['Eigenvalues of system matrix determine stability:\n', ...
        '  - All real parts negative: stable (equilibrium attracts)\n', ...
        '  - Any positive real part: unstable (trajectories diverge)\n', ...
        '  - Pure imaginary: oscillatory behaviour\n\n']);
    
    % Example: damped harmonic oscillator
    % dx/dt = v, dv/dt = -k*x - c*v
    k = 4;  % spring constant
    c = 1;  % damping coefficient
    
    system_matrix = [0, 1; -k, -c];
    
    fprintf('Damped harmonic oscillator system matrix:\n');
    disp(system_matrix);
    
    [sys_eigvecs, sys_eigvals] = eig(system_matrix);
    eigenvalues_complex = diag(sys_eigvals);
    
    fprintf('\nEigenvalues:\n');
    for i = 1:length(eigenvalues_complex)
        if imag(eigenvalues_complex(i)) ~= 0
            fprintf('  lambda_%d = %.4f %+.4fi\n', i, ...
                real(eigenvalues_complex(i)), imag(eigenvalues_complex(i)));
        else
            fprintf('  lambda_%d = %.4f\n', i, eigenvalues_complex(i));
        end
    end
    
    fprintf('\nStability analysis:\n');
    max_real_part = max(real(eigenvalues_complex));
    if max_real_part < 0
        fprintf('  System is STABLE (all eigenvalues have negative real parts)\n');
    elseif max_real_part > 0
        fprintf('  System is UNSTABLE (positive real part detected)\n');
    else
        fprintf('  System is MARGINALLY STABLE (eigenvalue on imaginary axis)\n');
    end
    fprintf('\n');
end
