%% chapter_ES_code_problem12.m
% Magnetic Suspension Balance Simulation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem12
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem12
    % MATLABBook_ChapterES_Problem12.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Magnetic suspension balance system for sting-free aerodynamic
    %   force measurements. Includes electromagnetic modeling, PID control,
    %   drag reduction studies, and measurement uncertainty analysis.
    %
    % Dependencies: None (base MATLAB)
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 12
    
    fprintf('\n=== Problem 12: Magnetic Suspension Balance for Drag Reduction ===\n\n');
    
    %% Physical Parameters
    
    % Model properties (sphere for simplicity)
    m_model = 0.050;  % Mass (kg)
    r_model = 0.025;  % Radius (m)
    I_model = 0.4 * m_model * r_model^2;  % Moment of inertia (sphere)
    
    % Magnetic properties
    mu_0 = 4*pi*1e-7;  % Permeability of free space (H/m)
    mu_mag = 800;  % Magnetic moment (A m) - permanent magnet in model
    
    % Gravity
    g = 9.81;  % m/s
    
    % Wind tunnel
    rho_air = 1.225;  % Air density (kg/m)
    U_inf = 20;  % Freestream velocity (m/s)
    
    fprintf('System parameters:\n');
    fprintf('  Model mass: %.3f kg\n', m_model);
    fprintf('  Model radius: %.3f m\n', r_model);
    fprintf('  Magnetic moment: %.0f A m\n', mu_mag);
    fprintf('  Freestream velocity: %.1f m/s\n', U_inf);
    fprintf('  Reynolds number: %.0f\n\n', rho_air * U_inf * 2*r_model / 1.81e-5);
    
    %% Electromagnetic System Design
    
    fprintf('=== Electromagnetic System Design ===\n');
    
    % Simplified model: vertical suspension (1-DOF for clarity)
    % 4 coils: top, bottom, left, right (for 2D position control)
    % Focus on vertical (z) control against gravity
    
    % Magnetic field gradient (linearized near equilibrium)
    % dB/dz = B_gradient (from finite element analysis or measurements)
    B_gradient = 15;  % T/m (typical for MSBS)
    
    % Force sensitivity: F = mu * dB/dz
    K_mag = mu_mag * B_gradient;  % N/A (force per ampere in coil)
    
    % Equilibrium current (to counteract gravity)
    i_eq = m_model * g / K_mag;
    
    fprintf('Magnetic suspension:\n');
    fprintf('  Field gradient: %.1f T/m\n', B_gradient);
    fprintf('  Force sensitivity: %.3f N/A\n', K_mag);
    fprintf('  Equilibrium current: %.3f A\n\n', i_eq);
    
    %% System Dynamics and Control
    
    fprintf('=== Control System Design ===\n');
    
    % State-space model (vertical position only)
    % State: x = [z; z_dot]
    % Input: u = i (coil current)
    % Output: y = z (measured position)
    
    % Linearized dynamics around equilibrium
    % Magnetic stiffness (negative - inherently unstable)
    k_mag = -mu_mag * 2*B_gradient;  % Approximation
    
    % Damping (aerodynamic + electromagnetic)
    c_damp = 0.5;  % N s/m
    
    A = [0, 1; -k_mag/m_model, -c_damp/m_model];
    B = [0; K_mag/m_model];
    C = [1, 0];
    D = 0;
    
    % Check open-loop stability
    eig_open = eig(A);
    
    fprintf('Open-loop dynamics:\n');
    fprintf('  Eigenvalues: %.2f   %.2fj\n', real(eig_open(1)), imag(eig_open(1)));
    fprintf('  System is %s\n', any(real(eig_open) > 0)  'unstable' : 'stable');
    
    % PID controller design
    % Tuning via pole placement for desired settling time ~0.5s
    
    % Desired closed-loop poles (underdamped, zeta=0.7)
    zeta = 0.7;
    omega_n = 10;  % Natural frequency (rad/s)
    poles_desired = [-zeta*omega_n + 1j*omega_n*sqrt(1-zeta^2), ...
                     -zeta*omega_n - 1j*omega_n*sqrt(1-zeta^2)];
    
    % State feedback gain (pole placement)
    K_fb = place(A, B, poles_desired);
    
    fprintf('\nPID controller (via state feedback):\n');
    fprintf('  Desired poles: %.2f   %.2fj\n', real(poles_desired(1)), imag(poles_desired(1)));
    fprintf('  Feedback gains: [%.2f, %.2f]\n', K_fb(1), K_fb(2));
    
    % Closed-loop system
    A_cl = A - B*K_fb;
    eig_cl = eig(A_cl);
    
    fprintf('  Closed-loop eigenvalues: %.2f   %.2fj\n', real(eig_cl(1)), imag(eig_cl(1)));
    fprintf('  Damping ratio: %.2f\n', -real(eig_cl(1)) / abs(eig_cl(1)));
    fprintf('  Natural frequency: %.2f rad/s\n\n', abs(eig_cl(1)));
    
    %% Aerodynamic Force Modeling
    
    fprintf('=== Aerodynamic Drag Modeling ===\n');
    
    % Drag force: F_d = 0.5 * rho * U^2 * C_d * A
    A_frontal = pi * r_model^2;  % Frontal area
    
    % Drag coefficients for different configurations
    % 1. Smooth sphere (baseline)
    % 2. Sphere with trip strip (turbulent BL, lower drag in subcritical Re)
    % 3. Sphere with dimples (golf ball effect)
    
    % Reynolds number
    nu = 1.81e-5;  % Kinematic viscosity (m/s)
    Re = rho_air * U_inf * 2*r_model / nu;
    
    % Drag coefficient models (empirical correlations)
    if Re < 2e5
        C_d_smooth = 0.47;  % Subcritical regime
    elseif Re < 4e5
        C_d_smooth = 0.08;  % Supercritical (drag crisis)
    else
        C_d_smooth = 0.20;  % Post-critical
    end
    
    C_d_trip = 0.35;  % Tripped (forced turbulent BL)
    C_d_dimples = 0.25;  % Dimpled (golf ball)
    
    % Drag forces
    F_drag_smooth = 0.5 * rho_air * U_inf^2 * C_d_smooth * A_frontal;
    F_drag_trip = 0.5 * rho_air * U_inf^2 * C_d_trip * A_frontal;
    F_drag_dimples = 0.5 * rho_air * U_inf^2 * C_d_dimples * A_frontal;
    
    fprintf('Drag forces:\n');
    fprintf('  Smooth sphere (C_d=%.2f): F_d = %.4f N\n', C_d_smooth, F_drag_smooth);
    fprintf('  Trip strip (C_d=%.2f): F_d = %.4f N (%.1f%% reduction)\n', ...
            C_d_trip, F_drag_trip, (1 - F_drag_trip/F_drag_smooth)*100);
    fprintf('  Dimples (C_d=%.2f): F_d = %.4f N (%.1f%% reduction)\n\n', ...
            C_d_dimples, F_drag_dimples, (1 - F_drag_dimples/F_drag_smooth)*100);
    
    %% Closed-Loop Simulation
    
    fprintf('=== Closed-Loop Simulation ===\n');
    
    % Time vector
    dt = 0.001;  % 1 ms (1000 Hz control loop)
    t_sim = 10;  % 10 seconds
    t = 0:dt:t_sim;
    N = length(t);
    
    % Simulate three scenarios
    scenarios = {'Smooth', 'Trip Strip', 'Dimples'};
    F_drags = [F_drag_smooth, F_drag_trip, F_drag_dimples];
    C_ds = [C_d_smooth, C_d_trip, C_d_dimples];
    
    % Storage
    results = struct();
    
    for s = 1:length(scenarios)
        fprintf('Simulating: %s sphere...\n', scenarios{s});
        
        F_drag_current = F_drags(s);
        
        % State: [z; z_dot] (position, velocity)
        x = zeros(2, N);
        x(:, 1) = [0; 0];  % Start at equilibrium
        
        % Control input
        i_coil = zeros(1, N);
        
        % Measured drag (from current)
        F_drag_measured = zeros(1, N);
        
        % Reference position
        z_ref = 0;  % Maintain at origin
        
        % Disturbance: wind gust at t=2s
        for k = 1:N-1
            % Aerodynamic force (with gust)
            if t(k) > 2 && t(k) < 2.5
                F_aero = F_drag_current * (1 + 0.3*sin(2*pi*(t(k)-2)/0.5));  % 30% gust
            else
                F_aero = F_drag_current;
            end
            
            % External forces
            F_gravity = -m_model * g;
            
            % State feedback control
            e_z = z_ref - x(1, k);
            e_zdot = 0 - x(2, k);
            
            i_control = K_fb(1)*e_z + K_fb(2)*e_zdot;
            
            % Total current (feedforward + feedback)
            i_coil(k) = i_eq + i_control;  % i_eq counters gravity
            
            % Magnetic force
            F_mag = K_mag * i_coil(k);
            
            % Total force
            F_total = F_mag + F_gravity + F_aero;
            
            % Dynamics: a = F/m
            a = F_total / m_model;
            
            % Euler integration
            x(2, k+1) = x(2, k) + a * dt;
            x(1, k+1) = x(1, k) + x(2, k) * dt;
            
            % Infer drag from steady-state current (when z_dot   0)
            if abs(x(2, k)) < 0.01  % Quasi-steady
                F_drag_measured(k) = K_mag * i_coil(k) - K_mag * i_eq;
            end
        end
        
        % Store results
        results(s).scenario = scenarios{s};
        results(s).t = t;
        results(s).z = x(1, :);
        results(s).z_dot = x(2, :);
        results(s).i_coil = i_coil;
        results(s).F_drag_actual = F_drag_current;
        results(s).F_drag_measured = mean(F_drag_measured(F_drag_measured > 0));
        results(s).C_d = C_ds(s);
        
        fprintf('  Position RMS: %.2e m\n', rms(x(1, :)));
        fprintf('  Max deviation: %.2e m\n', max(abs(x(1, :))));
        fprintf('  Measured drag: %.4f N (actual: %.4f N)\n', ...
                results(s).F_drag_measured, F_drag_current);
        fprintf('  Measurement error: %.2f%%\n\n', ...
                abs(results(s).F_drag_measured - F_drag_current)/F_drag_current*100);
    end
    
    %% Uncertainty Analysis
    
    fprintf('=== Measurement Uncertainty Analysis ===\n');
    
    % Uncertainty sources
    % 1. Sensor noise (position measurement)
    % 2. Calibration uncertainty (K_mag)
    % 3. Unsteady aerodynamics (turbulence)
    
    sigma_sensor = 1e-5;  % Position sensor noise (10 m)
    sigma_K_mag = 0.02 * K_mag;  % 2% calibration uncertainty
    sigma_aero = 0.05 * F_drag_smooth;  % 5% unsteady fluctuations
    
    % Combined uncertainty (RSS - root sum square)
    %  F = sqrt((F/K)  _K + (F/i)  _i +  _aero)
    
    % Sensitivity: F/K = i, F/i = K
    sigma_current = 0.01;  % Current measurement noise (10 mA)
    
    sigma_F_mag = sqrt((i_eq * sigma_K_mag)^2 + (K_mag * sigma_current)^2);
    sigma_F_total = sqrt(sigma_F_mag^2 + sigma_aero^2);
    
    fprintf('Uncertainty budget:\n');
    fprintf('  Magnetic force uncertainty:   %.4f N (%.1f%%)\n', ...
            sigma_F_mag, sigma_F_mag/F_drag_smooth*100);
    fprintf('  Aerodynamic fluctuations:   %.4f N (%.1f%%)\n', ...
            sigma_aero, sigma_aero/F_drag_smooth*100);
    fprintf('  Total drag uncertainty:   %.4f N (%.1f%%)\n\n', ...
            sigma_F_total, sigma_F_total/F_drag_smooth*100);
    
    %% Visualization
    
    fprintf('Generating visualizations...\n');
    
    % Figure 1: Control performance
    figure('Position', [50 50 1600 900]);
    
    for s = 1:3
        % Subplot: Position tracking
        subplot(3, 3, s);
        plot(results(s).t, results(s).z * 1e3, 'b-', 'LineWidth', 1.5);
        xlabel('Time (s)', 'Interpreter', 'latex');
        ylabel('Position (mm)', 'Interpreter', 'latex');
        title(sprintf('%s: Position', results(s).scenario), 'Interpreter', 'latex');
        grid on;
        
        % Mark gust period
        hold on;
        patch([2 2.5 2.5 2], [ylim fliplr(ylim)], 'r', 'FaceAlpha', 0.1, 'EdgeColor', 'none');
        hold off;
        
        % Subplot: Velocity
        subplot(3, 3, s+3);
        plot(results(s).t, results(s).z_dot * 1e3, 'g-', 'LineWidth', 1.5);
        xlabel('Time (s)', 'Interpreter', 'latex');
        ylabel('Velocity (mm/s)', 'Interpreter', 'latex');
        title('Velocity', 'Interpreter', 'latex');
        grid on;
        
        % Subplot: Control current
        subplot(3, 3, s+6);
        plot(results(s).t, results(s).i_coil, 'r-', 'LineWidth', 1.5);
        xlabel('Time (s)', 'Interpreter', 'latex');
        ylabel('Coil Current (A)', 'Interpreter', 'latex');
        title('Control Input', 'Interpreter', 'latex');
        grid on;
    end
    
    sgtitle('Magnetic Suspension Control Performance', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    % Figure 2: Drag comparison
    figure('Position', [100 100 1200 600]);
    
    % Subplot 1: Drag force bar chart
    subplot(1, 2, 1);
    F_measured = [results.F_drag_measured];
    F_actual = [results.F_drag_actual];
    
    x_bar = 1:3;
    bar(x_bar, [F_actual; F_measured]', 'grouped');
    set(gca, 'XTickLabel', scenarios);
    ylabel('Drag Force (N)', 'Interpreter', 'latex');
    title('Drag Force Measurements', 'Interpreter', 'latex');
    legend({'Actual', 'Measured'}, 'Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 2: Drag reduction
    subplot(1, 2, 2);
    reduction = (1 - F_actual / F_actual(1)) * 100;
    
    bar(categorical(scenarios), reduction, 'FaceColor', [0.3 0.7 0.3]);
    ylabel('Drag Reduction (\%)', 'Interpreter', 'latex');
    title('Drag Reduction Effectiveness', 'Interpreter', 'latex');
    grid on;
    
    sgtitle('Aerodynamic Performance Comparison', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Visualizations generated.\n\n');
end
