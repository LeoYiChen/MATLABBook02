%% chapter_FundamentalMathematics_Lab3_code.m
% Laboratory3: Fourier analysis and signal processing.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_Lab3_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory exercise
laboratoryExercise3_FourierAnalysis();

% Local functions (moved to end so this listing is a valid MATLAB script)
function laboratoryExercise3_FourierAnalysis()
    % LABORATORYEXERCISE3_FOURIERANALYSIS Fourier transforms and filtering
    %   Comprehensive exploration of spectral analysis techniques
    %
    %   Author: Dr Leo Chen
    %   Created: December 2024
    %   Version: 1.0
    %   MATLAB Version: R2023b or later
    
    fprintf('\\textbf{Laboratory3: Fourier Analysis}\n');
    fprintf('================================================\n\n');
    
    %% Part A: Discrete Fourier Transform Fundamentals
    fprintf('\\textbf{PART A: DISCRETE FOURIER TRANSFORM}\n');
    fprintf('--------\n\n');
    
    fprintf(['Historical Context: Fourier (1807) proposed that any\n', ...
        'periodic function decomposes into sinusoids. Cooley-Tukey\n', ...
        'FFT algorithm (1965) made this computationally practical.\n\n']);
    
    % Signal parameters
    samplingFrequency = 1000;  % Hz
    duration = 2;  % seconds
    numSamples = samplingFrequency * duration;
    timeVector = (0:numSamples-1) / samplingFrequency;
    
    % Create composite signal: sum of sinusoids
    frequency1 = 50;   % Hz
    frequency2 = 120;  % Hz
    frequency3 = 200;  % Hz
    
    amplitude1 = 1.0;
    amplitude2 = 0.7;
    amplitude3 = 0.4;
    
    cleanSignal = amplitude1 * sin(2 * pi * frequency1 * timeVector) + ...
                  amplitude2 * sin(2 * pi * frequency2 * timeVector) + ...
                  amplitude3 * sin(2 * pi * frequency3 * timeVector);
    
    fprintf('\\textbf{Test Signal Parameters}:\n');
    fprintf('  Sampling frequency: $f_s = %d$ Hz\n', samplingFrequency);
    fprintf('  Duration: $T = %.1f$ seconds\n', duration);
    fprintf('  Number of samples: $N = %d$\n', numSamples);
    fprintf('\n  Component frequencies:\n');
    fprintf('    $f_1 = %d$ Hz, amplitude = %.2f\n', frequency1, amplitude1);
    fprintf('    $f_2 = %d$ Hz, amplitude = %.2f\n', frequency2, amplitude2);
    fprintf('    $f_3 = %d$ Hz, amplitude = %.2f\n\n', frequency3, amplitude3);
    
    % Compute FFT
    signalFFT = fft(cleanSignal);
    
    % Frequency axis (properly scaled)
    frequencyAxis = (0:numSamples-1) * (samplingFrequency / numSamples);
    
    % Magnitude spectrum (one-sided)
    magnitudeSpectrum = abs(signalFFT / numSamples);
    magnitudeOneSided = magnitudeSpectrum(1:numSamples/2+1);
    magnitudeOneSided(2:end-1) = 2 * magnitudeOneSided(2:end-1);
    
    frequencyOneSided = frequencyAxis(1:numSamples/2+1);
    
    fprintf('\\textbf{FFT Computation Results}:\n');
    fprintf('  FFT length: %d\n', length(signalFFT));
    fprintf('  Frequency resolution: $\\Delta f = %.3f$ Hz\n', ...
        samplingFrequency / numSamples);
    fprintf('  Nyquist frequency: $f_{Nyquist} = %.1f$ Hz\n\n', ...
        samplingFrequency / 2);
    
    % Identify peaks in spectrum
    [peakValues, peakLocations] = findpeaks(magnitudeOneSided, ...
        frequencyOneSided, 'MinPeakHeight', 0.3, 'SortStr', 'descend');
    
    fprintf('\\textbf{Detected Frequency Components}:\n');
    fprintf('%-10*s  %-15*s  %-20*s\n', 'Rank', 'Frequency (Hz)', 'Amplitude');
    fprintf('%s\n', repmat('-', 1, 50));
    
    for idx = 1:min(3, length(peakValues))
        fprintf('%-10*d  %-15.2*f  %-20.4*f\n', idx, peakLocations(idx), ...
            peakValues(idx));
    end
    fprintf('\n');
    
    % Verify inverse transform
    reconstructedSignal = ifft(signalFFT);
    reconstructionError = norm(cleanSignal - real(reconstructedSignal)) / ...
        norm(cleanSignal);
    
    fprintf(['\\textbf{Inverse Transform Verification}:\n', ...
        '  Reconstruction error (relative): %.2e\n', ...
        '  (Confirms perfect reconstruction)\n\n'], reconstructionError);
    
    %% Part B: Spectral Analysis and Filtering
    fprintf('\\textbf{PART B: SPECTRAL ANALYSIS AND FILTERING}\n');
    fprintf('---------\n\n');
    
    fprintf(['Historical Context: Shannon (1949) established that\n', ...
        'filtering in frequency domain enables optimal signal\n', ...
        'processing for communication systems.\n\n']);
    
    % Add noise to signal
    noisePower = 0.5;
    noisySignal = cleanSignal + noisePower * randn(size(cleanSignal));
    
    % Compute signal-to-noise ratio (SNR)
    signalPower = var(cleanSignal);
    noiseActualPower = var(noisySignal - cleanSignal);
    snrOriginal = 10 * log10(signalPower / noiseActualPower);
    
    fprintf('\\textbf{Noise Characteristics}:\n');
    fprintf('  Noise type: Additive white Gaussian noise (AWGN)\n');
    fprintf('  Noise standard deviation: $\\sigma = %.2f$\n', noisePower);
    fprintf('  Original SNR: %.2f dB\n\n', snrOriginal);
    
    % FFT of noisy signal
    noisyFFT = fft(noisySignal);
    
    % Power spectral density
    psdOriginal = (abs(signalFFT).^2) / numSamples;
    psdNoisy = (abs(noisyFFT).^2) / numSamples;
    
    % Design low-pass filter (frequency domain)
    cutoffFrequency = 250;  % Hz
    filterMask = zeros(size(frequencyAxis));
    filterMask(frequencyAxis <= cutoffFrequency) = 1;
    filterMask(frequencyAxis >= (samplingFrequency - cutoffFrequency)) = 1;
    
    fprintf('\\textbf{Low-Pass Filter Design}:\n');
    fprintf('  Filter type: Ideal brick-wall (frequency domain)\n');
    fprintf('  Cutoff frequency: $f_c = %d$ Hz\n', cutoffFrequency);
    fprintf('  Passband: $[0, %d]$ Hz\n', cutoffFrequency);
    fprintf('  Stopband: $[%d, %d]$ Hz\n\n', cutoffFrequency, ...
        samplingFrequency/2);
    
    % Apply filter in frequency domain
    filteredFFT = noisyFFT .* filterMask;
    
    % Inverse FFT to obtain filtered signal
    filteredSignal = real(ifft(filteredFFT));
    
    % Compute filtered SNR
    noiseFiltered = filteredSignal - cleanSignal;
    filteredNoisePower = var(noiseFiltered);
    snrFiltered = 10 * log10(signalPower / filteredNoisePower);
    snrImprovement = snrFiltered - snrOriginal;
    
    fprintf('\\textbf{Filtering Performance}:\n');
    fprintf('  Filtered SNR: %.2f dB\n', snrFiltered);
    fprintf('  SNR improvement: %.2f dB\n', snrImprovement);
    fprintf('  Relative error (vs clean signal): %.4f\n\n', ...
        norm(filteredSignal - cleanSignal) / norm(cleanSignal));
    
    % Design band-pass filter
    bandLower = 40;   % Hz
    bandUpper = 130;  % Hz
    
    bandpassMask = zeros(size(frequencyAxis));
    bandpassMask(frequencyAxis >= bandLower & ...
        frequencyAxis <= bandUpper) = 1;
    bandpassMask(frequencyAxis >= (samplingFrequency - bandUpper) & ...
        frequencyAxis <= (samplingFrequency - bandLower)) = 1;
    
    filteredBandpass = real(ifft(noisyFFT .* bandpassMask));
    
    fprintf('\\textbf{Band-Pass Filter}:\n');
    fprintf('  Passband: $[%d, %d]$ Hz\n', bandLower, bandUpper);
    fprintf('  (Extracts first two frequency components)\n\n');
    
    %% Part C: Advanced Signal Processing
    fprintf('\\textbf{PART C: ADVANCED TECHNIQUES}\n');
    fprintf('------\n\n');
    
    fprintf(['Historical Context: Windowing techniques (1940*s-1950*s)\n', ...
        'address spectral leakage caused by finite observation\n', ...
        'windows, crucial for accurate spectral estimation.\n\n']);
    
    % Demonstrate spectral leakage
    % Create signal with non-integer number of periods
    leakageFreq = 50.5;  % Not aligned with frequency bins
    leakageSignal = sin(2 * pi * leakageFreq * timeVector);
    
    % FFT without windowing
    leakageFFT_noWindow = fft(leakageSignal);
    leakageMag_noWindow = abs(leakageFFT_noWindow(1:numSamples/2+1)) / ...
        (numSamples/2);
    
    % Apply Hamming window
    hammingWindow = hamming(numSamples)';
    windowedSignal = leakageSignal .* hammingWindow;
    leakageFFT_windowed = fft(windowedSignal);
    leakageMag_windowed = abs(leakageFFT_windowed(1:numSamples/2+1)) / ...
        (numSamples/2);
    
    fprintf('\\textbf{Windowing Analysis}:\n');
    fprintf('  Test frequency: %.1f Hz (causes leakage)\n', leakageFreq);
    fprintf('  Window type: Hamming\n');
    
    % Measure spectral leakage
    mainLobePower_noWindow = max(leakageMag_noWindow);
    sideLobePower_noWindow = median(leakageMag_noWindow);
    
    mainLobePower_windowed = max(leakageMag_windowed);
    sideLobePower_windowed = median(leakageMag_windowed);
    
    fprintf('\n  Without windowing:\n');
    fprintf('    Main lobe power: %.4f\n', mainLobePower_noWindow);
    fprintf('    Side lobe power: %.4e\n', sideLobePower_noWindow);
    fprintf('\n  With Hamming window:\n');
    fprintf('    Main lobe power: %.4f\n', mainLobePower_windowed);
    fprintf('    Side lobe power: %.4e\n', sideLobePower_windowed);
    fprintf('    Leakage reduction: %.1f dB\n\n', ...
        20 * log10(sideLobePower_noWindow / sideLobePower_windowed));
    
    % Short-Time Fourier Transform (STFT) for chirp signal
    fprintf('\\textbf{Time-Frequency Analysis}:\n');
    fprintf('  Creating frequency-modulated (chirp) signal...\n');
    
    % Chirp signal: frequency varies from 10 Hz to 400 Hz
    chirpSignal = chirp(timeVector, 10, duration, 400, 'linear');
    
    % Compute spectrogram
    windowLength = 256;
    overlapLength = 200;
    nfft = 512;
    
    [spectrogramData, frequencyVector, timeWindow] = spectrogram(...
        chirpSignal, hamming(windowLength), overlapLength, nfft, ...
        samplingFrequency, 'yaxis');
    
    fprintf('  STFT parameters:\n');
    fprintf('    Window length: %d samples (%.3f seconds)\n', ...
        windowLength, windowLength/samplingFrequency);
    fprintf('    Overlap: %d samples (%.1f\\%%)\n', overlapLength, ...
        100*overlapLength/windowLength);
    fprintf('    FFT length: %d\n', nfft);
    fprintf('    Time resolution: %.3f seconds\n', ...
        mean(diff(timeWindow)));
    fprintf('    Frequency resolution: %.2f Hz\n\n', ...
        mean(diff(frequencyVector)));
    
    %% Zero-padding demonstration
    fprintf('\\textbf{Zero-Padding for Interpolation}:\n');
    
    % Short signal
    shortDuration = 0.1;  % seconds
    shortSamples = round(samplingFrequency * shortDuration);
    shortTime = (0:shortSamples-1) / samplingFrequency;
    shortSignal = sin(2 * pi * 50 * shortTime);
    
    % FFT without zero-padding
    shortFFT = fft(shortSignal);
    shortFreqRes = samplingFrequency / shortSamples;
    
    % FFT with zero-padding
    paddedLength = 2048;
    paddedFFT = fft(shortSignal, paddedLength);
    paddedFreqRes = samplingFrequency / paddedLength;
    
    fprintf('  Original signal: %d samples\n', shortSamples);
    fprintf('  Frequency resolution: %.2f Hz\n', shortFreqRes);
    fprintf('\n  Zero-padded to: %d samples\n', paddedLength);
    fprintf('  Improved frequency resolution: %.2f Hz\n', paddedFreqRes);
    fprintf('  Resolution improvement: %.1fx\n\n', shortFreqRes/paddedFreqRes);
    
    %% Visualisations
    createFourierAnalysisPlots(timeVector, cleanSignal, noisySignal, ...
        filteredSignal, frequencyOneSided, magnitudeOneSided, ...
        psdNoisy, filterMask, frequencyAxis, spectrogramData, ...
        frequencyVector, timeWindow, leakageFreq, ...
        leakageMag_noWindow, leakageMag_windowed);
    
    fprintf('\\textbf{Exercise Complete}\n\n');
    fprintf(['Key Insights:\n', ...
        '1. FFT efficiently computes frequency spectrum in $O(N \\log N)$ time\n', ...
        '2. Frequency-domain filtering removes unwanted spectral components\n', ...
        '3. Windowing reduces spectral leakage from finite observations\n', ...
        '4. STFT reveals time-varying frequency content\n', ...
        '5. Zero-padding interpolates spectrum without adding information\n']);
end

function createFourierAnalysisPlots(time, clean, noisy, filtered, ...
    freq, magnitude, psd, filterMask, freqAxis, specData, ...
    specFreq, specTime, leakFreq, leakNoWin, leakWin)
    % CREATEFOURIERANALYSISPLOTS Generate comprehensive visualisations
    
    figure('Position', [100, 100, 1600, 1000]);
    
    % Time-domain signals
    subplot(3, 3, 1);
    plot(time(1:500), clean(1:500), 'b-', 'LineWidth', 1.5);
    xlabel('Time (seconds)', 'Interpreter', 'latex');
    ylabel('Amplitude', 'Interpreter', 'latex');
    title('Clean Signal (Time Domain)', 'Interpreter', 'latex');
    grid on;
    xlim([0, 0.5]);
    
    subplot(3, 3, 2);
    plot(time(1:500), noisy(1:500), 'r-', 'LineWidth', 1);
    xlabel('Time (seconds)', 'Interpreter', 'latex');
    ylabel('Amplitude', 'Interpreter', 'latex');
    title('Noisy Signal', 'Interpreter', 'latex');
    grid on;
    xlim([0, 0.5]);
    
    subplot(3, 3, 3);
    plot(time(1:500), filtered(1:500), 'g-', 'LineWidth', 1.5);
    hold on;
    plot(time(1:500), clean(1:500), 'b-', 'LineWidth', 1);
    xlabel('Time (seconds)', 'Interpreter', 'latex');
    ylabel('Amplitude', 'Interpreter', 'latex');
    title('Filtered Signal', 'Interpreter', 'latex');
    legend({'Filtered', 'Original'}, 'Interpreter', 'latex', ...
        'Location', 'best');
    grid on;
    xlim([0, 0.5]);
    
    % Frequency-domain representations
    subplot(3, 3, 4);
    plot(freq, magnitude, 'b-', 'LineWidth', 2);
    xlabel('Frequency (Hz)', 'Interpreter', 'latex');
    ylabel('Magnitude', 'Interpreter', 'latex');
    title('Magnitude Spectrum (Clean Signal)', 'Interpreter', 'latex');
    grid on;
    xlim([0, 300]);
    
    subplot(3, 3, 5);
    plot(freq, 10*log10(psd(1:length(freq))), 'r-', 'LineWidth', 1.5);
    xlabel('Frequency (Hz)', 'Interpreter', 'latex');
    ylabel('Power (dB)', 'Interpreter', 'latex');
    title('Power Spectral Density (Noisy)', 'Interpreter', 'latex');
    grid on;
    xlim([0, 500]);
    
    subplot(3, 3, 6);
    plot(freqAxis, filterMask, 'k-', 'LineWidth', 2);
    xlabel('Frequency (Hz)', 'Interpreter', 'latex');
    ylabel('Filter Response', 'Interpreter', 'latex');
    title('Low-Pass Filter Mask', 'Interpreter', 'latex');
    grid on;
    ylim([-0.1, 1.1]);
    xlim([0, 500]);
    
    % Spectral leakage comparison
    subplot(3, 3, 7);
    plot(freq, leakNoWin, 'b-', 'LineWidth', 1.5, ...
        'DisplayName', 'No Window');
    hold on;
    plot(freq, leakWin, 'r-', 'LineWidth', 1.5, ...
        'DisplayName', 'Hamming Window');
    xline(leakFreq, 'k-', 'LineWidth', 2, ...
        'Label', sprintf('True freq: %.1f Hz', leakFreq));
    xlabel('Frequency (Hz)', 'Interpreter', 'latex');
    ylabel('Magnitude', 'Interpreter', 'latex');
    title('Spectral Leakage Comparison', 'Interpreter', 'latex');
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    xlim([0, 100]);
    set(gca, 'YScale', 'log');
    
    % Spectrogram
    subplot(3, 3, [8, 9]);
    surf(specTime, specFreq, 10*log10(abs(specData)), 'EdgeColor', 'none');
    view(0, 90);
    xlabel('Time (seconds)', 'Interpreter', 'latex');
    ylabel('Frequency (Hz)', 'Interpreter', 'latex');
    title('Spectrogram (Time-Frequency Analysis)', 'Interpreter', 'latex');
    colorbar;
    colormap('jet');
    caxis([-80, 0]);
    ylim([0, 500]);
end
