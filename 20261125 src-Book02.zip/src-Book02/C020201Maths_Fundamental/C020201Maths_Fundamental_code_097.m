%% C020201Maths_Fundamental_code_097.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Incremental PCA for streaming data
numComponents = 2;
batchSize = 100;

% Initialise incremental PCA model
iPCAModel = incrementalPCA('NumComponents', numComponents);

% Process data in batches
for batchIdx = 1:batchSize:numSamples
    endIdx = min(batchIdx + batchSize - 1, numSamples);
    batchData = dataMatrix(:, batchIdx:endIdx)';
    iPCAModel = fit(iPCAModel, batchData);
end

% Transform new data using learned components
transformedData = transform(iPCAModel, dataMatrix');
