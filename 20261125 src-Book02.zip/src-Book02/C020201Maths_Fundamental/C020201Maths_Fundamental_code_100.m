%% C020201Maths_Fundamental_code_100.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Romberg integration
maxOrder = 6;
rombergTable = zeros(maxOrder, maxOrder);

for k = 1:maxOrder
    n = 2^(k-1);
    xPoints = linspace(a, b, n + 1);
    yPoints = integrand(xPoints);
    h = (b - a) / n;
    rombergTable(k, 1) = h * (sum(yPoints) - (yPoints(1) + yPoints(end))/2);
    
    % Richardson extrapolation
    for m = 2:k
        rombergTable(k, m) = (4^(m-1) * rombergTable(k, m-1) - ...
            rombergTable(k-1, m-1)) / (4^(m-1) - 1);
    end
end

integralRomberg = rombergTable(maxOrder, maxOrder);
