%% chapter_FundamentalMathematics_example_ForwardPropagation.m
% Simple neural network forward propagation demonstration.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_ForwardPropagation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Neural Network Forward Propagation
% Demonstrates matrix operations in deep learning

% Define network architecture
inputSize = 4;
hiddenSize = 6;
outputSize = 3;
numSamples = 10;

% Initialise random weights and biases
rng(42);
weightsInputHidden = randn(hiddenSize, inputSize) * 0.1;
biasHidden = randn(hiddenSize, 1) * 0.1;
weightsHiddenOutput = randn(outputSize, hiddenSize) * 0.1;
biasOutput = randn(outputSize, 1) * 0.1;

% Generate random input data
inputData = randn(inputSize, numSamples);

% Forward propagation: Input to Hidden layer
hiddenLayerInput = weightsInputHidden * inputData + biasHidden;
hiddenLayerOutput = max(0, hiddenLayerInput);  % ReLU activation

% Forward propagation: Hidden to Output layer
outputLayerInput = weightsHiddenOutput * hiddenLayerOutput + biasOutput;

% Apply softmax activation for classification
expScores = exp(outputLayerInput);
outputProbabilities = expScores ./ sum(expScores, 1);

% Display network information
fprintf('Network Architecture:\n');
fprintf('Input layer size: %d\n', inputSize);
fprintf('Hidden layer size: %d\n', hiddenSize);
fprintf('Output layer size: %d\n', outputSize);
fprintf('Number of samples: %d\n', numSamples);
fprintf('\nOutput probabilities for first sample:\n');
fprintf('Class 1: %.4f\n', outputProbabilities(1, 1));
fprintf('Class 2: %.4f\n', outputProbabilities(2, 1));
fprintf('Class 3: %.4f\n', outputProbabilities(3, 1));
fprintf('Sum: %.4f (should be 1.0)\n', sum(outputProbabilities(:, 1)));
