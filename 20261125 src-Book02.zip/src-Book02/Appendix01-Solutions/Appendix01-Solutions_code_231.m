%% Appendix01-Solutions_code_231.m
% Problem 13: Autonomous Mobile Robot Chemist with AI Decision-Making
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% ========================================================================
%% Problem 13: Autonomous Mobile Robot Chemist with AI Decision-Making
%% ========================================================================
% Scientific Goal:
%   Simulate an autonomous robotic chemist that executes synthesis reactions,
%   analyzes products, and uses AI to decide the next experiment. The robot
%   operates across three chemistry domains:
%     (1) Medicinal Chemistry: Optimize Suzuki coupling yield/selectivity
%     (2) Supramolecular Chemistry: Maximize host-guest binding affinity
%     (3) Photochemistry: Discover photocatalytic reaction conditions
%
% Approach:
%   - Multi-module workflow: Synthesis   UPLC-MS   NMR   AI Decision   Repeat
%   - AI decision-making: Bayesian optimization for condition optimization,
%                         decision tree for synthetic route selection
%   - Resource scheduling: Allocate instruments (conflicts, downtime)
%   - Performance metrics: Throughput (reactions/day), success rate, yield
%
% Demonstrates: Autonomous experimentation, multi-task learning, robotic
%               workflow orchestration, AI-accelerated chemistry
%% ------------------------------------

clear; clc; close all;
rng(2020); % Reproducibility (year of Nature publication)

fprintf('========================================\n');
fprintf('Problem 13: Autonomous Mobile Robot Chemist\n');
fprintf('========================================\n\n');

%% Step 1: Initialize Robot System and Chemistry Domains
fprintf('Step 1: Initializing robot system and chemistry domains...\n\n');

% Robot system parameters
robotPrecision = 0.12; % mm (positioning accuracy)
manipulationTime = struct('pipette', 15, 'transfer', 30, 'heat', 120, 'cool', 90); % seconds
analyticalTime = struct('UPLC_MS', 600, 'NMR', 900, 'workup', 300); % seconds

fprintf('  Robot System:\n');
fprintf('    Platform: KUKA LBR iiwa (7-DOF collaborative robot)\n');
fprintf('    Positioning accuracy: %.2f mm\n', robotPrecision);
fprintf('    Modules: Synthesis, UPLC-MS, NMR, Liquid Handler\n\n');

% Chemistry Domain 1: Medicinal Chemistry (Suzuki Coupling)
% Reaction: Aryl halide + Aryl boronic acid -[Pd catalyst, base, solvent]-> Biaryl product
% Variables: Pd loading (1-5 mol%), base (K2CO3, Cs2CO3, K3PO4), solvent (DMF, toluene, EtOH)
chemDomain1 = struct();
chemDomain1.name = 'Medicinal Chemistry (Suzuki Coupling)';
chemDomain1.variables = {'Pd_loading', 'base', 'solvent', 'temp', 'time'};
chemDomain1.ranges = {[1, 5], [1, 2, 3], [1, 2, 3], [80, 120], [2, 24]}; % Continuous + categorical
chemDomain1.baseNames = {'K2CO3', 'Cs2CO3', 'K3PO4'};
chemDomain1.solventNames = {'DMF', 'Toluene', 'EtOH'};
chemDomain1.objective = 'yield'; % Maximize product yield (%)

% Ground truth yield function (simplified, real chemistry is more complex)
chemDomain1.yieldFn = @(Pd, base, solv, temp, time) max(0, min(100, ...
    40 + 10*Pd - 2*Pd^2 ...                      % Optimal Pd ~2.5 mol%
    + [0, 8, 5](base) ...                        % Cs2CO3 best base
    + [12, 5, -3](solv) ...                      % DMF best solvent
    + 0.3*(temp - 100) - 0.01*(temp - 100)^2 ... % Optimal temp 100 C
    + 2*log(time) ...                            % Longer reaction better (diminishing returns)
    + 15*randn()));                              % Experimental noise

% Chemistry Domain 2: Supramolecular Chemistry (Host-Guest Binding)
% System: Cyclodextrin host + adamantane guest -[solvent, pH]-> Inclusion complex
% Variables: CD type (alpha, beta, gamma), guest conc. (mM), pH, temp
chemDomain2 = struct();
chemDomain2.name = 'Supramolecular Chemistry (Host-Guest)';
chemDomain2.variables = {'CD_type', 'guest_conc', 'pH', 'temp'};
chemDomain2.ranges = {[1, 2, 3], [0.1, 10], [3, 11], [20, 50]}; % mM, pH,  C
chemDomain2.CDNames = {'alpha-CD', 'beta-CD', 'gamma-CD'};
chemDomain2.objective = 'Ka'; % Maximize binding constant Ka (M^-1)

% Ground truth Ka function
chemDomain2.KaFn = @(CD, conc, pH, temp) max(100, ...
    [1e3, 1e5, 5e4](CD) ...                      % beta-CD strongest binding
    * (1 + 0.2*log(conc)) ...                    % Higher conc. favors binding (mass action)
    * exp(-0.1*abs(pH - 7)) ...                  % Optimal pH 7 (neutral)
    * exp(-0.02*(temp - 25)) ...                 % Lower temp favors enthalpy (van der Waals)
    * (1 + 0.3*randn()));                        % Experimental noise

% Chemistry Domain 3: Photochemistry (Photocatalytic Oxidation)
% Reaction: Substrate + O2 -[photocatalyst, light, solvent]-> Oxidized product
% Variables: Catalyst (Eosin Y, Rose Bengal, Ru(bpy)3), light intensity (mW/cm2), wavelength
chemDomain3 = struct();
chemDomain3.name = 'Photochemistry (Photocatalytic Oxidation)';
chemDomain3.variables = {'catalyst', 'light_intensity', 'wavelength', 'solvent'};
chemDomain3.ranges = {[1, 2, 3], [10, 100], [400, 550], [1, 2, 3]}; % mW/cm2, nm
chemDomain3.catalystNames = {'Eosin Y', 'Rose Bengal', 'Ru(bpy)3'};
chemDomain3.solventNames = {'MeCN', 'MeOH', 'H2O'};
chemDomain3.objective = 'conversion'; % Maximize substrate conversion (%)

% Ground truth conversion function
chemDomain3.convFn = @(cat, intensity, wavel, solv) max(0, min(100, ...
    [30, 50, 40](cat) ...                        % Rose Bengal most active
    + 0.5*intensity - 0.002*intensity^2 ...      % Optimal intensity ~125 mW/cm2 (photobleaching at high)
    - 0.1*abs(wavel - 520) ...                   % Optimal wavelength 520 nm (Rose Bengal absorption)
    + [8, 5, -2](solv) ...                       % MeCN best solvent (O2 solubility)
    + 12*randn()));                              % Experimental noise

fprintf('  Chemistry Domains:\n');
fprintf('    1. %s\n', chemDomain1.name);
fprintf('    2. %s\n', chemDomain2.name);
fprintf('    3. %s\n\n', chemDomain3.name);

%% Step 2: Define Initial Experimental Plan (Human Expert Input)
fprintf('Step 2: Defining initial experimental plan...\n\n');

% Each domain starts with 5 diverse initial experiments (DOE-like)
numInitial = 5;

% Domain 1: Suzuki coupling initial conditions
domain1_init = [
    2.0, 1, 1, 100, 12;   % Baseline: 2% Pd, K2CO3, DMF, 100 C, 12h
    4.0, 2, 2, 90,  6;    % High Pd, Cs2CO3, Toluene, low temp, short time
    1.0, 3, 3, 110, 24;   % Low Pd, K3PO4, EtOH, high temp, long time
    3.0, 1, 2, 100, 12;   % Mid Pd, K2CO3, Toluene
    2.5, 2, 1, 95,  18;   % Mid Pd, Cs2CO3, DMF
];

domain1_yields = arrayfun(@(i) chemDomain1.yieldFn(domain1_init(i,1), domain1_init(i,2), ...
                          domain1_init(i,3), domain1_init(i,4), domain1_init(i,5)), 1:numInitial)';

% Domain 2: Host-guest initial conditions
domain2_init = [
    2, 1.0, 7, 25;   % beta-CD, 1 mM, pH 7, 25 C (standard)
    1, 5.0, 5, 30;   % alpha-CD, 5 mM, pH 5, 30 C
    3, 0.5, 9, 20;   % gamma-CD, 0.5 mM, pH 9, 20 C
    2, 2.0, 6, 40;   % beta-CD, 2 mM, pH 6, 40 C
    2, 1.0, 8, 25;   % beta-CD, 1 mM, pH 8, 25 C
];

domain2_Ka = arrayfun(@(i) chemDomain2.KaFn(domain2_init(i,1), domain2_init(i,2), ...
                      domain2_init(i,3), domain2_init(i,4)), 1:numInitial)';

% Domain 3: Photochemistry initial conditions
domain3_init = [
    2, 50,  520, 1;   % Rose Bengal, 50 mW/cm2, 520 nm, MeCN
    1, 30,  450, 2;   % Eosin Y, 30 mW/cm2, 450 nm, MeOH
    3, 80,  470, 3;   % Ru(bpy)3, 80 mW/cm2, 470 nm, H2O
    2, 70,  540, 1;   % Rose Bengal, 70 mW/cm2, 540 nm, MeCN
    1, 100, 420, 2;   % Eosin Y, 100 mW/cm2, 420 nm, MeOH
];

domain3_conv = arrayfun(@(i) chemDomain3.convFn(domain3_init(i,1), domain3_init(i,2), ...
                        domain3_init(i,3), domain3_init(i,4)), 1:numInitial)';

fprintf('  Initial experiments (5 per domain):\n');
fprintf('    Domain 1 (Suzuki): Yield range %.1f%% - %.1f%%\n', min(domain1_yields), max(domain1_yields));
fprintf('    Domain 2 (Host-Guest): Ka range %.2e - %.2e M^-1\n', min(domain2_Ka), max(domain2_Ka));
fprintf('    Domain 3 (Photo): Conversion range %.1f%% - %.1f%%\n\n', min(domain3_conv), max(domain3_conv));

%% Step 3: Autonomous Experimentation Loop (Robot + AI Decision)
fprintf('Step 3: Starting autonomous experimentation loops...\n\n');

numIterations = 10; % 10 iterations per domain
batchSize = 3;      % Robot executes 3 reactions per batch (parallel synthesis)

% Storage for all experiments
allExperiments = struct();
allExperiments.domain1 = struct('conditions', domain1_init, 'yields', domain1_yields);
allExperiments.domain2 = struct('conditions', domain2_init, 'Ka', domain2_Ka);
allExperiments.domain3 = struct('conditions', domain3_init, 'conv', domain3_conv);

% Iterate through domains sequentially (in reality, could be parallelized)
for domainIdx = 1:3
    fprintf('  ========== Domain %d: ', domainIdx);
    switch domainIdx
        case 1
            fprintf('%s ==========\n', chemDomain1.name);
            currentDomain = chemDomain1;
            XTrain = domain1_init;
            yTrain = domain1_yields;
        case 2
            fprintf('%s ==========\n', chemDomain2.name);
            currentDomain = chemDomain2;
            XTrain = domain2_init;
            yTrain = log10(domain2_Ka); % Log transform for GP stability
        case 3
            fprintf('%s ==========\n', chemDomain3.name);
            currentDomain = chemDomain3;
            XTrain = domain3_init;
            yTrain = domain3_conv;
    end
    
    for iter = 1:numIterations
        fprintf('    -- Iteration %d/%d --\n', iter, numIterations);
        
        % Step 3a: Train Gaussian Process surrogate model
        % Normalize continuous variables (categorical handled separately)
        numVars = length(currentDomain.variables);
        XNorm = XTrain;
        for v = 1:numVars
            if iscell(currentDomain.ranges{v})
                % Categorical: already encoded as integers, no normalization
            else
                % Continuous: z-score normalization
                minVal = currentDomain.ranges{v}(1);
                maxVal = currentDomain.ranges{v}(2);
                XNorm(:, v) = (XTrain(:, v) - minVal) / (maxVal - minVal);
            end
        end
        
        % Simple GP kernel: RBF for continuous, Hamming for categorical
        sigma0 = 5.0;  % Noise std
        sigmaF = 15.0; % Signal variance
        
        % Build kernel matrix (simplified, mixed continuous/categorical)
        n = size(XNorm, 1);
        K_train = zeros(n, n);
        for i = 1:n
            for j = i:n
                % Distance metric: Euclidean for continuous, Hamming for categorical
                dist = 0;
                for v = 1:numVars
                    if iscell(currentDomain.ranges{v})
                        % Categorical: 0 if same, 1 if different
                        dist = dist + (XNorm(i,v) ~= XNorm(j,v));
                    else
                        % Continuous: squared difference
                        dist = dist + (XNorm(i,v) - XNorm(j,v))^2;
                    end
                end
                K_train(i,j) = sigmaF^2 * exp(-0.5 * dist);
                K_train(j,i) = K_train(i,j);
            end
        end
        K_train = K_train + sigma0^2 * eye(n);
        
        % Cholesky decomposition
        L_train = chol(K_train, 'lower');
        alpha = L_train' \ (L_train \ yTrain);
        
        % Step 3b: Generate candidate experiments (grid search over discrete space)
        % For efficiency, sample 100 random candidates (in reality, would use constrained BO)
        numCandidates = 100;
        XCandidates = zeros(numCandidates, numVars);
        for v = 1:numVars
            if iscell(currentDomain.ranges{v})
                % Categorical: random choice
                XCandidates(:, v) = randi(length(currentDomain.ranges{v}), numCandidates, 1);
            else
                % Continuous: uniform random
                minVal = currentDomain.ranges{v}(1);
                maxVal = currentDomain.ranges{v}(2);
                XCandidates(:, v) = minVal + (maxVal - minVal) * rand(numCandidates, 1);
            end
        end
        
        % Predict for candidates
        XCandNorm = XCandidates;
        for v = 1:numVars
            if ~iscell(currentDomain.ranges{v})
                minVal = currentDomain.ranges{v}(1);
                maxVal = currentDomain.ranges{v}(2);
                XCandNorm(:, v) = (XCandidates(:, v) - minVal) / (maxVal - minVal);
            end
        end
        
        muPred = zeros(numCandidates, 1);
        sigmaPred = zeros(numCandidates, 1);
        for i = 1:numCandidates
            k_star = zeros(n, 1);
            for j = 1:n
                dist = 0;
                for v = 1:numVars
                    if iscell(currentDomain.ranges{v})
                        dist = dist + (XCandNorm(i,v) ~= XNorm(j,v));
                    else
                        dist = dist + (XCandNorm(i,v) - XNorm(j,v))^2;
                    end
                end
                k_star(j) = sigmaF^2 * exp(-0.5 * dist);
            end
            muPred(i) = k_star' * alpha;
            v_tmp = L_train \ k_star;
            sigmaPred(i) = sqrt(max(0, sigmaF^2 - v_tmp' * v_tmp + sigma0^2));
        end
        
        % Step 3c: Acquisition function (UCB)
        beta = 2.0 + 0.1 * iter;
        ucbScores = muPred + beta * sigmaPred;
        
        % Select top batchSize candidates
        [~, sortIdx] = sort(ucbScores, 'descend');
        selectedIdx = sortIdx(1:batchSize);
        XSelected = XCandidates(selectedIdx, :);
        
        fprintf('      AI selected %d experiments (UCB acquisition)\n', batchSize);
        
        % Step 3d: Robot executes experiments (simulated)
        % Workflow: Synthesis (30 min)   UPLC-MS (10 min)   NMR (15 min)   Decision (1 sec)
        execTimePerReaction = manipulationTime.pipette*5 + manipulationTime.transfer*2 + ...
                              manipulationTime.heat + analyticalTime.UPLC_MS + analyticalTime.NMR;
        totalExecTime = execTimePerReaction * batchSize / 60; % minutes (parallel synthesis assumed)
        
        fprintf('      Robot executing %d reactions (%.1f minutes)...\n', batchSize, totalExecTime);
        
        % Measure outcomes
        ySelected = zeros(batchSize, 1);
        for i = 1:batchSize
            switch domainIdx
                case 1
                    ySelected(i) = chemDomain1.yieldFn(XSelected(i,1), XSelected(i,2), ...
                                                       XSelected(i,3), XSelected(i,4), XSelected(i,5));
                case 2
                    Ka_tmp = chemDomain2.KaFn(XSelected(i,1), XSelected(i,2), XSelected(i,3), XSelected(i,4));
                    ySelected(i) = log10(Ka_tmp);
                case 3
                    ySelected(i) = chemDomain3.convFn(XSelected(i,1), XSelected(i,2), ...
                                                      XSelected(i,3), XSelected(i,4));
            end
        end
        
        fprintf('      Results: [%.1f, %.1f, %.1f] ', ySelected(1), ySelected(2), ySelected(3));
        if domainIdx == 2
            fprintf('(log10 scale)\n');
        else
            fprintf('\n');
        end
        
        % Step 3e: AI decision - Accept or reject (quality control)
        % Reject if predicted uncertainty too high (unreliable region)
        acceptFlag = sigmaPred(selectedIdx) < 20; % Accept if uncertainty < 20%
        numAccepted = sum(acceptFlag);
        
        if numAccepted < batchSize
            fprintf('      Warning: %d/%d experiments rejected (high uncertainty)\n', ...
                    batchSize - numAccepted, batchSize);
        end
        
        % Update training data with accepted experiments
        XTrain = [XTrain; XSelected(acceptFlag, :)];
        yTrain = [yTrain; ySelected(acceptFlag)];
        
        fprintf('      Best result so far: %.1f\n', max(yTrain));
        fprintf('\n');
    end
    
    % Store final results for this domain
    switch domainIdx
        case 1
            allExperiments.domain1.conditions = XTrain;
            allExperiments.domain1.yields = yTrain;
        case 2
            allExperiments.domain2.conditions = XTrain;
            allExperiments.domain2.Ka = yTrain; % Still in log10
        case 3
            allExperiments.domain3.conditions = XTrain;
            allExperiments.domain3.conv = yTrain;
    end
    
    fprintf('  ========== Domain %d Complete: %d experiments, Best = %.1f ==========\n\n', ...
            domainIdx, size(XTrain, 1), max(yTrain));
end

%% Step 4: Performance Analysis
fprintf('Step 4: Analyzing robot performance...\n\n');

% Domain 1: Suzuki coupling
[bestYield1, bestIdx1] = max(allExperiments.domain1.yields);
bestCond1 = allExperiments.domain1.conditions(bestIdx1, :);

fprintf('  Domain 1 (Suzuki Coupling):\n');
fprintf('    Total experiments: %d\n', size(allExperiments.domain1.conditions, 1));
fprintf('    Best yield: %.1f%%\n', bestYield1);
fprintf('    Optimal conditions: Pd=%.1f mol%%, Base=%s, Solvent=%s, Temp=%.0f C, Time=%.0fh\n', ...
        bestCond1(1), chemDomain1.baseNames{bestCond1(2)}, chemDomain1.solventNames{bestCond1(3)}, ...
        bestCond1(4), bestCond1(5));

% Domain 2: Host-guest
[bestKa2_log, bestIdx2] = max(allExperiments.domain2.Ka);
bestKa2 = 10^bestKa2_log;
bestCond2 = allExperiments.domain2.conditions(bestIdx2, :);

fprintf('\n  Domain 2 (Host-Guest Binding):\n');
fprintf('    Total experiments: %d\n', size(allExperiments.domain2.conditions, 1));
fprintf('    Best Ka: %.2e M^-1\n', bestKa2);
fprintf('    Optimal conditions: CD=%s, Conc=%.1f mM, pH=%.1f, Temp=%.0f C\n', ...
        chemDomain2.CDNames{bestCond2(1)}, bestCond2(2), bestCond2(3), bestCond2(4));

% Domain 3: Photochemistry
[bestConv3, bestIdx3] = max(allExperiments.domain3.conv);
bestCond3 = allExperiments.domain3.conditions(bestIdx3, :);

fprintf('\n  Domain 3 (Photochemistry):\n');
fprintf('    Total experiments: %d\n', size(allExperiments.domain3.conditions, 1));
fprintf('    Best conversion: %.1f%%\n', bestConv3);
fprintf('    Optimal conditions: Catalyst=%s, Intensity=%.0f mW/cm^2, Wavelength=%.0f nm, Solvent=%s\n\n', ...
        chemDomain3.catalystNames{bestCond3(1)}, bestCond3(2), bestCond3(3), chemDomain3.solventNames{bestCond3(4)});

%% Step 5: Compare with Human Chemist Baseline
fprintf('Step 5: Comparing with human chemist baseline...\n\n');

% Simulate human chemist: Random selection (no AI guidance)
humanExperiments = struct();

% Domain 1: Human random experiments (same number as robot)
numHumanExp1 = size(allExperiments.domain1.conditions, 1);
humanCond1 = zeros(numHumanExp1, 5);
for i = 1:numHumanExp1
    humanCond1(i, 1) = 1 + 4*rand(); % Pd: 1-5
    humanCond1(i, 2) = randi(3);     % Base: 1-3
    humanCond1(i, 3) = randi(3);     % Solvent: 1-3
    humanCond1(i, 4) = 80 + 40*rand(); % Temp: 80-120
    humanCond1(i, 5) = 2 + 22*rand();  % Time: 2-24
end
humanYield1 = arrayfun(@(i) chemDomain1.yieldFn(humanCond1(i,1), humanCond1(i,2), ...
                       humanCond1(i,3), humanCond1(i,4), humanCond1(i,5)), 1:numHumanExp1)';

% Domain 2: Human random
numHumanExp2 = size(allExperiments.domain2.conditions, 1);
humanCond2 = zeros(numHumanExp2, 4);
for i = 1:numHumanExp2
    humanCond2(i, 1) = randi(3);       % CD: 1-3
    humanCond2(i, 2) = 0.1 + 9.9*rand(); % Conc: 0.1-10
    humanCond2(i, 3) = 3 + 8*rand();     % pH: 3-11
    humanCond2(i, 4) = 20 + 30*rand();   % Temp: 20-50
end
humanKa2 = arrayfun(@(i) chemDomain2.KaFn(humanCond2(i,1), humanCond2(i,2), ...
                    humanCond2(i,3), humanCond2(i,4)), 1:numHumanExp2)';

% Domain 3: Human random
numHumanExp3 = size(allExperiments.domain3.conditions, 1);
humanCond3 = zeros(numHumanExp3, 4);
for i = 1:numHumanExp3
    humanCond3(i, 1) = randi(3);         % Catalyst: 1-3
    humanCond3(i, 2) = 10 + 90*rand();   % Intensity: 10-100
    humanCond3(i, 3) = 400 + 150*rand(); % Wavelength: 400-550
    humanCond3(i, 4) = randi(3);         % Solvent: 1-3
end
humanConv3 = arrayfun(@(i) chemDomain3.convFn(humanCond3(i,1), humanCond3(i,2), ...
                      humanCond3(i,3), humanCond3(i,4)), 1:numHumanExp3)';

fprintf('  Human Chemist (Random Sampling) Results:\n');
fprintf('    Domain 1: Best yield = %.1f%% (Robot: %.1f%%, +%.1f%%)\n', ...
        max(humanYield1), bestYield1, bestYield1 - max(humanYield1));
fprintf('    Domain 2: Best Ka = %.2e M^-1 (Robot: %.2e, %.1fx better)\n', ...
        max(humanKa2), bestKa2, bestKa2 / max(humanKa2));
fprintf('    Domain 3: Best conversion = %.1f%% (Robot: %.1f%%, +%.1f%%)\n\n', ...
        max(humanConv3), bestConv3, bestConv3 - max(humanConv3));

%% Step 6: Decision Speed Analysis
fprintf('Step 6: Analyzing AI decision speed...\n\n');

% Human decision time: ~2 hours to analyze data, plan next experiment
humanDecisionTime = 2 * 3600; % seconds

% Robot decision time: GP training + prediction + acquisition
robotDecisionTime = 0.5 + 0.1 + 0.01; % seconds (GP train, predict, acquisition)

fprintf('  Decision Time Comparison:\n');
fprintf('    Human chemist: %.1f hours/decision\n', humanDecisionTime / 3600);
fprintf('    Robot AI: %.2f seconds/decision\n', robotDecisionTime);
fprintf('    Speedup: %.0fx faster\n\n', humanDecisionTime / robotDecisionTime);

%% Step 7: Visualization
fprintf('Step 7: Visualizing results...\n\n');

figure('Name', 'Robot Chemist Performance', 'Position', [100, 100, 1400, 900]);

% Subplot 1: Domain 1 convergence
subplot(2, 3, 1);
plot(1:length(allExperiments.domain1.yields), cummax(allExperiments.domain1.yields), '-o', ...
     'LineWidth', 2, 'MarkerSize', 6, 'Color', [0.2, 0.6, 0.8], 'DisplayName', 'Robot (BO)');
hold on;
plot(1:length(humanYield1), cummax(humanYield1), '-s', 'LineWidth', 2, 'MarkerSize', 6, ...
     'Color', [0.9, 0.4, 0.2], 'DisplayName', 'Human (Random)');
hold off;
xlabel('Experiment Number', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Best Yield (\%)', 'Interpreter', 'latex', 'FontSize', 12);
title('Domain 1: Suzuki Coupling', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'southeast');
grid on;

% Subplot 2: Domain 2 convergence
subplot(2, 3, 2);
plot(1:length(allExperiments.domain2.Ka), 10.^cummax(allExperiments.domain2.Ka), '-o', ...
     'LineWidth', 2, 'MarkerSize', 6, 'Color', [0.2, 0.6, 0.8], 'DisplayName', 'Robot (BO)');
hold on;
plot(1:length(humanKa2), cummax(humanKa2), '-s', 'LineWidth', 2, 'MarkerSize', 6, ...
     'Color', [0.9, 0.4, 0.2], 'DisplayName', 'Human (Random)');
hold off;
xlabel('Experiment Number', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Best Ka (M$^{-1}$)', 'Interpreter', 'latex', 'FontSize', 12);
title('Domain 2: Host-Guest Binding', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'southeast');
grid on;
set(gca, 'YScale', 'log');

% Subplot 3: Domain 3 convergence
subplot(2, 3, 3);
plot(1:length(allExperiments.domain3.conv), cummax(allExperiments.domain3.conv), '-o', ...
     'LineWidth', 2, 'MarkerSize', 6, 'Color', [0.2, 0.6, 0.8], 'DisplayName', 'Robot (BO)');
hold on;
plot(1:length(humanConv3), cummax(humanConv3), '-s', 'LineWidth', 2, 'MarkerSize', 6, ...
     'Color', [0.9, 0.4, 0.2], 'DisplayName', 'Human (Random)');
hold off;
xlabel('Experiment Number', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Best Conversion (\%)', 'Interpreter', 'latex', 'FontSize', 12);
title('Domain 3: Photochemistry', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'southeast');
grid on;

% Subplot 4: Pd loading vs. Yield (Domain 1)
subplot(2, 3, 4);
scatter(allExperiments.domain1.conditions(:, 1), allExperiments.domain1.yields, 80, ...
        allExperiments.domain1.yields, 'filled', 'MarkerEdgeColor', 'k');
colormap('hot');
colorbar;
xlabel('Pd Loading (mol\%)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Yield (\%)', 'Interpreter', 'latex', 'FontSize', 12);
title('Domain 1: Pd Loading Effect', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Subplot 5: Light intensity vs. Conversion (Domain 3)
subplot(2, 3, 5);
scatter(allExperiments.domain3.conditions(:, 2), allExperiments.domain3.conv, 80, ...
        allExperiments.domain3.conv, 'filled', 'MarkerEdgeColor', 'k');
colormap('hot');
colorbar;
xlabel('Light Intensity (mW/cm$^2$)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Conversion (\%)', 'Interpreter', 'latex', 'FontSize', 12);
title('Domain 3: Light Intensity Effect', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Subplot 6: Decision time comparison
subplot(2, 3, 6);
barData = [humanDecisionTime/3600, robotDecisionTime/3600];
bar(barData, 'FaceColor', [0.5, 0.7, 0.9], 'EdgeColor', 'k', 'LineWidth', 1.5);
set(gca, 'YScale', 'log');
set(gca, 'XTickLabel', {'Human', 'Robot AI'});
ylabel('Decision Time (hours)', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Decision Speed (%.0fx Faster)', humanDecisionTime/robotDecisionTime), ...
      'Interpreter', 'latex', 'FontSize', 13);
grid on;

saveas(gcf, 'Problem13_RobotChemist.fig');
saveas(gcf, 'Problem13_RobotChemist.eps', 'epsc');
saveas(gcf, 'Problem13_RobotChemist.jpg');

fprintf('  Visualization saved\n\n');

%% Summary
fprintf('========================================\n');
fprintf('Problem 13 Complete: Summary\n');
fprintf('========================================\n\n');

fprintf('Robot Performance:\n');
fprintf('  Domain 1 (Suzuki): %.1f%% yield (%.1f%% better than human random)\n', ...
        bestYield1, bestYield1 - max(humanYield1));
fprintf('  Domain 2 (Host-Guest): %.2e M^-1 Ka (%.1fx better than human)\n', ...
        bestKa2, bestKa2 / max(humanKa2));
fprintf('  Domain 3 (Photochem): %.1f%% conversion (%.1f%% better than human)\n\n', ...
        bestConv3, bestConv3 - max(humanConv3));

fprintf('Efficiency Metrics:\n');
fprintf('  Total experiments: %d (across 3 domains)\n', ...
        size(allExperiments.domain1.conditions, 1) + ...
        size(allExperiments.domain2.conditions, 1) + ...
        size(allExperiments.domain3.conditions, 1));
fprintf('  Average experiments to 90%% optimum: %.1f\n', ...
        (find(cummax(allExperiments.domain1.yields) > 0.9*bestYield1, 1) + ...
         find(10.^cummax(allExperiments.domain2.Ka) > 0.9*bestKa2, 1) + ...
         find(cummax(allExperiments.domain3.conv) > 0.9*bestConv3, 1)) / 3);
fprintf('  Decision speed: %.0fx faster than human (%.1f sec vs. %.1f hours)\n\n', ...
        humanDecisionTime/robotDecisionTime, robotDecisionTime, humanDecisionTime/3600);

fprintf('Key Insights:\n');
fprintf('  - AI-guided robot outperforms random sampling in all 3 domains\n');
fprintf('  - Bayesian optimization enables sample-efficient exploration\n');
fprintf('  - Decision-making speed: seconds (robot) vs. hours (human)\n');
fprintf('  - Multi-domain capability: Single platform handles diverse chemistry\n\n');

fprintf('Figures saved:\n');
fprintf('  - Problem13_RobotChemist (.fig, .eps, .jpg)\n\n');

fprintf('========================================\n');
