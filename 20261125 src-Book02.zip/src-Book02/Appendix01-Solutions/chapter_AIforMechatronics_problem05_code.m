%% chapter_AIforMechatronics_problem05_code.m
% Q-learning convergence analysis for path planning.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem05_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 5: Q-Learning Convergence Analysis for Path Planning
% Author: Dr Yi Chen
% Purpose: Analyse Q-learning convergence for mobile robot path planning
% MATLAB Version: R2023b or later
% Required Toolboxes: Reinforcement Learning Toolbox
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Define grid environment
fprintf('=== Q-Learning Convergence Analysis ===\n\n');
fprintf('Step 1: Defining grid environment...\n');

% Environment parameters
gridSize = [10, 10];
startPosition = [1, 1];
goalPosition = [10, 10];

% Define obstacles
obstaclePositions = [
    3, 3; 3, 4; 3, 5; 3, 6;
    5, 2; 5, 3; 5, 4;
    7, 6; 7, 7; 7, 8; 7, 9;
    2, 8; 3, 8; 4, 8];

% Create grid environment
environment = zeros(gridSize);
environment(goalPosition(1), goalPosition(2)) = 1; % Goal

for obstIdx = 1:size(obstaclePositions, 1)
    environment(obstaclePositions(obstIdx, 1), ...
        obstaclePositions(obstIdx, 2)) = -1; % Obstacles
end

fprintf('  Grid size: %dx%d\n', gridSize);
fprintf('  Start position: [%d, %d]\n', startPosition);
fprintf('  Goal position: [%d, %d]\n', goalPosition);
fprintf('  Number of obstacles: %d\n', size(obstaclePositions, 1));

%% Step 2: Define action space and reward structure
fprintf('\nStep 2: Defining action space and rewards...\n');

% Actions: 1=Up, 2=Down, 3=Left, 4=Right
numActions = 4;
actionNames = {'Up', 'Down', 'Left', 'Right'};

% Reward structure
rewardGoal = 100;
rewardObstacle = -100;
rewardStep = -1;
rewardOutOfBounds = -50;

fprintf('  Number of actions: %d\n', numActions);
fprintf('  Reward - Goal: %d\n', rewardGoal);
fprintf('  Reward - Obstacle: %d\n', rewardObstacle);
fprintf('  Reward - Step: %d\n', rewardStep);

%% Step 3: Implement Q-learning algorithm
fprintf('\nStep 3: Implementing Q-learning...\n');

% Q-learning hyperparameters (default configuration)
alphaDefault = 0.5; % Learning rate
gammaDefault = 0.95; % Discount factor
epsilonDefault = 0.2; % Exploration rate
numEpisodes = 500;
maxStepsPerEpisode = 100;

fprintf('  Default learning rate (alpha): %.2f\n', alphaDefault);
fprintf('  Default discount factor (gamma): %.2f\n', gammaDefault);
fprintf('  Default exploration rate (epsilon): %.2f\n', epsilonDefault);
fprintf('  Number of episodes: %d\n', numEpisodes);

%% Step 4: Run Q-learning with default parameters
fprintf('\nStep 4: Training with default parameters...\n');

[QTableDefault, episodeReturnsDefault, tdErrorsDefault] = ...
    runQLearning(environment, startPosition, goalPosition, ...
    numActions, alphaDefault, gammaDefault, epsilonDefault, ...
    numEpisodes, maxStepsPerEpisode, rewardGoal, rewardObstacle, ...
    rewardStep, rewardOutOfBounds);

fprintf('  Training completed\n');
fprintf('  Final average return (last 100 episodes): %.2f\n', ...
    mean(episodeReturnsDefault(end-99:end)));

%% Step 5: Hyperparameter sensitivity analysis - Learning Rate
fprintf('\nStep 5: Analysing learning rate sensitivity...\n');

alphaValues = [0.1, 0.3, 0.5, 0.7, 0.9];
returnsVsAlpha = zeros(numEpisodes, length(alphaValues));

for alphaIdx = 1:length(alphaValues)
    fprintf('  Training with alpha = %.2f...\n', alphaValues(alphaIdx));
    [~, episodeReturns, ~] = runQLearning(environment, startPosition, ...
        goalPosition, numActions, alphaValues(alphaIdx), gammaDefault, ...
        epsilonDefault, numEpisodes, maxStepsPerEpisode, rewardGoal, ...
        rewardObstacle, rewardStep, rewardOutOfBounds);
    returnsVsAlpha(:, alphaIdx) = episodeReturns;
end

fprintf('  Learning rate analysis completed\n');

%% Step 6: Hyperparameter sensitivity analysis - Discount Factor
fprintf('\nStep 6: Analysing discount factor sensitivity...\n');

gammaValues = [0.8, 0.9, 0.95, 0.99];
returnsVsGamma = zeros(numEpisodes, length(gammaValues));

for gammaIdx = 1:length(gammaValues)
    fprintf('  Training with gamma = %.2f...\n', gammaValues(gammaIdx));
    [~, episodeReturns, ~] = runQLearning(environment, startPosition, ...
        goalPosition, numActions, alphaDefault, gammaValues(gammaIdx), ...
        epsilonDefault, numEpisodes, maxStepsPerEpisode, rewardGoal, ...
        rewardObstacle, rewardStep, rewardOutOfBounds);
    returnsVsGamma(:, gammaIdx) = episodeReturns;
end

fprintf('  Discount factor analysis completed\n');

%% Step 7: Hyperparameter sensitivity analysis - Exploration Rate
fprintf('\nStep 7: Analysing exploration rate sensitivity...\n');

epsilonValues = [0.05, 0.1, 0.2, 0.3, 0.5];
returnsVsEpsilon = zeros(numEpisodes, length(epsilonValues));

for epsIdx = 1:length(epsilonValues)
    fprintf('  Training with epsilon = %.2f...\n', epsilonValues(epsIdx));
    [~, episodeReturns, ~] = runQLearning(environment, startPosition, ...
        goalPosition, numActions, alphaDefault, gammaDefault, ...
        epsilonValues(epsIdx), numEpisodes, maxStepsPerEpisode, ...
        rewardGoal, rewardObstacle, rewardStep, rewardOutOfBounds);
    returnsVsEpsilon(:, epsIdx) = episodeReturns;
end

fprintf('  Exploration rate analysis completed\n');

%% Step 8: Extract and visualise learned policy
fprintf('\nStep 8: Extracting learned policy...\n');

% Extract greedy policy from Q-table
policy = zeros(gridSize);
for row = 1:gridSize(1)
    for col = 1:gridSize(2)
        stateIdx = (row - 1) * gridSize(2) + col;
        [~, bestAction] = max(QTableDefault(stateIdx, :));
        policy(row, col) = bestAction;
    end
end

% Simulate trajectory using learned policy
currentPosition = startPosition;
trajectory = [currentPosition];
episodeFinished = false;
stepCount = 0;

while ~episodeFinished && stepCount < maxStepsPerEpisode
    stateIdx = (currentPosition(1) - 1) * gridSize(2) + currentPosition(2);
    action = policy(currentPosition(1), currentPosition(2));
    
    % Take action
    nextPosition = takeAction(currentPosition, action, gridSize);
    trajectory = [trajectory; nextPosition];
    
    % Check termination
    if isequal(nextPosition, goalPosition)
        episodeFinished = true;
    elseif environment(nextPosition(1), nextPosition(2)) == -1
        episodeFinished = true; % Hit obstacle
    end
    
    currentPosition = nextPosition;
    stepCount = stepCount + 1;
end

fprintf('  Learned policy extracted\n');
fprintf('  Trajectory length: %d steps\n', size(trajectory, 1));

%% Step 9: Performance analysis
fprintf('\nStep 9: Computing performance metrics...\n');

% Convergence episode (when average return stabilises)
windowSize = 50;
movingAvgReturns = movmean(episodeReturnsDefault, windowSize);
convergenceThreshold = 0.95 * movingAvgReturns(end);

convergenceEpisode = find(movingAvgReturns >= convergenceThreshold, 1);
if isempty(convergenceEpisode)
    convergenceEpisode = numEpisodes;
end

fprintf('  Convergence episode: %d\n', convergenceEpisode);
fprintf('  Final policy path length: %d steps\n', size(trajectory, 1) - 1);
fprintf('  Final average return: %.2f\n', mean(episodeReturnsDefault(end-99:end)));

%% Step 10: Visualisation
fprintf('\nStep 10: Generating visualisations...\n');

% Learning curves for different learning rates
figure('Name', 'Q-Learning Convergence Analysis', ...
    'Position', [100, 100, 1400, 1000]);

subplot(3, 3, 1);
hold on;
for alphaIdx = 1:length(alphaValues)
    smoothReturns = movmean(returnsVsAlpha(:, alphaIdx), windowSize);
    plot(smoothReturns, 'LineWidth', 1.5, ...
        'DisplayName', sprintf('$\\alpha=%.1f$', alphaValues(alphaIdx)));
end
xlabel('Episode', 'Interpreter', 'latex');
ylabel('Return (Moving Average)', 'Interpreter', 'latex');
title('Learning Rate Sensitivity', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'southeast');
grid on;
hold off;

% Learning curves for different discount factors
subplot(3, 3, 2);
hold on;
for gammaIdx = 1:length(gammaValues)
    smoothReturns = movmean(returnsVsGamma(:, gammaIdx), windowSize);
    plot(smoothReturns, 'LineWidth', 1.5, ...
        'DisplayName', sprintf('$\\gamma=%.2f$', gammaValues(gammaIdx)));
end
xlabel('Episode', 'Interpreter', 'latex');
ylabel('Return (Moving Average)', 'Interpreter', 'latex');
title('Discount Factor Sensitivity', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'southeast');
grid on;
hold off;

% Learning curves for different exploration rates
subplot(3, 3, 3);
hold on;
for epsIdx = 1:length(epsilonValues)
    smoothReturns = movmean(returnsVsEpsilon(:, epsIdx), windowSize);
    plot(smoothReturns, 'LineWidth', 1.5, ...
        'DisplayName', sprintf('$\\epsilon=%.2f$', epsilonValues(epsIdx)));
end
xlabel('Episode', 'Interpreter', 'latex');
ylabel('Return (Moving Average)', 'Interpreter', 'latex');
title('Exploration Rate Sensitivity', 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'Location', 'southeast');
grid on;
hold off;

% Environment and learned policy
subplot(3, 3, 4);
imagesc(environment');
colormap(gca, [1 0 0; 1 1 1; 0 1 0]); % Red=obstacle, White=free, Green=goal
hold on;

% Draw policy arrows
[X, Y] = meshgrid(1:gridSize(2), 1:gridSize(1));
U = zeros(gridSize);
V = zeros(gridSize);

for row = 1:gridSize(1)
    for col = 1:gridSize(2)
        if environment(row, col) == 0 % Free space
            action = policy(row, col);
            switch action
                case 1 % Up
                    V(row, col) = -0.3;
                case 2 % Down
                    V(row, col) = 0.3;
                case 3 % Left
                    U(row, col) = -0.3;
                case 4 % Right
                    U(row, col) = 0.3;
            end
        end
    end
end

quiver(X, Y, U, V, 'k', 'LineWidth', 1.5, 'MaxHeadSize', 0.5);
plot(startPosition(2), startPosition(1), 'bo', 'MarkerSize', 12, ...
    'MarkerFaceColor', 'b');
hold off;
axis equal tight;
xlabel('X Position', 'Interpreter', 'latex');
ylabel('Y Position', 'Interpreter', 'latex');
title('Environment and Learned Policy', 'Interpreter', 'latex');

% Learned trajectory
subplot(3, 3, 5);
imagesc(environment');
colormap(gca, [1 0 0; 1 1 1; 0 1 0]);
hold on;
plot(trajectory(:, 2), trajectory(:, 1), 'b-o', 'LineWidth', 2, ...
    'MarkerSize', 6, 'MarkerFaceColor', 'b');
plot(startPosition(2), startPosition(1), 'go', 'MarkerSize', 12, ...
    'MarkerFaceColor', 'g');
plot(goalPosition(2), goalPosition(1), 'ro', 'MarkerSize', 12, ...
    'MarkerFaceColor', 'r');
hold off;
axis equal tight;
xlabel('X Position', 'Interpreter', 'latex');
ylabel('Y Position', 'Interpreter', 'latex');
title('Learned Trajectory', 'Interpreter', 'latex');

% TD error convergence
subplot(3, 3, 6);
smoothTDErrors = movmean(tdErrorsDefault, windowSize);
plot(smoothTDErrors, 'r-', 'LineWidth', 1.5);
xlabel('Episode', 'Interpreter', 'latex');
ylabel('TD Error (Moving Average)', 'Interpreter', 'latex');
title('Temporal Difference Error Convergence', 'Interpreter', 'latex');
grid on;

% Final performance comparison
subplot(3, 3, 7);
finalReturnsAlpha = mean(returnsVsAlpha(end-99:end, :), 1);
bar(finalReturnsAlpha);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('%.1f', x), ...
    alphaValues, 'UniformOutput', false));
xlabel('Learning Rate ($\alpha$)', 'Interpreter', 'latex');
ylabel('Final Average Return', 'Interpreter', 'latex');
title('Final Performance vs Learning Rate', 'Interpreter', 'latex');
grid on;

subplot(3, 3, 8);
finalReturnsGamma = mean(returnsVsGamma(end-99:end, :), 1);
bar(finalReturnsGamma);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('%.2f', x), ...
    gammaValues, 'UniformOutput', false));
xlabel('Discount Factor ($\gamma$)', 'Interpreter', 'latex');
ylabel('Final Average Return', 'Interpreter', 'latex');
title('Final Performance vs Discount Factor', 'Interpreter', 'latex');
grid on;

subplot(3, 3, 9);
finalReturnsEpsilon = mean(returnsVsEpsilon(end-99:end, :), 1);
bar(finalReturnsEpsilon);
set(gca, 'XTickLabel', arrayfun(@(x) sprintf('%.2f', x), ...
    epsilonValues, 'UniformOutput', false));
xlabel('Exploration Rate ($\epsilon$)', 'Interpreter', 'latex');
ylabel('Final Average Return', 'Interpreter', 'latex');
title('Final Performance vs Exploration Rate', 'Interpreter', 'latex');
grid on;

suptitle('Q-Learning Hyperparameter Analysis', ...
    'Interpreter', 'latex', 'FontSize', 14);

fprintf('\nProblem 5 completed successfully.\n');

%% Helper Functions

function [QTable, episodeReturns, tdErrors] = runQLearning(environment, ...
    startPosition, goalPosition, numActions, alpha, gamma, epsilon, ...
    numEpisodes, maxSteps, rewardGoal, rewardObstacle, rewardStep, ...
    rewardOutOfBounds)
    % Q-learning training loop
    
    gridSize = size(environment);
    numStates = gridSize(1) * gridSize(2);
    QTable = zeros(numStates, numActions);
    episodeReturns = zeros(numEpisodes, 1);
    tdErrors = zeros(numEpisodes, 1);
    
    for episode = 1:numEpisodes
        currentPosition = startPosition;
        episodeReturn = 0;
        episodeTDError = 0;
        stepCount = 0;
        episodeFinished = false;
        
        while ~episodeFinished && stepCount < maxSteps
            % Get current state index
            stateIdx = (currentPosition(1) - 1) * gridSize(2) + currentPosition(2);
            
            % Epsilon-greedy action selection
            if rand() < epsilon
                action = randi(numActions); % Explore
            else
                [~, action] = max(QTable(stateIdx, :)); % Exploit
            end
            
            % Take action
            nextPosition = takeAction(currentPosition, action, gridSize);
            
            % Compute reward
            if isequal(nextPosition, goalPosition)
                reward = rewardGoal;
                episodeFinished = true;
            elseif nextPosition(1) < 1 || nextPosition(1) > gridSize(1) || ...
                   nextPosition(2) < 1 || nextPosition(2) > gridSize(2)
                reward = rewardOutOfBounds;
                nextPosition = currentPosition; % Stay in place
            elseif environment(nextPosition(1), nextPosition(2)) == -1
                reward = rewardObstacle;
                episodeFinished = true;
            else
                reward = rewardStep;
            end
            
            % Get next state index
            nextStateIdx = (nextPosition(1) - 1) * gridSize(2) + nextPosition(2);
            
            % Q-learning update
            oldQValue = QTable(stateIdx, action);
            maxNextQ = max(QTable(nextStateIdx, :));
            newQValue = oldQValue + alpha * (reward + gamma * maxNextQ - oldQValue);
            QTable(stateIdx, action) = newQValue;
            
            % Track TD error
            tdError = abs(reward + gamma * maxNextQ - oldQValue);
            episodeTDError = episodeTDError + tdError;
            
            % Update position and return
            currentPosition = nextPosition;
            episodeReturn = episodeReturn + reward;
            stepCount = stepCount + 1;
        end
        
        episodeReturns(episode) = episodeReturn;
        tdErrors(episode) = episodeTDError / stepCount;
    end
end

function nextPosition = takeAction(currentPosition, action, gridSize)
    % Execute action and return next position
    nextPosition = currentPosition;
    
    switch action
        case 1 % Up
            nextPosition(1) = currentPosition(1) - 1;
        case 2 % Down
            nextPosition(1) = currentPosition(1) + 1;
        case 3 % Left
            nextPosition(2) = currentPosition(2) - 1;
        case 4 % Right
            nextPosition(2) = currentPosition(2) + 1;
    end
    
    % Boundary checking
    nextPosition(1) = max(1, min(gridSize(1), nextPosition(1)));
    nextPosition(2) = max(1, min(gridSize(2), nextPosition(2)));
end
