%% chapter_FundamentalMaths_example_LinearProgramming.m
% Linear programming resource allocation example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_LinearProgramming
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter06_CalculusOptimisation_Example04.m
% Author: Dr Leo Chen
% Date: June 5, 2025
% MATLAB Version: R2025a
% Description: Linear programming for manufacturing resource allocation.

function resourceAllocationOptimisation()
    fprintf('Linear Programming Resource Allocation\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Problem: Maximise profit from producing two products
    % Product A: Profit = £40/unit, requires 2*h labour, 1*h machine, 1 unit material
    % Product B: Profit = £30/unit, requires 1*h labour, 2*h machine, 1 unit material
    % Available: 100*h labour, 80*h machine time, 60 units material
    
    fprintf('Manufacturing Resource Allocation Problem\n');
    fprintf('Products: A and B\n');
    fprintf('Profit per unit: A = £40, B = £30\n');
    fprintf('Resources: Labour (100*h), Machine (80*h), Materials (60 units)\n\n');
    
    % Define objective function coefficients (negative for maximisation)
    objectiveCoefficients = [-40; -30]; % Profit per unit for products A and B
    
    % Define inequality constraint matrix and bounds
    % Constraints: Labour hours, Machine hours, Raw materials
    constraintMatrix = [2, 1;    % Labour constraint
                       1, 2;     % Machine constraint  
                       1, 1];    % Material constraint
    
    constraintBounds = [100; 80; 60]; % Available resources
    
    % Define variable bounds
    lowerBounds = [0; 0]; % Non-negativity constraints
    upperBounds = [Inf; Inf];
    
    % Display problem formulation
    fprintf('Mathematical Formulation:\n');
    fprintf('Maximise: 40*x1 + 30*x2\n');
    fprintf('Subject to:\n');
    fprintf('  2*x1 + x2 <= 100  (labour)\n');
    fprintf('  x1 + 2*x2 <= 80   (machine)\n');
    fprintf('  x1 + x2 <= 60    (material)\n');
    fprintf('  x1, x2 >= 0\n\n');
    
    % Solve linear programming problem
    options = optimoptions('linprog', 'Display', 'iter', 'Algorithm', 'interior-point');
    [optimalSolution, optimalValue, exitFlag, output] = ...
        linprog(objectiveCoefficients, constraintMatrix, constraintBounds, ...
                [], [], lowerBounds, upperBounds, options);
    
    % Display results
    fprintf('\n%s\n', repmat('=', 1, 70));
    if exitFlag == 1
        fprintf('Optimal Solution Found\n');
        fprintf('Product A Quantity: %.2f units\n', optimalSolution(1));
        fprintf('Product B Quantity: %.2f units\n', optimalSolution(2));
        fprintf('Maximum Profit: £%.2f\n', -optimalValue);
        fprintf('Iterations: %d\n\n', output.iterations);
        
        % Resource utilisation
        resourceUsage = constraintMatrix * optimalSolution;
        fprintf('Resource Utilisation:\n');
        fprintf('  Labour: %.2f / 100 hours (%.1f%%)\n', ...
                resourceUsage(1), 100*resourceUsage(1)/100);
        fprintf('  Machine: %.2f / 80 hours (%.1f%%)\n', ...
                resourceUsage(2), 100*resourceUsage(2)/80);
        fprintf('  Materials: %.2f / 60 units (%.1f%%)\n\n', ...
                resourceUsage(3), 100*resourceUsage(3)/60);
        
        % Identify binding constraints
        slack = constraintBounds - resourceUsage;
        fprintf('Slack Analysis (unused resources):\n');
        constraintNames = {'Labour', 'Machine', 'Materials'};
        for k = 1:length(slack)
            if abs(slack(k)) < 1e-6
                fprintf('  %s: %.6f (BINDING CONSTRAINT)\n', ...
                        constraintNames{k}, slack(k));
            else
                fprintf('  %s: %.6f\n', constraintNames{k}, slack(k));
            end
        end
        fprintf('\n');
        
        % Visualise feasible region and optimal solution
        createFeasibilityPlot(constraintMatrix, constraintBounds, ...
                             optimalSolution, objectiveCoefficients);
    else
        fprintf('Optimisation failed with exit flag: %d\n', exitFlag);
    end
end

function createFeasibilityPlot(A, b, optimalPoint, c)
    % Create visualisation of feasible region
    figure('Position', [100, 100, 800, 600]);
    hold on;
    
    % Define plotting range
    xRange = 0:0.1:70;
    
    % Plot constraint lines
    constraintLabels = {'Labour Constraint', 'Machine Constraint', 'Material Constraint'};
    colours = ['r', 'g', 'b'];
    
    for constraintIndex = 1:size(A, 1)
        yConstraint = (b(constraintIndex) - A(constraintIndex, 1) * xRange) / A(constraintIndex, 2);
        plot(xRange, yConstraint, colours(constraintIndex), 'LineWidth', 2, ...
             'DisplayName', constraintLabels{constraintIndex});
    end
    
    % Identify feasible region vertices
    % For this simple problem, check intersections
    vertices = [0, 0;
                0, min(b(2)/A(2,2), b(3)/A(3,2));
                min(b(1)/A(1,1), b(3)/A(3,1)), 0];
    
    % Add constraint intersection points
    % Labour and Machine intersection
    Aint = [A(1,:); A(2,:)];
    bint = [b(1); b(2)];
    if rank(Aint) == 2
        xint = Aint \ bint;
        if all(xint >= 0) && all(A*xint <= b + 1e-6)
            vertices = [vertices; xint'];
        end
    end
    
    % Labour and Material intersection
    Aint = [A(1,:); A(3,:)];
    bint = [b(1); b(3)];
    if rank(Aint) == 2
        xint = Aint \ bint;
        if all(xint >= 0) && all(A*xint <= b + 1e-6)
            vertices = [vertices; xint'];
        end
    end
    
    % Machine and Material intersection
    Aint = [A(2,:); A(3,:)];
    bint = [b(2); b(3)];
    if rank(Aint) == 2
        xint = Aint \ bint;
        if all(xint >= 0) && all(A*xint <= b + 1e-6)
            vertices = [vertices; xint'];
        end
    end
    
    % Remove duplicates
    vertices = unique(vertices, 'rows');
    
    % Plot feasible region
    if size(vertices, 1) >= 3
        k = convhull(vertices(:,1), vertices(:,2));
        fill(vertices(k,1), vertices(k,2), 'cyan', 'FaceAlpha', 0.3, ...
             'EdgeColor', 'none', 'DisplayName', 'Feasible Region');
    end
    
    % Plot optimal point
    plot(optimalPoint(1), optimalPoint(2), 'ko', 'MarkerSize', 12, ...
         'MarkerFaceColor', 'yellow', 'LineWidth', 2, ...
         'DisplayName', 'Optimal Solution');
    
    % Plot iso-profit lines
    profitLevels = linspace(0, -c'*optimalPoint, 5);
    for profitLevel = profitLevels
        yProfit = (profitLevel - c(1)*xRange) / c(2);
        plot(xRange, yProfit, 'k--', 'LineWidth', 0.5, 'HandleVisibility', 'off');
    end
    
    % Configure plot appearance
    xlabel('Product A Quantity (units)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Product B Quantity (units)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Linear Programming Feasible Region and Optimal Solution', ...
          'Interpreter', 'latex', 'FontSize', 13);
    legend('Location', 'best', 'Interpreter', 'latex', 'FontSize', 10);
    grid on;
    axis([0 70 0 70]);
    set(gca, 'FontSize', 11);
end
