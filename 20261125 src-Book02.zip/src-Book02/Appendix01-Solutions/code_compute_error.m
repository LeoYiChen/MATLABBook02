%% code_compute_error.m
% Error computation function.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:compute_error
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function errors = computeEigenvalueError(lambda_approx, lambda_ref)
    % Compute relative errors in eigenvalues
    % Input:
    %   lambda_approx - Approximate eigenvalues
    %   lambda_ref - Reference eigenvalues
    % Output:
    %   errors - Relative errors
    
    % Match eigenvalues (they may be in different orders)
    n = length(lambda_ref);
    errors = zeros(n, 1);
    
    for i = 1:n
        % Find closest reference eigenvalue
        [~, idx] = min(abs(lambda_ref - lambda_approx(i)));
        
        % Compute relative error
        errors(i) = abs(lambda_approx(i) - lambda_ref(idx)) / ...
            abs(lambda_ref(idx));
    end
end
