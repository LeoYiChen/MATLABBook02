%% Appendix02-FAQs_code_071.m
% Euler’s Formula for Complex-Valued AI Signal Analysis
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Visualise Euler's formula on the unit circle (complex plane)
theta = linspace(0, 2*pi, 1000); % Angles from 0 to 2뿯ν
euler = exp(1i * theta); % Euler's formula (1i = imaginary unit in MATLAB)

% Extract sin/cos components (real = cos뿯ν, imaginary = sin뿯ν)
cos_vals = real(euler);
sin_vals = imag(euler);

% Plot unit circle + sin/cos projections
figure;
plot(cos_vals, sin_vals, 'b'); % Unit circle
hold on;
plot(cos_vals, zeros(size(cos_vals)), 'r--', 'DisplayName', 'Cos뿯ν (Real Axis)');
plot(zeros(size(sin_vals)), sin_vals, 'g--', 'DisplayName', 'Sin뿯ν (Imaginary Axis)');
axis equal; % Ensure circle is not distorted
title('Euler’s Formula: Unit Circle (Trigonometry + Complex Numbers)');
xlabel('Real Part (cos뿯ν)'); ylabel('Imaginary Part (sin뿯ν)');
legend;
grid on;
