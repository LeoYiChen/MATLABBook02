%% chapter_DataVisualisation_area.m
% Area Chart Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_area
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
t = linspace(0, 2*pi, 100);
y1 = sin(t);
y2 = cos(t);

figure('Position', [100 100 800 600]);
area(t, [y1' y2']);
xlabel('Time');
ylabel('Amplitude');
title('Temporal Analysis');
legend('Signal 1', 'Signal 2');
grid on;

% Export figure in multiple formats
exportFigure(gca, 'Area_plot');

