%% prob13_shoelace_syntax.m
% Shoelace Formula syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob13_shoelace_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
x = [x1, x2, x3, ..., xn, x1]; % Close polygon
y = [y1, y2, y3, ..., yn, y1];
area = 0.5 * abs(sum(x(1:end-1) .* y(2:end) - x(2:end) .* y(1:end-1)));
