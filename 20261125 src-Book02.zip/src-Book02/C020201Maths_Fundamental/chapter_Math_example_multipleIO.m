%% chapter_Math_example_multipleIO.m
% Function with multiple inputs and outputs.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_multipleIO
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [quotient, remainder] = divideWithRemainder(dividend, divisor)
    % DIVIDEWITHREMAINDER Perform division and return quotient and remainder
    %   [q, r] = divideWithRemainder(a, b) returns quotient q and 
    %   remainder r such that a = b*q + r
    
    % Calculate quotient (integer division)
    quotient = floor(dividend / divisor);
    
    % Calculate remainder
    remainder = dividend - quotient * divisor;
    
    % Alternatively, could use: remainder = mod(dividend, divisor);
end
