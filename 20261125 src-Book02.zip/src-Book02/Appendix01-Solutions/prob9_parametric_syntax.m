%% prob9_parametric_syntax.m
% Parametric curve plotting syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob9_parametric_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Parametric curve in Cartesian coordinates
t = linspace(0, 2*pi, 1000);
x = f(t);  y = g(t);
plot(x, y);

% Parametric curve in polar coordinates
theta = linspace(0, 2*pi, 1000);
r = f(theta);
polarplot(theta, r);
