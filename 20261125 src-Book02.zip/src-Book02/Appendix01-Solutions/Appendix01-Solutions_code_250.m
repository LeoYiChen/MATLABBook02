%% Appendix01-Solutions_code_250.m
% Deep Deterministic Policy Gradient for Pendulum Swing-Up
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Deep Deterministic Policy Gradient (DDPG)
% Problem 17: Continuous Control for Inverted Pendulum Swing-Up
% Author: Control Systems Course
% Description: Complete DDPG implementation from scratch
% Requires: Deep Learning Toolbox, Reinforcement Learning Toolbox

clear all; close all; clc;
rng(42);  % For reproducibility

fprintf('=== Deep Deterministic Policy Gradient (DDPG) ===\n\n');

%% Environment: Inverted Pendulum

% Physical parameters
env_params = struct();
env_params.m = 0.2;        % Mass (kg)
env_params.l = 0.5;        % Length to COM (m)
env_params.J = env_params.m * env_params.l^2 / 3;  % Inertia (rod)
env_params.g = 9.81;       % Gravity (m/s^2)
env_params.b = 0.01;       % Damping (N m s)
env_params.dt = 0.05;      % Time step (s)
env_params.u_max = 2.0;    % Max torque (N m)
env_params.omega_max = 8*pi;  % Max angular velocity (rad/s)

fprintf('Inverted Pendulum Parameters:\n');
fprintf('  Mass m: %.2f kg\n', env_params.m);
fprintf('  Length l: %.2f m\n', env_params.l);
fprintf('  Inertia J: %.4f kg m\n', env_params.J);
fprintf('  Max torque: %.1f N m\n', env_params.u_max);
fprintf('  Control frequency: %.0f Hz\n\n', 1/env_params.dt);

%% DDPG Hyperparameters

params = struct();

% Network architecture
params.state_dim = 3;       % [cos(theta), sin(theta), omega_norm]
params.action_dim = 1;      % [torque]
params.actor_hidden = [400, 300];
params.critic_hidden = [400, 300];

% Learning rates
params.lr_actor = 1e-4;
params.lr_critic = 1e-3;

% Training
params.gamma = 0.99;        % Discount factor
params.tau = 0.001;         % Target network soft update rate
params.buffer_size = 1e6;   % Replay buffer size
params.batch_size = 128;    % Minibatch size
params.num_episodes = 500;  % Training episodes
params.max_steps = 200;     % Max steps per episode

% Exploration (Ornstein-Uhlenbeck noise)
params.ou_theta = 0.15;     % Mean reversion rate
params.ou_sigma = 0.2;      % Volatility
params.noise_decay = 0.995; % Decay rate per episode

% Other
params.warmup_episodes = 10;  % Random action episodes
params.update_freq = 1;       % Updates per step

fprintf('DDPG Hyperparameters:\n');
fprintf('  Actor learning rate: %.0e\n', params.lr_actor);
fprintf('  Critic learning rate: %.0e\n', params.lr_critic);
fprintf('  Discount factor  : %.2f\n', params.gamma);
fprintf('  Soft update rate  : %.4f\n', params.tau);
fprintf('  Batch size: %d\n', params.batch_size);
fprintf('  Episodes: %d\n', params.num_episodes);
fprintf('  Buffer size: %.0e\n\n', params.buffer_size);

%% Define Environment Functions

% Dynamics function
function [theta_next, omega_next] = pendulum_dynamics(theta, omega, u, env_params)
    % Saturate control
    u = max(-env_params.u_max, min(env_params.u_max, u));
    
    % Compute angular acceleration
    alpha = (u - env_params.m*env_params.g*env_params.l*sin(theta) - env_params.b*omega) / ...
            (env_params.J + env_params.m*env_params.l^2);
    
    % Euler integration
    omega_next = omega + alpha * env_params.dt;
    theta_next = theta + omega_next * env_params.dt;
    
    % Normalize angle to [-pi, pi]
    theta_next = mod(theta_next + pi, 2*pi) - pi;
    
    % Limit angular velocity
    omega_next = max(-env_params.omega_max, min(env_params.omega_max, omega_next));
end

% State representation
function s = get_state(theta, omega, env_params)
    s = [cos(theta); sin(theta); omega/env_params.omega_max];
end

% Reward function
function r = get_reward(theta, omega, u, env_params)
    r_angle = cos(theta);  % Reward for being upright
    r_velocity = -0.1 * (omega/env_params.omega_max)^2;  % Penalty for velocity
    r_action = -0.01 * (u/env_params.u_max)^2;  % Penalty for control effort
    r = r_angle + r_velocity + r_action;
end

% Reset environment
function [theta, omega] = reset_env()
    theta = (rand() - 0.5) * 0.2;  % Near hanging down
    omega = 0;
end

%% Build Neural Networks

fprintf('Building neural networks...\n');

% Actor Network: s -> a
% Input: state (3), Output: action (1), bounded by tanh
actor_layers = [
    featureInputLayer(params.state_dim, 'Normalization', 'none', 'Name', 'state')
    fullyConnectedLayer(params.actor_hidden(1), 'Name', 'fc1')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(params.actor_hidden(2), 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    fullyConnectedLayer(params.action_dim, 'Name', 'fc3')
    tanhLayer('Name', 'tanh')
    scalingLayer('Name', 'action_scaling', 'Scale', env_params.u_max)
];

actor_net = layerGraph(actor_layers);

% Critic Network: [s, a] -> Q(s,a)
% State pathway
state_path = [
    featureInputLayer(params.state_dim, 'Normalization', 'none', 'Name', 'state')
    fullyConnectedLayer(params.critic_hidden(1), 'Name', 'state_fc1')
];

% Action pathway
action_path = [
    featureInputLayer(params.action_dim, 'Normalization', 'none', 'Name', 'action')
];

% Combined pathway
combined_path = [
    concatenationLayer(1, 2, 'Name', 'concat')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(params.critic_hidden(2), 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    fullyConnectedLayer(1, 'Name', 'q_value')
];

critic_net = layerGraph();
critic_net = addLayers(critic_net, state_path);
critic_net = addLayers(critic_net, action_path);
critic_net = addLayers(critic_net, combined_path);
critic_net = connectLayers(critic_net, 'state_fc1', 'concat/in1');
critic_net = connectLayers(critic_net, 'action', 'concat/in2');

fprintf('  Actor: %d-%d-%d-%d\n', params.state_dim, params.actor_hidden(1), ...
        params.actor_hidden(2), params.action_dim);
fprintf('  Critic: [%d,%d]-%d-%d-1\n\n', params.state_dim, params.action_dim, ...
        params.critic_hidden(1), params.critic_hidden(2));

%% Initialize Networks and Optimizers

% Create dlnetwork objects
actor = dlnetwork(actor_net);
critic = dlnetwork(critic_net);

% Target networks (copy of main networks)
actor_target = actor;
critic_target = critic;

% Initialize optimizers (Adam)
actor_avg_grad = [];
actor_avg_grad_sq = [];
critic_avg_grad = [];
critic_avg_grad_sq = [];

fprintf('Networks initialized.\n');
fprintf('  Actor parameters: %d\n', numel(actor.Learnables.Value));
fprintf('  Critic parameters: %d\n\n', numel(critic.Learnables.Value));

%% Experience Replay Buffer

buffer = struct();
buffer.states = zeros(params.state_dim, params.buffer_size);
buffer.actions = zeros(params.action_dim, params.buffer_size);
buffer.rewards = zeros(1, params.buffer_size);
buffer.next_states = zeros(params.state_dim, params.buffer_size);
buffer.dones = zeros(1, params.buffer_size);
buffer.count = 0;
buffer.position = 1;

% Add experience to buffer
function buffer = add_experience(buffer, s, a, r, s_next, done, params)
    idx = buffer.position;
    buffer.states(:, idx) = s;
    buffer.actions(:, idx) = a;
    buffer.rewards(idx) = r;
    buffer.next_states(:, idx) = s_next;
    buffer.dones(idx) = done;
    
    buffer.count = min(buffer.count + 1, params.buffer_size);
    buffer.position = mod(buffer.position, params.buffer_size) + 1;
end

% Sample minibatch
function [s_batch, a_batch, r_batch, s_next_batch, done_batch] = ...
         sample_batch(buffer, batch_size)
    indices = randperm(buffer.count, batch_size);
    s_batch = buffer.states(:, indices);
    a_batch = buffer.actions(:, indices);
    r_batch = buffer.rewards(indices);
    s_next_batch = buffer.next_states(:, indices);
    done_batch = buffer.dones(indices);
end

%% Ornstein-Uhlenbeck Noise Process

ou_state = 0;
ou_sigma = params.ou_sigma;

function [noise, ou_state] = ou_noise(ou_state, ou_theta, ou_sigma, dt)
    % OU process: dx = theta*(mu - x)*dt + sigma*dW
    mu = 0;
    noise = ou_state + ou_theta*(mu - ou_state)*dt + ou_sigma*sqrt(dt)*randn();
    ou_state = noise;
end

%% Training Loop

fprintf('=== Training DDPG ===\n\n');

% Metrics
episode_returns = zeros(params.num_episodes, 1);
episode_lengths = zeros(params.num_episodes, 1);
actor_losses = [];
critic_losses = [];
success_rate = zeros(params.num_episodes, 1);

% Training progress
tic;

for episode = 1:params.num_episodes
    % Reset environment
    [theta, omega] = reset_env();
    s = get_state(theta, omega, env_params);
    
    % Reset OU noise
    ou_state = 0;
    
    % Episode metrics
    episode_return = 0;
    episode_length = 0;
    upright_steps = 0;  % For success tracking
    
    for step = 1:params.max_steps
        % Select action
        if episode <= params.warmup_episodes
            % Random exploration
            a = (rand() - 0.5) * 2 * env_params.u_max;
        else
            % Policy with exploration noise
            s_dl = dlarray(s, 'CB');
            a_mean = extractdata(predict(actor, s_dl));
            a_mean = a_mean(1);
            
            % Add OU noise
            [noise, ou_state] = ou_noise(ou_state, params.ou_theta, ou_sigma, env_params.dt);
            a = a_mean + noise * env_params.u_max;
            a = max(-env_params.u_max, min(env_params.u_max, a));
        end
        
        % Execute action
        [theta_next, omega_next] = pendulum_dynamics(theta, omega, a, env_params);
        s_next = get_state(theta_next, omega_next, env_params);
        r = get_reward(theta_next, omega_next, a, env_params);
        
        % Check if upright and balanced
        if abs(theta_next - pi) < 0.1 && abs(omega_next) < 0.5
            upright_steps = upright_steps + 1;
        else
            upright_steps = 0;
        end
        
        % Store transition
        done = (step == params.max_steps);
        buffer = add_experience(buffer, s, a, r, s_next, done, params);
        
        % Update state
        s = s_next;
        theta = theta_next;
        omega = omega_next;
        episode_return = episode_return + r;
        episode_length = episode_length + 1;
        
        % Train networks
        if buffer.count >= params.batch_size && episode > params.warmup_episodes
            for update = 1:params.update_freq
                % Sample minibatch
                [s_b, a_b, r_b, s_next_b, done_b] = sample_batch(buffer, params.batch_size);
                
                % Convert to dlarray
                s_b = dlarray(s_b, 'CB');
                a_b = dlarray(a_b, 'CB');
                r_b = dlarray(r_b, 'CB');
                s_next_b = dlarray(s_next_b, 'CB');
                done_b = dlarray(done_b, 'CB');
                
                %% Critic Update
                
                % Compute target Q-values
                a_next = predict(actor_target, s_next_b);
                q_next = predict(critic_target, s_next_b, a_next);
                q_target = r_b + params.gamma * (1 - done_b) .* q_next;
                
                % Compute critic loss and gradients
                [critic_loss, critic_grads] = dlfeval(@critic_loss_fn, critic, s_b, a_b, q_target);
                
                % Update critic
                [critic, critic_avg_grad, critic_avg_grad_sq] = ...
                    adamupdate(critic, critic_grads, critic_avg_grad, critic_avg_grad_sq, ...
                              episode*params.max_steps + step, params.lr_critic);
                
                critic_losses(end+1) = extractdata(critic_loss);
                
                %% Actor Update
                
                % Compute actor loss and gradients
                [actor_loss, actor_grads] = dlfeval(@actor_loss_fn, actor, critic, s_b);
                
                % Update actor
                [actor, actor_avg_grad, actor_avg_grad_sq] = ...
                    adamupdate(actor, actor_grads, actor_avg_grad, actor_avg_grad_sq, ...
                              episode*params.max_steps + step, params.lr_actor);
                
                actor_losses(end+1) = extractdata(actor_loss);
                
                %% Soft Update Target Networks
                
                % Update target actor
                actor_target = soft_update(actor, actor_target, params.tau);
                
                % Update target critic
                critic_target = soft_update(critic, critic_target, params.tau);
            end
        end
        
        if done
            break;
        end
    end
    
    % Record metrics
    episode_returns(episode) = episode_return;
    episode_lengths(episode) = episode_length;
    success_rate(episode) = (upright_steps >= 40);  % 2 seconds at 50 Hz
    
    % Decay exploration noise
    ou_sigma = ou_sigma * params.noise_decay;
    
    % Print progress
    if mod(episode, 10) == 0
        avg_return = mean(episode_returns(max(1,episode-9):episode));
        avg_success = mean(success_rate(max(1,episode-9):episode));
        fprintf('Episode %d/%d | Avg Return: %.2f | Success Rate: %.2f | Noise: %.3f\n', ...
                episode, params.num_episodes, avg_return, avg_success, ou_sigma);
    end
end

training_time = toc;

fprintf('\nTraining completed in %.1f seconds (%.1f min)\n', training_time, training_time/60);
fprintf('Final average return (last 100 episodes): %.2f\n', mean(episode_returns(end-99:end)));
fprintf('Final success rate (last 100 episodes): %.2f%%\n\n', mean(success_rate(end-99:end))*100);

%% Loss Functions

function [loss, grads] = critic_loss_fn(critic, states, actions, targets)
    % Forward pass
    q_pred = predict(critic, states, actions);
    
    % MSE loss
    loss = mean((q_pred - targets).^2);
    
    % Compute gradients
    grads = dlgradient(loss, critic.Learnables);
end

function [loss, grads] = actor_loss_fn(actor, critic, states)
    % Forward pass through actor
    actions = predict(actor, states);
    
    % Forward pass through critic
    q_values = predict(critic, states, actions);
    
    % Loss is negative mean Q-value (maximize Q)
    loss = -mean(q_values);
    
    % Compute gradients w.r.t. actor parameters
    grads = dlgradient(loss, actor.Learnables);
end

%% Soft Update Function

function target_net = soft_update(net, target_net, tau)
    % Soft update: target = tau * net + (1-tau) * target
    for i = 1:height(net.Learnables)
        target_net.Learnables.Value{i} = ...
            tau * net.Learnables.Value{i} + (1-tau) * target_net.Learnables.Value{i};
    end
end

%% Evaluation

fprintf('=== Evaluating Trained Policy ===\n\n');

num_eval_episodes = 10;
eval_returns = zeros(num_eval_episodes, 1);
eval_trajectories = cell(num_eval_episodes, 1);

for ep = 1:num_eval_episodes
    [theta, omega] = reset_env();
    s = get_state(theta, omega, env_params);
    
    trajectory = struct();
    trajectory.theta = zeros(params.max_steps, 1);
    trajectory.omega = zeros(params.max_steps, 1);
    trajectory.action = zeros(params.max_steps, 1);
    trajectory.reward = zeros(params.max_steps, 1);
    
    episode_return = 0;
    
    for step = 1:params.max_steps
        % Select action (no noise)
        s_dl = dlarray(s, 'CB');
        a = extractdata(predict(actor, s_dl));
        a = a(1);
        
        % Execute
        [theta_next, omega_next] = pendulum_dynamics(theta, omega, a, env_params);
        s_next = get_state(theta_next, omega_next, env_params);
        r = get_reward(theta_next, omega_next, a, env_params);
        
        % Record
        trajectory.theta(step) = theta_next;
        trajectory.omega(step) = omega_next;
        trajectory.action(step) = a;
        trajectory.reward(step) = r;
        
        s = s_next;
        theta = theta_next;
        omega = omega_next;
        episode_return = episode_return + r;
    end
    
    eval_returns(ep) = episode_return;
    eval_trajectories{ep} = trajectory;
    
    fprintf('Evaluation episode %d: Return = %.2f\n', ep, episode_return);
end

fprintf('\nEvaluation Results:\n');
fprintf('  Mean return: %.2f   %.2f\n', mean(eval_returns), std(eval_returns));
fprintf('  Max return: %.2f\n', max(eval_returns));
fprintf('  Min return: %.2f\n\n', min(eval_returns));

%% Visualization

fprintf('Generating visualizations...\n');

% Training curves
figure('Position', [100, 100, 1400, 800]);

subplot(2,3,1);
plot(episode_returns, 'LineWidth', 1.5);
hold on;
plot(movmean(episode_returns, 20), 'r', 'LineWidth', 2);
grid on;
xlabel('Episode');
ylabel('Return');
title('Episode Returns');
legend('Raw', '20-episode MA', 'Location', 'southeast');

subplot(2,3,2);
plot(100*movmean(success_rate, 20), 'LineWidth', 2);
grid on;
xlabel('Episode');
ylabel('Success Rate (%)');
title('Success Rate (20-episode MA)');
ylim([0, 100]);

subplot(2,3,3);
if ~isempty(critic_losses)
    plot(movmean(critic_losses, 100), 'LineWidth', 1.5);
    grid on;
    xlabel('Update Step');
    ylabel('Critic Loss');
    title('Critic Loss (100-step MA)');
end

subplot(2,3,4);
if ~isempty(actor_losses)
    plot(movmean(actor_losses, 100), 'LineWidth', 1.5);
    grid on;
    xlabel('Update Step');
    ylabel('Actor Loss');
    title('Actor Loss (100-step MA)');
end

subplot(2,3,5);
histogram(episode_returns(end-99:end), 20);
grid on;
xlabel('Return');
ylabel('Count');
title('Return Distribution (Last 100 Episodes)');

subplot(2,3,6);
plot(cumsum(episode_lengths) * env_params.dt / 60, episode_returns, 'LineWidth', 1.5);
grid on;
xlabel('Training Time (minutes)');
ylabel('Episode Return');
title('Learning Progress');

sgtitle('DDPG Training Results', 'FontSize', 14, 'FontWeight', 'bold');

% Best trajectory visualization
[~, best_idx] = max(eval_returns);
best_traj = eval_trajectories{best_idx};

figure('Position', [100, 100, 1400, 600]);

t_eval = (0:params.max_steps-1) * env_params.dt;

subplot(2,3,1);
plot(t_eval, best_traj.theta, 'LineWidth', 2);
hold on;
yline(pi, 'r-', 'LineWidth', 1.5);
yline(pi-0.1, 'g:', 'LineWidth', 1);
yline(pi+0.1, 'g:', 'LineWidth', 1);
grid on;
xlabel('Time (s)');
ylabel('Angle (rad)');
title('Pendulum Angle');
legend('\theta', 'Target (\pi)', 'Success bounds', 'Location', 'best');

subplot(2,3,2);
plot(t_eval, best_traj.omega, 'LineWidth', 2);
hold on;
yline(0.5, 'g:', 'LineWidth', 1);
yline(-0.5, 'g:', 'LineWidth', 1);
grid on;
xlabel('Time (s)');
ylabel('Angular Velocity (rad/s)');
title('Angular Velocity');
legend('\omega', 'Success bounds', 'Location', 'best');

subplot(2,3,3);
plot(t_eval, best_traj.action, 'LineWidth', 2);
hold on;
yline(env_params.u_max, 'r-', 'LineWidth', 1);
yline(-env_params.u_max, 'r-', 'LineWidth', 1);
grid on;
xlabel('Time (s)');
ylabel('Torque (N m)');
title('Control Action');
legend('u', 'Limits', 'Location', 'best');

subplot(2,3,4);
plot(t_eval, best_traj.reward, 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Reward');
title('Instantaneous Reward');

subplot(2,3,5);
plot(t_eval, cumsum(best_traj.reward), 'LineWidth', 2);
grid on;
xlabel('Time (s)');
ylabel('Cumulative Reward');
title(sprintf('Cumulative Reward (Total: %.1f)', sum(best_traj.reward)));

% Phase portrait
subplot(2,3,6);
plot(best_traj.theta, best_traj.omega, 'LineWidth', 2);
hold on;
plot(best_traj.theta(1), best_traj.omega(1), 'go', 'MarkerSize', 12, 'LineWidth', 2);
plot(best_traj.theta(end), best_traj.omega(end), 'r^', 'MarkerSize', 12, 'LineWidth', 2);
plot(pi, 0, 'kx', 'MarkerSize', 15, 'LineWidth', 3);
grid on;
xlabel('Angle (rad)');
ylabel('Angular Velocity (rad/s)');
title('Phase Portrait');
legend('Trajectory', 'Start', 'End', 'Goal', 'Location', 'best');

sgtitle('Best Evaluation Episode', 'FontSize', 14, 'FontWeight', 'bold');

%% Animation

fprintf('Creating animation...\n');

fig_anim = figure('Position', [100, 100, 800, 800]);
best_traj = eval_trajectories{best_idx};

% Animation settings
anim_skip = 2;  % Show every 2nd frame
L = env_params.l;

for i = 1:anim_skip:params.max_steps
    clf;
    
    theta_i = best_traj.theta(i);
    
    % Pendulum position
    x = L * sin(theta_i);
    y = -L * cos(theta_i);
    
    % Draw
    subplot('Position', [0.1, 0.3, 0.8, 0.6]);
    hold on;
    
    % Pendulum rod
    plot([0, x], [0, y], 'b-', 'LineWidth', 4);
    
    % Pivot
    plot(0, 0, 'ko', 'MarkerSize', 15, 'LineWidth', 3, 'MarkerFaceColor', 'k');
    
    % Bob
    plot(x, y, 'ro', 'MarkerSize', 25, 'LineWidth', 3, 'MarkerFaceColor', 'r');
    
    % Reference line (upward)
    plot([0, 0], [0, L], 'g-', 'LineWidth', 2);
    
    axis equal;
    xlim([-L*1.2, L*1.2]);
    ylim([-L*1.2, L*1.2]);
    grid on;
    title(sprintf('Time: %.2f s | Angle: %.2f rad | Action: %.2f N m', ...
          t_eval(i), theta_i, best_traj.action(i)));
    
    % Control signal
    subplot('Position', [0.1, 0.05, 0.8, 0.15]);
    plot(t_eval(1:i), best_traj.action(1:i), 'b-', 'LineWidth', 2);
    hold on;
    plot(t_eval(i), best_traj.action(i), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    grid on;
    xlabel('Time (s)');
    ylabel('Torque (N m)');
    xlim([0, params.max_steps*env_params.dt]);
    ylim([-env_params.u_max*1.1, env_params.u_max*1.1]);
    
    drawnow;
    pause(env_params.dt);
end

fprintf('\nAll visualizations complete!\n');

%% Summary

fprintf('\n=== DDPG Summary ===\n\n');
fprintf('Training Statistics:\n');
fprintf('  Total episodes: %d\n', params.num_episodes);
fprintf('  Training time: %.1f minutes\n', training_time/60);
fprintf('  Final average return: %.2f\n', mean(episode_returns(end-99:end)));
fprintf('  Final success rate: %.1f%%\n\n', mean(success_rate(end-99:end))*100);

fprintf('Network Statistics:\n');
fprintf('  Actor parameters: %d\n', numel(actor.Learnables.Value));
fprintf('  Critic parameters: %d\n', numel(critic.Learnables.Value));
fprintf('  Replay buffer size: %d transitions\n\n', buffer.count);

fprintf('Evaluation Statistics:\n');
fprintf('  Mean return: %.2f   %.2f\n', mean(eval_returns), std(eval_returns));
fprintf('  Success episodes: %d/%d\n\n', sum(eval_returns > 180), num_eval_episodes);

fprintf('Key Observations:\n');
fprintf('   DDPG successfully learned continuous control policy\n');
fprintf('   Policy swings up and balances pendulum at unstable equilibrium\n');
fprintf('   Exploration noise (OU process) crucial for learning\n');
fprintf('   Target networks improve training stability\n');
fprintf('   Experience replay enables sample-efficient learning\n\n');
