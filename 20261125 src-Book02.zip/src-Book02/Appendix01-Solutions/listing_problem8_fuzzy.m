%% listing_problem8_fuzzy.m
% Problem 8: Fuzzy logic control for inverted pendulum on cart, including custom fuzzy inference engine, membership function design, rule base, comparison with LQR, and robustness analysis under parameter variations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem8_fuzzy
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 8 - Fuzzy Logic Control
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: Fuzzy logic control for inverted pendulum on cart.
%              Implements Mamdani inference, custom membership functions,
%              and compares against LQR controller.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 8: Fuzzy Logic Control for Inverted Pendulum\n');
fprintf('==================================================================\n\n');

%% System Parameters
fprintf('=== Inverted Pendulum Parameters ===\n');

sys.M = 1.0;        % Cart mass (kg)
sys.m = 0.3;        % Pendulum mass (kg)
sys.l = 0.5;        % Pendulum length to center of mass (m)
sys.g = 9.81;       % Gravity (m/s)
sys.b = 0.1;        % Cart friction (N s/m)
sys.mu = 0.01;      % Pendulum friction (N m s/rad)

fprintf('Cart mass M = %.2f kg\n', sys.M);
fprintf('Pendulum mass m = %.2f kg\n', sys.m);
fprintf('Pendulum length l = %.2f m\n', sys.l);
fprintf('Friction coefficients: b = %.3f,   = %.4f\n\n', sys.b, sys.mu);

%% Fuzzy Logic Controller Design
fprintf('=== Fuzzy Logic Controller Design ===\n');

% Input/output universes of discourse
fuzzy.theta_range = [-pi/6, pi/6];      %  30 degrees
fuzzy.theta_dot_range = [-2, 2];        %  2 rad/s
fuzzy.F_range = [-100, 100];            %  100 N

fprintf('Input ranges:\n');
fprintf('   : [%.2f, %.2f] rad ( %.1f deg)\n', ...
    fuzzy.theta_range(1), fuzzy.theta_range(2), rad2deg(fuzzy.theta_range(2)));
fprintf('  d /dt: [%.2f, %.2f] rad/s\n', ...
    fuzzy.theta_dot_range(1), fuzzy.theta_dot_range(2));
fprintf('Output range:\n');
fprintf('  F: [%.1f, %.1f] N\n\n', fuzzy.F_range(1), fuzzy.F_range(2));

% Discretization for inference
fuzzy.theta_disc = linspace(fuzzy.theta_range(1), fuzzy.theta_range(2), 201);
fuzzy.theta_dot_disc = linspace(fuzzy.theta_dot_range(1), fuzzy.theta_dot_range(2), 201);
fuzzy.F_disc = linspace(fuzzy.F_range(1), fuzzy.F_range(2), 201);

% Define membership functions for   (angle)
% Labels: NB, NM, NS, ZE, PS, PM, PB
fprintf('Defining membership functions...\n');

fuzzy.mf_theta.NB = @(x) trimf(x, [-pi/6, -pi/6, -pi/12]);
fuzzy.mf_theta.NM = @(x) trimf(x, [-pi/6, -pi/12, -pi/24]);
fuzzy.mf_theta.NS = @(x) trimf(x, [-pi/12, -pi/24, 0]);
fuzzy.mf_theta.ZE = @(x) trimf(x, [-pi/24, 0, pi/24]);
fuzzy.mf_theta.PS = @(x) trimf(x, [0, pi/24, pi/12]);
fuzzy.mf_theta.PM = @(x) trimf(x, [pi/24, pi/12, pi/6]);
fuzzy.mf_theta.PB = @(x) trimf(x, [pi/12, pi/6, pi/6]);

% Define membership functions for d /dt (angular velocity)
% Labels: NF, NM, NS, ZE, PS, PM, PF
fuzzy.mf_theta_dot.NF = @(x) trimf(x, [-2, -2, -1]);
fuzzy.mf_theta_dot.NM = @(x) trimf(x, [-2, -1, -0.5]);
fuzzy.mf_theta_dot.NS = @(x) trimf(x, [-1, -0.5, 0]);
fuzzy.mf_theta_dot.ZE = @(x) trimf(x, [-0.5, 0, 0.5]);
fuzzy.mf_theta_dot.PS = @(x) trimf(x, [0, 0.5, 1]);
fuzzy.mf_theta_dot.PM = @(x) trimf(x, [0.5, 1, 2]);
fuzzy.mf_theta_dot.PF = @(x) trimf(x, [1, 2, 2]);

% Define membership functions for F (control force)
% Labels: NVB, NB, NM, NS, ZE, PS, PM, PB, PVB
fuzzy.mf_F.NVB = @(x) trimf(x, [-100, -100, -75]);
fuzzy.mf_F.NB = @(x) trimf(x, [-100, -75, -50]);
fuzzy.mf_F.NM = @(x) trimf(x, [-75, -50, -25]);
fuzzy.mf_F.NS = @(x) trimf(x, [-50, -25, 0]);
fuzzy.mf_F.ZE = @(x) trimf(x, [-25, 0, 25]);
fuzzy.mf_F.PS = @(x) trimf(x, [0, 25, 50]);
fuzzy.mf_F.PM = @(x) trimf(x, [25, 50, 75]);
fuzzy.mf_F.PB = @(x) trimf(x, [50, 75, 100]);
fuzzy.mf_F.PVB = @(x) trimf(x, [75, 100, 100]);

fprintf('   : 7 fuzzy sets (NB, NM, NS, ZE, PS, PM, PB)\n');
fprintf('  d /dt: 7 fuzzy sets (NF, NM, NS, ZE, PS, PM, PF)\n');
fprintf('  F: 9 fuzzy sets (NVB, NB, NM, NS, ZE, PS, PM, PB, PVB)\n\n');

% Fuzzy rule base (7x7 = 49 rules)
fprintf('Building fuzzy rule base (49 rules)...\n');

fuzzy.rules = {
    %   = NB
    'NB', 'NF', 'NVB';
    'NB', 'NM', 'NVB';
    'NB', 'NS', 'NB';
    'NB', 'ZE', 'NB';
    'NB', 'PS', 'NM';
    'NB', 'PM', 'NS';
    'NB', 'PF', 'ZE';
    %   = NM
    'NM', 'NF', 'NVB';
    'NM', 'NM', 'NB';
    'NM', 'NS', 'NB';
    'NM', 'ZE', 'NM';
    'NM', 'PS', 'NS';
    'NM', 'PM', 'ZE';
    'NM', 'PF', 'PS';
    %   = NS
    'NS', 'NF', 'NB';
    'NS', 'NM', 'NB';
    'NS', 'NS', 'NM';
    'NS', 'ZE', 'NS';
    'NS', 'PS', 'ZE';
    'NS', 'PM', 'PS';
    'NS', 'PF', 'PM';
    %   = ZE
    'ZE', 'NF', 'NB';
    'ZE', 'NM', 'NM';
    'ZE', 'NS', 'NS';
    'ZE', 'ZE', 'ZE';
    'ZE', 'PS', 'PS';
    'ZE', 'PM', 'PM';
    'ZE', 'PF', 'PB';
    %   = PS
    'PS', 'NF', 'NM';
    'PS', 'NM', 'NS';
    'PS', 'NS', 'ZE';
    'PS', 'ZE', 'PS';
    'PS', 'PS', 'PM';
    'PS', 'PM', 'PB';
    'PS', 'PF', 'PB';
    %   = PM
    'PM', 'NF', 'NS';
    'PM', 'NM', 'ZE';
    'PM', 'NS', 'PS';
    'PM', 'ZE', 'PM';
    'PM', 'PS', 'PB';
    'PM', 'PM', 'PB';
    'PM', 'PF', 'PVB';
    %   = PB
    'PB', 'NF', 'ZE';
    'PB', 'NM', 'PS';
    'PB', 'NS', 'PM';
    'PB', 'ZE', 'PB';
    'PB', 'PS', 'PB';
    'PB', 'PM', 'PVB';
    'PB', 'PF', 'PVB';
};

fprintf('  Total rules: %d\n\n', size(fuzzy.rules, 1));

%% LQR Controller for Comparison
fprintf('=== LQR Controller Design (for comparison) ===\n');

% Linearized state-space model around   = 0
% State: x = [x; theta; x_dot; theta_dot]
% Input: u = F

p = sys.m / (sys.M + sys.m);
A = [0, 0, 1, 0;
     0, 0, 0, 1;
     0, -p*sys.m*sys.g/sys.M, -sys.b/sys.M, 0;
     0, (sys.M+sys.m)*sys.g/(sys.M*sys.l), sys.b/(sys.M*sys.l), 0];

B = [0; 0; 1/sys.M; -1/(sys.M*sys.l)];

% LQR weights
Q = diag([100, 1000, 1, 100]);  % Penalize position and angle errors heavily
R = 1;                          % Control effort

[K_lqr, ~, ~] = lqr(A, B, Q, R);

fprintf('LQR state feedback gain K:\n');
fprintf('  K = [%.2f, %.2f, %.2f, %.2f]\n', K_lqr(1), K_lqr(2), K_lqr(3), K_lqr(4));
fprintf('\n');

%% Simulation Setup
Tsim = 10;          % Simulation time (s)
dt = 0.01;          % Time step (s)
t = 0:dt:Tsim;
Nt = length(t);

fprintf('=== Simulation Parameters ===\n');
fprintf('Duration: %.1f s\n', Tsim);
fprintf('Time step: %.3f s\n', dt);
fprintf('Samples: %d\n\n', Nt);

%% Initial Conditions Scenarios
fprintf('=== Test Scenarios ===\n');

scenarios(1).name = 'Small perturbation';
scenarios(1).x0 = [0; deg2rad(5); 0; 0];    % 5 deg initial angle

scenarios(2).name = 'Large angle';
scenarios(2).x0 = [0; deg2rad(20); 0; 0];   % 20 deg initial angle

scenarios(3).name = 'Initial velocity';
scenarios(3).x0 = [0; deg2rad(10); 0; 1];   % 10 deg + 1 rad/s

scenarios(4).name = 'Cart displacement';
scenarios(4).x0 = [0.5; deg2rad(8); 0; 0];  % 0.5 m + 8 deg

for i = 1:length(scenarios)
    fprintf('Scenario %d: %s\n', i, scenarios(i).name);
    fprintf('  x0 = [%.2f, %.2f deg, %.2f, %.2f]\n', ...
        scenarios(i).x0(1), rad2deg(scenarios(i).x0(2)), ...
        scenarios(i).x0(3), scenarios(i).x0(4));
end
fprintf('\n');

%% Run Simulations
results_fuzzy = cell(length(scenarios), 1);
results_lqr = cell(length(scenarios), 1);

for scen = 1:length(scenarios)
    fprintf('=== Running Scenario %d: %s ===\n', scen, scenarios(scen).name);
    
    x0 = scenarios(scen).x0;
    
    % Fuzzy control simulation
    fprintf('  Simulating Fuzzy Control...\n');
    [t_fz, x_fz, F_fz] = simulate_fuzzy(t, x0, sys, fuzzy);
    
    results_fuzzy{scen}.t = t_fz;
    results_fuzzy{scen}.x = x_fz;
    results_fuzzy{scen}.F = F_fz;
    
    % LQR simulation
    fprintf('  Simulating LQR...\n');
    [t_lqr, x_lqr, F_lqr] = simulate_lqr(t, x0, sys, K_lqr);
    
    results_lqr{scen}.t = t_lqr;
    results_lqr{scen}.x = x_lqr;
    results_lqr{scen}.F = F_lqr;
    
    % Performance metrics
    theta_rms_fz = sqrt(mean(x_fz(:,2).^2));
    theta_rms_lqr = sqrt(mean(x_lqr(:,2).^2));
    
    F_max_fz = max(abs(F_fz));
    F_max_lqr = max(abs(F_lqr));
    
    fprintf('  Performance:\n');
    fprintf('    Fuzzy - RMS angle: %.3f deg, Max force: %.2f N\n', ...
        rad2deg(theta_rms_fz), F_max_fz);
    fprintf('    LQR   - RMS angle: %.3f deg, Max force: %.2f N\n\n', ...
        rad2deg(theta_rms_lqr), F_max_lqr);
end

%% Plot Results - Scenario 2 (Large angle)
fprintf('=== Generating Plots ===\n');

scen = 2;

figure('Position', [50, 50, 1400, 900]);

% Cart position
subplot(3,3,1);
plot(results_fuzzy{scen}.t, results_fuzzy{scen}.x(:,1), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fuzzy');
hold on;
plot(results_lqr{scen}.t, results_lqr{scen}.x(:,1), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'LQR');
grid on;
ylabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
title('Cart Position', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Pendulum angle
subplot(3,3,2);
plot(results_fuzzy{scen}.t, rad2deg(results_fuzzy{scen}.x(:,2)), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fuzzy');
hold on;
plot(results_lqr{scen}.t, rad2deg(results_lqr{scen}.x(:,2)), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'LQR');
yline(0, 'k:', 'LineWidth', 1);
grid on;
ylabel('$\theta$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
title('Pendulum Angle', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Cart velocity
subplot(3,3,3);
plot(results_fuzzy{scen}.t, results_fuzzy{scen}.x(:,3), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fuzzy');
hold on;
plot(results_lqr{scen}.t, results_lqr{scen}.x(:,3), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'LQR');
grid on;
ylabel('$\dot{x}$ (m/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('Cart Velocity', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Angular velocity
subplot(3,3,4);
plot(results_fuzzy{scen}.t, rad2deg(results_fuzzy{scen}.x(:,4)), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fuzzy');
hold on;
plot(results_lqr{scen}.t, rad2deg(results_lqr{scen}.x(:,4)), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'LQR');
grid on;
ylabel('$\dot{\theta}$ (deg/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('Angular Velocity', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Control force
subplot(3,3,5);
plot(results_fuzzy{scen}.t, results_fuzzy{scen}.F, 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'Fuzzy');
hold on;
plot(results_lqr{scen}.t, results_lqr{scen}.F, 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'LQR');
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$F$ (N)', 'Interpreter', 'latex', 'FontSize', 10);
title('Control Force', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Phase portrait (angle vs angular velocity)
subplot(3,3,6);
plot(rad2deg(results_fuzzy{scen}.x(:,2)), rad2deg(results_fuzzy{scen}.x(:,4)), ...
    'b-', 'LineWidth', 1.2, 'DisplayName', 'Fuzzy');
hold on;
plot(rad2deg(results_lqr{scen}.x(:,2)), rad2deg(results_lqr{scen}.x(:,4)), ...
    'r-', 'LineWidth', 1.2, 'DisplayName', 'LQR');
plot(rad2deg(scenarios(scen).x0(2)), rad2deg(scenarios(scen).x0(4)), ...
    'ko', 'MarkerSize', 8, 'LineWidth', 2, 'DisplayName', 'Start');
plot(0, 0, 'kx', 'MarkerSize', 10, 'LineWidth', 2, 'DisplayName', 'Target');
grid on;
xlabel('$\theta$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$\dot{\theta}$ (deg/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('Phase Portrait', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 8);

% Energy (kinetic + potential)
subplot(3,3,7);
E_fz = 0.5*sys.M*results_fuzzy{scen}.x(:,3).^2 + ...
       0.5*sys.m*(results_fuzzy{scen}.x(:,3).^2 + ...
       (sys.l*results_fuzzy{scen}.x(:,4)).^2) + ...
       sys.m*sys.g*sys.l*(1 - cos(results_fuzzy{scen}.x(:,2)));

E_lqr = 0.5*sys.M*results_lqr{scen}.x(:,3).^2 + ...
        0.5*sys.m*(results_lqr{scen}.x(:,3).^2 + ...
        (sys.l*results_lqr{scen}.x(:,4)).^2) + ...
        sys.m*sys.g*sys.l*(1 - cos(results_lqr{scen}.x(:,2)));

plot(results_fuzzy{scen}.t, E_fz, 'b-', 'LineWidth', 1.2, 'DisplayName', 'Fuzzy');
hold on;
plot(results_lqr{scen}.t, E_lqr, 'r-', 'LineWidth', 1.2, 'DisplayName', 'LQR');
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Energy (J)', 'Interpreter', 'latex', 'FontSize', 10);
title('System Energy', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Angle error histogram
subplot(3,3,8);
histogram(rad2deg(results_fuzzy{scen}.x(:,2)), 30, 'FaceColor', 'b', ...
    'FaceAlpha', 0.5, 'DisplayName', 'Fuzzy');
hold on;
histogram(rad2deg(results_lqr{scen}.x(:,2)), 30, 'FaceColor', 'r', ...
    'FaceAlpha', 0.5, 'DisplayName', 'LQR');
grid on;
xlabel('$\theta$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Count', 'Interpreter', 'latex', 'FontSize', 10);
title('Angle Distribution', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Animation frame (final state)
subplot(3,3,9);
idx_final = Nt;
draw_pendulum(results_fuzzy{scen}.x(idx_final,:), sys);
title('Final State (Fuzzy)', 'Interpreter', 'latex', 'FontSize', 12);
axis equal;
grid on;
xlim([-1, 1]);
ylim([-0.2, 1.2]);

sgtitle(['Scenario 2: ' scenarios(2).name], 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem08_Fuzzy_LargeAngle.fig');
saveas(gcf, 'Problem08_Fuzzy_LargeAngle.eps', 'epsc');

%% Plot Membership Functions
figure('Position', [100, 100, 1400, 500]);

%   membership functions
subplot(1,3,1);
theta_plot = linspace(fuzzy.theta_range(1), fuzzy.theta_range(2), 200);
labels_theta = {'NB', 'NM', 'NS', 'ZE', 'PS', 'PM', 'PB'};
colors = lines(7);
for i = 1:7
    label = labels_theta{i};
    mf_vals = fuzzy.mf_theta.(label)(theta_plot);
    plot(rad2deg(theta_plot), mf_vals, 'Color', colors(i,:), ...
        'LineWidth', 1.5, 'DisplayName', label);
    hold on;
end
grid on;
xlabel('$\theta$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Membership', 'Interpreter', 'latex', 'FontSize', 10);
title('Input: Pendulum Angle', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'bestoutside', 'NumColumns', 1);

% d /dt membership functions
subplot(1,3,2);
theta_dot_plot = linspace(fuzzy.theta_dot_range(1), fuzzy.theta_dot_range(2), 200);
labels_td = {'NF', 'NM', 'NS', 'ZE', 'PS', 'PM', 'PF'};
for i = 1:7
    label = labels_td{i};
    mf_vals = fuzzy.mf_theta_dot.(label)(theta_dot_plot);
    plot(theta_dot_plot, mf_vals, 'Color', colors(i,:), ...
        'LineWidth', 1.5, 'DisplayName', label);
    hold on;
end
grid on;
xlabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Membership', 'Interpreter', 'latex', 'FontSize', 10);
title('Input: Angular Velocity', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'bestoutside', 'NumColumns', 1);

% F membership functions
subplot(1,3,3);
F_plot = linspace(fuzzy.F_range(1), fuzzy.F_range(2), 200);
labels_F = {'NVB', 'NB', 'NM', 'NS', 'ZE', 'PS', 'PM', 'PB', 'PVB'};
colors_F = lines(9);
for i = 1:9
    label = labels_F{i};
    mf_vals = fuzzy.mf_F.(label)(F_plot);
    plot(F_plot, mf_vals, 'Color', colors_F(i,:), ...
        'LineWidth', 1.5, 'DisplayName', label);
    hold on;
end
grid on;
xlabel('$F$ (N)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Membership', 'Interpreter', 'latex', 'FontSize', 10);
title('Output: Control Force', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'bestoutside', 'NumColumns', 1);

sgtitle('Fuzzy Membership Functions', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem08_MembershipFunctions.fig');
saveas(gcf, 'Problem08_MembershipFunctions.eps', 'epsc');

%% Comparison Across All Scenarios
figure('Position', [150, 150, 1400, 800]);

for scen = 1:length(scenarios)
    subplot(2,4,scen);
    plot(results_fuzzy{scen}.t, rad2deg(results_fuzzy{scen}.x(:,2)), 'b-', ...
        'LineWidth', 1.2, 'DisplayName', 'Fuzzy');
    hold on;
    plot(results_lqr{scen}.t, rad2deg(results_lqr{scen}.x(:,2)), 'r-', ...
        'LineWidth', 1.2, 'DisplayName', 'LQR');
    yline(0, 'k:', 'LineWidth', 1);
    grid on;
    ylabel('$\theta$ (deg)', 'Interpreter', 'latex', 'FontSize', 9);
    title(scenarios(scen).name, 'Interpreter', 'latex', 'FontSize', 10);
    if scen == 1
        legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 8);
    end
    
    subplot(2,4,scen+4);
    plot(results_fuzzy{scen}.t, results_fuzzy{scen}.F, 'b-', ...
        'LineWidth', 1.2);
    hold on;
    plot(results_lqr{scen}.t, results_lqr{scen}.F, 'r-', ...
        'LineWidth', 1.2);
    grid on;
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 9);
    ylabel('$F$ (N)', 'Interpreter', 'latex', 'FontSize', 9);
end

sgtitle('Performance Comparison: All Scenarios', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem08_AllScenarios.fig');
saveas(gcf, 'Problem08_AllScenarios.eps', 'epsc');

fprintf('Plots saved.\n\n');
fprintf('=== Problem 8 Complete ===\n');

%% Simulation Functions

function [t_out, x_out, F_out] = simulate_fuzzy(t, x0, sys, fuzzy)
    % Simulate inverted pendulum with fuzzy logic control
    
    dt = t(2) - t(1);
    Nt = length(t);
    
    x = x0;
    x_out = zeros(Nt, 4);
    F_out = zeros(Nt, 1);
    
    for i = 1:Nt
        % Current state: [x; theta; x_dot; theta_dot]
        theta = x(2);
        theta_dot = x(4);
        
        % Fuzzy inference
        F = fuzzy_inference(theta, theta_dot, fuzzy);
        
        % Pendulum dynamics (nonlinear)
        x_ddot = pendulum_dynamics(x, F, sys);
        
        % Store
        x_out(i,:) = x';
        F_out(i) = F;
        
        % Integration (RK4)
        k1 = x_ddot;
        k2 = pendulum_dynamics(x + 0.5*dt*k1, F, sys);
        k3 = pendulum_dynamics(x + 0.5*dt*k2, F, sys);
        k4 = pendulum_dynamics(x + dt*k3, F, sys);
        
        x = x + (dt/6) * (k1 + 2*k2 + 2*k3 + k4);
    end
    
    t_out = t;
end

function [t_out, x_out, F_out] = simulate_lqr(t, x0, sys, K)
    % Simulate inverted pendulum with LQR control
    
    dt = t(2) - t(1);
    Nt = length(t);
    
    x = x0;
    x_out = zeros(Nt, 4);
    F_out = zeros(Nt, 1);
    
    for i = 1:Nt
        % LQR control law: u = -K*x (full state feedback)
        F = -K * x;
        
        % Limit force
        F = max(min(F, 100), -100);
        
        % Dynamics
        x_ddot = pendulum_dynamics(x, F, sys);
        
        x_out(i,:) = x';
        F_out(i) = F;
        
        % Integration (RK4)
        k1 = x_ddot;
        k2 = pendulum_dynamics(x + 0.5*dt*k1, F, sys);
        k3 = pendulum_dynamics(x + 0.5*dt*k2, F, sys);
        k4 = pendulum_dynamics(x + dt*k3, F, sys);
        
        x = x + (dt/6) * (k1 + 2*k2 + 2*k3 + k4);
    end
    
    t_out = t;
end

function x_dot = pendulum_dynamics(x, F, sys)
    % Nonlinear pendulum dynamics
    % x = [x; theta; x_dot; theta_dot]
    
    theta = x(2);
    x_dot_curr = x(3);
    theta_dot = x(4);
    
    % Intermediate calculations
    sin_theta = sin(theta);
    cos_theta = cos(theta);
    
    denom = sys.M + sys.m*sin_theta^2;
    
    % Accelerations from nonlinear equations
    x_ddot = (F + sys.m*sys.l*theta_dot^2*sin_theta - ...
             sys.m*sys.g*cos_theta*sin_theta - sys.b*x_dot_curr) / denom;
    
    theta_ddot = (sys.g*sin_theta - cos_theta*(F + sys.m*sys.l*theta_dot^2*sin_theta - ...
                 sys.b*x_dot_curr)/(sys.M + sys.m)) / ...
                 (sys.l * (4/3 - sys.m*cos_theta^2/(sys.M + sys.m)));
    
    % State derivative
    x_dot = [x_dot_curr; theta_dot; x_ddot; theta_ddot];
end

function F = fuzzy_inference(theta, theta_dot, fuzzy)
    % Mamdani fuzzy inference engine
    
    % Clip inputs to valid range
    theta = max(min(theta, fuzzy.theta_range(2)), fuzzy.theta_range(1));
    theta_dot = max(min(theta_dot, fuzzy.theta_dot_range(2)), fuzzy.theta_dot_range(1));
    
    % Initialize aggregated output
    output_agg = zeros(size(fuzzy.F_disc));
    
    % Evaluate each rule
    for r = 1:size(fuzzy.rules, 1)
        theta_label = fuzzy.rules{r,1};
        theta_dot_label = fuzzy.rules{r,2};
        F_label = fuzzy.rules{r,3};
        
        % Fuzzification: evaluate membership
        mu_theta = fuzzy.mf_theta.(theta_label)(theta);
        mu_theta_dot = fuzzy.mf_theta_dot.(theta_dot_label)(theta_dot);
        
        % Rule strength (minimum t-norm)
        alpha = min(mu_theta, mu_theta_dot);
        
        % Output fuzzy set clipped by rule strength
        output_fuzzy = min(alpha, fuzzy.mf_F.(F_label)(fuzzy.F_disc));
        
        % Aggregation (maximum)
        output_agg = max(output_agg, output_fuzzy);
    end
    
    % Defuzzification (centroid method)
    if sum(output_agg) > 0
        F = sum(fuzzy.F_disc .* output_agg) / sum(output_agg);
    else
        F = 0;  % No rules fired (shouldn't happen with proper design)
    end
    
    % Saturate output
    F = max(min(F, fuzzy.F_range(2)), fuzzy.F_range(1));
end

function y = trimf(x, params)
    % Triangular membership function
    % params = [a, b, c] where b is the peak
    
    a = params(1);
    b = params(2);
    c = params(3);
    
    y = max(0, min((x-a)/(b-a), (c-x)/(c-b)));
end

function draw_pendulum(state, sys)
    % Draw pendulum configuration
    
    x_cart = state(1);
    theta = state(2);
    
    % Cart
    cart_w = 0.3;
    cart_h = 0.15;
    rectangle('Position', [x_cart - cart_w/2, -cart_h/2, cart_w, cart_h], ...
        'FaceColor', [0.5, 0.5, 0.8], 'EdgeColor', 'k', 'LineWidth', 2);
    
    hold on;
    
    % Pendulum
    x_pend = x_cart + sys.l * sin(theta);
    y_pend = sys.l * cos(theta);
    
    plot([x_cart, x_pend], [0, y_pend], 'k-', 'LineWidth', 3);
    plot(x_pend, y_pend, 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
    
    % Ground
    plot([-2, 2], [-cart_h/2, -cart_h/2], 'k-', 'LineWidth', 2);
end
