%% chapter_Math_lab15_pendulum.m
% Nonlinear Pendulum Dynamics and Chaos
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab15_pendulum
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory
Lab15_NonlinearPendulumDynamics();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab15_NonlinearPendulumDynamics()
    % LAB15_NONLINEARPENDULULUMDYNAMICS Analyze pendulum systems and chaos
    %   Studies nonlinear dynamics, phase portraits, and chaotic behavior
    
    fprintf('\\textbf{Laboratory 15: Nonlinear Pendulum Dynamics}\n');
    fprintf('====================================================\n\n');
    
    % Physical constants
    global g;
    g = 9.81;  % m/s^2
    
    % Task 1: Linear vs nonlinear simple pendulum
    compareLinearNonlinear();
    
    % Task 2: Phase space analysis
    analyzePhasespace();
    
    % Task 3: Energy and conservation
    analyzeEnergyConservation();
    
    % Task 4: Double pendulum chaos
    demonstrateChaos();
    
    % Task 5: Sensitivity to initial conditions
    analyzeSensitivity();
end

function compareLinearNonlinear()
    % COMPARELINEARNONLINEAR Compare small and large angle pendulum
    
    global g;
    
    fprintf('\\textbf{Task 1: Linear vs Nonlinear Pendulum}\n');
    fprintf('---------\n\n');
    
    % Pendulum parameters
    L = 1.0;  % Length (m)
    
    fprintf('Pendulum Parameters:\n');
    fprintf('  Length: %.2f m\n', L);
    fprintf('  Gravity: %.2f m/s²\n', g);
    fprintf('  Natural frequency (small angle): %.4f rad/s\n', sqrt(g/L));
    fprintf('  Natural period (small angle): %.4f s\n\n', 2*pi*sqrt(L/g));
    
    % Test three initial angles
    initial_angles = [10, 60, 170];  % degrees
    colors = ['b', 'r', 'g'];
    
    fprintf('Comparing different initial angles:\n');
    
    % Time span
    t_span = [0, 20];
    
    % Create figure
    figure('Position', [100, 100, 1400, 900], 'Name', 'Linear vs Nonlinear Comparison');
    
    for i = 1:length(initial_angles)
        theta0_deg = initial_angles(i);
        theta0 = theta0_deg * pi / 180;  % Convert to radians
        
        fprintf('  Initial angle: %d°\n', theta0_deg);
        
        % Linear approximation
        omega0_linear = sqrt(g/L);
        
        % Analytical solution (small angle)
        t_analytical = linspace(t_span(1), t_span(2), 1000);
        theta_linear = theta0 * cos(omega0_linear * t_analytical);
        
        % Nonlinear numerical solution
        [t_nonlinear, y_nonlinear] = ode45(@(t,y) simplePendulumODE(t, y, L), ...
            t_span, [theta0; 0]);
        theta_nonlinear = y_nonlinear(:, 1);
        
        % Compute period for nonlinear case
        % Find zero crossings
        zero_crossings = find(diff(sign(theta_nonlinear)) ~= 0);
        if length(zero_crossings) >= 2
            period_nonlinear = 2 * (t_nonlinear(zero_crossings(2)) - ...
                t_nonlinear(zero_crossings(1)));
            fprintf('    Nonlinear period: %.4f s\n', period_nonlinear);
        end
        
        % Subplot 1: Angle vs time
        subplot(3, 3, (i-1)*3 + 1);
        plot(t_analytical, theta_linear * 180/pi, [colors(i), '-'], ...
            'LineWidth', 2, 'DisplayName', 'Linear');
        hold on;
        plot(t_nonlinear, theta_nonlinear * 180/pi, [colors(i), '-'], ...
            'LineWidth', 2, 'DisplayName', 'Nonlinear');
        xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('Angle (degrees)', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('$\\theta_0 = %d°$', theta0_deg), 'Interpreter', 'latex', ...
            'FontSize', 12);
        legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 9);
        grid on;
        
        % Subplot 2: Error between linear and nonlinear
        subplot(3, 3, (i-1)*3 + 2);
        
        % Interpolate to common time points
        theta_linear_interp = interp1(t_analytical, theta_linear, t_nonlinear);
        error = abs(theta_nonlinear - theta_linear_interp) * 180/pi;
        
        plot(t_nonlinear, error, colors(i), 'LineWidth', 2);
        xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('Error (degrees)', 'Interpreter', 'latex', 'FontSize', 11);
        title('Linear Approximation Error', 'Interpreter', 'latex', 'FontSize', 12);
        grid on;
        
        fprintf('    Maximum error: %.2f°\n', max(error));
        fprintf('    RMS error: %.2f°\n', sqrt(mean(error.^2)));
        
        % Subplot 3: Phase portrait
        subplot(3, 3, (i-1)*3 + 3);
        omega_nonlinear = y_nonlinear(:, 2);
        plot(theta_nonlinear * 180/pi, omega_nonlinear * 180/pi, colors(i), ...
            'LineWidth', 2);
        hold on;
        plot(theta_nonlinear(1) * 180/pi, omega_nonlinear(1) * 180/pi, ...
            [colors(i), 'o'], 'MarkerSize', 10, 'MarkerFaceColor', colors(i));
        xlabel('$\theta$ (degrees)', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('$\dot{\theta}$ (degrees/s)', 'Interpreter', 'latex', 'FontSize', 11);
        title('Phase Portrait', 'Interpreter', 'latex', 'FontSize', 12);
        grid on;
        axis equal;
    end
    
    fprintf('\n');
end

function dydt = simplePendulumODE(t, y, L)
    % SIMPLEPENDULUMMODE ODE for simple nonlinear pendulum
    global g;
    
    theta = y(1);
    omega = y(2);
    
    dydt = [omega; -(g/L) * sin(theta)];
end

function analyzePhasespace()
    % ANALYZEPHASESPACE Comprehensive phase space analysis
    
    global g;
    
    fprintf('\\textbf{Task 2: Phase Space Analysis}\n');
    fprintf('-------\n\n');
    
    L = 1.0;  % Length (m)
    
    fprintf('Generating phase portraits for different energy levels...\n\n');
    
    % Create figure
    figure('Position', [150, 150, 1400, 600], 'Name', 'Phase Space Analysis');
    
    % Subplot 1: Multiple trajectories
    subplot(1, 2, 1);
    hold on;
    
    % Generate trajectories with different initial conditions
    initial_conditions = [
        0.5, 0;      % Small oscillation
        1.5, 0;      % Medium oscillation
        2.8, 0;      % Large oscillation
        3.0, 0;      % Near separatrix
        3.14, 1;     % Rotation (over the top)
        3.14, 3      % Fast rotation
    ];
    
    colors = lines(size(initial_conditions, 1));
    t_span = [0, 50];
    
    for i = 1:size(initial_conditions, 1)
        IC = initial_conditions(i, :);
        
        [t, y] = ode45(@(t,y) simplePendulumODE(t, y, L), t_span, IC);
        
        plot(y(:,1), y(:,2), 'Color', colors(i,:), 'LineWidth', 2);
        plot(IC(1), IC(2), 'o', 'Color', colors(i,:), 'MarkerSize', 10, ...
            'MarkerFaceColor', colors(i,:));
    end
    
    % Plot separatrix (boundary between oscillation and rotation)
    theta_sep = linspace(-pi, pi, 200);
    omega_sep_positive = sqrt(4 * g/L * (cos(theta_sep) + 1));
    omega_sep_negative = -omega_sep_positive;
    
    plot(theta_sep, omega_sep_positive, 'k-', 'LineWidth', 2.5);
    plot(theta_sep, omega_sep_negative, 'k-', 'LineWidth', 2.5);
    
    xlabel('$\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 13);
    ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 13);
    title('Phase Portrait with Separatrix', 'Interpreter', 'latex', 'FontSize', 14);
    xlim([-pi, pi]);
    ylim([-5, 5]);
    grid on;
    
    % Mark fixed points
    plot(0, 0, 'ro', 'MarkerSize', 15, 'MarkerFaceColor', 'r', 'LineWidth', 2);
    text(0.2, 0.2, 'Stable', 'FontSize', 11, 'Color', 'r', 'FontWeight', 'bold');
    
    % Subplot 2: Energy contours
    subplot(1, 2, 2);
    
    % Create grid in phase space
    theta_grid = linspace(-pi, pi, 100);
    omega_grid = linspace(-5, 5, 100);
    [THETA, OMEGA] = meshgrid(theta_grid, omega_grid);
    
    % Compute energy at each point
    m = 1;  % Mass (normalized)
    E = 0.5 * m * L^2 * OMEGA.^2 + m*g*L*(1 - cos(THETA));
    
    % Plot energy contours
    contour(THETA, OMEGA, E, 20, 'LineWidth', 1.5);
    colorbar;
    
    % Overlay separatrix
    hold on;
    plot(theta_sep, omega_sep_positive, 'r-', 'LineWidth', 3);
    plot(theta_sep, omega_sep_negative, 'r-', 'LineWidth', 3);
    
    xlabel('$\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 13);
    ylabel('$\dot{\theta}$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 13);
    title('Energy Contours in Phase Space', 'Interpreter', 'latex', 'FontSize', 14);
    xlim([-pi, pi]);
    ylim([-5, 5]);
    
    fprintf('Phase space features:\n');
    fprintf('  • Closed orbits: bounded oscillations\n');
    fprintf('  • Open orbits: continuous rotation\n');
    fprintf('  • Separatrix: boundary between oscillation and rotation\n');
    fprintf('  • Fixed point at (0,0): stable equilibrium\n\n');
end

function analyzeEnergyConservation()
    % ANALYZEENERGYCONSERVATION Verify energy conservation
    
    global g;
    
    fprintf('\\textbf{Task 3: Energy Conservation}\n');
    fprintf('-------\n\n');
    
    L = 1.0;  % Length (m)
    m = 1.0;  % Mass (kg)
    
    % Initial conditions
    theta0 = 60 * pi/180;
    omega0 = 0;
    
    fprintf('Energy Conservation Test:\n');
    fprintf('  Initial angle: %.1f°\n', theta0 * 180/pi);
    fprintf('  Initial angular velocity: %.2f rad/s\n', omega0);
    
    % Compute initial energy
    E0 = 0.5 * m * L^2 * omega0^2 + m*g*L*(1 - cos(theta0));
    fprintf('  Initial total energy: %.6f J\n\n', E0);
    
    % Integrate with different tolerances
    tolerances = [1e-3, 1e-6, 1e-9, 1e-12];
    t_span = [0, 100];
    
    figure('Position', [200, 200, 1400, 900], 'Name', 'Energy Conservation');
    
    for i = 1:length(tolerances)
        tol = tolerances(i);
        
        fprintf('ODE solver tolerance: %.0e\n', tol);
        
        % Set ODE options
        options = odeset('RelTol', tol, 'AbsTol', tol);
        
        % Solve
        tic;
        [t, y] = ode45(@(t,y) simplePendulumODE(t, y, L), t_span, ...
            [theta0; omega0], options);
        solve_time = toc;
        
        % Compute energy at each timestep
        theta = y(:, 1);
        omega = y(:, 2);
        E = 0.5 * m * L^2 * omega.^2 + m*g*L*(1 - cos(theta));
        
        % Energy error
        E_error = abs(E - E0);
        
        fprintf('  Solution points: %d\n', length(t));
        fprintf('  Solve time: %.6f s\n', solve_time);
        fprintf('  Max energy error: %.6e J (%.6e%%)\n', ...
            max(E_error), 100*max(E_error)/E0);
        fprintf('  RMS energy error: %.6e J\n\n', sqrt(mean(E_error.^2)));
        
        % Subplot 1: Energy vs time
        subplot(2, 2, i);
        
        plot(t, E, 'b-', 'LineWidth', 1.5);
        hold on;
        yline(E0, 'r-', 'Initial Energy', 'LineWidth', 2);
        
        xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('Total Energy (J)', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('Tolerance: $%.0e$', tol), 'Interpreter', 'latex', 'FontSize', 13);
        grid on;
    end
    
    % Additional subplot: Energy error comparison
    figure('Position', [250, 250, 800, 600], 'Name', 'Energy Error Analysis');
    
    for i = 1:length(tolerances)
        tol = tolerances(i);
        options = odeset('RelTol', tol, 'AbsTol', tol);
        [t, y] = ode45(@(t,y) simplePendulumODE(t, y, L), t_span, ...
            [theta0; omega0], options);
        
        theta = y(:, 1);
        omega = y(:, 2);
        E = 0.5 * m * L^2 * omega.^2 + m*g*L*(1 - cos(theta));
        E_error = abs(E - E0) / E0;  % Relative error
        
        semilogy(t, E_error, 'LineWidth', 2, 'DisplayName', sprintf('Tol=%.0e', tol));
        hold on;
    end
    
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 13);
    ylabel('Relative Energy Error', 'Interpreter', 'latex', 'FontSize', 13);
    title('Energy Conservation: Effect of Tolerance', 'Interpreter', 'latex', ...
        'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 11);
    grid on;
end

function demonstrateChaos()
    % DEMONSTRATECHAOS Double pendulum chaos
    
    global g;
    
    fprintf('\\textbf{Task 4: Double Pendulum Chaos}\n');
    fprintf('--------\n\n');
    
    % Double pendulum parameters
    L1 = 1.0;  % Length of first rod (m)
    L2 = 1.0;  % Length of second rod (m)
    m1 = 1.0;  % Mass of first bob (kg)
    m2 = 1.0;  % Mass of second bob (kg)
    
    params = [L1, L2, m1, m2];
    
    fprintf('Double Pendulum Parameters:\n');
    fprintf('  L1 = %.2f m, L2 = %.2f m\n', L1, L2);
    fprintf('  m1 = %.2f kg, m2 = %.2f kg\n\n', m1, m2);
    
    % Initial conditions
    theta1_0 = 120 * pi/180;
    theta2_0 = -10 * pi/180;
    omega1_0 = 0;
    omega2_0 = 0;
    
    fprintf('Initial Conditions:\n');
    fprintf('  θ1(0) = %.1f°, θ2(0) = %.1f°\n', ...
        theta1_0*180/pi, theta2_0*180/pi);
    fprintf('  ω1(0) = %.2f rad/s, ω2(0) = %.2f rad/s\n\n', omega1_0, omega2_0);
    
    % Time span
    t_span = [0, 20];
    
    fprintf('Simulating double pendulum...\n');
    tic;
    [t, y] = ode45(@(t,y) doublePendulumODE(t, y, params), t_span, ...
        [theta1_0; theta2_0; omega1_0; omega2_0]);
    solve_time = toc;
    
    fprintf('  Simulation time: %.4f s\n', solve_time);
    fprintf('  Time points: %d\n\n', length(t));
    
    % Extract variables
    theta1 = y(:, 1);
    theta2 = y(:, 2);
    omega1 = y(:, 3);
    omega2 = y(:, 4);
    
    % Compute Cartesian coordinates for visualisation
    x1 = L1 * sin(theta1);
    y1 = -L1 * cos(theta1);
    x2 = x1 + L2 * sin(theta2);
    y2 = y1 - L2 * cos(theta2);
    
    % Plot results
    figure('Position', [100, 100, 1400, 900], 'Name', 'Double Pendulum Chaos');
    
    % Subplot 1: Angular positions
    subplot(3, 3, 1);
    plot(t, theta1*180/pi, 'r-', 'LineWidth', 2, 'DisplayName', '$\theta_1$');
    hold on;
    plot(t, theta2*180/pi, 'b-', 'LineWidth', 2, 'DisplayName', '$\theta_2$');
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Angle (degrees)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Angular Positions', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Subplot 2: Angular velocities
    subplot(3, 3, 2);
    plot(t, omega1*180/pi, 'r-', 'LineWidth', 2, 'DisplayName', '$\omega_1$');
    hold on;
    plot(t, omega2*180/pi, 'b-', 'LineWidth', 2, 'DisplayName', '$\omega_2$');
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Angular Velocity (deg/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Angular Velocities', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Subplot 3: Trajectory of second bob
    subplot(3, 3, 3);
    plot(x2, y2, 'b-', 'LineWidth', 1);
    hold on;
    plot(x2(1), y2(1), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    plot(x2(end), y2(end), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Trajectory of Second Bob', 'Interpreter', 'latex', 'FontSize', 13);
    axis equal;
    grid on;
    legend('Trajectory', 'Start', 'End', 'Interpreter', 'latex', 'Location', 'best');
    
    % Subplot 4-6: Phase portraits
    subplot(3, 3, 4);
    plot(theta1*180/pi, omega1*180/pi, 'r-', 'LineWidth', 1.5);
    xlabel('$\theta_1$ (degrees)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\omega_1$ (deg/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Phase Portrait: Pendulum 1', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    subplot(3, 3, 5);
    plot(theta2*180/pi, omega2*180/pi, 'b-', 'LineWidth', 1.5);
    xlabel('$\theta_2$ (degrees)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\omega_2$ (deg/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Phase Portrait: Pendulum 2', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    subplot(3, 3, 6);
    plot(theta1*180/pi, theta2*180/pi, 'g-', 'LineWidth', 1.5);
    xlabel('$\theta_1$ (degrees)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\theta_2$ (degrees)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Configuration Space', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 7: Energy
    subplot(3, 3, 7);
    E = computeDoublePendulumEnergy(y, params);
    plot(t, E, 'k-', 'LineWidth', 2);
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Total Energy (J)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Energy Conservation', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    E_variation = (max(E) - min(E)) / mean(E);
    fprintf('Energy variation: %.6f%% of mean energy\n\n', 100*E_variation);
    
    % Create animation (sample frames)
    subplot(3, 3, [8, 9]);
    axis equal;
    xlim([-(L1+L2)*1.2, (L1+L2)*1.2]);
    ylim([-(L1+L2)*1.2, (L1+L2)*1.2]);
    hold on;
    grid on;
    title('Double Pendulum Animation', 'Interpreter', 'latex', 'FontSize', 13);
    
    % Draw multiple positions to show motion
    n_frames = 20;
    frame_indices = round(linspace(1, length(t), n_frames));
    
    for idx = frame_indices
        % Draw rods and bobs with fading
        alpha_val = 0.1 + 0.9 * (idx - frame_indices(1)) / (frame_indices(end) - frame_indices(1));
        
        plot([0, x1(idx)], [0, y1(idx)], 'r-', 'LineWidth', 2, ...
            'Color', [1, 0, 0, alpha_val]);
        plot([x1(idx), x2(idx)], [y1(idx), y2(idx)], 'b-', 'LineWidth', 2, ...
            'Color', [0, 0, 1, alpha_val]);
        plot(x1(idx), y1(idx), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', ...
            'MarkerFaceAlpha', alpha_val);
        plot(x2(idx), y2(idx), 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b', ...
            'MarkerFaceAlpha', alpha_val);
    end
    
    % Draw origin
    plot(0, 0, 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'k');
end

function dydt = doublePendulumODE(t, y, params)
    % DOUBLEPENDULUMMODE ODE for double pendulum
    global g;
    
    L1 = params(1);
    L2 = params(2);
    m1 = params(3);
    m2 = params(4);
    
    theta1 = y(1);
    theta2 = y(2);
    omega1 = y(3);
    omega2 = y(4);
    
    % Equations of motion (from Lagrangian mechanics)
    delta = theta2 - theta1;
    
    den1 = (m1 + m2) * L1 - m2 * L1 * cos(delta)^2;
    den2 = (L2 / L1) * den1;
    
    dydt = zeros(4, 1);
    dydt(1) = omega1;
    dydt(2) = omega2;
    
    dydt(3) = (m2 * L1 * omega1^2 * sin(delta) * cos(delta) + ...
               m2 * g * sin(theta2) * cos(delta) + ...
               m2 * L2 * omega2^2 * sin(delta) - ...
               (m1 + m2) * g * sin(theta1)) / den1;
    
    dydt(4) = (-m2 * L2 * omega2^2 * sin(delta) * cos(delta) + ...
               (m1 + m2) * g * sin(theta1) * cos(delta) - ...
               (m1 + m2) * L1 * omega1^2 * sin(delta) - ...
               (m1 + m2) * g * sin(theta2)) / den2;
end

function E = computeDoublePendulumEnergy(y, params)
    % COMPUTEDOUBLEPENDULUMENERGY Calculate total energy
    global g;
    
    L1 = params(1);
    L2 = params(2);
    m1 = params(3);
    m2 = params(4);
    
    theta1 = y(:, 1);
    theta2 = y(:, 2);
    omega1 = y(:, 3);
    omega2 = y(:, 4);
    
    % Kinetic energy
    T = 0.5 * m1 * (L1 * omega1).^2 + ...
        0.5 * m2 * ((L1 * omega1).^2 + (L2 * omega2).^2 + ...
        2 * L1 * L2 * omega1 .* omega2 .* cos(theta1 - theta2));
    
    % Potential energy
    V = -m1 * g * L1 * cos(theta1) - ...
        m2 * g * (L1 * cos(theta1) + L2 * cos(theta2));
    
    E = T + V;
end

function analyzeSensitivity()
    % ANALYZESENSITIVITY Demonstrate sensitive dependence on ICs
    
    global g;
    
    fprintf('\\textbf{Task 5: Sensitivity to Initial Conditions}\n');
    fprintf('----------\n\n');
    
    % Double pendulum parameters
    L1 = 1.0;
    L2 = 1.0;
    m1 = 1.0;
    m2 = 1.0;
    params = [L1, L2, m1, m2];
    
    % Base initial condition
    theta1_0 = 120 * pi/180;
    theta2_0 = -10 * pi/180;
    omega1_0 = 0;
    omega2_0 = 0;
    
    IC_base = [theta1_0; theta2_0; omega1_0; omega2_0];
    
    % Perturbations (very small)
    perturbations = [1e-6, 1e-5, 1e-4, 1e-3];
    
    fprintf('Base Initial Conditions:\n');
    fprintf('  θ1 = %.4f rad, θ2 = %.4f rad\n', theta1_0, theta2_0);
    fprintf('  ω1 = %.4f rad/s, ω2 = %.4f rad/s\n\n', omega1_0, omega2_0);
    
    fprintf('Testing perturbations:\n');
    
    t_span = [0, 15];
    colors = lines(length(perturbations) + 1);
    
    % Solve base case
    [t_base, y_base] = ode45(@(t,y) doublePendulumODE(t, y, params), ...
        t_span, IC_base);
    
    % Create figure
    figure('Position', [150, 150, 1400, 900], 'Name', 'Sensitivity Analysis');
    
    % Subplot 1: Trajectories comparison
    subplot(2, 3, [1, 4]);
    
    % Base trajectory
    x1_base = L1 * sin(y_base(:,1));
    y1_base = -L1 * cos(y_base(:,1));
    x2_base = x1_base + L2 * sin(y_base(:,2));
    y2_base = y1_base - L2 * cos(y_base(:,2));
    
    plot(x2_base, y2_base, 'Color', colors(1,:), 'LineWidth', 2, ...
        'DisplayName', 'Base');
    hold on;
    
    % Perturbed trajectories
    for i = 1:length(perturbations)
        delta = perturbations(i);
        
        fprintf('  Perturbation: %.0e rad\n', delta);
        
        % Add small perturbation to theta1
        IC_perturbed = IC_base;
        IC_perturbed(1) = IC_perturbed(1) + delta;
        
        [t_pert, y_pert] = ode45(@(t,y) doublePendulumODE(t, y, params), ...
            t_span, IC_perturbed);
        
        x2_pert = L1 * sin(y_pert(:,1)) + L2 * sin(y_pert(:,2));
        y2_pert = -L1 * cos(y_pert(:,1)) - L2 * cos(y_pert(:,2));
        
        plot(x2_pert, y2_pert, 'Color', colors(i+1,:), 'LineWidth', 2, ...
            'DisplayName', sprintf('δ = %.0e', delta));
    end
    
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 13);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 13);
    title('Second Bob Trajectories', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 10);
    axis equal;
    grid on;
    
    % Subplot 2-4: Distance divergence
    for i = 1:length(perturbations)
        delta = perturbations(i);
        
        IC_perturbed = IC_base;
        IC_perturbed(1) = IC_perturbed(1) + delta;
        
        [t_pert, y_pert] = ode45(@(t,y) doublePendulumODE(t, y, params), ...
            t_span, IC_perturbed);
        
        % Interpolate to common time points
        y_pert_interp = interp1(t_pert, y_pert, t_base);
        
        % Compute state space distance
        distance = sqrt(sum((y_base - y_pert_interp).^2, 2));
        
        subplot(2, 3, i+1);
        semilogy(t_base, distance, 'Color', colors(i+1,:), 'LineWidth', 2);
        xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('State Distance', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('Perturbation: $\\delta = %.0e$', delta), ...
            'Interpreter', 'latex', 'FontSize', 13);
        grid on;
        
        % Estimate Lyapunov exponent from exponential growth
        % Fit log(distance) = log(delta) + lambda * t
        valid_idx = distance > 0 & t_base > 1;  % After initial transient
        if sum(valid_idx) > 10
            p = polyfit(t_base(valid_idx), log(distance(valid_idx)), 1);
            lambda_est = p(1);
            
            % Plot fit
            hold on;
            t_fit = linspace(min(t_base(valid_idx)), max(t_base(valid_idx)), 100);
            distance_fit = exp(polyval(p, t_fit));
            plot(t_fit, distance_fit, 'r-', 'LineWidth', 2);
            
            text(0.6*max(t_base), 0.5*max(distance), ...
                sprintf('$\\lambda \\approx %.2f$', lambda_est), ...
                'Interpreter', 'latex', 'FontSize', 11, 'Color', 'r', ...
                'FontWeight', 'bold');
            
            fprintf('    Estimated Lyapunov exponent: %.4f\n', lambda_est);
        end
    end
    
    fprintf('\n');
    fprintf('Observations:\n');
    fprintf('  • Trajectories diverge exponentially despite tiny differences\n');
    fprintf('  • Positive Lyapunov exponent confirms chaotic behavior\n');
    fprintf('  • Long-term prediction impossible due to sensitivity\n');
    fprintf('  • Butterfly effect: small causes lead to large effects\n\n');
end
