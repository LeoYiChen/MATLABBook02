%% lst_adv_prob03.m
% Lotka-Volterra predator-prey simulation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob03
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem03.m
%  Predator-Prey Dynamics: Lotka-Volterra Equations
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. Parameters and ODE Definition --
preyBirthRate   = 0.1;    % alpha
predationRate   = 0.02;   % beta
predatorEfficiency = 0.01; % delta
predatorDeathRate  = 0.1;  % gamma

lotkaVolterra = @(t, populationState) [ ...
    preyBirthRate * populationState(1) ...
    - predationRate * populationState(1) * populationState(2); ...
    predatorEfficiency * populationState(1) ...
    * populationState(2) ...
    - predatorDeathRate * populationState(2)];

initialPopulation = [40; 9];
timeSpan = [0 200];

%% -- 2. Solve ODE --
solverOptions = odeset('RelTol', 1e-8, 'AbsTol', 1e-10);
[timeOutput, populationOutput] = ode45(lotkaVolterra, ...
    timeSpan, initialPopulation, solverOptions);

preyPopulation     = populationOutput(:, 1);
predatorPopulation = populationOutput(:, 2);

fprintf('-- Population Oscillation Summary --\n');
fprintf('Max prey     = %.2f\n', max(preyPopulation));
fprintf('Min prey     = %.2f\n', min(preyPopulation));
fprintf('Max predator = %.2f\n', max(predatorPopulation));
fprintf('Min predator = %.2f\n', min(predatorPopulation));

% Estimate period from prey peaks
[~, peakLocations] = findpeaks(preyPopulation, timeOutput);
if numel(peakLocations) >= 2
    estimatedPeriod = mean(diff(peakLocations));
    fprintf('Estimated period = %.2f time units\n', ...
            estimatedPeriod);
end

%% -- 3. Visualisation --
figHandle = figure('Position', [80 80 1300 500]);

subplot(1,2,1);
plot(timeOutput, preyPopulation, 'b-', 'LineWidth', 1.3); hold on;
plot(timeOutput, predatorPopulation, 'r-', 'LineWidth', 1.3);
xlabel('Time (units)', 'Interpreter', 'latex');
ylabel('Population', 'Interpreter', 'latex');
title('Population Dynamics', 'Interpreter', 'latex');
legend({'Prey $x(t)$', 'Predator $y(t)$'}, ...
       'Interpreter', 'latex', 'Location', 'northeast');
grid on;

subplot(1,2,2);
plot(preyPopulation, predatorPopulation, 'k-', 'LineWidth', 1.2);
hold on;
plot(initialPopulation(1), initialPopulation(2), 'go', ...
     'MarkerSize', 10, 'MarkerFaceColor', 'g');
xlabel('Prey $x$', 'Interpreter', 'latex');
ylabel('Predator $y$', 'Interpreter', 'latex');
title('Phase Portrait', 'Interpreter', 'latex');
grid on;

savefig(figHandle, 'Problem03_LotkaVolterra.fig');
exportgraphics(figHandle, 'Problem03_LotkaVolterra.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem03_LotkaVolterra.jpg', ...
               'Resolution', 300);

%% -- 4. Animation (MP4 Video) --
videoFilename = 'Problem03_LotkaVolterra.mp4';
videoWriter = VideoWriter(videoFilename, 'MPEG-4');
videoWriter.FrameRate = 30;
videoWriter.Quality   = 95;
open(videoWriter);

figAnim = figure('Position', [100 100 800 600]);
numFrames = min(300, numel(timeOutput));
frameIndices = round(linspace(1, numel(timeOutput), numFrames));

for frameIdx = 1:numFrames
    currentIndex = frameIndices(frameIdx);
    clf;
    subplot(2,1,1);
    plot(timeOutput(1:currentIndex), ...
         preyPopulation(1:currentIndex), 'b-', ...
         'LineWidth', 1.3); hold on;
    plot(timeOutput(1:currentIndex), ...
         predatorPopulation(1:currentIndex), 'r-', ...
         'LineWidth', 1.3);
    xlim(timeSpan); ylim([0 85]);
    xlabel('Time', 'Interpreter', 'latex');
    ylabel('Population', 'Interpreter', 'latex');
    title(sprintf('$t = %.1f$', timeOutput(currentIndex)), ...
          'Interpreter', 'latex');
    legend({'Prey', 'Predator'}, 'Interpreter', 'latex');
    grid on;

    subplot(2,1,2);
    plot(preyPopulation(1:currentIndex), ...
         predatorPopulation(1:currentIndex), 'k-', ...
         'LineWidth', 1.2); hold on;
    plot(preyPopulation(currentIndex), ...
         predatorPopulation(currentIndex), 'ro', ...
         'MarkerSize', 8, 'MarkerFaceColor', 'r');
    xlim([0 85]); ylim([0 30]);
    xlabel('Prey $x$', 'Interpreter', 'latex');
    ylabel('Predator $y$', 'Interpreter', 'latex');
    title('Phase Portrait', 'Interpreter', 'latex');
    grid on;

    drawnow;
    frame = getframe(figAnim);
    writeVideo(videoWriter, frame);
end
close(videoWriter);
close(figAnim);
fprintf('Video saved: %s\n', videoFilename);

fprintf('\n-- Problem 3 Complete --\n');
% Computational Complexity:
% ode45 employs a 6-stage Runge-Kutta method, so each step
% requires 6 evaluations of the 2-dimensional ODE function,
% giving O(6*2) = O(12) operations per step.  With adaptive
% stepping, total steps N_s depend on error tolerance;
% typically N_s = O(1000) here.  Phase portrait plotting is
% O(N_s).  Video generation is O(numFrames * rendering_cost),
% dominated by frame capture rather than computation.  Space
% complexity is O(N_s) for the solution trajectory.
