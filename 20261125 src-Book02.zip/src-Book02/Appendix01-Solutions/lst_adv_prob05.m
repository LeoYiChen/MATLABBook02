%% lst_adv_prob05.m
% Multi-storey building vibration analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob05
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem05.m
%  Vibration Analysis of a Multi-Storey Building
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. Define Matrices --
massMatrix = diag([1000, 1000, 800]);  % kg
stiffnessMatrix = 1e6 * [2 -1  0;
                         -1  2 -1;
                          0 -1  1];    % N/m

%% -- 2. Solve Generalised Eigenvalue Problem --
[modeShapes, eigenvalueMatrix] = eig(stiffnessMatrix, ...
                                      massMatrix);
eigenvalues = diag(eigenvalueMatrix);

% Sort by ascending eigenvalue
[eigenvalues, sortOrder] = sort(eigenvalues);
modeShapes = modeShapes(:, sortOrder);

naturalFrequencies = sqrt(eigenvalues);       % rad/s
frequenciesHz = naturalFrequencies / (2*pi);  % Hz
periods = 1 ./ frequenciesHz;                 % s

fprintf('-- Natural Frequencies and Mode Shapes --\n');
for modeIndex = 1:3
    fprintf('\nMode %d:\n', modeIndex);
    fprintf('  Eigenvalue     = %.2f\n', eigenvalues(modeIndex));
    fprintf('  omega          = %.4f rad/s\n', ...
            naturalFrequencies(modeIndex));
    fprintf('  Frequency      = %.4f Hz\n', ...
            frequenciesHz(modeIndex));
    fprintf('  Period         = %.4f s\n', periods(modeIndex));
    fprintf('  Mode shape     = [%.4f, %.4f, %.4f]\n', ...
            modeShapes(:, modeIndex));
end

fprintf('\nMode 1 (fundamental) has the lowest frequency ');
fprintf('and is most dangerous for resonance.\n');

%% -- 3. Visualise Mode Shapes --
floorLevels = [0; 1; 2; 3];  % ground + 3 floors
figHandle = figure('Position', [100 100 1200 450]);

for modeIndex = 1:3
    subplot(1,3,modeIndex);
    modeDisplacement = [0; modeShapes(:, modeIndex)];
    modeDisplacement = modeDisplacement / ...
        max(abs(modeDisplacement));

    plot(modeDisplacement, floorLevels, 'bo-', ...
         'LineWidth', 2, 'MarkerSize', 8, ...
         'MarkerFaceColor', 'b'); hold on;
    plot(zeros(4,1), floorLevels, 'k-', 'LineWidth', 0.5);

    xlabel('Normalised displacement', 'Interpreter', 'latex');
    ylabel('Floor level', 'Interpreter', 'latex');
    title(sprintf('Mode %d ($f = %.2f$ Hz)', ...
          modeIndex, frequenciesHz(modeIndex)), ...
          'Interpreter', 'latex');
    ylim([-0.3 3.3]);
    xlim([-1.2 1.2]);
    grid on;
    set(gca, 'YTick', 0:3, ...
        'YTickLabel', {'Ground','1st','2nd','3rd'});
end

savefig(figHandle, 'Problem05_BuildingVibration.fig');
exportgraphics(figHandle, 'Problem05_BuildingVibration.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem05_BuildingVibration.jpg', ...
               'Resolution', 300);

%% -- 4. Animation (MP4) --
videoWriter = VideoWriter('Problem05_BuildingVibration.mp4', ...
                          'MPEG-4');
videoWriter.FrameRate = 30;
videoWriter.Quality   = 95;
open(videoWriter);

figAnim = figure('Position', [100 100 500 600]);
timeAnimation = linspace(0, 4*max(periods), 360);

for frameIdx = 1:numel(timeAnimation)
    currentTime = timeAnimation(frameIdx);
    clf;
    for modeIndex = 1:3
        modeDynamic = modeShapes(:, modeIndex) * ...
            sin(naturalFrequencies(modeIndex) * currentTime);
        displacement = [0; modeDynamic];
        displacement = displacement / ...
            (3 * max(abs(modeShapes(:, modeIndex))));

        plot(displacement + (modeIndex-1)*0.8, floorLevels, ...
             'o-', 'LineWidth', 2, 'MarkerSize', 8); hold on;
    end
    xlim([-0.8 2.2]);
    ylim([-0.3 3.5]);
    xlabel('Displacement (scaled)', 'Interpreter', 'latex');
    ylabel('Floor level', 'Interpreter', 'latex');
    title(sprintf('Building Vibration Modes at $t = %.2f$ s', ...
          currentTime), 'Interpreter', 'latex');
    legend({'Mode 1','Mode 2','Mode 3'}, ...
           'Interpreter', 'latex', 'Location', 'south');
    grid on;
    drawnow;
    writeVideo(videoWriter, getframe(figAnim));
end
close(videoWriter);
close(figAnim);

fprintf('\n-- Problem 5 Complete --\n');
% Computational Complexity:
% The generalised eigenvalue problem for an n-by-n system is
% solved via QZ factorisation in O(n^3) time; here n=3, so cost
% is negligible.  For large-scale structural models (n > 1000),
% Lanczos or subspace iteration methods reduce cost to
% O(n * k^2) for the k lowest modes.  Video rendering is
% O(numFrames * n) for mode superposition.  Space complexity is
% O(n^2) for matrices plus O(numFrames) for video frames.
