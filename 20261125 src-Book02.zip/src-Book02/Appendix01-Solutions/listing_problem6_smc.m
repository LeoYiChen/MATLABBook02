%% listing_problem6_smc.m
% Problem 6: Sliding mode control for 2-DOF robot manipulator with payload uncertainty, chattering analysis, and comparison against PD control showing superior robustness to parameter variations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem6_smc
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 6 - Sliding Mode Control
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: Sliding mode control for 2-DOF robot manipulator with
%              payload uncertainty. Implements reaching law, boundary
%              layer, and compares against PD control.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 6: Sliding Mode Control for 2-DOF Robot Manipulator\n');
fprintf('==================================================================\n\n');

%% Robot Parameters (Nominal)
fprintf('=== Robot Manipulator Parameters ===\n');

% Link properties
params.l1 = 1.0;      % Link 1 length (m)
params.l2 = 0.8;      % Link 2 length (m)
params.lc1 = 0.5;     % Link 1 center of mass (m)
params.lc2 = 0.4;     % Link 2 center of mass (m)
params.m1 = 2.0;      % Link 1 mass (kg)
params.m2 = 1.5;      % Link 2 mass (kg) - NOMINAL
params.I1 = 0.1;      % Link 1 inertia (kg m)
params.I2 = 0.05;     % Link 2 inertia (kg m)
params.g = 9.81;      % Gravity (m/s)

% Friction parameters
params.Fv = [0.5; 0.3];   % Viscous friction (N m s/rad)
params.Fc = [0.1; 0.05];  % Coulomb friction (N m)

fprintf('Link 1: length = %.2f m, mass = %.2f kg\n', params.l1, params.m1);
fprintf('Link 2: length = %.2f m, mass = %.2f kg (nominal)\n', params.l2, params.m2);
fprintf('Gravity: %.2f m/s\n\n', params.g);

%% Sliding Mode Controller Parameters
fprintf('=== SMC Controller Design ===\n');

% Sliding surface: s = dot(e) + Lambda * e
smc.Lambda = diag([5, 5]);  % Error dynamics convergence rate

% Switching gains (conservative to handle uncertainty)
smc.K = diag([30, 20]);     % High gain for robustness

% Boundary layer thickness (chattering reduction)
smc.phi = [0.1; 0.1];       % Boundary layer width

fprintf('Sliding surface parameter Lambda:\n');
disp(smc.Lambda);

fprintf('Switching gain K:\n');
disp(smc.K);

fprintf('Boundary layer thickness phi:\n');
disp(smc.phi);

fprintf('Expected time constant: 1/lambda = %.3f s\n\n', 1/smc.Lambda(1,1));

%% PD Controller for Comparison
fprintf('=== PD Controller Design (for comparison) ===\n');

% Tuned for nominal system
pd.Kp = diag([100, 80]);
pd.Kd = diag([20, 15]);

fprintf('Proportional gain Kp:\n');
disp(pd.Kp);
fprintf('Derivative gain Kd:\n');
disp(pd.Kd);
fprintf('\n');

%% Desired Trajectory
fprintf('=== Desired Trajectory Specification ===\n');

% Sinusoidal trajectory for both joints
traj.freq1 = 0.5;    % Joint 1 frequency (Hz)
traj.freq2 = 0.3;    % Joint 2 frequency (Hz)
traj.amp1 = pi/3;    % Joint 1 amplitude (rad) = 60 deg
traj.amp2 = pi/4;    % Joint 2 amplitude (rad) = 45 deg

fprintf('Joint 1: amplitude = %.2f deg, frequency = %.2f Hz\n', ...
    rad2deg(traj.amp1), traj.freq1);
fprintf('Joint 2: amplitude = %.2f deg, frequency = %.2f Hz\n\n', ...
    rad2deg(traj.amp2), traj.freq2);

%% Uncertainty Scenarios
fprintf('=== Uncertainty Scenarios ===\n');

% Scenario 1: Nominal (no uncertainty)
scenarios(1).name = 'Nominal';
scenarios(1).m2_factor = 1.0;
scenarios(1).disturbance = 0;

% Scenario 2: +50% payload (e.g., carrying object)
scenarios(2).name = 'Heavy Payload (+50%)';
scenarios(2).m2_factor = 1.5;
scenarios(2).disturbance = 0;

% Scenario 3: -30% payload (e.g., lighter than expected)
scenarios(3).name = 'Light Payload (-30%)';
scenarios(3).m2_factor = 0.7;
scenarios(3).disturbance = 0;

% Scenario 4: Nominal + external disturbance
scenarios(4).name = 'Nominal + Disturbance';
scenarios(4).m2_factor = 1.0;
scenarios(4).disturbance = 1;  % Flag for disturbance

for i = 1:length(scenarios)
    fprintf('Scenario %d: %s\n', i, scenarios(i).name);
end
fprintf('\n');

%% Simulation Parameters
Tsim = 10;          % Simulation time (s)
dt = 0.001;         % Time step (s)
t = 0:dt:Tsim;
Nt = length(t);

fprintf('=== Simulation Setup ===\n');
fprintf('Duration: %.1f s\n', Tsim);
fprintf('Time step: %.4f s (%.0f Hz)\n', dt, 1/dt);
fprintf('Total samples: %d\n\n', Nt);

%% Run Simulations for Each Scenario
results_smc = cell(length(scenarios), 1);
results_pd = cell(length(scenarios), 1);

for scen = 1:length(scenarios)
    fprintf('=== Running Scenario %d: %s ===\n', scen, scenarios(scen).name);
    
    % Modify parameters for this scenario
    params_actual = params;
    params_actual.m2 = params.m2 * scenarios(scen).m2_factor;
    
    % External disturbance (impulse at t=5s)
    disturbance = zeros(2, Nt);
    if scenarios(scen).disturbance
        dist_idx = find(t >= 5 & t < 5.2);
        disturbance(:, dist_idx) = repmat([5; 3], 1, length(dist_idx));
    end
    
    fprintf('  Actual m2: %.3f kg (%.0f%% of nominal)\n', ...
        params_actual.m2, scenarios(scen).m2_factor * 100);
    
    % Initial conditions
    q0 = [0; 0];
    qd0 = [0; 0];
    x0 = [q0; qd0];
    
    % Desired trajectory
    qd = [traj.amp1 * sin(2*pi*traj.freq1*t);
          traj.amp2 * sin(2*pi*traj.freq2*t)];
    qd_dot = [traj.amp1 * 2*pi*traj.freq1 * cos(2*pi*traj.freq1*t);
              traj.amp2 * 2*pi*traj.freq2 * cos(2*pi*traj.freq2*t)];
    qd_ddot = [-traj.amp1 * (2*pi*traj.freq1)^2 * sin(2*pi*traj.freq1*t);
               -traj.amp2 * (2*pi*traj.freq2)^2 * sin(2*pi*traj.freq2*t)];
    
    % ========== Sliding Mode Control ==========
    fprintf('  Simulating SMC...\n');
    
    [t_smc, x_smc, tau_smc, s_smc] = simulate_smc(t, x0, qd, qd_dot, qd_ddot, ...
        params, params_actual, smc, disturbance);
    
    results_smc{scen}.t = t_smc;
    results_smc{scen}.q = x_smc(:, 1:2)';
    results_smc{scen}.qd = x_smc(:, 3:4)';
    results_smc{scen}.tau = tau_smc;
    results_smc{scen}.s = s_smc;
    results_smc{scen}.error = x_smc(:, 1:2)' - qd;
    
    % ========== PD Control ==========
    fprintf('  Simulating PD...\n');
    
    [t_pd, x_pd, tau_pd] = simulate_pd(t, x0, qd, qd_dot, qd_ddot, ...
        params, params_actual, pd, disturbance);
    
    results_pd{scen}.t = t_pd;
    results_pd{scen}.q = x_pd(:, 1:2)';
    results_pd{scen}.qd = x_pd(:, 3:4)';
    results_pd{scen}.tau = tau_pd;
    results_pd{scen}.error = x_pd(:, 1:2)' - qd;
    
    % Compute performance metrics
    rms_smc = sqrt(mean(results_smc{scen}.error.^2, 2));
    rms_pd = sqrt(mean(results_pd{scen}.error.^2, 2));
    
    max_tau_smc = max(abs(results_smc{scen}.tau), [], 2);
    max_tau_pd = max(abs(results_pd{scen}.tau), [], 2);
    
    fprintf('  Performance (RMS error):\n');
    fprintf('    SMC: Joint1 = %.4f rad (%.2f deg), Joint2 = %.4f rad (%.2f deg)\n', ...
        rms_smc(1), rad2deg(rms_smc(1)), rms_smc(2), rad2deg(rms_smc(2)));
    fprintf('    PD:  Joint1 = %.4f rad (%.2f deg), Joint2 = %.4f rad (%.2f deg)\n', ...
        rms_pd(1), rad2deg(rms_pd(1)), rms_pd(2), rad2deg(rms_pd(2)));
    
    fprintf('  Max control effort:\n');
    fprintf('    SMC: tau1 = %.2f N m, tau2 = %.2f N m\n', ...
        max_tau_smc(1), max_tau_smc(2));
    fprintf('    PD:  tau1 = %.2f N m, tau2 = %.2f N m\n\n', ...
        max_tau_pd(1), max_tau_pd(2));
end

%% Plot Results for Nominal Case
fprintf('=== Generating Plots ===\n');

scen = 1;  % Nominal scenario

figure('Position', [50, 50, 1400, 900]);

% Joint 1 tracking
subplot(3,3,1);
plot(t, rad2deg(qd(1,:)), 'k-', 'LineWidth', 1.5, 'DisplayName', 'Desired');
hold on;
plot(results_smc{scen}.t, rad2deg(results_smc{scen}.q(1,:)), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'SMC');
plot(results_pd{scen}.t, rad2deg(results_pd{scen}.q(1,:)), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'PD');
grid on;
ylabel('$q_1$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
title('Joint 1 Position', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Joint 2 tracking
subplot(3,3,2);
plot(t, rad2deg(qd(2,:)), 'k-', 'LineWidth', 1.5, 'DisplayName', 'Desired');
hold on;
plot(results_smc{scen}.t, rad2deg(results_smc{scen}.q(2,:)), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'SMC');
plot(results_pd{scen}.t, rad2deg(results_pd{scen}.q(2,:)), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'PD');
grid on;
ylabel('$q_2$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
title('Joint 2 Position', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Tracking errors
subplot(3,3,3);
plot(results_smc{scen}.t, rad2deg(results_smc{scen}.error(1,:)), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'SMC J1');
hold on;
plot(results_smc{scen}.t, rad2deg(results_smc{scen}.error(2,:)), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'SMC J2');
plot(results_pd{scen}.t, rad2deg(results_pd{scen}.error(1,:)), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'PD J1');
plot(results_pd{scen}.t, rad2deg(results_pd{scen}.error(2,:)), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'PD J2');
grid on;
ylabel('Error (deg)', 'Interpreter', 'latex', 'FontSize', 10);
title('Tracking Errors', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 8);

% Control torques Joint 1
subplot(3,3,4);
plot(results_smc{scen}.t, results_smc{scen}.tau(1,:), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'SMC');
hold on;
plot(results_pd{scen}.t, results_pd{scen}.tau(1,:), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'PD');
grid on;
ylabel('$\tau_1$ (N m)', 'Interpreter', 'latex', 'FontSize', 10);
title('Control Torque Joint 1', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Control torques Joint 2
subplot(3,3,5);
plot(results_smc{scen}.t, results_smc{scen}.tau(2,:), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', 'SMC');
hold on;
plot(results_pd{scen}.t, results_pd{scen}.tau(2,:), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', 'PD');
grid on;
ylabel('$\tau_2$ (N m)', 'Interpreter', 'latex', 'FontSize', 10);
title('Control Torque Joint 2', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Sliding surface
subplot(3,3,6);
plot(results_smc{scen}.t, results_smc{scen}.s(1,:), 'b-', ...
    'LineWidth', 1.2, 'DisplayName', '$s_1$');
hold on;
plot(results_smc{scen}.t, results_smc{scen}.s(2,:), 'r-', ...
    'LineWidth', 1.2, 'DisplayName', '$s_2$');
yline(smc.phi(1), 'b-', 'Boundary', 'LineWidth', 1);
yline(-smc.phi(1), 'b-', 'LineWidth', 1);
yline(smc.phi(2), 'r-', 'Boundary', 'LineWidth', 1);
yline(-smc.phi(2), 'r-', 'LineWidth', 1);
grid on;
ylabel('$s$', 'Interpreter', 'latex', 'FontSize', 10);
title('Sliding Surface', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

% Phase portrait Joint 1
subplot(3,3,7);
plot(rad2deg(results_smc{scen}.error(1,:)), ...
    rad2deg(results_smc{scen}.qd(1,:) - qd_dot(1,:)), 'b-', 'LineWidth', 1.2);
hold on;
plot(rad2deg(results_pd{scen}.error(1,:)), ...
    rad2deg(results_pd{scen}.qd(1,:) - qd_dot(1,:)), 'r-', 'LineWidth', 1.2);
% Sliding line: dot(e) + lambda*e = 0
e_range = linspace(-5, 5, 100);
plot(e_range, -smc.Lambda(1,1)*e_range, 'k-', 'LineWidth', 1.5, ...
    'DisplayName', 'Sliding line');
grid on;
xlabel('$e_1$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$\dot{e}_1$ (deg/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('Phase Portrait J1', 'Interpreter', 'latex', 'FontSize', 12);
legend({'SMC', 'PD', 'Sliding'}, 'Interpreter', 'latex', 'Location', 'best');

% Phase portrait Joint 2
subplot(3,3,8);
plot(rad2deg(results_smc{scen}.error(2,:)), ...
    rad2deg(results_smc{scen}.qd(2,:) - qd_dot(2,:)), 'b-', 'LineWidth', 1.2);
hold on;
plot(rad2deg(results_pd{scen}.error(2,:)), ...
    rad2deg(results_pd{scen}.qd(2,:) - qd_dot(2,:)), 'r-', 'LineWidth', 1.2);
plot(e_range, -smc.Lambda(2,2)*e_range, 'k-', 'LineWidth', 1.5);
grid on;
xlabel('$e_2$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$\dot{e}_2$ (deg/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('Phase Portrait J2', 'Interpreter', 'latex', 'FontSize', 12);
legend({'SMC', 'PD', 'Sliding'}, 'Interpreter', 'latex', 'Location', 'best');

% End-effector trajectory
subplot(3,3,9);
% Forward kinematics
x1_smc = params.l1 * cos(results_smc{scen}.q(1,:));
y1_smc = params.l1 * sin(results_smc{scen}.q(1,:));
x2_smc = x1_smc + params.l2 * cos(results_smc{scen}.q(1,:) + results_smc{scen}.q(2,:));
y2_smc = y1_smc + params.l2 * sin(results_smc{scen}.q(1,:) + results_smc{scen}.q(2,:));

x1_des = params.l1 * cos(qd(1,:));
y1_des = params.l1 * sin(qd(1,:));
x2_des = x1_des + params.l2 * cos(qd(1,:) + qd(2,:));
y2_des = y1_des + params.l2 * sin(qd(1,:) + qd(2,:));

plot(x2_des, y2_des, 'k-', 'LineWidth', 1.5, 'DisplayName', 'Desired');
hold on;
plot(x2_smc, y2_smc, 'b-', 'LineWidth', 1.2, 'DisplayName', 'SMC');
grid on;
axis equal;
xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 10);
title('End-Effector Trajectory', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');

sgtitle('Scenario 1: Nominal Parameters', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem06_Nominal.fig');
saveas(gcf, 'Problem06_Nominal.eps', 'epsc');

%% Robustness Comparison: All Scenarios
figure('Position', [100, 100, 1400, 800]);

for scen = 1:length(scenarios)
    % Joint 1 error
    subplot(2,4,scen);
    plot(results_smc{scen}.t, rad2deg(results_smc{scen}.error(1,:)), 'b-', ...
        'LineWidth', 1.2, 'DisplayName', 'SMC');
    hold on;
    plot(results_pd{scen}.t, rad2deg(results_pd{scen}.error(1,:)), 'r-', ...
        'LineWidth', 1.2, 'DisplayName', 'PD');
    grid on;
    ylabel('$e_1$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
    title(scenarios(scen).name, 'Interpreter', 'latex', 'FontSize', 11);
    if scen == 1
        legend('Interpreter', 'latex', 'Location', 'best');
    end
    
    % Joint 2 error
    subplot(2,4,scen+4);
    plot(results_smc{scen}.t, rad2deg(results_smc{scen}.error(2,:)), 'b-', ...
        'LineWidth', 1.2, 'DisplayName', 'SMC');
    hold on;
    plot(results_pd{scen}.t, rad2deg(results_pd{scen}.error(2,:)), 'r-', ...
        'LineWidth', 1.2, 'DisplayName', 'PD');
    grid on;
    xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('$e_2$ (deg)', 'Interpreter', 'latex', 'FontSize', 10);
end

sgtitle('Tracking Errors: Robustness Comparison', 'Interpreter', 'latex', 'FontSize', 14);
saveas(gcf, 'Problem06_Robustness.fig');
saveas(gcf, 'Problem06_Robustness.eps', 'epsc');

%% Chattering Analysis
fprintf('=== Chattering Analysis ===\n');

scen = 1;
% Compute control derivative (chattering indicator)
tau_diff_smc = diff(results_smc{scen}.tau, 1, 2) / dt;
tau_diff_pd = diff(results_pd{scen}.tau, 1, 2) / dt;

chatter_smc = std(tau_diff_smc, 0, 2);
chatter_pd = std(tau_diff_pd, 0, 2);

fprintf('Control derivative std (chattering metric):\n');
fprintf('  SMC: Joint1 = %.2f, Joint2 = %.2f\n', chatter_smc(1), chatter_smc(2));
fprintf('  PD:  Joint1 = %.2f, Joint2 = %.2f\n\n', chatter_pd(1), chatter_pd(2));

% Plot chattering
figure('Position', [150, 150, 1200, 500]);

subplot(1,2,1);
t_diff = results_smc{scen}.t(1:end-1);
plot(t_diff, tau_diff_smc(1,:), 'b-', 'LineWidth', 0.8);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$d\tau_1/dt$ (N m/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('SMC Control Derivative J1 (Chattering)', 'Interpreter', 'latex', 'FontSize', 12);
xlim([5 6]);  % Zoom to show detail

subplot(1,2,2);
plot(t_diff, tau_diff_smc(2,:), 'b-', 'LineWidth', 0.8);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('$d\tau_2/dt$ (N m/s)', 'Interpreter', 'latex', 'FontSize', 10);
title('SMC Control Derivative J2 (Chattering)', 'Interpreter', 'latex', 'FontSize', 12);
xlim([5 6]);

saveas(gcf, 'Problem06_Chattering.fig');
saveas(gcf, 'Problem06_Chattering.eps', 'epsc');

fprintf('Plots saved.\n\n');
fprintf('=== Problem 6 Complete ===\n');

%% Simulation Functions

function [t_out, x_out, tau_out, s_out] = simulate_smc(t, x0, qd, qd_dot, qd_ddot, ...
    params_nom, params_act, smc, disturbance)
    % Simulate robot with sliding mode control
    
    dt = t(2) - t(1);
    Nt = length(t);
    
    % State: [q1; q2; q1_dot; q2_dot]
    x = x0;
    x_out = zeros(Nt, 4);
    tau_out = zeros(2, Nt);
    s_out = zeros(2, Nt);
    
    for i = 1:Nt
        % Current state
        q = x(1:2);
        q_dot = x(3:4);
        
        % Tracking error
        e = q - qd(:,i);
        e_dot = q_dot - qd_dot(:,i);
        
        % Sliding surface
        s = e_dot + smc.Lambda * e;
        
        % Control law (using nominal parameters)
        [M_nom, C_nom, G_nom] = robot_dynamics(q, q_dot, params_nom);
        
        % Equivalent control
        tau_eq = M_nom * (qd_ddot(:,i) - smc.Lambda * e_dot) + ...
                 C_nom * q_dot + G_nom;
        
        % Switching control with boundary layer
        tau_sw = -smc.K * sat(s ./ smc.phi);
        
        % Total control
        tau = tau_eq + tau_sw + disturbance(:,i);
        
        % Robot dynamics (with actual parameters)
        [M_act, C_act, G_act] = robot_dynamics(q, q_dot, params_act);
        F_act = params_act.Fv .* q_dot + params_act.Fc .* sign(q_dot);
        
        % Equations of motion: M*q_ddot = tau - C*q_dot - G - F
        q_ddot = M_act \ (tau - C_act * q_dot - G_act - F_act);
        
        % Store
        x_out(i,:) = x';
        tau_out(:,i) = tau;
        s_out(:,i) = s;
        
        % Integrate (Euler)
        x = x + dt * [q_dot; q_ddot];
    end
    
    t_out = t;
end

function [t_out, x_out, tau_out] = simulate_pd(t, x0, qd, qd_dot, qd_ddot, ...
    params_nom, params_act, pd, disturbance)
    % Simulate robot with PD control
    
    dt = t(2) - t(1);
    Nt = length(t);
    
    x = x0;
    x_out = zeros(Nt, 4);
    tau_out = zeros(2, Nt);
    
    for i = 1:Nt
        q = x(1:2);
        q_dot = x(3:4);
        
        % Tracking error
        e = q - qd(:,i);
        e_dot = q_dot - qd_dot(:,i);
        
        % PD control law
        tau = -pd.Kp * e - pd.Kd * e_dot + disturbance(:,i);
        
        % Robot dynamics
        [M_act, C_act, G_act] = robot_dynamics(q, q_dot, params_act);
        F_act = params_act.Fv .* q_dot + params_act.Fc .* sign(q_dot);
        
        q_ddot = M_act \ (tau - C_act * q_dot - G_act - F_act);
        
        x_out(i,:) = x';
        tau_out(:,i) = tau;
        
        x = x + dt * [q_dot; q_ddot];
    end
    
    t_out = t;
end

function [M, C, G] = robot_dynamics(q, q_dot, params)
    % Compute robot dynamics matrices
    
    % Inertia matrix
    m11 = params.I1 + params.I2 + params.m2*params.l1^2 + ...
          2*params.m2*params.l1*params.lc2*cos(q(2));
    m12 = params.I2 + params.m2*params.l1*params.lc2*cos(q(2));
    m22 = params.I2;
    
    M = [m11, m12; m12, m22];
    
    % Coriolis matrix
    h = -params.m2*params.l1*params.lc2*sin(q(2));
    C = [h*q_dot(2), h*(q_dot(1) + q_dot(2));
         -h*q_dot(1), 0];
    
    % Gravity vector
    g1 = (params.m1*params.lc1 + params.m2*params.l1)*params.g*cos(q(1)) + ...
         params.m2*params.lc2*params.g*cos(q(1) + q(2));
    g2 = params.m2*params.lc2*params.g*cos(q(1) + q(2));
    
    G = [g1; g2];
end

function y = sat(x)
    % Saturation function for boundary layer
    y = max(min(x, 1), -1);
end
