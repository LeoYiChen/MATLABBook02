%% Appendix01-Solutions_code_210.m
% Transfer Learning for Stellar Spectra (Condensed)
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
import torch
import torchvision.models as models
import torch.nn as nn
from scipy.signal import cwt, ricker

# ============================================================================
# Spectra to Spectrogram Conversion
# ============================================================================
def spectrum_to_spectrogram(wavelengths, flux, widths=np.arange(1, 31)):
    """Convert 1D spectrum to 2D spectrogram using Continuous Wavelet Transform"""
    coefficients = cwt(flux, ricker, widths)
    # Normalize to [0, 255]
    spectrogram = (coefficients - coefficients.min()) / (coefficients.max() - coefficients.min())
    spectrogram = (spectrogram * 255).astype(np.uint8)
    # Resize to 224x224 for ResNet
    spectrogram_rgb = np.stack([spectrogram]*3, axis=0)  # Create RGB channels
    return torch.tensor(spectrogram_rgb, dtype=torch.float32) / 255.0

# ============================================================================
# Transfer Learning Setup
# ============================================================================
# Load pre-trained ResNet-18
model = models.resnet18(pretrained=True)

# Freeze early layers (feature extraction)
for param in model.parameters():
    param.requires_grad = False

# Replace final fully connected layer
num_classes = 7  # O, B, A, F, G, K, M
model.fc = nn.Linear(model.fc.in_features, num_classes)

# Fine-tune only last layer initially
optimizer = torch.optim.Adam(model.fc.parameters(), lr=1e-3)

# After 5 epochs, unfreeze layer4 for fine-tuning
for param in model.layer4.parameters():
    param.requires_grad = True

optimizer = torch.optim.Adam([
    {'params': model.layer4.parameters(), 'lr': 1e-4},
    {'params': model.fc.parameters(), 'lr': 1e-3}
], lr=1e-3)

# Training loop (similar to Solution 4)
# ...
