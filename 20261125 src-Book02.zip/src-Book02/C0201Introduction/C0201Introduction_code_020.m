%% C0201Introduction_code_020.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Benchmark test suite for numerical integration


runIntegrationBenchmarks();

% Local functions (moved to end so this listing is a valid MATLAB script)
function runIntegrationBenchmarks()
    % RUNINTEGRATIONBENCHMARKS Test integration accuracy
    
    fprintf('\\textbf{Numerical Integration Benchmark Tests}\n');
    fprintf('===============================================\n\n');
    
    % Test 1: Polynomial (should be exact for high-order methods)
    fprintf('Test 1: Polynomial $\\int_0^1 x^4 dx$\n');
    f1 = @(x) x.^4;
    exactValue1 = 1/5;  % Analytical solution
    
    trapzValue = trapz(linspace(0, 1, 1000), f1(linspace(0, 1, 1000)));
    integralValue = integral(f1, 0, 1);
    
    fprintf('  Exact value: %.10f\n', exactValue1);
    fprintf('  Trapz approximation: %.10f (error: %.2e)\n', ...
        trapzValue, abs(trapzValue - exactValue1));
    fprintf('  Adaptive quad: %.10f (error: %.2e)\n\n', ...
        integralValue, abs(integralValue - exactValue1));
    
    % Test 2: Trigonometric
    fprintf('Test 2: Trigonometric $\\int_0^{\\pi} \\sin(x) dx$\n');
    f2 = @(x) sin(x);
    exactValue2 = 2;
    
    integralValue2 = integral(f2, 0, pi);
    fprintf('  Exact value: %.10f\n', exactValue2);
    fprintf('  Computed value: %.10f (error: %.2e)\n\n', ...
        integralValue2, abs(integralValue2 - exactValue2));
    
    % Test 3: Gaussian (challenging)
    fprintf('Test 3: Gaussian $\\int_{-\\infty}^{\\infty} e^{-x^2} dx$\n');
    f3 = @(x) exp(-x.^2);
    exactValue3 = sqrt(pi);
    
    integralValue3 = integral(f3, -Inf, Inf);
    fprintf('  Exact value: %.10f\n', exactValue3);
    fprintf('  Computed value: %.10f (error: %.2e)\n\n', ...
        integralValue3, abs(integralValue3 - exactValue3));
    
    % Test 4: Discontinuous (stress test)
    fprintf('Test 4: Discontinuous $\\int_0^1 H(x-0.5) dx$ (Heaviside)\n');
    f4 = @(x) double(x >= 0.5);  % Heaviside function
    exactValue4 = 0.5;
    
    integralValue4 = integral(f4, 0, 1, 'AbsTol', 1e-10, 'RelTol', 1e-8);
    fprintf('  Exact value: %.10f\n', exactValue4);
    fprintf('  Computed value: %.10f (error: %.2e)\n\n', ...
        integralValue4, abs(integralValue4 - exactValue4));
end
