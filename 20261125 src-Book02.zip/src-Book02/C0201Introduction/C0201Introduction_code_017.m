%% C0201Introduction_code_017.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Diagnosis function

% Example usage
A = rand(3, 4);
B = rand(4, 2);
checkDimensions(A, B, 'multiply');  % Valid
% checkDimensions(A, B, 'add');     % Error

% Common fixes:
% 1. Transpose if needed
C = A * B;      % Works: 3*x4 * 4*x2 = 3*x2
% D = A + B;    % Error
D = A' + B;     % Works if intended: 4*x3 + 4*x2 still error

% 2. Reshape arrays
vector = 1:12;
matrix = reshape(vector, 3, 4);  % Convert to 3*x4

% 3. Use element-wise operations when appropriate
x = [1; 2; 3];
y = [4; 5; 6];
z = x .* y;  % Element-wise multiplication [4; 10; 18]
% NOT: z = x * y;  % Error: 3*x1 * 3*x1 invalid for matrix multiplication

% Local functions (moved to end so this listing is a valid MATLAB script)
function checkDimensions(A, B, operation)
    fprintf('Matrix A: %d x %d\n', size(A, 1), size(A, 2));
    fprintf('Matrix B: %d x %d\n', size(B, 1), size(B, 2));
    
    switch operation
        case 'multiply'
            if size(A, 2) ~= size(B, 1)
                error(['Incompatible dimensions for multiplication.\n', ...
                    'A columns (%d) must equal B rows (%d)'], ...
                    size(A, 2), size(B, 1));
            end
            fprintf('Valid for multiplication: Result will be %d x %d\n', ...
                size(A, 1), size(B, 2));
            
        case 'add'
            if ~isequal(size(A), size(B))
                error(['Incompatible dimensions for addition.\n', ...
                    'Matrices must have same size']);
            end
            fprintf('Valid for addition\n');
    end
end
