%% C0201Introduction_code_013.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% INEFFICIENT: Dynamic growth
n = 100000;
tic;
data = [];
for i = 1:n
    data(i) = rand();  % Array grows each iteration
end
timeDynamic = toc;

% EFFICIENT: Preallocate
tic;
data = zeros(n, 1);
for i = 1:n
    data(i) = rand();
end
timePrealloc = toc;

fprintf('Dynamic growth: %.4f seconds\n', timeDynamic);
fprintf('Preallocated: %.4f seconds\n', timePrealloc);
fprintf('Speedup: %.1fx\n', timeDynamic / timePrealloc);
% Typical speedup: 100-1000*x for large arrays
