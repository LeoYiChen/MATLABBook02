%% C020201Maths_Fundamental_code_113.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Bayesian t-test approximation using bootstrap
numBootstrap = 100000;
group1Boot = bootstrp(numBootstrap, @mean, group1Data);
group2Boot = bootstrp(numBootstrap, @mean, group2Data);

differenceBoot = group2Boot - group1Boot;

% Credible interval (Bayesian confidence interval)
credibleInterval = prctile(differenceBoot, [2.5, 97.5]);

% Probability that group2 mean exceeds group1 mean
probGreater = mean(differenceBoot > 0);

fprintf('95\\%% Credible Interval: [%.2f, %.2f]\n', ...
    credibleInterval(1), credibleInterval(2));
fprintf('Probability(mu2 > mu1): %.3f\n', probGreater);
