%% C0201Introduction_code_018.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Troubleshooting optimisation convergence

% 1. Check objective function is well-defined
objectiveFunc = @(x) (x(1) - 2)^2 + (x(2) + 3)^2;

% Test at initial point
x0 = [0; 0];
f0 = objectiveFunc(x0);
if ~isfinite(f0)
    error('Objective function returns non-finite value at x0');
end

% 2. Verify gradient if provided
epsilon = 1e-7;
analyticGrad = @(x) [2*(x(1)-2); 2*(x(2)+3)];

% Numerical gradient check
numericalGrad = zeros(2, 1);
for i = 1:2
    x_plus = x0;
    x_plus(i) = x_plus(i) + epsilon;
    numericalGrad(i) = (objectiveFunc(x_plus) - f0) / epsilon;
end

gradError = norm(analyticGrad(x0) - numericalGrad) / ...
    (norm(numericalGrad) + eps);

fprintf('Gradient error: %.2e ', gradError);
if gradError < 1e-5
    fprintf('(PASS - gradient appears correct)\n');
else
    fprintf('(FAIL - check gradient implementation)\n');
end

% 3. Try different initialisations
numTrials = 10;
bestFval = Inf;
bestX = [];

for trial = 1:numTrials
    x0_trial = randn(2, 1) * 10;  % Random initialisation
    
    try
        [x_trial, fval_trial] = fminunc(objectiveFunc, x0_trial, ...
            optimoptions('fminunc', 'Display', 'off'));
        
        if fval_trial < bestFval
            bestFval = fval_trial;
            bestX = x_trial;
        end
    catch ME
        fprintf('Trial %d failed: %s\n', trial, ME.message);
    end
end

fprintf('\nBest solution found: (%.4f, %.4f) with f = %.4e\n', ...
    bestX(1), bestX(2), bestFval);

% 4. Adjust algorithmic parameters
options = optimoptions('fminunc', ...
    'MaxIterations', 1000, ...           % Increase if not converging
    'MaxFunctionEvaluations', 3000, ...
    'OptimalityTolerance', 1e-6, ...     % Relax if too strict
    'StepTolerance', 1e-10, ...
    'FiniteDifferenceStepSize', 1e-8, ...
    'Display', 'iter-detailed');         % Monitor progress

[x_final, fval_final, exitflag, output] = fminunc(...
    objectiveFunc, x0, options);

% Interpret exit flags
switch exitflag
    case 1
        fprintf('SUCCESS: First-order optimality satisfied\n');
    case 0
        fprintf('WARNING: Max iterations reached\n');
    case -1
        fprintf('ERROR: Stopped by output function\n');
    case -2
        fprintf('ERROR: No feasible point found\n');
    case -3
        fprintf('ERROR: Objective unbounded\n');
    otherwise
        fprintf('UNKNOWN exit flag: %d\n', exitflag);
end

% 5. Scale variables for better conditioning
% If variables have very different magnitudes
xScaled = x0 ./ [1000; 1];  % Scale first variable
objScaled = @(xs) objectiveFunc(xs .* [1000; 1]);
[xs_opt, ~] = fminunc(objScaled, xScaled, options);
x_opt = xs_opt .* [1000; 1];  % Unscale result
