%% Appendix02-FAQs_code_062.m
% Complete Implementation of the MATLAB Code Simplifier
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [status, statusReport] = matlab_code_simplifier(inputPath)
    % MATLAB_CODE_SIMPLIFIER - Enterprise-grade AI Code Purifier.
    % Author: Dr Leo Chen
    % Status Codes: 
    %   0   - Success: Processing completed without issues.
    %   101 - Path Error: Input path does not exist.
    %   102 - Folder Error: Directory creation failed.
    %   201 - Read Error: File access denied.
    %   202 - Write Error: Output directory is read-only.
    %   301 - Logic Error: Refactoring regex failed.

    status = 0;
    statusReport = struct('processedCount', 0, 'errorFiles', {}, 'details', {});

    % 1. Source Validation (Status 101)
    if ~exist(inputPath, 'file') && ~exist(inputPath, 'dir')
        status = 101;
        disp('\textsf{Status 101: Source path is unrecognised.}');
        return;
    end

    % 2. Path Logic and Output Generation
    if isfile(inputPath)
        targetFiles = {inputPath};
        [parentDirectory, ~, ~] = fileparts(inputPath);
        outputDirectory = fullfile(parentDirectory, 'simplified_output');
    else
        filesStruct = dir(fullfile(inputPath, '*.m'));
        targetFiles = fullfile({filesStruct.folder}, {filesStruct.name});
        outputDirectory = fullfile(inputPath, 'simplified_output');
    end

    % 3. Directory Setup (Status 102)
    if ~exist(outputDirectory, 'dir')
        [isCreated, folderError] = mkdir(outputDirectory);
        if ~isCreated
            status = 102;
            statusReport.details = folderError;
            return;
        end
    end

    % 4. Processing Loop
    for fileIndex = 1:length(targetFiles)
        currentPath = targetFiles{fileIndex};
        [~, fileName, fileExt] = fileparts(currentPath);
        
        try
            % File Access (Status 201)
            fileIdRead = fopen(currentPath, 'r');
            if fileIdRead == -1, throw(MException('IO:Read', 'Access Denied')); end
            rawCode = fread(fileIdRead, '*char')';
            fclose(fileIdRead);
            
            % Refactoring (Status 301)
            refinedCode = applyRefactoring(rawCode);
            
            % Save Results (Status 202)
            outPath = fullfile(outputDirectory, [fileName, fileExt]);
            fileIdWrite = fopen(outPath, 'w');
            if fileIdWrite == -1, throw(MException('IO:Write', 'Write Permission Error')); end
            fprintf(fileIdWrite, '%s', refinedCode);
            fclose(fileIdWrite);
            
            statusReport.processedCount = statusReport.processedCount + 1;
            
        catch exception
            statusReport.errorFiles{end+1} = currentPath;
            if strcmp(exception.identifier, 'IO:Read'), status = 201;
            elseif strcmp(exception.identifier, 'IO:Write'), status = 202;
            else, status = 301; end
        end
    end
    disp(['\textsf{Refactoring concluded. System Status Code: }', num2str(status)]);
end

function refinedCode = applyRefactoring(inputCode)
    % A. Guard Clauses: Flatten deep nesting
    refinedCode = regexprep(inputCode, 'if\s+(.*?)\n\s*(.*?)\nelse\n\s*return\nend', 'if ~($1), return; end\n$2');
    
    % B. Noise Reduction: Remove redundant AI chatter
    refinedCode = regexprep(refinedCode, '%.*(define|variable|initialize|loop).*[\r\n]', '\n');
    
    % C. Standardisation: Force camelCase for functions
    tokens = regexp(refinedCode, 'function\s+(\w+)\(', 'tokens');
    for i = 1:length(tokens)
        oldName = tokens{i}{1};
        if contains(oldName, '_')
            newName = regexprep(oldName, '_(\w)', '${upper($1)}');
            newName(1) = lower(newName(1));
            refinedCode = strrep(refinedCode, oldName, newName);
        end
    end
end
