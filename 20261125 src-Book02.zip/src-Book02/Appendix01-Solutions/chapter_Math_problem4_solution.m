%% chapter_Math_problem4_solution.m
% System of linear equations solution.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem4_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem4_LinearSystem()
    % PROBLEM4_LINEARSYSTEM Comprehensive solution for systems of linear equations
    %
    % This function demonstrates multiple methods for solving Ax = b:
    % - Gaussian elimination with partial pivoting (manual implementation)
    % - LU decomposition
    % - MATLAB backslash operator
    % - Cramer's rule (for comparison)
    % - Iterative methods (Jacobi, Gauss-Seidel)
    % - Error analysis and verification
    % - Visualization of solution geometry
    %
    % Author: Dr Yi Chen
    % Date: 2025
    % MATLAB Version: R2023b or later
    
    fprintf('\n=== Problem 4: System of Linear Equations ===\n\n');
    
    % Define system: Ax = b
    A = [2, 1, -1; 
         -3, -1, 2; 
         -2, 1, 2];
    b = [8; -11; -3];
    
    fprintf('System of equations:\n');
    fprintf('  2x + y - z = 8\n');
    fprintf('  -3x - y + 2z = -11\n');
    fprintf('  -2x + y + 2z = -3\n\n');
    
    fprintf('Matrix form: Ax = b\n');
    fprintf('A =\n');
    disp(A);
    fprintf('b =\n');
    disp(b);
    
    % Check system properties
    fprintf('=== System Analysis ===\n\n');
    analyzeSystem(A, b);
    
    % Method 1: Gaussian elimination (manual)
    fprintf('\n=== Method 1: Gaussian Elimination ===\n\n');
    x_gauss = gaussianElimination(A, b);
    verifyMethod('Gaussian Elimination', x_gauss, A, b);
    
    % Method 2: LU decomposition
    fprintf('\n=== Method 2: LU Decomposition ===\n\n');
    x_lu = solveLU(A, b);
    verifyMethod('LU Decomposition', x_lu, A, b);
    
    % Method 3: MATLAB backslash
    fprintf('\n=== Method 3: MATLAB Backslash ===\n\n');
    x_backslash = A \ b;
    verifyMethod('MATLAB Backslash', x_backslash, A, b);
    
    % Method 4: Matrix inverse (not recommended!)
    fprintf('\n=== Method 4: Matrix Inverse (pedagogical only) ===\n\n');
    x_inv = inv(A) * b;
    verifyMethod('Matrix Inverse', x_inv, A, b);
    
    % Method 5: Cramer's rule
    fprintf('\n=== Method 5: Cramer''s Rule ===\n\n');
    x_cramer = cramersRule(A, b);
    verifyMethod('Cramer''s Rule', x_cramer, A, b);
    
    % Comparison of all methods
    fprintf('\n=== Method Comparison ===\n\n');
    compareMethods(x_gauss, x_lu, x_backslash, x_inv, x_cramer);
    
    % Iterative methods
    fprintf('\n=== Iterative Methods ===\n\n');
    demonstrateIterative(A, b, x_backslash);
    
    % Geometric visualization
    fprintf('\n=== Geometric Interpretation ===\n\n');
    visualizeSystem(A, b, x_backslash);
    
    % Sensitivity analysis
    fprintf('\n=== Sensitivity Analysis ===\n\n');
    sensitivityAnalysis(A, b, x_backslash);
    
    fprintf('\nAnalysis complete!\n');
end

function analyzeSystem(A, b)
    % ANALYZESYSTEM Check system properties and solvability
    
    n = size(A, 1);
    m = size(A, 2);
    
    fprintf('System dimensions: %d equations, %d unknowns\n', n, m);
    
    % Determinant
    det_A = det(A);
    fprintf('\nDeterminant: det(A) = %.10f\n', det_A);
    
    if abs(det_A) < eps
        fprintf('  ✗ Matrix is SINGULAR (det ≈ 0)\n');
        fprintf('  뿯↽ System has no unique solution\n');
    else
        fprintf('  ✓ Matrix is INVERTIBLE (det ≠ 0)\n');
        fprintf('  뿯↽ System has unique solution\n');
    end
    
    % Rank
    rank_A = rank(A);
    rank_Ab = rank([A, b]);
    fprintf('\nRank analysis:\n');
    fprintf('  rank(A) = %d\n', rank_A);
    fprintf('  rank([A|b]) = %d\n', rank_Ab);
    
    if rank_A == rank_Ab
        if rank_A == n
            fprintf('  뿯↽ System is CONSISTENT with UNIQUE solution\n');
        else
            fprintf('  뿯↽ System is CONSISTENT with INFINITE solutions\n');
        end
    else
        fprintf('  뿯↽ System is INCONSISTENT (no solution)\n');
    end
    
    % Condition number
    kappa = cond(A);
    fprintf('\nCondition number: 뿯ν(A) = %.6f\n', kappa);
    
    if kappa < 10
        fprintf('  뿯↽ WELL-CONDITIONED (stable, accurate)\n');
    elseif kappa < 100
        fprintf('  뿯↽ MODERATELY conditioned\n');
    elseif kappa < 1000
        fprintf('  뿯↽ POORLY conditioned (careful!)\n');
    else
        fprintf('  뿯↽ ILL-CONDITIONED (numerically unstable!)\n');
    end
    
    fprintf('  Expected loss of accuracy: ~%.1f decimal digits\n', log10(kappa));
    
    % Matrix structure
    fprintf('\nMatrix structure:\n');
    fprintf('  Symmetric: %s\n', yesno(isequal(A, A')));
    fprintf('  Diagonal: %s\n', yesno(all(all(A == diag(diag(A))))));
    fprintf('  Upper triangular: %s\n', yesno(all(all(tril(A,-1) == 0))));
    fprintf('  Lower triangular: %s\n', yesno(all(all(triu(A,1) == 0))));
    fprintf('  Sparse: %s (%.1f%% nonzero)\n', ...
        yesno(nnz(A) < 0.5*numel(A)), 100*nnz(A)/numel(A));
    
    % Check diagonal dominance (important for iterative methods)
    is_diag_dom = true;
    for i = 1:n
        row_sum = sum(abs(A(i,:))) - abs(A(i,i));
        if abs(A(i,i)) <= row_sum
            is_diag_dom = false;
            break;
        end
    end
    fprintf('  Diagonally dominant: %s\n', yesno(is_diag_dom));
    if is_diag_dom
        fprintf('    뿯↽ Iterative methods (Jacobi, Gauss-Seidel) will converge\n');
    else
        fprintf('    뿯↽ Iterative methods may not converge\n');
    end
end

function x = gaussianElimination(A, b)
    % GAUSSIANELIMINATION Manual implementation with partial pivoting
    
    fprintf('Performing Gaussian elimination with partial pivoting...\n\n');
    
    n = length(b);
    Aug = [A, b];  % Augmented matrix
    
    fprintf('Initial augmented matrix [A|b]:\n');
    displayAugmented(Aug);
    
    % Forward elimination
    fprintf('\n-- Forward Elimination --\n\n');
    
    for k = 1:n-1
        fprintf('Step %d: Eliminate column %d\n', k, k);
        
        % Partial pivoting: find row with largest |a_kk|
        [~, max_row] = max(abs(Aug(k:n, k)));
        max_row = max_row + k - 1;
        
        if max_row ~= k
            fprintf('  Pivoting: Swap row %d 뿯↽ row %d\n', k, max_row);
            Aug([k, max_row], :) = Aug([max_row, k], :);
        end
        
        pivot = Aug(k, k);
        fprintf('  Pivot element: a_%d%d = %.6f\n', k, k, pivot);
        
        if abs(pivot) < eps
            error('Zero pivot encountered! Matrix is singular.');
        end
        
        % Eliminate below pivot
        for i = k+1:n
            multiplier = Aug(i, k) / pivot;
            fprintf('  Row %d: R%d 뿯↽ R%d - (%.6f) 뿯½ R%d\n', ...
                i, i, i, multiplier, k);
            Aug(i, :) = Aug(i, :) - multiplier * Aug(k, :);
        end
        
        fprintf('  Result:\n');
        displayAugmented(Aug);
        fprintf('\n');
    end
    
    % Back substitution
    fprintf('-- Back Substitution --\n\n');
    
    x = zeros(n, 1);
    
    % Last equation
    x(n) = Aug(n, n+1) / Aug(n, n);
    fprintf('x_%d = %.6f / %.6f = %.10f\n', n, Aug(n,n+1), Aug(n,n), x(n));
    
    % Remaining equations (bottom to top)
    for i = n-1:-1:1
        sum_term = Aug(i, i+1:n) * x(i+1:n);
        x(i) = (Aug(i, n+1) - sum_term) / Aug(i, i);
        fprintf('x_%d = (%.6f - %.6f) / %.6f = %.10f\n', ...
            i, Aug(i,n+1), sum_term, Aug(i,i), x(i));
    end
    
    fprintf('\nSolution vector:\n');
    fprintf('x = [%.10f, %.10f, %.10f]''\n', x);
end

function displayAugmented(Aug)
    % DISPLAYAUGMENTED Pretty print augmented matrix
    n = size(Aug, 1);
    for i = 1:n
        fprintf('  [ ');
        for j = 1:n
            fprintf('%8.4f ', Aug(i,j));
        end
        fprintf('| %8.4f ]\n', Aug(i,n+1));
    end
end

function x = solveLU(A, b)
    % SOLVELU Solve using LU decomposition
    
    fprintf('Computing LU decomposition with partial pivoting...\n\n');
    
    [L, U, P] = lu(A);
    
    fprintf('Lower triangular L:\n');
    disp(L);
    
    fprintf('Upper triangular U:\n');
    disp(U);
    
    fprintf('Permutation matrix P:\n');
    disp(P);
    
    % Verify: PA = LU
    error_LU = norm(P*A - L*U, 'fro');
    fprintf('Verification: ||PA - LU||_F = %.2e\n\n', error_LU);
    
    % Solve: PA x = P b
    % LU x = Pb
    % First solve: L y = Pb  (forward substitution)
    % Then solve: U x = y    (back substitution)
    
    fprintf('Step 1: Forward substitution (Ly = Pb)\n');
    Pb = P * b;
    y = forwardSubstitution(L, Pb);
    fprintf('  y = [%.10f, %.10f, %.10f]''\n\n', y);
    
    fprintf('Step 2: Back substitution (Ux = y)\n');
    x = backSubstitution(U, y);
    fprintf('  x = [%.10f, %.10f, %.10f]''\n', x);
end

function y = forwardSubstitution(L, b)
    % FORWARDSUBSTITUTION Solve Ly = b for lower triangular L
    n = length(b);
    y = zeros(n, 1);
    
    for i = 1:n
        y(i) = (b(i) - L(i, 1:i-1) * y(1:i-1)) / L(i, i);
    end
end

function x = backSubstitution(U, b)
    % BACKSUBSTITUTION Solve Ux = b for upper triangular U
    n = length(b);
    x = zeros(n, 1);
    
    for i = n:-1:1
        x(i) = (b(i) - U(i, i+1:n) * x(i+1:n)) / U(i, i);
    end
end

function x = cramersRule(A, b)
    % CRAMERSRULE Solve using Cramer's rule (inefficient but pedagogical)
    
    fprintf('Solving using Cramer''s rule: x_i = det(A_i) / det(A)\n\n');
    
    det_A = det(A);
    fprintf('det(A) = %.10f\n\n', det_A);
    
    if abs(det_A) < eps
        error('Cramer''s rule fails: det(A) = 0 (singular matrix)');
    end
    
    n = length(b);
    x = zeros(n, 1);
    
    for i = 1:n
        A_i = A;
        A_i(:, i) = b;  % Replace column i with b
        det_A_i = det(A_i);
        x(i) = det_A_i / det_A;
        
        fprintf('x_%d: Replace column %d with b\n', i, i);
        fprintf('  A_%d =\n', i);
        disp(A_i);
        fprintf('  det(A_%d) = %.10f\n', i, det_A_i);
        fprintf('  x_%d = det(A_%d) / det(A) = %.10f\n\n', i, i, x(i));
    end
    
    fprintf('WARNING: Cramer''s rule requires %d determinant calculations\n', n+1);
    fprintf('         Complexity: O(n 뿯½ n!) vs O(n뿯½) for Gaussian elimination\n');
    fprintf('         Only practical for n ≤ 3\n');
end

function verifyMethod(method_name, x, A, b)
    % VERIFYMETHOD Check solution accuracy
    
    fprintf('Solution: x = [%.10f, %.10f, %.10f]''\n', x);
    
    % Compute residual
    residual = b - A * x;
    residual_norm = norm(residual);
    relative_residual = residual_norm / norm(b);
    
    fprintf('\nVerification:\n');
    fprintf('  Residual r = b - Ax:\n');
    fprintf('    r = [%.2e, %.2e, %.2e]''\n', residual);
    fprintf('  ||r|| = %.2e\n', residual_norm);
    fprintf('  ||r|| / ||b|| = %.2e (relative residual)\n', relative_residual);
    
    if relative_residual < 1e-10
        fprintf('  ✓ EXCELLENT: Solution verified within machine precision\n');
    elseif relative_residual < 1e-6
        fprintf('  ✓ GOOD: Solution accurate to 6+ decimal places\n');
    elseif relative_residual < 1e-3
        fprintf('  ~ ACCEPTABLE: Solution accurate to 3+ decimal places\n');
    else
        fprintf('  ✗ WARNING: Poor solution accuracy!\n');
    end
end

function compareMethods(x1, x2, x3, x4, x5)
    % COMPAREMETHODS Compare solutions from all methods
    
    fprintf('Comparing all methods:\n\n');
    
    methods = {'Gaussian Elim.', 'LU Decomp.', 'Backslash', 'Matrix Inv.', 'Cramer''s Rule'};
    solutions = [x1, x2, x3, x4, x5];
    
    % Use backslash as reference (most reliable)
    x_ref = x3;
    
    fprintf('%-20s', 'Method');
    for i = 1:3
        fprintf('x_%d          ', i);
    end
    fprintf('||x - x_ref||\n');
    fprintf('%s\n', repmat('-', 1, 80));
    
    for j = 1:5
        fprintf('%-20s', methods{j});
        for i = 1:3
            fprintf('%.6f  ', solutions(i,j));
        end
        diff_norm = norm(solutions(:,j) - x_ref);
        fprintf('%.2e', diff_norm);
        if diff_norm < 1e-10
            fprintf(' ✓');
        end
        fprintf('\n');
    end
    
    fprintf('\nConclusion: All methods agree to within %.2e\n', ...
        max(vecnorm(solutions - x_ref)));
end

function demonstrateIterative(A, b, x_true)
    % DEMONSTRATEITERATIVE Show iterative methods (Jacobi, Gauss-Seidel)
    
    fprintf('Demonstrating iterative methods...\n\n');
    
    % Check diagonal dominance
    n = size(A, 1);
    is_diag_dom = true;
    for i = 1:n
        if abs(A(i,i)) <= sum(abs(A(i,:))) - abs(A(i,i))
            is_diag_dom = false;
            break;
        end
    end
    
    if ~is_diag_dom
        fprintf('WARNING: Matrix is NOT diagonally dominant\n');
        fprintf('         Iterative methods may not converge!\n');
        fprintf('         Proceeding anyway for demonstration...\n\n');
    end
    
    max_iter = 50;
    tol = 1e-6;
    
    % Jacobi method
    fprintf('-- Jacobi Method --\n');
    [x_jacobi, iter_jacobi, history_jacobi] = jacobiMethod(A, b, tol, max_iter);
    
    if iter_jacobi < max_iter
        fprintf('  Converged in %d iterations\n', iter_jacobi);
        fprintf('  Final solution: x = [%.6f, %.6f, %.6f]''\n', x_jacobi);
        error_jacobi = norm(x_jacobi - x_true);
        fprintf('  ||x - x_true|| = %.2e\n\n', error_jacobi);
    else
        fprintf('  Did NOT converge within %d iterations\n', max_iter);
        fprintf('  Final residual: %.2e\n\n', history_jacobi(end));
    end
    
    % Gauss-Seidel method
    fprintf('-- Gauss-Seidel Method --\n');
    [x_gs, iter_gs, history_gs] = gaussSeidelMethod(A, b, tol, max_iter);
    
    if iter_gs < max_iter
        fprintf('  Converged in %d iterations\n', iter_gs);
        fprintf('  Final solution: x = [%.6f, %.6f, %.6f]''\n', x_gs);
        error_gs = norm(x_gs - x_true);
        fprintf('  ||x - x_true|| = %.2e\n\n', error_gs);
    else
        fprintf('  Did NOT converge within %d iterations\n', max_iter);
        fprintf('  Final residual: %.2e\n\n', history_gs(end));
    end
    
    % Plot convergence
    figure('Position', [100, 100, 800, 500], 'Name', 'Iterative Methods Convergence');
    semilogy(1:length(history_jacobi), history_jacobi, 'b-o', 'LineWidth', 2, ...
        'DisplayName', 'Jacobi');
    hold on;
    semilogy(1:length(history_gs), history_gs, 'r-s', 'LineWidth', 2, ...
        'DisplayName', 'Gauss-Seidel');
    semilogy([1, max(length(history_jacobi), length(history_gs))], [tol, tol], ...
        'k-', 'LineWidth', 1.5, 'DisplayName', 'Tolerance');
    hold off;
    
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Residual $||\mathbf{r}||$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Convergence of Iterative Methods', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Location', 'best', 'Interpreter', 'latex');
    
    fprintf('Comparison:\n');
    fprintf('  Jacobi: %d iterations\n', iter_jacobi);
    fprintf('  Gauss-Seidel: %d iterations\n', iter_gs);
    if iter_gs < iter_jacobi
        fprintf('  뿯↽ Gauss-Seidel converged %.1f%% faster\n', ...
            100*(iter_jacobi - iter_gs)/iter_jacobi);
    end
end

function [x, iter, history] = jacobiMethod(A, b, tol, max_iter)
    % JACOBIMETHOD Jacobi iterative method
    n = length(b);
    x = zeros(n, 1);  % Initial guess
    history = zeros(max_iter, 1);
    
    D = diag(diag(A));
    R = A - D;
    
    for iter = 1:max_iter
        x_new = D \ (b - R * x);
        
        residual = norm(b - A * x_new);
        history(iter) = residual;
        
        if residual < tol
            history = history(1:iter);
            break;
        end
        
        x = x_new;
    end
end

function [x, iter, history] = gaussSeidelMethod(A, b, tol, max_iter)
    % GAUSSSEIDELMETHOD Gauss-Seidel iterative method
    n = length(b);
    x = zeros(n, 1);  % Initial guess
    history = zeros(max_iter, 1);
    
    for iter = 1:max_iter
        for i = 1:n
            sum1 = A(i, 1:i-1) * x(1:i-1);
            sum2 = A(i, i+1:n) * x(i+1:n);
            x(i) = (b(i) - sum1 - sum2) / A(i, i);
        end
        
        residual = norm(b - A * x);
        history(iter) = residual;
        
        if residual < tol
            history = history(1:iter);
            break;
        end
    end
end

function visualizeSystem(A, b, x_sol)
    % VISUALIZESYSTEM 3D visualization of system geometry
    
    fprintf('Creating geometric visualization...\n');
    fprintf('Each equation represents a PLANE in 3D space\n');
    fprintf('Solution is the INTERSECTION point of all three planes\n\n');
    
    figure('Position', [100, 100, 1200, 400], 'Name', ...
        'System Geometry');
    
    % Create meshgrid for plotting planes
    [X, Y] = meshgrid(linspace(-5, 10, 30), linspace(-20, 5, 30));
    
    % Extract coefficients
    a1 = A(1,:); b1 = b(1);  % Plane 1: a1뿯½x + b1 = 0 뿯↽ z = ...
    a2 = A(2,:); b2 = b(2);  % Plane 2
    a3 = A(3,:); b3 = b(3);  % Plane 3
    
    % Compute Z for each plane (assuming z-coefficient ≠ 0)
    Z1 = (b1 - a1(1)*X - a1(2)*Y) / a1(3);
    Z2 = (b2 - a2(1)*X - a2(2)*Y) / a2(3);
    Z3 = (b3 - a3(1)*X - a3(2)*Y) / a3(3);
    
    % Plot each plane
    subplot(1, 3, 1);
    surf(X, Y, Z1, 'FaceAlpha', 0.5, 'EdgeColor', 'none', 'FaceColor', 'r');
    hold on;
    plot3(x_sol(1), x_sol(2), x_sol(3), 'ko', 'MarkerSize', 12, ...
        'MarkerFaceColor', 'y', 'LineWidth', 2);
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$z$', 'Interpreter', 'latex');
    title('Plane 1: $2x + y - z = 8$', 'Interpreter', 'latex');
    view(45, 30);
    
    subplot(1, 3, 2);
    surf(X, Y, Z2, 'FaceAlpha', 0.5, 'EdgeColor', 'none', 'FaceColor', 'g');
    hold on;
    plot3(x_sol(1), x_sol(2), x_sol(3), 'ko', 'MarkerSize', 12, ...
        'MarkerFaceColor', 'y', 'LineWidth', 2);
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$z$', 'Interpreter', 'latex');
    title('Plane 2: $-3x - y + 2z = -11$', 'Interpreter', 'latex');
    view(45, 30);
    
    subplot(1, 3, 3);
    surf(X, Y, Z1, 'FaceAlpha', 0.3, 'EdgeColor', 'none', 'FaceColor', 'r');
    hold on;
    surf(X, Y, Z2, 'FaceAlpha', 0.3, 'EdgeColor', 'none', 'FaceColor', 'g');
    surf(X, Y, Z3, 'FaceAlpha', 0.3, 'EdgeColor', 'none', 'FaceColor', 'b');
    plot3(x_sol(1), x_sol(2), x_sol(3), 'ko', 'MarkerSize', 15, ...
        'MarkerFaceColor', 'y', 'LineWidth', 3);
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$z$', 'Interpreter', 'latex');
    title('All Three Planes', 'Interpreter', 'latex');
    legend('Plane 1', 'Plane 2', 'Plane 3', 'Solution', 'Location', 'best');
    view(45, 30);
    
    fprintf('Solution point: (%.4f, %.4f, %.4f)\n', x_sol);
end

function sensitivityAnalysis(A, b, x)
    % SENSITIVITYANALYSIS Analyze solution sensitivity to perturbations
    
    fprintf('Analyzing solution sensitivity...\n\n');
    
    kappa = cond(A);
    fprintf('Condition number 뿯ν(A) = %.6f\n', kappa);
    fprintf('Theoretical error bound: ||뿯νx||/||x|| ≤ 뿯ν(A) 뿯½ ||뿯νb||/||b||\n\n');
    
    % Perturb right-hand side
    n_trials = 10;
    epsilon = 1e-6;
    
    fprintf('Perturbing b by 뿯νb with ||뿯νb|| / ||b|| ≈ %.2e:\n\n', epsilon);
    
    relative_errors = zeros(n_trials, 1);
    amplification_factors = zeros(n_trials, 1);
    
    for trial = 1:n_trials
        % Random perturbation
        delta_b = epsilon * norm(b) * randn(size(b));
        delta_b = delta_b / norm(delta_b) * (epsilon * norm(b));
        
        b_pert = b + delta_b;
        x_pert = A \ b_pert;
        
        delta_x = x_pert - x;
        
        relative_input = norm(delta_b) / norm(b);
        relative_output = norm(delta_x) / norm(x);
        amplification = relative_output / relative_input;
        
        relative_errors(trial) = relative_output;
        amplification_factors(trial) = amplification;
    end
    
    fprintf('Results over %d trials:\n', n_trials);
    fprintf('  Mean relative error: %.2e\n', mean(relative_errors));
    fprintf('  Max relative error: %.2e\n', max(relative_errors));
    fprintf('  Mean amplification: %.2f\n', mean(amplification_factors));
    fprintf('  Max amplification: %.2f\n', max(amplification_factors));
    fprintf('  Condition number: %.2f\n', kappa);
    fprintf('\n');
    
    if max(amplification_factors) <= kappa
        fprintf('✓ Amplification ≤ 뿯ν(A): Theory confirmed\n');
    else
        fprintf('Note: Amplification slightly exceeds 뿯ν(A) (statistical variation)\n');
    end
end

function str = yesno(condition)
    % YESNO Return 'Yes' or 'No' based on condition
    if condition
        str = 'Yes';
    else
        str = 'No';
    end
end

% Execute problem solution
Problem4_LinearSystem();
