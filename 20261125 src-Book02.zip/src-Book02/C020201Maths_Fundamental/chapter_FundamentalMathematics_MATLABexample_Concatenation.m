%% chapter_FundamentalMathematics_MATLABexample_Concatenation.m
% Matrix concatenation operations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_Concatenation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_1_2_Example02.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates matrix concatenation techniques for
%              building composite structures.

% Define component matrices
matrixA = [1, 2; 3, 4];
matrixB = [5, 6; 7, 8];
columnVectorC = [9; 10];

disp('Matrix A:');
disp(matrixA);
disp('Matrix B:');
disp(matrixB);
disp('Column Vector C:');
disp(columnVectorC);

% Horizontal concatenation
horizontalConcat = [matrixA, matrixB];
disp('Horizontal concatenation [A, B]:');
disp(horizontalConcat);

% Vertical concatenation
verticalConcat = [matrixA; matrixB];
disp('Vertical concatenation [A; B]:');
disp(verticalConcat);

% Mixed concatenation to create augmented matrix
% Common in linear systems: [A | b] for system Ax = b
augmentedMatrix = [matrixA, columnVectorC];
disp('Augmented matrix [A | C]:');
disp(augmentedMatrix);

% Block matrix construction
% Create 4*x4 block matrix from 2*x2 components
blockMatrix = [matrixA, zeros(2,2); eye(2), matrixB];
disp('Block matrix construction:');
disp(blockMatrix);

% Building larger matrices incrementally
% Initialize empty matrix
compositeMatrix = [];

% Add rows sequentially (vertical concatenation)
for rowIdx = 1:3
    newRow = rowIdx:rowIdx+2;
    compositeMatrix = [compositeMatrix; newRow];
end
disp('Matrix built incrementally:');
disp(compositeMatrix);
