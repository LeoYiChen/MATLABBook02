%% chapter_Math_problem3_decomp.m
% Matrix decompositions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem3_decomp
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% LU decomposition with partial pivoting
[L, U, P] = lu(A);
% Verify: P*A = L*U

% QR decomposition
[Q, R] = qr(A);
% Verify: A = Q*R and Q'*Q = I

% Singular Value Decomposition
[U, S, V] = svd(A);
% Verify: A = U*S*V'
% Singular values on diagonal of S
singular_values = diag(S);
