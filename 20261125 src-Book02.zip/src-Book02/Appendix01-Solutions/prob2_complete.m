%% prob2_complete.m
% Problem 2: Complete Memory Bandwidth Bottleneck Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob2_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 2: GPU Memory Bandwidth Bottleneck Analysis
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Analyses arithmetic intensity, identifies performance bottlenecks,
%              and applies roofline model to convolutional layer execution
%
% Revision History:
%   v1.0 (15-Jan-2025): Initial implementation with roofline visualisation
%   v1.1 (15-Jan-2025): Added optimisation recommendations

%% Initialisation
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 2: GPU Memory Bandwidth Bottleneck Analysis\n');
fprintf('================================================================\n\n');

%% Define Convolutional Layer Specifications
% Input feature map dimensions
inputHeight = 224;
inputWidth = 224;
inputChannels = 64;

% Convolution parameters
kernelHeight = 3;
kernelWidth = 3;
outputChannels = 128;
stride = 1;
padding = 0;

% Batch configuration
batchSize = 32;

% Data type
bytesPerElement = 4;  % FP32 (single precision)

% GPU hardware specifications
peakBandwidth_GBps = 500;          % GB/s
peakCompute_TFLOPS = 10;           % TFLOPS (FP32)

fprintf('Convolutional Layer Configuration:\n');
fprintf('  Input feature map:  %d x %d x %d (H x W x C_in)\n', ...
        inputHeight, inputWidth, inputChannels);
fprintf('  Kernel size:        %d x %d\n', kernelHeight, kernelWidth);
fprintf('  Output channels:    %d\n', outputChannels);
fprintf('  Batch size:         %d\n', batchSize);
fprintf('  Stride:             %d\n', stride);
fprintf('  Padding:            %d\n', padding);
fprintf('  Data type:          FP32 (%d bytes/element)\n\n', bytesPerElement);

fprintf('GPU Hardware Specifications:\n');
fprintf('  Peak memory bandwidth: %d GB/s\n', peakBandwidth_GBps);
fprintf('  Peak compute (FP32):   %d TFLOPS\n\n', peakCompute_TFLOPS);

%% Part (a): Calculate Total FLOPs

% Output spatial dimensions
outputHeight = floor((inputHeight + 2*padding - kernelHeight) / stride) + 1;
outputWidth = floor((inputWidth + 2*padding - kernelWidth) / stride) + 1;

% Number of output elements
numOutputElements = batchSize * outputHeight * outputWidth * outputChannels;

% FLOPs per output element
% Each output requires K_h * K_w * C_in multiply-add operations
% Multiply-add (MAC) counts as 2 FLOPs
flopsPerOutputElement = kernelHeight * kernelWidth * inputChannels * 2;

% Total FLOPs
totalFLOPs = numOutputElements * flopsPerOutputElement;

fprintf('========================================\n');
fprintf('(a) Computational Complexity Analysis\n');
fprintf('========================================\n');
fprintf('Output dimensions:      %d x %d x %d (H x W x C_out)\n', ...
        outputHeight, outputWidth, outputChannels);
fprintf('Total output elements:  %.3e\n', numOutputElements);
fprintf('FLOPs per element:      %d (= %d x %d x %d x 2)\n', ...
        flopsPerOutputElement, kernelHeight, kernelWidth, inputChannels);
fprintf('Total FLOPs:            %.3e\n', totalFLOPs);
fprintf('                        %.2f GFLOPs\n\n', totalFLOPs / 1e9);

%% Part (b): Calculate Memory Traffic

% Input feature map bytes
bytesInput = batchSize * inputHeight * inputWidth * inputChannels * ...
             bytesPerElement;

% Weight (kernel) bytes
bytesWeights = kernelHeight * kernelWidth * inputChannels * ...
               outputChannels * bytesPerElement;

% Output feature map bytes
bytesOutput = batchSize * outputHeight * outputWidth * outputChannels * ...
              bytesPerElement;

% Total memory traffic (assuming no caching)
totalBytes = bytesInput + bytesWeights + bytesOutput;

fprintf('========================================\n');
fprintf('(b) Memory Traffic Analysis\n');
fprintf('========================================\n');
fprintf('Input feature map:      %.2f MB (%d elements)\n', ...
        bytesInput / 1e6, batchSize * inputHeight * inputWidth * inputChannels);
fprintf('Weights (kernel):       %.2f MB (%d elements)\n', ...
        bytesWeights / 1e6, ...
        kernelHeight * kernelWidth * inputChannels * outputChannels);
fprintf('Output feature map:     %.2f MB (%d elements)\n', ...
        bytesOutput / 1e6, numOutputElements);
fprintf('Total bytes transferred: %.2f MB\n', totalBytes / 1e6);
fprintf('Traffic breakdown:\n');
fprintf('  Reads:  %.2f MB (%.1f%%)\n', ...
        (bytesInput + bytesWeights) / 1e6, ...
        ((bytesInput + bytesWeights) / totalBytes) * 100);
fprintf('  Writes: %.2f MB (%.1f%%)\n\n', ...
        bytesOutput / 1e6, (bytesOutput / totalBytes) * 100);

%% Part (c): Compute Arithmetic Intensity

arithmeticIntensity = totalFLOPs / totalBytes;

fprintf('========================================\n');
fprintf('(c) Arithmetic Intensity\n');
fprintf('========================================\n');
fprintf('Definition: I = Total FLOPs / Total Bytes\n');
fprintf('Calculation:\n');
fprintf('  I = %.3e FLOPs / %.3e Bytes\n', totalFLOPs, totalBytes);
fprintf('  I = %.2f FLOP/Byte\n\n', arithmeticIntensity);

%% Part (d): Determine Performance Bottleneck

% Critical arithmetic intensity (ridge point)
criticalIntensity = (peakCompute_TFLOPS * 1e12) / (peakBandwidth_GBps * 1e9);

fprintf('========================================\n');
fprintf('(d) Bottleneck Identification\n');
fprintf('========================================\n');
fprintf('Critical arithmetic intensity:\n');
fprintf('  I_crit = Peak_FLOPS / Peak_Bandwidth\n');
fprintf('  I_crit = (%d x 10^12 FLOPS) / (%d x 10^9 Bytes/s)\n', ...
        peakCompute_TFLOPS, peakBandwidth_GBps);
fprintf('  I_crit = %.2f FLOP/Byte\n\n', criticalIntensity);

fprintf('Comparison:\n');
fprintf('  Actual intensity:   I = %.2f FLOP/Byte\n', arithmeticIntensity);
fprintf('  Critical intensity: I_crit = %.2f FLOP/Byte\n\n', criticalIntensity);

if arithmeticIntensity < criticalIntensity
    bottleneckType = 'MEMORY-BOUND';
    limitingFactor = 'Memory Bandwidth';
    fprintf('CONCLUSION: %s\n', bottleneckType);
    fprintf('  Since I < I_crit, performance is limited by %s\n', limitingFactor);
    fprintf('  The GPU compute units are UNDERUTILISED\n');
    fprintf('  Optimisation priority: Reduce memory traffic\n\n');
else
    bottleneckType = 'COMPUTE-BOUND';
    limitingFactor = 'Computational Throughput';
    fprintf('CONCLUSION: %s\n', bottleneckType);
    fprintf('  Since I >= I_crit, performance is limited by %s\n', limitingFactor);
    fprintf('  Memory bandwidth is UNDERUTILISED\n');
    fprintf('  Optimisation priority: Improve algorithmic efficiency\n\n');
end

%% Part (e): Estimate Execution Time

% Time if limited by computation
timeCompute_ms = (totalFLOPs / (peakCompute_TFLOPS * 1e12)) * 1000;

% Time if limited by memory bandwidth
timeMemory_ms = (totalBytes / (peakBandwidth_GBps * 1e9)) * 1000;

% Actual time (determined by bottleneck)
actualTime_ms = max(timeCompute_ms, timeMemory_ms);

% Achieved performance metrics
achievedGFLOPS = (totalFLOPs / 1e9) / (actualTime_ms / 1000);
achievedBandwidth_GBps = (totalBytes / 1e9) / (actualTime_ms / 1000);

% Utilisation percentages
computeUtilisation = (timeCompute_ms / actualTime_ms) * 100;
bandwidthUtilisation = (timeMemory_ms / actualTime_ms) * 100;

fprintf('========================================\n');
fprintf('(e) Execution Time and Performance\n');
fprintf('========================================\n');
fprintf('Theoretical times:\n');
fprintf('  If compute-limited:  %.3f ms\n', timeCompute_ms);
fprintf('  If memory-limited:   %.3f ms\n\n', timeMemory_ms);

fprintf('Actual performance (limited by %s):\n', limitingFactor);
fprintf('  Execution time:         %.3f ms\n', actualTime_ms);
fprintf('  Achieved throughput:    %.2f GFLOPS\n', achievedGFLOPS);
fprintf('  Achieved bandwidth:     %.2f GB/s\n\n', achievedBandwidth_GBps);

fprintf('Resource utilisation:\n');
fprintf('  Compute utilisation:    %.1f%% (%.2f / %.2f TFLOPS)\n', ...
        computeUtilisation, achievedGFLOPS / 1000, peakCompute_TFLOPS);
fprintf('  Bandwidth utilisation:  %.1f%% (%.2f / %.2f GB/s)\n\n', ...
        bandwidthUtilisation, achievedBandwidth_GBps, peakBandwidth_GBps);

fprintf('Performance bottleneck: %s\n', bottleneckType);
fprintf('Wasted compute capacity: %.1f%% (%.2f TFLOPS unused)\n', ...
        100 - computeUtilisation, ...
        peakCompute_TFLOPS * (1 - computeUtilisation/100));

%% Visualisation: Roofline Model

figure('Position', [100, 100, 900, 700], 'Color', 'w');

% Create intensity range for roofline
intensityRange = logspace(-2, 3, 1000);  % 0.01 to 1000 FLOP/Byte

% Roofline: min of compute ceiling and bandwidth ceiling
rooflinePerformance = min(peakCompute_TFLOPS, ...
                          peakBandwidth_GBps * intensityRange / 1000);

% Plot roofline
loglog(intensityRange, rooflinePerformance, 'k-', 'LineWidth', 3.5);
hold on;

% Shade memory-bound region
memBoundRegion_X = [1e-2, criticalIntensity, criticalIntensity, 1e-2];
memBoundRegion_Y = [1e-3, 1e-3, peakCompute_TFLOPS * 1.5, ...
                    peakCompute_TFLOPS * 1.5];
fill(memBoundRegion_X, memBoundRegion_Y, [1, 0.85, 0.85], ...
     'EdgeColor', 'none', 'FaceAlpha', 0.4);
text(0.5, peakCompute_TFLOPS / 3, '\textbf{Memory-Bound}', ...
     'Interpreter', 'latex', 'FontSize', 13, 'Color', [0.7, 0, 0], ...
     'FontWeight', 'bold');

% Shade compute-bound region
compBoundRegion_X = [criticalIntensity, 1e3, 1e3, criticalIntensity];
compBoundRegion_Y = [1e-3, 1e-3, peakCompute_TFLOPS * 1.5, ...
                     peakCompute_TFLOPS * 1.5];
fill(compBoundRegion_X, compBoundRegion_Y, [0.85, 0.85, 1], ...
     'EdgeColor', 'none', 'FaceAlpha', 0.4);
text(80, peakCompute_TFLOPS / 3, '\textbf{Compute-Bound}', ...
     'Interpreter', 'latex', 'FontSize', 13, 'Color', [0, 0, 0.7], ...
     'FontWeight', 'bold');

% Plot convolution layer operating point
scatter(arithmeticIntensity, achievedGFLOPS / 1000, 300, 'r', ...
        'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 2.5);

% Add annotation for convolution layer
annotation('textarrow', [0.35, 0.28], [0.55, 0.42], ...
           'String', {sprintf('\\textbf{Conv Layer}'), ...
                      sprintf('$I = %.2f$', arithmeticIntensity), ...
                      sprintf('%.2f GFLOPS', achievedGFLOPS)}, ...
           'Interpreter', 'latex', 'FontSize', 12, 'LineWidth', 1.5, ...
           'HeadStyle', 'cback2', 'HeadLength', 10, 'HeadWidth', 10);

% Reference lines
xline(criticalIntensity, '-', 'Color', [0.3, 0.3, 0.3], 'LineWidth', 2, ...
      'Label', sprintf('$I_{\\mathrm{crit}} = %.1f$', criticalIntensity), ...
      'Interpreter', 'latex', 'FontSize', 11, ...
      'LabelOrientation', 'horizontal', 'LabelHorizontalAlignment', 'center');

yline(peakCompute_TFLOPS, '-', 'Color', [0, 0, 0.8], 'LineWidth', 2.5, ...
      'Label', sprintf('Peak Compute: %d TFLOPS', peakCompute_TFLOPS), ...
      'Interpreter', 'latex', 'FontSize', 11, ...
      'LabelHorizontalAlignment', 'right');

% Formatting
grid on; box on;
xlabel('Arithmetic Intensity (FLOP/Byte)', 'Interpreter', 'latex', ...
       'FontSize', 15);
ylabel('Performance (TFLOPS)', 'Interpreter', 'latex', 'FontSize', 15);
title('\textbf{Roofline Model: Convolutional Layer Analysis}', ...
      'Interpreter', 'latex', 'FontSize', 17);
xlim([1e-2, 1e3]);
ylim([1e-3, peakCompute_TFLOPS * 1.2]);
set(gca, 'FontSize', 12, 'LineWidth', 1.2);

% Add legend
legend({'Roofline Bound', '', '', 'Convolution Layer'}, ...
       'Interpreter', 'latex', 'Location', 'southeast', 'FontSize', 11);

%% Optimisation Recommendations

fprintf('\n========================================\n');
fprintf('Optimisation Recommendations\n');
fprintf('========================================\n');

fprintf('\n1. IMMEDIATE OPTIMISATIONS (reduce memory traffic):\n');
fprintf('   - Implement tiling/blocking to maximise L1/L2 cache reuse\n');
fprintf('   - Use mixed-precision (FP16): reduces traffic by 50%%\n');
fprintf('   - Enable Tensor Core operations (for FP16/INT8)\n');
fprintf('   - Expected improvement: 1.5-2x speedup\n');

fprintf('\n2. ALGORITHMIC OPTIMISATIONS:\n');
fprintf('   - Winograd convolution (for 3x3 kernels): reduces FLOPs by 2.25x\n');
fprintf('   - FFT-based convolution (for large kernels): O(n log n) vs O(n^2)\n');
fprintf('   - Im2col + GEMM transformation: better memory access patterns\n');
fprintf('   - Expected improvement: 2-4x speedup\n');

fprintf('\n3. ARCHITECTURAL OPTIMISATIONS:\n');
fprintf('   - Kernel fusion: combine conv + batch norm + activation\n');
fprintf('   - Depthwise separable convolutions (MobileNet-style)\n');
fprintf('   - Channel pruning to reduce C_in and C_out\n');
fprintf('   - Expected improvement: 3-10x speedup\n');

fprintf('\n4. QUANTISATION (if accuracy permits):\n');
fprintf('   - INT8 quantisation: 4x memory reduction, 4x higher throughput\n');
fprintf('   - Expected improvement: 4-8x speedup\n');

fprintf('\n5. THEORETICAL BEST CASE:\n');
currentIntensity = arithmeticIntensity;
targetIntensity = criticalIntensity * 1.1;  % Slightly above ridge point
requiredReduction = totalBytes / (totalFLOPs / targetIntensity);
reductionFactor = totalBytes / requiredReduction;

fprintf('   To become compute-bound, need I > %.2f FLOP/Byte\n', ...
        criticalIntensity);
fprintf('   Current I = %.2f, requires %.1fx reduction in memory traffic\n', ...
        currentIntensity, reductionFactor);
fprintf('   Or equivalently: %.1fx increase in arithmetic intensity\n', ...
        targetIntensity / currentIntensity);
fprintf('   Achievable through: Winograd (2.25x) + FP16 (2x) = 4.5x total\n\n');
