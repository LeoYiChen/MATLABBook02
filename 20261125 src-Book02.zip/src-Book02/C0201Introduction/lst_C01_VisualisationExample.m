%% lst_C01_VisualisationExample.m
% Basic visualisation demonstrating multiple plot types and customisation options
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : lst:C01_VisualisationExample
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Generate data
x = linspace(0, 2*pi, 100);
y1 = sin(x);
y2 = cos(x);

% Create figure with two subplots
figure('Position', [100, 100, 800, 400]);

% First subplot - line plot with customisation
subplot(1, 2, 1);
plot(x, y1, 'b-', x, y2, 'r-', 'LineWidth', 1.5);
xlabel('x');
ylabel('f(x)');
title('Trigonometric Functions');
legend('sin(x)', 'cos(x)', 'Location', 'best');
grid on;

% Second subplot - parametric plot
subplot(1, 2, 2);
plot(y1, y2, 'g-', 'LineWidth', 1.5);
xlabel('sin(x)');
ylabel('cos(x)');
title('Parametric Plot: Unit Circle');
axis equal;  % Equal scaling for both axes
grid on;
