%% chapter_Math_example_functionGeneral.m
% General structure of MATLAB function definition.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_functionGeneral
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [output1, output2, ...] = functionName(input1, input2, ...)
    % Function documentation
    % Describe purpose, inputs, outputs, and usage
    
    % Function body - computational steps
    statements
    
    % Return values through output variables
end
