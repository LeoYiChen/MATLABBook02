%% chapter_UQ_example_confidenceIntervals.m
% Confidence intervals: base-MATLAB t and chi-square quantiles verified against tables, percentile and BCa bootstrap intervals, exact exponential reliability bands, and a coverage study exposing non-normal fragility.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_UQ_example_confidenceIntervals
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Confidence intervals: parametric, bootstrap, exact, and their coverage
%  Requires: base MATLAB, R2016b or later (gammaincinv, betaincinv).
%  No toolboxes required.

clearvars; close all; clc;
rng(1906, 'twister');

verifyQuantileFunctions();
parametricAndBootstrapIntervals();
exactReliabilityInterval();
coverageStudy();

%% --------- local functions -----------
function verifyQuantileFunctions()

    fprintf('Stage 0: verifying base-MATLAB quantile functions\n');
    fprintf('================================================\n\n');
    fprintf('%-34s %12s %12s\n', 'Quantity', 'Computed', 'Published');
    fprintf('%-34s %12.4f %12.4f\n', 't(0.975, 29)', ...
        studentTQuantile(0.975, 29), 2.0452);
    fprintf('%-34s %12.4f %12.4f\n', 't(0.995, 9)', ...
        studentTQuantile(0.995, 9), 3.2498);
    fprintf('%-34s %12.4f %12.4f\n', 'chi2(0.975, 29)', ...
        chiSquareQuantile(0.975, 29), 45.7223);
    fprintf('%-34s %12.4f %12.4f\n', 'chi2(0.025, 29)', ...
        chiSquareQuantile(0.025, 29), 16.0471);
    fprintf('\nAgreement to four decimals confirms the identities.\n\n');
end

function parametricAndBootstrapIntervals()

    fprintf('Stage 1: parametric and bootstrap intervals\n');
    fprintf('==========================================\n\n');

    trueMean = 100;  trueStd = 15;  sampleSize = 30;
    dataVector = trueMean + trueStd * randn(sampleSize, 1);

    sampleMean = mean(dataVector);
    sampleStd  = std(dataVector);
    standardError = sampleStd / sqrt(sampleSize);
    confidenceLevel = 0.95;
    alphaLevel = 1 - confidenceLevel;

    tCritical = studentTQuantile(1 - alphaLevel/2, sampleSize - 1);
    meanInterval = sampleMean + tCritical * standardError * [-1, 1];

    chiUpper = chiSquareQuantile(1 - alphaLevel/2, sampleSize - 1);
    chiLower = chiSquareQuantile(alphaLevel/2, sampleSize - 1);
    stdInterval = sqrt((sampleSize-1) * sampleStd^2 ./ [chiUpper, chiLower]);

    fprintf('Sample of %d from N(%.0f, %.0f^2): mean %.3f, std %.3f\n\n', ...
        sampleSize, trueMean, trueStd, sampleMean, sampleStd);
    fprintf('  95%% t interval for the mean : [%.3f, %.3f]  contains mu: %s\n', ...
        meanInterval, logicalToText(trueMean >= meanInterval(1) && ...
        trueMean <= meanInterval(2)));
    fprintf('  95%% chi2 interval for sigma : [%.3f, %.3f]  contains sigma: %s\n', ...
        stdInterval, logicalToText(trueStd >= stdInterval(1) && ...
        trueStd <= stdInterval(2)));
    fprintf('  Note the asymmetry of the variance interval: dispersion\n');
    fprintf('  intervals are never symmetric about the point estimate.\n\n');

    % -- Bootstrap for a skewed statistic: coefficient of variation ---
    numBootstrap = 10000;
    coefficientOfVariation = @(x) std(x) / mean(x);

    [percentileInterval, bcaInterval, bootstrapReplicates] = ...
        bootstrapIntervals(dataVector, coefficientOfVariation, ...
        numBootstrap, alphaLevel);

    trueCoV = trueStd / trueMean;
    fprintf('Bootstrap intervals for the coefficient of variation:\n');
    fprintf('  True value        : %.4f\n', trueCoV);
    fprintf('  Point estimate    : %.4f\n', ...
        coefficientOfVariation(dataVector));
    fprintf('  Percentile 95%% CI : [%.4f, %.4f] (width %.4f)\n', ...
        percentileInterval, diff(percentileInterval));
    fprintf('  BCa 95%% CI        : [%.4f, %.4f] (width %.4f)\n', ...
        bcaInterval, diff(bcaInterval));
    fprintf('  BCa shifts the interval by %.1f%% of its width, correcting\n', ...
        100*abs(mean(bcaInterval) - mean(percentileInterval))/ ...
        diff(percentileInterval));
    fprintf('  for the skewness of the sampling distribution.\n\n');

    visualiseIntervals(dataVector, sampleMean, meanInterval, trueMean, ...
        bootstrapReplicates, percentileInterval, bcaInterval, trueCoV);
end

function exactReliabilityInterval()

    fprintf('Stage 2: exact interval for an exponential failure rate\n');
    fprintf('======================================================\n\n');

    trueFailureRate = 0.01;      % per hour
    numFailures = 50;
    % Inverse-transform sampling replaces exprnd
    failureTimes = -log(rand(numFailures, 1)) / trueFailureRate;

    totalTimeOnTest = sum(failureTimes);
    rateEstimate = numFailures / totalTimeOnTest;

    alphaLevel = 0.05;
    rateInterval = [chiSquareQuantile(alphaLevel/2, 2*numFailures), ...
        chiSquareQuantile(1 - alphaLevel/2, 2*numFailures)] / ...
        (2 * totalTimeOnTest);

    missionTime = 100;
    reliabilityEstimate = exp(-rateEstimate * missionTime);
    reliabilityInterval = exp(-fliplr(rateInterval) * missionTime);

    fprintf('True rate %.4f per hour, %d observed failures\n\n', ...
        trueFailureRate, numFailures);
    fprintf('  MLE of the rate        : %.5f per hour\n', rateEstimate);
    fprintf('  Exact 95%% CI for rate  : [%.5f, %.5f]\n', rateInterval);
    fprintf('  MTBF estimate          : %.1f h, CI [%.1f, %.1f] h\n', ...
        1/rateEstimate, 1/rateInterval(2), 1/rateInterval(1));
    fprintf('  R(%d h) estimate      : %.4f\n', missionTime, ...
        reliabilityEstimate);
    fprintf('  Exact 95%% CI for R     : [%.4f, %.4f]\n', ...
        reliabilityInterval);
    fprintf('  Contains the truth     : %s\n\n', ...
        logicalToText(exp(-trueFailureRate*missionTime) >= ...
        reliabilityInterval(1) && exp(-trueFailureRate*missionTime) <= ...
        reliabilityInterval(2)));

    visualiseReliabilityBand(failureTimes, rateEstimate, rateInterval, ...
        trueFailureRate);
end

function coverageStudy()

    fprintf('Stage 3: does the procedure actually deliver 95 per cent?\n');
    fprintf('========================================================\n\n');

    numExperiments = 20000;
    confidenceLevel = 0.95;
    alphaLevel = 1 - confidenceLevel;

    scenarioLabel = {'Normal data, n = 30', 'Normal data, n = 5', ...
        'Exponential data, n = 5', 'Exponential data, n = 30'};
    sampleSizes = [30, 5, 5, 30];
    isExponential = [false, false, true, true];
    observedCoverage = zeros(1, numel(sampleSizes));
    meanWidth = zeros(1, numel(sampleSizes));

    for scenarioIndex = 1:numel(sampleSizes)
        sampleSize = sampleSizes(scenarioIndex);
        if isExponential(scenarioIndex)
            populationMean = 100;
            dataMatrix = -log(rand(sampleSize, numExperiments)) * ...
                populationMean;
        else
            populationMean = 100;
            dataMatrix = populationMean + 15*randn(sampleSize, ...
                numExperiments);
        end

        sampleMeans = mean(dataMatrix, 1);
        sampleStds  = std(dataMatrix, 0, 1);
        tCritical   = studentTQuantile(1 - alphaLevel/2, sampleSize - 1);
        halfWidths  = tCritical * sampleStds / sqrt(sampleSize);

        coversTruth = abs(sampleMeans - populationMean) <= halfWidths;
        observedCoverage(scenarioIndex) = mean(coversTruth);
        meanWidth(scenarioIndex) = mean(2*halfWidths);
    end

    fprintf('%-26s %12s %12s\n', 'Scenario', 'Coverage', 'Mean width');
    for scenarioIndex = 1:numel(sampleSizes)
        fprintf('%-26s %11.3f%% %12.2f\n', scenarioLabel{scenarioIndex}, ...
            100*observedCoverage(scenarioIndex), meanWidth(scenarioIndex));
    end
    fprintf('\nThe t interval is remarkably robust for normal data at any n,\n');
    fprintf('but under-covers for small samples from a skewed population.\n');
    fprintf('Nominal confidence is a property of the model as well as of\n');
    fprintf('the arithmetic, and skewness is what breaks it.\n\n');

    visualiseCoverage(scenarioLabel, observedCoverage, confidenceLevel);
end

function quantileValue = studentTQuantile(probability, degreesOfFreedom)
    % Base-MATLAB Student t quantile via the incomplete beta inverse.
    if probability < 0.5
        quantileValue = -studentTQuantile(1 - probability, degreesOfFreedom);
        return;
    end
    tailMass = 2 * (1 - probability);
    betaValue = betaincinv(tailMass, degreesOfFreedom/2, 0.5);
    quantileValue = sqrt(degreesOfFreedom * (1 - betaValue) / betaValue);
end

function quantileValue = chiSquareQuantile(probability, degreesOfFreedom)
    % Base-MATLAB chi-square quantile: chi2 is Gamma(nu/2, scale 2).
    quantileValue = 2 * gammaincinv(probability, degreesOfFreedom/2);
end

function cumulativeProbability = standardNormalCdf(zValue)
    cumulativeProbability = 0.5 * erfc(-zValue / sqrt(2));
end

function zValue = standardNormalQuantile(probability)
    zValue = -sqrt(2) * erfcinv(2 * probability);
end

function [percentileInterval, bcaInterval, bootstrapReplicates] = ...
    bootstrapIntervals(dataVector, statisticFun, numBootstrap, alphaLevel)

    sampleSize = numel(dataVector);
    pointEstimate = statisticFun(dataVector);

    resampleIndices = randi(sampleSize, sampleSize, numBootstrap);
    bootstrapReplicates = zeros(numBootstrap, 1);
    for replicateIndex = 1:numBootstrap
        bootstrapReplicates(replicateIndex) = ...
            statisticFun(dataVector(resampleIndices(:, replicateIndex)));
    end

    percentileInterval = empiricalPercentile(bootstrapReplicates, ...
        100*[alphaLevel/2, 1-alphaLevel/2]);

    % Bias correction from the proportion of replicates below the estimate
    biasCorrection = standardNormalQuantile( ...
        mean(bootstrapReplicates < pointEstimate));

    % Acceleration from jackknife influence values
    jackknifeValues = zeros(sampleSize, 1);
    for omitIndex = 1:sampleSize
        retained = dataVector([1:omitIndex-1, omitIndex+1:sampleSize]);
        jackknifeValues(omitIndex) = statisticFun(retained);
    end
    centredJackknife = mean(jackknifeValues) - jackknifeValues;
    acceleration = sum(centredJackknife.^3) / ...
        (6 * sum(centredJackknife.^2)^1.5);

    zLevels = standardNormalQuantile([alphaLevel/2, 1-alphaLevel/2]);
    adjustedLevels = standardNormalCdf(biasCorrection + ...
        (biasCorrection + zLevels) ./ ...
        (1 - acceleration*(biasCorrection + zLevels)));
    bcaInterval = empiricalPercentile(bootstrapReplicates, ...
        100*adjustedLevels);
end

function quantileValues = empiricalPercentile(dataVector, percentLevels)
    sortedData = sort(dataVector(:));
    numObservations = numel(sortedData);
    plottingPosition = ((1:numObservations)' - 0.5) / numObservations;
    quantileValues = interp1(plottingPosition, sortedData, ...
        percentLevels(:)/100, 'linear', 'extrap')';
end

function textValue = logicalToText(conditionValue)
    if conditionValue
        textValue = 'yes';
    else
        textValue = 'no';
    end
end

function visualiseIntervals(dataVector, sampleMean, meanInterval, ...
    trueMean, bootstrapReplicates, percentileInterval, bcaInterval, trueCoV)

    figure('Position', [100, 100, 1300, 400], 'Name', 'Intervals');

    subplot(1, 3, 1);
    histogram(dataVector, 12, 'FaceColor', [0.55 0.75 0.90], ...
        'EdgeColor', 'k'); hold on;
    xline(trueMean, 'g-', 'LineWidth', 2);
    xline(sampleMean, 'b--', 'LineWidth', 1.5);
    xline(meanInterval(1), 'r-'); xline(meanInterval(2), 'r-');
    xlabel('Observation'); ylabel('Count');
    title('(a) Sample and 95% t interval'); grid on;

    subplot(1, 3, 2);
    histogram(bootstrapReplicates, 60, 'Normalization', 'pdf', ...
        'FaceColor', [0.85 0.60 0.60], 'EdgeColor', 'none'); hold on;
    xline(trueCoV, 'g-', 'LineWidth', 2);
    xlabel('Bootstrap coefficient of variation');
    ylabel('Probability density');
    title('(b) Bootstrap sampling distribution'); grid on;

    subplot(1, 3, 3);
    plot(percentileInterval, [1 1], 'b-', 'LineWidth', 8); hold on;
    plot(bcaInterval, [2 2], 'r-', 'LineWidth', 8);
    xline(trueCoV, 'g-', 'LineWidth', 2);
    set(gca, 'YTick', [1 2], 'YTickLabel', {'Percentile', 'BCa'});
    ylim([0.5 2.5]); xlabel('Coefficient of variation');
    title('(c) Percentile versus BCa'); grid on;
end

function visualiseReliabilityBand(failureTimes, rateEstimate, ...
    rateInterval, trueFailureRate)

    figure('Position', [100, 100, 900, 380], 'Name', 'Reliability band');

    subplot(1, 2, 1);
    histogram(failureTimes, 20, 'Normalization', 'pdf', ...
        'FaceColor', [0.90 0.75 0.55], 'EdgeColor', 'none'); hold on;
    timeGrid = linspace(0, max(failureTimes)*1.1, 300);
    plot(timeGrid, rateEstimate*exp(-rateEstimate*timeGrid), 'r-', ...
        'LineWidth', 2);
    xlabel('Time to failure [h]'); ylabel('Probability density');
    title('(a) Observed lifetimes and fit'); grid on;

    subplot(1, 2, 2);
    timeGrid = linspace(0, 400, 300);
    plot(timeGrid, exp(-rateEstimate*timeGrid), 'b-', 'LineWidth', 2);
    hold on;
    upperBand = exp(-rateInterval(1)*timeGrid);
    lowerBand = exp(-rateInterval(2)*timeGrid);
    fill([timeGrid, fliplr(timeGrid)], [upperBand, fliplr(lowerBand)], ...
        'r', 'FaceAlpha', 0.18, 'EdgeColor', 'none');
    plot(timeGrid, exp(-trueFailureRate*timeGrid), 'g--', 'LineWidth', 1.8);
    xlabel('Time [h]'); ylabel('Reliability R(t)');
    title('(b) Exact 95% confidence band');
    legend('MLE', '95% band', 'Truth', 'Location', 'northeast'); grid on;
end

function visualiseCoverage(scenarioLabel, observedCoverage, confidenceLevel)

    figure('Position', [100, 100, 800, 380], 'Name', 'Coverage');
    barh(100*observedCoverage); hold on;
    xline(100*confidenceLevel, 'r--', 'LineWidth', 2);
    set(gca, 'YTick', 1:numel(scenarioLabel), 'YTickLabel', scenarioLabel);
    xlabel('Observed coverage [%]'); xlim([85 100]);
    title('Actual versus nominal coverage of the 95% t interval');
    grid on;
end

% -----------------------
% Computational complexity. Parametric intervals cost O(n) plus one
% quantile evaluation. The bootstrap costs O(B n) for B replicates of an
% O(n) statistic, and BCa adds an O(n^2) jackknife loop, which dominates
% for large n but is negligible below a few thousand observations. The
% coverage study is fully vectorised at O(M n) for M experiments, so
% twenty thousand replications run in under a second. Exact exponential
% intervals cost O(n) with no simulation whatsoever, and are therefore
% always preferable when the model warrants them.
% -----------------------
