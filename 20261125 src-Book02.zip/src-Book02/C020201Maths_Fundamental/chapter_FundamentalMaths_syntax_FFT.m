%% chapter_FundamentalMaths_syntax_FFT.m
% Basic FFT syntax in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_syntax_FFT
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Compute FFT of signal x
Y = fft(x);

% Compute single-sided amplitude spectrum
L = length(Y);
P2 = abs(Y/L);
P1 = P2(1:L/2+1);
P1(2:end-1) = 2*P1(2:end-1);

% Construct frequency vector
fs = 1000;  % Sampling frequency (Hz)
f = fs*(0:(L/2))/L;
