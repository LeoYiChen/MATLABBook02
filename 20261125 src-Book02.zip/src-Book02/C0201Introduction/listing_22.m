%% listing_22.m
% Publication-quality damped oscillatory signals
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : listing_22
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
createPublicationFigure();

% Local functions (moved to end so this listing is a valid MATLAB script)
function createPublicationFigure()
    % CREATEPUBLICATIONFIGURE Generate high-quality plots for papers
    
    % Generate sample data
    x = linspace(0, 4*pi, 200);
    y1 = sin(x) .* exp(-x/8);
    y2 = cos(x) .* exp(-x/8);
    y3 = sin(2*x) .* exp(-x/8) * 0.5;
    
    % Create figure with specific size for publication
    % Common journal requirements: 3.5" (single column) or 7" (double column)
    figWidth = 7;  % inches
    figHeight = 5;  % inches
    
    fig = figure('Units', 'inches', 'Position', [1, 1, figWidth, figHeight]);
    
    % Main plot
    hold on;
    h1 = plot(x, y1, '-', 'LineWidth', 2.5, 'Color', [0, 0.4470, 0.7410], ...
        'DisplayName', 'Signal A');
    h2 = plot(x, y2, '-', 'LineWidth', 2.5, 'Color', [0.8500, 0.3250, 0.0980], ...
        'DisplayName', 'Signal B');
    h3 = plot(x, y3, '-.', 'LineWidth', 2, 'Color', [0.9290, 0.6940, 0.1250], ...
        'DisplayName', 'Signal C');
    
    % Formatting for readability
    xlabel('Time (seconds)', 'Interpreter', 'latex', 'FontSize', 14);
    ylabel('Amplitude', 'Interpreter', 'latex', 'FontSize', 14);
    title('Damped Oscillatory Signals', 'Interpreter', 'latex', ...
        'FontSize', 16, 'FontWeight', 'bold');
    
    % Legend with LaTeX formatting
    leg = legend('Interpreter', 'latex', 'Location', 'northeast', ...
        'FontSize', 12);
    leg.Box = 'off';  % Remove legend box for cleaner look
    
    % Grid and axis properties
    grid on;
    set(gca, 'FontSize', 12, 'LineWidth', 1.2, 'TickLabelInterpreter', ...
        'latex');
    xlim([0, 4*pi]);
    ylim([-1, 1]);
    
    % Set ticks for better readability
    xticks(0:pi:4*pi);
    xticklabels({'0', '$\pi$', '$2\pi$', '$3\pi$', '$4\pi$'});
    
    % Tight layout (removes excess white space)
    set(gca, 'LooseInset', get(gca, 'TightInset'));
    
    % Export at high resolution
    % Vector format (PDF/EPS) for papers
    exportgraphics(fig, 'publication_figure.pdf', ...
        'ContentType', 'vector', 'BackgroundColor', 'white');
    
    % Raster format (PNG/TIFF) for presentations
    exportgraphics(fig, 'publication_figure.png', ...
        'Resolution', 300);  % 300 DPI for print quality
    
    fprintf('Figures exported:\n');
    fprintf('  - publication_figure.pdf (vector, for papers)\n');
    fprintf('  - publication_figure.png (300 DPI, for slides)\n');
end
