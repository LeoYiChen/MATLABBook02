% MATLABBook02_Chapter01_Lab03.m
% This script demonstrates MATLAB integration with external tools

% Part 1: Python integration using MATLAB Engine API
% First, verify Python is configured
hasPython = ~isempty(pyenv);
if hasPython
    fprintf('Python is configured: %s\n', pyenv.Executable);
else
    warning('Python is not configured. Run pyenv command to configure.');
end

% Example of calling Python from MATLAB
try
    % Create a simple Python script
    fileID = fopen('simple_script.py', 'w');
    fprintf(fileID, ['import numpy as np\n', ...
                     'def process_data(data):\n', ...
                     '    # Simple data processing with NumPy\n', ...
                     '    mean_val = np.mean(data)\n', ...
                     '    std_val = np.std(data)\n', ...
                     '    normalized = (data - mean_val) / std_val\n', ...
                     '    return normalized, mean_val, std_val\n']);
    fclose(fileID);
    
    % Generate random data in MATLAB
    data = randn(1, 1000);
    
    % Call Python function
    py.importlib.import_module('simple_script');
    [normalized, mean_val, std_val] = py.simple_script.process_data(data);
    
    % Convert Python objects to MATLAB
    normalized_matlab = double(normalized);
    mean_matlab = double(mean_val);
    std_matlab = double(std_val);
    
    % Verify results by comparing with MATLAB's built-in functions
    matlab_mean = mean(data);
    matlab_std = std(data);
    
    fprintf('Python calculated mean: %.6f, MATLAB calculated mean: %.6f\n', mean_matlab, matlab_mean);
    fprintf('Python calculated std: %.6f, MATLAB calculated std: %.6f\n', std_matlab, matlab_std);
    
    % Visualise results
    figure;
    histogram(data, 30, 'Normalization', 'pdf', 'FaceColor', 'b', 'FaceAlpha', 0.3);
    hold on;
    histogram(normalized_matlab, 30, 'Normalization', 'pdf', 'FaceColor', 'r', 'FaceAlpha', 0.3);
    legend('Original Data', 'Normalised Data (Python)');
    title('Data Normalisation via Python Integration');
    xlabel('Value');
    ylabel('Probability Density');
catch ME
    warning('Python integration example failed: %s', ME.message);
end

% Part 2: File Exchange with External Tools
data_for_export = struct('x', 1:10, 'y', (1:10).^2, 'metadata', struct('title', 'Sample Data', 'author', 'MATLAB User'));

% Export to JSON (common interchange format)
try
    jsonStr = jsonencode(data_for_export);
    fileID = fopen('exported_data.json', 'w');
    fprintf(fileID, '%s', jsonStr);
    fclose(fileID);
    fprintf('Data successfully exported to JSON\n');
    
    % Read it back
    fileID = fopen('exported_data.json', 'r');
    imported_json = fscanf(fileID, '%c');
    fclose(fileID);
    imported_data = jsondecode(imported_json);
    
    % Verify data integrity
    fprintf('Data verification after JSON roundtrip:\n');
    disp(imported_data);
catch ME
    warning('JSON export/import failed: %s', ME.message);
end

% Part 3: RESTful API Communication
% Create a function to fetch data from a public API
try
    % Setting up web options
    options = weboptions('ContentType', 'json', 'Timeout', 30);
    
    % Get sample data from JSONPlaceholder (public API)
    url = 'https://jsonplaceholder.typicode.com/posts/1';
    data = webread(url, options);
    
    % Display the received data
    fprintf('Data retrieved from external API:\n');
    disp(data);
    
    % Demonstrate a POST request (note: this is a simulation as JSONPlaceholder doesn't actually save)
    newPost = struct('title', 'MATLAB Integration Test', 'body', 'Testing RESTful API communication from MATLAB', 'userId', 1);
    postUrl = 'https://jsonplaceholder.typicode.com/posts';
    response = webwrite(postUrl, newPost, options);
    
    fprintf('Response from POST request:\n');
    disp(response);
catch ME
    warning('API communication example failed: %s', ME.message);
end