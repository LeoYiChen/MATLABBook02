%% chapter_FundamentalMathematics_example_SymbolicVsNumeric.m
% Comparing numerical and symbolic computation in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_SymbolicVsNumeric
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Demonstrating Symbolic versus Numerical Computation
% Shows when exact arithmetic is necessary

% Define symbolic variables
syms x;

% Calculate derivative symbolically (exact)
symbolicDerivative = diff(sin(x^2) * exp(-x), x);

% Evaluate at specific point symbolically
pointValue = sym(1)/sym(3);
exactValue = subs(symbolicDerivative, x, pointValue);

% Numerical approximation using finite differences
numericalPoint = 1/3;
delta*X = 1e-8;
numericalDerivative = (sin((numericalPoint + delta*X)^2) * ...
    exp(-(numericalPoint + delta*X)) - ...
    sin(numericalPoint^2) * exp(-numericalPoint)) / delta*X;

% Display results
fprintf('Symbolic derivative: ');
disp(symbolicDerivative);
fprintf('Exact value at x=1/3: %.15f\n', double(exactValue));
fprintf('Numerical approximation: %.15f\n', numericalDerivative);
fprintf('Absolute difference: %.2e\n', ...
    abs(double(exactValue) - numericalDerivative));
