%% prob8_prob_syntax.m
% Probability plot syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob8_prob_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Fit distribution
pd = fitdist(data, 'Weibull');
% Create probability plot
probplot('weibull', data);
% Q-Q plot
qqplot(data, pd);
% ECDF
ecdf(data);
