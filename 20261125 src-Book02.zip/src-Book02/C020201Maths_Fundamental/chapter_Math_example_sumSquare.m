%% chapter_Math_example_sumSquare.m
% Function calculating sum of squares.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_sumSquare
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function result = sumSquare(x, y)
    % SUMSQUARE Calculate sum of squares of two inputs
    %   result = sumSquare(x, y) returns x^2 + y^2
    %
    %   Inputs:
    %       x - first number (scalar or array)
    %       y - second number (scalar or array)
    %   Output:
    %       result - sum of squares (same size as inputs)
    
    % Compute sum of squares
    result = x.^2 + y.^2;
end
