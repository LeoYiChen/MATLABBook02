% MATLABBook02_Chapter01_Lab04.m
% This script demonstrates best practices for reproducible research in MATLAB

% Part 1: Setting up a reproducible environment
% Setting a fixed random seed
rng(42, 'twister');  % Use a specific seed and generator for reproducibility
fprintf('Random number generator initialised with seed 42\n');

% Record MATLAB version and environment information
matlabVersion = version;
computerInfo = computer;
dateTimeStamp = datetime('now');

fprintf('MATLAB Version: %s\n', matlabVersion);
fprintf('Computer: %s\n', computerInfo);
fprintf('Date and Time: %s\n', dateTimeStamp);

% Check and record installed toolboxes (important for reproducibility)
v = ver;
installedToolboxes = {v.Name};
fprintf('Installed Toolboxes:\n');
disp(installedToolboxes');

% Part 2: Documenting data generation and preprocessing
% Generate synthetic dataset
n = 100;  % Number of samples
p = 5;    % Number of features

% Document data generation process
fprintf('\nGenerating synthetic dataset with %d samples and %d features\n', n, p);
fprintf('Using multivariate normal distribution with controlled correlation structure\n');

% Create correlated features
rho = 0.7;  % Correlation parameter
Sigma = eye(p);  % Start with identity matrix (uncorrelated)
for i = 1:p
    for j = 1:p
        if i ~= j
            Sigma(i,j) = rho^abs(i-j);  % Correlation decreases with distance
        end
    end
end

% Generate multivariate normal data
X = mvnrnd(zeros(1,p), Sigma, n);

% Create response variable with known coefficients
beta_true = [1.5; -0.8; 0.6; 0; 0];  % True coefficients (some are zero)
noise = 0.5 * randn(n, 1);  % Controlled noise
y = X * beta_true + noise;

% Document preprocessing steps
fprintf('Preprocessing steps:\n');
fprintf('1. Standardising features\n');

% Standardise features (important to document exactly how this is done)
X_mean = mean(X);
X_std = std(X);
X_standardized = (X - X_mean) ./ X_std;

fprintf('Feature means before standardisation: ');
fprintf('%.4f ', X_mean);
fprintf('\n');

fprintf('Feature standard deviations before standardisation: ');
fprintf('%.4f ', X_std);
fprintf('\n');

% Part 3: Algorithm implementation with detailed documentation
fprintf('\nImplementing linear regression with cross-validation\n');

% K-fold cross-validation setup
k = 5;  % Number of folds
fprintf('Using %d-fold cross-validation\n', k);

% Create folds (ensuring reproducibility by using fixed seed)
cv = cvpartition(n, 'KFold', k);

% Initialise storage for results
mse = zeros(k, 1);
coefficients = zeros(k, p);

% Document cross-validation process
fprintf('Cross-validation process:\n');
for i = 1:k
    fprintf('Fold %d: Training with %d samples, testing with %d samples\n', ...
        i, sum(cv.training(i)), sum(cv.test(i)));
    
    % Get training and test indices
    trainIdx = cv.training(i);
    testIdx = cv.test(i);
    
    % Fit model
    X_train = X_standardized(trainIdx, :);
    y_train = y(trainIdx);
    
    % Use MATLAB's built-in function for linear regression
    b = regress(y_train, [ones(sum(trainIdx), 1), X_train]);
    
    % Store coefficients (excluding intercept)
    coefficients(i, :) = b(2:end);
    
    % Make predictions
    X_test = X_standardized(testIdx, :);
    y_test = y(testIdx);
    y_pred = [ones(sum(testIdx), 1), X_test] * b;
    
    % Calculate MSE
    mse(i) = mean((y_test - y_pred).^2);
end

% Report results
fprintf('\nCross-validation results:\n');
fprintf('Mean MSE across folds: %.4f (std: %.4f)\n', mean(mse), std(mse));
fprintf('Mean coefficients across folds:\n');
mean_coeffs = mean(coefficients);
for i = 1:p
    fprintf('Feature %d: %.4f (std: %.4f)\n', i, mean_coeffs(i), std(coefficients(:,i)));
end

% Compare with true values
fprintf('\nComparison with true coefficients:\n');
for i = 1:p
    fprintf('Feature %d: Estimated = %.4f, True = %.4f, Difference = %.4f\n', ...
        i, mean_coeffs(i), beta_true(i), mean_coeffs(i) - beta_true(i));
end

% Part 4: Visualisation with proper documentation
figure;
hold on;
bar(1:p, beta_true, 'FaceColor', [0.2 0.6 0.2], 'FaceAlpha', 0.6);
bar(1:p, mean_coeffs, 'FaceColor', [0.8 0.3 0.3], 'FaceAlpha', 0.6);
errorbar(1:p, mean_coeffs, std(coefficients), '.k');
xlabel('Feature');
ylabel('Coefficient');
title('Estimated vs True Coefficients');
legend('True', 'Estimated', 'Std Dev');
grid on;
hold off;

% Add detailed figure caption in the code (for reproducibility)
fprintf('\nFigure details: Bar chart comparing estimated coefficients (red) with true coefficients (green).\n');
fprintf('Error bars represent standard deviation across cross-validation folds.\n');

% Part 5: Saving results in a reproducible format
% Create results structure with all relevant information
results = struct(...
    'datetime', dateTimeStamp, ...
    'matlab_version', matlabVersion, ...
    'computer', computerInfo, ...
    'installed_toolboxes', {installedToolboxes}, ...
    'data_generation', struct(...
        'n_samples', n, ...
        'n_features', p, ...
        'correlation_parameter', rho, ...
        'correlation_matrix', Sigma, ...
        'true_coefficients', beta_true, ...
        'noise_level', 0.5), ...
    'preprocessing', struct(...
        'feature_means', X_mean, ...
        'feature_stds', X_std), ...
    'cross_validation', struct(...
        'k_folds', k, ...
        'mse_per_fold', mse, ...
        'coefficients_per_fold', coefficients), ...
    'results', struct(...
        'mean_mse', mean(mse), ...
        'std_mse', std(mse), ...
        'mean_coefficients', mean_coeffs, ...
        'std_coefficients', std(coefficients(:,:))));

% Save results in multiple formats for maximum reproducibility
save('reproducible_research_results.mat', 'results');
writetable(struct2table(results.results), 'reproducible_research_summary.csv');

% Also save as JSON for platform-independent sharing
jsonStr = jsonencode(results);
fileID = fopen('reproducible_research_results.json', 'w');
fprintf(fileID, '%s', jsonStr);
fclose(fileID);

fprintf('\nResults saved in three formats:\n');
fprintf('1. MATLAB .mat file for comprehensive data\n');
fprintf('2. CSV file for summary statistics\n');
fprintf('3. JSON file for platform-independent sharing\n');