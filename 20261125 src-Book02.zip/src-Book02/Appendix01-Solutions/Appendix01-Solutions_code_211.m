%% Appendix01-Solutions_code_211.m
% Q-Learning Oscillator Control (Condensed)
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
import numpy as np
import matplotlib.pyplot as plt

class OscillatorEnv:
    def __init__(self, m=1.0, c=0.5, k=2.0, dt=0.1):
        self.m, self.c, self.k, self.dt = m, c, k, dt
        self.state = np.array([0.0, 0.0])  # [position, velocity]
        self.actions = np.array([-2, -1, 0, 1, 2])  # Force values
    
    def step(self, action):
        x, v = self.state
        F = self.actions[action]
        # Semi-implicit Euler integration
        a = (F - self.c * v - self.k * x) / self.m
        v_new = v + a * self.dt
        x_new = x + v_new * self.dt
        self.state = np.array([x_new, v_new])
        
        # Reward: negative quadratic cost
        reward = -(x_new**2 + v_new**2 + 0.1 * F**2)
        done = abs(x_new) < 0.1 and abs(v_new) < 0.1
        return self.state, reward, done

# Q-learning algorithm
Q = np.zeros((n_pos_bins, n_vel_bins, len(actions)))
alpha, gamma, epsilon = 0.1, 0.95, 0.2

for episode in range(1000):
    state = env.reset()
    for t in range(50):
        # Discretize continuous state
        pos_idx = np.digitize(state[0], pos_bins)
        vel_idx = np.digitize(state[1], vel_bins)
        
        # Epsilon-greedy action selection
        if np.random.rand() < epsilon:
            action = np.random.randint(len(actions))
        else:
            action = np.argmax(Q[pos_idx, vel_idx])
        
        # Take action
        next_state, reward, done = env.step(action)
        
        # Q-update
        next_pos_idx = np.digitize(next_state[0], pos_bins)
        next_vel_idx = np.digitize(next_state[1], vel_bins)
        
        Q[pos_idx, vel_idx, action] += alpha * (
            reward + gamma * np.max(Q[next_pos_idx, next_vel_idx]) - 
            Q[pos_idx, vel_idx, action]
        )
        
        state = next_state
        if done:
            break
