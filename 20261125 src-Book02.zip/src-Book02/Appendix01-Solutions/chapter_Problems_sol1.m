%% chapter_Problems_sol1.m
% Signal processing for AI applications
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Problems_sol1
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define time vector and sampling parameters
fs = 1000; % Sampling frequency (Hz)
t = 0:1/fs:2-1/fs; % Time vector (2 seconds)
N = length(t); % Number of samples

% Generate two sinusoidal signals with different characteristics
f1 = 5; % Frequency of first signal (Hz)
f2 = 10; % Frequency of second signal (Hz)
A1 = 1.5; % Amplitude of first signal
A2 = 0.8; % Amplitude of second signal
signal1 = A1 * sin(2pif1t);
signal2 = A2 * sin(2pif2t);

% Add Gaussian noise with different variances
noise1 = 0.2 * randn(size(t));
noise2 = 0.1 * randn(size(t));
noisy_signal1 = signal1 + noise1;
noisy_signal2 = signal2 + noise2;

% Perform normalisation (scaling to [0,1])
normalized_signal1 = (noisy_signal1 - min(noisy_signal1)) / (max(noisy_signal1) - min(noisy_signal1));
normalized_signal2 = (noisy_signal2 - min(noisy_signal2)) / (max(noisy_signal2) - min(noisy_signal2));

% Perform standardisation (zero mean, unit variance)
standardized_signal1 = (noisy_signal1 - mean(noisy_signal1)) / std(noisy_signal1);
standardized_signal2 = (noisy_signal2 - mean(noisy_signal2)) / std(noisy_signal2);

% Calculate cross-correlation between signals
[xcorr_values, lags] = xcorr(noisy_signal1, noisy_signal2, 'coeff');
lag_time = lags / fs; % Convert lags to time

% Extract basic features
features = struct();
% Signal 1 features
features.signal1.mean = mean(noisy_signal1);
features.signal1.std = std(noisy_signal1);
features.signal1.max = max(noisy_signal1);
features.signal1.min = min(noisy_signal1);
features.signal1.energy = sum(noisy_signal1.^2) / N;
% Signal 2 features
features.signal2.mean = mean(noisy_signal2);
features.signal2.std = std(noisy_signal2);
features.signal2.max = max(noisy_signal2);
features.signal2.min = min(noisy_signal2);
features.signal2.energy = sum(noisy_signal2.^2) / N;

% Calculate frequency spectra
freq = (0:N-1)(fs/N); % Frequency vector
freq = freq(1:floor(N/2)+1); % Keep only positive frequencies
Y1 = fft(noisy_signal1);
P1 = abs(Y1/N);
P1 = P1(1:floor(N/2)+1);
P1(2:end) = 2P1(2:end); % Correct for single-sided spectrum

Y2 = fft(noisy_signal2);
P2 = abs(Y2/N);
P2 = P2(1:floor(N/2)+1);
P2(2:end) = 2*P2(2:end);

% Visualisations
figure('Position', [100, 100, 1200, 800]);

% Time domain signals
subplot(3,2,1);
plot(t, noisy_signal1, 'b', t, normalized_signal1, 'r', t, standardized_signal1, 'g');
title('Signal 1: Original and Processed');
xlabel('Time (s)');
ylabel('Amplitude');
legend('Noisy', 'Normalised', 'Standardised');
grid on;

subplot(3,2,2);
plot(t, noisy_signal2, 'b', t, normalized_signal2, 'r', t, standardized_signal2, 'g');
title('Signal 2: Original and Processed');
xlabel('Time (s)');
ylabel('Amplitude');
legend('Noisy', 'Normalised', 'Standardised');
grid on;

% Frequency spectra
subplot(3,2,3);
plot(freq, P1);
title('Frequency Spectrum of Signal 1');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;
xlim([0, 20]); % Limit to relevant frequency range

subplot(3,2,4);
plot(freq, P2);
title('Frequency Spectrum of Signal 2');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;
xlim([0, 20]); % Limit to relevant frequency range

% Cross-correlation
subplot(3,2,5:6);
plot(lag_time, xcorr_values);
title('Cross-correlation Between Signals');
xlabel('Time Lag (s)');
ylabel('Correlation Coefficient');
grid on;
xlim([-0.5, 0.5]); % Limit to relevant lag range

% Display extracted features
disp('Extracted Features:');
disp(features);

% Find maximum correlation and corresponding lag
[max_corr, max_idx] = max(abs(xcorr_values));
max_lag = lag_time(max_idx);
fprintf('Maximum correlation: %.4f at lag: %.4f seconds\n', xcorr_values(max_idx), max_lag);
