%% prob11_code.m
% LSTM-based traffic prediction with attention mechanism.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob11_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Deep Learning Traffic Prediction: LSTM with Attention
% File: MATLABBook02_Chapter07_Problem11.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Implements LSTM neural network for multivariate traffic
%              volume prediction with feature importance analysis and
%              comprehensive performance evaluation
% =========================================================================

function MATLABBook02_Chapter07_Problem11()
    % Main function for Problem 11: Traffic Prediction using Deep Learning
    
    clc; clear; close all;
    
    % Set random seed for reproducibility
    rng(2024);
    
    % Generate synthetic traffic data (or load real data)
    [features, target, featureNames] = generateTrafficData();
    
    % Preprocess and normalise features
    [featuresNorm, mu, sigma] = normaliseFeatures(features);
    
    % Create sequences for LSTM
    sequenceLength = 24; % 24-hour lookback window
    [XTrain, YTrain, XVal, YVal, XTest, YTest] = ...
        prepareSequences(featuresNorm, target, sequenceLength);
    
    % Build and train LSTM model
    net = buildAndTrainLSTM(XTrain, YTrain, XVal, YVal, size(features, 2));
    
    % Make predictions on test set
    YPred = predict(net, XTest);
    
    % Evaluate model performance
    evaluateModel(YTest, YPred);
    
    % Visualise results
    visualisePredictions(YTest, YPred);
    
    % Feature importance analysis
    importance = analyseFeatureImportance(net, XTest, YTest, featureNames);
    
    % Display and visualise feature importance
    displayFeatureImportance(featureNames, importance);
    
    fprintf('\nAnalysis completed successfully.\n');
end

function [features, target, featureNames] = generateTrafficData()
    % GENERATETRAFFICDATA - Creates synthetic traffic dataset
    %
    % Outputs:
    %   features - Matrix of predictor variables
    %   target - Vector of traffic volumes
    %   featureNames - Cell array of feature names
    
    fprintf('Generating synthetic traffic data...\n');
    
    % Generate 90 days of hourly data
    numDays = 90;
    numHours = numDays * 24;
    
    % Time-based features
    hour = mod(0:numHours-1, 24)';
    dayOfWeek = mod(floor((0:numHours-1)/24), 7)' + 1;
    dayOfMonth = mod(floor((0:numHours-1)/24), 30)' + 1;
    isWeekend = double(dayOfWeek >= 6);
    
    % Weather features (simulated)
    temperature = 15 + 10*sin(2*pi*(0:numHours-1)/(24*365)) + 3*randn(numHours, 1);
    precipitation = max(0, randn(numHours, 1));
    
    % Event indicator (random special events)
    eventIndicator = double(rand(numHours, 1) < 0.05);
    
    % Generate base traffic pattern
    baseTraffic = 1000 + ...
                  500*sin(2*pi*hour/24) + ...           % Daily pattern
                  200*(dayOfWeek <= 5) + ...             % Weekday boost
                  -300*isWeekend + ...                   % Weekend reduction
                  50*eventIndicator + ...                % Event impact
                  -10*temperature + ...                  % Temperature effect
                  -50*precipitation;                     % Rain effect
    
    % Add noise and ensure positive values
    target = max(100, baseTraffic + 100*randn(numHours, 1));
    
    % Create lag features
    lag1 = [NaN; target(1:end-1)];
    lag24 = [NaN(24,1); target(1:end-24)];
    
    % Rolling mean (7-day)
    rollingMean7d = movmean(target, [168, 0], 'omitnan');
    
    % Remove initial NaN rows
    validIdx = 25:numHours;
    
    features = [hour(validIdx), dayOfWeek(validIdx), isWeekend(validIdx), ...
                temperature(validIdx), precipitation(validIdx), ...
                eventIndicator(validIdx), lag1(validIdx), lag24(validIdx), ...
                rollingMean7d(validIdx)];
    
    target = target(validIdx);
    
    featureNames = {'Hour', 'DayOfWeek', 'IsWeekend', 'Temperature', ...
                    'Precipitation', 'EventIndicator', 'Lag1h', 'Lag24h', ...
                    'RollingMean7d'};
    
    fprintf('Generated %d samples with %d features\n', length(target), size(features, 2));
end

function [featuresNorm, mu, sigma] = normaliseFeatures(features)
    % NORMALISEFEATURES - Z-score normalisation
    
    mu = mean(features);
    sigma = std(features);
    featuresNorm = (features - mu) ./ sigma;
end

function [XTrain, YTrain, XVal, YVal, XTest, YTest] = ...
    prepareSequences(features, target, seqLength)
    % PREPARESEQUENCES - Creates sequences for LSTM training
    
    fprintf('Preparing sequences (length=%d)...\n', seqLength);
    
    numObservations = size(features, 1) - seqLength;
    numFeatures = size(features, 2);
    
    X = cell(numObservations, 1);
    Y = zeros(numObservations, 1);
    
    for i = 1:numObservations
        X{i} = features(i:i+seqLength-1, :)';
        Y(i) = target(i + seqLength);
    end
    
    % Chronological split: 70% train, 15% val, 15% test
    nTrain = floor(0.70 * numObservations);
    nVal = floor(0.15 * numObservations);
    
    XTrain = X(1:nTrain);
    YTrain = Y(1:nTrain);
    
    XVal = X(nTrain+1:nTrain+nVal);
    YVal = Y(nTrain+1:nTrain+nVal);
    
    XTest = X(nTrain+nVal+1:end);
    YTest = Y(nTrain+nVal+1:end);
    
    fprintf('Training samples: %d, Validation: %d, Testing: %d\n', ...
            length(YTrain), length(YVal), length(YTest));
end

function net = buildAndTrainLSTM(XTrain, YTrain, XVal, YVal, numFeatures)
    % BUILDANDTRAINLSTM - Constructs and trains LSTM network
    
    fprintf('\nBuilding LSTM architecture...\n');
    
    numHiddenUnits = 128;
    numResponses = 1;
    
    layers = [
        sequenceInputLayer(numFeatures, 'Name', 'input')
        lstmLayer(numHiddenUnits, 'OutputMode', 'sequence', 'Name', 'lstm1')
        dropoutLayer(0.2, 'Name', 'dropout1')
        lstmLayer(numHiddenUnits/2, 'OutputMode', 'sequence', 'Name', 'lstm2')
        dropoutLayer(0.2, 'Name', 'dropout2')
        lstmLayer(numHiddenUnits/4, 'OutputMode', 'last', 'Name', 'lstm3')
        fullyConnectedLayer(numResponses, 'Name', 'fc')
        regressionLayer('Name', 'output')];
    
    options = trainingOptions('adam', ...
        'MaxEpochs', 50, ...
        'MiniBatchSize', 64, ...
        'InitialLearnRate', 0.001, ...
        'LearnRateSchedule', 'piecewise', ...
        'LearnRateDropFactor', 0.5, ...
        'LearnRateDropPeriod', 15, ...
        'GradientThreshold', 1, ...
        'Shuffle', 'every-epoch', ...
        'ValidationData', {XVal, YVal}, ...
        'ValidationFrequency', 30, ...
        'ValidationPatience', 10, ...
        'Verbose', true, ...
        'Plots', 'training-progress', ...
        'ExecutionEnvironment', 'auto');
    
    fprintf('Training LSTM network...\n');
    tic;
    net = trainNetwork(XTrain, YTrain, layers, options);
    trainingTime = toc;
    fprintf('Training completed in %.2f minutes\n', trainingTime/60);
end

function evaluateModel(YTest, YPred)
    % EVALUATEMODEL - Calculates and displays performance metrics
    
    rmse = sqrt(mean((YTest - YPred).^2));
    mae = mean(abs(YTest - YPred));
    mape = mean(abs((YTest - YPred)./YTest)) * 100;
    rSquared = 1 - sum((YTest - YPred).^2) / sum((YTest - mean(YTest)).^2);
    
    fprintf('\n========================================\n');
    fprintf('   MODEL PERFORMANCE METRICS\n');
    fprintf('========================================\n');
    fprintf('RMSE:      %.2f vehicles/hour\n', rmse);
    fprintf('MAE:       %.2f vehicles/hour\n', mae);
    fprintf('MAPE:      %.2f%%\n', mape);
    fprintf('R-squared: %.4f\n', rSquared);
    fprintf('========================================\n');
end

function visualisePredictions(YTest, YPred)
    % VISUALISEPREDICTIONS - Creates comprehensive visualisation
    
    fprintf('\nGenerating visualisations...\n');
    
    figure('Name', 'Traffic Prediction Results', 'Position', [100, 100, 1400, 800]);
    
    % Subplot 1: Actual vs Predicted
    subplot(3,1,1);
    timeSteps = 1:length(YTest);
    plot(timeSteps, YTest, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Actual');
    hold on;
    plot(timeSteps, YPred, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Predicted');
    xlabel('Time Step (hours)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Traffic Volume (vehicles/hour)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Traffic Prediction: Actual vs Predicted', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    legend('Location', 'best', 'FontSize', 10);
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 2: Residual Analysis
    subplot(3,1,2);
    residuals = YTest - YPred;
    plot(timeSteps, residuals, 'k-', 'LineWidth', 1);
    hold on;
    yline(0, 'r-', 'LineWidth', 1.5);
    yline(2*std(residuals), 'g-', '$+2\sigma$', 'LineWidth', 1, ...
          'Interpreter', 'latex', 'FontSize', 10);
    yline(-2*std(residuals), 'g-', '$-2\sigma$', 'LineWidth', 1, ...
          'Interpreter', 'latex', 'FontSize', 10);
    xlabel('Time Step (hours)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Residual (vehicles/hour)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Prediction Residuals', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 3: Residual Distribution
    subplot(3,1,3);
    histogram(residuals, 30, 'FaceColor', [0.3, 0.6, 0.8], 'EdgeColor', 'k');
    hold on;
    xRange = linspace(min(residuals), max(residuals), 100);
    normalPDF = normpdf(xRange, mean(residuals), std(residuals));
    normalPDF_scaled = normalPDF * (max(histcounts(residuals, 30)) / max(normalPDF));
    plot(xRange, normalPDF_scaled, 'r-', 'LineWidth', 2, 'DisplayName', 'Normal Fit');
    xlabel('Prediction Error (vehicles/hour)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
    title('Residual Distribution', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    legend('Location', 'best', 'FontSize', 10);
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    hold off;
end

function importance = analyseFeatureImportance(net, XTest, YTest, featureNames)
    % ANALYSEFEATUREIMPORTANCE - Permutation-based importance
    
    fprintf('\nCalculating feature importance...\n');
    
    YPred_baseline = predict(net, XTest);
    baseline_rmse = sqrt(mean((YTest - YPred_baseline).^2));
    
    numFeatures = length(featureNames);
    importance = zeros(numFeatures, 1);
    
    for f = 1:numFeatures
        fprintf('  Processing feature %d/%d: %s\n', f, numFeatures, featureNames{f});
        
        XTest_permuted = XTest;
        for i = 1:length(XTest_permuted)
            XTest_permuted{i}(f, :) = XTest_permuted{i}(f, randperm(size(XTest_permuted{i}, 2)));
        end
        
        YPred_permuted = predict(net, XTest_permuted);
        permuted_rmse = sqrt(mean((YTest - YPred_permuted).^2));
        
        importance(f) = permuted_rmse - baseline_rmse;
    end
end

function displayFeatureImportance(featureNames, importance)
    % DISPLAYFEATUREIMPORTANCE - Visualises feature importance
    
    [importanceSorted, idx] = sort(importance, 'descend');
    featureNamesSorted = featureNames(idx);
    
    fprintf('\n========================================\n');
    fprintf('   FEATURE IMPORTANCE RANKING\n');
    fprintf('========================================\n');
    for i = 1:length(featureNames)
        fprintf('%d. %-20s: %.4f\n', i, featureNamesSorted{i}, importanceSorted(i));
    end
    fprintf('========================================\n');
    
    figure('Name', 'Feature Importance', 'Position', [100, 100, 900, 600]);
    barh(importanceSorted, 'FaceColor', [0.2, 0.6, 0.8], 'EdgeColor', 'k', 'LineWidth', 1.2);
    set(gca, 'YTick', 1:length(featureNames), 'YTickLabel', featureNamesSorted, 'FontSize', 10);
    xlabel('Importance (RMSE Increase)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Feature Importance Analysis', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    set(gca, 'LineWidth', 1.2);
end
