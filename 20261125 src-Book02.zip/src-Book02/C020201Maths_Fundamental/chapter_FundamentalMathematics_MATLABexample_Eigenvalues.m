%% chapter_FundamentalMathematics_MATLABexample_Eigenvalues.m
% Eigenvalues, eigenvectors, and spectral decomposition.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_Eigenvalues
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_5_1_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates eigenvalue and eigenvector computation with
%              applications to spectral decomposition and stability analysis.

function demonstrateEigenvalues()
    fprintf('Eigenvalues and Eigenvectors in Linear Algebra\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic eigenvalue computation
    demonstrateBasicEigen();
    
    % Part 2: Spectral decomposition
    demonstrateSpectralDecomposition();
    
    % Part 3: Symmetric matrices and the Spectral Theorem
    demonstrateSpectralTheorem();
    
    % Part 4: Application to stability analysis
    demonstrateStabilityAnalysis();
    
    % Part 5: Application to Principal Component Analysis
    demonstratePCA();
end

function demonstrateBasicEigen()
    % Demonstrate basic eigenvalue and eigenvector computation
    
    fprintf('Part 1: Basic Eigenvalue Computation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define matrix
    A = [4, -2, 1; -2, 4, -2; 1, -2, 4];
    
    fprintf('Matrix A:\n');
    disp(A);
    
    % Compute eigenvalues and eigenvectors
    [V, D] = eig(A);
    
    fprintf('Eigenvalues (diagonal of D):\n');
    eigenvalues = diag(D);
    fprintf('  λ₁ = %.6f\n', eigenvalues(1));
    fprintf('  λ₂ = %.6f\n', eigenvalues(2));
    fprintf('  λ₃ = %.6f\n', eigenvalues(3));
    
    fprintf('\nEigenvectors (columns of V):\n');
    fprintf('v₁ = [%.6f; %.6f; %.6f]\n', V(:, 1));
    fprintf('v₂ = [%.6f; %.6f; %.6f]\n', V(:, 2));
    fprintf('v₃ = [%.6f; %.6f; %.6f]\n', V(:, 3));
    
    % Verify eigenvalue equation: Av = λv
    fprintf('\nVerification of Av = λv:\n');
    for k = 1:3
        Av = A * V(:, k);
        lambda*V = eigenvalues(k) * V(:, k);
        error = norm(Av - lambda*V);
        fprintf('  ||Av%d - λ%dv%d|| = %.10e\n', k, k, k, error);
    end
    fprintf('\n');
end

function demonstrateSpectralDecomposition()
    % Demonstrate eigendecomposition: A = VΛV^(-1)
    
    fprintf('Part 2: Spectral Decomposition\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create diagonalizable matrix
    A = [1, 2, 3; 0, 4, 5; 0, 0, 6];
    
    fprintf('Matrix A (upper triangular):\n');
    disp(A);
    
    % Compute eigendecomposition
    [V, D] = eig(A);
    
    fprintf('Eigendecomposition: A = VΛV^{-1}\n\n');
    fprintf('Eigenvector matrix V:\n');
    disp(V);
    fprintf('Eigenvalue matrix Λ:\n');
    disp(D);
    
    % Reconstruct A
    A_reconstructed = V * D * inv(V);
    
    fprintf('Reconstructed A = VΛV^{-1}:\n');
    disp(A_reconstructed);
    
    % Verify reconstruction
    reconstructionError = norm(A - A_reconstructed, 'fro');
    fprintf('Reconstruction error: ||A - VΛV^{-1}||_F = %.10e\n\n', ...
            reconstructionError);
    
    % Application: Matrix powers
    fprintf('Application: Computing matrix powers using eigendecomposition\n');
    k = 10;
    
    % Direct computation
    tic;
    A_power_direct = A^k;
    time_direct = toc;
    
    % Using eigendecomposition: A^k = V Λ^k V^{-1}
    tic;
    D_power = D^k; % Fast for diagonal matrices
    A_power_eigen = V * D_power * inv(V);
    time_eigen = toc;
    
    fprintf('A^%d computed both ways:\n', k);
    fprintf('  Direct method time: %.6f seconds\n', time_direct);
    fprintf('  Eigen method time:  %.6f seconds\n', time_eigen);
    
    powerError = norm(A_power_direct - A_power_eigen, 'fro');
    fprintf('  Difference: ||A^k_direct - A^k_eigen||_F = %.10e\n\n', ...
            powerError);
end

function demonstrateSpectralTheorem()
    % Demonstrate Spectral Theorem for symmetric matrices
    
    fprintf('Part 3: Spectral Theorem for Symmetric Matrices\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create symmetric matrix
    B = randn(4, 4);
    A = (B + B') / 2; % Ensure symmetry
    
    fprintf('Symmetric matrix A:\n');
    fprintf('%.6f  %.6f  %.6f  %.6f\n', A');
    
    % Verify symmetry
    symmetryError = norm(A - A', 'fro');
    fprintf('\nSymmetry check: ||A - A''||_F = %.10e\n\n', symmetryError);
    
    % Compute eigendecomposition
    [Q, Lambda] = eig(A);
    
    fprintf('Spectral Theorem: A = QΛQ'' (Q orthogonal, Λ diagonal)\n\n');
    
    % Verify eigenvalues are real
    eigenvalues = diag(Lambda);
    fprintf('Eigenvalues (all real for symmetric matrices):\n');
    fprintf('  %.6f + %.6fi\n', [real(eigenvalues), imag(eigenvalues)]');
    fprintf('Maximum imaginary part: %.10e\n\n', max(abs(imag(eigenvalues))));
    
    % Verify orthogonality of Q
    orthogonalityError = norm(Q' * Q - eye(size(Q)), 'fro');
    fprintf('Orthogonality of Q: ||Q''Q - I||_F = %.10e\n', orthogonalityError);
    
    % Verify eigenvectors are orthogonal
    fprintf('\nPairwise dot products of eigenvectors:\n');
    for i = 1:4
        for j = i+1:4
            dotProduct = Q(:, i)' * Q(:, j);
            fprintf('  v%d'' · v%d = %.10e\n', i, j, dotProduct);
        end
    end
    
    % Reconstruct using spectral decomposition
    A_reconstructed = Q * Lambda * Q';
    reconstructionError = norm(A - A_reconstructed, 'fro');
    fprintf('\nReconstruction: ||A - QΛQ''||_F = %.10e\n\n', ...
            reconstructionError);
end

function demonstrateStabilityAnalysis()
    % Application: Stability analysis of dynamical systems
    
    fprintf('Part 4: Application - Stability Analysis\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    fprintf('Analyzing stability of discrete-time dynamical system:\n');
    fprintf('  x(k+1) = A x(k)\n\n');
    
    % Stable system (all eigenvalues inside unit circle)
    A_stable = [0.8, 0.2; -0.3, 0.7];
    
    fprintf('Case 1: Stable System\n');
    fprintf('State transition matrix A:\n');
    disp(A_stable);
    
    eigenvalues_stable = eig(A_stable);
    magnitudes_stable = abs(eigenvalues_stable);
    
    fprintf('Eigenvalues:\n');
    fprintf('  λ₁ = %.4f + %.4fi, |λ₁| = %.4f\n', ...
            real(eigenvalues_stable(1)), imag(eigenvalues_stable(1)), ...
            magnitudes_stable(1));
    fprintf('  λ₂ = %.4f + %.4fi, |λ₂| = %.4f\n', ...
            real(eigenvalues_stable(2)), imag(eigenvalues_stable(2)), ...
            magnitudes_stable(2));
    
    if all(magnitudes_stable < 1)
        fprintf('\nSystem is STABLE (all |λᵢ| < 1)\n');
    else
        fprintf('\nSystem is UNSTABLE\n');
    end
    
    % Simulate system evolution
    x0 = [10; 5];
    numSteps = 30;
    trajectory_stable = zeros(2, numSteps);
    trajectory_stable(:, 1) = x0;
    
    for k = 2:numSteps
        trajectory_stable(:, k) = A_stable * trajectory_stable(:, k-1);
    end
    
    % Unstable system
    fprintf('\nCase 2: Unstable System\n');
    A_unstable = [1.1, 0.2; -0.3, 1.15];
    
    fprintf('State transition matrix A:\n');
    disp(A_unstable);
    
    eigenvalues_unstable = eig(A_unstable);
    magnitudes_unstable = abs(eigenvalues_unstable);
    
    fprintf('Eigenvalues:\n');
    fprintf('  λ₁ = %.4f + %.4fi, |λ₁| = %.4f\n', ...
            real(eigenvalues_unstable(1)), imag(eigenvalues_unstable(1)), ...
            magnitudes_unstable(1));
    fprintf('  λ₂ = %.4f + %.4fi, |λ₂| = %.4f\n', ...
            real(eigenvalues_unstable(2)), imag(eigenvalues_unstable(2)), ...
            magnitudes_unstable(2));
    
    if all(magnitudes_unstable < 1)
        fprintf('\nSystem is STABLE (all |λᵢ| < 1)\n');
    else
        fprintf('\nSystem is UNSTABLE (some |λᵢ| ≥ 1)\n');
    end
    
    trajectory_unstable = zeros(2, numSteps);
    trajectory_unstable(:, 1) = x0;
    
    for k = 2:numSteps
        trajectory_unstable(:, k) = A_unstable * trajectory_unstable(:, k-1);
    end
    
    % Visualize both systems
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    plot(1:numSteps, trajectory_stable(1, :), 'b-o', ...
         'LineWidth', 2, 'DisplayName', '$x_1(k)$');
    hold on;
    plot(1:numSteps, trajectory_stable(2, :), 'r-s', ...
         'LineWidth', 2, 'DisplayName', '$x_2(k)$');
    grid on;
    xlabel('Time Step $k$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('State Value', 'Interpreter', 'latex', 'FontSize', 12);
    title('Stable System: State Evolution', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    set(gca, 'FontSize', 11);
    
    subplot(1, 2, 2);
    plot(1:numSteps, trajectory_unstable(1, :), 'b-o', ...
         'LineWidth', 2, 'DisplayName', '$x_1(k)$');
    hold on;
    plot(1:numSteps, trajectory_unstable(2, :), 'r-s', ...
         'LineWidth', 2, 'DisplayName', '$x_2(k)$');
    grid on;
    xlabel('Time Step $k$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('State Value', 'Interpreter', 'latex', 'FontSize', 12);
    title('Unstable System: State Evolution', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    set(gca, 'FontSize', 11);
    
    fprintf('\nTrajectories visualized showing stability behavior\n\n');
end

function demonstratePCA()
    % Application: Principal Component Analysis
    
    fprintf('Part 5: Application - Principal Component Analysis\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Generate correlated 2*D data
    rng(42); % For reproducibility
    numSamples = 200;
    
    % Create data with known structure
    theta = pi/4; % 45-degree rotation
    R = [cos(theta), -sin(theta); sin(theta), cos(theta)];
    originalData = randn(2, numSamples) .* [3; 1]; % Different variances
    data = R * originalData; % Rotate
    
    fprintf('Generated 2*D dataset with %d samples\n', numSamples);
    fprintf('Data shows correlation due to underlying structure\n\n');
    
    % Compute covariance matrix
    dataCentered = data - mean(data, 2);
    covMatrix = (dataCentered * dataCentered') / (numSamples - 1);
    
    fprintf('Covariance matrix:\n');
    fprintf('%.6f  %.6f\n', covMatrix');
    
    % Perform PCA via eigendecomposition
    [principalComponents, varianceMatrix] = eig(covMatrix);
    variances = diag(varianceMatrix);
    
    % Sort by decreasing variance
    [variances, sortIdx] = sort(variances, 'descend');
    principalComponents = principalComponents(:, sortIdx);
    
    fprintf('\nPrincipal Component Analysis Results:\n');
    fprintf('PC1 variance: %.6f (%.1f%% of total)\n', ...
            variances(1), 100 * variances(1) / sum(variances));
    fprintf('PC2 variance: %.6f (%.1f%% of total)\n', ...
            variances(2), 100 * variances(2) / sum(variances));
    
    fprintf('\nPrincipal Component directions:\n');
    fprintf('PC1 = [%.6f; %.6f]\n', principalComponents(:, 1));
    fprintf('PC2 = [%.6f; %.6f]\n', principalComponents(:, 2));
    
    % Project data onto principal components
    projectedData = principalComponents' * dataCentered;
    
    % Visualize
    figure('Position', [100, 100, 1200, 500]);
    
    % Original data
    subplot(1, 2, 1);
    scatter(data(1, :), data(2, :), 30, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    
    % Draw principal component axes
    origin = mean(data, 2);
    scale = 3;
    quiver(origin(1), origin(2), ...
           scale*sqrt(variances(1))*principalComponents(1, 1), ...
           scale*sqrt(variances(1))*principalComponents(2, 1), ...
           0, 'r', 'LineWidth', 3, 'MaxHeadSize', 0.5);
    quiver(origin(1), origin(2), ...
           scale*sqrt(variances(2))*principalComponents(1, 2), ...
           scale*sqrt(variances(2))*principalComponents(2, 2), ...
           0, 'g', 'LineWidth', 3, 'MaxHeadSize', 0.5);
    
    axis equal;
    grid on;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Data with Principal Components', ...
          'Interpreter', 'latex', 'FontSize', 13);
    legend('Data', 'PC1', 'PC2', 'Interpreter', 'latex', 'Location', 'best');
    set(gca, 'FontSize', 11);
    
    % Projected data
    subplot(1, 2, 2);
    scatter(projectedData(1, :), projectedData(2, :), 30, 'b', ...
            'filled', 'MarkerFaceAlpha', 0.6);
    axis equal;
    grid on;
    xlabel('PC1 Coordinate', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('PC2 Coordinate', 'Interpreter', 'latex', 'FontSize', 12);
    title('Data in Principal Component Space', ...
          'Interpreter', 'latex', 'FontSize', 13);
    set(gca, 'FontSize', 11);
    
    fprintf('\nvisualisation shows data aligned with principal components\n');
    fprintf('PC1 captures the direction of maximum variance\n');
end
