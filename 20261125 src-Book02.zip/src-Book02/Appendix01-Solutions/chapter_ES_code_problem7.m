%% chapter_ES_code_problem7.m
% Adaptive Load Balancing for Parallel Computing
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem7
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem7
    % MATLABBook_ChapterES_Problem7.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Parallel computing with adaptive load balancing. Compares static
    %   partitioning, dynamic work stealing, and adaptive redistribution
    %   strategies for heterogeneous workloads.
    %
    % Dependencies: Parallel Computing Toolbox
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 7
    
    fprintf('\n=== Problem 7: Adaptive Load Balancing ===\n\n');
    
    %% Initialize Parallel Pool
    
    % Check for existing pool
    poolobj = gcp('nocreate');
    if isempty(poolobj)
        poolobj = parpool('local', 4);  % Create pool with 4 workers
        fprintf('Created parallel pool with %d workers\n\n', poolobj.NumWorkers);
    else
        fprintf('Using existing parallel pool with %d workers\n\n', poolobj.NumWorkers);
    end
    
    num_workers = poolobj.NumWorkers;
    
    %% Task Generation
    
    % Generate heterogeneous tasks (varying computational costs)
    num_tasks = 100;
    
    % Task costs follow log-normal distribution (realistic for many applications)
    mu_cost = 2.0;      % Mean of log(cost)
    sigma_cost = 1.0;   % Std of log(cost)
    
    rng(42);  % Reproducibility
    task_costs = lognrnd(mu_cost, sigma_cost, num_tasks, 1);
    
    % Normalize so total work = 100 units for easier interpretation
    task_costs = task_costs / sum(task_costs) * 100;
    
    fprintf('Task generation:\n');
    fprintf('  Number of tasks: %d\n', num_tasks);
    fprintf('  Cost distribution: log-normal(%.1f, %.1f)\n', mu_cost, sigma_cost);
    fprintf('  Total work: %.1f units\n', sum(task_costs));
    fprintf('  Min cost: %.3f, Max cost: %.3f, Mean: %.3f\n\n', ...
            min(task_costs), max(task_costs), mean(task_costs));
    
    %% Serial Execution (Baseline)
    
    fprintf('=== Method 1: Serial Execution (Baseline) ===\n');
    
    tic;
    results_serial = zeros(num_tasks, 1);
    for i = 1:num_tasks
        results_serial(i) = computeTask(i, task_costs(i));
    end
    time_serial = toc;
    
    fprintf('Serial execution time: %.3f s\n', time_serial);
    fprintf('Total work completed: %.2f units\n\n', sum(task_costs));
    
    %% Method 2: Static Partitioning
    
    fprintf('=== Method 2: Static Partitioning ===\n');
    
    % Divide tasks evenly (round-robin)
    task_assignments = mod(0:num_tasks-1, num_workers) + 1;
    
    % Analyze static partition balance
    partition_work = zeros(num_workers, 1);
    for w = 1:num_workers
        partition_work(w) = sum(task_costs(task_assignments == w));
    end
    
    fprintf('Static partition work distribution:\n');
    for w = 1:num_workers
        fprintf('  Worker %d: %.2f units (%d tasks)\n', w, partition_work(w), ...
                sum(task_assignments == w));
    end
    
    lif_static_predicted = max(partition_work) / mean(partition_work);
    fprintf('Predicted load imbalance factor: %.3f\n', lif_static_predicted);
    
    % Execute with static partitioning
    tic;
    worker_times_static = zeros(num_workers, 1);
    results_static = zeros(num_tasks, 1);
    
    spmd
        worker_id = labindex;
        my_tasks = find(task_assignments == worker_id);
        
        tic_worker = tic;
        for i = 1:length(my_tasks)
            task_id = my_tasks(i);
            results_static(task_id) = computeTask(task_id, task_costs(task_id));
        end
        worker_times_static(worker_id) = toc(tic_worker);
    end
    
    time_static = toc;
    worker_times_static = [worker_times_static{:}];
    
    lif_static_actual = max(worker_times_static) / mean(worker_times_static);
    speedup_static = time_serial / time_static;
    efficiency_static = speedup_static / num_workers;
    
    fprintf('\nStatic partitioning results:\n');
    fprintf('  Total time: %.3f s\n', time_static);
    fprintf('  Speedup: %.2fx\n', speedup_static);
    fprintf('  Efficiency: %.1f%%\n', efficiency_static * 100);
    fprintf('  Load imbalance factor: %.3f\n', lif_static_actual);
    fprintf('  Worker time range: %.3f - %.3f s\n\n', ...
            min(worker_times_static), max(worker_times_static));
    
    %% Method 3: Dynamic Work Stealing
    
    fprintf('=== Method 3: Dynamic Work Stealing ===\n');
    
    % Initialize task queues (evenly distributed)
    task_queues = cell(num_workers, 1);
    for w = 1:num_workers
        task_queues{w} = find(task_assignments == w)';
    end
    
    % Work stealing simulation
    tic;
    worker_times_stealing = zeros(num_workers, 1);
    worker_tasks_completed = cell(num_workers, 1);
    steal_events = [];  % Track stealing events
    
    % Note: True work stealing requires shared memory; this is a simulation
    results_stealing = zeros(num_tasks, 1);
    
    % Simulate work stealing (simplified model)
    remaining_queues = task_queues;
    worker_work = partition_work;
    
    steal_count = 0;
    while any(cellfun(@(x) ~isempty(x), remaining_queues))
        % Find worker with minimum remaining work
        [~, idle_worker] = min(worker_work);
        
        % Find worker with maximum remaining work
        [max_work, busy_worker] = max(worker_work);
        
        if worker_work(idle_worker) < 0.5 * max_work && ~isempty(remaining_queues{busy_worker})
            % Steal half of tasks from busiest worker
            num_steal = ceil(length(remaining_queues{busy_worker}) / 2);
            stolen_tasks = remaining_queues{busy_worker}(1:num_steal);
            remaining_queues{busy_worker}(1:num_steal) = [];
            remaining_queues{idle_worker} = [remaining_queues{idle_worker}, stolen_tasks];
            
            % Update work estimates
            stolen_work = sum(task_costs(stolen_tasks));
            worker_work(busy_worker) = worker_work(busy_worker) - stolen_work;
            worker_work(idle_worker) = worker_work(idle_worker) + stolen_work;
            
            steal_count = steal_count + 1;
            steal_events = [steal_events; steal_count, idle_worker, busy_worker, num_steal];
        else
            break;  % No more beneficial stealing
        end
    end
    
    fprintf('Work stealing performed %d steal operations\n', steal_count);
    
    % Execute with redistributed tasks
    spmd
        worker_id = labindex;
        my_tasks = remaining_queues{worker_id};
        
        tic_worker = tic;
        for i = 1:length(my_tasks)
            task_id = my_tasks(i);
            results_stealing(task_id) = computeTask(task_id, task_costs(task_id));
        end
        worker_times_stealing(worker_id) = toc(tic_worker);
    end
    
    time_stealing = toc;
    worker_times_stealing = [worker_times_stealing{:}];
    
    lif_stealing = max(worker_times_stealing) / mean(worker_times_stealing);
    speedup_stealing = time_serial / time_stealing;
    efficiency_stealing = speedup_stealing / num_workers;
    
    fprintf('\nDynamic work stealing results:\n');
    fprintf('  Total time: %.3f s\n', time_stealing);
    fprintf('  Speedup: %.2fx\n', speedup_stealing);
    fprintf('  Efficiency: %.1f%%\n', efficiency_stealing * 100);
    fprintf('  Load imbalance factor: %.3f\n', lif_stealing);
    fprintf('  Improvement over static: %.1f%%\n\n', ...
            (time_static - time_stealing) / time_static * 100);
    
    %% Method 4: Adaptive Redistribution with Cost Estimation
    
    fprintf('=== Method 4: Adaptive Redistribution ===\n');
    
    % Estimate task costs based on first few tasks
    calibration_tasks = 10;
    estimated_costs = ones(num_tasks, 1) * mean(task_costs(1:calibration_tasks));
    
    % Initial partition based on estimates
    tasks_sorted = 1:num_tasks;
    estimated_sorted = estimated_costs;
    
    % Greedy partition (longest processing time first)
    [~, sort_idx] = sort(estimated_sorted, 'descend');
    tasks_sorted = tasks_sorted(sort_idx);
    
    adaptive_queues = cell(num_workers, 1);
    for i = 1:num_workers
        adaptive_queues{i} = [];
    end
    
    worker_load = zeros(num_workers, 1);
    for i = 1:num_tasks
        [~, min_worker] = min(worker_load);
        adaptive_queues{min_worker} = [adaptive_queues{min_worker}, tasks_sorted(i)];
        worker_load(min_worker) = worker_load(min_worker) + estimated_costs(tasks_sorted(i));
    end
    
    fprintf('Adaptive initial partition (based on estimates):\n');
    for w = 1:num_workers
        fprintf('  Worker %d: %.2f estimated units (%d tasks)\n', w, ...
                worker_load(w), length(adaptive_queues{w}));
    end
    
    % Execute with adaptive redistribution
    tic;
    worker_times_adaptive = zeros(num_workers, 1);
    results_adaptive = zeros(num_tasks, 1);
    
    spmd
        worker_id = labindex;
        my_tasks = adaptive_queues{worker_id};
        
        tic_worker = tic;
        for i = 1:length(my_tasks)
            task_id = my_tasks(i);
            results_adaptive(task_id) = computeTask(task_id, task_costs(task_id));
            
            % Update cost estimate (exponential moving average)
            alpha = 0.3;
            estimated_costs(task_id) = alpha * task_costs(task_id) + ...
                                       (1 - alpha) * estimated_costs(task_id);
        end
        worker_times_adaptive(worker_id) = toc(tic_worker);
    end
    
    time_adaptive = toc;
    worker_times_adaptive = [worker_times_adaptive{:}];
    
    lif_adaptive = max(worker_times_adaptive) / mean(worker_times_adaptive);
    speedup_adaptive = time_serial / time_adaptive;
    efficiency_adaptive = speedup_adaptive / num_workers;
    
    fprintf('\nAdaptive redistribution results:\n');
    fprintf('  Total time: %.3f s\n', time_adaptive);
    fprintf('  Speedup: %.2fx\n', speedup_adaptive);
    fprintf('  Efficiency: %.1f%%\n', efficiency_adaptive * 100);
    fprintf('  Load imbalance factor: %.3f\n\n', lif_adaptive);
    
    %% Scalability Analysis
    
    fprintf('=== Scalability Analysis ===\n');
    
    worker_counts = [1, 2, 4, 8];
    scalability_data = zeros(length(worker_counts), 4);  % workers, time, speedup, efficiency
    
    for idx = 1:length(worker_counts)
        nw = worker_counts(idx);
        
        if nw == 1
            % Serial execution
            t_scale = time_serial;
        else
            % Simulate parallel execution with adaptive method
            % Simplified: assume perfect load balance with LIF from adaptive method
            t_scale = time_serial / (nw / lif_adaptive);
        end
        
        scalability_data(idx, 1) = nw;
        scalability_data(idx, 2) = t_scale;
        scalability_data(idx, 3) = time_serial / t_scale;
        scalability_data(idx, 4) = scalability_data(idx, 3) / nw;
    end
    
    fprintf('Strong scaling (fixed problem size):\n');
    fprintf('  Workers | Time [s] | Speedup | Efficiency\n');
    fprintf('  ----|-----|-----|------\n');
    for idx = 1:length(worker_counts)
        fprintf('  %7d | %8.3f | %7.2fx | %9.1f%%\n', ...
                scalability_data(idx, 1), scalability_data(idx, 2), ...
                scalability_data(idx, 3), scalability_data(idx, 4) * 100);
    end
    fprintf('\n');
    
    %% Comparison Summary
    
    fprintf('=== Performance Comparison ===\n');
    fprintf('Method                  | Time [s] | Speedup | Efficiency | LIF\n');
    fprintf('------------|-----|-----|------|---\n');
    fprintf('Serial (baseline)       | %8.3f | %7.2fx | %9.1f%% | %.3f\n', ...
            time_serial, 1.0, 100.0, 1.0);
    fprintf('Static Partitioning     | %8.3f | %7.2fx | %9.1f%% | %.3f\n', ...
            time_static, speedup_static, efficiency_static*100, lif_static_actual);
    fprintf('Dynamic Work Stealing   | %8.3f | %7.2fx | %9.1f%% | %.3f\n', ...
            time_stealing, speedup_stealing, efficiency_stealing*100, lif_stealing);
    fprintf('Adaptive Redistribution | %8.3f | %7.2fx | %9.1f%% | %.3f\n\n', ...
            time_adaptive, speedup_adaptive, efficiency_adaptive*100, lif_adaptive);
    
    %% Visualization
    
    figure('Position', [100 100 1400 900]);
    
    % Subplot 1: Task cost distribution
    subplot(3, 3, 1);
    histogram(task_costs, 20, 'FaceColor', [0.3 0.6 0.9]);
    xlabel('Task Cost [units]', 'Interpreter', 'latex');
    ylabel('Frequency', 'Interpreter', 'latex');
    title('Task Cost Distribution', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 2: Worker load distribution (static)
    subplot(3, 3, 2);
    bar(1:num_workers, partition_work, 'FaceColor', [0.8 0.4 0.4]);
    xlabel('Worker ID', 'Interpreter', 'latex');
    ylabel('Assigned Work [units]', 'Interpreter', 'latex');
    title('Static Partitioning Load', 'Interpreter', 'latex');
    grid on;
    ylim([0 max(partition_work)*1.2]);
    
    % Add average line
    hold on;
    yline(mean(partition_work), 'k-', 'LineWidth', 1.5);
    hold off;
    
    % Subplot 3: Worker execution times comparison
    subplot(3, 3, 3);
    worker_time_comparison = [worker_times_static, worker_times_stealing, worker_times_adaptive];
    bar(worker_time_comparison);
    xlabel('Worker ID', 'Interpreter', 'latex');
    ylabel('Execution Time [s]', 'Interpreter', 'latex');
    title('Worker Times Comparison', 'Interpreter', 'latex');
    legend({'Static', 'Stealing', 'Adaptive'}, 'Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 4: Speedup comparison
    subplot(3, 3, 4);
    speedups = [speedup_static, speedup_stealing, speedup_adaptive];
    bar(speedups, 'FaceColor', [0.2 0.7 0.3]);
    hold on;
    yline(num_workers, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Ideal');
    hold off;
    set(gca, 'XTickLabel', {'Static', 'Stealing', 'Adaptive'});
    ylabel('Speedup', 'Interpreter', 'latex');
    title('Speedup Comparison', 'Interpreter', 'latex');
    legend('Location', 'northwest', 'Interpreter', 'latex');
    grid on;
    ylim([0 num_workers*1.2]);
    
    % Subplot 5: Efficiency comparison
    subplot(3, 3, 5);
    efficiencies = [efficiency_static, efficiency_stealing, efficiency_adaptive] * 100;
    bar(efficiencies, 'FaceColor', [0.9 0.6 0.2]);
    hold on;
    yline(100, 'r-', 'LineWidth', 1.5);
    hold off;
    set(gca, 'XTickLabel', {'Static', 'Stealing', 'Adaptive'});
    ylabel('Efficiency [\%]', 'Interpreter', 'latex');
    title('Parallel Efficiency', 'Interpreter', 'latex');
    grid on;
    ylim([0 120]);
    
    % Subplot 6: Load imbalance factor
    subplot(3, 3, 6);
    lifs = [lif_static_actual, lif_stealing, lif_adaptive];
    bar(lifs, 'FaceColor', [0.7 0.3 0.7]);
    hold on;
    yline(1.0, 'g-', 'LineWidth', 1.5, 'DisplayName', 'Perfect Balance');
    hold off;
    set(gca, 'XTickLabel', {'Static', 'Stealing', 'Adaptive'});
    ylabel('Load Imbalance Factor', 'Interpreter', 'latex');
    title('Load Balance Quality', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    ylim([0.8 max(lifs)*1.2]);
    
    % Subplot 7: Strong scaling
    subplot(3, 3, 7);
    plot(scalability_data(:,1), scalability_data(:,3), 'o-', 'LineWidth', 2, 'MarkerSize', 8);
    hold on;
    plot(scalability_data(:,1), scalability_data(:,1), 'r-', 'LineWidth', 1.5);
    hold off;
    xlabel('Number of Workers', 'Interpreter', 'latex');
    ylabel('Speedup', 'Interpreter', 'latex');
    title('Strong Scaling', 'Interpreter', 'latex');
    legend({'Actual', 'Ideal'}, 'Location', 'northwest', 'Interpreter', 'latex');
    grid on;
    set(gca, 'XScale', 'log', 'YScale', 'log');
    
    % Subplot 8: Parallel efficiency vs workers
    subplot(3, 3, 8);
    plot(scalability_data(:,1), scalability_data(:,4)*100, 's-', 'LineWidth', 2, 'MarkerSize', 8);
    hold on;
    yline(100, 'r-', 'LineWidth', 1.5);
    hold off;
    xlabel('Number of Workers', 'Interpreter', 'latex');
    ylabel('Efficiency [\%]', 'Interpreter', 'latex');
    title('Efficiency Scaling', 'Interpreter', 'latex');
    grid on;
    ylim([0 120]);
    
    % Subplot 9: Amdahl's law comparison
    subplot(3, 3, 9);
    P_range = 1:16;
    
    % Estimate parallel fraction from actual performance
    f_parallel = 1 - 1/(speedup_adaptive * (1 - 1/num_workers) + 1/num_workers);
    
    amdahl_speedup = 1 ./ ((1 - f_parallel) + f_parallel ./ P_range);
    
    plot(P_range, amdahl_speedup, 'b-', 'LineWidth', 2, 'DisplayName', ...
         sprintf('Amdahl ($f=%.2f$)', f_parallel));
    hold on;
    plot(P_range, P_range, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Linear');
    plot(scalability_data(:,1), scalability_data(:,3), 'ko', 'MarkerSize', 10, ...
         'LineWidth', 2, 'DisplayName', 'Measured');
    hold off;
    xlabel('Number of Processors', 'Interpreter', 'latex');
    ylabel('Speedup', 'Interpreter', 'latex');
    title('Amdahl''s Law Prediction', 'Interpreter', 'latex');
    legend('Location', 'northwest', 'Interpreter', 'latex');
    grid on;
    xlim([1 16]);
    ylim([0 10]);
    
    sgtitle('Adaptive Load Balancing Performance Analysis', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Figures generated.\n\n');
end

%% Helper Functions

function result = computeTask(task_id, cost)
    % Simulate computational task with given cost
    % Cost is in arbitrary units; scale to actual time
    
    time_scale = 0.001;  % 1 unit = 1 ms
    pause(cost * time_scale);
    
    % Compute some result (for demonstration)
    result = sum(rand(100, 100) * task_id) * cost;
end
