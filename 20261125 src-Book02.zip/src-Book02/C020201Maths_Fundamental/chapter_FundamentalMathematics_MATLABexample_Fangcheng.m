%% chapter_FundamentalMathematics_MATLABexample_Fangcheng.m
% Chinese Fangcheng Method: Ancient Algorithm in Modern Code
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_Fangcheng
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [solution, steps] = chineseFangcheng(A, b)
% CHINESEFANGCHENG Implements the ancient Chinese counting board method
% for solving linear systems using column operations
%
% Inputs:
%   A - Coefficient matrix (n x n)
%   b - Right-hand side vector (n x 1)
%
% Outputs:
%   solution - Solution vector
%   steps - Cell array documenting each transformation step
%
% This implementation mirrors the historical fangcheng method described
% in the Jiuzhang Suanshu (Nine Chapters on Mathematical Art)

    % Create augmented matrix in column-wise format (Chinese style)
    % Each column represents one constraint equation
    n = size(A, 1);
    augMatrix = [A; b'];
    steps = {};
    stepCount = 1;
    
    fprintf('Initial Counting Board Configuration:\n');
    displayCountingBoard(augMatrix);
    steps{stepCount} = augMatrix;
    stepCount = stepCount + 1;
    
    % Forward elimination using column operations (zhí chú method)
    for col = 1:n-1
        % Find pivot column (ancient Chinese would arrange manually)
        [~, pivotCol] = max(abs(augMatrix(col, col:n)));
        pivotCol = pivotCol + col - 1;
        
        if pivotCol ~= col
            % Column exchange (huàn wèi)
            fprintf('\nStep %d: Exchanging columns %d and %d\n', ...
                    stepCount-1, col, pivotCol);
            augMatrix(:, [col, pivotCol]) = augMatrix(:, [pivotCol, col]);
            displayCountingBoard(augMatrix);
            steps{stepCount} = augMatrix;
            stepCount = stepCount + 1;
        end
        
        % Eliminate entries below pivot using column subtraction
        for targetCol = col+1:n
            if augMatrix(col, targetCol) ~= 0
                % Calculate multiplier (Chinese: multiplying factor)
                multiplier = augMatrix(col, targetCol) / augMatrix(col, col);
                
                fprintf(['\nStep %d: Subtract %.2f times column %d ' ...
                        'from column %d\n'], stepCount-1, multiplier, ...
                        col, targetCol);
                
                % Perform column operation (zhí chú)
                augMatrix(:, targetCol) = augMatrix(:, targetCol) - ...
                                          multiplier * augMatrix(:, col);
                displayCountingBoard(augMatrix);
                steps{stepCount} = augMatrix;
                stepCount = stepCount + 1;
            end
        end
    end
    
    % Back substitution (ancient Chinese: "seeking the unknown")
    fprintf('\nBeginning back-substitution (qiú wèi zhī shù)...\n');
    solution = zeros(n, 1);
    
    for i = n:-1:1
        solution(i) = augMatrix(end, i);
        for j = i+1:n
            solution(i) = solution(i) - augMatrix(i, j) * solution(j);
        end
        solution(i) = solution(i) / augMatrix(i, i);
        fprintf('x_%d = %.4f\n', i, solution(i));
    end
end

function displayCountingBoard(matrix)
% Helper function to display matrix in counting board format
    fprintf('\nCounting Board Configuration:\n');
    fprintf('─────────────────────────────────\n');
    [rows, cols] = size(matrix);
    
    % Display coefficient rows
    for i = 1:rows-1
        fprintf('Grade %d: ', i);
        for j = 1:cols
            if matrix(i,j) >= 0
                fprintf('%6.2*f  ', matrix(i,j));
            else
                fprintf('%6.2*f* ', matrix(i,j)); % * indicates red rods
            end
        end
        fprintf('\n');
    end
    
    % Display totals row
    fprintf('─────────────────────────────────\n');
    fprintf('Totals:  ');
    for j = 1:cols
        fprintf('%6.2*f  ', matrix(end,j));
    end
    fprintf('\n─────────────────────────────────\n');
end
