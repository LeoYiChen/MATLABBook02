%% code_generate_matrix.m
% Sparse matrix generation function.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:generate_matrix
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function A = generateSparseTestMatrix(n)
    % Generate sparse symmetric positive definite test matrix
    % Mimics discretised Laplacian operator
    % Input:
    %   n - Matrix dimension
    % Output:
    %   A - Sparse symmetric matrix
    
    % Create tridiagonal structure
    diag_main = 4 * ones(n, 1);
    diag_off = -ones(n-1, 1);
    
    % Assemble sparse matrix
    A = spdiags([diag_off, diag_main, diag_off], [-1, 0, 1], n, n);
    
    % Add random sparse perturbations for realism
    nPerturbations = round(0.01 * n^2);  % 1% density
    for k = 1:nPerturbations
        i = randi(n);
        j = randi(n);
        if i ~= j
            val = 0.1 * randn();
            A(i, j) = A(i, j) + val;
            A(j, i) = A(j, i) + val;  % Maintain symmetry
        end
    end
    
    % Ensure positive definiteness
    A = A + (abs(min(eig(full(A(1:min(50,n), 1:min(50,n)))))) + 0.1) * speye(n);
end
