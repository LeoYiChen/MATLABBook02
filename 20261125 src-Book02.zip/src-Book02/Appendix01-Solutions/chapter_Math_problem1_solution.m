%% chapter_Math_problem1_solution.m
% Complete solution for rocket velocity analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem1_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem1_RocketVelocityAnalysis()
    % PROBLEM1_ROCKETVELOCITYANALYSIS Compute velocity and acceleration using
    % numerical differentiation
    %
    % This function analyses a sounding rocket trajectory by computing
    % velocity and acceleration profiles from position data using three
    % finite difference schemes. It compares numerical approximations with
    % analytical solutions and investigates step size effects.
    %
    % Author: Dr Yi Chen
    % Date: 2025
    % MATLAB Version: R2023b or later
    
    fprintf('\\n=== Problem 1: Rocket Velocity Analysis ===\\n\\n');
    
    % Define altitude function and analytical derivatives
    h_func = @(t) 0.5*t.^3 - 2*t.^2 + 150*t;  % Position (m)
    v_analytical = @(t) 1.5*t.^2 - 4*t + 150;  % Velocity (m/s)
    a_analytical = @(t) 3*t - 4;               % Acceleration (m/s^2)
    
    % Time parameters
    t_max = 100;  % seconds
    dt = 1.0;     % time step (seconds)
    
    fprintf('Trajectory Parameters:\\n');
    fprintf('  Time span: 0 to %d seconds\\n', t_max);
    fprintf('  Time step: %.2f seconds\\n', dt);
    fprintf('  Altitude function: h(t) = 0.5t^3 - 2t^2 + 150t\\n\\n');
    
    % Generate time vector and position data
    t = 0:dt:t_max;
    h = h_func(t);
    
    % Compute numerical derivatives using different schemes
    [v_forward, v_backward, v_central] = computeVelocity(h, dt, t);
    [a_central] = computeAcceleration(h, dt, t);
    
    % Compute analytical solutions
    v_exact = v_analytical(t);
    a_exact = a_analytical(t);
    
    % Calculate errors
    analyseErrors(v_forward, v_backward, v_central, v_exact, ...
        a_central, a_exact, t, dt);
    
    % Create comprehensive visualisation
    createVisualisations(t, h, v_forward, v_backward, v_central, ...
        v_exact, a_central, a_exact);
    
    % Investigate step size sensitivity
    investigateStepSize(h_func, v_analytical, a_analytical, t_max);
    
    fprintf('\\nAnalysis complete!\\n');
end

function [v_forward, v_backward, v_central] = computeVelocity(h, dt, t)
    % COMPUTEVELOCITY Calculate velocity using three finite difference schemes
    %
    % Inputs:
    %   h  - Position vector (m)
    %   dt - Time step (s)
    %   t  - Time vector (s)
    %
    % Outputs:
    %   v_forward  - Forward difference approximation
    %   v_backward - Backward difference approximation
    %   v_central  - Central difference approximation
    
    n = length(h);
    
    % Forward difference: df/dt ≈ (f(t+뿯νt) - f(t)) / 뿯νt
    % Valid for indices 1 to n-1
    v_forward = zeros(size(t));
    v_forward(1:end-1) = (h(2:end) - h(1:end-1)) / dt;
    v_forward(end) = v_forward(end-1);  % Extrapolate last point
    
    % Backward difference: df/dt ≈ (f(t) - f(t-뿯νt)) / 뿯νt  
    % Valid for indices 2 to n
    v_backward = zeros(size(t));
    v_backward(2:end) = (h(2:end) - h(1:end-1)) / dt;
    v_backward(1) = v_backward(2);  % Extrapolate first point
    
    % Central difference: df/dt ≈ (f(t+뿯νt) - f(t-뿯νt)) / (2뿯νt)
    % Valid for indices 2 to n-1
    v_central = zeros(size(t));
    v_central(2:end-1) = (h(3:end) - h(1:end-2)) / (2*dt);
    v_central(1) = v_central(2);        % Extrapolate endpoints
    v_central(end) = v_central(end-1);
    
    fprintf('Velocity Computation:\\n');
    fprintf('  Forward difference points: %d\\n', sum(~isnan(v_forward)));
    fprintf('  Backward difference points: %d\\n', sum(~isnan(v_backward)));
    fprintf('  Central difference points: %d\\n', sum(~isnan(v_central)));
end

function [a_central] = computeAcceleration(h, dt, t)
    % COMPUTEACCELERATION Calculate acceleration using central difference
    %
    % Uses second derivative approximation:
    % d뿯½f/dt뿯½ ≈ (f(t+뿯νt) - 2f(t) + f(t-뿯νt)) / (뿯νt)뿯½
    
    n = length(h);
    a_central = zeros(size(t));
    
    % Central difference for second derivative
    % Valid for indices 2 to n-1
    a_central(2:end-1) = (h(3:end) - 2*h(2:end-1) + h(1:end-2)) / (dt^2);
    a_central(1) = a_central(2);        % Extrapolate endpoints
    a_central(end) = a_central(end-1);
    
    fprintf('  Acceleration (2nd derivative) points: %d\\n\\n', ...
        sum(~isnan(a_central)));
end

function analyseErrors(v_forward, v_backward, v_central, v_exact, ...
    a_central, a_exact, t, dt)
    % ANALYSEERRORS Compute and display error metrics
    
    fprintf('Error Analysis:\\n');
    fprintf('Time step: %.2f seconds\\n\\n', dt);
    
    % Velocity errors
    err_forward = abs(v_forward - v_exact);
    err_backward = abs(v_backward - v_exact);
    err_central = abs(v_central - v_exact);
    
    fprintf('Velocity Errors:\\n');
    fprintf('  Forward Difference:\\n');
    fprintf('    Max error: %.6f m/s\\n', max(err_forward));
    fprintf('    RMS error: %.6f m/s\\n', rms(err_forward));
    fprintf('    Mean error: %.6f m/s\\n\\n', mean(err_forward));
    
    fprintf('  Backward Difference:\\n');
    fprintf('    Max error: %.6f m/s\\n', max(err_backward));
    fprintf('    RMS error: %.6f m/s\\n', rms(err_backward));
    fprintf('    Mean error: %.6f m/s\\n\\n', mean(err_backward));
    
    fprintf('  Central Difference:\\n');
    fprintf('    Max error: %.6f m/s\\n', max(err_central));
    fprintf('    RMS error: %.6f m/s\\n', rms(err_central));
    fprintf('    Mean error: %.6f m/s\\n', mean(err_central));
    
    % Demonstrate O(h뿯½) vs O(h) accuracy
    ratio = mean(err_forward) / mean(err_central);
    fprintf('    Forward/Central error ratio: %.2f\\n', ratio);
    fprintf('    (Central difference is %.1fx more accurate)\\n\\n', ratio);
    
    % Acceleration errors
    err_accel = abs(a_central - a_exact);
    fprintf('Acceleration Errors:\\n');
    fprintf('  Max error: %.6f m/s뿯½\\n', max(err_accel));
    fprintf('  RMS error: %.6f m/s뿯½\\n', rms(err_accel));
    fprintf('  Mean error: %.6f m/s뿯½\\n\\n', mean(err_accel));
end

function createVisualisations(t, h, v_forward, v_backward, v_central, ...
    v_exact, a_central, a_exact)
    % CREATEVISUALISATIONS Generate comprehensive plots
    
    figure('Position', [100, 100, 1400, 900], 'Name', 'Rocket Trajectory Analysis');
    
    % Subplot 1: Altitude profile
    subplot(3, 3, 1);
    plot(t, h/1000, 'b-', 'LineWidth', 2);
    xlabel('$t$ (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$h$ (km)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Altitude Profile', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Find and mark maximum altitude
    [h_max, idx_max] = max(h);
    hold on;
    plot(t(idx_max), h(idx_max)/1000, 'ro', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'r');
    text(t(idx_max), h(idx_max)/1000*1.05, ...
        sprintf('Max: %.2f km at t=%.1f s', h_max/1000, t(idx_max)), ...
        'HorizontalAlignment', 'center', 'FontSize', 10);
    
    % Subplot 2: Velocity comparison
    subplot(3, 3, 2);
    plot(t, v_exact, 'k-', 'LineWidth', 2.5, 'DisplayName', 'Analytical');
    hold on;
    plot(t, v_forward, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Forward');
    plot(t, v_backward, 'g-', 'LineWidth', 1.5, 'DisplayName', 'Backward');
    plot(t, v_central, 'b:', 'LineWidth', 2, 'DisplayName', 'Central');
    xlabel('$t$ (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$v$ (m/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Velocity: Method Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 9);
    grid on;
    
    % Subplot 3: Velocity errors
    subplot(3, 3, 3);
    semilogy(t, abs(v_forward - v_exact), 'r-', 'LineWidth', 1.5, ...
        'DisplayName', 'Forward');
    hold on;
    semilogy(t, abs(v_backward - v_exact), 'g-', 'LineWidth', 1.5, ...
        'DisplayName', 'Backward');
    semilogy(t, abs(v_central - v_exact), 'b-', 'LineWidth', 2, ...
        'DisplayName', 'Central');
    xlabel('$t$ (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|v_{\rm num} - v_{\rm exact}|$ (m/s)', 'Interpreter', 'latex', ...
        'FontSize', 12);
    title('Velocity Absolute Errors', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 9);
    grid on;
    
    % Subplot 4: Acceleration comparison
    subplot(3, 3, 4);
    plot(t, a_exact, 'k-', 'LineWidth', 2.5, 'DisplayName', 'Analytical');
    hold on;
    plot(t, a_central, 'b:', 'LineWidth', 2, 'DisplayName', 'Central Diff.');
    xlabel('$t$ (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$a$ (m/s$^2$)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Acceleration Profile', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 10);
    grid on;
    yline(0, 'r-', 'Zero Acceleration', 'LineWidth', 1.5, ...
        'LabelHorizontalAlignment', 'left');
    
    % Subplot 5: Acceleration error
    subplot(3, 3, 5);
    plot(t, abs(a_central - a_exact), 'b-', 'LineWidth', 2);
    xlabel('$t$ (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|a_{\rm num} - a_{\rm exact}|$ (m/s$^2$)', 'Interpreter', 'latex', ...
        'FontSize', 12);
    title('Acceleration Absolute Error', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 6: Phase portrait (velocity vs altitude)
    subplot(3, 3, 6);
    plot(h/1000, v_exact, 'b-', 'LineWidth', 2);
    xlabel('$h$ (km)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$v$ (m/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Phase Portrait', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 7: Zoomed comparison (first 20 seconds)
    subplot(3, 3, 7);
    idx_zoom = t <= 20;
    plot(t(idx_zoom), v_exact(idx_zoom), 'k-', 'LineWidth', 2.5, ...
        'DisplayName', 'Analytical');
    hold on;
    plot(t(idx_zoom), v_central(idx_zoom), 'b:', 'LineWidth', 2, ...
        'DisplayName', 'Central Diff.');
    plot(t(idx_zoom), v_forward(idx_zoom), 'r-', 'LineWidth', 1.5, ...
        'DisplayName', 'Forward Diff.');
    xlabel('$t$ (s)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$v$ (m/s)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Velocity Detail (0-20 s)', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 9);
    grid on;
    
    % Subplot 8: Error distribution histogram
    subplot(3, 3, 8);
    err_central = v_central - v_exact;
    histogram(err_central, 30, 'FaceColor', 'b', 'FaceAlpha', 0.7, ...
        'EdgeColor', 'k');
    xlabel('$v_{\rm num} - v_{\rm exact}$ (m/s)', 'Interpreter', 'latex', ...
        'FontSize', 12);
    ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 12);
    title('Central Diff. Error Distribution', 'Interpreter', 'latex', ...
        'FontSize', 13);
    grid on;
    
    % Subplot 9: Convergence table
    subplot(3, 3, 9);
    axis off;
    
    % Create error summary table
    err_forward_rms = rms(v_forward - v_exact);
    err_backward_rms = rms(v_backward - v_exact);
    err_central_rms = rms(v_central - v_exact);
    
    str = {'\textbf{Error Summary}', '', ...
        sprintf('Forward Diff.: %.4f m/s', err_forward_rms), ...
        sprintf('Backward Diff.: %.4f m/s', err_backward_rms), ...
        sprintf('Central Diff.: %.4f m/s', err_central_rms), '', ...
        sprintf('Improvement: %.1fx', err_forward_rms/err_central_rms), '', ...
        '\textbf{Key Results}', ...
        sprintf('Max altitude: %.2f km', max(h)/1000), ...
        sprintf('Max velocity: %.2f m/s', max(v_exact)), ...
        sprintf('Final accel.: %.2f m/s$^2$', a_exact(end))};
    
    text(0.1, 0.9, str, 'Interpreter', 'latex', 'FontSize', 11, ...
        'VerticalAlignment', 'top');
end

function investigateStepSize(h_func, v_analytical, a_analytical, t_max)
    % INVESTIGATESTEPSIZE Analyse effect of time step on accuracy
    
    fprintf('\\nStep Size Sensitivity Analysis:\\n');
    fprintf('================================\\n\\n');
    
    % Test different step sizes
    step_sizes = [0.5, 1.0, 2.0, 5.0];
    n_steps = length(step_sizes);
    
    errors_forward = zeros(n_steps, 1);
    errors_central = zeros(n_steps, 1);
    
    figure('Position', [200, 200, 1200, 600], 'Name', 'Step Size Analysis');
    
    for i = 1:n_steps
        dt = step_sizes(i);
        
        % Generate data
        t = 0:dt:t_max;
        h = h_func(t);
        v_exact = v_analytical(t);
        
        % Compute numerical derivatives
        v_forward = zeros(size(t));
        v_forward(1:end-1) = (h(2:end) - h(1:end-1)) / dt;
        v_forward(end) = v_forward(end-1);
        
        v_central = zeros(size(t));
        v_central(2:end-1) = (h(3:end) - h(1:end-2)) / (2*dt);
        v_central(1) = v_central(2);
        v_central(end) = v_central(end-1);
        
        % Calculate errors
        errors_forward(i) = rms(v_forward - v_exact);
        errors_central(i) = rms(v_central - v_exact);
        
        fprintf('뿯νt = %.2f s:\\n', dt);
        fprintf('  Forward RMS error: %.6f m/s\\n', errors_forward(i));
        fprintf('  Central RMS error: %.6f m/s\\n', errors_central(i));
        fprintf('  Ratio: %.2f\\n\\n', errors_forward(i)/errors_central(i));
    end
    
    % Plot error vs step size
    subplot(1, 2, 1);
    loglog(step_sizes, errors_forward, 'ro-', 'LineWidth', 2, 'MarkerSize', 10, ...
        'MarkerFaceColor', 'r', 'DisplayName', 'Forward Diff. $O(h)$');
    hold on;
    loglog(step_sizes, errors_central, 'bs-', 'LineWidth', 2, 'MarkerSize', 10, ...
        'MarkerFaceColor', 'b', 'DisplayName', 'Central Diff. $O(h^2)$');
    
    % Add theoretical slopes
    h_ref = step_sizes(1);
    err_ref_forward = errors_forward(1);
    err_ref_central = errors_central(1);
    
    slope_1 = err_ref_forward * (step_sizes / h_ref).^1;
    slope_2 = err_ref_central * (step_sizes / h_ref).^2;
    
    plot(step_sizes, slope_1, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Slope = 1');
    plot(step_sizes, slope_2, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Slope = 2');
    
    xlabel('$\Delta t$ (s)', 'Interpreter', 'latex', 'FontSize', 13);
    ylabel('RMS Error (m/s)', 'Interpreter', 'latex', 'FontSize', 13);
    title('Error vs Step Size', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 11);
    grid on;
    
    % Plot convergence rate
    subplot(1, 2, 2);
    
    % Calculate slopes from log-log data
    log_h = log10(step_sizes);
    log_err_forward = log10(errors_forward);
    log_err_central = log10(errors_central);
    
    p_forward = polyfit(log_h, log_err_forward, 1);
    p_central = polyfit(log_h, log_err_central, 1);
    
    plot(step_sizes, errors_forward, 'ro-', 'LineWidth', 2, 'MarkerSize', 10, ...
        'MarkerFaceColor', 'r');
    hold on;
    plot(step_sizes, errors_central, 'bs-', 'LineWidth', 2, 'MarkerSize', 10, ...
        'MarkerFaceColor', 'b');
    
    xlabel('$\Delta t$ (s)', 'Interpreter', 'latex', 'FontSize', 13);
    ylabel('RMS Error (m/s)', 'Interpreter', 'latex', 'FontSize', 13);
    title('Convergence Comparison', 'Interpreter', 'latex', 'FontSize', 14);
    grid on;
    
    % Add text annotations
    text_str = {sprintf('Forward slope: %.2f', p_forward(1)), ...
                sprintf('Central slope: %.2f', p_central(1)), '', ...
                'Expected:', 'Forward: 1.0', 'Central: 2.0'};
    text(0.6*max(step_sizes), 0.7*max(errors_forward), text_str, ...
        'Interpreter', 'latex', 'FontSize', 11, ...
        'BackgroundColor', 'w', 'EdgeColor', 'k');
    
    fprintf('Convergence Analysis:\\n');
    fprintf('  Forward difference: slope = %.3f (expected ≈ 1.0)\\n', p_forward(1));
    fprintf('  Central difference: slope = %.3f (expected ≈ 2.0)\\n', p_central(1));
    fprintf('\\nConclusion: Central difference demonstrates O(h뿯½) convergence,\\n');
    fprintf('            providing superior accuracy for same computational cost.\\n');
end

% Execute problem solution
Problem1_RocketVelocityAnalysis();
