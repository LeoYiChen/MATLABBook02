%% chapter_FundamentalMathematics_MATLABexample_Interactive.m
% Interactive Counting Board Visualisation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_Interactive
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Example usage
fprintf('Creating interactive visualisation...\n');
A = [2 1 3; 3 2 1; 1 3 2];
b = [39; 34; 26];
visualiseCountingBoard(A, b);

% Local functions (moved to end so this listing is a valid MATLAB script)
function visualiseCountingBoard(A, b)
% VISUALISECOUNTINGBOARD Creates animated visualisation of the Chinese
% counting board method for solving linear systems
%
% This function creates a step-by-step animation showing how ancient
% Chinese mathematicians would have solved systems using counting rods

    % Create figure
    fig = figure('Position', [100 100 1000 600], ...
                 'Name', 'Ancient Chinese Counting Board Method', ...
                 'NumberTitle', 'off');
    
    % Solve system and store steps
    [~, steps] = chineseFangcheng(A, b);
    numSteps = length(steps);
    
    % Animation loop
    for stepIdx = 1:numSteps
        clf;
        currentMatrix = steps{stepIdx};
        [rows, cols] = size(currentMatrix);
        
        % Create counting board background
        hold on;
        axis([0 cols+1 0 rows+2]);
        axis equal;
        axis off;
        
        % Draw grid lines
        for i = 1:cols
            plot([i i], [0.5 rows+0.5], 'k-', 'LineWidth', 1.5);
        end
        for i = 1:rows
            plot([0.5 cols+0.5], [rows-i+1 rows-i+1], ...
                 'k-', 'LineWidth', 1.5);
        end
        
        % Draw counting rods
        for i = 1:rows
            for j = 1:cols
                value = currentMatrix(i, j);
                
                if value ~= 0
                    % Determine rod colour (red for negative)
                    if value < 0
                        rodColour = [0.8 0.2 0.2]; % Red rods
                        value = abs(value);
                    else
                        rodColour = [0.85 0.7 0.4]; % Natural bamboo
                    end
                    
                    % Draw rods representing the number
                    drawCountingRods(j, rows-i+1, value, rodColour);
                    
                    % Add numerical label
                    text(j, rows-i+1, sprintf('%.1f', currentMatrix(i,j)), ...
                         'HorizontalAlignment', 'center', ...
                         'VerticalAlignment', 'bottom', ...
                         'FontSize', 10, 'FontWeight', 'bold');
                end
            end
        end
        
        % Add labels
        title(sprintf('Step %d of %d: Chinese Fangcheng Method', ...
                     stepIdx, numSteps), 'FontSize', 14, 'FontWeight', 'bold');
        
        % Row labels
        for i = 1:rows-1
            text(0.2, rows-i+1, sprintf('x_%d', i), ...
                 'FontSize', 12, 'FontWeight', 'bold');
        end
        text(0.2, 1, 'Total', 'FontSize', 12, 'FontWeight', 'bold');
        
        hold off;
        
        % Pause for animation
        pause(1.5);
    end
end

function drawCountingRods(x, y, value, colour)
% Draw stylised counting rods to represent a number
    rodLength = 0.3;
    rodWidth = 0.05;
    spacing = 0.08;
    
    % Simplified representation: draw vertical rods
    numRods = min(floor(value), 9); % Max 9 rods for visual clarity
    
    startX = x - (numRods-1)*spacing/2;
    
    for i = 1:numRods
        rodX = startX + (i-1)*spacing;
        rectangle('Position', [rodX-rodWidth/2, y-rodLength/2, ...
                              rodWidth, rodLength], ...
                 'FaceColor', colour, 'EdgeColor', 'k', 'LineWidth', 1);
    end
end

% Local function copied from another listing in this chapter
function [solution, steps] = chineseFangcheng(A, b)
% CHINESEFANGCHENG Implements the ancient Chinese counting board method
% for solving linear systems using column operations
%
% Inputs:
%   A - Coefficient matrix (n x n)
%   b - Right-hand side vector (n x 1)
%
% Outputs:
%   solution - Solution vector
%   steps - Cell array documenting each transformation step
%
% This implementation mirrors the historical fangcheng method described
% in the Jiuzhang Suanshu (Nine Chapters on Mathematical Art)

    % Create augmented matrix in column-wise format (Chinese style)
    % Each column represents one constraint equation
    n = size(A, 1);
    augMatrix = [A; b'];
    steps = {};
    stepCount = 1;
    
    fprintf('Initial Counting Board Configuration:\n');
    displayCountingBoard(augMatrix);
    steps{stepCount} = augMatrix;
    stepCount = stepCount + 1;
    
    % Forward elimination using column operations (zhí chú method)
    for col = 1:n-1
        % Find pivot column (ancient Chinese would arrange manually)
        [~, pivotCol] = max(abs(augMatrix(col, col:n)));
        pivotCol = pivotCol + col - 1;
        
        if pivotCol ~= col
            % Column exchange (huàn wèi)
            fprintf('\nStep %d: Exchanging columns %d and %d\n', ...
                    stepCount-1, col, pivotCol);
            augMatrix(:, [col, pivotCol]) = augMatrix(:, [pivotCol, col]);
            displayCountingBoard(augMatrix);
            steps{stepCount} = augMatrix;
            stepCount = stepCount + 1;
        end
        
        % Eliminate entries below pivot using column subtraction
        for targetCol = col+1:n
            if augMatrix(col, targetCol) ~= 0
                % Calculate multiplier (Chinese: multiplying factor)
                multiplier = augMatrix(col, targetCol) / augMatrix(col, col);
                
                fprintf(['\nStep %d: Subtract %.2f times column %d ' ...
                        'from column %d\n'], stepCount-1, multiplier, ...
                        col, targetCol);
                
                % Perform column operation (zhí chú)
                augMatrix(:, targetCol) = augMatrix(:, targetCol) - ...
                                          multiplier * augMatrix(:, col);
                displayCountingBoard(augMatrix);
                steps{stepCount} = augMatrix;
                stepCount = stepCount + 1;
            end
        end
    end
    
    % Back substitution (ancient Chinese: "seeking the unknown")
    fprintf('\nBeginning back-substitution (qiú wèi zhī shù)...\n');
    solution = zeros(n, 1);
    
    for i = n:-1:1
        solution(i) = augMatrix(end, i);
        for j = i+1:n
            solution(i) = solution(i) - augMatrix(i, j) * solution(j);
        end
        solution(i) = solution(i) / augMatrix(i, i);
        fprintf('x_%d = %.4f\n', i, solution(i));
    end
end

% Local function copied from another listing in this chapter
function displayCountingBoard(matrix)
% Helper function to display matrix in counting board format
    fprintf('\nCounting Board Configuration:\n');
    fprintf('─────────────────────────────────\n');
    [rows, cols] = size(matrix);
    
    % Display coefficient rows
    for i = 1:rows-1
        fprintf('Grade %d: ', i);
        for j = 1:cols
            if matrix(i,j) >= 0
                fprintf('%6.2*f  ', matrix(i,j));
            else
                fprintf('%6.2*f* ', matrix(i,j)); % * indicates red rods
            end
        end
        fprintf('\n');
    end
    
    % Display totals row
    fprintf('─────────────────────────────────\n');
    fprintf('Totals:  ');
    for j = 1:cols
        fprintf('%6.2*f  ', matrix(end,j));
    end
    fprintf('\n─────────────────────────────────\n');
end
