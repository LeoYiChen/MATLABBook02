%% ch08_prob3_mapper.m
% Mapper function (meanVarianceMapper.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob3_mapper
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function meanVarianceMapper(dataChunk, ~, intermKVStore)
% meanVarianceMapper  Emit partial sums for each feature.
% Author : Dr Yi Chen | Version 1.0 | 2026
    variableNames = dataChunk.Properties.VariableNames;
    dataArray     = table2array(dataChunk);
    for colIdx = 1:numel(variableNames)
        columnData = dataArray(:, colIdx);
        columnData = columnData(~isnan(columnData));
        partialResult.Count  = numel(columnData);
        partialResult.Sum    = sum(columnData);
        partialResult.SumSq  = sum(columnData .^ 2);
        add(intermKVStore, variableNames{colIdx}, partialResult);
    end
end
% Complexity per call: O(chunkRows * numFeatures).
