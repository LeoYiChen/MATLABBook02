%% chapter_SymbolicComputing_problem1_code.m
% Advanced symbolic manipulation system implementation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_SymbolicComputing_problem1_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter_SymbolicComputing_Problem01.m
%
% Advanced Symbolic Manipulation and Expression Optimisation
%
% Author: Dr Yi Chen
% Institution: University Engineering Department
% Date: 2024
% Version: 1.0
% MATLAB Version: R2024a
%
% Description: Comprehensive symbolic expression manipulation system
% with automated simplification, factorisation, and optimisation

function comprehensive_symbolic_manipulation_system()
    %COMPREHENSIVE_SYMBOLIC_MANIPULATION_SYSTEM Advanced symbolic processor
    %   Implements sophisticated algebraic manipulation with performance analysis
    
    clear; clc;
    
    % Display system header
    fprintf('Advanced Symbolic Manipulation and Expression Optimisation\n');
    fprintf('========================================================\n\n');
    
    % Define symbolic variables
    syms x y z a b real
    
    % Test expression from problem statement
    test_expression = (sin(x)^2 + cos(x)^2) / (exp(log(y)) + z^2 - z^2) * ...
                     ((a+b)^3 - (a^3 + 3*a^2*b + 3*a*b^2 + b^3)) / (x^4 - 1);
    
    fprintf('Original Expression:\n');
    fprintf('f(x,y,z,a,b) = %s\n\n', char(test_expression));
    
    % Perform comprehensive analysis
    analysis_results = perform_expression_analysis(test_expression);
    
    % Display results
    display_analysis_results(analysis_results);
    
    % Advanced manipulation demonstrations
    demonstrate_advanced_techniques();
    
    % Performance benchmarking
    perform_performance_analysis();
    
end

function analysis_results = perform_expression_analysis(expression)
    %PERFORM_EXPRESSION_ANALYSIS Comprehensive expression analysis
    %   Analyses symbolic expressions using multiple techniques
    
    fprintf('Performing Comprehensive Expression Analysis\n');
    fprintf('===========================================\n');
    
    analysis_results = struct();
    
    % Step 1: Basic simplification
    simplified_basic = simplify(expression);
    fprintf('Basic Simplification: %s\n', char(simplified_basic));
    
    % Step 2: Advanced simplification with assumptions
    simplified_advanced = simplify(expression, 'Steps', 50);
    fprintf('Advanced Simplification: %s\n', char(simplified_advanced));
    
    % Step 3: Factorisation attempts
    try
        factored_form = factor(simplified_advanced);
        fprintf('Factored Form: %s\n', char(factored_form));
    catch
        fprintf('Factorisation not applicable to this expression\n');
        factored_form = simplified_advanced;
    end
    
    % Step 4: Expand for comparison
    expanded_form = expand(expression);
    fprintf('Expanded Form: %s\n', char(expanded_form));
    
    % Step 5: Collect terms
    collected_form = collect(simplified_advanced, symvar(simplified_advanced));
    fprintf('Collected Form: %s\n', char(collected_form));
    
    % Store results
    analysis_results.original = expression;
    analysis_results.simplified_basic = simplified_basic;
    analysis_results.simplified_advanced = simplified_advanced;
    analysis_results.factored = factored_form;
    analysis_results.expanded = expanded_form;
    analysis_results.collected = collected_form;
    
    % Complexity analysis
    analysis_results.complexity = analyse_expression_complexity(analysis_results);
    
    fprintf('\n');
end

function complexity_metrics = analyse_expression_complexity(results)
    %ANALYSE_EXPRESSION_COMPLEXITY Compute complexity metrics
    %   Evaluates various measures of expression complexity
    
    fprintf('Expression Complexity Analysis\n');
    fprintf('---------------\n');
    
    expressions = {results.original, results.simplified_basic, ...
                  results.simplified_advanced, results.factored};
    labels = {'Original', 'Basic Simplified', 'Advanced Simplified', 'Factored'};
    
    complexity_metrics = struct();
    
    for expression_index = 1:length(expressions)
        expr = expressions{expression_index};
        label = labels{expression_index};
        
        % Character count
        char_count = length(char(expr));
        
        % Operation count
        expr_str = char(expr);
        operation_count = count_operations(expr_str);
        
        % Function count
        function_count = count_functions(expr_str);
        
        % Variable count
        variables = symvar(expr);
        variable_count = length(variables);
        
        fprintf('%s: Characters=%d, Operations=%d, Functions=%d, Variables=%d\n', ...
               label, char_count, operation_count, function_count, variable_count);
        
        complexity_metrics.(labels{expression_index}) = struct(...
            'characters', char_count, ...
            'operations', operation_count, ...
            'functions', function_count, ...
            'variables', variable_count);
    end
    
    fprintf('\n');
end

function operation_count = count_operations(expression_string)
    %COUNT_OPERATIONS Count arithmetic operations in expression
    %   Returns total number of +, -, *, /, ^ operations
    
    operations = {'+', '-', '*', '/', '^'};
    operation_count = 0;
    
    for operation_index = 1:length(operations)
        operation_count = operation_count + ...
            length(strfind(expression_string, operations{operation_index}));
    end
end

function function_count = count_functions(expression_string)
    %COUNT_FUNCTIONS Count mathematical functions in expression
    %   Returns total number of sin, cos, exp, log, etc.
    
    functions = {'sin', 'cos', 'tan', 'exp', 'log', 'sqrt', 'abs'};
    function_count = 0;
    
    for function_index = 1:length(functions)
        function_count = function_count + ...
            length(strfind(expression_string, functions{function_index}));
    end
end

function demonstrate_advanced_techniques()
    %DEMONSTRATE_ADVANCED_TECHNIQUES Show sophisticated manipulation methods
    %   Demonstrates advanced symbolic manipulation capabilities
    
    fprintf('Advanced Manipulation Techniques\n');
    fprintf('===============================\n');
    
    syms x y z real
    
    % Technique 1: Trigonometric simplification
    trig_expr = sin(x)^2 + cos(x)^2 + tan(x)^2 + 1;
    trig_simplified = simplify(trig_expr);
    fprintf('Trigonometric: %s -> %s\n', char(trig_expr), char(trig_simplified));
    
    % Technique 2: Logarithmic manipulation
    log_expr = log(x*y) + log(z) - log(x) - log(y*z);
    log_simplified = simplify(log_expr);
    fprintf('Logarithmic: %s -> %s\n', char(log_expr), char(log_simplified));
    
    % Technique 3: Rational function simplification
    rational_expr = (x^2 - 1)/(x - 1) + (x^3 - 8)/(x - 2);
    rational_simplified = simplify(rational_expr);
    fprintf('Rational: %s -> %s\n', char(rational_expr), char(rational_simplified));
    
    % Technique 4: Polynomial factorisation
    poly_expr = x^4 + 4*x^3 + 6*x^2 + 4*x + 1;
    poly_factored = factor(poly_expr);
    fprintf('Polynomial: %s -> %s\n', char(poly_expr), char(poly_factored));
    
    fprintf('\n');
end

function perform_performance_analysis()
    %PERFORM_PERFORMANCE_ANALYSIS Benchmark different approaches
    %   Compares performance of various simplification strategies
    
    fprintf('Performance Analysis\n');
    fprintf('===================\n');
    
    syms x y z real
    
    % Create test expressions of varying complexity
    test_expressions = {
        x^2 + 2*x + 1,
        sin(x)^2 + cos(x)^2,
        (x^3 - 1)/(x - 1),
        exp(log(x)) + log(exp(y)),
        (x + y)^5 - x^5 - 5*x^4*y - 10*x^3*y^2 - 10*x^2*y^3 - 5*x*y^4 - y^5
    };
    
    complexity_levels = {'Simple', 'Trigonometric', 'Rational', 'Transcendental', 'Polynomial'};
    
    fprintf('Expression Type       | Original Length | Simplified Length | Time (ms)\n');
    fprintf('-----------|---------|----------|-----\n');
    
    for test_index = 1:length(test_expressions)
        expr = test_expressions{test_index};
        
        % Measure simplification time
        tic;
        simplified = simplify(expr);
        elapsed_time = toc * 1000; % Convert to milliseconds
        
        original_length = length(char(expr));
        simplified_length = length(char(simplified));
        
        fprintf('%-20s | %15d | %17d | %8.2f\n', ...
               complexity_levels{test_index}, original_length, simplified_length, elapsed_time);
    end
    
    fprintf('\nPerformance analysis complete.\n\n');
end

function display_analysis_results(results)
    %DISPLAY_ANALYSIS_RESULTS Present comprehensive analysis summary
    %   Formats and displays all analysis results professionally
    
    fprintf('Comprehensive Analysis Summary\n');
    fprintf('=============================\n');
    
    % Mathematical correctness verification
    fprintf('Mathematical Verification:\n');
    
    % Test numerical equivalence at random points
    test_points = [1, 2, 3; 0.5, 1.5, 2.5; -1, -0.5, 0.5];
    variables = symvar(results.original);
    
    if length(variables) >= 3
        for point_index = 1:size(test_points, 1)
            original_value = double(subs(results.original, variables(1:3), test_points(point_index, :)));
            simplified_value = double(subs(results.simplified_advanced, variables(1:3), test_points(point_index, :)));
            
            if abs(original_value - simplified_value) < 1e-10
                fprintf(' Numerical verification passed at point [%.1f, %.1f, %.1f]\n', ...
                       test_points(point_index, :));
            else
                fprintf(' Numerical verification failed at point [%.1f, %.1f, %.1f]\n', ...
                       test_points(point_index, :));
            end
        end
    end
    
    % Simplification effectiveness
    original_complexity = results.complexity.Original.characters;
    simplified_complexity = results.complexity.(['Advanced', 'Simplified']).characters;
    
    reduction_percentage = (original_complexity - simplified_complexity) / original_complexity * 100;
    
    fprintf('\nSimplification Effectiveness:\n');
    fprintf('Original complexity: %d characters\n', original_complexity);
    fprintf('Simplified complexity: %d characters\n', simplified_complexity);
    fprintf('Reduction: %.1f%%\n', reduction_percentage);
    
    fprintf('\nFinal Result:\n');
    fprintf('Optimised Expression: %s\n', char(results.simplified_advanced));
    fprintf('\nAnalysis complete.\n\n');
end
