%% chapter_AI_Chemistry_Problem04_code.m
% Problem 4: CNN for NMR Peak Identification
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Chemistry_Problem04_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Script: Problem 4 - CNN for NMR Peak Identification
% Chapter: AI in Chemistry Research and Education
% Author: Dr Yi Chen (IEEE Fellow, IET Fellow, IMechE Fellow)
% Affiliation: Newcastle University, United Kingdom
% Date: January 2025
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox,
%                     Statistics and Machine Learning Toolbox
% Description: Train 1D convolutional neural network to classify
%              functional groups from simulated 1H NMR spectra
% Version Control: v1.0 - Initial implementation
%                  Tested on MATLAB R2023b, Windows 11 Pro, 16GB RAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Initialisation and Environment Setup
clear all; close all; clc;

fprintf('========================================\n');
fprintf('Problem 4: CNN for NMR Peak Identification\n');
fprintf('Deep Learning for Spectroscopic Analysis\n');
fprintf('========================================\n\n');

% Set random seed for reproducibility
rng(2025, 'twister');

%% Step 1: Generate Simulated 1H NMR Spectra
fprintf('Step 1: Generating simulated 1H NMR spectra...\n');

numClasses = 5;
samplesPerClass = 1000;
totalSamples = numClasses * samplesPerClass;
spectrumLength = 2048;

% Chemical shift range: 0-12 ppm
chemicalShift = linspace(0, 12, spectrumLength);

% Functional group classes and characteristic peaks
classNames = {'Alkane', 'Aromatic', 'Alcohol', 'Aldehyde/Ketone', 'Alkene'};

% Characteristic peak positions (ppm) for each class
peakPositions = {
    [0.8, 1.2, 1.4, 2.1],           % Alkane: methyl, methylene
    [7.2, 7.5, 7.8],                % Aromatic: benzene ring protons
    [1.0, 1.5, 3.6, 4.2],           % Alcohol: CH + OH (broad, 3-5 ppm)
    [1.2, 2.3, 9.7],                % Aldehyde: CHO peak ~9.7 ppm
    [1.3, 2.2, 5.4, 5.8]            % Alkene: vinyl protons 5-6 ppm
};

% Initialize dataset
spectraData = zeros(spectrumLength, 1, 1, totalSamples);
labelsData = zeros(totalSamples, 1);

fprintf('  Generating %d spectra per class...\n', samplesPerClass);

for classIdx = 1:numClasses
    peaks = peakPositions{classIdx};
    
    for sampleIdx = 1:samplesPerClass
        spectrum = zeros(1, spectrumLength);
        
        % Add characteristic peaks with Lorentzian line shapes
        for peakIdx = 1:length(peaks)
            peakCenter = peaks(peakIdx);
            
            % Add some random variation in peak position ( 0.2 ppm)
            peakCenter = peakCenter + 0.2 * (rand() - 0.5);
            
            % Peak height variation
            peakHeight = 0.5 + 0.5 * rand();
            
            % Line width (Hz, converted to ppm)
            lineWidth = 0.05 + 0.05 * rand();
            
            % Lorentzian lineshape
            lorentzian = peakHeight * lineWidth^2 ./ ...
                        ((chemicalShift - peakCenter).^2 + lineWidth^2);
            
            spectrum = spectrum + lorentzian;
        end
        
        % Add baseline drift
        baselineDrift = 0.02 * sin(2*pi*chemicalShift/12) .* rand();
        spectrum = spectrum + baselineDrift;
        
        % Add noise
        noiseLevel = 0.03;
        spectrum = spectrum + noiseLevel * randn(1, spectrumLength);
        
        % Normalise spectrum
        spectrum = spectrum / (max(abs(spectrum)) + 1e-8);
        
        % Store spectrum
        globalIdx = (classIdx - 1) * samplesPerClass + sampleIdx;
        spectraData(:, 1, 1, globalIdx) = spectrum';
        labelsData(globalIdx) = classIdx;
    end
    
    fprintf('    Class %d (%s): %d spectra generated\n', ...
            classIdx, classNames{classIdx}, samplesPerClass);
end

% Convert labels to categorical
labelsDataCategorical = categorical(labelsData);

fprintf('  Total dataset: %d spectra, %d classes\n', totalSamples, numClasses);
fprintf('\n');

%% Step 2: Visualise Sample Spectra
fprintf('Step 2: Visualising sample spectra from each class...\n');

figure('Name', 'Sample NMR Spectra', 'Position', [100, 100, 1600, 1000]);

for classIdx = 1:numClasses
    subplot(numClasses, 1, classIdx);
    
    % Get first sample from this class
    sampleIdx = (classIdx - 1) * samplesPerClass + 1;
    spectrum = squeeze(spectraData(:, 1, 1, sampleIdx));
    
    plot(chemicalShift, spectrum, 'b-', 'LineWidth', 1.5);
    xlim([0, 12]);
    ylim([min(spectrum)-0.1, max(spectrum)+0.1]);
    xlabel('Chemical Shift (ppm)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Intensity (a.u.)', 'Interpreter', 'latex', 'FontSize', 11);
    title(sprintf('Class %d: %s', classIdx, classNames{classIdx}), ...
          'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    set(gca, 'XDir', 'reverse'); % NMR convention: high ppm on left
end

saveas(gcf, 'Problem04_SampleSpectra.fig');
saveas(gcf, 'Problem04_SampleSpectra.eps', 'epsc');
saveas(gcf, 'Problem04_SampleSpectra.jpg');

fprintf('  Sample spectra visualised and saved\n\n');

%% Step 3: Train-Validation Split
fprintf('Step 3: Splitting data into training and validation sets...\n');

% Shuffle data
shuffleIdx = randperm(totalSamples);
spectraData = spectraData(:, :, :, shuffleIdx);
labelsDataCategorical = labelsDataCategorical(shuffleIdx);

% 80-20 split
trainRatio = 0.8;
numTrain = round(trainRatio * totalSamples);

trainSpectra = spectraData(:, :, :, 1:numTrain);
trainLabels = labelsDataCategorical(1:numTrain);

valSpectra = spectraData(:, :, :, (numTrain+1):end);
valLabels = labelsDataCategorical((numTrain+1):end);

fprintf('  Training set: %d spectra\n', numTrain);
fprintf('  Validation set: %d spectra\n', totalSamples - numTrain);
fprintf('\n');

%% Step 4: Define 1D CNN Architecture
fprintf('Step 4: Designing 1D convolutional neural network...\n');

layers = [
    imageInputLayer([spectrumLength, 1, 1], 'Name', 'input', ...
                   'Normalization', 'zscore')
    
    % Convolutional Block 1
    convolution2dLayer([25, 1], 32, 'Name', 'conv1', ...
                      'Padding', 'same', 'Stride', 1)
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer([4, 1], 'Name', 'pool1', 'Stride', 4)
    
    % Convolutional Block 2
    convolution2dLayer([15, 1], 64, 'Name', 'conv2', ...
                      'Padding', 'same', 'Stride', 1)
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer([4, 1], 'Name', 'pool2', 'Stride', 4)
    
    % Convolutional Block 3
    convolution2dLayer([7, 1], 128, 'Name', 'conv3', ...
                      'Padding', 'same', 'Stride', 1)
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    maxPooling2dLayer([4, 1], 'Name', 'pool3', 'Stride', 4)
    
    % Fully Connected Layers
    fullyConnectedLayer(128, 'Name', 'fc1')
    reluLayer('Name', 'relu4')
    dropoutLayer(0.5, 'Name', 'dropout')
    
    fullyConnectedLayer(numClasses, 'Name', 'fc2')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')
];

fprintf('  CNN Architecture:\n');
fprintf('    Input: [%d   1   1] (spectrum length)\n', spectrumLength);
fprintf('    Conv1: 32 filters, kernel size [25 1]\n');
fprintf('    MaxPool1: [4 1], stride 4\n');
fprintf('    Conv2: 64 filters, kernel size [15 1]\n');
fprintf('    MaxPool2: [4 1], stride 4\n');
fprintf('    Conv3: 128 filters, kernel size [7 1]\n');
fprintf('    MaxPool3: [4 1], stride 4\n');
fprintf('    FC1: 128 neurons\n');
fprintf('    Dropout: 0.5\n');
fprintf('    FC2: %d neurons (output classes)\n', numClasses);
fprintf('    Total parameters: ~%d\n', sum(arrayfun(@(x) prod(x.OutputSize), ...
           layers(cellfun(@(x) isa(x, 'nnet.cnn.layer.Convolution2DLayer') || ...
           isa(x, 'nnet.cnn.layer.FullyConnectedLayer'), num2cell(layers))))));
fprintf('\n');

%% Step 5: Configure Training Options
fprintf('Step 5: Configuring training hyperparameters...\n');

options = trainingOptions('adam', ...
    'MaxEpochs', 30, ...
    'MiniBatchSize', 64, ...
    'InitialLearnRate', 1e-3, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 10, ...
    'Shuffle', 'every-epoch', ...
    'ValidationData', {valSpectra, valLabels}, ...
    'ValidationFrequency', 50, ...
    'Verbose', false, ...
    'Plots', 'training-progress', ...
    'ExecutionEnvironment', 'auto');

fprintf('  Optimiser: Adam\n');
fprintf('  Max epochs: %d\n', options.MaxEpochs);
fprintf('  Mini-batch size: %d\n', options.MiniBatchSize);
fprintf('  Initial learning rate: %.0e\n', options.InitialLearnRate);
fprintf('  Learning rate schedule: Piecewise (drop by 0.5 every 10 epochs)\n');
fprintf('\n');

%% Step 6: Train CNN
fprintf('Step 6: Training convolutional neural network...\n');
fprintf('  (Training progress plot will open in separate window)\n\n');

tic;
net = trainNetwork(trainSpectra, trainLabels, layers, options);
trainingTime = toc;

fprintf('  Training complete in %.1f seconds (%.2f min)\n', ...
        trainingTime, trainingTime/60);
fprintf('\n');

%% Step 7: Evaluate on Validation Set
fprintf('Step 7: Evaluating model on validation set...\n');

% Predictions
valPredictions = classify(net, valSpectra);

% Accuracy
valAccuracy = sum(valPredictions == valLabels) / numel(valLabels);

fprintf('  Validation Accuracy: %.2f%%\n', valAccuracy * 100);

% Confusion matrix
confMat = confusionmat(valLabels, valPredictions);
confMatNorm = confMat ./ sum(confMat, 2) * 100; % Row-normalised percentages

fprintf('  Confusion Matrix (row-normalised, %%):\n');
fprintf('        ');
for k = 1:numClasses
    fprintf('%10s', classNames{k});
end
fprintf('\n');
for i = 1:numClasses
    fprintf('  %10s: ', classNames{i});
    for j = 1:numClasses
        fprintf('%8.1f%% ', confMatNorm(i, j));
    end
    fprintf('\n');
end
fprintf('\n');

% Per-class metrics
precision = zeros(numClasses, 1);
recall = zeros(numClasses, 1);
f1Score = zeros(numClasses, 1);

for k = 1:numClasses
    tp = confMat(k, k);
    fp = sum(confMat(:, k)) - tp;
    fn = sum(confMat(k, :)) - tp;
    
    precision(k) = tp / (tp + fp);
    recall(k) = tp / (tp + fn);
    f1Score(k) = 2 * precision(k) * recall(k) / (precision(k) + recall(k));
end

fprintf('  Per-Class Performance:\n');
for k = 1:numClasses
    fprintf('    %15s: Precision=%.3f, Recall=%.3f, F1=%.3f\n', ...
            classNames{k}, precision(k), recall(k), f1Score(k));
end
fprintf('\n');

%% Step 8: Visualise Confusion Matrix
fprintf('Step 8: Visualising confusion matrix...\n');

figure('Name', 'Confusion Matrix', 'Position', [100, 100, 800, 700]);
imagesc(confMatNorm);
colormap('hot');
colorbar;
caxis([0, 100]);
xticks(1:numClasses);
yticks(1:numClasses);
xticklabels(classNames);
yticklabels(classNames);
xtickangle(45);
xlabel('Predicted Class', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('True Class', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Confusion Matrix (Validation Accuracy: %.2f\\%%)', valAccuracy*100), ...
      'Interpreter', 'latex', 'FontSize', 14);

% Annotate with percentages
[xGrid, yGrid] = meshgrid(1:numClasses);
for idx = 1:numel(confMatNorm)
    text(xGrid(idx), yGrid(idx), sprintf('%.1f%%', confMatNorm(idx)), ...
         'HorizontalAlignment', 'center', 'Color', 'white', ...
         'FontWeight', 'bold', 'FontSize', 11);
end

saveas(gcf, 'Problem04_ConfusionMatrix.fig');
saveas(gcf, 'Problem04_ConfusionMatrix.eps', 'epsc');
saveas(gcf, 'Problem04_ConfusionMatrix.jpg');

fprintf('  Confusion matrix saved\n\n');

%% Step 9: Visualise Learned Convolutional Filters
fprintf('Step 9: Extracting and visualising learned filters...\n');

% Extract weights from first convolutional layer
conv1Layer = net.Layers(2); % conv1
conv1Weights = conv1Layer.Weights;

% conv1Weights dimensions: [height, width, channels_in, num_filters]
% For 1D: [kernelSize, 1, 1, numFilters]
numFilters1 = size(conv1Weights, 4);

figure('Name', 'Learned Filters (Conv1)', 'Position', [100, 100, 1600, 800]);

% Display first 16 filters
numDisplayFilters = min(16, numFilters1);
for filterIdx = 1:numDisplayFilters
    subplot(4, 4, filterIdx);
    filterWeights = squeeze(conv1Weights(:, 1, 1, filterIdx));
    plot(filterWeights, 'b-', 'LineWidth', 1.5);
    xlabel('Position', 'Interpreter', 'latex', 'FontSize', 9);
    ylabel('Weight', 'Interpreter', 'latex', 'FontSize', 9);
    title(sprintf('Filter %d', filterIdx), 'Interpreter', 'latex', 'FontSize', 10);
    grid on;
end

saveas(gcf, 'Problem04_LearnedFilters.fig');
saveas(gcf, 'Problem04_LearnedFilters.eps', 'epsc');
saveas(gcf, 'Problem04_LearnedFilters.jpg');

fprintf('  Learned filters visualised (%d filters shown)\n', numDisplayFilters);
fprintf('  Filters detect peak shapes, multiplet patterns, baseline features\n\n');

%% Step 10: Feature Activation Visualisation
fprintf('Step 10: Visualising feature activations for sample spectra...\n');

% Select one sample from each class for activation analysis
sampleIndices = 1:samplesPerClass:totalSamples;

figure('Name', 'Feature Activations', 'Position', [100, 100, 1800, 1000]);

for plotIdx = 1:numClasses
    sampleIdx = sampleIndices(plotIdx);
    sampleSpectrum = spectraData(:, :, :, sampleIdx);
    sampleLabel = labelsDataCategorical(sampleIdx);
    
    % Get activations from conv1 layer
    act = activations(net, sampleSpectrum, 'conv1');
    
    % Plot original spectrum
    subplot(numClasses, 2, (plotIdx-1)*2 + 1);
    plot(chemicalShift, squeeze(sampleSpectrum), 'b-', 'LineWidth', 1.5);
    xlim([0, 12]);
    xlabel('Chemical Shift (ppm)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Intensity', 'Interpreter', 'latex', 'FontSize', 10);
    title(sprintf('Class: %s', char(sampleLabel)), 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'XDir', 'reverse');
    
    % Plot feature map (average across filters)
    subplot(numClasses, 2, (plotIdx-1)*2 + 2);
    avgActivation = mean(act, 3);
    imagesc(avgActivation');
    colormap('hot');
    colorbar;
    xlabel('Spectral Position', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Feature Map', 'Interpreter', 'latex', 'FontSize', 10);
    title('Average Conv1 Activation', 'Interpreter', 'latex', 'FontSize', 11);
end

saveas(gcf, 'Problem04_FeatureActivations.fig');
saveas(gcf, 'Problem04_FeatureActivations.eps', 'epsc');
saveas(gcf, 'Problem04_FeatureActivations.jpg');

fprintf('  Feature activations visualised\n');
fprintf('  Bright regions indicate strong filter responses (detected features)\n\n');

%% Step 11: ROC Curves for Multi-Class Classification
fprintf('Step 11: Generating ROC curves for each class...\n');

% Get prediction scores (probabilities)
valScores = predict(net, valSpectra);

% Calculate ROC for each class (one-vs-rest)
figure('Name', 'ROC Curves', 'Position', [100, 100, 1000, 800]);
colours = lines(numClasses);
aucScores = zeros(numClasses, 1);

for k = 1:numClasses
    % Binary labels (class k vs. rest)
    binaryLabels = double(valLabels == classNames{k});
    classScores = valScores(:, k);
    
    % ROC curve
    [xROC, yROC, ~, auc] = perfcurve(binaryLabels, classScores, 1);
    aucScores(k) = auc;
    
    plot(xROC, yROC, '-', 'LineWidth', 2, 'Color', colours(k, :), ...
         'DisplayName', sprintf('%s (AUC=%.3f)', classNames{k}, auc));
    hold on;
end

% Random classifier line
plot([0, 1], [0, 1], 'k-', 'LineWidth', 1.5, 'DisplayName', 'Random (AUC=0.5)');
hold off;

xlabel('False Positive Rate', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('True Positive Rate', 'Interpreter', 'latex', 'FontSize', 12);
title('ROC Curves (One-vs-Rest)', 'Interpreter', 'latex', 'FontSize', 14);
legend('Location', 'southeast', 'Interpreter', 'latex', 'FontSize', 10);
grid on;
axis square;

saveas(gcf, 'Problem04_ROC_Curves.fig');
saveas(gcf, 'Problem04_ROC_Curves.eps', 'epsc');
saveas(gcf, 'Problem04_ROC_Curves.jpg');

fprintf('  ROC curves generated\n');
fprintf('  AUC scores:\n');
for k = 1:numClasses
    fprintf('    %15s: %.3f\n', classNames{k}, aucScores(k));
end
fprintf('  Mean AUC: %.3f\n\n', mean(aucScores));

%% Summary and Chemical Interpretation
fprintf('========================================\n');
fprintf('Problem 4 Complete: Summary and Insights\n');
fprintf('========================================\n\n');

fprintf('Dataset Summary:\n');
fprintf('  Total spectra: %d (%d training, %d validation)\n', ...
        totalSamples, numTrain, totalSamples - numTrain);
fprintf('  Classes: %d functional groups\n', numClasses);
fprintf('  Spectrum resolution: %d points (0-12 ppm)\n', spectrumLength);
fprintf('\n');

fprintf('Model Performance:\n');
fprintf('  Validation Accuracy: %.2f%%\n', valAccuracy * 100);
fprintf('  Mean F1-Score: %.3f\n', mean(f1Score));
fprintf('  Mean AUC: %.3f\n', mean(aucScores));
fprintf('  Training Time: %.1f seconds\n', trainingTime);
fprintf('\n');

fprintf('Best Performing Class: %s (F1=%.3f)\n', ...
        classNames{f1Score == max(f1Score)}, max(f1Score));
fprintf('Most Challenging Class: %s (F1=%.3f)\n', ...
        classNames{f1Score == min(f1Score)}, min(f1Score));
fprintf('\n');

fprintf('Chemical Insights:\n');
fprintf('  - CNNs learn hierarchical spectral features (peaks   multiplets   patterns)\n');
fprintf('  - Early layers detect local peak shapes; deeper layers recognise group signatures\n');
fprintf('  - Aromatic/Aldehyde classes highly separable (distinct chemical shift regions)\n');
fprintf('  - Alkane/Alcohol overlap possible (similar aliphatic regions)\n');
fprintf('  - Model achieves expert-level accuracy with minimal training data\n');
fprintf('  - Applications: automated structure elucidation, quality control, mixture analysis\n\n');

fprintf('Figures saved:\n');
fprintf('  - Problem04_SampleSpectra (.fig, .eps, .jpg)\n');
fprintf('  - Problem04_ConfusionMatrix (.fig, .eps, .jpg)\n');
fprintf('  - Problem04_LearnedFilters (.fig, .eps, .jpg)\n');
fprintf('  - Problem04_FeatureActivations (.fig, .eps, .jpg)\n');
fprintf('  - Problem04_ROC_Curves (.fig, .eps, .jpg)\n\n');

fprintf('========================================\n');
