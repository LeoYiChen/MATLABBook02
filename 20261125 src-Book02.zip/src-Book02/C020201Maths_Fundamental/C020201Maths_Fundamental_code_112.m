%% C020201Maths_Fundamental_code_112.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Multiple comparisons with many groups
numComparisons = 20;
pValues = rand(numComparisons, 1) * 0.15;  % Simulated p-values

% Bonferroni correction
alpha*Bonferroni = 0.05 / numComparisons;
significantBonferroni = pValues < alpha*Bonferroni;

% Benjamini-Hochberg (FDR control)
[pValuesSorted, sortIndices] = sort(pValues);
fdrThreshold = (1:numComparisons)' * 0.05 / numComparisons;
significantFDR = pValuesSorted < fdrThreshold;

fprintf('Bonferroni: %d significant tests\n', sum(significantBonferroni));
fprintf('FDR (B-H): %d significant tests\n', sum(significantFDR));
