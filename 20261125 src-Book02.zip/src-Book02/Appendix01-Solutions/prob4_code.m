%% prob4_code.m
% Heat map visualisation with hierarchical clustering for correlation analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob4_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Heat Map Visualisation: Material Property Correlation Analysis
% File: MATLABBook02_Chapter07_Problem04.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Analyses correlation structure of mechanical properties
%              using heat maps, hierarchical clustering, and dendrograms
% =========================================================================

function MATLABBook02_Chapter07_Problem04()
    % Main function for Problem 4: Correlation Heat Maps
    
    clc; clear; close all;
    
    % Define property names
    propertyNames = {'Tensile Strength', 'Compressive Strength', ...
                    'Shear Strength', 'Elastic Modulus', 'Poisson Ratio', ...
                    'Density', 'Hardness', 'Fracture Toughness', ...
                    'Impact Resistance', 'Thermal Conductivity'};
    
    % Generate synthetic material property data
    numSpecimens = 100;
    materialData = generateMaterialPropertyData(numSpecimens);
    
    % Compute correlation matrix
    correlationMatrix = corr(materialData);
    
    % Perform hierarchical clustering
    [clusteredCorr, clusterOrder, linkageTree] = performHierarchicalClustering(...
        correlationMatrix, propertyNames);
    
    % Create comprehensive heat map visualisations
    createCorrelationHeatMaps(correlationMatrix, clusteredCorr, ...
                             propertyNames, clusterOrder);
    
    % Generate dendrogram
    createDendrogram(linkageTree, propertyNames);
    
    % Identify significant correlations
    analyseSignificantCorrelations(correlationMatrix, propertyNames, numSpecimens);
    
    % Perform dimensionality assessment
    assessDimensionality(correlationMatrix, propertyNames);
end

function data = generateMaterialPropertyData(n)
    % GENERATEMATERIALPROPERTYDATA - Creates synthetic correlated measurements
    %
    % Inputs:
    %   n - Number of specimens
    %
    % Outputs:
    %   data - n 10 matrix of material properties
    
    rng(789);
    
    % Define correlation structure (realistic for composite materials)
    % Properties grouped by mechanical strength, stiffness, and physical
    trueCorrMatrix = [
        1.00, 0.85, 0.78, 0.72, 0.15, 0.45, 0.68, 0.62, 0.71, 0.12;
        0.85, 1.00, 0.81, 0.75, 0.18, 0.52, 0.73, 0.58, 0.68, 0.08;
        0.78, 0.81, 1.00, 0.68, 0.22, 0.48, 0.65, 0.55, 0.72, 0.15;
        0.72, 0.75, 0.68, 1.00, 0.35, 0.58, 0.71, 0.48, 0.52, 0.25;
        0.15, 0.18, 0.22, 0.35, 1.00, 0.42, 0.28, 0.18, 0.12, 0.38;
        0.45, 0.52, 0.48, 0.58, 0.42, 1.00, 0.62, 0.38, 0.41, 0.68;
        0.68, 0.73, 0.65, 0.71, 0.28, 0.62, 1.00, 0.51, 0.58, 0.32;
        0.62, 0.58, 0.55, 0.48, 0.18, 0.38, 0.51, 1.00, 0.78, 0.22;
        0.71, 0.68, 0.72, 0.52, 0.12, 0.41, 0.58, 0.78, 1.00, 0.18;
        0.12, 0.08, 0.15, 0.25, 0.38, 0.68, 0.32, 0.22, 0.18, 1.00
    ];
    
    % Generate multivariate normal data with specified correlation
    mu = [500, 550, 300, 70, 0.25, 1.6, 85, 45, 120, 0.8];
    sigma = [50, 55, 30, 7, 0.03, 0.15, 8, 5, 12, 0.1];
    
    % Cholesky decomposition to induce correlation
    L = chol(trueCorrMatrix, 'lower');
    
    % Generate standard normal random variables
    Z = randn(n, 10);
    
    % Transform to correlated normal variables
    Y = Z * L';
    
    % Scale and shift to desired means and standard deviations
    data = bsxfun(@plus, bsxfun(@times, Y, sigma), mu);
end

function [clusteredCorr, clusterOrder, linkageTree] = ...
    performHierarchicalClustering(corrMatrix, propertyNames)
    % PERFORMHIERARCHICALCLUSTERING - Clusters properties by similarity
    %
    % Inputs:
    %   corrMatrix - Correlation matrix
    %   propertyNames - Cell array of property names
    %
    % Outputs:
    %   clusteredCorr - Reordered correlation matrix
    %   clusterOrder - Indices showing new order
    %   linkageTree - Hierarchical clustering linkage
    
    % Convert correlation to distance (1 - |correlation|)
    distanceMatrix = 1 - abs(corrMatrix);
    
    % Convert to vector form for linkage
    distanceVector = squareform(distanceMatrix);
    
    % Perform hierarchical clustering using average linkage
    linkageTree = linkage(distanceVector, 'average');
    
    % Determine optimal leaf order for dendrogram
    clusterOrder = optimalleaforder(linkageTree, distanceVector);
    
    % Reorder correlation matrix
    clusteredCorr = corrMatrix(clusterOrder, clusterOrder);
end

function createCorrelationHeatMaps(corrMatrix, clusteredCorr, ...
                                   propertyNames, clusterOrder)
    % CREATECORRELATIONHEATMAPS - Generates heat map visualisations
    
    figure('Name', 'Correlation Heat Maps', 'Position', [50, 50, 1400, 600]);
    
    % Subplot 1: Original correlation matrix
    subplot(1, 2, 1);
    imagesc(corrMatrix);
    colormap(jet);
    caxis([-1, 1]);
    cb1 = colorbar;
    ylabel(cb1, 'Correlation Coefficient', 'Interpreter', 'latex', 'FontSize', 11);
    
    % Add correlation values as text
    [nRows, nCols] = size(corrMatrix);
    for i = 1:nRows
        for j = 1:nCols
            if abs(corrMatrix(i,j)) > 0.5
                textColor = 'w';
            else
                textColor = 'k';
            end
            text(j, i, sprintf('%.2f', corrMatrix(i,j)), ...
                'HorizontalAlignment', 'center', 'Color', textColor, ...
                'FontSize', 7, 'FontWeight', 'bold');
        end
    end
    
    % Axis labels
    set(gca, 'XTick', 1:length(propertyNames), 'XTickLabel', propertyNames, ...
            'XTickLabelRotation', 45, 'FontSize', 9);
    set(gca, 'YTick', 1:length(propertyNames), 'YTickLabel', propertyNames, ...
            'FontSize', 9);
    title('Original Correlation Matrix', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    axis equal tight;
    set(gca, 'LineWidth', 1.2);
    
    % Subplot 2: Clustered correlation matrix
    subplot(1, 2, 2);
    imagesc(clusteredCorr);
    colormap(jet);
    caxis([-1, 1]);
    cb2 = colorbar;
    ylabel(cb2, 'Correlation Coefficient', 'Interpreter', 'latex', 'FontSize', 11);
    
    % Add correlation values as text
    for i = 1:nRows
        for j = 1:nCols
            if abs(clusteredCorr(i,j)) > 0.5
                textColor = 'w';
            else
                textColor = 'k';
            end
            text(j, i, sprintf('%.2f', clusteredCorr(i,j)), ...
                'HorizontalAlignment', 'center', 'Color', textColor, ...
                'FontSize', 7, 'FontWeight', 'bold');
        end
    end
    
    % Reordered axis labels
    clusteredNames = propertyNames(clusterOrder);
    set(gca, 'XTick', 1:length(propertyNames), 'XTickLabel', clusteredNames, ...
            'XTickLabelRotation', 45, 'FontSize', 9);
    set(gca, 'YTick', 1:length(propertyNames), 'YTickLabel', clusteredNames, ...
            'FontSize', 9);
    title('Hierarchically Clustered Correlation Matrix', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    axis equal tight;
    set(gca, 'LineWidth', 1.2);
end

function createDendrogram(linkageTree, propertyNames)
    % CREATEDENDROGRAM - Visualises hierarchical clustering structure
    
    figure('Name', 'Dendrogram: Property Clustering', ...
           'Position', [100, 100, 1000, 500]);
    
    dendrogram(linkageTree, 'Labels', propertyNames, 'Orientation', 'left', ...
              'ColorThreshold', 0.5);
    
    xlabel('Dissimilarity (1 - $|r|$)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Material Properties', 'Interpreter', 'latex', 'FontSize', 12);
    title('Hierarchical Clustering Dendrogram', 'Interpreter', 'latex', ...
          'FontSize', 13, 'FontWeight', 'bold');
    
    grid on;
    set(gca, 'LineWidth', 1.2, 'FontSize', 10);
    
    % Add interpretation text
    annotation('textbox', [0.15, 0.02, 0.7, 0.08], 'String', ...
              ['Properties closer in the dendrogram exhibit stronger correlations. ', ...
               'Clusters indicate groups of related mechanical behaviours.'], ...
              'Interpreter', 'latex', 'FontSize', 10, 'EdgeColor', 'none');
end

function analyseSignificantCorrelations(corrMatrix, propertyNames, n)
    % ANALYSESIGNIFICANTCORRELATIONS - Identifies statistically significant correlations
    
    fprintf('\n========================================\n');
    fprintf('   SIGNIFICANT CORRELATIONS ANALYSIS\n');
    fprintf('========================================\n');
    
    % Critical value for significance (  = 0.05, two-tailed)
    % For large n, approximately: r_crit   1.96/sqrt(n-3)
    r_critical = 1.96 / sqrt(n - 3);
    
    fprintf('Sample Size: %d specimens\n', n);
    fprintf('Significance Level:   = 0.05 (two-tailed)\n');
    fprintf('Critical Correlation: |r| > %.4f\n\n', r_critical);
    
    fprintf('Strong Positive Correlations (r > 0.70):\n');
    fprintf('-------------------------\n');
    
    [nProps, ~] = size(corrMatrix);
    for i = 1:nProps
        for j = (i+1):nProps
            if corrMatrix(i,j) > 0.70
                fprintf('%s <-> %s: r = %.3f\n', ...
                       propertyNames{i}, propertyNames{j}, corrMatrix(i,j));
            end
        end
    end
    
    fprintf('\nModerate Correlations (0.50 < r < 0.70):\n');
    fprintf('-------------------------\n');
    
    for i = 1:nProps
        for j = (i+1):nProps
            if corrMatrix(i,j) > 0.50 && corrMatrix(i,j) <= 0.70
                fprintf('%s <-> %s: r = %.3f\n', ...
                       propertyNames{i}, propertyNames{j}, corrMatrix(i,j));
            end
        end
    end
end

function assessDimensionality(corrMatrix, propertyNames)
    % ASSESSDIMENSIONALITY - Evaluates information redundancy
    
    fprintf('\n========================================\n');
    fprintf('   DIMENSIONALITY ASSESSMENT\n');
    fprintf('========================================\n');
    
    % Compute eigenvalues (principal components)
    eigenvalues = eig(corrMatrix);
    eigenvalues = sort(eigenvalues, 'descend');
    
    % Calculate variance explained by each component
    varianceExplained = 100 * eigenvalues / sum(eigenvalues);
    cumulativeVariance = cumsum(varianceExplained);
    
    fprintf('Principal Component Analysis Results:\n\n');
    fprintf('PC   Eigenvalue   Variance (%%)   Cumulative (%%)\n');
    fprintf('------------------------\n');
    
    for i = 1:length(eigenvalues)
        fprintf('%2d    %6.3f      %6.2f         %6.2f\n', ...
               i, eigenvalues(i), varianceExplained(i), cumulativeVariance(i));
    end
    
    % Determine number of components for 90% variance
    numComponents90 = find(cumulativeVariance >= 90, 1);
    
    fprintf('\n=== Recommendations ===\n');
    fprintf('%d components explain 90%% of total variance\n', numComponents90);
    fprintf('Consider reducing from 10 to %d key measurements\n', numComponents90);
    
    % Identify most redundant properties
    avgAbsCorr = mean(abs(corrMatrix), 2) - 1/length(propertyNames);
    [~, sortedIdx] = sort(avgAbsCorr, 'descend');
    
    fprintf('\nMost redundant properties (highest avg correlation):\n');
    for i = 1:3
        fprintf('  %d. %s (avg |r| = %.3f)\n', i, ...
               propertyNames{sortedIdx(i)}, avgAbsCorr(sortedIdx(i)));
    end
end
