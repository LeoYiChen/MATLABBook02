%% chapter_Math_problem7_solution.m
% Comprehensive Newton-Raphson root finding implementation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem7_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem7_NewtonRaphson()
    % PROBLEM7_NEWTONRAPHSON Comprehensive root finding analysis
    %
    % This function demonstrates:
    % - Newton-Raphson method for root finding
    % - Convergence analysis and rate determination
    % - Basin of attraction visualization
    % - Comparison with other root-finding methods
    % - Multiple root handling
    % - Complex root finding
    % - System of nonlinear equations
    % - Globalization strategies (damping, trust region)
    % - Automatic differentiation simulation
    %
    % Mathematical foundation:
    %   Newton-Raphson: x_{n+1} = x_n - f(x_n)/f'(x_n)
    %   Convergence: Quadratic near simple roots
    %   Error: |e_{n+1}| ≈ C|e_n|뿯½
    %
    % References:
    % - Kelley, "Iterative Methods for Linear and Nonlinear Equations" (1995)
    % - Dennis & Schnabel, "Numerical Methods for Unconstrained 
    %   Optimization and Nonlinear Equations" (1996)
    % - Ortega & Rheinboldt, "Iterative Solution of Nonlinear 
    %   Equations in Several Variables" (1970)
    %
    % Author: Dr Yi Chen
    % Date: 2025
    % MATLAB Version: R2023b or later
    
    fprintf('\n=== Problem 7: Newton-Raphson Root Finding ===\n\n');
    
    % Define test function and its derivative
    f = @(x) x.^3 - 2*x - 5;
    df = @(x) 3*x.^2 - 2;
    
    x0 = 2;  % Initial guess
    
    fprintf('Finding root of: f(x) = x뿯½ - 2x - 5\n');
    fprintf('Initial guess: x뿯₽ = %.1f\n\n', x0);
    
    % Method 1: Basic Newton-Raphson
    fprintf('=== Method 1: Basic Newton-Raphson ===\n\n');
    [root1, history1] = newtonRaphsonBasic(f, df, x0);
    
    % Method 2: Newton-Raphson with numerical derivative
    fprintf('\n=== Method 2: Newton with Numerical Derivative ===\n\n');
    [root2, history2] = newtonRaphsonNumerical(f, x0);
    
    % Method 3: Secant method (derivative-free)
    fprintf('\n=== Method 3: Secant Method ===\n\n');
    [root3, history3] = secantMethod(f, x0, x0 + 0.1);
    
    % Method 4: Bisection method (guaranteed convergence)
    fprintf('\n=== Method 4: Bisection Method ===\n\n');
    [root4, history4] = bisectionMethod(f, 2, 3);
    
    % Method 5: Halley's method (cubic convergence!)
    fprintf('\n=== Method 5: Halley''s Method ===\n\n');
    d2f = @(x) 6*x;  % Second derivative
    [root5, history5] = halleyMethod(f, df, d2f, x0);
    
    % Compare convergence rates
    fprintf('\n=== Convergence Comparison ===\n\n');
    compareConvergence(history1, history2, history3, history4, history5);
    
    % Analyze convergence order
    fprintf('\n=== Convergence Order Analysis ===\n\n');
    analyzeConvergenceOrder(history1, 'Newton-Raphson');
    analyzeConvergenceOrder(history3, 'Secant');
    analyzeConvergenceOrder(history5, 'Halley');
    
    % Basin of attraction
    fprintf('\n=== Basin of Attraction Analysis ===\n\n');
    analyzeBasinOfAttraction(f, df, root1);
    
    % Multiple roots problem
    fprintf('\n=== Multiple Root Handling ===\n\n');
    demonstrateMultipleRoots();
    
    % Complex roots
    fprintf('\n=== Complex Root Finding ===\n\n');
    findComplexRoots();
    
    % System of nonlinear equations
    fprintf('\n=== System of Nonlinear Equations ===\n\n');
    solveNonlinearSystem();
    
    % Globalization strategies
    fprintf('\n=== Globalization Strategies ===\n\n');
    demonstrateGlobalization(f, df);
    
    % Create comprehensive visualizations
    createRootFindingPlots(f, df, history1, history2, history3, ...
        history4, history5, root1);
    
    fprintf('\nAnalysis complete!\n');
end

function [root, history] = newtonRaphsonBasic(f, df, x0, tol, maxiter)
    % NEWTONRAPHSONBASIC Classic Newton-Raphson implementation
    %
    % Algorithm:
    %   while not converged:
    %     x_new = x - f(x)/f'(x)
    %     check convergence
    %     x = x_new
    
    if nargin < 4, tol = 1e-10; end
    if nargin < 5, maxiter = 50; end
    
    fprintf('Newton-Raphson Method\n');
    fprintf('Tolerance: %.2e, Max iterations: %d\n\n', tol, maxiter);
    
    fprintf('%4s  %15s  %15s  %15s  %10s\n', ...
        'Iter', 'x_n', 'f(x_n)', 'f''(x_n)', '|뿯νx|');
    fprintf('%s\n', repmat('-', 1, 75));
    
    x = x0;
    history = zeros(maxiter, 4);  % [x, f(x), f'(x), |뿯νx|]
    
    for iter = 1:maxiter
        fx = f(x);
        dfx = df(x);
        
        % Check for zero derivative
        if abs(dfx) < eps
            warning('Derivative near zero at x = %.6f', x);
            break;
        end
        
        % Newton step
        delta_x = -fx / dfx;
        x_new = x + delta_x;
        
        % Store history
        history(iter, :) = [x, fx, dfx, abs(delta_x)];
        
        % Display progress
        fprintf('%4d  %15.10f  %15.10e  %15.10e  %10.2e\n', ...
            iter, x, fx, dfx, abs(delta_x));
        
        % Check convergence
        if abs(fx) < tol || abs(delta_x) < tol
            fprintf('\n✓ Converged in %d iterations\n', iter);
            fprintf('Root: x = %.15f\n', x_new);
            fprintf('f(x) = %.2e\n', f(x_new));
            history = history(1:iter, :);
            root = x_new;
            return;
        end
        
        x = x_new;
    end
    
    warning('Maximum iterations reached without convergence');
    history = history(1:iter, :);
    root = x;
end

function [root, history] = newtonRaphsonNumerical(f, x0, tol, maxiter)
    % NEWTONRAPHSONNUMERICAL Newton with finite difference derivative
    %
    % Uses central difference: f'(x) ≈ [f(x+h) - f(x-h)]/(2h)
    
    if nargin < 3, tol = 1e-10; end
    if nargin < 4, maxiter = 50; end
    
    fprintf('Newton-Raphson with Numerical Derivative\n');
    fprintf('Using central finite differences\n\n');
    
    fprintf('%4s  %15s  %15s  %15s\n', ...
        'Iter', 'x_n', 'f(x_n)', '|뿯νx|');
    fprintf('%s\n', repmat('-', 1, 60));
    
    x = x0;
    history = zeros(maxiter, 3);
    
    for iter = 1:maxiter
        fx = f(x);
        
        % Numerical derivative (central difference)
        h = max(abs(x), 1) * sqrt(eps);  % Adaptive step size
        dfx = (f(x + h) - f(x - h)) / (2 * h);
        
        if abs(dfx) < eps
            warning('Numerical derivative near zero');
            break;
        end
        
        delta_x = -fx / dfx;
        x_new = x + delta_x;
        
        history(iter, :) = [x, fx, abs(delta_x)];
        
        fprintf('%4d  %15.10f  %15.10e  %15.2e\n', ...
            iter, x, fx, abs(delta_x));
        
        if abs(fx) < tol || abs(delta_x) < tol
            fprintf('\n✓ Converged in %d iterations\n', iter);
            fprintf('Root: x = %.15f\n', x_new);
            history = history(1:iter, :);
            root = x_new;
            return;
        end
        
        x = x_new;
    end
    
    warning('Maximum iterations reached');
    history = history(1:iter, :);
    root = x;
end

function [root, history] = secantMethod(f, x0, x1, tol, maxiter)
    % SECANTMETHOD Derivative-free alternative to Newton
    %
    % Uses finite difference of function values:
    %   f'(x_n) ≈ [f(x_n) - f(x_{n-1})] / [x_n - x_{n-1}]
    %
    % Convergence order: 뿯ν = (1+√5)/2 ≈ 1.618 (golden ratio!)
    
    if nargin < 4, tol = 1e-10; end
    if nargin < 5, maxiter = 50; end
    
    fprintf('Secant Method (derivative-free)\n');
    fprintf('Requires two initial guesses\n\n');
    
    fprintf('%4s  %15s  %15s  %15s\n', ...
        'Iter', 'x_n', 'f(x_n)', '|뿯νx|');
    fprintf('%s\n', repmat('-', 1, 60));
    
    x_prev = x0;
    x_curr = x1;
    f_prev = f(x_prev);
    f_curr = f(x_curr);
    
    history = zeros(maxiter, 3);
    
    for iter = 1:maxiter
        % Secant approximation to derivative
        if abs(x_curr - x_prev) < eps
            warning('Division by near-zero difference');
            break;
        end
        
        df_approx = (f_curr - f_prev) / (x_curr - x_prev);
        
        if abs(df_approx) < eps
            warning('Approximate derivative near zero');
            break;
        end
        
        % Secant step
        delta_x = -f_curr / df_approx;
        x_new = x_curr + delta_x;
        f_new = f(x_new);
        
        history(iter, :) = [x_curr, f_curr, abs(delta_x)];
        
        fprintf('%4d  %15.10f  %15.10e  %15.2e\n', ...
            iter, x_curr, f_curr, abs(delta_x));
        
        if abs(f_curr) < tol || abs(delta_x) < tol
            fprintf('\n✓ Converged in %d iterations\n', iter);
            fprintf('Root: x = %.15f\n', x_new);
            history = history(1:iter, :);
            root = x_new;
            return;
        end
        
        % Update for next iteration
        x_prev = x_curr;
        x_curr = x_new;
        f_prev = f_curr;
        f_curr = f_new;
    end
    
    warning('Maximum iterations reached');
    history = history(1:iter, :);
    root = x_curr;
end

function [root, history] = bisectionMethod(f, a, b, tol, maxiter)
    % BISECTIONMETHOD Guaranteed convergence (but slow)
    %
    % Requirements: f(a) and f(b) have opposite signs
    % Convergence: Linear, error halves each iteration
    % Advantage: ALWAYS converges (robust!)
    
    if nargin < 4, tol = 1e-10; end
    if nargin < 5, maxiter = 100; end
    
    fprintf('Bisection Method\n');
    fprintf('Interval: [%.2f, %.2f]\n', a, b);
    
    fa = f(a);
    fb = f(b);
    
    if fa * fb > 0
        error('f(a) and f(b) must have opposite signs!');
    end
    
    fprintf('\nf(%.2f) = %.6f\n', a, fa);
    fprintf('f(%.2f) = %.6f\n', b, fb);
    fprintf('Signs are opposite ✓\n\n');
    
    fprintf('%4s  %15s  %15s  %15s  %15s\n', ...
        'Iter', 'a', 'b', 'midpoint', 'f(mid)');
    fprintf('%s\n', repmat('-', 1, 75));
    
    history = zeros(maxiter, 3);
    
    for iter = 1:maxiter
        c = (a + b) / 2;  % Midpoint
        fc = f(c);
        
        history(iter, :) = [c, fc, (b - a) / 2];
        
        fprintf('%4d  %15.10f  %15.10f  %15.10f  %15.10e\n', ...
            iter, a, b, c, fc);
        
        if abs(fc) < tol || (b - a) / 2 < tol
            fprintf('\n✓ Converged in %d iterations\n', iter);
            fprintf('Root: x = %.15f\n', c);
            history = history(1:iter, :);
            root = c;
            return;
        end
        
        % Update interval
        if fa * fc < 0
            b = c;
            fb = fc;
        else
            a = c;
            fa = fc;
        end
    end
    
    warning('Maximum iterations reached');
    history = history(1:iter, :);
    root = (a + b) / 2;
end

function [root, history] = halleyMethod(f, df, d2f, x0, tol, maxiter)
    % HALLEYMETHOD Cubic convergence using second derivative!
    %
    % Formula: x_{n+1} = x_n - 2f(x)f'(x) / [2(f'(x))뿯½ - f(x)f''(x)]
    %
    % Converges faster than Newton (cubic vs quadratic)
    % but requires second derivative
    
    if nargin < 5, tol = 1e-10; end
    if nargin < 6, maxiter = 50; end
    
    fprintf('Halley''s Method (cubic convergence)\n');
    fprintf('Uses both first and second derivatives\n\n');
    
    fprintf('%4s  %15s  %15s  %15s\n', ...
        'Iter', 'x_n', 'f(x_n)', '|뿯νx|');
    fprintf('%s\n', repmat('-', 1, 60));
    
    x = x0;
    history = zeros(maxiter, 3);
    
    for iter = 1:maxiter
        fx = f(x);
        dfx = df(x);
        d2fx = d2f(x);
        
        % Halley's formula
        denom = 2 * dfx^2 - fx * d2fx;
        
        if abs(denom) < eps
            warning('Denominator near zero');
            break;
        end
        
        delta_x = -2 * fx * dfx / denom;
        x_new = x + delta_x;
        
        history(iter, :) = [x, fx, abs(delta_x)];
        
        fprintf('%4d  %15.10f  %15.10e  %15.2e\n', ...
            iter, x, fx, abs(delta_x));
        
        if abs(fx) < tol || abs(delta_x) < tol
            fprintf('\n✓ Converged in %d iterations\n', iter);
            fprintf('Root: x = %.15f\n', x_new);
            fprintf('\nNote: Halley converges faster than Newton!\n');
            history = history(1:iter, :);
            root = x_new;
            return;
        end
        
        x = x_new;
    end
    
    warning('Maximum iterations reached');
    history = history(1:iter, :);
    root = x;
end

function compareConvergence(h1, h2, h3, h4, h5)
    % COMPARECONVERGENCE Compare different methods
    
    methods = {'Newton', 'Newton (num)', 'Secant', 'Bisection', 'Halley'};
    histories = {h1, h2, h3, h4, h5};
    
    fprintf('Method comparison:\n\n');
    fprintf('%15s  %10s  %15s  %15s\n', ...
        'Method', 'Iterations', 'Final |f(x)|', 'Final root');
    fprintf('%s\n', repmat('-', 1, 65));
    
    for i = 1:length(methods)
        h = histories{i};
        if ~isempty(h)
            n_iter = size(h, 1);
            final_fx = abs(h(end, 2));
            final_x = h(end, 1);
            
            fprintf('%15s  %10d  %15.2e  %15.10f\n', ...
                methods{i}, n_iter, final_fx, final_x);
        end
    end
    
    fprintf('\nObservations:\n');
    fprintf('  • Newton: Fast (quadratic), needs derivative\n');
    fprintf('  • Secant: Good (superlinear), no derivative needed\n');
    fprintf('  • Bisection: Slow but guaranteed (robust)\n');
    fprintf('  • Halley: Fastest (cubic), needs 2nd derivative\n');
end

function analyzeConvergenceOrder(history, method_name)
    % ANALYZECONVERGENCEORDER Empirically determine convergence rate
    %
    % For order p: |e_{n+1}| ≈ C|e_n|^p
    % Taking logs: log|e_{n+1}| ≈ log(C) + p뿯½log|e_n|
    
    fprintf('Convergence order analysis for %s:\n\n', method_name);
    
    if size(history, 1) < 4
        fprintf('Insufficient iterations for analysis\n');
        return;
    end
    
    % Extract x values (first column)
    x_vals = history(:, 1);
    
    % Approximate true root as final value
    x_true = x_vals(end);
    
    % Compute errors
    errors = abs(x_vals - x_true);
    
    % Filter out very small errors (numerical noise)
    valid = errors > 1e-14;
    errors = errors(valid);
    
    if length(errors) < 3
        fprintf('Errors too small for reliable analysis\n');
        return;
    end
    
    % Estimate convergence order using consecutive error ratios
    % p ≈ log|e_{n+1}| / log|e_n|
    n = length(errors) - 1;
    orders = zeros(n-1, 1);
    
    for i = 1:n-1
        if errors(i) > 0 && errors(i+1) > 0 && errors(i+2) > 0
            orders(i) = log(errors(i+2) / errors(i+1)) / ...
                       log(errors(i+1) / errors(i));
        end
    end
    
    % Remove invalid values
    orders = orders(isfinite(orders) & orders > 0);
    
    if ~isempty(orders)
        avg_order = mean(orders);
        fprintf('Estimated convergence order: p ≈ %.2f\n', avg_order);
        
        if abs(avg_order - 1) < 0.2
            fprintf('뿯↽ Linear convergence\n');
        elseif abs(avg_order - 1.618) < 0.2
            fprintf('뿯↽ Superlinear (Golden ratio, typical for Secant)\n');
        elseif abs(avg_order - 2) < 0.3
            fprintf('뿯↽ Quadratic convergence (Newton)\n');
        elseif abs(avg_order - 3) < 0.5
            fprintf('뿯↽ Cubic convergence (Halley)\n');
        end
    end
    
    % Display error progression
    fprintf('\nError progression:\n');
    fprintf('%4s  %15s  %15s\n', 'Iter', '|error|', 'Ratio');
    fprintf('%s\n', repmat('-', 1, 40));
    
    for i = 1:min(length(errors), 8)
        if i > 1
            ratio = errors(i) / errors(i-1);
            fprintf('%4d  %15.2e  %15.6f\n', i-1, errors(i), ratio);
        else
            fprintf('%4d  %15.2e  %15s\n', i-1, errors(i), '-');
        end
    end
    
    fprintf('\n');
end

function analyzeBasinOfAttraction(f, df, true_root)
    % ANALYZEBASINOFATTRACTION Test many initial guesses
    
    fprintf('Testing basin of attraction...\n');
    fprintf('(Which initial guesses converge to root %.6f)\n\n', true_root);
    
    x0_range = linspace(-5, 5, 100);
    converged = false(size(x0_range));
    iterations = zeros(size(x0_range));
    
    for i = 1:length(x0_range)
        x0 = x0_range(i);
        
        try
            [root, history] = newtonRaphsonSilent(f, df, x0, 1e-6, 50);
            
            if abs(root - true_root) < 1e-3
                converged(i) = true;
                iterations(i) = size(history, 1);
            end
        catch
            % Diverged or error
            converged(i) = false;
        end
    end
    
    pct_converged = 100 * sum(converged) / length(converged);
    
    fprintf('Results from %d initial guesses in [-5, 5]:\n', ...
        length(x0_range));
    fprintf('  Converged: %d (%.1f%%)\n', sum(converged), pct_converged);
    fprintf('  Diverged: %d\n', sum(~converged));
    
    if any(converged)
        fprintf('\nConvergence statistics:\n');
        fprintf('  Mean iterations: %.1f\n', mean(iterations(converged)));
        fprintf('  Min iterations: %d\n', min(iterations(converged)));
        fprintf('  Max iterations: %d\n', max(iterations(converged)));
    end
    
    fprintf('\nNote: Poor initial guesses may diverge or converge slowly!\n');
end

function [root, history] = newtonRaphsonSilent(f, df, x0, tol, maxiter)
    % Silent version for basin analysis
    
    x = x0;
    history = zeros(maxiter, 2);
    
    for iter = 1:maxiter
        fx = f(x);
        dfx = df(x);
        
        if abs(dfx) < eps
            error('Zero derivative');
        end
        
        delta_x = -fx / dfx;
        x_new = x + delta_x;
        
        history(iter, :) = [x, fx];
        
        if abs(fx) < tol || abs(delta_x) < tol
            history = history(1:iter, :);
            root = x_new;
            return;
        end
        
        % Detect divergence
        if abs(x_new) > 1e6
            error('Divergence detected');
        end
        
        x = x_new;
    end
    
    history = history(1:iter, :);
    root = x;
end

function demonstrateMultipleRoots()
    % DEMONSTRATEMULTIPLEROOTS Show problems with multiple roots
    
    fprintf('Example: f(x) = (x - 1)뿯½(x + 2)\n');
    fprintf('Roots: x = 1 (double), x = -2 (simple)\n\n');
    
    % Multiple root at x = 1
    f_mult = @(x) (x - 1).^2 .* (x + 2);
    df_mult = @(x) 2*(x - 1).*(x + 2) + (x - 1).^2;
    
    fprintf('Standard Newton starting near x = 1:\n');
    [~, h1] = newtonRaphsonSilent(f_mult, df_mult, 1.5, 1e-10, 30);
    
    fprintf('Iterations to converge: %d (slow!)\n', size(h1, 1));
    fprintf('뿯↽ Convergence is only LINEAR at multiple roots\n\n');
    
    fprintf('Modified Newton (multiplicity m = 2):\n');
    % Modified: x_{n+1} = x_n - m * f(x_n)/f'(x_n)
    f_mod = @(x) 2 * f_mult(x);  % Multiply by m
    [root_mod, h2] = newtonRaphsonSilent(f_mod, df_mult, 1.5, 1e-10, 30);
    
    fprintf('Iterations to converge: %d (fast!)\n', size(h2, 1));
    fprintf('Root: %.10f\n', root_mod);
    fprintf('뿯↽ QUADRATIC convergence restored!\n\n');
    
    fprintf('Lesson: If you know multiplicity, use modified Newton\n');
    fprintf('        x_{n+1} = x_n - m뿯½f(x_n)/f''(x_n)\n');
end

function findComplexRoots()
    % FINDCOMPLEXROOTS Newton works in complex plane too!
    
    fprintf('Finding complex roots of f(z) = z뿯½ - 1\n');
    fprintf('Known roots: 1, e^(2뿯νi/3), e^(4뿯νi/3)\n\n');
    
    f = @(z) z.^3 - 1;
    df = @(z) 3*z.^2;
    
    % Complex initial guess
    z0 = 0.5 + 0.5i;
    
    fprintf('Using complex initial guess: z뿯₽ = %.2f + %.2fi\n\n', ...
        real(z0), imag(z0));
    
    z = z0;
    tol = 1e-10;
    
    fprintf('%4s  %20s  %15s\n', 'Iter', 'z_n', '|f(z_n)|');
    fprintf('%s\n', repmat('-', 1, 50));
    
    for iter = 1:20
        fz = f(z);
        dfz = df(z);
        
        delta_z = -fz / dfz;
        z_new = z + delta_z;
        
        fprintf('%4d  %8.6f + %8.6fi  %15.2e\n', ...
            iter, real(z), imag(z), abs(fz));
        
        if abs(fz) < tol
            fprintf('\n✓ Converged to root: z = %.10f + %.10fi\n', ...
                real(z_new), imag(z_new));
            
            % Verify it's a cube root of unity
            cube = z_new^3;
            fprintf('Verification: z뿯½ = %.10f + %.10fi\n', ...
                real(cube), imag(cube));
            break;
        end
        
        z = z_new;
    end
    
    fprintf('\nNote: Newton works beautifully in complex plane!\n');
    fprintf('      Try different initial guesses to find all roots.\n');
end

function solveNonlinearSystem()
    % SOLVENONLINEARSYSTEM Multi-dimensional Newton
    
    fprintf('Solving system of nonlinear equations:\n');
    fprintf('  x뿯½ + y뿯½ = 10\n');
    fprintf('  x뿯½y = 3\n\n');
    
    % System: F(x) = 0 where x = [x; y]
    F = @(x) [x(1)^2 + x(2)^2 - 10; 
              x(1)*x(2) - 3];
    
    % Jacobian: J = ∂F/∂x
    J = @(x) [2*x(1), 2*x(2);
              x(2),   x(1)];
    
    x0 = [2; 2];  % Initial guess
    
    fprintf('Initial guess: x뿯₽ = [%.1f; %.1f]\n\n', x0);
    
    fprintf('%4s  %15s  %15s  %15s\n', ...
        'Iter', 'x', 'y', '||F(x)||');
    fprintf('%s\n', repmat('-', 1, 60));
    
    x = x0;
    tol = 1e-10;
    
    for iter = 1:20
        Fx = F(x);
        Jx = J(x);
        
        % Newton step: solve J뿯½뿯νx = -F
        delta_x = -Jx \ Fx;
        x_new = x + delta_x;
        
        fprintf('%4d  %15.10f  %15.10f  %15.2e\n', ...
            iter, x(1), x(2), norm(Fx));
        
        if norm(Fx) < tol
            fprintf('\n✓ Solution: x = %.10f, y = %.10f\n', ...
                x_new(1), x_new(2));
            
            % Verify
            fprintf('\nVerification:\n');
            fprintf('  x뿯½ + y뿯½ = %.10f (should be 10)\n', ...
                x_new(1)^2 + x_new(2)^2);
            fprintf('  x뿯½y = %.10f (should be 3)\n', ...
                x_new(1) * x_new(2));
            break;
        end
        
        x = x_new;
    end
    
    fprintf('\nNote: Multi-dimensional Newton requires Jacobian matrix!\n');
end

function demonstrateGlobalization(f, df)
    % DEMONSTRATEGLOBALIZATION Show damping and trust regions
    
    fprintf('Poor initial guess can cause divergence!\n');
    fprintf('Solution: Globalization strategies\n\n');
    
    bad_x0 = 10;  % Far from root
    
    fprintf('Example: x뿯₽ = %.1f (far from root at x ≈ 2.09)\n\n', bad_x0);
    
    % Standard Newton (may diverge)
    fprintf('1. Standard Newton (undamped):\n');
    try
        [~, h1] = newtonRaphsonSilent(f, df, bad_x0, 1e-6, 20);
        fprintf('   Converged in %d iterations\n', size(h1, 1));
    catch
        fprintf('   DIVERGED or FAILED!\n');
    end
    
    % Damped Newton
    fprintf('\n2. Damped Newton (뿯ν = 0.5):\n');
    fprintf('   x_{n+1} = x_n - 뿯ν뿯½f(x_n)/f''(x_n)\n');
    
    x = bad_x0;
    lambda = 0.5;  % Damping factor
    
    for iter = 1:30
        fx = f(x);
        dfx = df(x);
        
        % Damped step
        delta_x = -lambda * fx / dfx;
        x = x + delta_x;
        
        if abs(fx) < 1e-6
            fprintf('   Converged in %d iterations\n', iter);
            fprintf('   Root: x = %.10f\n', x);
            break;
        end
    end
    
    fprintf('\nNote: Damping prevents wild steps, aids convergence\n');
    fprintf('      Advanced: Line search, trust regions\n');
end

function createRootFindingPlots(f, df, h1, h2, h3, h4, h5, true_root)
    % CREATEROOTFINDINGPLOTS Comprehensive visualization
    
    fprintf('\nCreating visualization plots...\n');
    
    figure('Position', [100, 100, 1400, 900], ...
        'Name', 'Root Finding Analysis');
    
    % Subplot 1: Function and roots
    subplot(2, 3, 1);
    x_plot = linspace(-1, 4, 500);
    y_plot = arrayfun(f, x_plot);
    
    plot(x_plot, y_plot, 'b-', 'LineWidth', 2);
    hold on;
    plot(x_plot, zeros(size(x_plot)), 'k-', 'LineWidth', 1);
    plot(true_root, f(true_root), 'ro', 'MarkerSize', 12, ...
        'MarkerFaceColor', 'r');
    
    % Show Newton iterations
    x_newton = h1(:, 1);
    y_newton = arrayfun(f, x_newton);
    plot(x_newton, y_newton, 'g*-', 'MarkerSize', 8, 'LineWidth', 1.5);
    
    % Draw tangent lines
    for i = 1:min(4, length(x_newton))
        x_val = x_newton(i);
        y_val = y_newton(i);
        slope = df(x_val);
        
        x_tang = [x_val - 0.5, x_val + 0.5];
        y_tang = y_val + slope * (x_tang - x_val);
        
        plot(x_tang, y_tang, 'r-', 'LineWidth', 0.5, ...
            'HandleVisibility', 'off');
    end
    
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f(x)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Function and Newton Iterations', 'Interpreter', 'latex', ...
        'FontSize', 14);
    legend('$f(x)$', '$y=0$', 'Root', 'Newton path', ...
        'Interpreter', 'latex', 'Location', 'best');
    
    % Subplot 2: Convergence comparison
    subplot(2, 3, 2);
    hold on;
    
    methods = {'Newton', 'Newton(num)', 'Secant', 'Bisection', 'Halley'};
    histories = {h1, h2, h3, h4, h5};
    colors = lines(5);
    markers = {'o', 's', 'd', '^', 'v'};
    
    for i = 1:length(histories)
        h = histories{i};
        if ~isempty(h)
            errors = abs(h(:, 2));  % |f(x_n)|
            plot(1:length(errors), errors, [markers{i} '-'], ...
                'Color', colors(i,:), 'LineWidth', 2, 'MarkerSize', 6, ...
                'DisplayName', methods{i});
        end
    end
    
    hold off;
    grid on;
    set(gca, 'YScale', 'log');
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|f(x_n)|$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Convergence Comparison', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    % Subplot 3: Convergence rate analysis
    subplot(2, 3, 3);
    
    % Plot for Newton
    errors_newton = abs(h1(:, 1) - true_root);
    errors_newton = errors_newton(errors_newton > 1e-14);
    
    if length(errors_newton) > 2
        loglog(errors_newton(1:end-1), errors_newton(2:end), ...
            'bo-', 'LineWidth', 2, 'MarkerSize', 8, ...
            'DisplayName', 'Newton');
        hold on;
        
        % Theoretical quadratic line
        x_theory = logspace(log10(min(errors_newton)), ...
            log10(max(errors_newton)), 100);
        y_theory = x_theory.^2 / x_theory(1);
        plot(x_theory, y_theory, 'r-', 'LineWidth', 1.5, ...
            'DisplayName', 'Quadratic');
        
        hold off;
        grid on;
        xlabel('$|e_n|$', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('$|e_{n+1}|$', 'Interpreter', 'latex', 'FontSize', 12);
        title('Error vs Previous Error (log-log)', ...
            'Interpreter', 'latex', 'FontSize', 14);
        legend('Interpreter', 'latex');
    end
    
    % Subplot 4: Basin of attraction
    subplot(2, 3, 4);
    
    x_range = linspace(-2, 5, 200);
    converged_arr = false(size(x_range));
    iter_arr = zeros(size(x_range));
    
    for i = 1:length(x_range)
        try
            [root, hist] = newtonRaphsonSilent(f, df, x_range(i), ...
                1e-6, 50);
            if abs(root - true_root) < 1e-3
                converged_arr(i) = true;
                iter_arr(i) = size(hist, 1);
            end
        catch
            converged_arr(i) = false;
        end
    end
    
    % Color by iterations
    scatter(x_range(converged_arr), ...
        iter_arr(converged_arr), 50, iter_arr(converged_arr), 'filled');
    colorbar;
    xlabel('Initial guess $x_0$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Iterations to converge', 'Interpreter', 'latex', 'FontSize', 12);
    title('Basin of Attraction', 'Interpreter', 'latex', 'FontSize', 14);
    grid on;
    
    % Subplot 5: Residual plot
    subplot(2, 3, 5);
    residuals = h1(:, 2);  % f(x_n)
    iterations = 1:length(residuals);
    
    stem(iterations, residuals, 'b', 'LineWidth', 2, 'MarkerSize', 8);
    hold on;
    plot([1, length(residuals)], [0, 0], 'r-', 'LineWidth', 1);
    hold off;
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f(x_n)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Residual History (Newton)', 'Interpreter', 'latex', ...
        'FontSize', 14);
    
    % Subplot 6: Step size history
    subplot(2, 3, 6);
    step_sizes = abs(h1(:, 4));
    
    semilogy(1:length(step_sizes), step_sizes, 'bo-', ...
        'LineWidth', 2, 'MarkerSize', 8);
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|\Delta x|$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Step Size History', 'Interpreter', 'latex', 'FontSize', 14);
end

% Execute problem
Problem7_NewtonRaphson();
