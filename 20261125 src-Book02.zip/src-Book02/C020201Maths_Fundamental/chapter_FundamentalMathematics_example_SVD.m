%% chapter_FundamentalMathematics_example_SVD.m
% Singular Value Decomposition for matrix analysis and compression.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_SVD
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Singular Value Decomposition (SVD)
% Demonstrates matrix factorisation and low-rank approximation

% Create example matrix (could represent image, data, etc.)
rng(42);
originalMatrix = randn(100, 50);

% Perform SVD: A = U * S * V'
[leftSingularVectors, singularValues, rightSingularVectors] = ...
    svd(originalMatrix);

% Extract singular values as vector
singularValueVector = diag(singularValues);

% Analyse singular value decay
figure('Position', [100, 100, 800, 600]);

subplot(2, 2, 1);
semilogy(singularValueVector, 'b-o', 'LineWidth', 2);
xlabel('Singular Value Index');
ylabel('Magnitude (log scale)');
title('Singular Value Spectrum');
grid on;

% Compute low-rank approximations
ranks = [5, 10, 20, 30];
approximationErrors = zeros(length(ranks), 1);

for rankIdx = 1:length(ranks)
    currentRank = ranks(rankIdx);
    
    % Reconstruct using only first k singular values
    approximateMatrix = leftSingularVectors(:, 1:currentRank) * ...
                        singularValues(1:currentRank, 1:currentRank) * ...
                        rightSingularVectors(:, 1:currentRank)';
    
    % Compute approximation error (Frobenius norm)
    approximationErrors(rankIdx) = ...
        norm(originalMatrix - approximateMatrix, 'fro') / ...
        norm(originalMatrix, 'fro');
end

subplot(2, 2, 2);
plot(ranks, approximationErrors * 100, 'r-s', ...
    'LineWidth', 2, 'MarkerSize', 8);
xlabel('Rank of Approximation');
ylabel('Relative Error (%)');
title('Low-Rank Approximation Error');
grid on;

% Compute cumulative energy (variance captured)
totalEnergy = sum(singularValueVector.^2);
cumulativeEnergy = cumsum(singularValueVector.^2) / totalEnergy;

subplot(2, 2, 3);
plot(cumulativeEnergy * 100, 'g-', 'LineWidth', 2);
xlabel('Number of Singular Values');
ylabel('Cumulative Energy (%)');
title('Energy Capture vs. Rank');
grid on;
hold on;
plot([1, length(singularValueVector)], [90, 90], 'r--', 'LineWidth', 1);
plot([1, length(singularValueVector)], [95, 95], 'r--', 'LineWidth', 1);
plot([1, length(singularValueVector)], [99, 99], 'r--', 'LineWidth', 1);
legend('Cumulative Energy', '90%', '95%', '99%', 'Location', 'southeast');
hold off;

% Find rank for 90% energy capture
rank90 = find(cumulativeEnergy >= 0.90, 1, 'first');

subplot(2, 2, 4);
bar(singularValueVector(1:min(20, length(singularValueVector))));
xlabel('Singular Value Index');
ylabel('Magnitude');
title('First 20 Singular Values');
grid on;

% Display numerical results
fprintf('Matrix Dimensions: %d x %d\n', size(originalMatrix));
fprintf('Number of singular values: %d\n', length(singularValueVector));
fprintf('Largest singular value: %.4f\n', singularValueVector(1));
fprintf('Smallest singular value: %.4e\n', singularValueVector(end));
fprintf('Condition number: %.2e\n', singularValueVector(1)/singularValueVector(end));
fprintf('Rank for 90%% energy: %d (%.1f%% compression)\n', ...
    rank90, (1 - rank90/min(size(originalMatrix))) * 100);
fprintf('\nApproximation Errors:\n');
for rankIdx = 1:length(ranks)
    fprintf('  Rank %2*d: %.2f%%\n', ...
        ranks(rankIdx), approximationErrors(rankIdx) * 100);
end
