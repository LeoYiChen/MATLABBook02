%% Appendix01-Solutions_code_251.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define network as dlnetwork
u = forward(net, dlarray([x, t], 'BC'));

% Compute first derivative
u_t = dlgradient(sum(u), t);

% Compute second derivative
u_tt = dlgradient(sum(u_t), t);
