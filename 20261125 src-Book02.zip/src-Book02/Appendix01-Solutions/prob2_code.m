%% prob2_code.m
% Polynomial regression with comprehensive model selection.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob2_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Polynomial Regression: Airfoil Lift Coefficient Analysis
% File: MATLABBook02_Chapter07_Problem02.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Performs polynomial regression on airfoil lift coefficient
%              data with comprehensive model selection and validation
% =========================================================================

function MATLABBook02_Chapter07_Problem02()
    % Main function for Problem 2: Polynomial Regression
    
    clc; clear; close all;
    
    % Generate synthetic wind tunnel data
    [angleOfAttack, liftCoefficient] = generateAirfoilData();
    
    % Fit polynomials of varying degrees
    maxDegree = 6;
    models = fitPolynomialModels(angleOfAttack, liftCoefficient, maxDegree);
    
    % Evaluate model quality
    metrics = evaluateModelQuality(models, angleOfAttack, liftCoefficient);
    
    % Display model comparison table
    displayModelComparisonTable(metrics);
    
    % Perform residual analysis
    analyseResiduals(models, angleOfAttack, liftCoefficient);
    
    % Create comprehensive visualisation
    visualisePolynomialFits(models, angleOfAttack, liftCoefficient, metrics);
    
    % Select optimal model
    optimalDegree = selectOptimalModel(metrics);
    
    % Predict using optimal model
    newAngles = linspace(-5, 20, 100);
    predictions = polyval(models(optimalDegree).coefficients, newAngles);
    
    fprintf('\n=== Optimal Model Selected ===\n');
    fprintf('Polynomial Degree: %d\n', optimalDegree);
    fprintf('R-squared: %.6f\n', metrics(optimalDegree).Rsquared);
    fprintf('Adjusted R-squared: %.6f\n', metrics(optimalDegree).adjRsquared);
    fprintf('RMSE: %.6f\n', metrics(optimalDegree).RMSE);
    fprintf('AIC: %.4f\n', metrics(optimalDegree).AIC);
end

function [alpha, CL] = generateAirfoilData()
    % GENERATEAIRFOILDATA - Creates synthetic lift coefficient measurements
    %
    % Outputs:
    %   alpha - Angle of attack (degrees)
    %   CL - Lift coefficient (dimensionless)
    
    rng(123); % Reproducibility
    
    % True angles of attack from wind tunnel tests
    alpha = (-4:0.5:18)';
    numPoints = length(alpha);
    
    % True relationship: polynomial with stall behaviour
    % Pre-stall: approximately linear (CL = 0.1 * alpha)
    % Post-stall: nonlinear decrease
    CL_true = 0.08 * alpha + 0.002 * alpha.^2 - 0.0001 * alpha.^3;
    
    % Add realistic measurement noise ( 0.05 in CL)
    noise = 0.05 * randn(numPoints, 1);
    CL = CL_true + noise;
end

function models = fitPolynomialModels(x, y, maxDegree)
    % FITPOLYNOMIALMODELS - Fits polynomials of degrees 1 through maxDegree
    %
    % Inputs:
    %   x - Independent variable (angle of attack)
    %   y - Dependent variable (lift coefficient)
    %   maxDegree - Maximum polynomial degree to fit
    %
    % Outputs:
    %   models - Structure array containing fitted coefficients
    
    models = struct('degree', {}, 'coefficients', {});
    
    for degree = 1:maxDegree
        models(degree).degree = degree;
        models(degree).coefficients = polyfit(x, y, degree);
    end
end

function metrics = evaluateModelQuality(models, x, y)
    % EVALUATEMODELQUALITY - Computes quality metrics for each model
    %
    % Calculates R, adjusted R, RMSE, and AIC
    
    n = length(y);
    yMean = mean(y);
    SST = sum((y - yMean).^2); % Total sum of squares
    
    for i = 1:length(models)
        % Predictions
        yPred = polyval(models(i).coefficients, x);
        
        % Residuals
        residuals = y - yPred;
        SSE = sum(residuals.^2); % Sum of squared errors
        
        % R-squared
        metrics(i).Rsquared = 1 - SSE / SST;
        
        % Adjusted R-squared
        p = models(i).degree; % Number of parameters (excluding intercept)
        metrics(i).adjRsquared = 1 - (SSE / (n - p - 1)) / (SST / (n - 1));
        
        % Root Mean Square Error
        metrics(i).RMSE = sqrt(SSE / n);
        
        % Akaike Information Criterion (assumes normal errors)
        % AIC = 2k + n*ln(SSE/n)
        k = p + 1; % Number of parameters (including intercept)
        metrics(i).AIC = 2 * k + n * log(SSE / n);
        
        % Store degree
        metrics(i).degree = models(i).degree;
    end
end

function displayModelComparisonTable(metrics)
    % DISPLAYMODELCOMPARISONTABLE - Formats model quality metrics
    
    fprintf('\n========================================================================\n');
    fprintf('                    POLYNOMIAL MODEL COMPARISON\n');
    fprintf('========================================================================\n');
    fprintf('Degree | R-squared | Adj R-squared |   RMSE   |    AIC    | Ranking\n');
    fprintf('------------------------------------\n');
    
    % Sort by AIC (lower is better)
    [~, sortedIdx] = sort([metrics.AIC]);
    
    for i = 1:length(metrics)
        ranking = find(sortedIdx == i);
        fprintf('  %2d   |  %7.5f  |    %7.5f    | %8.6f | %9.4f |   %d\n', ...
                metrics(i).degree, metrics(i).Rsquared, ...
                metrics(i).adjRsquared, metrics(i).RMSE, ...
                metrics(i).AIC, ranking);
    end
    fprintf('========================================================================\n');
end

function analyseResiduals(models, x, y)
    % ANALYSERESIDUALS - Creates residual plots for model diagnostics
    
    figure('Name', 'Residual Analysis', 'Position', [100, 100, 1400, 900]);
    
    numModels = length(models);
    rows = 2;
    cols = ceil(numModels / 2);
    
    for i = 1:numModels
        yPred = polyval(models(i).coefficients, x);
        residuals = y - yPred;
        
        subplot(rows, cols, i);
        
        % Residual plot
        scatter(yPred, residuals, 60, 'filled', 'MarkerFaceColor', [0.2, 0.4, 0.8]);
        hold on;
        yline(0, 'r-', 'LineWidth', 2);
        
        % Add reference lines at  2*std(residuals)
        resStd = std(residuals);
        yline(2*resStd, 'g:', 'LineWidth', 1.5);
        yline(-2*resStd, 'g:', 'LineWidth', 1.5);
        
        xlabel('Fitted $C_L$', 'Interpreter', 'latex', 'FontSize', 10);
        ylabel('Residuals', 'Interpreter', 'latex', 'FontSize', 10);
        title(sprintf('Degree %d Polynomial', models(i).degree), ...
              'Interpreter', 'latex', 'FontSize', 11, 'FontWeight', 'bold');
        grid on;
        set(gca, 'LineWidth', 1.2);
        hold off;
    end
end

function visualisePolynomialFits(models, x, y, metrics)
    % VISUALISEPOLYNOMIALFITS - Creates comprehensive visualisation
    
    figure('Name', 'Polynomial Regression Comparison', ...
           'Position', [100, 100, 1200, 800]);
    
    % Define colour scheme
    colours = lines(length(models));
    
    % Plot original data
    scatter(x, y, 80, 'k', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    
    % Plot fitted polynomials
    xFine = linspace(min(x), max(x), 200);
    
    for i = 1:length(models)
        yFit = polyval(models(i).coefficients, xFine);
        plot(xFine, yFit, 'LineWidth', 2, 'Color', colours(i,:), ...
             'DisplayName', sprintf('Degree %d ($R^2$ = %.4f)', ...
             models(i).degree, metrics(i).Rsquared));
    end
    
    xlabel('Angle of Attack, $\alpha$ (degrees)', 'Interpreter', 'latex', ...
           'FontSize', 12);
    ylabel('Lift Coefficient, $C_L$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Polynomial Regression: Airfoil Lift Coefficient', ...
          'Interpreter', 'latex', 'FontSize', 14, 'FontWeight', 'bold');
    legend('Location', 'northwest', 'Interpreter', 'latex', 'FontSize', 9);
    grid on;
    set(gca, 'LineWidth', 1.2);
    hold off;
end

function optimalDegree = selectOptimalModel(metrics)
    % SELECTOPTIMALMODEL - Identifies best model using multiple criteria
    %
    % Selection based on:
    % 1. Minimum AIC (primary criterion)
    % 2. Adjusted R within 1% of maximum
    % 3. Parsimony (prefer simpler models when performance similar)
    
    % Find model with minimum AIC
    [~, minAICidx] = min([metrics.AIC]);
    optimalDegree = metrics(minAICidx).degree;
    
    fprintf('\n=== Model Selection Criteria ===\n');
    fprintf('Minimum AIC achieved by: Degree %d\n', optimalDegree);
end
