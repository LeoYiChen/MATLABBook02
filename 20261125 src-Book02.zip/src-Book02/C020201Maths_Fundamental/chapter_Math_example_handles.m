%% chapter_Math_example_handles.m
% Function handle usage.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_handles
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create function handles to built-in functions
sinHandle = @sin;
cosHandle = @cos;

% Create array of function handles
trigFunctions = {@sin, @cos, @tan};

% Apply function from array
x = pi/4;
for k = 1:length(trigFunctions)
    fprintf('Function %d applied to pi/4: %.4f\n', ...
        k, trigFunctions{k}(x));
end

% Function returning function handle (closure)

% Create specific multipliers
double = makeMultiplier(2);
triple = makeMultiplier(3);
y1 = double(5);     % Returns 10
y2 = triple(5);     % Returns 15

% Local functions (moved to end so this listing is a valid MATLAB script)
function f = makeMultiplier(factor)
    f = @(x) factor * x;
end
