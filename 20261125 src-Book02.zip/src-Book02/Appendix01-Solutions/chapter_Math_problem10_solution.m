%% chapter_Math_problem10_solution.m
% Comprehensive optimisation implementation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem10_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem10_Optimisation()
    % PROBLEM10_OPTIMISATION Comprehensive optimisation theory and algorithms
    %
    % This function demonstrates:
    % - Unconstrained optimisation (gradient descent, Newton, BFGS)
    % - Line search strategies (backtracking, Wolfe conditions)
    % - Constrained optimisation (Lagrange multipliers, KKT)
    % - Penalty and augmented Lagrangian methods
    % - Linear programming (simplex visualization)
    % - Convex vs non-convex problems
    % - Multi-dimensional optimisation visualisation
    % - Convergence analysis and comparison
    % - Rosenbrock function (challenging test case)
    % - Applications to:
    %   * Curve fitting (least squares)
    %   * Portfolio optimisation
    %   * Structural design
    %   * Machine learning (logistic regression)
    %
    % Topics covered:
    % 1. Gradient-based methods
    % 2. Second-order methods
    % 3. Quasi-Newton approximations
    % 4. Constraint handling
    % 5. Global optimisation challenges
    % 6. Practical applications
    %
    % References:
    % - Nocedal & Wright, "Numerical Optimisation" (2006)
    % - Boyd & Vandenberghe, "Convex Optimisation" (2004)
    % - Bertsekas, "Nonlinear Programming" (1999)
    % - Fletcher, "Practical Methods of Optimisation" (2013)
    %
    % Author: Dr Yi Chen
    % Date: 2025
    
    fprintf('\n=== Problem 10: Optimisation Theory and Algorithms ===\n\n');
    
    % Part 1: Gradient descent variations
    fprintf('=== Part 1: Gradient Descent Methods ===\n\n');
    compareGradientMethods();
    
    % Part 2: Newton vs BFGS
    fprintf('\n=== Part 2: Second-Order Methods ===\n\n');
    compareSecondOrderMethods();
    
    % Part 3: Rosenbrock function (challenging!)
    fprintf('\n=== Part 3: Rosenbrock Function (Banana Valley) ===\n\n');
    optimiseRosenbrock();
    
    % Part 4: Line search strategies
    fprintf('\n=== Part 4: Line Search Strategies ===\n\n');
    demonstrateLineSearch();
    
    % Part 5: Constrained optimisation
    fprintf('\n=== Part 5: Constrained Optimisation - Lagrange Multipliers ===\n\n');
    demonstrateLagrange();
    
    % Part 6: KKT conditions
    fprintf('\n=== Part 6: KKT Conditions (Inequality Constraints) ===\n\n');
    demonstrateKKT();
    
    % Part 7: Penalty methods
    fprintf('\n=== Part 7: Penalty Methods ===\n\n');
    demonstratePenalty();
    
    % Part 8: Linear programming
    fprintf('\n=== Part 8: Linear Programming ===\n\n');
    demonstrateLinearProgramming();
    
    % Part 9: Portfolio optimisation
    fprintf('\n=== Part 9: Application - Portfolio Optimisation ===\n\n');
    portfolioOptimisation();
    
    % Part 10: Logistic regression
    fprintf('\n=== Part 10: Application - Logistic Regression ===\n\n');
    logisticRegressionOptimisation();
    
    fprintf('\nOptimisation analysis complete!\n');
end

function compareGradientMethods()
    % COMPAREGRADIENTMETHODS Compare gradient descent variants
    %
    % Test on simple quadratic: f(x) = 0.5 x^T Q x - b^T x
    
    fprintf('Comparing gradient descent variants\n');
    fprintf('Test function: f(x) = 0.5 x^T Q x - b^T x (quadratic)\n\n');
    
    % Set up problem
    n = 2;
    Q = [4, 1; 1, 2];  % Positive definite
    b = [1; 2];
    
    % Analytical solution
    x_star = Q \ b;
    f_star = -0.5 * (b' * x_star);
    
    fprintf('Analytical optimum: x* = [%.4f, %.4f]^T\n', x_star);
    fprintf('Optimal value: f* = %.6f\n\n', f_star);
    
    % Define function and gradient
    f = @(x) 0.5 * (x' * Q * x) - b' * x;
    grad_f = @(x) Q * x - b;
    
    % Starting point
    x0 = [3; 3];
    max_iter = 100;
    
    % Method 1: Fixed step size
    fprintf('Method 1: Fixed step size\n');
    alpha_fixed = 0.1;
    [x_hist1, f_hist1] = gradientDescentFixed(f, grad_f, x0, alpha_fixed, max_iter);
    fprintf('  Iterations: %d, Final f: %.6f\n', length(f_hist1), f_hist1(end));
    
    % Method 2: Optimal step size (for quadratic)
    fprintf('Method 2: Optimal step size (exact for quadratic)\n');
    [x_hist2, f_hist2] = gradientDescentOptimal(f, grad_f, Q, x0, max_iter);
    fprintf('  Iterations: %d, Final f: %.6f\n', length(f_hist2), f_hist2(end));
    
    % Method 3: Backtracking line search
    fprintf('Method 3: Backtracking line search\n');
    [x_hist3, f_hist3] = gradientDescentBacktrack(f, grad_f, x0, max_iter);
    fprintf('  Iterations: %d, Final f: %.6f\n\n', length(f_hist3), f_hist3(end));
    
    % Visualise
    figure('Position', [100, 100, 1400, 500]);
    
    % Contour plot with paths
    subplot(1, 2, 1);
    [X, Y] = meshgrid(linspace(-1, 4, 100), linspace(-1, 4, 100));
    Z = zeros(size(X));
    for i = 1:numel(X)
        Z(i) = f([X(i); Y(i)]);
    end
    
    contour(X, Y, Z, 30);
    hold on;
    plot(x_hist1(1,:), x_hist1(2,:), 'ro-', 'LineWidth', 2, 'MarkerSize', 6, ...
        'DisplayName', 'Fixed step');
    plot(x_hist2(1,:), x_hist2(2,:), 'gs-', 'LineWidth', 2, 'MarkerSize', 6, ...
        'DisplayName', 'Optimal step');
    plot(x_hist3(1,:), x_hist3(2,:), 'b^-', 'LineWidth', 2, 'MarkerSize', 6, ...
        'DisplayName', 'Backtracking');
    plot(x_star(1), x_star(2), 'k*', 'MarkerSize', 15, 'LineWidth', 3, ...
        'DisplayName', 'Optimum');
    hold off;
    colorbar;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Optimisation Paths', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northeast');
    axis equal;
    grid on;
    
    % Convergence plot
    subplot(1, 2, 2);
    semilogy(0:length(f_hist1)-1, abs(f_hist1 - f_star), 'ro-', ...
        'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Fixed step');
    hold on;
    semilogy(0:length(f_hist2)-1, abs(f_hist2 - f_star), 'gs-', ...
        'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Optimal step');
    semilogy(0:length(f_hist3)-1, abs(f_hist3 - f_star), 'b^-', ...
        'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Backtracking');
    hold off;
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|f(x_k) - f^*|$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Convergence', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northeast');
    
    fprintf('Observations:\n');
    fprintf('  • Fixed step: Can be slow or diverge if 뿯ν too large\n');
    fprintf('  • Optimal step: Fastest for quadratics (analytical formula)\n');
    fprintf('  • Backtracking: Adaptive, robust, generally good\n');
end

function [x_hist, f_hist] = gradientDescentFixed(f, grad_f, x0, alpha, max_iter)
    % Fixed step size gradient descent
    x = x0;
    x_hist = x0;
    f_hist = f(x0);
    tol = 1e-6;
    
    for k = 1:max_iter
        g = grad_f(x);
        
        if norm(g) < tol
            break;
        end
        
        x = x - alpha * g;
        x_hist = [x_hist, x];
        f_hist = [f_hist; f(x)];
    end
end

function [x_hist, f_hist] = gradientDescentOptimal(f, grad_f, Q, x0, max_iter)
    % Optimal step size for quadratic (exact line search)
    x = x0;
    x_hist = x0;
    f_hist = f(x0);
    tol = 1e-6;
    
    for k = 1:max_iter
        g = grad_f(x);
        
        if norm(g) < tol
            break;
        end
        
        % Optimal step for quadratic: 뿯ν = g^T g / g^T Q g
        alpha = (g' * g) / (g' * Q * g);
        
        x = x - alpha * g;
        x_hist = [x_hist, x];
        f_hist = [f_hist; f(x)];
    end
end

function [x_hist, f_hist] = gradientDescentBacktrack(f, grad_f, x0, max_iter)
    % Backtracking line search
    x = x0;
    x_hist = x0;
    f_hist = f(x0);
    tol = 1e-6;
    
    % Backtracking parameters
    alpha_init = 1.0;
    rho = 0.5;
    c = 1e-4;
    
    for k = 1:max_iter
        g = grad_f(x);
        
        if norm(g) < tol
            break;
        end
        
        % Backtracking line search
        alpha = alpha_init;
        while f(x - alpha * g) > f(x) - c * alpha * (g' * g)
            alpha = rho * alpha;
        end
        
        x = x - alpha * g;
        x_hist = [x_hist, x];
        f_hist = [f_hist; f(x)];
    end
end

function compareSecondOrderMethods()
    % COMPARESECONDORDERMETHODS Compare Newton and BFGS
    %
    % Test on more complex function
    
    fprintf('Comparing second-order methods\n');
    fprintf('Test function: f(x,y) = (1-x)뿯½ + 100(y-x뿯½)뿯½ (Rosenbrock)\n\n');
    
    % Rosenbrock function (banana valley - challenging!)
    f = @(x) (1 - x(1))^2 + 100*(x(2) - x(1)^2)^2;
    
    % Gradient
    grad_f = @(x) [-2*(1-x(1)) - 400*x(1)*(x(2)-x(1)^2); 
                    200*(x(2)-x(1)^2)];
    
    % Hessian
    hess_f = @(x) [-2 + 800*x(1)^2 - 400*(x(2)-x(1)^2), -400*x(1);
                    -400*x(1), 200];
    
    x0 = [-1; 1];
    x_star = [1; 1];
    max_iter = 50;
    
    fprintf('Starting point: x0 = [%.1f, %.1f]^T\n', x0);
    fprintf('True optimum: x* = [%.1f, %.1f]^T\n\n', x_star);
    
    % Gradient descent
    fprintf('Gradient Descent:\n');
    [x_hist_gd, f_hist_gd, iter_gd] = optimiseGradientDescent(f, grad_f, x0, max_iter);
    fprintf('  Iterations: %d, Final: x = [%.6f, %.6f], f = %.2e\n', ...
        iter_gd, x_hist_gd(1,end), x_hist_gd(2,end), f_hist_gd(end));
    
    % Newton's method
    fprintf('Newton''s Method:\n');
    [x_hist_newton, f_hist_newton, iter_newton] = optimiseNewton(f, grad_f, hess_f, x0, max_iter);
    fprintf('  Iterations: %d, Final: x = [%.6f, %.6f], f = %.2e\n', ...
        iter_newton, x_hist_newton(1,end), x_hist_newton(2,end), f_hist_newton(end));
    
    % BFGS
    fprintf('BFGS (Quasi-Newton):\n');
    [x_hist_bfgs, f_hist_bfgs, iter_bfgs] = optimiseBFGS(f, grad_f, x0, max_iter);
    fprintf('  Iterations: %d, Final: x = [%.6f, %.6f], f = %.2e\n\n', ...
        iter_bfgs, x_hist_bfgs(1,end), x_hist_bfgs(2,end), f_hist_bfgs(end));
    
    % Visualise
    figure('Position', [100, 100, 1400, 500]);
    
    % Contour with paths
    subplot(1, 2, 1);
    [X, Y] = meshgrid(linspace(-1.5, 1.5, 200), linspace(-0.5, 1.5, 200));
    Z = zeros(size(X));
    for i = 1:numel(X)
        Z(i) = f([X(i); Y(i)]);
    end
    
    contour(X, Y, log10(Z + 1), 40);  % Log scale for better visualisation
    hold on;
    plot(x_hist_gd(1,:), x_hist_gd(2,:), 'r.-', 'LineWidth', 1.5, ...
        'MarkerSize', 8, 'DisplayName', 'Gradient Descent');
    plot(x_hist_newton(1,:), x_hist_newton(2,:), 'g.-', 'LineWidth', 1.5, ...
        'MarkerSize', 8, 'DisplayName', 'Newton');
    plot(x_hist_bfgs(1,:), x_hist_bfgs(2,:), 'b.-', 'LineWidth', 1.5, ...
        'MarkerSize', 8, 'DisplayName', 'BFGS');
    plot(1, 1, 'k*', 'MarkerSize', 15, 'LineWidth', 3, 'DisplayName', 'Optimum');
    hold off;
    colorbar;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Rosenbrock Function', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest');
    axis equal;
    grid on;
    
    % Convergence
    subplot(1, 2, 2);
    semilogy(0:length(f_hist_gd)-1, f_hist_gd, 'r-', 'LineWidth', 2, ...
        'DisplayName', 'Gradient Descent');
    hold on;
    semilogy(0:length(f_hist_newton)-1, f_hist_newton, 'g-', 'LineWidth', 2, ...
        'DisplayName', 'Newton');
    semilogy(0:length(f_hist_bfgs)-1, f_hist_bfgs, 'b-', 'LineWidth', 2, ...
        'DisplayName', 'BFGS');
    hold off;
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f(x_k)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Convergence', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northeast');
    
    fprintf('Key insights:\n');
    fprintf('  • Newton: Quadratic convergence near optimum (if Hessian well-conditioned)\n');
    fprintf('  • BFGS: Superlinear convergence, no Hessian computation\n');
    fprintf('  • Gradient descent: Linear convergence, simplest\n');
end

function [x_hist, f_hist, iter] = optimiseGradientDescent(f, grad_f, x0, max_iter)
    % Standard gradient descent with backtracking
    x = x0;
    x_hist = x0;
    f_hist = f(x0);
    tol = 1e-6;
    
    for k = 1:max_iter
        g = grad_f(x);
        
        if norm(g) < tol
            break;
        end
        
        % Backtracking
        alpha = 1.0;
        rho = 0.5;
        c = 1e-4;
        
        while f(x - alpha * g) > f(x) - c * alpha * (g' * g)
            alpha = rho * alpha;
            if alpha < 1e-10
                break;
            end
        end
        
        x = x - alpha * g;
        x_hist = [x_hist, x];
        f_hist = [f_hist; f(x)];
    end
    
    iter = length(f_hist) - 1;
end

function [x_hist, f_hist, iter] = optimiseNewton(f, grad_f, hess_f, x0, max_iter)
    % Newton's method with line search
    x = x0;
    x_hist = x0;
    f_hist = f(x0);
    tol = 1e-6;
    
    for k = 1:max_iter
        g = grad_f(x);
        H = hess_f(x);
        
        if norm(g) < tol
            break;
        end
        
        % Newton direction
        try
            p = -H \ g;
        catch
            % Hessian singular, fall back to gradient
            p = -g;
        end
        
        % Line search
        alpha = 1.0;
        rho = 0.5;
        c = 1e-4;
        
        while f(x + alpha * p) > f(x) + c * alpha * (g' * p)
            alpha = rho * alpha;
            if alpha < 1e-10
                break;
            end
        end
        
        x = x + alpha * p;
        x_hist = [x_hist, x];
        f_hist = [f_hist; f(x)];
    end
    
    iter = length(f_hist) - 1;
end

function [x_hist, f_hist, iter] = optimiseBFGS(f, grad_f, x0, max_iter)
    % BFGS quasi-Newton method
    n = length(x0);
    x = x0;
    x_hist = x0;
    f_hist = f(x0);
    H = eye(n);  % Initial Hessian approximation
    tol = 1e-6;
    
    g_old = grad_f(x);
    
    for k = 1:max_iter
        g = grad_f(x);
        
        if norm(g) < tol
            break;
        end
        
        % BFGS direction
        p = -H * g;
        
        % Line search
        alpha = 1.0;
        rho = 0.8;
        c = 1e-4;
        
        while f(x + alpha * p) > f(x) + c * alpha * (g' * p)
            alpha = rho * alpha;
            if alpha < 1e-10
                break;
            end
        end
        
        % Update
        s = alpha * p;
        x = x + s;
        g_new = grad_f(x);
        y = g_new - g_old;
        
        % BFGS update of Hessian approximation
        if s' * y > 1e-10  % Curvature condition
            rho_k = 1 / (y' * s);
            H = (eye(n) - rho_k * s * y') * H * (eye(n) - rho_k * y * s') + ...
                rho_k * s * s';
        end
        
        x_hist = [x_hist, x];
        f_hist = [f_hist; f(x)];
        g_old = g_new;
    end
    
    iter = length(f_hist) - 1;
end

function optimiseRosenbrock()
    % OPTIMISEROSENBROCK Detailed analysis of Rosenbrock function
    
    fprintf('Rosenbrock Function: f(x,y) = (1-x)뿯½ + 100(y-x뿯½)뿯½\n');
    fprintf('Known as "banana valley" - narrow curved valley\n');
    fprintf('Global minimum: (1,1) with f = 0\n\n');
    
    % Different starting points
    starts = {[-1.2, 1], [0, 0.5], [2, 2]};
    
    f = @(x) (1 - x(1))^2 + 100*(x(2) - x(1)^2)^2;
    grad_f = @(x) [-2*(1-x(1)) - 400*x(1)*(x(2)-x(1)^2); 
                    200*(x(2)-x(1)^2)];
    
    figure('Position', [100, 100, 1400, 900]);
    
    for idx = 1:3
        x0 = starts{idx}';
        
        fprintf('Starting point %d: [%.1f, %.1f]\n', idx, x0);
        
        % Run BFGS
        [x_hist, f_hist, iter] = optimiseBFGS(f, grad_f, x0, 100);
        
        fprintf('  Converged in %d iterations\n', iter);
        fprintf('  Final point: [%.6f, %.6f]\n', x_hist(1,end), x_hist(2,end));
        fprintf('  Final value: %.2e\n\n', f_hist(end));
        
        % Plot
        subplot(2, 3, idx);
        [X, Y] = meshgrid(linspace(-2, 2, 200), linspace(-1, 3, 200));
        Z = zeros(size(X));
        for i = 1:numel(X)
            Z(i) = f([X(i); Y(i)]);
        end
        
        contour(X, Y, log10(Z + 1), 40);
        hold on;
        plot(x_hist(1,:), x_hist(2,:), 'r.-', 'LineWidth', 2, 'MarkerSize', 10);
        plot(1, 1, 'k*', 'MarkerSize', 15, 'LineWidth', 3);
        hold off;
        colorbar;
        xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('Start: $[%.1f, %.1f]$', x0), 'Interpreter', 'latex', ...
            'FontSize', 12);
        grid on;
        
        subplot(2, 3, idx+3);
        semilogy(0:length(f_hist)-1, f_hist, 'b-', 'LineWidth', 2);
        grid on;
        xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('$f(x_k)$', 'Interpreter', 'latex', 'FontSize', 11);
        title('Convergence', 'Interpreter', 'latex', 'FontSize', 12);
    end
    
    fprintf('Rosenbrock is challenging because:\n');
    fprintf('  • Narrow curved valley (ill-conditioned)\n');
    fprintf('  • Easy to find valley, hard to find minimum\n');
    fprintf('  • Tests robustness of optimisation algorithms\n');
end

function demonstrateLineSearch()
    % DEMONSTRATELINESEARCH Visualise line search strategies
    
    fprintf('Line Search Strategies\n\n');
    
    % Simple 1D function
    f = @(alpha) (alpha - 2)^2 + sin(5*alpha);
    df = @(alpha) 2*(alpha - 2) + 5*cos(5*alpha);
    
    fprintf('Test function: f(뿯ν) = (뿯ν-2)뿯½ + sin(5뿯ν)\n\n');
    
    alpha_vals = linspace(0, 4, 1000);
    f_vals = arrayfun(f, alpha_vals);
    
    % Starting point
    alpha0 = 0.5;
    f0 = f(alpha0);
    df0 = df(alpha0);
    
    % Backtracking
    fprintf('Backtracking line search:\n');
    alpha_back = alpha0;
    rho = 0.5;
    c = 0.1;
    iter_back = 0;
    
    while f(alpha_back) > f0 + c * alpha_back * df0
        alpha_back = rho * alpha_back;
        iter_back = iter_back + 1;
    end
    
    fprintf('  Found 뿯ν = %.4f after %d halvings\n', alpha_back, iter_back);
    fprintf('  Armijo condition satisfied\n\n');
    
    % Plot
    figure('Position', [100, 100, 1400, 500]);
    
    subplot(1, 2, 1);
    plot(alpha_vals, f_vals, 'b-', 'LineWidth', 2);
    hold on;
    
    % Armijo line
    armijo_line = f0 + c * alpha_vals * df0;
    plot(alpha_vals, armijo_line, 'r-', 'LineWidth', 1.5, ...
        'DisplayName', 'Armijo line');
    
    plot(alpha0, f0, 'go', 'MarkerSize', 10, 'LineWidth', 2, ...
        'DisplayName', 'Start');
    plot(alpha_back, f(alpha_back), 'r*', 'MarkerSize', 15, 'LineWidth', 2, ...
        'DisplayName', 'Accepted point');
    
    hold off;
    grid on;
    xlabel('$\alpha$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f(\alpha)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Backtracking Line Search', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    % Wolfe conditions
    subplot(1, 2, 2);
    plot(alpha_vals, f_vals, 'b-', 'LineWidth', 2, 'DisplayName', '$f(\alpha)$');
    hold on;
    
    % Armijo
    plot(alpha_vals, armijo_line, 'r-', 'LineWidth', 1.5, ...
        'DisplayName', 'Armijo');
    
    % Curvature condition
    c2 = 0.9;
    curvature_line = f0 + c2 * alpha_vals * df0;
    plot(alpha_vals, curvature_line, 'g-', 'LineWidth', 1.5, ...
        'DisplayName', 'Curvature');
    
    % Acceptable region
    acceptable = (f_vals <= armijo_line) & ...
                 (arrayfun(df, alpha_vals) >= c2 * df0);
    if any(acceptable)
        alpha_accept = alpha_vals(acceptable);
        plot(alpha_accept, f(alpha_accept(1)), 'r*', 'MarkerSize', 15, ...
            'LineWidth', 2, 'DisplayName', 'Wolfe region');
    end
    
    hold off;
    grid on;
    xlabel('$\alpha$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f(\alpha)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Wolfe Conditions', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    
    fprintf('Line search ensures:\n');
    fprintf('  • Sufficient decrease (Armijo): f(뿯ν) ≤ f(0) + c뿯₽ 뿯ν f''(0)\n');
    fprintf('  • Curvature condition (Wolfe): f''(뿯ν) ≥ c뿯₽ f''(0)\n');
    fprintf('  • Guarantees convergence of iterative methods\n');
end

function demonstrateLagrange()
    % DEMONSTRATELAGRANGE Lagrange multipliers for equality constraints
    
    fprintf('Lagrange Multipliers: Equality Constraints\n\n');
    
    fprintf('Problem: Minimise f(x,y) = x뿯½ + y뿯½ subject to x + y = 1\n\n');
    
    % Analytical solution
    fprintf('Lagrangian: L(x,y,뿯ν) = x뿯½ + y뿯½ + 뿯ν(x + y - 1)\n\n');
    fprintf('Optimality conditions:\n');
    fprintf('  ∂L/∂x = 2x + 뿯ν = 0\n');
    fprintf('  ∂L/∂y = 2y + 뿯ν = 0\n');
    fprintf('  ∂L/∂뿯ν = x + y - 1 = 0\n\n');
    
    fprintf('Solution: x = y = 0.5, 뿯ν = -1\n');
    fprintf('Optimal value: f* = 0.5\n\n');
    
    % Visualise
    figure('Position', [100, 100, 1200, 500]);
    
    % Contour plot
    subplot(1, 2, 1);
    [X, Y] = meshgrid(linspace(-1, 2, 100), linspace(-1, 2, 100));
    Z = X.^2 + Y.^2;
    
    contour(X, Y, Z, 20);
    hold on;
    
    % Constraint
    x_line = linspace(-0.5, 1.5, 100);
    y_line = 1 - x_line;
    plot(x_line, y_line, 'r-', 'LineWidth', 3, 'DisplayName', 'Constraint');
    
    % Optimum
    plot(0.5, 0.5, 'k*', 'MarkerSize', 20, 'LineWidth', 3, ...
        'DisplayName', 'Optimum');
    
    % Gradient at optimum (perpendicular to constraint!)
    quiver(0.5, 0.5, 1, 1, 0.3, 'g', 'LineWidth', 2, 'MaxHeadSize', 0.5, ...
        'DisplayName', '$\nabla f$');
    quiver(0.5, 0.5, 1, -1, 0.3, 'r', 'LineWidth', 2, 'MaxHeadSize', 0.5, ...
        'DisplayName', '$\nabla h$');
    
    hold off;
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Constrained Optimisation', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest');
    axis equal;
    grid on;
    
    % 3D visualisation
    subplot(1, 2, 2);
    surf(X, Y, Z, 'EdgeColor', 'none', 'FaceAlpha', 0.7);
    hold on;
    
    % Constraint line in 3D
    z_line = x_line.^2 + y_line.^2;
    plot3(x_line, y_line, z_line, 'r-', 'LineWidth', 4);
    
    % Optimum
    plot3(0.5, 0.5, 0.5, 'k*', 'MarkerSize', 20, 'LineWidth', 3);
    
    hold off;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$f(x,y)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('3D View', 'Interpreter', 'latex', 'FontSize', 14);
    view(45, 30);
    colormap jet;
    grid on;
    
    fprintf('Key insight:\n');
    fprintf('  At optimum: ∇f is parallel to ∇h (perpendicular to constraint!)\n');
    fprintf('  Lagrange multiplier 뿯ν measures sensitivity to constraint\n');
end

function demonstrateKKT()
    % DEMONSTRATEKKT KKT conditions for inequality constraints
    
    fprintf('KKT Conditions: Inequality Constraints\n\n');
    
    fprintf('Problem: Minimise f(x,y) = (x-1)뿯½ + (y-1)뿯½\n');
    fprintf('         subject to x뿯½ + y뿯½ ≤ 1\n\n');
    
    % Analytical solution
    fprintf('The constraint is active at optimum (circle boundary)\n\n');
    
    % Optimum on boundary
    theta_opt = pi/4;
    x_opt = [cos(theta_opt); sin(theta_opt)];
    
    fprintf('Optimal point: x* = [%.4f, %.4f]^T\n', x_opt);
    fprintf('On circle boundary: x뿯½ + y뿯½ = 1\n\n');
    
    fprintf('KKT conditions:\n');
    fprintf('  Stationarity: ∇f + 뿯ν∇g = 0\n');
    fprintf('  Primal feasibility: g(x) ≤ 0\n');
    fprintf('  Dual feasibility: 뿯ν ≥ 0\n');
    fprintf('  Complementarity: 뿯ν g(x) = 0\n\n');
    
    % Visualise
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    [X, Y] = meshgrid(linspace(-1.5, 2, 100), linspace(-1.5, 2, 100));
    Z = (X - 1).^2 + (Y - 1).^2;
    
    contour(X, Y, Z, 20);
    hold on;
    
    % Constraint circle
    theta = linspace(0, 2*pi, 100);
    plot(cos(theta), sin(theta), 'r-', 'LineWidth', 3, ...
        'DisplayName', 'Constraint');
    
    % Feasible region
    theta_fill = linspace(0, 2*pi, 100);
    fill(cos(theta_fill), sin(theta_fill), 'r', 'FaceAlpha', 0.1, ...
        'EdgeColor', 'none', 'DisplayName', 'Feasible');
    
    % Unconstrained optimum (outside feasible region!)
    plot(1, 1, 'go', 'MarkerSize', 12, 'LineWidth', 2, ...
        'DisplayName', 'Unconstrained opt');
    
    % Constrained optimum
    plot(x_opt(1), x_opt(2), 'k*', 'MarkerSize', 20, 'LineWidth', 3, ...
        'DisplayName', 'Constrained opt');
    
    % Gradients
    grad_f = 2*[x_opt(1)-1; x_opt(2)-1];
    grad_g = 2*x_opt;
    
    quiver(x_opt(1), x_opt(2), grad_f(1), grad_f(2), 0.2, 'g', ...
        'LineWidth', 2, 'MaxHeadSize', 0.5);
    quiver(x_opt(1), x_opt(2), -grad_g(1), -grad_g(2), 0.2, 'r', ...
        'LineWidth', 2, 'MaxHeadSize', 0.5);
    
    hold off;
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('KKT Problem', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest');
    axis equal;
    grid on;
    
    % Active set
    subplot(1, 2, 2);
    
    % Show different cases
    points = [x_opt, [0;1], [1;1]];
    labels = {'Boundary (active)', 'Boundary (inactive)', 'Outside (infeasible)'};
    colors = ['k', 'b', 'r'];
    
    contour(X, Y, Z, 20);
    hold on;
    plot(cos(theta), sin(theta), 'r-', 'LineWidth', 3);
    
    for i = 1:3
        plot(points(1,i), points(2,i), [colors(i) '*'], ...
            'MarkerSize', 15, 'LineWidth', 3, ...
            'DisplayName', labels{i});
    end
    
    hold off;
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Active vs Inactive Constraints', 'Interpreter', 'latex', ...
        'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northwest');
    axis equal;
    grid on;
    
    fprintf('Complementarity intuition:\n');
    fprintf('  • If constraint inactive (g < 0): 뿯ν = 0 (no effect)\n');
    fprintf('  • If constraint active (g = 0): 뿯ν > 0 (pushes optimum)\n');
end

function demonstratePenalty()
    % DEMONSTRATEPENALTY Penalty methods for constraints
    
    fprintf('Penalty Methods for Constrained Optimisation\n\n');
    
    fprintf('Problem: Minimise f(x,y) = x뿯½ + y뿯½\n');
    fprintf('         subject to x + y ≥ 1\n\n');
    
    fprintf('Penalty formulation:\n');
    fprintf('  뿯ν(x,y;뿯ν) = x뿯½ + y뿯½ + 뿯ν[max(0, 1-x-y)]뿯½\n\n');
    
    % True solution
    x_true = [0.5; 0.5];
    f_true = 0.5;
    
    fprintf('True optimum: x* = [0.5, 0.5]^T, f* = 0.5\n\n');
    
    % Penalty parameters
    rho_values = [1, 10, 100, 1000];
    
    figure('Position', [100, 100, 1400, 900]);
    
    for idx = 1:length(rho_values)
        rho = rho_values(idx);
        
        fprintf('뿯ν = %d:\n', rho);
        
        % Penalty function
        penalty = @(x) x(1)^2 + x(2)^2 + rho * max(0, 1 - x(1) - x(2))^2;
        grad_penalty = @(x) [2*x(1) - 2*rho*max(0,1-x(1)-x(2)); 
                              2*x(2) - 2*rho*max(0,1-x(1)-x(2))];
        
        % Optimise
        x0 = [0; 0];
        [x_hist, ~, ~] = optimiseGradientDescent(penalty, grad_penalty, x0, 200);
        x_opt = x_hist(:, end);
        
        fprintf('  Solution: x = [%.4f, %.4f]^T\n', x_opt);
        fprintf('  Error: ||x - x*|| = %.4f\n\n', norm(x_opt - x_true));
        
        % Plot
        subplot(2, 2, idx);
        [X, Y] = meshgrid(linspace(-0.5, 1.5, 100), linspace(-0.5, 1.5, 100));
        Z = zeros(size(X));
        for i = 1:numel(X)
            Z(i) = penalty([X(i); Y(i)]);
        end
        
        contour(X, Y, Z, 30);
        hold on;
        
        % Constraint
        x_line = linspace(-0.5, 1.5, 100);
        y_line = 1 - x_line;
        plot(x_line, y_line, 'r-', 'LineWidth', 2, 'DisplayName', 'Constraint');
        
        % True optimum
        plot(x_true(1), x_true(2), 'k*', 'MarkerSize', 15, 'LineWidth', 3);
        
        % Penalty optimum
        plot(x_opt(1), x_opt(2), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
        
        % Path
        plot(x_hist(1,:), x_hist(2,:), 'g.-', 'LineWidth', 1);
        
        hold off;
        colorbar;
        xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 11);
        ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 11);
        title(sprintf('$\\rho = %d$', rho), 'Interpreter', 'latex', ...
            'FontSize', 12);
        axis equal;
        grid on;
    end
    
    fprintf('Observations:\n');
    fprintf('  • As 뿯ν 뿯↽ ∞, penalty solution 뿯↽ true solution\n');
    fprintf('  • Trade-off: accuracy vs conditioning\n');
    fprintf('  • Large 뿯ν makes problem ill-conditioned\n');
end

function demonstrateLinearProgramming()
    % DEMONSTRATELINEARPROGRAMMING Visualise LP geometry
    
    fprintf('Linear Programming\n\n');
    
    fprintf('Problem:\n');
    fprintf('  Maximise: 3x + 4y\n');
    fprintf('  subject to: x + 2y ≤ 8\n');
    fprintf('              3x + 2y ≤ 12\n');
    fprintf('              x, y ≥ 0\n\n');
    
    % Convert to standard form for linprog (minimise)
    f = [-3; -4];
    A = [1, 2; 3, 2];
    b = [8; 12];
    lb = [0; 0];
    
    % Solve
    options = optimoptions('linprog', 'Display', 'off');
    [x_opt, fval] = linprog(f, A, b, [], [], lb, [], options);
    
    fprintf('Optimal solution: x = %.2f, y = %.2f\n', x_opt);
    fprintf('Optimal value: %.2f\n\n', -fval);
    
    % Visualise
    figure('Position', [100, 100, 800, 600]);
    
    % Constraints
    x = linspace(0, 5, 100);
    
    % x + 2y ≤ 8
    y1 = (8 - x) / 2;
    
    % 3x + 2y ≤ 12
    y2 = (12 - 3*x) / 2;
    
    plot(x, y1, 'r-', 'LineWidth', 2, 'DisplayName', '$x + 2y \\leq 8$');
    hold on;
    plot(x, y2, 'b-', 'LineWidth', 2, 'DisplayName', '$3x + 2y \\leq 12$');
    
    % Feasible region
    [X, Y] = meshgrid(linspace(0, 5, 100), linspace(0, 5, 100));
    feasible = (X + 2*Y <= 8) & (3*X + 2*Y <= 12) & (X >= 0) & (Y >= 0);
    contourf(X, Y, double(feasible), 1, 'FaceAlpha', 0.2, 'EdgeColor', 'none');
    
    % Objective function contours
    Z = -3*X - 4*Y;  % Negative because we're maximising
    contour(X, Y, Z, 10, '-k', 'LineWidth', 1);
    
    % Vertices of feasible region
    vertices = [0, 0; 4, 0; 0, 4; 8/3, 2/3];
    plot(vertices(:,1), vertices(:,2), 'ko', 'MarkerSize', 8, 'LineWidth', 2);
    
    % Optimal point
    plot(x_opt(1), x_opt(2), 'g*', 'MarkerSize', 20, 'LineWidth', 3, ...
        'DisplayName', 'Optimum');
    
    hold off;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Linear Programming', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'northeast');
    grid on;
    axis([0, 5, 0, 5]);
    
    fprintf('Key properties of LP:\n');
    fprintf('  • Feasible region is convex polytope\n');
    fprintf('  • Optimum always at vertex (corner point)\n');
    fprintf('  • Simplex method walks along edges\n');
    fprintf('  • Polynomial-time algorithms exist (interior point)\n');
end

function portfolioOptimisation()
    % PORTFOLIOOPTIMISATION Markowitz mean-variance portfolio
    
    fprintf('Application: Portfolio Optimisation (Markowitz)\n\n');
    
    fprintf('Problem: Allocate wealth among assets to minimise risk\n');
    fprintf('         for target expected return\n\n');
    
    % Simulate asset data
    n_assets = 4;
    rng(42);
    
    % Expected returns
    mu = [0.10; 0.12; 0.08; 0.15];
    
    % Covariance matrix (risk)
    Sigma = [0.04, 0.01, 0.02, 0.01;
             0.01, 0.06, 0.015, 0.02;
             0.02, 0.015, 0.03, 0.01;
             0.01, 0.02, 0.01, 0.08];
    
    fprintf('Assets: %d\n', n_assets);
    fprintf('Expected returns: [%.2f, %.2f, %.2f, %.2f]\n', mu);
    fprintf('Risk (std dev): [%.3f, %.3f, %.3f, %.3f]\n\n', sqrt(diag(Sigma)));
    
    % Efficient frontier
    target_returns = linspace(min(mu), max(mu), 50);
    frontier_risk = zeros(size(target_returns));
    frontier_weights = zeros(n_assets, length(target_returns));
    
    fprintf('Computing efficient frontier...\n\n');
    
    for i = 1:length(target_returns)
        r_target = target_returns(i);
        
        % Quadratic program:
        % min w^T 뿯ν w
        % s.t. w^T 뿯ν = r_target
        %      sum(w) = 1
        %      w ≥ 0
        
        H = 2 * Sigma;
        f = zeros(n_assets, 1);
        Aeq = [mu'; ones(1, n_assets)];
        beq = [r_target; 1];
        lb = zeros(n_assets, 1);
        
        options = optimoptions('quadprog', 'Display', 'off');
        [w, fval] = quadprog(H, f, [], [], Aeq, beq, lb, [], [], options);
        
        frontier_weights(:, i) = w;
        frontier_risk(i) = sqrt(w' * Sigma * w);
    end
    
    % Plot efficient frontier
    figure('Position', [100, 100, 1400, 500]);
    
    subplot(1, 2, 1);
    plot(frontier_risk, target_returns, 'b-', 'LineWidth', 3);
    hold on;
    
    % Individual assets
    asset_risk = sqrt(diag(Sigma));
    plot(asset_risk, mu, 'ro', 'MarkerSize', 12, 'LineWidth', 2, ...
        'DisplayName', 'Individual assets');
    
    % Minimum variance portfolio
    [min_risk, idx_min] = min(frontier_risk);
    plot(min_risk, target_returns(idx_min), 'g*', 'MarkerSize', 20, ...
        'LineWidth', 3, 'DisplayName', 'Min variance');
    
    hold off;
    xlabel('Risk (std dev)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Expected return', 'Interpreter', 'latex', 'FontSize', 12);
    title('Efficient Frontier', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'southeast');
    grid on;
    
    % Weight allocation
    subplot(1, 2, 2);
    area(target_returns, frontier_weights');
    xlabel('Target return', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Portfolio weights', 'Interpreter', 'latex', 'FontSize', 12);
    title('Optimal Asset Allocation', 'Interpreter', 'latex', 'FontSize', 14);
    legend(arrayfun(@(i) sprintf('Asset %d', i), 1:n_assets, ...
        'UniformOutput', false), 'Location', 'eastoutside');
    grid on;
    
    fprintf('Efficient frontier computed!\n');
    fprintf('Each point: minimum risk for given return\n');
    fprintf('Diversification reduces risk (Markowitz insight)\n');
end

function logisticRegressionOptimisation()
    % LOGISTICREGRESSIONOPTIMISATION Train classifier via optimisation
    
    fprintf('Application: Logistic Regression (Classification)\n\n');
    
    fprintf('Problem: Find decision boundary for binary classification\n');
    fprintf('Loss function: Cross-entropy (convex!)\n\n');
    
    % Generate synthetic data
    rng(123);
    n = 100;
    
    % Class 0
    X0 = mvnrnd([1, 1], 0.5*eye(2), n/2);
    y0 = zeros(n/2, 1);
    
    % Class 1
    X1 = mvnrnd([3, 3], 0.5*eye(2), n/2);
    y1 = ones(n/2, 1);
    
    % Combine
    X = [X0; X1];
    y = [y0; y1];
    
    % Add bias term
    X = [ones(n, 1), X];
    
    fprintf('Dataset: %d samples, 2 features\n', n);
    fprintf('Classes: balanced (50-50)\n\n');
    
    % Logistic regression loss
    sigmoid = @(z) 1 ./ (1 + exp(-z));
    
    loss = @(w) -mean(y .* log(sigmoid(X*w)) + ...
                      (1-y) .* log(1 - sigmoid(X*w)));
    
    grad_loss = @(w) X' * (sigmoid(X*w) - y) / n;
    
    % Train using gradient descent
    fprintf('Training via gradient descent...\n');
    w0 = zeros(3, 1);
    [w_hist, loss_hist, iter] = optimiseGradientDescent(loss, grad_loss, w0, 500);
    w_opt = w_hist(:, end);
    
    fprintf('Converged in %d iterations\n', iter);
    fprintf('Final loss: %.6f\n', loss_hist(end));
    fprintf('Weights: [%.4f, %.4f, %.4f]\n\n', w_opt);
    
    % Evaluate accuracy
    y_pred = sigmoid(X * w_opt) > 0.5;
    accuracy = mean(y_pred == y);
    
    fprintf('Training accuracy: %.2f%%\n\n', accuracy * 100);
    
    % Visualise
    figure('Position', [100, 100, 1400, 500]);
    
    % Decision boundary
    subplot(1, 2, 1);
    
    % Plot data
    plot(X(y==0, 2), X(y==0, 3), 'bo', 'MarkerSize', 8, 'LineWidth', 1.5, ...
        'DisplayName', 'Class 0');
    hold on;
    plot(X(y==1, 2), X(y==1, 3), 'r^', 'MarkerSize', 8, 'LineWidth', 1.5, ...
        'DisplayName', 'Class 1');
    
    % Decision boundary: w0 + w1*x1 + w2*x2 = 0
    x1_line = linspace(min(X(:,2)), max(X(:,2)), 100);
    x2_line = -(w_opt(1) + w_opt(2)*x1_line) / w_opt(3);
    plot(x1_line, x2_line, 'k-', 'LineWidth', 3, 'DisplayName', 'Decision boundary');
    
    hold off;
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Logistic Regression', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    axis equal;
    
    % Loss convergence
    subplot(1, 2, 2);
    semilogy(0:length(loss_hist)-1, loss_hist, 'b-', 'LineWidth', 2);
    grid on;
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Cross-entropy loss', 'Interpreter', 'latex', 'FontSize', 12);
    title('Training Convergence', 'Interpreter', 'latex', 'FontSize', 14);
    
    fprintf('Logistic regression:\n');
    fprintf('  • Convex optimisation problem (global optimum!)\n');
    fprintf('  • Gradient descent guaranteed to converge\n');
    fprintf('  • Foundation of neural networks\n');
end

% Execute
Problem10_Optimisation();
