%% lst_adv_prob07.m
% Temperature polynomial fitting
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob07
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem07.m
%  Temperature Distribution Modelling Using Polynomial Fitting
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. Experimental Data --
positionData    = [0, 5, 10, 15, 20, 25];  % cm
temperatureData = [100, 87, 72, 59, 48, 40]; % deg C
numDataPoints = numel(positionData);
positionFine = linspace(0, 25, 200);

%% -- 2. Polynomial Fitting (Degrees 1 to 5) --
maxDegree = 5;
rSquaredValues = zeros(maxDegree, 1);
rmseValues     = zeros(maxDegree, 1);
predictions    = zeros(maxDegree, 1);

ssTotal = sum((temperatureData - mean(temperatureData)).^2);

figHandle = figure('Position', [80 80 1200 500]);
subplot(1,2,1);
plot(positionData, temperatureData, 'ko', 'MarkerSize', 10, ...
     'MarkerFaceColor', 'k'); hold on;
lineStyles = {'-', '-', '-.', ':', '-'};
colourMap = lines(maxDegree);

fprintf('-- Polynomial Fit Comparison --\n');
fprintf('%-8s  %-12s  %-12s  %-14s\n', ...
    'Degree', 'R^2', 'RMSE (C)', 'T(12.5) (C)');
fprintf('%s\n', repmat('-', 1, 50));

for degree = 1:maxDegree
    coefficients = polyfit(positionData, temperatureData, degree);
    fittedValues = polyval(coefficients, positionData);
    fineValues   = polyval(coefficients, positionFine);

    ssResidual = sum((temperatureData - fittedValues).^2);
    rSquaredValues(degree) = 1 - ssResidual / ssTotal;
    rmseValues(degree) = sqrt(ssResidual / numDataPoints);
    predictions(degree) = polyval(coefficients, 12.5);

    plot(positionFine, fineValues, ...
         'Color', colourMap(degree, :), ...
         'LineStyle', lineStyles{degree}, ...
         'LineWidth', 1.3);

    fprintf('  %d       %10.6f    %10.6f    %10.4f\n', ...
        degree, rSquaredValues(degree), rmseValues(degree), ...
        predictions(degree));
end

xlabel('Position $x$ (cm)', 'Interpreter', 'latex');
ylabel('Temperature ($^\circ$C)', 'Interpreter', 'latex');
title('Polynomial Fits to Temperature Data', ...
      'Interpreter', 'latex');
legend([{'Data'}, arrayfun(@(d) sprintf('Degree %d', d), ...
    1:maxDegree, 'UniformOutput', false)], ...
    'Interpreter', 'latex', 'Location', 'northeast');
grid on;

subplot(1,2,2);
bar(1:maxDegree, [rSquaredValues, rmseValues]);
xlabel('Polynomial degree', 'Interpreter', 'latex');
ylabel('Metric value', 'Interpreter', 'latex');
title('$R^2$ and RMSE Comparison', 'Interpreter', 'latex');
legend({'$R^2$', 'RMSE ($^\circ$C)'}, ...
       'Interpreter', 'latex');
grid on;

fprintf('\nBest practical model: degree 2 (high R^2, low RMSE, ');
fprintf('minimal overfitting risk)\n');
coeffBest = polyfit(positionData, temperatureData, 2);
fprintf('Prediction at x = 12.5 cm: T = %.4f deg C\n', ...
    polyval(coeffBest, 12.5));

savefig(figHandle, 'Problem07_PolyFitting.fig');
exportgraphics(figHandle, 'Problem07_PolyFitting.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem07_PolyFitting.jpg', ...
               'Resolution', 300);

fprintf('\n-- Problem 7 Complete --\n');
% Computational Complexity:
% polyfit uses QR decomposition of the Vandermonde matrix,
% costing O(n * d^2) for n data points and degree d.  Evaluating
% polyval on m fine-grid points is O(m * d).  Total for 5
% degrees: O(5 * n * d_max^2 + 5 * m * d_max).  With n=6 and
% m=200, cost is negligible.  The primary concern is numerical
% conditioning: the Vandermonde matrix becomes ill-conditioned
% for high degrees, which polyfit mitigates by centring and
% scaling.  Space complexity is O(n * d + m).
