%% chapter_Problems_sol2.m
% Exploratory data analysis for machine learning
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Problems_sol2
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Load and examine the patients dataset
load patients
% Display dataset information
disp('Dataset Variables:');
disp(patients.Properties.VariableNames');
disp('Dataset Size:');
disp(size(patients));
disp('Variable Descriptions:');
disp(patients.Properties.VariableDescriptions');

% Check for missing values
missing_counts = sum(ismissing(patients));
missing_percentage = 100 * missing_counts / height(patients);
missing_info = table(patients.Properties.VariableNames', missing_counts', missing_percentage', ...
'VariableNames', {'Variable', 'MissingCount', 'MissingPercentage'});
disp('Missing Value Analysis:');
disp(missing_info);

% Identify numerical and categorical variables
varTypes = varfun(@class, patients, 'OutputFormat', 'cell');
numVars = patients.Properties.VariableNames(strcmp(varTypes, 'double'));
catVars = patients.Properties.VariableNames(strcmp(varTypes, 'categorical'));

% Handle missing values
% For numerical variables, impute with median
for i = 1:length(numVars)
var = numVars{i};
patients.(var) = fillmissing(patients.(var), 'median');
end

% For categorical variables, impute with mode
for i = 1:length(catVars)
var = catVars{i};
if any(ismissing(patients.(var)))
% Find the mode (most frequent category)
mode_category = mode(patients.(var));
% Replace missing values with mode
patients.(var)(ismissing(patients.(var))) = mode_category;
end
end

% Univariate Analysis - Numerical Variables
figure('Position', [100, 100, 1200, 600]);
num_numVars = length(numVars);
rows = ceil(num_numVars / 3);
for i = 1:num_numVars
subplot(rows, 3, i);
histogram(patients.(numVars{i}), 'Normalization', 'probability');
title(['Distribution of ', numVars{i}]);
xlabel(numVars{i});
ylabel('Probability');
grid on;
end
sgtitle('Distributions of Numerical Variables');

% Basic statistics for numerical variables
numStats = varfun(@(x) [mean(x), median(x), std(x), min(x), max(x)], ...
patients(:, numVars), 'OutputFormat', 'table');
numStats.Properties.RowNames = numVars;
numStats.Properties.VariableNames = {'Mean', 'Median', 'StdDev', 'Min', 'Max'};
disp('Numerical Variable Statistics:');
disp(numStats);

% Univariate Analysis - Categorical Variables
figure('Position', [100, 100, 1200, 600]);
num_catVars = length(catVars);
rows = ceil(num_catVars / 3);
for i = 1:num_catVars
subplot(rows, 3, i);

% Get category counts
cats = categories(patients.(catVars{i}));
counts = countcats(patients.(catVars{i}));

% Create bar chart
bar(categorical(cats), counts);
title(['Distribution of ', catVars{i}]);
xlabel(catVars{i});
ylabel('Count');

% Rotate x-axis labels if there are many categories
if length(cats) > 5
    xtickangle(45);
end
grid on;

end
sgtitle('Distributions of Categorical Variables');

% Correlation analysis for numerical variables
figure('Position', [100, 100, 800, 600]);
corrMatrix = corr(table2array(patients(:, numVars)), 'rows', 'complete');
heatmap(numVars, numVars, corrMatrix, 'Colormap', jet, 'ColorbarVisible', 'on');
title('Correlation Matrix of Numerical Variables');

% Bivariate Analysis - Relationships between key variables
figure('Position', [100, 100, 1000, 800]);

% Scatter plot of Age vs Weight, colored by Gender
subplot(2, 2, 1);
gscatter(patients.Age, patients.Weight, patients.Gender);
title('Age vs Weight by Gender');
xlabel('Age (years)');
ylabel('Weight (kg)');
grid on;

% Boxplot of SystolicBP by Gender
subplot(2, 2, 2);
boxplot(patients.SystolicBP, patients.Gender);
title('Systolic Blood Pressure by Gender');
xlabel('Gender');
ylabel('Systolic BP (mmHg)');
grid on;

% Scatter plot with SystolicBP vs DiastolicBP
subplot(2, 2, 3);
scatter(patients.SystolicBP, patients.DiastolicBP, 25, patients.Age, 'filled');
title('Blood Pressure Relationship Colored by Age');
xlabel('Systolic BP (mmHg)');
ylabel('Diastolic BP (mmHg)');
colorbar;
grid on;

% Stacked bar chart for Smoker by Gender
subplot(2, 2, 4);
smoker_gender = crosstab(patients.Smoker, patients.Gender);
bar(smoker_gender, 'stacked');
title('Smoking Status by Gender');
xticklabels(categories(patients.Smoker));
legend(categories(patients.Gender));
xlabel('Smoker');
ylabel('Count');
grid on;

sgtitle('Bivariate Relationships in Patient Data');

% Prepare data for machine learning - Encode categorical variables
patients_encoded = patients;
for i = 1:length(catVars)
var = catVars{i};
% One-hot encode the categorical variable
dummyVars = dummyvar(patients.(var));
cats = categories(patients.(var));

% Create new binary columns for each category
for j = 1:length(cats)
    newVarName = [var, '_', char(cats{j})];
    % Replace spaces with underscores for valid variable names
    newVarName = strrep(newVarName, ' ', '_');
    patients_encoded.(newVarName) = dummyVars(:, j);
end

% Remove the original categorical variable
patients_encoded.(var) = [];

end

% Display first few rows of encoded dataset
disp('First 5 rows of ML-ready encoded dataset:');
disp(head(patients_encoded, 5));

% Create a comprehensive dashboard with key insights
figure('Position', [100, 100, 1200, 900]);

% 1. Age distribution with gender breakdown
subplot(3, 3, 1);
histogram(patients.Age(patients.Gender == 'Male'), 'BinWidth', 5, 'FaceColor', 'b', 'FaceAlpha', 0.6);
hold on;
histogram(patients.Age(patients.Gender == 'Female'), 'BinWidth', 5, 'FaceColor', 'r', 'FaceAlpha', 0.6);
title('Age Distribution by Gender');
xlabel('Age (years)');
ylabel('Count');
legend('Male', 'Female');
grid on;

% 2. BMI distribution
subplot(3, 3, 2);
% Calculate BMI (weight in kg / height in meters squared)
height_m = patients.Height / 100; % Convert cm to m
bmi = patients.Weight ./ (height_m.^2);
histogram(bmi, 15, 'FaceColor', [0.3, 0.6, 0.3], 'FaceAlpha', 0.7);
title('BMI Distribution');
xlabel('BMI (kg/m)');
ylabel('Count');
grid on;

% 3. Smoker vs Non-smoker ratio
subplot(3, 3, 3);
pie(countcats(patients.Smoker));
title('Smoking Status Distribution');
legend(categories(patients.Smoker), 'Location', 'eastoutside');

% 4. Blood pressure classification
subplot(3, 3, 4);
% Create a blood pressure category variable
bp_category = cell(height(patients), 1);
for i = 1:height(patients)
sys = patients.SystolicBP(i);
dia = patients.DiastolicBP(i);

if sys < 120 && dia < 80
    bp_category{i} = 'Normal';
elseif (sys >= 120 && sys < 130) && dia < 80
    bp_category{i} = 'Elevated';
elseif (sys >= 130 && sys < 140) || (dia >= 80 && dia < 90)
    bp_category{i} = 'Stage 1';
elseif sys >= 140 || dia >= 90
    bp_category{i} = 'Stage 2';
elseif sys >= 180 || dia >= 120
    bp_category{i} = 'Crisis';
else
    bp_category{i} = 'Unknown';
end

end

bp_category = categorical(bp_category);
bp_counts = countcats(bp_category);
bar(bp_category, bp_counts);
title('Blood Pressure Classification');
xlabel('BP Category');
ylabel('Count');
grid on;
xtickangle(45);

% 5. Age vs BP, colored by Gender
subplot(3, 3, 5);
scatter(patients.Age(patients.Gender == 'Male'), patients.SystolicBP(patients.Gender == 'Male'), 25, 'blue', 'filled', 'o');
hold on;
scatter(patients.Age(patients.Gender == 'Female'), patients.SystolicBP(patients.Gender == 'Female'), 25, 'red', 'filled', 'd');
title('Age vs Systolic BP by Gender');
xlabel('Age (years)');
ylabel('Systolic BP (mmHg)');
legend('Male', 'Female');
grid on;

% 6. Correlation heatmap of key variables
subplot(3, 3, 6);
key_vars = {'Age', 'Weight', 'Height', 'SystolicBP', 'DiastolicBP'};
key_corr = corr(table2array(patients(:, key_vars)));
heatmap(key_vars, key_vars, key_corr, 'Colormap', jet);
title('Correlation of Key Variables');

% 7. Weight distribution by gender
subplot(3, 3, 7);
boxplot(patients.Weight, patients.Gender);
title('Weight Distribution by Gender');
xlabel('Gender');
ylabel('Weight (kg)');
grid on;

% 8. Smoker status by gender
subplot(3, 3, 8);
gender_cat = categories(patients.Gender);
smoker_cat = categories(patients.Smoker);
smoker_gender_counts = zeros(length(smoker_cat), length(gender_cat));

for i = 1:length(smoker_cat)
for j = 1:length(gender_cat)
smoker_gender_counts(i,j) = sum(patients.Smoker == smoker_cat{i} & patients.Gender == gender_cat{j});
end
end

bar(categorical(smoker_cat), smoker_gender_counts, 'stacked');
title('Smoking Status by Gender');
xlabel('Smoker Status');
ylabel('Count');
legend(gender_cat);
grid on;

% 9. Height vs Weight with fitted line
subplot(3, 3, 9);
scatter(patients.Height, patients.Weight, 25, patients.Age, 'filled');
title('Height vs Weight Colored by Age');
xlabel('Height (cm)');
ylabel('Weight (kg)');
colorbar;
grid on;

% Add a linear fit
hold on;
p = polyfit(patients.Height, patients.Weight, 1);
x_fit = linspace(min(patients.Height), max(patients.Height), 100);
y_fit = polyval(p, x_fit);
plot(x_fit, y_fit, 'r-', 'LineWidth', 2);
text(160, 100, sprintf('y = %.2fx + %.2f', p(1), p(2)), 'FontSize', 8);

sgtitle('Comprehensive Patient Data Analysis Dashboard', 'FontSize', 14, 'FontWeight', 'bold');

% Export ML-ready dataset
writetable(patients_encoded, 'patients_ml_ready.csv');
fprintf('ML-ready dataset exported to patients_ml_ready.csv\n');
