%% C020201Maths_Fundamental_code_105.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Continuous wavelet transform
waveletType = 'morse';  % Analytic Morse wavelet
[waveletCoefficients, frequencies] = cwt(signal, samplingFrequency, ...
    'VoicesPerOctave', 48);

% Plot scalogram (wavelet power spectrum)
figure;
surf(time, frequencies, abs(waveletCoefficients).^2, ...
    'EdgeColor', 'none');
view(0, 90);
set(gca, 'YScale', 'log');
ylabel('Frequency (Hz)', 'Interpreter', 'latex');
xlabel('Time (seconds)', 'Interpreter', 'latex');
title('Wavelet Scalogram', 'Interpreter', 'latex');
colorbar;
