%% code_mixed_precision.m
% Mixed precision iterative refinement.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:mixed_precision
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [V_refined, lambda_refined, history] = mixedPrecisionEigenSolver(...
    A, k, V_initial, lambda_initial)
    % Refine eigenvalue approximation using mixed precision
    % Input:
    %   A - Sparse matrix (double precision)
    %   k - Number of eigenvalues
    %   V_initial - Initial eigenvectors (from single precision)
    %   lambda_initial - Initial eigenvalues (from single precision)
    % Output:
    %   V_refined - Refined eigenvectors
    %   lambda_refined - Refined eigenvalues
    %   history - Convergence history
    
    % Refinement parameters
    max_iterations = 10;
    tolerance = 1e-10;
    
    % Initialise
    V_refined = V_initial;
    lambda_refined = lambda_initial;
    history = zeros(max_iterations, k);
    
    fprintf('  Refinement progress:\n');
    
    for iter = 1:max_iterations
        residuals = zeros(k, 1);
        
        % Refine each eigenpair
        for i = 1:k
            v = V_refined(:, i);
            lam = lambda_refined(i);
            
            % Compute residual in double precision
            r = A * v - lam * v;
            residual_norm = norm(r);
            residuals(i) = residual_norm;
            
            % Check convergence
            if residual_norm < tolerance
                continue;
            end
            
            % Solve correction equation (approximate)
            % (A - lambda*I) * delta_v = -r
            % Use few iterations of conjugate gradient
            shift_matrix = A - lam * speye(size(A, 1));
            delta_v = pcg(shift_matrix, -r, 1e-6, 10);
            
            % Update eigenvector
            v_new = v + delta_v;
            v_new = v_new / norm(v_new);  % Renormalise
            
            % Update eigenvalue (Rayleigh quotient)
            lam_new = (v_new' * A * v_new) / (v_new' * v_new);
            
            % Store refined values
            V_refined(:, i) = v_new;
            lambda_refined(i) = lam_new;
        end
        
        % Record history
        history(iter, :) = residuals';
        
        % Display progress
        fprintf('    Iteration %2d: max residual = %.2e\n', ...
            iter, max(residuals));
        
        % Check global convergence
        if max(residuals) < tolerance
            history = history(1:iter, :);
            fprintf('  Converged after %d iterations!\n', iter);
            break;
        end
    end
end
