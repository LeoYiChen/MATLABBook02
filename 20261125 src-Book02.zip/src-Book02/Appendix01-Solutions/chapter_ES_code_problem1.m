%% chapter_ES_code_problem1.m
% Quantum State Tomography Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem1
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem1
    % MATLABBook_ChapterES_Problem1.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Implements quantum state tomography for two-qubit systems using
    %   maximum likelihood estimation from Pauli measurement statistics.
    %   Reconstructs unknown density matrix and validates against known
    %   target state using fidelity and trace distance metrics.
    %
    % Dependencies: Optimisation Toolbox (for fmincon)
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 1
    
    fprintf('\n=== Problem 1: Quantum State Tomography ===\n\n');
    
    % Define true two-qubit state (Bell state |Phi+> = (|00> + |11>)/sqrt(2))
    trueDensityMatrix = createBellState();
    fprintf('True state: Bell state |\\Phi^+\\rangle\n');
    
    % Simulate measurements
    numShots = 1000;
    fprintf('Simulating %d measurement shots per Pauli basis...\n', numShots);
    [pauliOps, measurementCounts] = simulateMeasurements(trueDensityMatrix, numShots);
    
    % Perform maximum likelihood tomography
    fprintf('Performing maximum likelihood estimation...\n');
    reconstructedRho = performTomography(pauliOps, measurementCounts, numShots);
    
    % Compute metrics
    fid = computeFidelity(trueDensityMatrix, reconstructedRho);
    traceDist = computeTraceDistance(trueDensityMatrix, reconstructedRho);
    
    fprintf('\nReconstruction Quality:\n');
    fprintf('  Fidelity: %.6f\n', fid);
    fprintf('  Trace Distance: %.6f\n', traceDist);
    
    % Visualisation
    visualiseResults(trueDensityMatrix, reconstructedRho, pauliOps, measurementCounts, numShots);
    
    fprintf('\nTomography complete. See generated figures.\n');
end

function rho = createBellState()
    % Create Bell state |Phi+> = (|00> + |11>)/sqrt(2)
    psi = zeros(4, 1);
    psi(1) = 1/sqrt(2); % |00>
    psi(4) = 1/sqrt(2); % |11>
    rho = psi * psi'; % Pure state density matrix
end

function [pauliOps, counts] = simulateMeasurements(rho, numShots)
    % Generate 16 two-qubit Pauli operators and simulate measurements
    
    % Single-qubit Pauli matrices
    I = eye(2);
    X = [0 1; 1 0];
    Y = [0 -1i; 1i 0];
    Z = [1 0; 0 -1];
    
    singleQubitPaulis = {I, X, Y, Z};
    pauliNames = {'I', 'X', 'Y', 'Z'};
    
    % Generate two-qubit Paulis via tensor products
    pauliOps = cell(16, 1);
    counts = zeros(16, 2); % [positive outcomes, negative outcomes]
    
    idx = 1;
    for i = 1:4
        for j = 1:4
            pauliOps{idx} = kron(singleQubitPaulis{i}, singleQubitPaulis{j});
            
            % Compute expected value: <P> = Tr(P * rho)
            expectation = real(trace(pauliOps{idx} * rho));
            
            % Probability of +1 outcome: p(+1) = (1 + <P>)/2
            probPlus = (1 + expectation) / 2;
            
            % Simulate measurement outcomes
            outcomes = rand(numShots, 1) < probPlus;
            counts(idx, 1) = sum(outcomes);      % +1 outcomes
            counts(idx, 2) = numShots - counts(idx, 1); % -1 outcomes
            
            idx = idx + 1;
        end
    end
end

function rhoRecon = performTomography(pauliOps, counts, numShots)
    % Maximum likelihood estimation of density matrix
    
    % Parameterise via Cholesky: rho = T*T'/trace(T*T')
    % T is 4x4 lower triangular with complex entries
    % Real params: 4 diagonal (real) + 6*2 lower (complex) = 16 real params
    
    % Initial guess: identity/4 (maximally mixed state)
    T0 = eye(4) / 2;
    params0 = cholToParams(T0);
    
    % Optimisation options
    options = optimoptions('fmincon', 'Display', 'off', ...
                          'MaxFunctionEvaluations', 10000, ...
                          'Algorithm', 'interior-point');
    
    % Objective: negative log-likelihood
    objectiveFcn = @(params) negativeLogLikelihood(params, pauliOps, counts, numShots);
    
    % Optimise (unconstrained as parameterisation ensures physical constraints)
    paramsOpt = fmincon(objectiveFcn, params0, [], [], [], [], [], [], [], options);
    
    % Convert back to density matrix
    T = paramsToChol(paramsOpt);
    rhoRecon = (T * T') / trace(T * T');
end

function nll = negativeLogLikelihood(params, pauliOps, counts, numShots)
    % Compute negative log-likelihood for given parameters
    
    T = paramsToChol(params);
    rho = (T * T') / trace(T * T');
    
    nll = 0;
    for i = 1:length(pauliOps)
        expectation = real(trace(pauliOps{i} * rho));
        probPlus = (1 + expectation) / 2;
        probPlus = max(min(probPlus, 0.9999), 0.0001); % Avoid log(0)
        
        % Binomial log-likelihood
        nll = nll - (counts(i,1)*log(probPlus) + counts(i,2)*log(1-probPlus));
    end
end

function params = cholToParams(T)
    % Convert Cholesky matrix to parameter vector
    params = zeros(16, 1);
    
    % Diagonal elements (real)
    params(1:4) = diag(T);
    
    % Lower triangular elements (complex)
    idx = 5;
    for col = 1:3
        for row = (col+1):4
            params(idx) = real(T(row, col));
            params(idx+1) = imag(T(row, col));
            idx = idx + 2;
        end
    end
end

function T = paramsToChol(params)
    % Convert parameter vector to Cholesky matrix
    T = zeros(4);
    
    % Diagonal (real, positive via abs)
    T(1,1) = abs(params(1));
    T(2,2) = abs(params(2));
    T(3,3) = abs(params(3));
    T(4,4) = abs(params(4));
    
    % Lower triangular (complex)
    idx = 5;
    for col = 1:3
        for row = (col+1):4
            T(row, col) = params(idx) + 1i*params(idx+1);
            idx = idx + 2;
        end
    end
end

function fid = computeFidelity(rho1, rho2)
    % Compute fidelity F(rho1, rho2) = Tr[sqrt(sqrt(rho1)*rho2*sqrt(rho1))]^2
    
    sqrtRho1 = sqrtm(rho1);
    M = sqrtRho1 * rho2 * sqrtRho1;
    fid = real(trace(sqrtm(M)))^2;
end

function dist = computeTraceDistance(rho1, rho2)
    % Compute trace distance D(rho1, rho2) = (1/2)*Tr|rho1 - rho2|
    
    diff = rho1 - rho2;
    dist = 0.5 * sum(abs(eig(diff)));
end

function visualiseResults(rhoTrue, rhoRecon, pauliOps, counts, numShots)
    % Visualise tomography results
    
    figure('Position', [100 100 1400 600]);
    
    % Subplot 1: True density matrix (real part)
    subplot(2,4,1);
    imagesc(real(rhoTrue));
    colorbar;
    title('$\mathrm{Re}(\rho_{\mathrm{true}})$', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Column Index', 'Interpreter', 'latex');
    ylabel('Row Index', 'Interpreter', 'latex');
    axis square;
    
    % Subplot 2: True density matrix (imag part)
    subplot(2,4,2);
    imagesc(imag(rhoTrue));
    colorbar;
    title('$\mathrm{Im}(\rho_{\mathrm{true}})$', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Column Index', 'Interpreter', 'latex');
    ylabel('Row Index', 'Interpreter', 'latex');
    axis square;
    
    % Subplot 3: Reconstructed density matrix (real part)
    subplot(2,4,3);
    imagesc(real(rhoRecon));
    colorbar;
    title('$\mathrm{Re}(\hat{\rho})$', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Column Index', 'Interpreter', 'latex');
    ylabel('Row Index', 'Interpreter', 'latex');
    axis square;
    
    % Subplot 4: Reconstructed density matrix (imag part)
    subplot(2,4,4);
    imagesc(imag(rhoRecon));
    colorbar;
    title('$\mathrm{Im}(\hat{\rho})$', 'Interpreter', 'latex', 'FontSize', 12);
    xlabel('Column Index', 'Interpreter', 'latex');
    ylabel('Row Index', 'Interpreter', 'latex');
    axis square;
    
    % Subplot 5-6: Pauli expectation values comparison
    subplot(2,4,[5 6]);
    expTrue = zeros(16, 1);
    expRecon = zeros(16, 1);
    for i = 1:16
        expTrue(i) = real(trace(pauliOps{i} * rhoTrue));
        expRecon(i) = real(trace(pauliOps{i} * rhoRecon));
    end
    
    x = 1:16;
    bar(x-0.2, expTrue, 0.4, 'FaceColor', [0.2 0.4 0.8]);
    hold on;
    bar(x+0.2, expRecon, 0.4, 'FaceColor', [0.8 0.4 0.2]);
    hold off;
    
    xlabel('Pauli Operator Index', 'Interpreter', 'latex');
    ylabel('Expectation Value', 'Interpreter', 'latex');
    title('Pauli Expectation Values: True vs.\ Reconstructed', 'Interpreter', 'latex', 'FontSize', 12);
    legend({'True', 'Reconstructed'}, 'Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Subplot 7-8: Measurement statistics
    subplot(2,4,[7 8]);
    probsObserved = counts(:,1) / numShots;
    probsExpected = (1 + expTrue) / 2;
    
    plot(1:16, probsExpected, 'o-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', [0.2 0.4 0.8]);
    hold on;
    plot(1:16, probsObserved, 's-', 'LineWidth', 1.5, 'MarkerSize', 6, 'Color', [0.8 0.4 0.2]);
    hold off;
    
    xlabel('Pauli Operator Index', 'Interpreter', 'latex');
    ylabel('Probability of $+1$ Outcome', 'Interpreter', 'latex');
    title('Measurement Probabilities: Expected vs.\ Observed', 'Interpreter', 'latex', 'FontSize', 12);
    legend({'Expected', 'Observed'}, 'Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    sgtitle('Quantum State Tomography Results', 'Interpreter', 'latex', 'FontSize', 14, 'FontWeight', 'bold');
end
