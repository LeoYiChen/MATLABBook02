%% chapter_CFDPrinciples_example_documentation.m
% Simulation documentation and provenance system.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_documentation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function docSystem = createSimulationDocumentation(simulationData, varargin)
    % CREATESIMULATIONDOCUMENTATION Comprehensive CFD simulation documentation
    % Generates reproducible simulation records following best practices
    %
    % Inputs:
    %   simulationData - Struct: all simulation parameters and results
    %   varargin       - Optional: 'OutputFormat', 'JSON'/'XML'/'PDF'
    %
    % Output:
    %   docSystem      - Documentation structure
    %
    % Author: Dr Leo Chen
    % Institution: University of Cambridge
    % Version: 3.0
    
    fprintf('=== Simulation Documentation System ===\n\n');
    
    % Parse optional arguments
    p = inputParser;
    addParameter(p, 'OutputFormat', 'JSON', @ischar);
    addParameter(p, 'OutputPath', './simulation_docs', @ischar);
    addParameter(p, 'IncludeVersionControl', true, @islogical);
    parse(p, varargin{:});
    
    % Initialise documentation structure
    docSystem = struct();
    docSystem.timestamp = datetime('now');
    docSystem.documentVersion = '3.0';
    
    % 1. Simulation metadata
    docSystem.metadata = compileSimulationMetadata(simulationData);
    
    % 2. Computational configuration
    docSystem.configuration = documentComputationalConfiguration(simulationData);
    
    % 3. Physical models
    docSystem.physics = documentPhysicalModels(simulationData);
    
    % 4. Mesh information
    docSystem.mesh = documentMeshDetails(simulationData);
    
    % 5. Boundary conditions
    docSystem.boundaryConditions = documentBoundaryConditions(simulationData);
    
    % 6. Solver settings
    docSystem.solver = documentSolverSettings(simulationData);
    
    % 7. Convergence history
    docSystem.convergence = documentConvergenceHistory(simulationData);
    
    % 8. Results summary
    docSystem.results = documentResultsSummary(simulationData);
    
    % 9. Validation data (if available)
    if isfield(simulationData, 'validation')
        docSystem.validation = simulationData.validation;
    end
    
    % 10. Provenance tracking
    if p.Results.IncludeVersionControl
        docSystem.provenance = trackProvenance(simulationData);
    end
    
    % Export documentation
    exportDocumentation(docSystem, p.Results.OutputFormat, p.Results.OutputPath);
    
    % Generate human-readable report
    generateReadableReport(docSystem, p.Results.OutputPath);
    
    fprintf('Documentation system created successfully.\n');
    fprintf('Output path: %s\n', p.Results.OutputPath);
end

function metadata = compileSimulationMetadata(simData)
    % Compile high-level simulation metadata
    
    metadata = struct();
    
    % Simulation identifiers
    metadata.simulationID = char(java.util.UUID.randomUUID);
    metadata.simulationName = simData.name;
    metadata.analyst = getenv('USER');  % Unix systems
    metadata.institution = 'University of Cambridge';
    metadata.timestamp = datetime('now', 'Format', 'yyyy-MM-dd HH:mm:ss');
    
    % Purpose and objectives
    if isfield(simData, 'objectives')
        metadata.objectives = simData.objectives;
    else
        metadata.objectives = 'Not specified';
    end
    
    % Classification
    metadata.problemType = simData.problemType;  % e.g., 'external aerodynamics'
    metadata.flowRegime = simData.flowRegime;    % e.g., 'turbulent, incompressible'
    
    % Computational platform
    metadata.matlabVersion = version;
    metadata.computerInfo = getComputerInfo();
end

function config = documentComputationalConfiguration(simData)
    % Document computational configuration
    
    config = struct();
    
    config.dimensions = simData.dimensions;  % 2D or 3D
    config.coordinateSystem = simData.coordinateSystem;  % Cartesian, cylindrical, etc.
    
    if isfield(simData, 'parallelisation')
        config.parallelisation = simData.parallelisation;
    end
    
    config.precision = 'double';  % MATLAB default
    config.memoryUsage_GB = simData.memoryUsage;
end

function physics = documentPhysicalModels(simData)
    % Document all physical models employed
    
    physics = struct();
    
    % Fluid dynamics
    physics.fluidModel = simData.fluidModel;  % e.g., 'Navier-Stokes'
    physics.compressibility = simData.compressibility;  % incompressible/compressible
    
    % Turbulence model
    if isfield(simData, 'turbulenceModel')
        physics.turbulence = struct();
        physics.turbulence.model = simData.turbulenceModel.name;
        physics.turbulence.constants = simData.turbulenceModel.constants;
        physics.turbulence.wallTreatment = simData.turbulenceModel.wallTreatment;
    end
    
    % Additional physics
    if isfield(simData, 'heat Transfer') && simData.heatTransfer
        physics.heatTransfer = true;
        physics.thermalModel = simData.thermalModel;
    end
    
    if isfield(simData, 'multiphase') && simData.multiphase
        physics.multiphase = true;
        physics.multiphaseModel = simData.multiphaseModel;
    end
end

function meshDoc = documentMeshDetails(simData)
    % Document mesh generation and characteristics
    
    meshDoc = struct();
    
    meshDoc.type = simData.mesh.type;  % structured, unstructured, hybrid
    meshDoc.elementType = simData.mesh.elementType;  % hex, tet, prism
    meshDoc.numCells = simData.mesh.numCells;
    meshDoc.numFaces = simData.mesh.numFaces;
    meshDoc.numNodes = simData.mesh.numNodes;
    
    % Quality metrics
    if isfield(simData.mesh, 'quality')
        meshDoc.quality = simData.mesh.quality;
    end
    
    % Refinement zones
    if isfield(simData.mesh, 'refinementZones')
        meshDoc.refinementZones = simData.mesh.refinementZones;
    end
    
    % Mesh generation software/procedure
    meshDoc.generator = simData.mesh.generator;
    meshDoc.generationProcedure = simData.mesh.generationProcedure;
end

function bcDoc = documentBoundaryConditions(simData)
    % Document all boundary conditions
    
    bcDoc = struct();
    
    boundaries = fieldnames(simData.boundaryConditions);
    
    for i = 1:length(boundaries)
        bcName = boundaries{i};
        bc = simData.boundaryConditions.(bcName);
        
        bcDoc.(bcName) = bc;
    end
end

function solverDoc = documentSolverSettings(simData)
    % Document numerical solver configuration
    
    solverDoc = struct();
    
    % Discretisation schemes
    solverDoc.discretisation = simData.discretisation;
    
    % Time integration (if transient)
    if isfield(simData, 'timeIntegration')
        solverDoc.timeIntegration = simData.timeIntegration;
    end
    
    % Linear solver
    solverDoc.linearSolver = simData.linearSolver;
    
    % Convergence criteria
    solverDoc.convergenceCriteria = simData.convergenceCriteria;
    
    % Under-relaxation factors
    if isfield(simData, 'underRelaxation')
        solverDoc.underRelaxation = simData.underRelaxation;
    end
end

function convDoc = documentConvergenceHistory(simData)
    % Document convergence behaviour
    
    convDoc = struct();
    
    if isfield(simData, 'residualHistory')
        convDoc.residualHistory = simData.residualHistory;
        convDoc.finalResiduals = structfun(@(x) x(end), simData.residualHistory, ...
                                          'UniformOutput', false);
    end
    
    convDoc.iterations = simData.iterations;
    convDoc.converged = simData.converged;
    convDoc.convergenceTime = simData.convergenceTime;
end

function resultsDoc = documentResultsSummary(simData)
    % Document key results
    
    resultsDoc = struct();
    
    if isfield(simData, 'forces')
        resultsDoc.forces = simData.forces;
    end
    
    if isfield(simData, 'flowStatistics')
        resultsDoc.statistics = simData.flowStatistics;
    end
    
    % Custom outputs
    if isfield(simData, 'customOutputs')
        resultsDoc.customOutputs = simData.customOutputs;
    end
end

function prov = trackProvenance(simData)
    % Track simulation provenance
    
    prov = struct();
    
    prov.sourceFiles = simData.sourceFiles;
    prov.inputFiles = simData.inputFiles;
    prov.preprocessing = simData.preprocessingSteps;
    prov.execution = simData.executionLog;
    prov.postprocessing = simData.postprocessingSteps;
    
    % Git information (if available)
    if exist('.git', 'dir')
        [~, gitCommit] = system('git rev-parse HEAD');
        [~, gitBranch] = system('git branch --show-current');
        
        prov.versionControl = struct();
        prov.versionControl.system = 'git';
        prov.versionControl.commit = strtrim(gitCommit);
        prov.versionControl.branch = strtrim(gitBranch);
    end
end

function exportDocumentation(docSys, format, outputPath)
    % Export documentation in specified format
    
    if ~exist(outputPath, 'dir')
        mkdir(outputPath);
    end
    
    timestamp = datestr(now, 'yyyymmdd_HHMMSS');
    
    switch upper(format)
        case 'JSON'
            filename = fullfile(outputPath, ['simulation_' timestamp '.json']);
            jsonStr = jsonencode(docSys);
            
            fid = fopen(filename, 'w');
            fprintf(fid, '%s', jsonStr);
            fclose(fid);
            
            fprintf('  JSON documentation exported: %s\n', filename);
            
        case 'XML'
            filename = fullfile(outputPath, ['simulation_' timestamp '.xml']);
            struct2xml(docSys, filename);
            
            fprintf('  XML documentation exported: %s\n', filename);
            
        case 'MAT'
            filename = fullfile(outputPath, ['simulation_' timestamp '.mat']);
            save(filename, 'docSys');
            
            fprintf('  MAT documentation exported: %s\n', filename);
            
        otherwise
            warning('Unsupported format: %s', format);
    end
end

function generateReadableReport(docSys, outputPath)
    % Generate human-readable text report
    
    timestamp = datestr(now, 'yyyymmdd_HHMMSS');
    filename = fullfile(outputPath, ['simulation_report_' timestamp '.txt']);
    
    fid = fopen(filename, 'w');
    
    fprintf(fid, '========================================\n');
    fprintf(fid, 'CFD SIMULATION DOCUMENTATION REPORT\n');
    fprintf(fid, '========================================\n\n');
    
    fprintf(fid, 'Generated: %s\n\n', char(docSys.timestamp));
    
    fprintf(fid, 'METADATA:\n');
    fprintf(fid, '  Simulation ID: %s\n', docSys.metadata.simulationID);
    fprintf(fid, '  Name: %s\n', docSys.metadata.simulationName);
    fprintf(fid, '  Analyst: %s\n', docSys.metadata.analyst);
    fprintf(fid, '  Problem type: %s\n', docSys.metadata.problemType);
    fprintf(fid, '  Flow regime: %s\n\n', docSys.metadata.flowRegime);
    
    fprintf(fid, 'MESH:\n');
    fprintf(fid, '  Type: %s\n', docSys.mesh.type);
    fprintf(fid, '  Number of cells: %d\n', docSys.mesh.numCells);
    fprintf(fid, '  Element type: %s\n\n', docSys.mesh.elementType);
    
    fprintf(fid, 'PHYSICAL MODELS:\n');
    fprintf(fid, '  Fluid model: %s\n', docSys.physics.fluidModel);
    
    if isfield(docSys.physics, 'turbulence')
        fprintf(fid, '  Turbulence: %s\n', docSys.physics.turbulence.model);
    end
    
    fprintf(fid, '\n');
    
    fprintf(fid, 'CONVERGENCE:\n');
    fprintf(fid, '  Iterations: %d\n', docSys.convergence.iterations);
    fprintf(fid, '  Converged: %s\n', string(docSys.convergence.converged));
    fprintf(fid, '\n');
    
    if isfield(docSys, 'results') && isfield(docSys.results, 'forces')
        fprintf(fid, 'RESULTS:\n');
        fprintf(fid, '  C_L: %.6f\n', docSys.results.forces.C_L);
        fprintf(fid, '  C_D: %.6f\n', docSys.results.forces.C_D);
        fprintf(fid, '\n');
    end
    
    fprintf(fid, '========================================\n');
    fprintf(fid, 'END OF REPORT\n');
    fprintf(fid, '========================================\n');
    
    fclose(fid);
    
    fprintf('  Text report generated: %s\n', filename);
end

function info = getComputerInfo()
    % Get computer/platform information
    
    info = struct();
    
    if ispc
        info.platform = 'Windows';
    elseif isunix
        info.platform = 'Unix/Linux';
    elseif ismac
        info.platform = 'macOS';
    else
        info.platform = 'Unknown';
    end
    
    info.hostname = getenv('HOSTNAME');
    
    % CPU information
    if ispc
        [~, cpuInfo] = system('wmic cpu get name');
    elseif isunix
        [~, cpuInfo] = system('cat /proc/cpuinfo | grep "model name" | uniq');
    else
        cpuInfo = 'Not available';
    end
    
    info.cpu = strtrim(cpuInfo);
end
