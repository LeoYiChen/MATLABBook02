%% code_memory_analysis.m
% Memory usage analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:memory_analysis
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function analyseMemoryUsage(n, k)
    % Analyse memory requirements for different precision levels
    
    % Bytes per element
    bytes_single = 4;
    bytes_double = 8;
    
    % Memory for eigenvalue solver (approximate)
    % Krylov vectors: k vectors of length n
    mem_vectors_single = k * n * bytes_single;
    mem_vectors_double = k * n * bytes_double;
    
    % Matrix storage (sparse, assume 1% density)
    density = 0.01;
    nnz_estimate = round(density * n^2);
    mem_matrix_single = nnz_estimate * (bytes_single + 8);  % value + indices
    mem_matrix_double = nnz_estimate * (bytes_double + 8);
    
    % Total memory
    total_single = mem_vectors_single + mem_matrix_single;
    total_double = mem_vectors_double + mem_matrix_double;
    total_mixed = mem_vectors_single + mem_matrix_double;  % Approximate
    
    % Convert to MB
    total_single_MB = total_single / 1024^2;
    total_double_MB = total_double / 1024^2;
    total_mixed_MB = total_mixed / 1024^2;
    
    fprintf('Single Precision:  %.2f MB\n', total_single_MB);
    fprintf('Double Precision:  %.2f MB\n', total_double_MB);
    fprintf('Mixed Precision:   %.2f MB\n', total_mixed_MB);
    fprintf('Memory Saving:     %.1f%%\n', ...
        100 * (1 - total_mixed_MB/total_double_MB));
end
