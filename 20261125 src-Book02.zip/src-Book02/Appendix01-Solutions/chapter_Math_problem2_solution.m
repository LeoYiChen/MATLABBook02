%% chapter_Math_problem2_solution.m
% Complete solution for spring work calculation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem2_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem2_SpringWorkCalculation()
    % PROBLEM2_SPRINGWORKCALCULATION Compute work done by non-linear spring
    %
    % This function calculates the work required to compress a non-linear
    % spring from equilibrium to 0.5 m displacement using three numerical
    % integration methods: trapezoidal rule, Simpson's rule, and MATLAB's
    % adaptive quadrature. It compares accuracy, convergence rates, and
    % computational efficiency.
    %
    % Spring force: F(x) = -k1*x - k2*x^3 (Newtons)
    % Work integral: W = integral(|F(x)|, 0, 0.5) (Joules)
    %
    % Author: Dr Yi Chen
    % Date: 2025
    % MATLAB Version: R2023b or later
    
    fprintf('\n=== Problem 2: Work Done by Non-Linear Spring ===\n\n');
    
    % Spring parameters
    k1 = 100;  % Linear stiffness (N/m)
    k2 = 50;   % Cubic stiffness (N/m^3)
    
    % Integration limits
    a = 0;     % Initial position (m)
    b = 0.5;   % Final position (m)
    
    fprintf('Spring Parameters:\n');
    fprintf('  Linear stiffness k1 = %.1f N/m\n', k1);
    fprintf('  Cubic stiffness k2 = %.1f N/m^3\n', k2);
    fprintf('  Force law: F(x) = -%.1f*x - %.1f*x^3 Newtons\n\n', k1, k2);
    
    fprintf('Integration Parameters:\n');
    fprintf('  Lower limit: %.1f m\n', a);
    fprintf('  Upper limit: %.1f m\n', b);
    fprintf('  Interval length: %.1f m\n\n', b-a);
    
    % Define force function (magnitude for work calculation)
    force_magnitude = @(x) k1.*x + k2.*x.^3;
    
    % Compute analytical solution
    W_exact = analyticalSolution(k1, k2, a, b);
    fprintf('Analytical Solution:\n');
    fprintf('  W_exact = %.10f Joules\n\n', W_exact);
    
    % Perform numerical integration with multiple resolutions
    performConvergenceStudy(force_magnitude, a, b, W_exact);
    
    % Compare three methods at specific resolution
    n_compare = 100;  % Number of intervals for comparison
    compareMethodsDetailed(force_magnitude, a, b, W_exact, n_compare, k1, k2);
    
    % Visualize integration methods
    visualizeIntegration(force_magnitude, a, b, k1, k2);
    
    % Physical interpretation
    analysePhysicalBehaviour(k1, k2, a, b, W_exact);
    
    fprintf('\nAnalysis complete!\n');
end

function W_exact = analyticalSolution(k1, k2, a, b)
    % ANALYTICALSOLUTION Compute exact work using antiderivative
    %
    % For F(x) = k1*x + k2*x^3:
    % W = integral(F(x), a, b) = [k1*x^2/2 + k2*x^4/4] from a to b
    
    W_upper = (k1/2)*b^2 + (k2/4)*b^4;
    W_lower = (k1/2)*a^2 + (k2/4)*a^4;
    W_exact = W_upper - W_lower;
    
    fprintf('Analytical Calculation:\n');
    fprintf('  Antiderivative: F(x) = %.1f*x^2/2 + %.1f*x^4/4\n', k1, k2);
    fprintf('  F(%.1f) = %.10f\n', b, W_upper);
    fprintf('  F(%.1f) = %.10f\n', a, W_lower);
    fprintf('  W = F(%.1f) - F(%.1f) = %.10f J\n\n', b, a, W_exact);
    
    % Break down into linear and non-linear components
    W_linear = (k1/2)*(b^2 - a^2);
    W_cubic = (k2/4)*(b^4 - a^4);
    
    fprintf('Component Contributions:\n');
    fprintf('  Linear term (k1*x): %.10f J (%.2f%%)\n', ...
        W_linear, 100*W_linear/W_exact);
    fprintf('  Cubic term (k2*x^3): %.10f J (%.2f%%)\n', ...
        W_cubic, 100*W_cubic/W_exact);
    fprintf('  Total work: %.10f J\n', W_exact);
end

function performConvergenceStudy(f, a, b, W_exact)
    % PERFORMCONVERGENCESTUDY Analyse convergence with increasing resolution
    
    fprintf('\n=== Convergence Study ===\n\n');
    
    % Test range of interval counts
    n_values = [10, 20, 50, 100, 200, 500, 1000, 2000];
    
    % Preallocate result arrays
    n_count = length(n_values);
    W_trap = zeros(n_count, 1);
    W_simp = zeros(n_count, 1);
    err_trap = zeros(n_count, 1);
    err_simp = zeros(n_count, 1);
    time_trap = zeros(n_count, 1);
    time_simp = zeros(n_count, 1);
    
    fprintf('%8s %15s %15s %15s %15s\n', 'n', 'W_trap', 'Err_trap', ...
        'W_simp', 'Err_simp');
    fprintf('%s\n', repmat('-', 1, 75));
    
    for i = 1:n_count
        n = n_values(i);
        
        % Trapezoidal rule
        tic;
        W_trap(i) = trapezoidalRule(f, a, b, n);
        time_trap(i) = toc;
        err_trap(i) = abs(W_trap(i) - W_exact);
        
        % Simpson's rule (ensure even n)
        if mod(n, 2) == 1
            n = n + 1;  % Make even
        end
        tic;
        W_simp(i) = simpsonsRule(f, a, b, n);
        time_simp(i) = toc;
        err_simp(i) = abs(W_simp(i) - W_exact);
        
        fprintf('%8d %15.10f %15.2e %15.10f %15.2e\n', ...
            n_values(i), W_trap(i), err_trap(i), W_simp(i), err_simp(i));
    end
    
    % MATLAB adaptive quadrature
    fprintf('\nMATLAB Adaptive Quadrature:\n');
    tic;
    W_adaptive = integral(f, a, b, 'AbsTol', 1e-12, 'RelTol', 1e-10);
    time_adaptive = toc;
    err_adaptive = abs(W_adaptive - W_exact);
    
    fprintf('  Result: %.12f J\n', W_adaptive);
    fprintf('  Error: %.2e J\n', err_adaptive);
    fprintf('  Time: %.6f seconds\n', time_adaptive);
    
    % Plot convergence
    plotConvergence(n_values, err_trap, err_simp, W_exact);
    
    % Analyse convergence rates
    analyseConvergenceRates(n_values, err_trap, err_simp);
end

function W = trapezoidalRule(f, a, b, n)
    % TRAPEZOIDALRULE Composite trapezoidal rule implementation
    %
    % Formula: W ≈ (h/2)[f(x0) + 2*sum(f(xi)) + f(xn)]
    % where h = (b-a)/n and xi = a + i*h
    
    h = (b - a) / n;
    x = linspace(a, b, n+1);
    y = f(x);
    
    % Composite formula
    W = (h/2) * (y(1) + 2*sum(y(2:end-1)) + y(end));
    
    % Alternative using MATLAB's built-in (produces same result)
    % W = trapz(x, y);
end

function W = simpsonsRule(f, a, b, n)
    % SIMPSONSRULE Composite Simpson's 1/3 rule implementation
    %
    % Requires even n (odd number of points)
    % Formula: W ≈ (h/3)[f(x0) + 4*sum(f(x_odd)) + 2*sum(f(x_even)) + f(xn)]
    
    if mod(n, 2) ~= 0
        error('Simpson''s rule requires even number of intervals');
    end
    
    h = (b - a) / n;
    x = linspace(a, b, n+1);
    y = f(x);
    
    % Separate odd and even indexed interior points
    % Indices: 1, 2, 3, 4, 5, ..., n, n+1
    % Weights: 1, 4, 2, 4, 2, ..., 4, 2, 4, 1
    
    W = (h/3) * (y(1) + y(end) + ...
        4*sum(y(2:2:end-1)) + ...  % Odd indices (2,4,6,...)
        2*sum(y(3:2:end-2)));      % Even indices (3,5,7,...)
end

function plotConvergence(n_values, err_trap, err_simp, W_exact)
    % PLOTCONVERGENCE Visualize error vs. resolution on log-log scale
    
    figure('Position', [100, 100, 1200, 500], 'Name', ...
        'Integration Convergence Analysis');
    
    % Subplot 1: Error vs. n (log-log)
    subplot(1, 2, 1);
    loglog(n_values, err_trap, 'ro-', 'LineWidth', 2, 'MarkerSize', 8, ...
        'MarkerFaceColor', 'r', 'DisplayName', 'Trapezoidal $O(h^2)$');
    hold on;
    loglog(n_values, err_simp, 'bs-', 'LineWidth', 2, 'MarkerSize', 8, ...
        'MarkerFaceColor', 'b', 'DisplayName', 'Simpson $O(h^4)$');
    
    % Add reference slopes
    n_ref = n_values(1);
    err_ref_trap = err_trap(1);
    err_ref_simp = err_simp(1);
    
    slope_2 = err_ref_trap * (n_values / n_ref).^(-2);
    slope_4 = err_ref_simp * (n_values / n_ref).^(-4);
    
    loglog(n_values, slope_2, 'r-', 'LineWidth', 1.5, ...
        'DisplayName', 'Slope $= -2$');
    loglog(n_values, slope_4, 'b-', 'LineWidth', 1.5, ...
        'DisplayName', 'Slope $= -4$');
    
    xlabel('$n$ (number of intervals)', 'Interpreter', 'latex', 'FontSize', 13);
    ylabel('Absolute Error (J)', 'Interpreter', 'latex', 'FontSize', 13);
    title('Convergence Comparison', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'southwest', 'FontSize', 11);
    grid on;
    
    % Subplot 2: Relative error
    subplot(1, 2, 2);
    rel_err_trap = err_trap / W_exact;
    rel_err_simp = err_simp / W_exact;
    
    semilogy(n_values, rel_err_trap, 'ro-', 'LineWidth', 2, 'MarkerSize', 8, ...
        'MarkerFaceColor', 'r', 'DisplayName', 'Trapezoidal');
    hold on;
    semilogy(n_values, rel_err_simp, 'bs-', 'LineWidth', 2, 'MarkerSize', 8, ...
        'MarkerFaceColor', 'b', 'DisplayName', 'Simpson');
    
    % Mark common accuracy thresholds
    yline(1e-2, 'k-', '1\% error', 'LineWidth', 1.5, ...
        'LabelHorizontalAlignment', 'left');
    yline(1e-4, 'k-', '0.01\% error', 'LineWidth', 1.5, ...
        'LabelHorizontalAlignment', 'left');
    yline(1e-6, 'k-', '1 ppm', 'LineWidth', 1.5, ...
        'LabelHorizontalAlignment', 'left');
    
    xlabel('$n$ (number of intervals)', 'Interpreter', 'latex', 'FontSize', 13);
    ylabel('Relative Error', 'Interpreter', 'latex', 'FontSize', 13);
    title('Relative Error Comparison', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Interpreter', 'latex', 'Location', 'southwest', 'FontSize', 11);
    grid on;
    ylim([1e-12, 1e0]);
end

function analyseConvergenceRates(n_values, err_trap, err_simp)
    % ANALYSECONVERGENCERATES Compute empirical convergence rates
    
    fprintf('\n=== Convergence Rate Analysis ===\n\n');
    
    % Fit power law: error = C * n^(-p)
    % Taking log: log(error) = log(C) - p*log(n)
    
    log_n = log10(n_values);
    log_err_trap = log10(err_trap);
    log_err_simp = log10(err_simp);
    
    % Linear regression
    p_trap = polyfit(log_n, log_err_trap, 1);
    p_simp = polyfit(log_n, log_err_simp, 1);
    
    fprintf('Empirical Convergence Rates:\n');
    fprintf('  Trapezoidal: error ~ n^(%.3f)  [Expected: n^(-2)]\n', p_trap(1));
    fprintf('  Simpson:     error ~ n^(%.3f)  [Expected: n^(-4)]\n\n', p_simp(1));
    
    % Calculate efficiency: accuracy per function evaluation
    fprintf('Efficiency Analysis (for 6-digit accuracy):\n');
    
    target_error = 1e-6;
    
    % Find n required for target error (linear interpolation in log space)
    n_trap_required = interp1(log_err_trap, n_values, log10(target_error), ...
        'linear', 'extrap');
    n_simp_required = interp1(log_err_simp, n_values, log10(target_error), ...
        'linear', 'extrap');
    
    fprintf('  Trapezoidal requires n ≈ %.0f  (%.0f function evaluations)\n', ...
        n_trap_required, n_trap_required+1);
    fprintf('  Simpson requires n ≈ %.0f  (%.0f function evaluations)\n', ...
        n_simp_required, n_simp_required+1);
    fprintf('  Efficiency ratio: %.1f:1 (Simpson is %.1fx more efficient)\n', ...
        n_trap_required/n_simp_required, n_trap_required/n_simp_required);
end

function compareMethodsDetailed(f, a, b, W_exact, n, k1, k2)
    % COMPAREMETHODSDETAILED Side-by-side comparison at specific resolution
    
    fprintf('\n=== Detailed Method Comparison (n = %d) ===\n\n', n);
    
    % Ensure n is even for Simpson's
    if mod(n, 2) == 1
        n = n + 1;
    end
    
    % Compute using all three methods
    fprintf('Computing work using three methods...\n\n');
    
    % Method 1: Trapezoidal
    tic;
    W_trap = trapezoidalRule(f, a, b, n);
    t_trap = toc;
    err_trap = abs(W_trap - W_exact);
    rel_err_trap = err_trap / W_exact;
    
    % Method 2: Simpson's
    tic;
    W_simp = simpsonsRule(f, a, b, n);
    t_simp = toc;
    err_simp = abs(W_simp - W_exact);
    rel_err_simp = err_simp / W_exact;
    
    % Method 3: MATLAB adaptive
    tic;
    W_matlab = integral(f, a, b);
    t_matlab = toc;
    err_matlab = abs(W_matlab - W_exact);
    rel_err_matlab = err_matlab / W_exact;
    
    % Display results
    fprintf('Results Summary:\n');
    fprintf('%s\n', repmat('=', 1, 80));
    fprintf('%-20s %15s %15s %15s %12s\n', 'Method', 'Work (J)', ...
        'Abs Error', 'Rel Error', 'Time (s)');
    fprintf('%s\n', repmat('-', 1, 80));
    fprintf('%-20s %15.10f %15.2e %15.2e %12.6f\n', 'Analytical', ...
        W_exact, 0, 0, 0);
    fprintf('%-20s %15.10f %15.2e %15.2e %12.6f\n', 'Trapezoidal', ...
        W_trap, err_trap, rel_err_trap, t_trap);
    fprintf('%-20s %15.10f %15.2e %15.2e %12.6f\n', 'Simpson', ...
        W_simp, err_simp, rel_err_simp, t_simp);
    fprintf('%-20s %15.10f %15.2e %15.2e %12.6f\n', 'MATLAB integral()', ...
        W_matlab, err_matlab, rel_err_matlab, t_matlab);
    fprintf('%s\n', repmat('=', 1, 80));
    
    % Additional statistics
    fprintf('\nAccuracy Comparison:\n');
    fprintf('  Simpson is %.1fx more accurate than Trapezoidal\n', ...
        err_trap/err_simp);
    fprintf('  MATLAB is %.1fx more accurate than Simpson\n', ...
        err_simp/err_matlab);
    
    fprintf('\nComputational Cost:\n');
    fprintf('  Function evaluations: %d (both Trap. and Simpson)\n', n+1);
    fprintf('  MATLAB uses adaptive subdivision (typically fewer evaluations)\n');
end

function visualizeIntegration(f, a, b, k1, k2)
    % VISUALIZEINTEGRATION Create geometric representation of integration
    
    figure('Position', [200, 200, 1400, 900], 'Name', ...
        'Integration Method Visualization');
    
    % Generate fine grid for smooth plotting
    x_fine = linspace(a, b, 500);
    y_fine = f(x_fine);
    
    % Coarse grids for numerical methods
    n_visual = 10;  % Use few intervals for clarity
    x_trap = linspace(a, b, n_visual+1);
    y_trap = f(x_trap);
    
    % Subplot 1: Force vs displacement with integration area
    subplot(3, 3, 1);
    plot(x_fine, y_fine, 'b-', 'LineWidth', 2.5);
    hold on;
    area(x_fine, y_fine, 'FaceColor', [0.7, 0.9, 1], 'FaceAlpha', 0.5, ...
        'EdgeColor', 'none');
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|F(x)|$ (N)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Force vs Displacement', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    text(0.25, max(y_fine)*0.5, ...
        sprintf('Work = $\\int_0^{0.5} |F(x)| dx$'), ...
        'Interpreter', 'latex', 'FontSize', 12, 'HorizontalAlignment', 'center');
    
    % Subplot 2: Trapezoidal approximation
    subplot(3, 3, 2);
    plot(x_fine, y_fine, 'b-', 'LineWidth', 2);
    hold on;
    
    % Draw trapezoids
    for i = 1:n_visual
        x_trap_i = [x_trap(i), x_trap(i+1), x_trap(i+1), x_trap(i)];
        y_trap_i = [0, 0, y_trap(i+1), y_trap(i)];
        fill(x_trap_i, y_trap_i, 'r', 'FaceAlpha', 0.3, 'EdgeColor', 'r', ...
            'LineWidth', 1.5);
    end
    
    plot(x_trap, y_trap, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|F(x)|$ (N)', 'Interpreter', 'latex', 'FontSize', 12);
    title(sprintf('Trapezoidal Rule ($n=%d$)', n_visual), 'Interpreter', ...
        'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 3: Simpson's rule with parabolic segments
    subplot(3, 3, 3);
    plot(x_fine, y_fine, 'b-', 'LineWidth', 2);
    hold on;
    
    % Draw parabolic segments (for pairs of intervals)
    for i = 1:2:n_visual-1
        x_seg = x_trap(i:i+2);
        y_seg = y_trap(i:i+2);
        
        % Fit parabola through three points
        x_seg_fine = linspace(x_seg(1), x_seg(3), 50);
        p = polyfit(x_seg, y_seg, 2);
        y_seg_fine = polyval(p, x_seg_fine);
        
        % Fill area under parabola
        area(x_seg_fine, y_seg_fine, 'FaceColor', 'g', 'FaceAlpha', 0.3, ...
            'EdgeColor', 'g', 'LineWidth', 1.5);
    end
    
    plot(x_trap, y_trap, 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g');
    
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|F(x)|$ (N)', 'Interpreter', 'latex', 'FontSize', 12);
    title(sprintf('Simpson''s Rule ($n=%d$)', n_visual), 'Interpreter', ...
        'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 4: Linear vs non-linear spring comparison
    subplot(3, 3, 4);
    F_linear = k1 * x_fine;
    F_nonlinear = k1 * x_fine + k2 * x_fine.^3;
    
    plot(x_fine, F_linear, 'b-', 'LineWidth', 2, ...
        'DisplayName', 'Linear: $F = k_1 x$');
    hold on;
    plot(x_fine, F_nonlinear, 'r-', 'LineWidth', 2, ...
        'DisplayName', 'Non-linear: $F = k_1 x + k_2 x^3$');
    
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$|F(x)|$ (N)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Linear vs Non-Linear Comparison', 'Interpreter', 'latex', ...
        'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 10);
    grid on;
    
    % Subplot 5: Percent difference from linear
    subplot(3, 3, 5);
    percent_diff = 100 * (F_nonlinear - F_linear) ./ F_linear;
    plot(x_fine, percent_diff, 'k-', 'LineWidth', 2);
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Deviation from Linear (\%)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Non-Linearity Quantification', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    yline(10, 'r-', '10\% threshold', 'LineWidth', 1.5);
    
    % Find where deviation exceeds 10%
    idx_10 = find(percent_diff >= 10, 1);
    if ~isempty(idx_10)
        x_10 = x_fine(idx_10);
        hold on;
        plot(x_10, 10, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
        text(x_10, 15, sprintf('$x = %.3f$ m', x_10), 'Interpreter', 'latex', ...
            'FontSize', 10);
    end
    
    % Subplot 6: Spring stiffness (dF/dx)
    subplot(3, 3, 6);
    k_eff = k1 + 3*k2*x_fine.^2;  % Effective stiffness = dF/dx
    plot(x_fine, k_eff, 'm-', 'LineWidth', 2);
    hold on;
    yline(k1, 'b-', sprintf('$k_1 = %.0f$ N/m', k1), 'LineWidth', 1.5, ...
        'Interpreter', 'latex');
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$k_{\\rm eff}(x) = dF/dx$ (N/m)', 'Interpreter', 'latex', ...
        'FontSize', 12);
    title('Effective Spring Stiffness', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 7: Energy stored vs displacement
    subplot(3, 3, 7);
    W_linear = 0.5 * k1 * x_fine.^2;
    W_nonlinear = 0.5*k1*x_fine.^2 + 0.25*k2*x_fine.^4;
    
    plot(x_fine, W_linear, 'b-', 'LineWidth', 2, 'DisplayName', 'Linear');
    hold on;
    plot(x_fine, W_nonlinear, 'r-', 'LineWidth', 2, 'DisplayName', 'Non-linear');
    
    % Mark evaluation point
    W_eval = 0.5*k1*b^2 + 0.25*k2*b^4;
    plot(b, W_eval, 'ko', 'MarkerSize', 10, 'MarkerFaceColor', 'k');
    text(b, W_eval*1.1, sprintf('%.2f J at $x=%.1f$ m', W_eval, b), ...
        'Interpreter', 'latex', 'FontSize', 10);
    
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$W(x)$ (J)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Energy Stored in Spring', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 10);
    grid on;
    
    % Subplot 8: Error distribution for trapezoidal rule
    subplot(3, 3, 8);
    n_err_test = 50;
    x_err = linspace(a, b, n_err_test+1);
    h_err = (b - a) / n_err_test;
    
    % Second derivative of integrand (for error estimate)
    f_double_prime = @(x) 2*k1 + 6*k2*x;  % d뿯½(k1*x + k2*x뿯½)/dx뿯½ at midpoints
    x_mid = (x_err(1:end-1) + x_err(2:end)) / 2;
    f_pp = f_double_prime(x_mid);
    
    % Local error estimate: -h뿯½/12 * f''(뿯ν)
    local_error = -h_err^3 / 12 * f_pp;
    
    bar(x_mid, abs(local_error), 'FaceColor', [0.8, 0.4, 0.4], ...
        'EdgeColor', 'k');
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Estimated Local Error (J)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Trapezoidal Rule Error Distribution', 'Interpreter', 'latex', ...
        'FontSize', 13);
    grid on;
    
    % Subplot 9: Summary table
    subplot(3, 3, 9);
    axis off;
    
    % Create summary text
    W_exact_calc = 0.5*k1*b^2 + 0.25*k2*b^4;
    F_max = k1*b + k2*b^3;
    k_eff_max = k1 + 3*k2*b^2;
    
    str = {'\textbf{Summary Statistics}', '', ...
        sprintf('Spring Parameters:'), ...
        sprintf('  $k_1 = %.0f$ N/m', k1), ...
        sprintf('  $k_2 = %.0f$ N/m$^3$', k2), '', ...
        sprintf('At $x = %.1f$ m:', b), ...
        sprintf('  Force: $%.2f$ N', F_max), ...
        sprintf('  Work: $%.3f$ J', W_exact_calc), ...
        sprintf('  $k_{\\rm eff}$: $%.1f$ N/m', k_eff_max), '', ...
        'Linear contribution: 94.1\%', ...
        'Cubic contribution: 5.9\%'};
    
    text(0.1, 0.9, str, 'Interpreter', 'latex', 'FontSize', 11, ...
        'VerticalAlignment', 'top');
end

function analysePhysicalBehaviour(k1, k2, a, b, W_exact)
    % ANALYSEPHYSICALBEHAVIOUR Detailed physical interpretation
    
    fprintf('\n=== Physical Interpretation ===\n\n');
    
    % Component contributions
    W_linear = (k1/2) * (b^2 - a^2);
    W_cubic = (k2/4) * (b^4 - a^4);
    
    fprintf('Energy Contributions:\n');
    fprintf('  Linear component: %.6f J (%.2f%%)\n', W_linear, ...
        100*W_linear/W_exact);
    fprintf('  Cubic component: %.6f J (%.2f%%)\n', W_cubic, ...
        100*W_cubic/W_exact);
    fprintf('  Total work: %.6f J\n\n', W_exact);
    
    % Force analysis at displacement b
    F_linear = k1 * b;
    F_cubic_contrib = k2 * b^3;
    F_total = F_linear + F_cubic_contrib;
    
    fprintf('Force Analysis at x = %.1f m:\n', b);
    fprintf('  Linear force: %.2f N (%.1f%%)\n', F_linear, ...
        100*F_linear/F_total);
    fprintf('  Cubic contribution: %.2f N (%.1f%%)\n', F_cubic_contrib, ...
        100*F_cubic_contrib/F_total);
    fprintf('  Total force: %.2f N\n\n', F_total);
    
    % Effective stiffness
    k_eff = k1 + 3*k2*b^2;
    fprintf('Effective Stiffness:\n');
    fprintf('  k_eff(x=0) = %.1f N/m\n', k1);
    fprintf('  k_eff(x=%.1f) = %.1f N/m\n', b, k_eff);
    fprintf('  Stiffness increase: %.1f%% (spring hardens)\n\n', ...
        100*(k_eff-k1)/k1);
    
    % Crossover analysis
    x_crossover = sqrt(k1/k2);
    fprintf('Non-Linearity Analysis:\n');
    fprintf('  Cubic term equals linear term at x = %.3f m\n', x_crossover);
    fprintf('  For x < %.3f m: linear behaviour dominates\n', x_crossover);
    fprintf('  For x > %.3f m: non-linear effects significant\n\n', x_crossover);
    
    % Maximum compression for 10% error in linear approximation
    % Solve: k2*x뿯½/(k1*x) = 0.1
    x_10pct = (0.1 * k1 / k2)^(1/2);
    fprintf('Validity of Linear Approximation:\n');
    fprintf('  10%% error threshold at x = %.3f m\n', x_10pct);
    fprintf('  Current compression (%.1f m) has %.1f%% non-linear contribution\n', ...
        b, 100*W_cubic/W_linear);
    
    if b > x_10pct
        fprintf('  WARNING: Non-linear effects exceed 10%% - linear model invalid!\n');
    else
        fprintf('  Linear approximation acceptable (< 10%% error)\n');
    end
end

% Execute problem solution
Problem2_SpringWorkCalculation();
