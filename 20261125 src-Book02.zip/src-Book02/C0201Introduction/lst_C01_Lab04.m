%% lst_C01_Lab04.m
% Reproducible research practices implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : lst:C01_Lab04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab04.m
% Demonstrates best practices for reproducible research in MATLAB
% Topics: Environment documentation, controlled experiments, multi-format saving
% Author: [Your Name]
% Date: [Date]

%% Initialize
clear; clc; close all;

fprintf('=== Reproducible Research Framework ===\n');
fprintf('Initializing reproducible research environment...\n\n');

%% Part 1: Setting up Reproducible Environment
fprintf('=== Part 1: Environment Setup ===\n');

% Set a fixed random seed for reproducibility
seed_value = 42;
rng(seed_value, 'twister');  % Use Mersenne Twister algorithm
fprintf('Random number generator initialized:\n');
fprintf('  Algorithm: Mersenne Twister\n');
fprintf('  Seed: %d\n', seed_value);

% Verify reproducibility
test_sequence_1 = rand(1, 5);
rng(seed_value, 'twister');  % Reset to same seed
test_sequence_2 = rand(1, 5);
sequences_match = isequal(test_sequence_1, test_sequence_2);
fprintf('  Reproducibility verified: %d\n', sequences_match);

% Record MATLAB version and environment information
matlabVersion = version;
matlabRelease = version('-release');
computerInfo = computer;
dateTimeStamp = datetime('now');

fprintf('\nComputational Environment:\n');
fprintf('  MATLAB Version: %s\n', matlabVersion);
fprintf('  MATLAB Release: %s\n', matlabRelease);
fprintf('  Computer Architecture: %s\n', computerInfo);
fprintf('  Timestamp: %s\n', dateTimeStamp);

% Check and record installed toolboxes
v = ver;
installedToolboxes = {v.Name}';
fprintf('  Installed Toolboxes: %d found\n', length(installedToolboxes));

% Display critical toolboxes
critical_toolboxes = {'Statistics and Machine Learning Toolbox', ...
                      'Optimization Toolbox', ...
                      'Deep Learning Toolbox'};
fprintf('  Critical Toolboxes Status:\n');
for i = 1:length(critical_toolboxes)
    is_installed = any(contains(installedToolboxes, critical_toolboxes{i}));
    status = char(["Not Installed", "Installed"]);
    fprintf('    %s: %s\n', critical_toolboxes{i}, status(is_installed + 1));
end

%% Part 2: Documenting Data Generation and Preprocessing
fprintf('\n=== Part 2: Data Generation and Preprocessing ===\n');

% Define parameters (separating parameters from code improves reproducibility)
params = struct();
params.n_samples = 100;  % Number of observations
params.n_features = 5;   % Number of features
params.noise_level = 0.5;  % Standard deviation of noise
params.correlation_param = 0.7;  % Correlation between features

fprintf('Experimental Parameters:\n');
fprintf('  Number of samples: %d\n', params.n_samples);
fprintf('  Number of features: %d\n', params.n_features);
fprintf('  Noise level: %.2f\n', params.noise_level);
fprintf('  Correlation parameter: %.2f\n', params.correlation_param);

% Create correlation matrix with controlled structure
fprintf('\nGenerating synthetic dataset with controlled correlation structure...\n');
Sigma = eye(params.n_features);
for i = 1:params.n_features
    for j = 1:params.n_features
        if i ~= j
            Sigma(i,j) = params.correlation_param^abs(i-j);
        end
    end
end

fprintf('Correlation matrix structure:\n');
disp(Sigma);

% Generate multivariate normal data
X = mvnrnd(zeros(1, params.n_features), Sigma, params.n_samples);

% Create response variable with known coefficients
beta_true = [1.5; -0.8; 0.6; 0; 0];  % True coefficients (some are zero)
fprintf('True coefficient vector:\n');
for i = 1:params.n_features
    fprintf('  beta_%d = %.2f\n', i, beta_true(i));
end

noise = params.noise_level * randn(params.n_samples, 1);
y = X * beta_true + noise;

% Document preprocessing steps
fprintf('\nPreprocessing Pipeline:\n');
fprintf('1. Standardizing features (zero mean, unit variance)\n');

X_mean = mean(X);
X_std = std(X);
X_standardized = (X - X_mean) ./ X_std;

fprintf('   Feature means before standardization: ');
fprintf('%.4f ', X_mean);
fprintf('\n');
fprintf('   Feature std devs before standardization: ');
fprintf('%.4f ', X_std);
fprintf('\n');

% Verify standardization
X_mean_after = mean(X_standardized);
X_std_after = std(X_standardized);
fprintf('   Feature means after standardization: ');
fprintf('%.2e ', X_mean_after);
fprintf('\n');
fprintf('   Feature std devs after standardization: ');
fprintf('%.4f ', X_std_after);
fprintf('\n');

%% Part 3: Controlled Experiment with Cross-Validation
fprintf('\n=== Part 3: Cross-Validation Experiment ===\n');

k = 5;  % Number of folds
fprintf('Implementing %d-fold cross-validation\n', k);
fprintf('This ensures robust performance estimation\n\n');

% Create cross-validation partition
cv = cvpartition(params.n_samples, 'KFold', k);

% Initialize storage for results
mse_folds = zeros(k, 1);
coefficients_folds = zeros(k, params.n_features);

% Perform cross-validation
fprintf('Cross-Validation Progress:\n');
for fold = 1:k
    % Get training and test indices
    trainIdx = cv.training(fold);
    testIdx = cv.test(fold);
    
    fprintf('Fold %d/%d: Train=%d, Test=%d samples', ...
        fold, k, sum(trainIdx), sum(testIdx));
    
    % Training data
    X_train = X_standardized(trainIdx, :);
    y_train = y(trainIdx);
    
    % Test data
    X_test = X_standardized(testIdx, :);
    y_test = y(testIdx);
    
    % Fit model (using normal equations for simplicity)
    % Adding intercept term
    X_train_aug = [ones(sum(trainIdx), 1), X_train];
    b = (X_train_aug' * X_train_aug) \ (X_train_aug' * y_train);
    
    % Store coefficients (excluding intercept)
    coefficients_folds(fold, :) = b(2:end)';
    
    % Make predictions
    X_test_aug = [ones(sum(testIdx), 1), X_test];
    y_pred = X_test_aug * b;
    
    % Calculate MSE
    mse_folds(fold) = mean((y_test - y_pred).^2);
    
    fprintf(' -> MSE=%.4f\n', mse_folds(fold));
end

% Aggregate results
mean_mse = mean(mse_folds);
std_mse = std(mse_folds);
mean_coefficients = mean(coefficients_folds, 1);
std_coefficients = std(coefficients_folds, 0, 1);

fprintf('\n=== Cross-Validation Results ===\n');
fprintf('Mean MSE: %.4f $\\pm$ %.4f (std)\n', mean_mse, std_mse);
fprintf('Coefficient estimates:\n');
for i = 1:params.n_features
    fprintf('  beta_%d: %.4f $\\pm$ %.4f (True: %.2f, Error: %.4f)\n', ...
        i, mean_coefficients(i), std_coefficients(i), ...
        beta_true(i), abs(mean_coefficients(i) - beta_true(i)));
end

%% Part 4: Visualization with Proper Documentation
fprintf('\n=== Part 4: Result Visualization ===\n');

% Figure 1: Coefficient estimates vs true values
figure('Name', 'Coefficient Estimation Results', 'Position', [100, 100, 800, 500]);

subplot(2, 2, 1);
hold on;
bar(1:params.n_features, beta_true, 'FaceColor', [0.2 0.6 0.2], 'FaceAlpha', 0.6);
bar(1:params.n_features, mean_coefficients, 'FaceColor', [0.8 0.3 0.3], 'FaceAlpha', 0.6);
errorbar(1:params.n_features, mean_coefficients, std_coefficients, '.k', 'LineWidth', 1.5);
xlabel('Feature Index');
ylabel('Coefficient Value');
title('Estimated vs True Coefficients');
legend('True', 'Estimated', 'Std Dev (across folds)', 'Location', 'best');
grid on;
hold off;

% Subplot 2: MSE distribution across folds
subplot(2, 2, 2);
bar(1:k, mse_folds);
hold on;
yline(mean_mse, 'r--', 'LineWidth', 2);
yline(mean_mse + std_mse, 'r:', 'LineWidth', 1);
yline(mean_mse - std_mse, 'r:', 'LineWidth', 1);
xlabel('Fold Number');
ylabel('Mean Squared Error');
title('MSE Distribution Across CV Folds');
legend('Fold MSE', 'Mean MSE', '$pm$1 Std Dev', 'Location', 'best');
grid on;
hold off;

% Subplot 3: Correlation matrix heatmap
subplot(2, 2, 3);
imagesc(Sigma);
colorbar;
colormap('parula');
xlabel('Feature Index');
ylabel('Feature Index');
title('Feature Correlation Matrix');
axis square;

% Subplot 4: Residual analysis for fold 1
subplot(2, 2, 4);
% Recompute predictions for fold 1 for residual plot
trainIdx = cv.training(1);
testIdx = cv.test(1);
X_test = X_standardized(testIdx, :);
y_test = y(testIdx);
X_test_aug = [ones(sum(testIdx), 1), X_test];
b_fold1 = [mean(y(trainIdx)); coefficients_folds(1, :)'];
y_pred_fold1 = X_test_aug * b_fold1;
residuals = y_test - y_pred_fold1;

scatter(y_pred_fold1, residuals, 'filled');
hold on;
yline(0, 'r--', 'LineWidth', 2);
xlabel('Predicted Values');
ylabel('Residuals');
title('Residual Plot (Fold 1)');
grid on;
hold off;

% Add overall figure title
sgtitle('Reproducible Research: Regression Analysis with Cross-Validation');

fprintf('Visualization created with 4 panels:\n');
fprintf('  1. Coefficient estimates with error bars\n');
fprintf('  2. MSE distribution across folds\n');
fprintf('  3. Feature correlation structure\n');
fprintf('  4. Residual analysis\n');

%% Part 5: Saving Results in Multiple Formats
fprintf('\n=== Part 5: Multi-Format Result Archiving ===\n');

% Create comprehensive results structure
results = struct();
results.metadata = struct();
results.metadata.timestamp = char(dateTimeStamp);
results.metadata.matlab_version = matlabVersion;
results.metadata.matlab_release = matlabRelease;
results.metadata.computer = computerInfo;
results.metadata.installed_toolboxes = {installedToolboxes};
results.metadata.random_seed = seed_value;

results.parameters = params;
results.parameters.true_coefficients = beta_true;
results.parameters.correlation_matrix = Sigma;

results.preprocessing = struct();
results.preprocessing.feature_means_original = X_mean;
results.preprocessing.feature_stds_original = X_std;

results.cross_validation = struct();
results.cross_validation.k_folds = k;
results.cross_validation.mse_per_fold = mse_folds;
results.cross_validation.coefficients_per_fold = coefficients_folds;

results.summary = struct();
results.summary.mean_mse = mean_mse;
results.summary.std_mse = std_mse;
results.summary.mean_coefficients = mean_coefficients;
results.summary.std_coefficients = std_coefficients;
results.summary.coefficient_errors = abs(mean_coefficients - beta_true');

% Format 1: MATLAB .mat file (complete workspace preservation)
save('reproducible_research_results.mat', 'results', 'X', 'y', 'X_standardized');
fprintf('Saved complete results to: reproducible_research_results.mat\n');

% Format 2: CSV files (for easy viewing and external processing)
% Summary statistics
summary_table = table(...
    (1:params.n_features)', ...
    beta_true, ...
    mean_coefficients', ...
    std_coefficients', ...
    abs(mean_coefficients' - beta_true), ...
    'VariableNames', {'Feature', 'True_Coefficient', 'Estimated_Coefficient', ...
                      'Std_Error', 'Absolute_Error'});
writetable(summary_table, 'reproducible_research_summary.csv');
fprintf('Saved summary table to: reproducible_research_summary.csv\n');

% CV results
cv_table = table(...
    (1:k)', ...
    mse_folds, ...
    'VariableNames', {'Fold', 'MSE'});
writetable(cv_table, 'reproducible_research_cv_results.csv');
fprintf('Saved CV results to: reproducible_research_cv_results.csv\n');

% Format 3: JSON (platform-independent, hierarchical)
% Convert datetime to string and arrays to cells for JSON compatibility
results_json = results;
results_json.metadata.timestamp = char(results.metadata.timestamp);

jsonStr = jsonencode(results_json);
fileID = fopen('reproducible_research_results.json', 'w');
fprintf(fileID, '%s', jsonStr);
fclose(fileID);
fprintf('Saved hierarchical results to: reproducible_research_results.json\n');

% Format 4: Plain text report
fileID = fopen('reproducible_research_report.txt', 'w');
fprintf(fileID, '=== Reproducible Research Report ===\n\n');
fprintf(fileID, 'Generated: %s\n', char(dateTimeStamp));
fprintf(fileID, 'MATLAB: %s (%s)\n', matlabVersion, matlabRelease);
fprintf(fileID, 'Computer: %s\n', computerInfo);
fprintf(fileID, 'Random Seed: %d\n\n', seed_value);
fprintf(fileID, 'Experimental Parameters:\n');
fprintf(fileID, '  Samples: %d\n', params.n_samples);
fprintf(fileID, '  Features: %d\n', params.n_features);
fprintf(fileID, '  Noise Level: %.2f\n', params.noise_level);
fprintf(fileID, '  Correlation Parameter: %.2f\n\n', params.correlation_param);
fprintf(fileID, 'Cross-Validation Results:\n');
fprintf(fileID, '  K-Folds: %d\n', k);
fprintf(fileID, '  Mean MSE: %.4f $pm$ %.4f\n\n', mean_mse, std_mse);
fprintf(fileID, 'Coefficient Estimates:\n');
for i = 1:params.n_features
    fprintf(fileID, '  Feature %d: %.4f $pm$ %.4f (True: %.2f, Error: %.4f)\n', ...
        i, mean_coefficients(i), std_coefficients(i), ...
        beta_true(i), abs(mean_coefficients(i) - beta_true(i)));
end
fclose(fileID);
fprintf('Saved text report to: reproducible_research_report.txt\n');

fprintf('\nResults saved in 4 formats:\n');
fprintf('  1. .mat - Full MATLAB workspace (binary, complete)\n');
fprintf('  2. .csv - Summary tables (text, easy viewing)\n');
fprintf('  3. .json - Hierarchical structure (platform-independent)\n');
fprintf('  4. .txt - Human-readable report (documentation)\n');

%% Summary
fprintf('\n=== Reproducibility Best Practices Summary ===\n');
fprintf('This exercise demonstrated essential reproducibility practices:\n\n');
fprintf('1. Random Seed Management:\n');
fprintf('   - Set explicit seed value\n');
fprintf('   - Document RNG algorithm\n');
fprintf('   - Verify reproducibility\n\n');
fprintf('2. Environment Documentation:\n');
fprintf('   - Record MATLAB version and release\n');
fprintf('   - Document installed toolboxes\n');
fprintf('   - Capture timestamp and computer info\n\n');
fprintf('3. Parameter Separation:\n');
fprintf('   - Define parameters in structures\n');
fprintf('   - Separate configuration from code\n');
fprintf('   - Enable easy parameter sweeps\n\n');
fprintf('4. Controlled Experimentation:\n');
fprintf('   - Use cross-validation for robust estimates\n');
fprintf('   - Document all preprocessing steps\n');
fprintf('   - Calculate uncertainty estimates\n\n');
fprintf('5. Multi-Format Archiving:\n');
fprintf('   - Save complete results (.mat)\n');
fprintf('   - Export summaries (CSV)\n');
fprintf('   - Use platform-independent formats (JSON)\n');
fprintf('   - Generate human-readable reports (TXT)\n\n');
fprintf('6. Visualization:\n');
fprintf('   - Create comprehensive multi-panel figures\n');
fprintf('   - Include error bars and confidence intervals\n');
fprintf('   - Document figure contents in code\n\n');

fprintf('Laboratory Exercise 4 completed successfully.\n');
fprintf('All results saved to current directory.\n');
