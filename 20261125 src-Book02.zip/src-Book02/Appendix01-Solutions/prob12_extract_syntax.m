%% prob12_extract_syntax.m
% First digit extraction syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob12_extract_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
firstDigits = floor(abs(data) ./ 10.^floor(log10(abs(data))));
% Chi-squared test
[h, p, chi2stat] = chi2gof(firstDigits, 'Expected', expectedCounts);
