%% chapter_UQ_example_sensitivityAnalysis.m
% Global sensitivity analysis: pick-freeze Sobol' estimators validated on the Ishigami function, then applied to a chemical reactor model alongside local sensitivities and Morris screening.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_UQ_example_sensitivityAnalysis
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Global and local sensitivity analysis
%  Requires: base MATLAB, R2016b or later. No toolboxes required.
%
%  Strategy: validate the estimator against a function with KNOWN indices
%  before trusting it on an engineering model. The Ishigami function is
%  the standard benchmark; its exact Sobol' indices are available in
%  closed form.

clearvars; close all; clc;
rng(7, 'twister');

validateSobolEstimator();
analyseReactorSensitivity();

%% --------- local functions -----------
function validateSobolEstimator()

    fprintf('Stage 1: estimator validation on the Ishigami function\n');
    fprintf('======================================================\n\n');

    coefficientA = 7;
    coefficientB = 0.1;
    ishigami = @(x) sin(x(:,1)) + coefficientA * sin(x(:,2)).^2 + ...
        coefficientB * (x(:,3).^4) .* sin(x(:,1));
    uniformSampler = @(n) -pi + 2*pi*rand(n, 3);

    numBaseSamples = 2^14;
    [firstOrder, totalEffect] = sobolIndicesPickFreeze(ishigami, ...
        uniformSampler, numBaseSamples);

    % Exact indices (Sobol' 2001; see also Saltelli et al. 2008, Sec. 4.6)
    totalVariance = coefficientA^2/8 + coefficientB*pi^4/5 + ...
        coefficientB^2*pi^8/18 + 0.5;
    varianceOne   = 0.5 * (1 + coefficientB*pi^4/5)^2;
    varianceTwo   = coefficientA^2/8;
    varianceOneThree = coefficientB^2 * pi^8 * (1/18 - 1/50);

    exactFirstOrder  = [varianceOne, varianceTwo, 0] / totalVariance;
    exactTotalEffect = [varianceOne + varianceOneThree, varianceTwo, ...
        varianceOneThree] / totalVariance;

    fprintf('Model evaluations used: %d\n\n', numBaseSamples * (3 + 2));
    fprintf('%-8s %10s %10s %10s %10s\n', 'Factor', 'S_i (est)', ...
        'S_i (exact)', 'S_Ti (est)', 'S_Ti (exact)');
    for factorIndex = 1:3
        fprintf('x%-7d %10.4f %10.4f %10.4f %10.4f\n', factorIndex, ...
            firstOrder(factorIndex), exactFirstOrder(factorIndex), ...
            totalEffect(factorIndex), exactTotalEffect(factorIndex));
    end
    fprintf('\nSum of S_i  : %.4f (exact %.4f)\n', sum(firstOrder), ...
        sum(exactFirstOrder));
    fprintf('Sum of S_Ti : %.4f (exact %.4f)\n', sum(totalEffect), ...
        sum(exactTotalEffect));
    fprintf('Interpretation: x3 has S_3 = 0 yet S_T3 = %.3f, so it acts\n', ...
        exactTotalEffect(3));
    fprintf('purely through interaction with x1. A first-order-only\n');
    fprintf('analysis would dismiss x3 entirely, which would be wrong.\n\n');

    visualiseEstimatorValidation(firstOrder, exactFirstOrder, ...
        totalEffect, exactTotalEffect);
end

function [firstOrder, totalEffect] = sobolIndicesPickFreeze(modelFun, ...
    samplerFun, numBaseSamples)
    % Saltelli et al. (2010) first-order and Jansen (1999) total-effect
    % estimators. Cost: numBaseSamples * (numFactors + 2) evaluations.

    matrixA = samplerFun(numBaseSamples);
    matrixB = samplerFun(numBaseSamples);
    responseA = modelFun(matrixA);
    responseB = modelFun(matrixB);
    totalVariance = var([responseA; responseB]);

    numFactors  = size(matrixA, 2);
    firstOrder  = zeros(1, numFactors);
    totalEffect = zeros(1, numFactors);

    for factorIndex = 1:numFactors
        matrixFrozen = matrixA;
        matrixFrozen(:, factorIndex) = matrixB(:, factorIndex);
        responseFrozen = modelFun(matrixFrozen);

        firstOrder(factorIndex) = ...
            mean(responseB .* (responseFrozen - responseA)) / totalVariance;
        totalEffect(factorIndex) = ...
            mean((responseA - responseFrozen).^2) / (2 * totalVariance);
    end
end

function analyseReactorSensitivity()

    fprintf('Stage 2: chemical reactor temperature sensitivity\n');
    fprintf('================================================\n\n');

    % T = T0 + Q*R / (rho*Cp*V)
    factorNames   = {'Q  heat rate', 'R  rate const', 'rho density', ...
                     'Cp heat cap.', 'T0 inlet temp'};
    factorMeans   = [50000, 1.20, 1000, 4200, 300];
    factorStdDev  = [ 5000, 0.15,   50,  200,   5];
    isLognormal   = [true, true, true, true, false];
    reactorVolume = 0.5;

    reactorModel = @(x) x(:,5) + (x(:,1) .* x(:,2)) ./ ...
        (x(:,3) .* x(:,4) * reactorVolume);
    transformFun = @(u) mapUnitToPhysical(u, factorMeans, factorStdDev, ...
        isLognormal);
    samplerFun   = @(n) transformFun(rand(n, numel(factorMeans)));

    % -- Local normalised sensitivities, with an exact identity check --
    temperatureRise = (factorMeans(1) * factorMeans(2)) / ...
        (factorMeans(3) * factorMeans(4) * reactorVolume);
    nominalTemperature = factorMeans(5) + temperatureRise;
    riseFraction = temperatureRise / nominalTemperature;

    localSensitivity = [riseFraction, riseFraction, -riseFraction, ...
        -riseFraction, factorMeans(5) / nominalTemperature];

    fprintf('Nominal temperature: %.2f K (rise = %.2f K)\n\n', ...
        nominalTemperature, temperatureRise);
    fprintf('Local normalised sensitivities (1%% input -> X%% output):\n');
    for factorIndex = 1:numel(factorNames)
        fprintf('  %-14s : %+.4f\n', factorNames{factorIndex}, ...
            localSensitivity(factorIndex));
    end

    % Euler's homogeneous function theorem: T is degree-one homogeneous in
    % (T0, Q) jointly, so S_T0 + S_Q must equal exactly one.
    eulerResidual = localSensitivity(5) + localSensitivity(1) - 1;
    fprintf('\n  Verification, S_T0 + S_Q - 1 = %.3e (must be zero)\n\n', ...
        eulerResidual);

    % -- Global variance-based indices -----------
    numBaseSamples = 2^13;
    [firstOrder, totalEffect] = sobolIndicesPickFreeze(reactorModel, ...
        samplerFun, numBaseSamples);

    fprintf('Variance-based indices (%d evaluations):\n', ...
        numBaseSamples * (numel(factorMeans) + 2));
    fprintf('%-14s %10s %10s %12s\n', 'Factor', 'S_i', 'S_Ti', ...
        'Interaction');
    for factorIndex = 1:numel(factorNames)
        fprintf('%-14s %10.4f %10.4f %12.4f\n', factorNames{factorIndex}, ...
            firstOrder(factorIndex), totalEffect(factorIndex), ...
            totalEffect(factorIndex) - firstOrder(factorIndex));
    end
    fprintf('%-14s %10.4f %10.4f\n', 'SUM', sum(firstOrder), ...
        sum(totalEffect));
    fprintf('Sum of S_i below one confirms genuine interaction structure.\n\n');

    % -- Morris screening in quantile space -----------
    numTrajectories = 60;
    perturbationStep = 2/3;
    [morrisMuStar, morrisSigma] = morrisRadialScreening(reactorModel, ...
        transformFun, numTrajectories, numel(factorMeans), perturbationStep);

    fprintf('Morris screening (%d trajectories, %d evaluations):\n', ...
        numTrajectories, numTrajectories * (numel(factorMeans) + 1));
    fprintf('%-14s %10s %10s   %s\n', 'Factor', 'mu*', 'sigma', ...
        'Classification');
    for factorIndex = 1:numel(factorNames)
        aboveMeanEffect      = morrisMuStar(factorIndex) > mean(morrisMuStar);
        aboveMeanInteraction = morrisSigma(factorIndex) > mean(morrisSigma);
        if aboveMeanEffect && aboveMeanInteraction
            label = 'influential, nonlinear';
        elseif aboveMeanEffect
            label = 'influential, near-linear';
        elseif aboveMeanInteraction
            label = 'interacting only';
        else
            label = 'negligible';
        end
        fprintf('%-14s %10.3f %10.3f   %s\n', factorNames{factorIndex}, ...
            morrisMuStar(factorIndex), morrisSigma(factorIndex), label);
    end
    fprintf('\n');

    % -- Correlation cross-check on an existing sample -------
    sampleMatrix   = samplerFun(20000);
    sampleResponse = reactorModel(sampleMatrix);
    pearsonRho = zeros(1, numel(factorNames));
    for factorIndex = 1:numel(factorNames)
        correlationMatrix = corrcoef(sampleMatrix(:, factorIndex), ...
            sampleResponse);
        pearsonRho(factorIndex) = correlationMatrix(1, 2);
    end

    fprintf('Pearson correlation cross-check:\n');
    fprintf('  %s\n', sprintf('%.3f  ', pearsonRho));
    fprintf('  Squared correlations sum to %.3f, an approximate additive\n', ...
        sum(pearsonRho.^2));
    fprintf('  variance budget that agrees with the Sobol'' first orders.\n\n');

    visualiseReactorSensitivity(factorNames, localSensitivity, ...
        firstOrder, totalEffect, morrisMuStar, morrisSigma, ...
        sampleMatrix, sampleResponse);
end

function physicalMatrix = mapUnitToPhysical(unitMatrix, meanVector, ...
    stdVector, isLognormalFlag)
    % Inverse-CDF transform from the unit hypercube to physical units.
    standardNormal = -sqrt(2) * erfcinv(2 * unitMatrix);
    physicalMatrix = zeros(size(unitMatrix));
    for columnIndex = 1:size(unitMatrix, 2)
        if isLognormalFlag(columnIndex)
            sigmaLog = sqrt(log(1 + (stdVector(columnIndex) / ...
                meanVector(columnIndex))^2));
            muLog = log(meanVector(columnIndex)) - 0.5 * sigmaLog^2;
            physicalMatrix(:, columnIndex) = ...
                exp(muLog + sigmaLog * standardNormal(:, columnIndex));
        else
            physicalMatrix(:, columnIndex) = meanVector(columnIndex) + ...
                stdVector(columnIndex) * standardNormal(:, columnIndex);
        end
    end
end

function [muStar, sigmaEffect] = morrisRadialScreening(modelFun, ...
    transformFun, numTrajectories, numFactors, perturbationStep)
    % Radial one-at-a-time design (Campolongo et al. 2011). Effects are
    % computed in QUANTILE space so that factors with different physical
    % units remain directly comparable.
    elementaryEffects = zeros(numTrajectories, numFactors);
    for trajectoryIndex = 1:numTrajectories
        unitBase     = rand(1, numFactors);
        responseBase = modelFun(transformFun(unitBase));
        for factorIndex = 1:numFactors
            unitPerturbed = unitBase;
            unitPerturbed(factorIndex) = ...
                mod(unitBase(factorIndex) + perturbationStep, 1);
            responsePerturbed = modelFun(transformFun(unitPerturbed));
            elementaryEffects(trajectoryIndex, factorIndex) = ...
                (responsePerturbed - responseBase) / perturbationStep;
        end
    end
    muStar      = mean(abs(elementaryEffects), 1);
    sigmaEffect = std(elementaryEffects, 0, 1);
end

function visualiseEstimatorValidation(firstOrder, exactFirstOrder, ...
    totalEffect, exactTotalEffect)

    figure('Position', [100, 100, 900, 380], 'Name', 'Estimator validation');

    subplot(1, 2, 1);
    bar([firstOrder(:), exactFirstOrder(:)]);
    set(gca, 'XTickLabel', {'x_1', 'x_2', 'x_3'});
    ylabel('First-order index S_i'); title('(a) Ishigami: S_i');
    legend('Pick-freeze estimate', 'Exact', 'Location', 'northeast');
    grid on;

    subplot(1, 2, 2);
    bar([totalEffect(:), exactTotalEffect(:)]);
    set(gca, 'XTickLabel', {'x_1', 'x_2', 'x_3'});
    ylabel('Total-effect index S_{Ti}'); title('(b) Ishigami: S_{Ti}');
    legend('Jansen estimate', 'Exact', 'Location', 'northeast');
    grid on;
end

function visualiseReactorSensitivity(factorNames, localSensitivity, ...
    firstOrder, totalEffect, morrisMuStar, morrisSigma, ...
    sampleMatrix, sampleResponse)

    figure('Position', [100, 100, 1400, 820], 'Name', 'Reactor sensitivity');

    subplot(2, 3, 1);
    barh(localSensitivity);
    set(gca, 'YTick', 1:numel(factorNames), 'YTickLabel', factorNames);
    xlabel('Normalised local sensitivity');
    title('(a) Local sensitivities'); grid on;

    subplot(2, 3, 2);
    bar([firstOrder(:), totalEffect(:)]);
    set(gca, 'XTick', 1:numel(factorNames), 'XTickLabel', ...
        {'Q', 'R', '\rho', 'C_p', 'T_0'});
    ylabel('Sensitivity index');
    title('(b) Variance-based indices');
    legend('S_i', 'S_{Ti}', 'Location', 'northeast'); grid on;

    subplot(2, 3, 3);
    scatter(morrisMuStar, morrisSigma, 90, 'filled'); hold on;
    for factorIndex = 1:numel(factorNames)
        text(morrisMuStar(factorIndex), morrisSigma(factorIndex), ...
            ['  ' factorNames{factorIndex}(1:2)], 'FontSize', 9);
    end
    xline(mean(morrisMuStar), 'k--'); yline(mean(morrisSigma), 'k--');
    xlabel('\mu^* (mean absolute effect)');
    ylabel('\sigma (effect dispersion)');
    title('(c) Morris screening plane'); grid on;

    subplot(2, 3, 4);
    scatter(sampleMatrix(:, 1), sampleResponse, 6, 'filled', ...
        'MarkerFaceAlpha', 0.15);
    xlabel('Heat generation Q [W]'); ylabel('Temperature [K]');
    title('(d) Dominant factor scatter'); grid on;

    subplot(2, 3, 5);
    scatter(sampleMatrix(:, 5), sampleResponse, 6, 'filled', ...
        'MarkerFaceAlpha', 0.15);
    xlabel('Inlet temperature T_0 [K]'); ylabel('Temperature [K]');
    title('(e) Secondary factor scatter'); grid on;

    subplot(2, 3, 6);
    correlationMatrix = corrcoef([sampleMatrix, sampleResponse]);
    imagesc(correlationMatrix); colorbar;
    clim([-1 1]);            % use caxis([-1 1]) on releases before R2022a
    axisLabels = {'Q', 'R', '\rho', 'C_p', 'T_0', 'T'};
    set(gca, 'XTick', 1:6, 'XTickLabel', axisLabels, ...
             'YTick', 1:6, 'YTickLabel', axisLabels);
    title('(f) Correlation structure');
end

% -----------------------
% Computational complexity. The pick-freeze estimators require exactly
% N(k+2) model evaluations for all 2k indices, so cost grows linearly in
% the factor count k and linearly in N, with O(Nk) memory for the sample
% matrices. Morris screening costs r(k+1) evaluations for r trajectories,
% typically two orders of magnitude cheaper, which is why it precedes
% variance-based analysis for expensive models. Estimator standard error
% decays as O(N^{-1/2}); indices near zero need the largest N because
% their relative error is unbounded.
% -----------------------
