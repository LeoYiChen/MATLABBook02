%% chapter_AI_Mechanics_Problem6_transfer_syntax.m
% Transfer learning using ResNet-18 syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem6_transfer_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Load pre-trained ResNet-18
net = resnet18;

% Inspect network architecture
lgraph = layerGraph(net);

% Replace final layers for regression
numClasses = 1;  % Regression (single output)
newLayers = [
    fullyConnectedLayer(numClasses, 'Name', 'fc_new', ...
        'WeightLearnRateFactor', 10, 'BiasLearnRateFactor', 10)
    regressionLayer('Name', 'regression')
];

% Replace classification layers
lgraph = replaceLayer(lgraph, 'fc1000', newLayers(1));
lgraph = replaceLayer(lgraph, 'ClassificationLayer_predictions', newLayers(2));

% Freeze early layers (feature extraction)
layers = lgraph.Layers;
connections = lgraph.Connections;

% Freeze all layers except last 10
for i = 1:(length(layers) - 10)
    if isprop(layers(i), 'WeightLearnRateFactor')
        layers(i).WeightLearnRateFactor = 0;
        layers(i).BiasLearnRateFactor = 0;
    end
end

lgraph = createLgraphUsingConnections(layers, connections);
