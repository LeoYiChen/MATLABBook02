# Appendix02-FAQs - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines |
| Chapter | FAQs |
| Package version | 1.1.0 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P02-20261027` |
| Source chapter file | `P0202main/Appendix02-FAQs/` (included by `P02_20260830.tex`) |
| Code files | 71 |
| Code lines relocated | 8,195 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting`, every code `verbatim`
environment and every `\lstinputlisting` call in the chapter has been removed
from the main body and deposited here. Only the filename, the listing caption
and a reference to this folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `Appendix02-FAQs_code_NNN.m`.
- Code held in a `verbatim` environment receives `Appendix02-FAQs_verbatim_NN.m`.
- Code loaded by `\lstinputlisting` keeps the label of that call, so
  `chapter_CW04_code_runner` becomes `chapter_CW04_code_runner.m`.
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 4.3:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book02/Appendix02-FAQs/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook02
```

Clone or download `src-Book02/` from this repository, or use the Springer
supplementary archive. The same address is printed in the preface of the book.
Keep the `src-Book02/` folder name so that the in-text `src-Book02/Appendix02-FAQs/`
paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `Appendix02-FAQs_code_036.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix02-FAQs_code_037.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix02-FAQs_code_038.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix02-FAQs_code_039.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix02-FAQs_code_040.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix02-FAQs_code_062.m` | `(generated)` | Complete Implementation of the MATLAB Code Simplifier |
| `Appendix02-FAQs_code_067.m` | `(generated)` | Basic Trigonometric Calculations in MATLAB |
| `Appendix02-FAQs_code_068.m` | `(generated)` | Trigonometry-Based Signal Denoising for AI Preprocessing |
| `Appendix02-FAQs_code_069.m` | `(generated)` | Trigonometry-Driven Image Rotation for Computer Vision AI |
| `Appendix02-FAQs_code_070.m` | `(generated)` | Trigonometric Encoding of Cyclic Features for AI Time-Series Forecasting |
| `Appendix02-FAQs_code_071.m` | `(generated)` | Euler’s Formula for Complex-Valued AI Signal Analysis |
| `chapter_CFDPrinciples_example_boundary_conditions.m` | `chapter_CFDPrinciples_example_boundary_conditions` | Physically-consistent boundary condition specification. |
| `chapter_CFDPrinciples_example_conservation_checks.m` | `chapter_CFDPrinciples_example_conservation_checks` | Global conservation verification system. |
| `chapter_CFDPrinciples_example_convergence_monitoring.m` | `chapter_CFDPrinciples_example_convergence_monitoring` | Comprehensive convergence monitoring system. |
| `chapter_CFDPrinciples_example_documentation.m` | `chapter_CFDPrinciples_example_documentation` | Simulation documentation and provenance system. |
| `chapter_CFDPrinciples_example_gci_analysis.m` | `chapter_CFDPrinciples_example_gci_analysis` | Grid Convergence Index calculation and verification. |
| `chapter_CFDPrinciples_example_mesh_quality.m` | `chapter_CFDPrinciples_example_mesh_quality` | Comprehensive mesh quality analysis and reporting. |
| `chapter_CFDPrinciples_example_multiscale.m` | `chapter_CFDPrinciples_example_multiscale` | Multi-scale physics coupling framework. |
| `chapter_CFDPrinciples_example_objective_definition.m` | `chapter_CFDPrinciples_example_objective_definition` | Problem definition and physics regime identification. |
| `chapter_CFDPrinciples_example_postprocessing.m` | `chapter_CFDPrinciples_example_postprocessing` | Intelligent post-processing framework. |
| `chapter_CFDPrinciples_example_resource_management.m` | `chapter_CFDPrinciples_example_resource_management` | Computational resource management utilities. |
| `chapter_CFDPrinciples_example_scheme_selection.m` | `chapter_CFDPrinciples_example_scheme_selection` | Discretisation scheme selection logic. |
| `chapter_CFDPrinciples_example_sensitivity_analysis.m` | `chapter_CFDPrinciples_example_sensitivity_analysis` | Comprehensive sensitivity analysis framework. |
| `chapter_CFDPrinciples_example_turbulence_selection.m` | `chapter_CFDPrinciples_example_turbulence_selection` | Turbulence model selection framework. |
| `chapter_CFDPrinciples_example_validation.m` | `chapter_CFDPrinciples_example_validation` | Systematic validation assessment framework. |
| `chapter_DataVisualisation_advanced.m` | `chapter_DataVisualisation_advanced` | Advanced Customisation |
| `chapter_DataVisualisation_area.m` | `chapter_DataVisualisation_area` | Area Chart Implementation |
| `chapter_DataVisualisation_automated.m` | `chapter_DataVisualisation_automated` | Automated Generation |
| `chapter_DataVisualisation_boxplot.m` | `chapter_DataVisualisation_boxplot` | Box Plot Implementation |
| `chapter_DataVisualisation_choropleth.m` | `chapter_DataVisualisation_choropleth` | Choropleth Map Implementation |
| `chapter_DataVisualisation_confusion.m` | `chapter_DataVisualisation_confusion` | Confusion Matrix Plot |
| `chapter_DataVisualisation_contour.m` | `chapter_DataVisualisation_contour` | Advanced Contour Implementation |
| `chapter_DataVisualisation_density.m` | `chapter_DataVisualisation_density` | Density Plot Implementation |
| `chapter_DataVisualisation_export.m` | `chapter_DataVisualisation_export` | Figure Export Function |
| `chapter_DataVisualisation_histogram.m` | `chapter_DataVisualisation_histogram` | Histogram Implementation |
| `chapter_DataVisualisation_network.m` | `chapter_DataVisualisation_network` | Network Visualization Implementation |
| `chapter_DataVisualisation_network_02.m` | `chapter_DataVisualisation_network` | Network Graph Plot |
| `chapter_DataVisualisation_performance.m` | `chapter_DataVisualisation_performance` | Performance Optimization |
| `chapter_DataVisualisation_phase.m` | `chapter_DataVisualisation_phase` | Phase Portrait Implementation |
| `chapter_DataVisualisation_pubstandards.m` | `chapter_DataVisualisation_pubstandards` | Publication Quality Setup |
| `chapter_DataVisualisation_qq.m` | `chapter_DataVisualisation_qq` | Q-Q Plot Implementation |
| `chapter_DataVisualisation_radar.m` | `chapter_DataVisualisation_radar` | Radar Chart Implementation |
| `chapter_DataVisualisation_roc.m` | `chapter_DataVisualisation_roc` | ROC Curve Implementation |
| `chapter_DataVisualisation_sankey.m` | `chapter_DataVisualisation_sankey` | Sankey Diagram Implementation |
| `chapter_DataVisualisation_setup.m` | `chapter_DataVisualisation_setup` | Basic MATLAB Plotting Setup |
| `chapter_DataVisualisation_spectrogram.m` | `chapter_DataVisualisation_spectrogram` | Spectrogram Implementation |
| `chapter_DataVisualisation_stats.m` | `chapter_DataVisualisation_stats` | Statistical Integration |
| `chapter_DataVisualisation_treemap.m` | `chapter_DataVisualisation_treemap` | Treemap Implementation |
| `chapter_DataVisualisation_venn.m` | `chapter_DataVisualisation_venn` | Venn Diagram Implementation |
| `chapter_DataVisualisation_violin.m` | `chapter_DataVisualisation_violin` | Violin Plot Implementation |
| `chapter_DataVisualisation_waterfall.m` | `chapter_DataVisualisation_waterfall` | Waterfall Chart Implementation |
| `chapter_DataVisualisation_wordcloud.m` | `chapter_DataVisualisation_wordcloud` | Word Cloud Implementation |
| `listing_consistency_validation.m` | `listing_consistency_validation` | Advanced data consistency validation and standardisation framework. |
| `listing_duplicate_detection.m` | `listing_duplicate_detection` | Comprehensive duplicate detection framework with fuzzy matching capabilities. |
| `listing_missing_imputation.m` | `listing_missing_imputation` | Comprehensive missing value imputation framework. |
| `listing_missing_visualisation.m` | `listing_missing_visualisation` | Missing data visualisation toolkit. |
| `listing_normalisation_scaling.m` | `listing_normalisation_scaling` | Advanced feature scaling and normalisation framework with multiple methods. |
| `listing_outlier_detection.m` | `listing_outlier_detection` | Multi-method outlier detection framework with robust statistics. |
| `listing_outlier_visualisation.m` | `listing_outlier_visualisation` | Comprehensive outlier visualisation toolkit. |
| `lst_boolean_mask.m` | `lst:boolean_mask` | Set-Theoretic Filtering via Boolean Masks |
| `lst_conditional_filter.m` | `lst:conditional_filter` | Conditional Filtering via Nested Control Structures |
| `lst_domain_discretisation.m` | `lst:domain_discretisation` | Parametric Space Discretisation |
| `lst_flame_func.m` | `lst:flame_func` | Advanced 3D Flame Simulation Function (British English Parameterisation) |
| `lst_inplace_mod.m` | `lst:inplace_mod` | In-Place Modification Using Logical Indexing |
| `lst_iterative_norm.m` | `lst:iterative_norm` | Iterative Approach for Sum of Squares Computation |
| `lst_mp4_export.m` | `lst:mp4_export` | MP4 Animation Export (British English) |
| `lst_parallel_threshold.m` | `lst:parallel_threshold` | Parallelised Threshold Detection |
| `lst_regression.m` | `lst:regression` | Linear regression example |
| `lst_sequential_threshold.m` | `lst:sequential_threshold` | Sequential Threshold Checking |
| `lst_spline.m` | `lst:spline` | Spline interpolation example |
| `lst_vectorised_norm.m` | `lst:vectorised_norm` | Vectorised Implementation for Optimal Performance |
