%% chapter_ES_code_problem9.m
% Multi-Modal Scientific Visualization
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem9
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem9
    % MATLABBook_ChapterES_Problem9.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Advanced multi-modal scientific visualization combining scalar
    %   fields, vector fields, isosurfaces, streamlines, and volume
    %   rendering for complex scientific datasets.
    %
    % Dependencies: None (base MATLAB)
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 9
    
    fprintf('\n=== Problem 9: Multi-Modal Scientific Visualization ===\n\n');
    
    %% Generate Synthetic Scientific Data
    
    % Create 3D grid
    nx = 50; ny = 50; nz = 50;
    x = linspace(-2, 2, nx);
    y = linspace(-2, 2, ny);
    z = linspace(-2, 2, nz);
    [X, Y, Z] = meshgrid(x, y, z);
    
    fprintf('Grid setup:\n');
    fprintf('  Grid size: %d   %d   %d = %d points\n', nx, ny, nz, nx*ny*nz);
    fprintf('  Domain: [%.1f, %.1f]^3\n\n', x(1), x(end));
    
    % Scalar field: Temperature-like distribution with multiple hot spots
    T = zeros(size(X));
    
    % Hot spot 1: Gaussian centered at (-1, 0, 0)
    r1_sq = (X + 1).^2 + Y.^2 + Z.^2;
    T = T + 100 * exp(-2 * r1_sq);
    
    % Hot spot 2: Gaussian centered at (1, 0, 0)
    r2_sq = (X - 1).^2 + Y.^2 + Z.^2;
    T = T + 80 * exp(-2 * r2_sq);
    
    % Hot spot 3: Elongated along z-axis
    r3_sq = X.^2 + Y.^2 + 0.1 * Z.^2;
    T = T + 50 * exp(-r3_sq);
    
    % Add background gradient and noise
    T = T + 10 + 5 * Z + 2 * randn(size(X));
    
    fprintf('Scalar field (Temperature):\n');
    fprintf('  Min: %.2f, Max: %.2f, Mean: %.2f\n', min(T(:)), max(T(:)), mean(T(:)));
    fprintf('  Std: %.2f\n\n', std(T(:)));
    
    % Vector field: Velocity field with vortex structure
    U = zeros(size(X));
    V = zeros(size(Y));
    W = zeros(size(Z));
    
    % Vortex 1: Rotation around z-axis at (x=-1, y=0)
    R1 = sqrt((X + 1).^2 + Y.^2);
    theta1 = atan2(Y, X + 1);
    strength1 = 2 * exp(-R1.^2);
    U = U - strength1 .* sin(theta1);
    V = V + strength1 .* cos(theta1);
    
    % Vortex 2: Rotation around z-axis at (x=1, y=0)
    R2 = sqrt((X - 1).^2 + Y.^2);
    theta2 = atan2(Y, X - 1);
    strength2 = 2 * exp(-R2.^2);
    U = U + strength2 .* sin(theta2);
    V = V - strength2 .* cos(theta2);
    
    % Vertical component (upward flow in hot regions)
    W = 0.5 * (T - mean(T(:))) / std(T(:));
    
    % Add source-sink pair
    source_strength = 1.0;
    U = U + source_strength * (X + 1.5) ./ (r1_sq + 0.1);
    V = V + source_strength * Y ./ (r1_sq + 0.1);
    W = W + source_strength * Z ./ (r1_sq + 0.1);
    
    U = U - source_strength * (X - 1.5) ./ (r2_sq + 0.1);
    V = V - source_strength * Y ./ (r2_sq + 0.1);
    W = W - source_strength * Z ./ (r2_sq + 0.1);
    
    % Compute vector field magnitude
    V_mag = sqrt(U.^2 + V.^2 + W.^2);
    
    fprintf('Vector field (Velocity):\n');
    fprintf('  Magnitude - Min: %.2f, Max: %.2f, Mean: %.2f\n', ...
            min(V_mag(:)), max(V_mag(:)), mean(V_mag(:)));
    
    % Compute vorticity (curl of velocity)
    [curl_x, curl_y, curl_z] = curl(X, Y, Z, U, V, W);
    vorticity_mag = sqrt(curl_x.^2 + curl_y.^2 + curl_z.^2);
    
    fprintf('  Vorticity - Min: %.2f, Max: %.2f, Mean: %.2f\n\n', ...
            min(vorticity_mag(:)), max(vorticity_mag(:)), mean(vorticity_mag(:)));
    
    % Volumetric data: Density-like scalar (for volume rendering)
    rho = 50 * exp(-0.5 * (X.^2 + Y.^2 + Z.^2)) + 10 * randn(size(X));
    rho = max(rho, 0);  % Non-negative
    
    fprintf('Volumetric data (Density):\n');
    fprintf('  Min: %.2f, Max: %.2f, Mean: %.2f\n\n', ...
            min(rho(:)), max(rho(:)), mean(rho(:)));
    
    %% Method 1: Scalar Field Visualization with Isosurfaces
    
    fprintf('=== Method 1: Scalar Field Visualization ===\n');
    
    % Extract isosurface at multiple levels
    isovalue1 = 40;  % Mid-level
    isovalue2 = 70;  % High level
    
    fprintf('Computing isosurfaces:\n');
    fprintf('  Isovalue 1: %.1f\n', isovalue1);
    fprintf('  Isovalue 2: %.1f\n\n', isovalue2);
    
    % Use isosurface function
    fv1 = isosurface(X, Y, Z, T, isovalue1);
    fv2 = isosurface(X, Y, Z, T, isovalue2);
    
    fprintf('Isosurface 1: %d vertices, %d faces\n', ...
            size(fv1.vertices, 1), size(fv1.faces, 1));
    fprintf('Isosurface 2: %d vertices, %d faces\n\n', ...
            size(fv2.vertices, 1), size(fv2.faces, 1));
    
    %% Method 2: Vector Field Visualization with Streamlines
    
    fprintf('=== Method 2: Vector Field Visualization ===\n');
    
    % Define seed points for streamlines
    num_seeds = 20;
    seed_x = linspace(-1.8, 1.8, num_seeds);
    seed_y = zeros(1, num_seeds);
    seed_z = linspace(-1.5, 1.5, num_seeds);
    
    % Create seed point grid
    [seed_X, seed_Z] = meshgrid(seed_x(1:5:end), seed_z(1:5:end));
    seed_Y = zeros(size(seed_X));
    
    seed_points = [seed_X(:), seed_Y(:), seed_Z(:)];
    
    fprintf('Streamline computation:\n');
    fprintf('  Number of seed points: %d\n', size(seed_points, 1));
    
    % Compute streamlines using stream3
    streamlines = stream3(X, Y, Z, U, V, W, ...
                         seed_points(:,1), seed_points(:,2), seed_points(:,3));
    
    % Remove empty streamlines
    streamlines = streamlines(~cellfun('isempty', streamlines));
    
    fprintf('  Number of streamlines: %d\n', length(streamlines));
    
    % Compute streamline lengths
    stream_lengths = zeros(length(streamlines), 1);
    for i = 1:length(streamlines)
        pts = streamlines{i};
        if size(pts, 1) > 1
            diffs = diff(pts);
            stream_lengths(i) = sum(sqrt(sum(diffs.^2, 2)));
        end
    end
    
    fprintf('  Streamline lengths - Min: %.2f, Max: %.2f, Mean: %.2f\n\n', ...
            min(stream_lengths), max(stream_lengths), mean(stream_lengths));
    
    %% Method 3: Volume Rendering
    
    fprintf('=== Method 3: Volume Rendering ===\n');
    
    % Design transfer function for volume rendering
    % Map density values to opacity
    alpha_map = linspace(0, 1, 256);
    alpha_map = alpha_map.^2;  % Emphasize high values
    
    % Map to color (using custom colormap)
    color_map = parula(256);
    
    fprintf('Transfer function:\n');
    fprintf('  Colormap: parula (perceptually uniform)\n');
    fprintf('  Opacity: quadratic mapping (emphasize high density)\n\n');
    
    %% Method 4: Multi-Modal Fusion
    
    fprintf('=== Method 4: Multi-Modal Fusion ===\n');
    fprintf('Combining multiple visualization techniques:\n');
    fprintf('  - Isosurfaces (scalar field)\n');
    fprintf('  - Streamlines (vector field)\n');
    fprintf('  - Volume rendering (density)\n');
    fprintf('  - Slice planes (cross-sections)\n\n');
    
    %% Visualization
    
    fprintf('Generating visualizations...\n');
    
    % Figure 1: Scalar field visualization
    figure('Position', [50 50 1600 800]);
    
    % Subplot 1: Slice planes with colormap
    subplot(2, 3, 1);
    slice(X, Y, Z, T, 0, 0, 0);
    shading interp;
    colormap(parula);
    colorbar;
    xlabel('X', 'Interpreter', 'latex');
    ylabel('Y', 'Interpreter', 'latex');
    zlabel('Z', 'Interpreter', 'latex');
    title('Temperature Field (Slice Planes)', 'Interpreter', 'latex');
    axis equal tight;
    view(3);
    camlight; lighting gouraud;
    
    % Subplot 2: Isosurfaces
    subplot(2, 3, 2);
    p1 = patch(fv1, 'FaceColor', 'red', 'EdgeColor', 'none', 'FaceAlpha', 0.5);
    hold on;
    p2 = patch(fv2, 'FaceColor', 'yellow', 'EdgeColor', 'none', 'FaceAlpha', 0.7);
    hold off;
    xlabel('X', 'Interpreter', 'latex');
    ylabel('Y', 'Interpreter', 'latex');
    zlabel('Z', 'Interpreter', 'latex');
    title('Isosurfaces', 'Interpreter', 'latex');
    axis equal tight;
    view(3);
    camlight; lighting gouraud;
    legend({sprintf('T = %.0f', isovalue1), sprintf('T = %.0f', isovalue2)}, ...
           'Location', 'northeast', 'Interpreter', 'latex');
    
    % Subplot 3: 3D histogram of temperature
    subplot(2, 3, 3);
    histogram(T(:), 50, 'FaceColor', [0.3 0.6 0.9], 'EdgeColor', 'none');
    xlabel('Temperature', 'Interpreter', 'latex');
    ylabel('Frequency', 'Interpreter', 'latex');
    title('Temperature Distribution', 'Interpreter', 'latex');
    grid on;
    
    % Mark isovalues
    hold on;
    yl = ylim;
    plot([isovalue1 isovalue1], yl, 'r-', 'LineWidth', 2);
    plot([isovalue2 isovalue2], yl, 'y-', 'LineWidth', 2);
    hold off;
    
    % Subplot 4: Vector field - quiver plot on slice
    subplot(2, 3, 4);
    z_slice_idx = round(nz/2);
    quiver_spacing = 3;
    quiver(X(:, :, z_slice_idx), Y(:, :, z_slice_idx), ...
           U(:, :, z_slice_idx), V(:, :, z_slice_idx), ...
           quiver_spacing, 'Color', 'b', 'LineWidth', 1.2);
    hold on;
    contourf(X(:, :, z_slice_idx), Y(:, :, z_slice_idx), ...
             V_mag(:, :, z_slice_idx), 20, 'EdgeColor', 'none');
    hold off;
    colormap(gca, hot);
    colorbar;
    xlabel('X', 'Interpreter', 'latex');
    ylabel('Y', 'Interpreter', 'latex');
    title('Velocity Field (Mid-plane)', 'Interpreter', 'latex');
    axis equal tight;
    
    % Subplot 5: Streamlines
    subplot(2, 3, 5);
    for i = 1:length(streamlines)
        pts = streamlines{i};
        if size(pts, 1) > 1
            % Color by velocity magnitude along streamline
            vel_interp = interp3(X, Y, Z, V_mag, pts(:,1), pts(:,2), pts(:,3));
            patch(pts(:,1), pts(:,2), pts(:,3), vel_interp, ...
                  'EdgeColor', 'interp', 'FaceColor', 'none', 'LineWidth', 2);
        end
    end
    colormap(gca, jet);
    colorbar;
    xlabel('X', 'Interpreter', 'latex');
    ylabel('Y', 'Interpreter', 'latex');
    zlabel('Z', 'Interpreter', 'latex');
    title('Streamlines (Colored by Velocity)', 'Interpreter', 'latex');
    axis equal tight;
    view(3);
    
    % Subplot 6: Vorticity magnitude
    subplot(2, 3, 6);
    slice(X, Y, Z, vorticity_mag, [-1.5 0 1.5], 0, 0);
    shading interp;
    colormap(gca, hot);
    colorbar;
    xlabel('X', 'Interpreter', 'latex');
    ylabel('Y', 'Interpreter', 'latex');
    zlabel('Z', 'Interpreter', 'latex');
    title('Vorticity Magnitude', 'Interpreter', 'latex');
    axis equal tight;
    view(3);
    camlight; lighting gouraud;
    
    sgtitle('Multi-Modal Scalar and Vector Field Visualization', ...
            'Interpreter', 'latex', 'FontSize', 14, 'FontWeight', 'bold');
    
    % Figure 2: Multi-modal fusion
    figure('Position', [100 100 1600 800]);
    
    % Subplot 1: Combined view - isosurface + streamlines
    subplot(1, 2, 1);
    p1 = patch(fv1, 'FaceColor', [1 0.5 0.5], 'EdgeColor', 'none', 'FaceAlpha', 0.3);
    hold on;
    p2 = patch(fv2, 'FaceColor', [1 1 0.5], 'EdgeColor', 'none', 'FaceAlpha', 0.5);
    
    % Plot streamlines
    for i = 1:length(streamlines)
        pts = streamlines{i};
        if size(pts, 1) > 1
            plot3(pts(:,1), pts(:,2), pts(:,3), 'b-', 'LineWidth', 1.5);
        end
    end
    hold off;
    xlabel('X', 'Interpreter', 'latex');
    ylabel('Y', 'Interpreter', 'latex');
    zlabel('Z', 'Interpreter', 'latex');
    title('Combined: Isosurfaces + Streamlines', 'Interpreter', 'latex');
    axis equal tight;
    view([-45 20]);
    camlight; lighting gouraud;
    grid on;
    
    % Subplot 2: Volume rendering simulation (slice-based)
    subplot(1, 2, 2);
    
    % Create multiple semi-transparent slices
    num_slices = 30;
    z_slices = linspace(z(1), z(end), num_slices);
    
    for i = 1:num_slices
        [~, z_idx] = min(abs(z - z_slices(i)));
        
        % Interpolate data on slice
        slice_data = squeeze(rho(:, :, z_idx));
        
        % Normalize for opacity
        alpha_slice = (slice_data - min(rho(:))) / (max(rho(:)) - min(rho(:)));
        alpha_slice = alpha_slice.^2 * 0.3;  % Scale opacity
        
        % Create surface
        surf(X(:, :, z_idx), Y(:, :, z_idx), Z(:, :, z_idx), slice_data, ...
             'FaceAlpha', 'flat', 'AlphaData', alpha_slice, ...
             'EdgeColor', 'none');
        hold on;
    end
    hold off;
    
    colormap(parula);
    colorbar;
    xlabel('X', 'Interpreter', 'latex');
    ylabel('Y', 'Interpreter', 'latex');
    zlabel('Z', 'Interpreter', 'latex');
    title('Volume Rendering (Density)', 'Interpreter', 'latex');
    axis equal tight;
    view(3);
    
    sgtitle('Multi-Modal Fusion Visualization', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    % Figure 3: Colormap comparison
    figure('Position', [150 150 1400 600]);
    
    % Create sample data for colormap comparison
    [Xc, Yc] = meshgrid(linspace(0, 1, 256), linspace(0, 1, 100));
    Zc = Xc;
    
    colormaps = {'parula', 'viridis', 'jet', 'hot'};
    colormap_titles = {'Parula (MATLAB default)', 'Viridis (Perceptually uniform)', ...
                       'Jet (Not recommended)', 'Hot (Sequential)'};
    
    for i = 1:4
        subplot(2, 4, i);
        imagesc(Zc);
        colormap(gca, colormaps{i});
        axis off;
        title(colormap_titles{i}, 'Interpreter', 'latex', 'FontSize', 10);
        
        % Grayscale version (simulates color blindness)
        subplot(2, 4, i+4);
        Zc_gray = rgb2gray(ind2rgb(round(Zc*255)+1, feval(colormaps{i}, 256)));
        imagesc(Zc_gray);
        colormap(gca, gray);
        axis off;
        title('Grayscale (Luminance)', 'Interpreter', 'latex', 'FontSize', 10);
    end
    
    sgtitle('Colormap Comparison and Accessibility', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    %% Analysis and Statistics
    
    fprintf('\n=== Visualization Statistics ===\n');
    
    % Compute divergence of vector field
    [div_U, div_V, div_W] = gradient(U);
    [~, grad_V, ~] = gradient(V);
    [~, ~, grad_W] = gradient(W);
    divergence = div_U + grad_V + grad_W;
    
    fprintf('Vector field topology:\n');
    fprintf('  Divergence - Min: %.2f, Max: %.2f\n', min(divergence(:)), max(divergence(:)));
    fprintf('  Number of source regions (div > 1): %d\n', sum(divergence(:) > 1));
    fprintf('  Number of sink regions (div < -1): %d\n', sum(divergence(:) < -1));
    
    % Compute gradient of scalar field
    [grad_T_x, grad_T_y, grad_T_z] = gradient(T);
    grad_T_mag = sqrt(grad_T_x.^2 + grad_T_y.^2 + grad_T_z.^2);
    
    fprintf('\nScalar field gradients:\n');
    fprintf('  Gradient magnitude - Mean: %.2f, Max: %.2f\n', ...
            mean(grad_T_mag(:)), max(grad_T_mag(:)));
    fprintf('  High gradient regions (>20): %.1f%% of volume\n', ...
            sum(grad_T_mag(:) > 20) / numel(grad_T_mag) * 100);
    
    % Information theory metrics
    % Entropy of temperature field (discretized)
    T_discretized = round((T - min(T(:))) / (max(T(:)) - min(T(:))) * 100);
    [counts, ~] = histcounts(T_discretized, 0:101);
    p_T = counts / sum(counts);
    p_T = p_T(p_T > 0);  % Remove zeros
    entropy_T = -sum(p_T .* log2(p_T));
    
    fprintf('\nInformation content:\n');
    fprintf('  Temperature entropy: %.2f bits\n', entropy_T);
    fprintf('  Max possible entropy: %.2f bits\n', log2(101));
    fprintf('  Relative entropy: %.1f%%\n\n', entropy_T / log2(101) * 100);
    
    fprintf('Visualization completed. Figures generated.\n\n');
end
