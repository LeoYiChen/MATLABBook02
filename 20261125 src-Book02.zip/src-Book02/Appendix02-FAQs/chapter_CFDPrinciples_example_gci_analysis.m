%% chapter_CFDPrinciples_example_gci_analysis.m
% Grid Convergence Index calculation and verification.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_gci_analysis
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function gciResults = performGridIndependenceStudy(solutionData, meshData, ...
    refinementRatio, targetVariable, theoreticalOrder)
    % PERFORMGRIDINDEPENDENCESTUDY Comprehensive GCI analysis
    % Implements Roache's Grid Convergence Index methodology with asymptotic
    % range verification according to ASME V&V 20-2009 standard
    %
    % Inputs:
    %   solutionData      - Struct array with fields: coarse, medium, fine
    %                       Each containing solution variables
    %   meshData          - Struct array with fields: coarse, medium, fine
    %                       Each containing: numCells, characteristicSpacing
    %   refinementRatio   - Scalar or [r_32, r_21] for non-uniform refinement
    %   targetVariable    - String specifying quantity of interest
    %   theoreticalOrder  - Expected order of accuracy (e.g., 2 for 2nd order)
    %
    % Output:
    %   gciResults        - Comprehensive GCI analysis results
    %
    % Author: Dr Leo Chen
    % Institution: University of Cambridge
    % Version: 4.0
    % MATLAB Version: R2023b and later
    %
    % References:
    %   [1] Roache (1998) Verification and Validation in CFD
    %   [2] Celik et al. (2008) ASME J. Fluids Eng. 130(7):078001
    %   [3] ASME V&V 20-2009 Standard for V&V in CFD
    
    fprintf('=== Grid Independence Study ===\n\n');
    
    % Initialise results structure
    gciResults = struct();
    gciResults.timestamp = datetime('now');
    gciResults.targetVariable = targetVariable;
    
    % Extract solution quantities
    phi_1 = extractTargetQuantity(solutionData.fine, targetVariable);
    phi_2 = extractTargetQuantity(solutionData.medium, targetVariable);
    phi_3 = extractTargetQuantity(solutionData.coarse, targetVariable);
    
    gciResults.phi_fine = phi_1;
    gciResults.phi_medium = phi_2;
    gciResults.phi_coarse = phi_3;
    
    % Extract mesh characteristics
    N_1 = meshData.fine.numCells;
    N_2 = meshData.medium.numCells;
    N_3 = meshData.coarse.numCells;
    
    gciResults.N_fine = N_1;
    gciResults.N_medium = N_2;
    gciResults.N_coarse = N_3;
    
    % Calculate refinement ratios
    if isscalar(refinementRatio)
        r_21 = refinementRatio;
        r_32 = refinementRatio;
    else
        r_32 = refinementRatio(1);
        r_21 = refinementRatio(2);
    end
    
    % Verify refinement ratios from mesh data
    r_21_actual = (N_2/N_1)^(1/3);
    r_32_actual = (N_3/N_2)^(1/3);
    
    gciResults.r_21_specified = r_21;
    gciResults.r_32_specified = r_32;
    gciResults.r_21_actual = r_21_actual;
    gciResults.r_32_actual = r_32_actual;
    
    fprintf('Refinement ratios:\n');
    fprintf('  r_21 (medium/fine): %.4f (specified) vs %.4f (actual)\n', ...
            r_21, r_21_actual);
    fprintf('  r_32 (coarse/medium): %.4f (specified) vs %.4f (actual)\n\n', ...
            r_32, r_32_actual);
    
    % Use actual refinement ratios for calculations
    r_21 = r_21_actual;
    r_32 = r_32_actual;
    
    % Calculate relative errors
    epsilon_21 = (phi_2 - phi_1) / phi_1;
    epsilon_32 = (phi_3 - phi_2) / phi_2;
    
    gciResults.epsilon_21 = epsilon_21;
    gciResults.epsilon_32 = epsilon_32;
    
    fprintf('Relative differences:\n');
    fprintf('  epsilon_21 (medium vs fine): %.6f (%.4f%%)\n', ...
            epsilon_21, epsilon_21*100);
    fprintf('  epsilon_32 (coarse vs medium): %.6f (%.4f%%)\n\n', ...
            epsilon_32, epsilon_32*100);
    
    % Calculate observed order of accuracy
    if abs(r_21 - r_32) < 1e-6
        % Uniform refinement ratio - use simplified formula
        if abs(phi_3 - phi_2) > 1e-12 && abs(phi_2 - phi_1) > 1e-12
            p_observed = log(abs((phi_3 - phi_2)/(phi_2 - phi_1))) / log(r_21);
        else
            warning('Solution differences too small for order calculation.');
            p_observed = NaN;
        end
    else
        % Non-uniform refinement - use general formula
        s = sign(phi_3 - phi_2) / sign(phi_2 - phi_1);
        
        % Iterative solution for p using fixed-point iteration
        p_guess = theoreticalOrder;
        for iter = 1:50
            q = log((r_21^p_guess - s)/(r_32^p_guess - s));
            p_new = (1/log(r_21)) * abs(log(abs(epsilon_32/epsilon_21)) + q);
            
            if abs(p_new - p_guess) < 1e-6
                break;
            end
            p_guess = p_new;
        end
        p_observed = p_new;
    end
    
    gciResults.p_observed = p_observed;
    gciResults.p_theoretical = theoreticalOrder;
    
    fprintf('Order of accuracy:\n');
    fprintf('  Theoretical: %.2f\n', theoreticalOrder);
    fprintf('  Observed: %.4f\n\n', p_observed);
    
    % Calculate extrapolated value (Richardson extrapolation)
    if ~isnan(p_observed) && p_observed > 0
        phi_ext = (r_21^p_observed * phi_1 - phi_2) / (r_21^p_observed - 1);
        gciResults.phi_extrapolated = phi_ext;
        
        fprintf('Richardson extrapolation:\n');
        fprintf('  Extrapolated value: %.8f\n', phi_ext);
        fprintf('  Fine grid value: %.8f\n', phi_1);
        fprintf('  Difference: %.4e (%.4f%%)\n\n', ...
                abs(phi_ext - phi_1), abs((phi_ext - phi_1)/phi_ext)*100);
    else
        gciResults.phi_extrapolated = NaN;
        warning('Cannot perform Richardson extrapolation with invalid order.');
    end
    
    % Calculate Grid Convergence Index
    F_s = 1.25;  % Safety factor
    
    if ~isnan(p_observed) && p_observed > 0 && abs(r_21^p_observed - 1) > 1e-12
        GCI_fine = F_s * abs(epsilon_21) / (r_21^p_observed - 1);
        gciResults.GCI_fine = GCI_fine * 100;  % Convert to percentage
        
        fprintf('Grid Convergence Index (fine grid):\n');
        fprintf('  GCI_fine = %.4f%%\n\n', gciResults.GCI_fine);
    else
        gciResults.GCI_fine = NaN;
        warning('Cannot calculate GCI with invalid observed order.');
    end
    
    % Calculate GCI for medium grid
    if ~isnan(p_observed) && p_observed > 0 && abs(r_32^p_observed - 1) > 1e-12
        GCI_medium = F_s * abs(epsilon_32) / (r_32^p_observed - 1);
        gciResults.GCI_medium = GCI_medium * 100;
        
        fprintf('Grid Convergence Index (medium grid):\n');
        fprintf('  GCI_medium = %.4f%%\n\n', gciResults.GCI_medium);
    else
        gciResults.GCI_medium = NaN;
    end
    
    % Asymptotic range verification
    if ~isnan(gciResults.GCI_fine) && ~isnan(gciResults.GCI_medium)
        if abs(r_21 - r_32) < 1e-6
            % Uniform refinement
            asymptotic_ratio = gciResults.GCI_medium / ...
                              (r_21^p_observed * gciResults.GCI_fine);
            
            gciResults.asymptotic_ratio = asymptotic_ratio;
            
            fprintf('Asymptotic range check:\n');
            fprintf('  Ratio GCI_23/(r^p * GCI_12) = %.6f\n', asymptotic_ratio);
            
            if asymptotic_ratio >= 0.95 && asymptotic_ratio <= 1.05
                gciResults.in_asymptotic_range = true;
                fprintf('  Status: PASSED (within asymptotic range)\n\n');
            else
                gciResults.in_asymptotic_range = false;
                fprintf('  Status: FAILED (outside asymptotic range [0.95, 1.05])\n');
                fprintf('  Recommendation: Use finer grids or check solution quality\n\n');
            end
        else
            gciResults.in_asymptotic_range = NaN;
            fprintf('Asymptotic check requires uniform refinement ratio.\n\n');
        end
    else
        gciResults.in_asymptotic_range = NaN;
    end
    
    % Convergence classification
    gciResults.convergence = classifyConvergence(epsilon_21, epsilon_32, p_observed);
    
    fprintf('Convergence classification:\n');
    fprintf('  Type: %s\n', gciResults.convergence.type);
    fprintf('  Description: %s\n\n', gciResults.convergence.description);
    
    % Uncertainty bounds
    if ~isnan(gciResults.GCI_fine)
        uncertainty_fine = gciResults.GCI_fine / 100 * phi_1;
        gciResults.uncertainty_fine = uncertainty_fine;
        
        fprintf('Solution with uncertainty bounds:\n');
        fprintf('  phi = %.8f 뿯½뿯½ %.8f (%.4f%%)\n\n', ...
                phi_1, uncertainty_fine, gciResults.GCI_fine);
    end
    
    % Visualise grid convergence
    visualiseGridConvergence(gciResults, meshData);
    
    % Generate comprehensive report
    generateGCIReport(gciResults);
    
    fprintf('Grid independence study completed.\n');
end

function phi = extractTargetQuantity(solutionStruct, variableName)
    % Extract target quantity from solution structure
    
    if isfield(solutionStruct, variableName)
        phi = solutionStruct.(variableName);
    else
        error('Target variable %s not found in solution data.', variableName);
    end
end

function convergence = classifyConvergence(eps_21, eps_32, p_obs)
    % Classify convergence behaviour
    
    convergence = struct();
    
    if isnan(p_obs) || abs(eps_21) < 1e-15
        convergence.type = 'Insufficient_data';
        convergence.description = 'Cannot determine convergence behaviour';
        
    elseif p_obs > 0 && abs(eps_21) < abs(eps_32)
        % Monotonic convergence
        convergence.type = 'Monotonic_convergence';
        convergence.description = 'Solution converging monotonically with refinement';
        
    elseif p_obs < 0 || abs(eps_21) > abs(eps_32)
        % Divergence or oscillatory
        if sign(eps_21) ~= sign(eps_32)
            convergence.type = 'Oscillatory_convergence';
            convergence.description = 'Solution oscillating about exact value';
        else
            convergence.type = 'Divergence';
            convergence.description = 'Solution diverging with refinement - check setup';
        end
        
    else
        convergence.type = 'Unclear';
        convergence.description = 'Convergence behaviour unclear - investigate further';
    end
end

function visualiseGridConvergence(gciResults, meshData)
    % Visualise grid convergence behaviour
    
    figure('Name', 'Grid Convergence Study', 'Position', [100, 100, 1200, 800]);
    
    % Grid spacing (characteristic)
    h_1 = 1 / gciResults.N_fine^(1/3);
    h_2 = 1 / gciResults.N_medium^(1/3);
    h_3 = 1 / gciResults.N_coarse^(1/3);
    
    h_values = [h_3, h_2, h_1];
    phi_values = [gciResults.phi_coarse, gciResults.phi_medium, gciResults.phi_fine];
    
    % Solution vs grid spacing
    subplot(2, 2, 1);
    plot(h_values, phi_values, 'bo-', 'LineWidth', 2, 'MarkerSize', 10, ...
         'MarkerFaceColor', 'b');
    hold on;
    
    if ~isnan(gciResults.phi_extrapolated)
        plot(0, gciResults.phi_extrapolated, 'r*', 'MarkerSize', 15, 'LineWidth', 2);
        legend('Grid solutions', 'Richardson extrapolation', ...
               'Location', 'best', 'Interpreter', 'latex');
    end
    
    xlabel('Characteristic grid spacing $h$', 'Interpreter', 'latex');
    ylabel('Solution value $\phi$', 'Interpreter', 'latex');
    title('Grid Convergence', 'Interpreter', 'latex');
    grid on;
    set(gca, 'XDir', 'reverse');
    
    % Log-log plot for order verification
    subplot(2, 2, 2);
    loglog(h_values, abs(phi_values - gciResults.phi_fine), 'bo-', ...
           'LineWidth', 2, 'MarkerSize', 10, 'MarkerFaceColor', 'b');
    hold on;
    
    % Theoretical slope line
    if ~isnan(gciResults.p_theoretical)
        h_theory = linspace(min(h_values)*0.8, max(h_values)*1.2, 100);
        error_theory = abs(phi_values(end) - gciResults.phi_fine) * ...
                      (h_theory / h_values(end)).^gciResults.p_theoretical;
        plot(h_theory, error_theory, 'r--', 'LineWidth', 1.5);
        
        legend('Observed', sprintf('Theoretical (order %.1f)', gciResults.p_theoretical), ...
               'Location', 'best', 'Interpreter', 'latex');
    end
    
    xlabel('Grid spacing $h$', 'Interpreter', 'latex');
    ylabel('Error $|\phi - \phi_{\mathrm{fine}}|$', 'Interpreter', 'latex');
    title('Order of Accuracy Verification', 'Interpreter', 'latex');
    grid on;
    
    % GCI comparison
    subplot(2, 2, 3);
    if ~isnan(gciResults.GCI_fine) && ~isnan(gciResults.GCI_medium)
        gci_values = [gciResults.GCI_medium, gciResults.GCI_fine];
        bar(gci_values);
        set(gca, 'XTickLabel', {'Medium', 'Fine'});
        ylabel('GCI (\%)', 'Interpreter', 'latex');
        title('Grid Convergence Index', 'Interpreter', 'latex');
        grid on;
    end
    
    % Solution summary table
    subplot(2, 2, 4);
    axis off;
    
    summaryText = sprintf('Grid Independence Summary\n\n');
    summaryText = [summaryText sprintf('Target variable: %s\n\n', gciResults.targetVariable)];
    summaryText = [summaryText sprintf('Observed order: %.3f\n', gciResults.p_observed)];
    summaryText = [summaryText sprintf('Theoretical order: %.1f\n\n', gciResults.p_theoretical)];
    
    if ~isnan(gciResults.GCI_fine)
        summaryText = [summaryText sprintf('GCI (fine): %.4f%%\n', gciResults.GCI_fine)];
    end
    
    if ~isnan(gciResults.in_asymptotic_range)
        if gciResults.in_asymptotic_range
            summaryText = [summaryText sprintf('\nAsymptotic range: YES\n')];
        else
            summaryText = [summaryText sprintf('\nAsymptotic range: NO\n')];
        end
    end
    
    summaryText = [summaryText sprintf('\nConvergence: %s\n', gciResults.convergence.type)];
    
    text(0.1, 0.5, summaryText, 'FontSize', 10, 'VerticalAlignment', 'middle', ...
         'FontName', 'FixedWidth');
    
    sgtitle('Grid Independence Study Results', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
end

function generateGCIReport(gciResults)
    % Generate comprehensive text report
    
    fprintf('\n=== COMPREHENSIVE GCI REPORT ===\n\n');
    
    fprintf('MESH INFORMATION:\n');
    fprintf('  Fine grid cells: %d\n', gciResults.N_fine);
    fprintf('  Medium grid cells: %d\n', gciResults.N_medium);
    fprintf('  Coarse grid cells: %d\n', gciResults.N_coarse);
    fprintf('  Refinement ratio r_21: %.4f\n', gciResults.r_21_actual);
    fprintf('  Refinement ratio r_32: %.4f\n\n', gciResults.r_32_actual);
    
    fprintf('SOLUTION VALUES:\n');
    fprintf('  phi_fine: %.10f\n', gciResults.phi_fine);
    fprintf('  phi_medium: %.10f\n', gciResults.phi_medium);
    fprintf('  phi_coarse: %.10f\n', gciResults.phi_coarse);
    
    if ~isnan(gciResults.phi_extrapolated)
        fprintf('  phi_extrapolated: %.10f\n\n', gciResults.phi_extrapolated);
    else
        fprintf('\n');
    end
    
    fprintf('CONVERGENCE ANALYSIS:\n');
    fprintf('  Observed order: %.4f\n', gciResults.p_observed);
    fprintf('  Convergence type: %s\n\n', gciResults.convergence.type);
    
    fprintf('UNCERTAINTY QUANTIFICATION:\n');
    if ~isnan(gciResults.GCI_fine)
        fprintf('  GCI_fine: %.4f%%\n', gciResults.GCI_fine);
        fprintf('  Solution uncertainty: 뿯½뿯½%.4e\n\n', gciResults.uncertainty_fine);
    else
        fprintf('  Cannot quantify uncertainty\n\n');
    end
    
    fprintf('VERIFICATION STATUS:\n');
    if ~isnan(gciResults.in_asymptotic_range)
        if gciResults.in_asymptotic_range
            fprintf('  Asymptotic range: ACHIEVED\n');
            fprintf('  Grid independence: DEMONSTRATED\n');
            fprintf('  Recommendation: Solution acceptable for validation\n\n');
        else
            fprintf('  Asymptotic range: NOT ACHIEVED\n');
            fprintf('  Grid independence: QUESTIONABLE\n');
            fprintf('  Recommendation: Refine mesh further or investigate\n\n');
        end
    else
        fprintf('  Asymptotic verification: INCOMPLETE\n');
        fprintf('  Recommendation: Provide additional grid refinement\n\n');
    end
    
    fprintf('=== END OF REPORT ===\n\n');
end
