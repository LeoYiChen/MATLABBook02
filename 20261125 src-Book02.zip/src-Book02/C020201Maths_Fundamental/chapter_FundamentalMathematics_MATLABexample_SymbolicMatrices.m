%% chapter_FundamentalMathematics_MATLABexample_SymbolicMatrices.m
% Symbolic computation with matrices.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_SymbolicMatrices
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_6_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates symbolic computation with matrices including
%              exact eigenvalues, characteristic polynomials, and symbolic
%              matrix calculus.

function demonstrateSymbolicMatrices()
    fprintf('Symbolic Computation with Matrices\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic symbolic matrix operations
    demonstrateBasicSymbolic();
    
    % Part 2: Characteristic polynomial and eigenvalues
    demonstrateCharacteristicPolynomial();
    
    % Part 3: Parametric matrix analysis
    demonstrateParametricAnalysis();
    
    % Part 4: Matrix calculus
    demonstrateMatrixCalculus();
    
    % Part 5: Symbolic solutions to matrix equations
    demonstrateSymbolicSolutions();
end

function demonstrateBasicSymbolic()
    % Demonstrate basic symbolic matrix operations
    
    fprintf('Part 1: Basic Symbolic Matrix Operations\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define symbolic variables
    syms a b c d real
    
    % Create symbolic matrix
    A = [a, b; c, d];
    
    fprintf('Symbolic matrix A:\n');
    disp(A);
    
    % Basic operations
    fprintf('Transpose A'':\n');
    disp(A');
    
    fprintf('Determinant det(A):\n');
    detA = det(A);
    disp(detA);
    
    fprintf('Trace tr(A):\n');
    traceA = trace(A);
    disp(traceA);
    
    % Inverse
    fprintf('Inverse A^(-1):\n');
    invA = inv(A);
    disp(invA);
    
    % Simplify
    fprintf('Simplified inverse:\n');
    invA_simplified = simplify(invA);
    disp(invA_simplified);
    
    % Verify A * inv(A) = I
    fprintf('Verification A * A^(-1):\n');
    identity_check = simplify(A * invA);
    disp(identity_check);
    fprintf('\n');
end

function demonstrateCharacteristicPolynomial()
    % Demonstrate characteristic polynomial and exact eigenvalues
    
    fprintf('Part 2: Characteristic Polynomial and Exact Eigenvalues\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define symbolic matrix
    syms lambda
    A = sym([1, 2; 2, 1]);
    
    fprintf('Matrix A:\n');
    disp(A);
    
    % Compute characteristic polynomial det(A - λI)
    I = eye(2);
    charMatrix = A - lambda * I;
    
    fprintf('Characteristic matrix (A - λI):\n');
    disp(charMatrix);
    
    charPoly = det(charMatrix);
    fprintf('\nCharacteristic polynomial det(A - λI):\n');
    disp(charPoly);
    
    % Expand and collect terms
    charPoly_expanded = expand(charPoly);
    fprintf('Expanded form:\n');
    disp(charPoly_expanded);
    
    % Solve for eigenvalues
    eigenvalues_sym = solve(charPoly == 0, lambda);
    fprintf('\nExact eigenvalues (roots of characteristic polynomial):\n');
    for k = 1:length(eigenvalues_sym)
        fprintf('  λ_%d = ', k);
        disp(eigenvalues_sym(k));
    end
    
    % Compute eigenvectors symbolically
    [V_sym, D_sym] = eig(A);
    fprintf('Symbolic eigenvalue matrix D:\n');
    disp(D_sym);
    
    fprintf('Symbolic eigenvector matrix V:\n');
    disp(V_sym);
    
    % Verify eigenvalue equation
    fprintf('\nVerification of eigenvalue equation Av = λv:\n');
    for k = 1:length(eigenvalues_sym)
        v = V_sym(:, k);
        Av = A * v;
        lambda*V = eigenvalues_sym(k) * v;
        difference = simplify(Av - lambda*V);
        
        fprintf('  For λ_%d: ||Av - λv|| = ', k);
        disp(norm(double(difference)));
    end
    fprintf('\n');
    
    % Example with symbolic entries
    fprintf('Example with symbolic parameter:\n');
    syms alpha real positive
    B = [alpha, 1; 1, alpha];
    
    fprintf('Matrix B(α):\n');
    disp(B);
    
    charPoly_B = det(B - lambda * eye(2));
    fprintf('\nCharacteristic polynomial:\n');
    disp(expand(charPoly_B));
    
    eigenvalues_B = solve(charPoly_B == 0, lambda);
    fprintf('Eigenvalues as functions of α:\n');
    for k = 1:length(eigenvalues_B)
        fprintf('  λ_%d(α) = ', k);
        disp(eigenvalues_B(k));
    end
    fprintf('\n');
end

function demonstrateParametricAnalysis()
    % Demonstrate analysis of parametric matrix systems
    
    fprintf('Part 3: Parametric Matrix Analysis\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define parametric matrix (rotation-like)
    syms theta real
    R = [cos(theta), -sin(theta); sin(theta), cos(theta)];
    
    fprintf('Rotation matrix R(θ):\n');
    disp(R);
    
    % Determinant
    detR = det(R);
    fprintf('\nDeterminant det(R):\n');
    detR_simplified = simplify(detR);
    disp(detR_simplified);
    
    % Eigenvalues
    fprintf('Eigenvalues of rotation matrix:\n');
    eigenvalues_R = eig(R);
    fprintf('  λ₁ = ');
    disp(simplify(eigenvalues_R(1)));
    fprintf('  λ₂ = ');
    disp(simplify(eigenvalues_R(2)));
    
    % These are complex for real θ (except θ = 0, π)
    fprintf('Note: Eigenvalues are complex (lie on unit circle)\n\n');
    
    % Analyse stability of parametric system
    fprintf('Stability analysis of discrete-time system x(k+1) = A(α)x(k):\n');
    syms alpha real
    A_param = [0.9, alpha; -alpha, 0.9];
    
    fprintf('System matrix A(α):\n');
    disp(A_param);
    
    % Eigenvalues
    eigenvalues_param = eig(A_param);
    fprintf('\nEigenvalues:\n');
    for k = 1:length(eigenvalues_param)
        fprintf('  λ_%d(α) = ', k);
        disp(eigenvalues_param(k));
    end
    
    % Magnitude of eigenvalues
    fprintf('Magnitude of eigenvalues:\n');
    for k = 1:length(eigenvalues_param)
        mag = simplify(abs(eigenvalues_param(k)));
        fprintf('  |λ_%d(α)| = ', k);
        disp(mag);
    end
    
    % Stability condition: |λ| < 1
    fprintf('\nStability condition: |λ| < 1\n');
    fprintf('For this system: |λ| = sqrt(0.81 + α²)\n');
    fprintf('Stable when: 0.81 + α² < 1\n');
    fprintf('           → |α| < sqrt(0.19) ≈ 0.436\n\n');
end

function demonstrateMatrixCalculus()
    % Demonstrate symbolic matrix calculus
    
    fprintf('Part 4: Matrix Calculus\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define symbolic vector and matrix
    syms x1 x2 real
    x = [x1; x2];
    
    A = sym([2, 1; 1, 4]);
    b = sym([1; -1]);
    
    fprintf('Vector x:\n');
    disp(x);
    
    fprintf('Matrix A:\n');
    disp(A);
    
    fprintf('Vector b:\n');
    disp(b);
    
    % Quadratic form f(x) = x'Ax
    fprintf('\nQuadratic form f(x) = x''Ax:\n');
    f_quad = x' * A * x;
    f_quad_expanded = expand(f_quad);
    disp(f_quad_expanded);
    
    % Gradient ∇f
    fprintf('Gradient ∇f = [∂f/∂x₁; ∂f/∂x₂]:\n');
    grad_f = [diff(f_quad, x1); diff(f_quad, x2)];
    grad_f_simplified = simplify(grad_f);
    disp(grad_f_simplified);
    
    fprintf('Note: ∇(x''Ax) = (A + A'')x\n');
    grad_formula = (A + A') * x;
    disp(grad_formula);
    
    fprintf('Verification (should be zero):\n');
    verification = simplify(grad_f_simplified - grad_formula);
    disp(verification);
    
    % Linear form g(x) = b'x
    fprintf('\nLinear form g(x) = b''x:\n');
    g_linear = b' * x;
    disp(g_linear);
    
    fprintf('Gradient ∇g:\n');
    grad_g = [diff(g_linear, x1); diff(g_linear, x2)];
    disp(grad_g);
    
    fprintf('Note: ∇(b''x) = b\n\n');
    
    % General function h(x) = x'Ax + b'x + c
    syms c real
    h = x' * A * x + b' * x + c;
    
    fprintf('General quadratic h(x) = x''Ax + b''x + c:\n');
    h_expanded = expand(h);
    disp(h_expanded);
    
    fprintf('Gradient ∇h:\n');
    grad_h = [diff(h, x1); diff(h, x2)];
    grad_h_simplified = simplify(grad_h);
    disp(grad_h_simplified);
    
    % Find critical point: ∇h = 0
    fprintf('Critical point (solving ∇h = 0):\n');
    critical_point = solve([grad_h_simplified(1) == 0, ...
                           grad_h_simplified(2) == 0], [x1, x2]);
    
    fprintf('  x₁* = ');
    disp(critical_point.x1);
    fprintf('  x₂* = ');
    disp(critical_point.x2);
    
    fprintf('\nNote: Critical point x* = -A^(-1)b (for quadratic forms)\n');
    x_star_formula = -inv(A) * b;
    disp(x_star_formula);
    fprintf('\n');
end

function demonstrateSymbolicSolutions()
    % Demonstrate symbolic solutions to matrix equations
    
    fprintf('Part 5: Symbolic Solutions to Matrix Equations\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Solve Ax = b symbolically
    syms x1 x2 a b c d e f real
    
    A = [a, b; c, d];
    rhs = [e; f];
    
    fprintf('Solving Ax = b symbolically:\n');
    fprintf('A =\n');
    disp(A);
    fprintf('b =\n');
    disp(rhs);
    
    % Solve using matrix inverse
    x_solution = inv(A) * rhs;
    fprintf('\nSolution x = A^(-1)b:\n');
    x_simplified = simplify(x_solution);
    disp(x_simplified);
    
    % Alternative: solve equations directly
    fprintf('Alternative: Solving system of equations directly:\n');
    syms x1 x2
    eq1 = a*x1 + b*x2 == e;
    eq2 = c*x1 + d*x2 == f;
    
    solution_struct = solve([eq1, eq2], [x1, x2]);
    fprintf('  x₁ = ');
    disp(simplify(solution_struct.x1));
    fprintf('  x₂ = ');
    disp(simplify(solution_struct.x2));
    
    % Matrix equation AX + XB = C (Sylvester equation)
    fprintf('\nSolving matrix equation AX + XB = C (Sylvester equation):\n');
    
    % Define small symbolic matrices
    syms x11 x12 x21 x22
    X = [x11, x12; x21, x22];
    
    A_syl = sym([1, 2; 0, 3]);
    B_syl = sym([4, 1; 0, 2]);
    C_syl = sym([5, 6; 7, 8]);
    
    fprintf('A =\n');
    disp(A_syl);
    fprintf('B =\n');
    disp(B_syl);
    fprintf('C =\n');
    disp(C_syl);
    
    % Form equation AX + XB = C
    equation = A_syl * X + X * B_syl - C_syl;
    
    % Extract system of equations
    equations = [equation(1,1) == 0, equation(1,2) == 0, ...
                 equation(2,1) == 0, equation(2,2) == 0];
    
    % Solve
    X_solution = solve(equations, [x11, x12, x21, x22]);
    
    fprintf('\nSolution X:\n');
    X_result = [X_solution.x11, X_solution.x12; ...
                X_solution.x21, X_solution.x22];
    disp(X_result);
    
    % Verify
    fprintf('Verification AX + XB:\n');
    verification = A_syl * X_result + X_result * B_syl;
    disp(verification);
    
    fprintf('Should equal C:\n');
    disp(C_syl);
    
    fprintf('\nDifference (should be zero):\n');
    diff_matrix = simplify(verification - C_syl);
    disp(diff_matrix);
end
