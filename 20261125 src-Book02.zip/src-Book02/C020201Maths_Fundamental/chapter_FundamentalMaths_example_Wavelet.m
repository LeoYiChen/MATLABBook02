%% chapter_FundamentalMaths_example_Wavelet.m
% Comprehensive wavelet transform analysis for non-stationary signals.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_Wavelet
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section6_example2.m
% Author: Dr Leo Chen
% Date: June 4, 2025
% MATLAB Version: R2025a
% Description: Comprehensive wavelet analysis demonstrating CWT scalogram
% generation, DWT-based denoising, and multi-resolution decomposition for
% non-stationary signal analysis in digital twin and autonomous systems

fprintf('=== Comprehensive Wavelet Transform Analysis ===\n\n');

%% Generate Non-Stationary Chirp Signal
% Chirp signals exhibit time-varying frequency content, making them ideal
% test cases for wavelet analysis superiority over Fourier methods

samplingFrequency = 1000;      % Sampling frequency (Hz)
timeVector = 0:1/samplingFrequency:2;   % Time vector (2 seconds)
initialFrequency = 50;         % Initial frequency (Hz)
finalFrequency = 250;          % Final frequency (Hz)

% Create chirp signal with quadratic frequency modulation
chirpSignal = chirp(timeVector, initialFrequency, 2, finalFrequency, ...
    'quadratic');

% Add Gaussian noise to simulate realistic sensor measurements
noiseLevel = 0.5;
noisyChirp = chirpSignal + noiseLevel * randn(size(timeVector));

fprintf('Signal parameters:\n');
fprintf('  Signal type: Quadratic chirp\n');
fprintf('  Frequency sweep: %d Hz to %d Hz\n', ...
    initialFrequency, finalFrequency);
fprintf('  Duration: %.1f seconds\n', max(timeVector));
fprintf('  Sampling frequency: %d Hz\n', samplingFrequency);

%% Continuous Wavelet Transform Analysis
% CWT provides high-resolution time-frequency representation revealing
% time-varying spectral content invisible to traditional Fourier analysis

waveletName = 'amor';  % Analytic Morlet wavelet (optimal for frequency)
frequencyLimits = [20, 300];  % Analysis frequency range (Hz)

[cwtCoefficients, cwtFrequencies] = cwt(noisyChirp, waveletName, ...
    samplingFrequency, 'FrequencyLimits', frequencyLimits);

fprintf('\nContinuous Wavelet Transform computed:\n');
fprintf('  Wavelet: %s (Analytic Morlet)\n', waveletName);
fprintf('  Frequency range: %d-%d Hz\n', frequencyLimits(1), ...
    frequencyLimits(2));
fprintf('  Time-frequency resolution: %d x %d\n', ...
    length(timeVector), length(cwtFrequencies));

%% Visualisation: CWT Scalogram
figure('Position', [100, 100, 1400, 900]);

% Subplot 1: Clean chirp signal (time domain)
subplot(3, 1, 1);
plot(timeVector, chirpSignal, 'b-', 'LineWidth', 1.5);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
title('Clean Chirp Signal with Time-Varying Frequency', ...
    'Interpreter', 'latex', 'FontSize', 12);
grid on;
xlim([0, 2]);

% Subplot 2: Noisy measurement signal (time domain)
subplot(3, 1, 2);
plot(timeVector, noisyChirp, 'r-', 'LineWidth', 1);
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Amplitude', 'Interpreter', 'latex');
title('Noisy Measurement Signal', 'Interpreter', 'latex', 'FontSize', 12);
grid on;
xlim([0, 2]);

% Subplot 3: CWT scalogram (time-frequency representation)
subplot(3, 1, 3);
surface(timeVector, cwtFrequencies, abs(cwtCoefficients));
axis tight;
shading interp;
xlabel('Time (s)', 'Interpreter', 'latex');
ylabel('Frequency (Hz)', 'Interpreter', 'latex');
title('Continuous Wavelet Transform Scalogram', 'Interpreter', 'latex', ...
    'FontSize', 12);
set(gca, 'YScale', 'log');
colormap('parula');
colourBar = colorbar;
ylabel(colourBar, 'Magnitude', 'Interpreter', 'latex');
view(0, 90);

saveas(gcf, 'wavelet_cwt_scalogram.png');

%% Discrete Wavelet Transform for Denoising
% DWT enables efficient multi-resolution signal decomposition with
% computational complexity O(N) compared to CWT's O(N^2)

waveletFamily = 'db4';      % Daubechies 4 wavelet
decompositionLevel = 5;     % Number of decomposition levels

% Perform multi-level wavelet decomposition
[waveletCoefficients, levelLengths] = wavedec(noisyChirp, ...
    decompositionLevel, waveletFamily);

fprintf('\nDiscrete Wavelet Transform decomposition:\n');
fprintf('  Wavelet family: %s (Daubechies 4)\n', waveletFamily);
fprintf('  Decomposition levels: %d\n', decompositionLevel);
fprintf('  Total coefficients: %d\n', length(waveletCoefficients));

% Universal threshold denoising strategy (Donoho & Johnstone, 1994)
% Robust noise level estimation using median absolute deviation
sigma = median(abs(waveletCoefficients)) / 0.6745;
thresholdValue = sigma * sqrt(2 * log(length(noisyChirp)));

fprintf('  Estimated noise level: %.4f\n', sigma);
fprintf('  Universal threshold: %.4f\n', thresholdValue);

% Apply soft thresholding to wavelet coefficients
denoisedCoefficients = wthresh(waveletCoefficients, 's', thresholdValue);

% Reconstruct denoised signal from thresholded coefficients
denoisedSignal = waverec(denoisedCoefficients, levelLengths, waveletFamily);

%% Multi-Resolution Decomposition Visualisation
% Extract individual decomposition levels for detailed analysis
approximation = appcoef(denoisedCoefficients, levelLengths, ...
    waveletFamily, decompositionLevel);
details = cell(1, decompositionLevel);
for level = 1:decompositionLevel
    details{level} = detcoef(denoisedCoefficients, levelLengths, level);
end

figure('Position', [100, 100, 1400, 1000]);

% Original and denoised signals
subplot(decompositionLevel + 2, 1, 1);
plot(timeVector, noisyChirp, 'r-', 'LineWidth', 1);
title('Noisy Signal', 'Interpreter', 'latex', 'FontSize', 10);
ylabel('Amplitude', 'Interpreter', 'latex');
grid on;
xlim([0, 2]);

subplot(decompositionLevel + 2, 1, 2);
plot(timeVector, denoisedSignal, 'g-', 'LineWidth', 1.5);
hold on;
plot(timeVector, chirpSignal, 'b--', 'LineWidth', 1);
title('Wavelet-Denoised Signal vs Original', 'Interpreter', 'latex', ...
    'FontSize', 10);
ylabel('Amplitude', 'Interpreter', 'latex');
legend('Denoised', 'Original', 'Interpreter', 'latex', 'Location', 'best');
grid on;
xlim([0, 2]);
hold off;

% Detail coefficients at each level
for level = 1:decompositionLevel
    subplot(decompositionLevel + 2, 1, level + 2);
    detailTime = linspace(0, 2, length(details{level}));
    plot(detailTime, details{level}, 'k-', 'LineWidth', 0.8);
    title(sprintf('Detail Level %d (High Freq)', level), ...
        'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Amplitude', 'Interpreter', 'latex');
    grid on;
    xlim([0, 2]);
end

xlabel('Time (s)', 'Interpreter', 'latex');

saveas(gcf, 'wavelet_dwt_decomposition.png');

%% Quantitative Performance Metrics
% Compute denoising performance using standard metrics

meanSquaredErrorNoisy = mean((chirpSignal - noisyChirp).^2);
meanSquaredErrorDenoised = mean((chirpSignal - denoisedSignal).^2);
improvementPercentage = 100 * (meanSquaredErrorNoisy - ...
    meanSquaredErrorDenoised) / meanSquaredErrorNoisy;

% Signal-to-noise ratio calculation
snrNoisy = snr(chirpSignal, noisyChirp - chirpSignal);
snrDenoised = snr(chirpSignal, denoisedSignal - chirpSignal);

fprintf('\n=== Wavelet Denoising Performance Metrics ===\n');
fprintf('MSE (noisy signal):     %.6f\n', meanSquaredErrorNoisy);
fprintf('MSE (denoised signal):  %.6f\n', meanSquaredErrorDenoised);
fprintf('MSE improvement:        %.2f%%\n', improvementPercentage);
fprintf('RMSE reduction:         %.2f%%\n', ...
    100 * (1 - sqrt(meanSquaredErrorDenoised) / sqrt(meanSquaredErrorNoisy)));
fprintf('SNR improvement:        %.2f dB\n', snrDenoised - snrNoisy);

fprintf('\nWavelet analysis example complete.\n');
fprintf('Figures saved: wavelet_cwt_scalogram.png, ');
fprintf('wavelet_dwt_decomposition.png\n');
