%% lst_adv_prob04.m
% Electrical circuit analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : lst:adv_prob04
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_AdvMath_Problem04.m
%  Electrical Circuit Analysis Using Linear Systems
%  Author : Dr Yi Chen
%  MATLAB : R2024a or later
%  Created: 2025
% --------------------------------

clear; clc; close all;

%% -- 1. System Definition --
coefficientMatrix = [10 -5  0 -2;
                     -5 15 -8  0;
                      0 -8 12 -3;
                     -2  0 -3  8];
rightHandSide = [12; 0; 0; -8];
systemSize = size(coefficientMatrix, 1);

%% -- 2. Direct Solution (Backslash) --
voltageBackslash = coefficientMatrix \ rightHandSide;
fprintf('-- Direct Solution (A\\b) --\n');
for nodeIndex = 1:systemSize
    fprintf('  V_%d = %10.6f V\n', nodeIndex, ...
            voltageBackslash(nodeIndex));
end
fprintf('  Residual norm = %.4e\n', ...
    norm(coefficientMatrix * voltageBackslash - rightHandSide));

%% -- 3. LU Decomposition --
[lowerMatrix, upperMatrix, permutationMatrix] = ...
    lu(coefficientMatrix);
intermediateSolution = lowerMatrix \ ...
    (permutationMatrix * rightHandSide);
voltageLU = upperMatrix \ intermediateSolution;
fprintf('\n-- LU Decomposition --\n');
for nodeIndex = 1:systemSize
    fprintf('  V_%d = %10.6f V\n', nodeIndex, ...
            voltageLU(nodeIndex));
end

%% -- 4. Jacobi Iteration --
maxIterations = 500;
tolerance = 1e-10;
voltageJacobi = zeros(systemSize, 1);
diagonalMatrix = diag(diag(coefficientMatrix));
offDiagonalMatrix = coefficientMatrix - diagonalMatrix;
jacobiConvergenceHistory = zeros(maxIterations, 1);

for iterIndex = 1:maxIterations
    voltageJacobiNew = diagonalMatrix \ ...
        (rightHandSide - offDiagonalMatrix * voltageJacobi);
    jacobiConvergenceHistory(iterIndex) = ...
        norm(voltageJacobiNew - voltageJacobi);
    voltageJacobi = voltageJacobiNew;
    if jacobiConvergenceHistory(iterIndex) < tolerance
        fprintf('\n-- Jacobi converged in %d iterations --\n', ...
                iterIndex);
        break;
    end
end
for nodeIndex = 1:systemSize
    fprintf('  V_%d = %10.6f V\n', nodeIndex, ...
            voltageJacobi(nodeIndex));
end

%% -- 5. Gauss-Seidel Iteration --
voltageGS = zeros(systemSize, 1);
gsConvergenceHistory = zeros(maxIterations, 1);

for iterIndex = 1:maxIterations
    voltageGSold = voltageGS;
    for rowIndex = 1:systemSize
        sigma = rightHandSide(rowIndex);
        for colIndex = 1:systemSize
            if colIndex ~= rowIndex
                sigma = sigma - coefficientMatrix(rowIndex, ...
                    colIndex) * voltageGS(colIndex);
            end
        end
        voltageGS(rowIndex) = sigma / ...
            coefficientMatrix(rowIndex, rowIndex);
    end
    gsConvergenceHistory(iterIndex) = ...
        norm(voltageGS - voltageGSold);
    if gsConvergenceHistory(iterIndex) < tolerance
        fprintf('\n-- Gauss-Seidel converged in %d iters --\n',...
                iterIndex);
        break;
    end
end
for nodeIndex = 1:systemSize
    fprintf('  V_%d = %10.6f V\n', nodeIndex, ...
            voltageGS(nodeIndex));
end

%% -- 6. Condition Number --
conditionNumber = cond(coefficientMatrix);
fprintf('\nCondition number kappa(A) = %.4f\n', conditionNumber);
fprintf('Estimated digits of accuracy lost: %.1f\n', ...
    log10(conditionNumber));

%% -- 7. Visualisation --
figHandle = figure('Position', [100 100 1000 450]);

subplot(1,2,1);
bar(1:systemSize, [voltageBackslash, voltageLU, ...
    voltageJacobi, voltageGS]);
xlabel('Node index', 'Interpreter', 'latex');
ylabel('Voltage (V)', 'Interpreter', 'latex');
title('Node Voltages by Method', 'Interpreter', 'latex');
legend({'Backslash', 'LU', 'Jacobi', 'Gauss-Seidel'}, ...
       'Interpreter', 'latex', 'Location', 'best');
grid on;

subplot(1,2,2);
jacobiTrimmed = jacobiConvergenceHistory(1: ...
    find(jacobiConvergenceHistory > 0, 1, 'last'));
gsTrimmed = gsConvergenceHistory(1: ...
    find(gsConvergenceHistory > 0, 1, 'last'));
semilogy(1:numel(jacobiTrimmed), jacobiTrimmed, 'b-o', ...
    'LineWidth', 1.2); hold on;
semilogy(1:numel(gsTrimmed), gsTrimmed, 'r-s', ...
    'LineWidth', 1.2);
xlabel('Iteration', 'Interpreter', 'latex');
ylabel('$\|\mathbf{V}^{(k+1)} - \mathbf{V}^{(k)}\|$', ...
       'Interpreter', 'latex');
title('Iterative Convergence', 'Interpreter', 'latex');
legend({'Jacobi', 'Gauss-Seidel'}, 'Interpreter', 'latex');
grid on;

savefig(figHandle, 'Problem04_CircuitAnalysis.fig');
exportgraphics(figHandle, 'Problem04_CircuitAnalysis.eps', ...
               'ContentType', 'vector');
exportgraphics(figHandle, 'Problem04_CircuitAnalysis.jpg', ...
               'Resolution', 300);

fprintf('\n-- Problem 4 Complete --\n');
% Computational Complexity:
% Gaussian elimination (backslash) and LU decomposition both
% require O(n^3/3) operations for an n-by-n system; here n=4,
% so cost is negligible.  Jacobi and Gauss-Seidel iterate with
% O(n^2) operations per step; convergence rate depends on the
% spectral radius of the iteration matrix.  Gauss-Seidel
% typically converges in roughly half the iterations of Jacobi
% for SPD matrices.  Condition number computation via SVD is
% O(n^3).  Space complexity is O(n^2) for all methods.
