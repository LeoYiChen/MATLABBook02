%% chapter_FundamentalMathematics_conclusion_calculus.m
% Numerical differentiation and integration fundamentals.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_conclusion_calculus
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute demonstration
demonstrateCalculusFundamentals();

% Local functions (moved to end so this listing is a valid MATLAB script)
function demonstrateCalculusFundamentals()
    % DEMONSTRATECALCULUSFUNDAMENTALS Numerical calculus essentials
    %   Explores differentiation, integration, and differential equations
    
    fprintf('Calculus in Computational Practice\n');
    fprintf('===================================\n\n');
    
    %% Numerical Differentiation
    fprintf('NUMERICAL DIFFERENTIATION\n');
    fprintf('-----\n\n');
    
    fprintf(['Computing derivatives numerically using finite differences:\n', ...
        '  Forward: f''(x) ≈ [f(x+h) - f(x)] / h\n', ...
        '  Central: f''(x) ≈ [f(x+h) - f(x-h)] / (2*h)\n\n']);
    
    % Define test function: f(x) = sin(x), f'(x) = cos(x)
    f = @(x) sin(x);
    f_prime_exact = @(x) cos(x);
    
    x_test = pi / 4;
    h_values = logspace(-1, -16, 16);
    
    errors_forward = zeros(size(h_values));
    errors_central = zeros(size(h_values));
    
    for i = 1:length(h_values)
        h = h_values(i);
        
        % Forward difference
        deriv_forward = (f(x_test + h) - f(x_test)) / h;
        errors_forward(i) = abs(deriv_forward - f_prime_exact(x_test));
        
        % Central difference
        deriv_central = (f(x_test + h) - f(x_test - h)) / (2 * h);
        errors_central(i) = abs(deriv_central - f_prime_exact(x_test));
    end
    
    fprintf('Test function: f(x) = sin(x) at x = π/4\n');
    fprintf('Exact derivative: f''(π/4) = cos(π/4) = %.10f\n\n', ...
        f_prime_exact(x_test));
    
    % Visualise error behaviour
    figure('Position', [100, 100, 1400, 500]);
    
    subplot(1, 2, 1);
    loglog(h_values, errors_forward, 'b-o', 'LineWidth', 2, ...
        'DisplayName', 'Forward Difference');
    hold on;
    loglog(h_values, errors_central, 'r-s', 'LineWidth', 2, ...
        'DisplayName', 'Central Difference');
    loglog(h_values, h_values, 'k-', 'LineWidth', 1.5, ...
        'DisplayName', 'O(h)');
    loglog(h_values, h_values.^2, 'k:', 'LineWidth', 1.5, ...
        'DisplayName', 'O(h^2)');
    
    xlabel('Step Size h');
    ylabel('Absolute Error');
    title('Finite Difference Error vs Step Size');
    legend('Location', 'best');
    grid on;
    
    fprintf('Observation: Central differences achieve O(h^2) accuracy,\n');
    fprintf('superior to forward differences O(h) accuracy.\n\n');
    
    %% Numerical Integration
    fprintf('NUMERICAL INTEGRATION\n');
    fprintf('-----\n\n');
    
    fprintf(['Computing definite integrals numerically:\n', ...
        '  Trapezoidal rule, Simpson''s rule, adaptive quadrature\n\n']);
    
    % Test integral: ∫₀^π sin(x) dx = 2
    integral_exact = 2;
    a = 0;
    b = pi;
    
    % Trapezoidal rule with varying subdivisions
    n_values = [10, 50, 100, 500, 1000];
    
    fprintf('Integrating sin(x) from 0 to π (exact value = 2):\n\n');
    fprintf('%-15*s  %-20*s  %-20*s\n', 'Subdivisions', 'Approximation', ...
        'Absolute Error');
    fprintf('%s\n', repmat('-', 1, 60));
    
    for n = n_values
        x_points = linspace(a, b, n + 1);
        y_points = sin(x_points);
        h = (b - a) / n;
        
        integral_trap = h * (sum(y_points) - (y_points(1) + y_points(end)) / 2);
        error_trap = abs(integral_trap - integral_exact);
        
        fprintf('%-15*d  %-20.10*f  %-20.2*e\n', n, integral_trap, error_trap);
    end
    fprintf('\n');
    
    % MATLAB's built-in adaptive quadrature
    integral_adaptive = integral(f, a, b);
    error_adaptive = abs(integral_adaptive - integral_exact);
    
    fprintf('MATLAB adaptive quadrature (integral function):\n');
    fprintf('  Result: %.15f\n', integral_adaptive);
    fprintf('  Error:  %.2e\n\n', error_adaptive);
    
    %% Ordinary Differential Equations
    fprintf('ORDINARY DIFFERENTIAL EQUATIONS\n');
    fprintf('------\n\n');
    
    fprintf(['ODEs describe systems evolving continuously in time.\n', ...
        'Example: Predator-prey dynamics (Lotka-Volterra model)\n\n']);
    
    % Lotka-Volterra equations
    % dx/dt = alpha*x - beta*x*y  (prey)
    % dy/dt = delta*x*y - gamma*y (predator)
    
    alpha = 1.0;   % prey growth rate
    beta = 0.1;    % predation rate
    delta = 0.075; % predator efficiency
    gamma = 1.5;   % predator death rate
    
    lotka_volterra = @(t, z) [
        alpha * z(1) - beta * z(1) * z(2);
        delta * z(1) * z(2) - gamma * z(2)
    ];
    
    % Initial conditions
    y0 = [10; 5];  % [prey, predator]
    tspan = [0, 50];
    
    % Solve using MATLAB's ode45 (Dormand-Prince method)
    [t, y] = ode45(lotka_volterra, tspan, y0);
    
    fprintf('Lotka-Volterra Parameters:\n');
    fprintf('  Prey growth rate (alpha):     %.3f\n', alpha);
    fprintf('  Predation rate (beta):        %.3f\n', beta);
    fprintf('  Predator efficiency (delta):  %.3f\n', delta);
    fprintf('  Predator death rate (gamma):  %.3f\n\n', gamma);
    
    fprintf('Initial conditions: %.0f prey, %.0f predators\n', y0(1), y0(2));
    fprintf('Time span: %.0f to %.0f time units\n\n', tspan(1), tspan(2));
    
    % Visualisation
    subplot(1, 2, 2);
    plot(t, y(:, 1), 'b-', 'LineWidth', 2, 'DisplayName', 'Prey');
    hold on;
    plot(t, y(:, 2), 'r-', 'LineWidth', 2, 'DisplayName', 'Predator');
    xlabel('Time');
    ylabel('Population');
    title('Predator-Prey Dynamics');
    legend('Location', 'best');
    grid on;
    
    % Phase portrait
    figure('Position', [100, 100, 700, 600]);
    plot(y(:, 1), y(:, 2), 'b-', 'LineWidth', 2);
    hold on;
    plot(y(1, 1), y(1, 2), 'go', 'MarkerSize', 12, 'MarkerFaceColor', 'g', ...
        'DisplayName', 'Initial State');
    plot(y(end, 1), y(end, 2), 'ro', 'MarkerSize', 12, 'MarkerFaceColor', 'r', ...
        'DisplayName', 'Final State');
    
    xlabel('Prey Population');
    ylabel('Predator Population');
    title('Phase Portrait: Predator-Prey Dynamics');
    legend('Location', 'best');
    grid on;
    
    fprintf('Phase portrait reveals cyclic population dynamics,\n');
    fprintf('a characteristic feature of Lotka-Volterra systems.\n\n');
end
