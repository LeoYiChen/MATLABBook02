%% chapter_DataVisualisation_venn.m
% Venn Diagram Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_venn
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Requires Image Processing Toolbox
A = [1 1 1 0]; % Set intersections
figure('Position', [100 100 800 600]);
venn(A, 'FaceColor', {'b', 'r'}, 'FaceAlpha', 0.3);
title('Set Relationship Analysis');

% Export figure in multiple formats
exportFigure(gca, 'VennDiagram_plot');

