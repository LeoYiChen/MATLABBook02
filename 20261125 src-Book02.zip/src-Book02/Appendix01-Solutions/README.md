# Appendix01-Solutions - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines |
| Chapter | Solutions To Problems |
| Package version | 1.1.0 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P02-20261027` |
| Source chapter file | `P0202main/Appendix01-Solutions/` (included by `P02_20260830.tex`) |
| Code files | 254 |
| Code lines relocated | 79,096 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting`, every code `verbatim`
environment and every `\lstinputlisting` call in the chapter has been removed
from the main body and deposited here. Only the filename, the listing caption
and a reference to this folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `Appendix01-Solutions_code_NNN.m`.
- Code held in a `verbatim` environment receives `Appendix01-Solutions_verbatim_NN.m`.
- Code loaded by `\lstinputlisting` keeps the label of that call, so
  `chapter_CW04_code_runner` becomes `chapter_CW04_code_runner.m`.
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 4.3:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book02/Appendix01-Solutions/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook02
```

Clone or download `src-Book02/` from this repository, or use the Springer
supplementary archive. The same address is printed in the preface of the book.
Keep the `src-Book02/` folder name so that the in-text `src-Book02/Appendix01-Solutions/`
paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `Appendix01-Solutions_code_208.m` | `(generated)` | Physics-Informed Neural Network for 1D Diffusion |
| `Appendix01-Solutions_code_209.m` | `(generated)` | CNN for Handwritten Physics Symbol Recognition |
| `Appendix01-Solutions_code_210.m` | `(generated)` | Transfer Learning for Stellar Spectra (Condensed) |
| `Appendix01-Solutions_code_211.m` | `(generated)` | Q-Learning Oscillator Control (Condensed) |
| `Appendix01-Solutions_code_212.m` | `(generated)` | Bayesian Optimization (Condensed) |
| `Appendix01-Solutions_code_213.m` | `(generated)` | Ensemble Learning for Particle Mass Prediction |
| `Appendix01-Solutions_code_214.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_215.m` | `(generated)` | Variational Autoencoder for Phase Space Reduction |
| `Appendix01-Solutions_code_216.m` | `(generated)` | Multi-Task Learning for EM Fields (Key Components) |
| `Appendix01-Solutions_code_229.m` | `(generated)` | Problem 11: Human-in-the-Loop Bayesian Optimization for Photocatalyst Discovery |
| `Appendix01-Solutions_code_230.m` | `(generated)` | Problem 12: Machine Learning-Guided Enzyme Design via Fitness Landscape Navigation |
| `Appendix01-Solutions_code_231.m` | `(generated)` | Problem 13: Autonomous Mobile Robot Chemist with AI Decision-Making |
| `Appendix01-Solutions_code_236.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_237.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_243.m` | `(generated)` | Complete MPC Implementation for Coupled Tank System |
| `Appendix01-Solutions_code_244.m` | `(generated)` | Genetic Algorithm for PID Parameter Optimisation |
| `Appendix01-Solutions_code_245.m` | `(generated)` | NSGA-II for Multi-Objective PID Optimization |
| `Appendix01-Solutions_code_246.m` | `(generated)` | PSO for PID Controller Optimization |
| `Appendix01-Solutions_code_247.m` | `(generated)` | Fuzzy Logic Controller for Magnetic Levitation |
| `Appendix01-Solutions_code_248.m` | `(generated)` | Neural Network System Identification |
| `Appendix01-Solutions_code_249.m` | `(generated)` | Q-Learning for Cart-Pole Control |
| `Appendix01-Solutions_code_250.m` | `(generated)` | Deep Deterministic Policy Gradient for Pendulum Swing-Up |
| `Appendix01-Solutions_code_251.m` | `(generated)` | MATLAB source code for this example. |
| `Appendix01-Solutions_code_252.m` | `(generated)` | Physics-Informed Neural Networks for System Modeling |
| `Appendix01-Solutions_code_253.m` | `(generated)` | Digital Twin with Real-Time Parameter Adaptation |
| `Appendix01-Solutions_code_254.m` | `(generated)` | Hybrid AI-Classical Control: Neural Network + PID |
| `adaptive_quadrature.m` | `adaptive_quadrature` | Adaptive Simpson's Quadrature |
| `ch08_prob10_code.m` | `ch08_prob10_code` | Big-data visualisation dashboard with animation (MATLABBook02_Chapter08_Problem10.m). |
| `ch08_prob1_code.m` | `ch08_prob1_code` | Datastore-based CSV loading and pre-processing (MATLABBook02_Chapter08_Problem1.m). |
| `ch08_prob2_code.m` | `ch08_prob2_code` | Tall-array statistical analysis (MATLABBook02_Chapter08_Problem2.m). |
| `ch08_prob3_code.m` | `ch08_prob3_code` | MapReduce pipeline (MATLABBook02_Chapter08_Problem3.m). |
| `ch08_prob3_mapper.m` | `ch08_prob3_mapper` | Mapper function (meanVarianceMapper.m). |
| `ch08_prob3_reducer.m` | `ch08_prob3_reducer` | Reducer function (meanVarianceReducer.m). |
| `ch08_prob4_code.m` | `ch08_prob4_code` | PCA dimensionality reduction with animated 3-D plot (MATLABBook02_Chapter08_Problem4.m). |
| `ch08_prob5_code.m` | `ch08_prob5_code` | Transfer learning with imageDatastore (MATLABBook02_Chapter08_Problem5.m). |
| `ch08_prob6_code.m` | `ch08_prob6_code` | Autoencoder anomaly detection (MATLABBook02_Chapter08_Problem6.m). |
| `ch08_prob7_code.m` | `ch08_prob7_code` | Parallel vs.\ serial feature extraction benchmark (MATLABBook02_Chapter08_Problem7.m). |
| `ch08_prob8_code.m` | `ch08_prob8_code` | LSTM streaming prediction with animation (MATLABBook02_Chapter08_Problem8.m). |
| `ch08_prob9_code.m` | `ch08_prob9_code` | NLP topic modelling on a large text corpus (MATLABBook02_Chapter08_Problem9.m). |
| `chaotic_system.m` | `chaotic_system` | Chaotic Dynamical System Simulation |
| `chapter_AI_Chemistry_Problem01_code.m` | `chapter_AI_Chemistry_Problem01_code` | Problem 1: QSAR Modelling for Aqueous Solubility Prediction |
| `chapter_AI_Chemistry_Problem02_code.m` | `chapter_AI_Chemistry_Problem02_code` | Problem 2: Bayesian Optimisation for Reaction Yield (Abbreviated) |
| `chapter_AI_Chemistry_Problem03_code.m` | `chapter_AI_Chemistry_Problem03_code` | Problem 3: Molecular Similarity Searching with Fingerprints |
| `chapter_AI_Chemistry_Problem04_code.m` | `chapter_AI_Chemistry_Problem04_code` | Problem 4: CNN for NMR Peak Identification |
| `chapter_AI_Chemistry_Problem05_code.m` | `chapter_AI_Chemistry_Problem05_code` | Problem 5: Transfer Learning for Toxicity Prediction |
| `chapter_AI_Chemistry_Problem06_code.m` | `chapter_AI_Chemistry_Problem06_code` | Problem 6: Graph Neural Networks for Molecular Property Prediction |
| `chapter_AI_Chemistry_Problem07_code.m` | `chapter_AI_Chemistry_Problem07_code` | Problem 7: Reinforcement Learning for Reaction Pathway Optimization |
| `chapter_AI_Chemistry_Problem08_code.m` | `chapter_AI_Chemistry_Problem08_code` | Problem 8: Transformer Models for SMILES-to-Property Translation |
| `chapter_AI_Chemistry_Problem09_code.m` | `chapter_AI_Chemistry_Problem09_code` | Problem 9: Generative Adversarial Networks for Molecular Design |
| `chapter_AI_Chemistry_Problem10_code.m` | `chapter_AI_Chemistry_Problem10_code` | Problem 10: Explainable AI for Chemical Reaction Prediction |
| `chapter_AI_Mechanics_Problem10_ae_syntax.m` | `chapter_AI_Mechanics_Problem10_ae_syntax` | Autoencoder network definition syntax. |
| `chapter_AI_Mechanics_Problem10_roc_syntax.m` | `chapter_AI_Mechanics_Problem10_roc_syntax` | ROC curve and optimal threshold selection syntax. |
| `chapter_AI_Mechanics_Problem1_complete_code.m` | `chapter_AI_Mechanics_Problem1_complete_code` | Complete ensemble learning for fatigue life prediction. |
| `chapter_AI_Mechanics_Problem1_nn_syntax.m` | `chapter_AI_Mechanics_Problem1_nn_syntax` | Neural network regression syntax. |
| `chapter_AI_Mechanics_Problem1_polyreg_syntax.m` | `chapter_AI_Mechanics_Problem1_polyreg_syntax` | Polynomial regression syntax. |
| `chapter_AI_Mechanics_Problem1_svr_syntax.m` | `chapter_AI_Mechanics_Problem1_svr_syntax` | Support Vector Regression syntax. |
| `chapter_AI_Mechanics_Problem2_pca_syntax.m` | `chapter_AI_Mechanics_Problem2_pca_syntax` | PCA using economy SVD syntax. |
| `chapter_AI_Mechanics_Problem2_tsne_syntax.m` | `chapter_AI_Mechanics_Problem2_tsne_syntax` | t-SNE dimensionality reduction syntax. |
| `chapter_AI_Mechanics_Problem3_complete_code.m` | `chapter_AI_Mechanics_Problem3_complete_code` | Complete defect classification using unsupervised clustering. |
| `chapter_AI_Mechanics_Problem3_hierarchical_syntax.m` | `chapter_AI_Mechanics_Problem3_hierarchical_syntax` | Hierarchical clustering syntax. |
| `chapter_AI_Mechanics_Problem3_kmeans_syntax.m` | `chapter_AI_Mechanics_Problem3_kmeans_syntax` | K-means clustering syntax. |
| `chapter_AI_Mechanics_Problem4_architecture_syntax.m` | `chapter_AI_Mechanics_Problem4_architecture_syntax` | PINN architecture definition for beam vibration. |
| `chapter_AI_Mechanics_Problem4_residual_syntax.m` | `chapter_AI_Mechanics_Problem4_residual_syntax` | PDE residual computation using automatic differentiation. |
| `chapter_AI_Mechanics_Problem5_complete_code.m` | `chapter_AI_Mechanics_Problem5_complete_code` | Complete phase-field fracture simulation. |
| `chapter_AI_Mechanics_Problem5_damage_syntax.m` | `chapter_AI_Mechanics_Problem5_damage_syntax` | Phase-field damage evolution syntax. |
| `chapter_AI_Mechanics_Problem5_gp_syntax.m` | `chapter_AI_Mechanics_Problem5_gp_syntax` | Gaussian Process surrogate model syntax. |
| `chapter_AI_Mechanics_Problem5_split_syntax.m` | `chapter_AI_Mechanics_Problem5_split_syntax` | Strain energy split (tension/compression) syntax. |
| `chapter_AI_Mechanics_Problem6_cnn_syntax.m` | `chapter_AI_Mechanics_Problem6_cnn_syntax` | CNN architecture definition syntax. |
| `chapter_AI_Mechanics_Problem6_gradcam_syntax.m` | `chapter_AI_Mechanics_Problem6_gradcam_syntax` | Grad-CAM saliency map syntax. |
| `chapter_AI_Mechanics_Problem6_transfer_syntax.m` | `chapter_AI_Mechanics_Problem6_transfer_syntax` | Transfer learning using ResNet-18 syntax. |
| `chapter_AI_Mechanics_Problem7_ABD_syntax.m` | `chapter_AI_Mechanics_Problem7_ABD_syntax` | ABD matrix calculation using CLT syntax. |
| `chapter_AI_Mechanics_Problem7_NSGAII_syntax.m` | `chapter_AI_Mechanics_Problem7_NSGAII_syntax` | NSGA-II multi-objective optimisation syntax. |
| `chapter_AI_Mechanics_Problem7_TsaiWu_syntax.m` | `chapter_AI_Mechanics_Problem7_TsaiWu_syntax` | Tsai-Wu failure criterion syntax. |
| `chapter_AI_Mechanics_Problem8_arima_syntax.m` | `chapter_AI_Mechanics_Problem8_arima_syntax` | ARIMA model fitting and forecasting syntax. |
| `chapter_AI_Mechanics_Problem8_attention_viz_syntax.m` | `chapter_AI_Mechanics_Problem8_attention_viz_syntax` | Attention mechanism extraction and visualisation syntax. |
| `chapter_AI_Mechanics_Problem8_complete_code.m` | `chapter_AI_Mechanics_Problem8_complete_code` | Complete LSTM time series forecasting system. |
| `chapter_AI_Mechanics_Problem8_lstm_syntax.m` | `chapter_AI_Mechanics_Problem8_lstm_syntax` | LSTM network architecture syntax. |
| `chapter_AI_Mechanics_Problem8_windowing_syntax.m` | `chapter_AI_Mechanics_Problem8_windowing_syntax` | Sequence windowing for time series syntax. |
| `chapter_AI_Mechanics_Problem9_constitutive_syntax.m` | `chapter_AI_Mechanics_Problem9_constitutive_syntax` | Hyperelastic constitutive model implementation syntax. |
| `chapter_AI_Mechanics_Problem9_mcmc_syntax.m` | `chapter_AI_Mechanics_Problem9_mcmc_syntax` | Metropolis-Hastings MCMC implementation syntax. |
| `chapter_AI_Mechanics_Problem9_posterior_syntax.m` | `chapter_AI_Mechanics_Problem9_posterior_syntax` | Posterior distribution analysis syntax. |
| `chapter_AIforMechatronics_problem01_code.m` | `chapter_AIforMechatronics_problem01_code` | Custom CNN architecture for defect classification. |
| `chapter_AIforMechatronics_problem02_code.m` | `chapter_AIforMechatronics_problem02_code` | Transfer learning for bearing fault classification. |
| `chapter_AIforMechatronics_problem03_code.m` | `chapter_AIforMechatronics_problem03_code` | Hyperparameter optimisation using Bayesian optimisation. |
| `chapter_AIforMechatronics_problem04_code.m` | `chapter_AIforMechatronics_problem04_code` | Real-time inference optimisation for edge deployment. |
| `chapter_AIforMechatronics_problem05_code.m` | `chapter_AIforMechatronics_problem05_code` | Q-learning convergence analysis for path planning. |
| `chapter_AIforMechatronics_problem06_code.m` | `chapter_AIforMechatronics_problem06_code` | Multi-sensor fusion architecture comparison. |
| `chapter_AIforMechatronics_problem07_code.m` | `chapter_AIforMechatronics_problem07_code` | Object detection algorithm comparison and selection. |
| `chapter_AIforMechatronics_problem08_code.m` | `chapter_AIforMechatronics_problem08_code` | Time series prediction with LSTM networks. |
| `chapter_AIforMechatronics_problem09_code.m` | `chapter_AIforMechatronics_problem09_code` | Uncertainty quantification in neural network predictions. |
| `chapter_AIforMechatronics_problem10_code.m` | `chapter_AIforMechatronics_problem10_code` | Model compression and edge deployment pipeline. |
| `chapter_AIforMechatronics_problem11_code.m` | `chapter_AIforMechatronics_problem11_code` | Bio-inspired wind turbine blade optimisation. |
| `chapter_ES_code_problem1.m` | `chapter_ES_code_problem1` | Quantum State Tomography Implementation |
| `chapter_ES_code_problem10.m` | `chapter_ES_code_problem10` | Decentralised Gradient Descent |
| `chapter_ES_code_problem11.m` | `chapter_ES_code_problem11` | Human-Automation Teaming Simulation |
| `chapter_ES_code_problem12.m` | `chapter_ES_code_problem12` | Magnetic Suspension Balance Simulation |
| `chapter_ES_code_problem13.m` | `chapter_ES_code_problem13` | RL for Wind Farm Control |
| `chapter_ES_code_problem14.m` | `chapter_ES_code_problem14` | AI-Driven Optimal Design for Robotic Mobility Device |
| `chapter_ES_code_problem2.m` | `chapter_ES_code_problem2` | Parallel Monte Carlo Integration Implementation |
| `chapter_ES_code_problem3.m` | `chapter_ES_code_problem3` | Real-Time PID Controller Simulation with Performance Monitoring |
| `chapter_ES_code_problem4.m` | `chapter_ES_code_problem4` | Monte Carlo Integration for Multi-Dimensional Functions |
| `chapter_ES_code_problem5.m` | `chapter_ES_code_problem5` | Finite Element Analysis with Adaptive Mesh Refinement |
| `chapter_ES_code_problem6.m` | `chapter_ES_code_problem6` | Signal Processing with Time-Frequency Analysis |
| `chapter_ES_code_problem7.m` | `chapter_ES_code_problem7` | Adaptive Load Balancing for Parallel Computing |
| `chapter_ES_code_problem8.m` | `chapter_ES_code_problem8` | Hardware-in-the-Loop Co-simulation |
| `chapter_ES_code_problem9.m` | `chapter_ES_code_problem9` | Multi-Modal Scientific Visualization |
| `chapter_ExtInt_problem11_selfevolution.m` | `chapter_ExtInt_problem11_selfevolution` | Self-evolutionary AI development using AI-assisted programming. |
| `chapter_ExtInt_problem12_cad_integration.m` | `chapter_ExtInt_problem12_cad_integration` | MATLAB-based AI + CAD integration with bidirectional communication. |
| `chapter_ExtInt_problem13_cae_integration.m` | `chapter_ExtInt_problem13_cae_integration` | MATLAB-based AI + CAE integration with bidirectional communication. |
| `chapter_ExtInt_problem14_ai_engineer.m` | `chapter_ExtInt_problem14_ai_engineer` | MATLAB-based AI-Engineer managing CAD to CAE integration automation. |
| `chapter_ExtInt_problem1_mex.m` | `chapter_ExtInt_problem1_mex` | High-performance MEX file implementation for quantum chemistry. |
| `chapter_ExtInt_problem2_python.m` | `chapter_ExtInt_problem2_python` | Advanced Python-MATLAB integration for machine learning workflows. |
| `chapter_ExtInt_problem3_webservices.m` | `chapter_ExtInt_problem3_webservices` | Enterprise web services architecture for MATLAB functionality. |
| `chapter_ExtInt_problem4_iiot.m` | `chapter_ExtInt_problem4_iiot` | Industrial IoT integration using OPC UA and MQTT protocols. |
| `chapter_ExtInt_problem5_database.m` | `chapter_ExtInt_problem5_database` | Advanced database integration for big data analytics. |
| `chapter_ExtInt_problem6_multiagent.m` | `chapter_ExtInt_problem6_multiagent` | Multi-agent computational system for collaborative engineering design. |
| `chapter_ExtInt_problem7_mcp.m` | `chapter_ExtInt_problem7_mcp` | AI-enhanced Model Context Protocol implementation. |
| `chapter_ExtInt_problem8_pipeline.m` | `chapter_ExtInt_problem8_pipeline` | Cross-platform multi-language pipeline for scientific data processing. |
| `chapter_ExtInt_problem9_security.m` | `chapter_ExtInt_problem9_security` | Secure communication framework for distributed MATLAB computing. |
| `chapter_Math_problem10_solution.m` | `chapter_Math_problem10_solution` | Comprehensive optimisation implementation. |
| `chapter_Math_problem1_diff.m` | `chapter_Math_problem1_diff` | Numerical differentiation using finite differences. |
| `chapter_Math_problem1_solution.m` | `chapter_Math_problem1_solution` | Complete solution for rocket velocity analysis. |
| `chapter_Math_problem2_integral.m` | `chapter_Math_problem2_integral` | MATLAB adaptive quadrature. |
| `chapter_Math_problem2_simpson.m` | `chapter_Math_problem2_simpson` | Simpson's rule implementation. |
| `chapter_Math_problem2_solution.m` | `chapter_Math_problem2_solution` | Complete solution for spring work calculation. |
| `chapter_Math_problem2_trapz.m` | `chapter_Math_problem2_trapz` | Trapezoidal rule syntax. |
| `chapter_Math_problem3_basic.m` | `chapter_Math_problem3_basic` | Basic matrix operations. |
| `chapter_Math_problem3_decomp.m` | `chapter_Math_problem3_decomp` | Matrix decompositions. |
| `chapter_Math_problem3_solution.m` | `chapter_Math_problem3_solution` | Complete matrix analysis solution. |
| `chapter_Math_problem4_solution.m` | `chapter_Math_problem4_solution` | System of linear equations solution. |
| `chapter_Math_problem5_solution.m` | `chapter_Math_problem5_solution` | Eigenvalue and eigenvector computation. |
| `chapter_Math_problem6_solution.m` | `chapter_Math_problem6_solution` | Comprehensive polynomial curve fitting. |
| `chapter_Math_problem7_solution.m` | `chapter_Math_problem7_solution` | Comprehensive Newton-Raphson root finding implementation. |
| `chapter_Math_problem8_solution.m` | `chapter_Math_problem8_solution` | Comprehensive ODE solution methods. |
| `chapter_Math_problem9_solution.m` | `chapter_Math_problem9_solution` | Comprehensive Fourier analysis implementation. |
| `chapter_Problems_sol1.m` | `chapter_Problems_sol1` | Signal processing for AI applications |
| `chapter_Problems_sol2.m` | `chapter_Problems_sol2` | Exploratory data analysis for machine learning |
| `chapter_Problems_sol3.m` | `chapter_Problems_sol3` | Simple neural network implementation |
| `chapter_Problems_sol4_matlab.m` | `chapter_Problems_sol4_matlab` | MATLAB script for Python integration |
| `chapter_Problems_sol5.m` | `chapter_Problems_sol5` | Reproducible research framework |
| `chapter_Problems_sol6.m` | `chapter_Problems_sol6` | Interactive data visualisation app - key components |
| `chapter_SymbolicComputing_problem10_code.m` | `chapter_SymbolicComputing_problem10_code` | Quantum computing simulation with comprehensive symbolic operators. |
| `chapter_SymbolicComputing_problem1_code.m` | `chapter_SymbolicComputing_problem1_code` | Advanced symbolic manipulation system implementation. |
| `chapter_SymbolicComputing_problem2_code.m` | `chapter_SymbolicComputing_problem2_code` | Multi-variable calculus and optimisation implementation. |
| `chapter_SymbolicComputing_problem3_code.m` | `chapter_SymbolicComputing_problem3_code` | Symbolic differential equation system with AI enhancement. |
| `chapter_SymbolicComputing_problem4_code.m` | `chapter_SymbolicComputing_problem4_code` | Robotics inverse kinematics with comprehensive symbolic solutions. |
| `chapter_SymbolicComputing_problem5_code.m` | `chapter_SymbolicComputing_problem5_code` | Advanced circuit analysis with comprehensive symbolic methods. |
| `chapter_SymbolicComputing_problem6_code.m` | `chapter_SymbolicComputing_problem6_code` | Computational fluid dynamics with comprehensive symbolic preprocessing. |
| `chapter_SymbolicComputing_problem7_code.m` | `chapter_SymbolicComputing_problem7_code` | Digital signal processing with comprehensive symbolic filter design. |
| `chapter_SymbolicComputing_problem8_code.m` | `chapter_SymbolicComputing_problem8_code` | Structural engineering with comprehensive symbolic finite element methods. |
| `chapter_SymbolicComputing_problem9_code.m` | `chapter_SymbolicComputing_problem9_code` | Control systems design with comprehensive symbolic root locus analysis. |
| `code_comparison.m` | `code:comparison` | Model comparison function. |
| `code_compute_error.m` | `code:compute_error` | Error computation function. |
| `code_discrete_model.m` | `code:discrete_model` | Discrete spring-mass model. |
| `code_energy_function.m` | `code:energy_function` | Energy computation function. |
| `code_generate_matrix.m` | `code:generate_matrix` | Sparse matrix generation function. |
| `code_inverse_design.m` | `code:inverse_design` | AI-enhanced inverse design. |
| `code_memory_analysis.m` | `code:memory_analysis` | Memory usage analysis. |
| `code_mixed_precision.m` | `code:mixed_precision` | Mixed precision iterative refinement. |
| `code_mixedprecision_main.m` | `code:mixedprecision_main` | Main script for mixed precision eigenvalue solver. |
| `code_morphing_main.m` | `code:morphing_main` | Main script for active morphing simulation. |
| `code_single_precision.m` | `code:single_precision` | Single precision eigenvalue solver. |
| `code_visualisation.m` | `code:visualisation` | Visualisation function. |
| `code_visualise_results.m` | `code:visualise_results` | Results visualisation function. |
| `constrained_optimisation.m` | `constrained_optimisation` | Constrained Optimisation Problem |
| `finite_difference_bvp.m` | `finite_difference_bvp` | Finite Difference Method for BVP |
| `genetic_algorithms.m` | `genetic_algorithms` | Global Optimisation with Genetic Algorithms |
| `listing_problem1_ziegler_nichols.m` | `listing:problem1_ziegler_nichols` | Problem 1: Ziegler-Nichols PID tuning for chemical reactor temperature control with comprehensive stability and performance analysis. |
| `listing_problem2_pole_placement.m` | `listing:problem2_pole_placement` | Problem 2: State-space pole placement design for DC motor position control with full controllability analysis, Ackermann's formula implementation, and comprehensive robustness validation. |
| `listing_problem3_leadlag.m` | `listing:problem3_leadlag` | Problem 3: Lead-lag compensator design for aircraft pitch control with comprehensive frequency-domain analysis, Bode plot visualization, and performance comparison between uncompensated, lead-only, lag-only, and combined lead-lag configurations. |
| `listing_problem4_mpc.m` | `listing:problem4_mpc` | Problem 4: Model Predictive Control for constrained CSTR temperature regulation with QP optimization, receding horizon implementation, and comprehensive comparison against unconstrained LQR showing explicit constraint handling and setpoint tracking. |
| `listing_problem5_hinf.m` | `listing:problem5_hinf` | Problem 5: H-infinity robust control for aircraft pitch with mixed-sensitivity design, uncertainty modeling, and comparison against LQG showing improved robustness margins and worst-case performance. |
| `listing_problem6_smc.m` | `listing:problem6_smc` | Problem 6: Sliding mode control for 2-DOF robot manipulator with payload uncertainty, chattering analysis, and comparison against PD control showing superior robustness to parameter variations. |
| `listing_problem7_mrac.m` | `listing:problem7_mrac` | Problem 7: Model reference adaptive control for DC motor with unknown inertia and friction, showing parameter convergence under persistent excitation and tracking performance comparison against fixed-gain controller. |
| `listing_problem8_fuzzy.m` | `listing:problem8_fuzzy` | Problem 8: Fuzzy logic control for inverted pendulum on cart, including custom fuzzy inference engine, membership function design, rule base, comparison with LQR, and robustness analysis under parameter variations. |
| `listing_problem9_nn.m` | `listing:problem9_nn` | Problem 9: Neural network control for nonlinear plant identification and control, including NN class, backpropagation training, Van der Pol oscillator identification, inverse model controller, comparison with PID, and robustness analysis. |
| `lst_adv_prob01.m` | `lst:adv_prob01` | Rocket velocity analysis via numerical differentiation |
| `lst_adv_prob02.m` | `lst:adv_prob02` | Work done by variable force. |
| `lst_adv_prob03.m` | `lst:adv_prob03` | Lotka-Volterra predator-prey simulation. |
| `lst_adv_prob04.m` | `lst:adv_prob04` | Electrical circuit analysis. |
| `lst_adv_prob05.m` | `lst:adv_prob05` | Multi-storey building vibration analysis. |
| `lst_adv_prob06.m` | `lst:adv_prob06` | Optimal cylindrical tank design. |
| `lst_adv_prob07.m` | `lst:adv_prob07` | Temperature polynomial fitting |
| `lst_adv_prob08.m` | `lst:adv_prob08` | Quality control statistical analysis |
| `lst_adv_prob09.m` | `lst:adv_prob09` | Chemical reactor temperature root-finding |
| `lst_adv_prob10.m` | `lst:adv_prob10` | Suspension bridge cable analysis |
| `lst_problem12.m` | `lst:problem12` | Machine learning topology optimisation with conditional GAN. |
| `lst_problem13.m` | `lst:problem13` | AI-enhanced aircraft FEA with Gaussian process surrogates and UQ. |
| `lst_problem14.m` | `lst:problem14` | Patient-specific biomechanical modelling with deep neural networks. |
| `lst_problem15.m` | `lst:problem15` | Reinforcement learning control of thermoacoustic combustion instabilities. |
| `lst_problem16.m` | `lst:problem16` | Multi-objective optimisation of automotive gearbox design using NSGA-III. |
| `lst_problem17.m` | `lst:problem17` | EV powertrain optimisation: Tesla Model Y case study with motor-battery-transmission co-design. |
| `lst_problem18.m` | `lst:problem18` | Humanoid robot motion planning: ZMP-based walking with whole-body IK and push recovery. |
| `lst_problem19.m` | `lst:problem19` | CORLEO hybrid wheeled-legged rover: terrain-adaptive locomotion with mode transitions. |
| `lst_problem20_tmsr.m` | `lst:problem20_tmsr` | Thorium Molten-Salt Reactor: Neutronics, Breeding, Corrosion and Economic Optimisation |
| `newton_cotes.m` | `newton_cotes` | Composite Newton-Cotes Rules |
| `nonlinear_systems.m` | `nonlinear_systems` | Newton's Method for Systems of Nonlinear Equations |
| `poly_root_deflation.m` | `poly_root_deflation` | Polynomial Root Finding with Deflation |
| `prob10_code.m` | `prob10_code` | Advanced multi-panel data dashboard. |
| `prob10_complete.m` | `prob10_complete` | Problem 10: Multi-GPU Scaling Analysis. |
| `prob10_dashboard_syntax.m` | `prob10_dashboard_syntax` | Multi-panel dashboard syntax. |
| `prob11_code.m` | `prob11_code` | LSTM-based traffic prediction with attention mechanism. |
| `prob11_lstm_syntax.m` | `prob11_lstm_syntax` | LSTM layer syntax for time series prediction. |
| `prob12_code.m` | `prob12_code` | Benford's Law analysis for fraud detection. |
| `prob12_extract_syntax.m` | `prob12_extract_syntax` | First digit extraction syntax. |
| `prob13_code.m` | `prob13_code` | Shoelace Formula implementation for polygon area calculation. |
| `prob13_shoelace_syntax.m` | `prob13_shoelace_syntax` | Shoelace Formula syntax. |
| `prob14_code.m` | `prob14_code` | Bio-PCM thermal simulation for wearable thermal management. |
| `prob14_heat_syntax.m` | `prob14_heat_syntax` | Heat diffusion equation for PCM thermal modelling. |
| `prob1_amdahl_basic.m` | `prob1_amdahl_basic` | Amdahl's Law speedup calculation. |
| `prob1_code.m` | `prob1_code` | Comprehensive statistical analysis of tensile strength data. |
| `prob1_complete.m` | `prob1_complete` | Problem 1: Complete Amdahl's Law Analysis for Deep Learning. |
| `prob1_histogram_syntax.m` | `prob1_histogram_syntax` | Histogram generation syntax. |
| `prob2_code.m` | `prob2_code` | Polynomial regression with comprehensive model selection. |
| `prob2_complete.m` | `prob2_complete` | Problem 2: Complete Memory Bandwidth Bottleneck Analysis. |
| `prob2_intensity_basic.m` | `prob2_intensity_basic` | Arithmetic intensity computation. |
| `prob2_polyfit_syntax.m` | `prob2_polyfit_syntax` | Polynomial fitting syntax. |
| `prob3_code.m` | `prob3_code` | 3D surface fitting for CVD process optimisation. |
| `prob3_complete.m` | `prob3_complete` | Problem 3: Multi-GPU Scaling Analysis. |
| `prob3_interp_syntax.m` | `prob3_interp_syntax` | Surface interpolation syntax. |
| `prob4_code.m` | `prob4_code` | Heat map visualisation with hierarchical clustering for correlation analysis. |
| `prob4_complete.m` | `prob4_complete` | Problem 4: Batch Size Impact Analysis. |
| `prob4_heatmap_syntax.m` | `prob4_heatmap_syntax` | Heat map generation syntax. |
| `prob5_code.m` | `prob5_code` | Polar plots and radar charts for anisotropic material characterisation. |
| `prob5_complete.m` | `prob5_complete` | Problem 5: Precision Format Analysis. |
| `prob5_polar_syntax.m` | `prob5_polar_syntax` | Polar plot syntax. |
| `prob6_animation_syntax.m` | `prob6_animation_syntax` | Animation generation syntax. |
| `prob6_code.m` | `prob6_code` | Animation of cantilever beam vibration. |
| `prob6_complete.m` | `prob6_complete` | Problem 6: Dropout Regularization Analysis. |
| `prob7_code.m` | `prob7_code` | Vector field visualisation for flow around cylinder. |
| `prob7_complete.m` | `prob7_complete` | Problem 7: Data Augmentation Analysis. |
| `prob7_vector_syntax.m` | `prob7_vector_syntax` | Vector field visualisation syntax. |
| `prob8_code.m` | `prob8_code` | Statistical distribution and probability plot analysis. |
| `prob8_complete.m` | `prob8_complete` | Problem 8: Transfer Learning Analysis. |
| `prob8_prob_syntax.m` | `prob8_prob_syntax` | Probability plot syntax. |
| `prob9_code.m` | `prob9_code` | Parametric curves and mathematical art visualisation. |
| `prob9_complete.m` | `prob9_complete` | Problem 9: Gradient Clipping Analysis. |
| `prob9_parametric_syntax.m` | `prob9_parametric_syntax` | Parametric curve plotting syntax. |
| `problem10_code.m` | `problem10_code` | Stakeholder-Informed Ethical Framework for Demand Response |
| `problem11_complete.m` | `problem11_complete` | Complete solution for Problem 11: PINN for structured light optimisation. |
| `problem12_complete.m` | `problem12_complete` | Complete solution for Problem 12: Topology optimisation for aerospike cooling. |
| `problem1_code.m` | `problem1_code` | Bayesian Uncertainty Quantification for Transformer DGA Analysis |
| `problem1_complete.m` | `problem1_complete` | Complete solution for Problem 1: Polynomial regression for Hooke's law. |
| `problem2_code.m` | `problem2_code` | Fairness Analysis in EV Charging Infrastructure Allocation |
| `problem2_complete.m` | `problem2_complete` | Complete solution for Problem 2: Neural network for Wien's law. |
| `problem3_code.m` | `problem3_code` | Differential Privacy for Distribution Network State Estimation |
| `problem4_code.m` | `problem4_code` | Adversarial Robustness for PV Fault Detection |
| `problem5_code.m` | `problem5_code` | Multi-Objective Ethical Optimisation for Microgrid EMS |
| `problem6_code.m` | `problem6_code` | Conformal Prediction for Wind Power Forecasting |
| `problem7_code.m` | `problem7_code` | Intersectional Fairness in Building Energy Management |
| `problem8_code.m` | `problem8_code` | Privacy-Preserving Federated Learning for DER Forecasting |
| `problem9_code.m` | `problem9_code` | Certified Adversarial Robustness for Power System Security |
| `robust_interpolation.m` | `robust_interpolation` | Spline Interpolation for Data with Outliers |
| `stiff_ode_solvers.m` | `stiff_ode_solvers` | Stiff ODE Solver Comparison |
