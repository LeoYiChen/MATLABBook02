%% Appendix02-FAQs_code_067.m
% Basic Trigonometric Calculations in MATLAB
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Basic trigonometric calculations (radians are default in MATLAB)
% Convert degrees to radians (essential for accurate results)
angle_deg = 30; % 30 degrees
angle_rad = deg2rad(angle_deg); % MATLAB built-in unit conversion

% Calculate core trigonometric values
sin_val = sin(angle_rad);    % Sine of 30뿯½ (expected: 0.5)
cos_val = cos(angle_rad);    % Cosine of 30뿯½ (expected: √3/2 ≈ 0.866)
tan_val = tan(angle_rad);    % Tangent of 30뿯½ (expected: 1/√3 ≈ 0.577)

% Display formatted results
fprintf('Sine of %d뿯½ = %.4f\n', angle_deg, sin_val);
fprintf('Cosine of %d뿯½ = %.4f\n', angle_deg, cos_val);
fprintf('Tangent of %d뿯½ = %.4f\n', angle_deg, tan_val);

% Inverse trigonometric function (convert ratio back to angle)
inverse_angle = rad2deg(asin(sin_val)); % Convert radians to degrees
fprintf('Inverse sine of %.4f = %d뿯½\n', sin_val, inverse_angle);
