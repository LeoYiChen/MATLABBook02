%% listing_problem3_leadlag.m
% Problem 3: Lead-lag compensator design for aircraft pitch control with comprehensive frequency-domain analysis, Bode plot visualization, and performance comparison between uncompensated, lead-only, lag-only, and combined lead-lag configurations.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem3_leadlag
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 3 - Lead-Lag Compensator Design
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: Design lead-lag compensator for aircraft pitch control to
%              meet phase margin, gain margin, bandwidth, and steady-state
%              error specifications. Comprehensive Bode/step analysis.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 3: Lead-Lag Compensator for Aircraft Pitch Control\n');
fprintf('==================================================================\n\n');

%% Plant Transfer Function
fprintf('=== Plant Transfer Function ===\n');

% G(s) = 50 / [s(s+5)(s+10)]
num_G = 50;
den_G = conv([1 0], conv([1 5], [1 10]));

G = tf(num_G, den_G);

fprintf('Plant G(s):\n');
disp(G);

% Extract poles and zeros
poles_G = pole(G);
zeros_G = zero(G);

fprintf('Open-loop poles:\n');
for idx = 1:length(poles_G)
    if abs(imag(poles_G(idx))) < 1e-6
        fprintf('  p_%d = %.4f (real)\n', idx, real(poles_G(idx)));
    else
        fprintf('  p_%d = %.4f %+.4fi\n', idx, real(poles_G(idx)), imag(poles_G(idx)));
    end
end

if isempty(zeros_G)
    fprintf('Open-loop zeros: None\n\n');
else
    fprintf('Open-loop zeros:\n');
    for idx = 1:length(zeros_G)
        fprintf('  z_%d = %.4f\n', idx, zeros_G(idx));
    end
    fprintf('\n');
end

%% Design Specifications
fprintf('=== Design Specifications ===\n');

PM_spec = 50;        % Phase margin (degrees)
GM_spec_dB = 10;     % Gain margin (dB)
wBW_spec = 10;       % Bandwidth (rad/s)
Kv_spec = 10;        % Velocity constant (1/s)
ess_ramp_spec = 0.1; % Steady-state error for unit ramp (rad)

fprintf('Phase Margin (PM): >= %.0f degrees\n', PM_spec);
fprintf('Gain Margin (GM): >= %.0f dB\n', GM_spec_dB);
fprintf('Bandwidth: >= %.0f rad/s\n', wBW_spec);
fprintf('Velocity constant (Kv): >= %.0f s^(-1)\n', Kv_spec);
fprintf('Steady-state error (unit ramp): <= %.2f rad\n\n', ess_ramp_spec);

%% Uncompensated System Analysis
fprintf('=== Uncompensated System Analysis ===\n');

% Frequency response
[mag_uncomp, phase_uncomp, wout_uncomp] = bode(G, logspace(-2, 2, 500));
mag_uncomp_dB = 20*log10(squeeze(mag_uncomp));
phase_uncomp_deg = squeeze(phase_uncomp);

% Stability margins
[Gm_uncomp, Pm_uncomp, Wgc_uncomp, Wpc_uncomp] = margin(G);

fprintf('Crossover frequency (wc): %.4f rad/s\n', Wpc_uncomp);
fprintf('Phase margin (PM): %.2f degrees\n', Pm_uncomp);
if isinf(Gm_uncomp)
    fprintf('Gain margin (GM): Infinite (no phase crossover)\n');
else
    fprintf('Gain margin (GM): %.2f dB at %.4f rad/s\n', 20*log10(Gm_uncomp), Wgc_uncomp);
end

% Velocity constant
Kv_uncomp = dcgain(G * tf([1 0], 1));
fprintf('Velocity constant (Kv): %.4f s^(-1)\n', Kv_uncomp);
fprintf('Steady-state error (unit ramp): %.4f rad\n\n', 1/Kv_uncomp);

% Step response
[y_uncomp, t_uncomp] = step(G / dcgain(G), 15);  % Normalize for unity DC gain
stepInfo_uncomp = stepinfo(G / dcgain(G));

fprintf('Step response metrics (uncompensated):\n');
fprintf('  Rise time: %.4f s\n', stepInfo_uncomp.RiseTime);
fprintf('  Settling time: %.4f s\n', stepInfo_uncomp.SettlingTime);
fprintf('  Overshoot: %.2f %%\n', stepInfo_uncomp.Overshoot);
fprintf('  Peak value: %.4f\n\n', stepInfo_uncomp.Peak);

% Specification check
fprintf('Specification Status (UNCOMPENSATED):\n');
if Pm_uncomp >= PM_spec
    fprintf('  PM: PASS (%.2f >= %.0f deg)\n', Pm_uncomp, PM_spec);
else
    fprintf('  PM: FAIL (%.2f < %.0f deg) -> Need +%.2f deg\n', Pm_uncomp, PM_spec, PM_spec - Pm_uncomp);
end

if Kv_uncomp >= Kv_spec
    fprintf('  Kv: PASS (%.4f >= %.0f)\n', Kv_uncomp, Kv_spec);
else
    fprintf('  Kv: FAIL (%.4f < %.0f) -> Need %.1fx increase\n\n', Kv_uncomp, Kv_spec, Kv_spec/Kv_uncomp);
end

%% Lead Compensator Design
fprintf('=== Lead Compensator Design ===\n');

% Required phase lead (with safety margin)
phi_required = (PM_spec - Pm_uncomp) + 10;  % Add 10 deg margin
fprintf('Required phase lead: %.2f degrees (includes 10 deg margin)\n', phi_required);

% Calculate alpha
alpha_lead = (1 + sind(phi_required)) / (1 - sind(phi_required));
fprintf('Calculated alpha: %.4f\n', alpha_lead);

% Round to practical value
alpha_lead = round(alpha_lead);
fprintf('Practical alpha: %.0f\n', alpha_lead);

% Actual maximum phase lead
phi_max = asind((alpha_lead - 1) / (alpha_lead + 1));
fprintf('Actual maximum phase lead: %.2f degrees\n', phi_max);

% Magnitude contribution at omega_m
mag_at_wm_dB = 10*log10(alpha_lead);
fprintf('Magnitude at omega_m: %.2f dB\n', mag_at_wm_dB);

% Find new crossover frequency (target ~8 rad/s for bandwidth spec)
wc_target = 8;
fprintf('Target new crossover: %.0f rad/s\n', wc_target);

% Place omega_m at target crossover
wm_lead = wc_target;
fprintf('Omega_m (max phase lead): %.2f rad/s\n', wm_lead);

% Calculate zero and pole
z_lead = wm_lead / sqrt(alpha_lead);
p_lead = wm_lead * sqrt(alpha_lead);

fprintf('Lead zero: z1 = %.4f rad/s\n', z_lead);
fprintf('Lead pole: p1 = %.4f rad/s\n', p_lead);

% Gain to achieve crossover at wc_target
% Evaluate |G(jwc)| and |Glead(jwc)|
[mag_G_at_wc, ~] = bode(G, wc_target);
mag_G_at_wc = squeeze(mag_G_at_wc);

[mag_lead_at_wc, ~] = bode(tf([1 z_lead], [1 p_lead]), wc_target);
mag_lead_at_wc = squeeze(mag_lead_at_wc);

K_lead = 1 / (mag_G_at_wc * mag_lead_at_wc);
fprintf('Lead gain: K_lead = %.4f\n', K_lead);

% Lead compensator transfer function
Gc_lead = K_lead * tf([1 z_lead], [1 p_lead]);

fprintf('\nLead compensator Gc_lead(s):\n');
disp(Gc_lead);

% Analyze system with lead only
G_lead_only = Gc_lead * G;

[Gm_lead, Pm_lead, Wgc_lead, Wpc_lead] = margin(G_lead_only);
Kv_lead = dcgain(G_lead_only * tf([1 0], 1));

fprintf('Performance with LEAD only:\n');
fprintf('  Crossover frequency: %.4f rad/s\n', Wpc_lead);
fprintf('  Phase margin: %.2f degrees\n', Pm_lead);
fprintf('  Gain margin: %.2f dB\n', 20*log10(Gm_lead));
fprintf('  Velocity constant: %.4f s^(-1)\n', Kv_lead);
fprintf('  Steady-state error (ramp): %.4f rad\n\n', 1/Kv_lead);

%% Lag Compensator Design
fprintf('=== Lag Compensator Design ===\n');

% Required low-frequency gain increase
beta_required = Kv_spec / Kv_lead;
fprintf('Required beta (Kv increase): %.4f\n', beta_required);

% Choose conservative value
beta_lag = ceil(beta_required);
fprintf('Chosen beta: %.0f\n', beta_lag);

% Place zero one decade below crossover
z_lag = Wpc_lead / 10;
fprintf('Lag zero: z2 = %.4f rad/s (wc/10)\n', z_lag);

% Calculate pole
p_lag = z_lag / beta_lag;
fprintf('Lag pole: p2 = %.4f rad/s\n', p_lag);

% Verify phase contribution at crossover
phase_lag_at_wc = atan2d(Wpc_lead, z_lag) - atan2d(Wpc_lead, p_lag);
fprintf('Phase contribution at wc: %.2f degrees (should be minimal)\n', phase_lag_at_wc);

if abs(phase_lag_at_wc) > 5
    fprintf('WARNING: Lag phase contribution exceeds -5 degrees!\n');
end

% Lag compensator transfer function
Gc_lag = tf([1 z_lag], [1 p_lag]);

fprintf('\nLag compensator Gc_lag(s):\n');
disp(Gc_lag);

fprintf('DC gain of lag: %.4f (should equal beta)\n\n', dcgain(Gc_lag));

%% Combined Lead-Lag Compensator
fprintf('=== Combined Lead-Lag Compensator ===\n');

Gc_leadlag = Gc_lead * Gc_lag;

fprintf('Lead-Lag compensator Gc(s):\n');
disp(Gc_leadlag);

% Simplify for display
[num_c, den_c] = tfdata(Gc_leadlag, 'v');
fprintf('Gc(s) = %.4f * (s + %.4f)(s + %.4f) / [(s + %.4f)(s + %.4f)]\n\n', ...
    num_c(1), -roots(num_c), -roots(den_c));

% Analyze compensated system
G_compensated = Gc_leadlag * G;

[Gm_comp, Pm_comp, Wgc_comp, Wpc_comp] = margin(G_compensated);
Kv_comp = dcgain(G_compensated * tf([1 0], 1));

% Bandwidth (-3dB point)
[mag_comp, ~, w_comp] = bode(feedback(G_compensated, 1), logspace(-1, 2, 1000));
mag_comp_dB = 20*log10(squeeze(mag_comp));
wBW_idx = find(mag_comp_dB <= -3, 1, 'first');
if ~isempty(wBW_idx)
    wBW_comp = w_comp(wBW_idx);
else
    wBW_comp = NaN;
end

fprintf('Performance with LEAD-LAG:\n');
fprintf('  Crossover frequency: %.4f rad/s\n', Wpc_comp);
fprintf('  Phase margin: %.2f degrees\n', Pm_comp);
fprintf('  Gain margin: %.2f dB at %.4f rad/s\n', 20*log10(Gm_comp), Wgc_comp);
fprintf('  Velocity constant: %.4f s^(-1)\n', Kv_comp);
fprintf('  Steady-state error (ramp): %.4f rad\n', 1/Kv_comp);
fprintf('  Bandwidth (-3dB): %.4f rad/s\n\n', wBW_comp);

% Specification check
fprintf('Specification Status (COMPENSATED):\n');
status_PM = Pm_comp >= PM_spec;
status_GM = 20*log10(Gm_comp) >= GM_spec_dB;
status_wBW = wBW_comp >= wBW_spec;
status_Kv = Kv_comp >= Kv_spec;
status_ess = (1/Kv_comp) <= ess_ramp_spec;

fprintf('  PM: %s (%.2f %s %.0f deg)\n', iif(status_PM, 'PASS', 'FAIL'), Pm_comp, iif(status_PM, '>=', '<'), PM_spec);
fprintf('  GM: %s (%.2f %s %.0f dB)\n', iif(status_GM, 'PASS', 'FAIL'), 20*log10(Gm_comp), iif(status_GM, '>=', '<'), GM_spec_dB);
fprintf('  wBW: %s (%.2f %s %.0f rad/s)\n', iif(status_wBW, 'PASS', 'FAIL'), wBW_comp, iif(status_wBW, '>=', '<'), wBW_spec);
fprintf('  Kv: %s (%.2f %s %.0f s^-1)\n', iif(status_Kv, 'PASS', 'FAIL'), Kv_comp, iif(status_Kv, '>=', '<'), Kv_spec);
fprintf('  e_ss: %s (%.4f %s %.2f rad)\n\n', iif(status_ess, 'PASS', 'FAIL'), 1/Kv_comp, iif(status_ess, '<=', '>'), ess_ramp_spec);

%% Visualization: Bode Plots
fprintf('=== Generating Bode Plots ===\n');

figure('Position', [50, 50, 1600, 900]);

% Uncompensated
subplot(2,2,1);
margin(G);
grid on;
title('Bode Plot: Uncompensated $G(s)$', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'southwest');

% Lead compensator only
subplot(2,2,2);
margin(Gc_lead);
grid on;
title('Bode Plot: Lead Compensator $G_c^{lead}(s)$', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'southwest');

% System with lead only
subplot(2,2,3);
margin(G_lead_only);
grid on;
title('Bode Plot: $G_c^{lead}(s) G(s)$', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'southwest');

% Fully compensated system
subplot(2,2,4);
margin(G_compensated);
grid on;
title('Bode Plot: $G_c(s) G(s)$ (Lead-Lag)', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'southwest');

saveas(gcf, 'Problem03_Bode_Comparison.fig');
saveas(gcf, 'Problem03_Bode_Comparison.eps', 'epsc');
saveas(gcf, 'Problem03_Bode_Comparison.jpg');
fprintf('Saved: Problem03_Bode_Comparison.fig/.eps/.jpg\n\n');

%% Comparison: All Configurations
fprintf('=== Step Response Comparison ===\n');

% Create closed-loop systems
T_uncomp = feedback(G, 1);
T_lead = feedback(G_lead_only, 1);
T_lag = feedback(Gc_lag * G, 1);  % Lag only (for comparison)
T_leadlag = feedback(G_compensated, 1);

figure('Position', [100, 100, 1400, 800]);

% Step responses
subplot(2,3,1);
step(T_uncomp, T_lead, T_lag, T_leadlag, 5);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Output', 'Interpreter', 'latex', 'FontSize', 11);
title('Step Response Comparison', 'Interpreter', 'latex', 'FontSize', 13);
legend('Uncompensated', 'Lead Only', 'Lag Only', 'Lead-Lag', 'Interpreter', 'latex', 'Location', 'best');

% Ramp responses (integrate step responses)
subplot(2,3,2);
t_ramp = linspace(0, 10, 1000);
r_ramp = t_ramp;  % Unit ramp

% Simulate ramp responses
[y_uncomp_ramp, ~] = lsim(T_uncomp, r_ramp, t_ramp);
[y_leadlag_ramp, ~] = lsim(T_leadlag, r_ramp, t_ramp);

plot(t_ramp, r_ramp, 'k-', 'LineWidth', 1.5, 'DisplayName', 'Reference');
hold on;
plot(t_ramp, y_uncomp_ramp, 'r-', 'LineWidth', 1.2, 'DisplayName', 'Uncompensated');
plot(t_ramp, y_leadlag_ramp, 'b-', 'LineWidth', 1.2, 'DisplayName', 'Lead-Lag');
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Output', 'Interpreter', 'latex', 'FontSize', 11);
title('Ramp Response Comparison', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');

% Ramp error
subplot(2,3,3);
e_uncomp_ramp = r_ramp - y_uncomp_ramp';
e_leadlag_ramp = r_ramp - y_leadlag_ramp';

plot(t_ramp, e_uncomp_ramp, 'r-', 'LineWidth', 1.2, 'DisplayName', 'Uncompensated');
hold on;
plot(t_ramp, e_leadlag_ramp, 'b-', 'LineWidth', 1.2, 'DisplayName', 'Lead-Lag');
yline(ess_ramp_spec, 'g-', 'Spec Limit', 'LineWidth', 1.5, 'Interpreter', 'latex');
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Tracking Error', 'Interpreter', 'latex', 'FontSize', 11);
title('Ramp Tracking Error', 'Interpreter', 'latex', 'FontSize', 13);
legend('Interpreter', 'latex', 'Location', 'best');

fprintf('Steady-state ramp error:\n');
fprintf('  Uncompensated: %.4f rad\n', e_uncomp_ramp(end));
fprintf('  Lead-Lag: %.4f rad\n\n', e_leadlag_ramp(end));

% Root locus comparison
subplot(2,3,4);
rlocus(G);
grid on;
title('Root Locus: Uncompensated', 'Interpreter', 'latex', 'FontSize', 13);

subplot(2,3,5);
rlocus(Gc_leadlag * G);
grid on;
title('Root Locus: Lead-Lag Compensated', 'Interpreter', 'latex', 'FontSize', 13);

% Nyquist plot
subplot(2,3,6);
nyquist(G, G_compensated);
grid on;
title('Nyquist Plot Comparison', 'Interpreter', 'latex', 'FontSize', 13);
legend('Uncompensated', 'Lead-Lag', 'Interpreter', 'latex', 'Location', 'best');

saveas(gcf, 'Problem03_Response_Comparison.fig');
saveas(gcf, 'Problem03_Response_Comparison.eps', 'epsc');
saveas(gcf, 'Problem03_Response_Comparison.jpg');
fprintf('Saved: Problem03_Response_Comparison.fig/.eps/.jpg\n\n');

%% Performance Metrics Summary Table
fprintf('=== Performance Summary Table ===\n\n');

configs = {'Uncompensated', 'Lead Only', 'Lag Only', 'Lead-Lag'};
systems = {T_uncomp, T_lead, T_lag, T_leadlag};

table_data = zeros(4, 6);

for idx = 1:4
    info = stepinfo(systems{idx});
    
    % Extract metrics (handle missing fields)
    if isfield(info, 'RiseTime')
        table_data(idx, 1) = info.RiseTime;
    else
        table_data(idx, 1) = NaN;
    end
    
    if isfield(info, 'SettlingTime')
        table_data(idx, 2) = info.SettlingTime;
    else
        table_data(idx, 2) = NaN;
    end
    
    if isfield(info, 'Overshoot')
        table_data(idx, 3) = info.Overshoot;
    else
        table_data(idx, 3) = 0;
    end
    
    % Phase and gain margins
    if idx == 1
        [gm, pm, ~, ~] = margin(G);
        table_data(idx, 4) = pm;
        table_data(idx, 5) = 20*log10(gm);
    elseif idx == 2
        [gm, pm, ~, ~] = margin(G_lead_only);
        table_data(idx, 4) = pm;
        table_data(idx, 5) = 20*log10(gm);
    elseif idx == 3
        [gm, pm, ~, ~] = margin(Gc_lag * G);
        table_data(idx, 4) = pm;
        table_data(idx, 5) = 20*log10(gm);
    else
        table_data(idx, 4) = Pm_comp;
        table_data(idx, 5) = 20*log10(Gm_comp);
    end
    
    % Velocity constant
    if idx == 1
        table_data(idx, 6) = Kv_uncomp;
    elseif idx == 2
        table_data(idx, 6) = Kv_lead;
    elseif idx == 3
        kv_lag = dcgain(Gc_lag * G * tf([1 0], 1));
        table_data(idx, 6) = kv_lag;
    else
        table_data(idx, 6) = Kv_comp;
    end
end

% Display table
fprintf('Configuration   |  Tr (s) |  Ts (s) | Mp (%%) |  PM (deg) | GM (dB) |  Kv (s^-1)\n');
fprintf('--------|-----|-----|----|------|-----|------\n');
for idx = 1:4
    fprintf('%-15s | %7.3f | %7.3f | %6.2f | %9.2f | %7.2f | %10.4f\n', ...
        configs{idx}, table_data(idx, 1), table_data(idx, 2), table_data(idx, 3), ...
        table_data(idx, 4), table_data(idx, 5), table_data(idx, 6));
end
fprintf('--------|-----|-----|----|------|-----|------\n');
fprintf('Specification   |    -   |   -    |  <16   |    >=50   |  >=10   |    >=10   \n');
fprintf('--------|-----|-----|----|------|-----|------\n\n');

fprintf('=== Problem 3 Complete ===\n');

% Helper function for conditional formatting
function result = iif(condition, true_val, false_val)
    if condition
        result = true_val;
    else
        result = false_val;
    end
end
