%% C0201Introduction_code_014.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Profile your code
profile on;
myComplexFunction(inputs);
profile viewer;

% Or programmatically access profile results
profileResults = profile('info');

% Identify most time-consuming functions
[~, sortIdx] = sort([profileResults.FunctionTable.TotalTime], 'descend');
topFunctions = profileResults.FunctionTable(sortIdx(1:5));

fprintf('Top 5 time-consuming functions:\n');
for i = 1:5
    fprintf('%2*d. %s: %.3f seconds (%.1f%% total)\n', i, ...
        topFunctions(i).FunctionName, topFunctions(i).TotalTime, ...
        100 * topFunctions(i).TotalTime / profileResults.ClockTime);
end
