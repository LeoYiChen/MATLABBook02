%% chapter_AIforMechatronics_problem02_code.m
% Transfer learning for bearing fault classification.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AIforMechatronics_problem02_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 2: Transfer Learning with Limited Training Data
% Author: Dr Yi Chen
% Purpose: Implement transfer learning using ResNet-50 for fault classification
% MATLAB Version: R2023b or later
% Required Toolboxes: Deep Learning Toolbox, Signal Processing Toolbox
% Date: 2024
% Version: 1.0

%% Clear environment
clear all;
close all;
clc;

%% Step 1: Load pre-trained ResNet-50
fprintf('=== Transfer Learning for Bearing Fault Classification ===\n\n');
fprintf('Step 1: Loading pre-trained ResNet-50...\n');

% Load pre-trained network
networkPretrained = resnet50;

% Display network structure summary
fprintf('  ResNet-50 loaded successfully\n');
fprintf('  Total layers: %d\n', length(networkPretrained.Layers));
fprintf('  Input size: %dx%dx%d\n', networkPretrained.Layers(1).InputSize);

%% Step 2: Generate synthetic bearing fault dataset
fprintf('\nStep 2: Generating bearing fault spectrograms...\n');

% Dataset parameters
imageSize = [224, 224, 3]; % ResNet-50 input size
numClasses = 4;
classNames = {'Healthy', 'InnerRaceFault', 'OuterRaceFault', 'BallFault'};
samplesPerClass = 50; % Limited data scenario

% Sampling parameters
samplingFrequency = 12000; % Hz
signalDuration = 1; % second
timeVector = 0:(1/samplingFrequency):(signalDuration - 1/samplingFrequency);

% Generate spectrograms for each fault condition
allImages = [];
allLabels = [];

for classIdx = 1:numClasses
    for sampleIdx = 1:samplesPerClass
        % Generate synthetic vibration signal
        switch classIdx
            case 1 % Healthy bearing - low amplitude broadband
                signalAmplitude = 0.1;
                vibrationSignal = signalAmplitude * randn(size(timeVector));
                
            case 2 % Inner race fault - impulses at shaft frequency
                shaftFrequency = 25 + 5 * randn(); % Hz with variation
                impulsePeriod = 1 / shaftFrequency;
                impulseLocations = 0:impulsePeriod:signalDuration;
                vibrationSignal = zeros(size(timeVector));
                for impulseTime = impulseLocations
                    impulseIdx = find(timeVector >= impulseTime, 1);
                    if impulseIdx <= length(timeVector)
                        % Damped sinusoid impulse response
                        impulseResponse = exp(-50*(timeVector(impulseIdx:end) - ...
                            impulseTime)) .* sin(2*pi*1000*(timeVector(impulseIdx:end) - ...
                            impulseTime));
                        vibrationSignal(impulseIdx:end) = ...
                            vibrationSignal(impulseIdx:end) + 0.5 * impulseResponse;
                    end
                end
                vibrationSignal = vibrationSignal + 0.05 * randn(size(timeVector));
                
            case 3 % Outer race fault - impulses at cage frequency
                cageFrequency = 10 + 2 * randn(); % Hz
                impulsePeriod = 1 / cageFrequency;
                impulseLocations = 0:impulsePeriod:signalDuration;
                vibrationSignal = zeros(size(timeVector));
                for impulseTime = impulseLocations
                    impulseIdx = find(timeVector >= impulseTime, 1);
                    if impulseIdx <= length(timeVector)
                        impulseResponse = exp(-40*(timeVector(impulseIdx:end) - ...
                            impulseTime)) .* sin(2*pi*800*(timeVector(impulseIdx:end) - ...
                            impulseTime));
                        vibrationSignal(impulseIdx:end) = ...
                            vibrationSignal(impulseIdx:end) + 0.6 * impulseResponse;
                    end
                end
                vibrationSignal = vibrationSignal + 0.05 * randn(size(timeVector));
                
            case 4 % Ball fault - impulses at ball pass frequency
                ballPassFrequency = 40 + 8 * randn(); % Hz
                impulsePeriod = 1 / ballPassFrequency;
                impulseLocations = 0:impulsePeriod:signalDuration;
                vibrationSignal = zeros(size(timeVector));
                for impulseTime = impulseLocations
                    impulseIdx = find(timeVector >= impulseTime, 1);
                    if impulseIdx <= length(timeVector)
                        impulseResponse = exp(-60*(timeVector(impulseIdx:end) - ...
                            impulseTime)) .* sin(2*pi*1200*(timeVector(impulseIdx:end) - ...
                            impulseTime));
                        vibrationSignal(impulseIdx:end) = ...
                            vibrationSignal(impulseIdx:end) + 0.4 * impulseResponse;
                    end
                end
                vibrationSignal = vibrationSignal + 0.05 * randn(size(timeVector));
        end
        
        % Generate spectrogram
        windowLength = 256;
        overlap = windowLength * 0.75;
        [spectrogramData, frequencyVector, timeVectorSpec] = ...
            spectrogram(vibrationSignal, windowLength, overlap, [], ...
            samplingFrequency);
        
        % Convert to image format
        spectrogramImage = abs(spectrogramData);
        spectrogramImage = mat2gray(log10(spectrogramImage + eps));
        spectrogramImage = imresize(spectrogramImage, [imageSize(1), imageSize(2)]);
        
        % Convert to RGB (duplicate grayscale across channels)
        spectrogramRGB = repmat(spectrogramImage, [1, 1, 3]);
        
        % Store image and label
        allImages = cat(4, allImages, spectrogramRGB);
        allLabels = [allLabels; classIdx];
    end
end

% Convert labels to categorical
allLabels = categorical(allLabels, 1:numClasses, classNames);

fprintf('  Generated %d spectrogram images\n', size(allImages, 4));
fprintf('  Samples per class: %d\n', samplesPerClass);

%% Step 3: Split dataset
fprintf('\nStep 3: Splitting dataset...\n');

trainRatio = 0.70;
valRatio = 0.15;
testRatio = 0.15;

numSamples = size(allImages, 4);
[trainIdx, valIdx, testIdx] = dividerand(numSamples, ...
    trainRatio, valRatio, testRatio);

trainImages = allImages(:, :, :, trainIdx);
trainLabels = allLabels(trainIdx);
valImages = allImages(:, :, :, valIdx);
valLabels = allLabels(valIdx);
testImages = allImages(:, :, :, testIdx);
testLabels = allLabels(testIdx);

fprintf('  Training samples: %d\n', length(trainIdx));
fprintf('  Validation samples: %d\n', length(valIdx));
fprintf('  Test samples: %d\n', length(testIdx));

%% Step 4: Feature extraction approach (freeze all conv layers)
fprintf('\nStep 4: Implementing feature extraction approach...\n');

% Extract layer graph from pre-trained network
layerGraph = layerGraph(networkPretrained);

% Replace final layers for new classification task
newFCLayer = fullyConnectedLayer(numClasses, 'Name', 'new_fc', ...
    'WeightLearnRateFactor', 10, 'BiasLearnRateFactor', 10);
newSoftmaxLayer = softmaxLayer('Name', 'new_softmax');
newClassificationLayer = classificationLayer('Name', 'new_output');

% Remove old classification layers
layerGraph = removeLayers(layerGraph, {'fc1000', 'fc1000_softmax', 'ClassificationLayer_fc1000'});

% Add new classification layers
layerGraph = addLayers(layerGraph, [newFCLayer, newSoftmaxLayer, newClassificationLayer]);
layerGraph = connectLayers(layerGraph, 'pool5', 'new_fc');

% Freeze all layers except new classification layers
layers = layerGraph.Layers;
for layerIdx = 1:length(layers)
    if ~contains(layers(layerIdx).Name, 'new_')
        if isprop(layers(layerIdx), 'WeightLearnRateFactor')
            layers(layerIdx).WeightLearnRateFactor = 0;
            layers(layerIdx).BiasLearnRateFactor = 0;
        end
    end
end

% Recreate layer graph with frozen layers
layerGraphFrozen = layerGraph;
for layerIdx = 1:length(layers)
    if contains(layers(layerIdx).Name, 'new_')
        continue; % Skip new layers
    end
    if isprop(layers(layerIdx), 'WeightLearnRateFactor')
        layerGraphFrozen = replaceLayer(layerGraphFrozen, ...
            layers(layerIdx).Name, layers(layerIdx));
    end
end

fprintf('  Pre-trained convolutional layers frozen\n');
fprintf('  New classification layers added\n');

%% Step 5: Train feature extraction model
fprintf('\nStep 5: Training feature extraction model...\n');

trainingOptionsFeatureExtraction = trainingOptions('sgdm', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 15, ...
    'MiniBatchSize', 16, ...
    'ValidationData', {valImages, valLabels}, ...
    'ValidationFrequency', 10, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
networkFeatureExtraction = trainNetwork(trainImages, trainLabels, ...
    layerGraphFrozen, trainingOptionsFeatureExtraction);
trainingTimeFeatureExtraction = toc;

fprintf('  Feature extraction training completed in %.2f seconds\n', ...
    trainingTimeFeatureExtraction);

%% Step 6: Evaluate feature extraction model
predictedLabelsFeatureExtraction = classify(networkFeatureExtraction, testImages);
accuracyFeatureExtraction = sum(predictedLabelsFeatureExtraction == testLabels) / numel(testLabels);

fprintf('  Feature extraction test accuracy: %.2f%%\n', accuracyFeatureExtraction * 100);

%% Step 7: Fine-tuning approach
fprintf('\nStep 7: Implementing fine-tuning approach...\n');

% Start with feature extraction model, then unfreeze later layers
layerGraphFineTune = layerGraph(networkFeatureExtraction);

% Unfreeze last few convolutional blocks (res5a onwards)
layersToUnfreeze = {'res5a_branch2a', 'res5a_branch2b', 'res5a_branch2c', ...
    'res5b_branch2a', 'res5b_branch2b', 'res5b_branch2c', ...
    'res5c_branch2a', 'res5c_branch2b', 'res5c_branch2c'};

layers = layerGraphFineTune.Layers;
for layerIdx = 1:length(layers)
    layerName = layers(layerIdx).Name;
    if any(contains(layersToUnfreeze, layerName)) || contains(layerName, 'new_')
        if isprop(layers(layerIdx), 'WeightLearnRateFactor')
            layers(layerIdx).WeightLearnRateFactor = 1;
            layers(layerIdx).BiasLearnRateFactor = 1;
        end
    end
end

fprintf('  Unfrozen final convolutional blocks for fine-tuning\n');

%% Step 8: Train fine-tuned model
fprintf('\nStep 8: Training fine-tuned model...\n');

trainingOptionsFineTune = trainingOptions('sgdm', ...
    'InitialLearnRate', 0.0001, ... % Lower learning rate for fine-tuning
    'MaxEpochs', 20, ...
    'MiniBatchSize', 16, ...
    'ValidationData', {valImages, valLabels}, ...
    'ValidationFrequency', 10, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
networkFineTuned = trainNetwork(trainImages, trainLabels, ...
    layerGraphFineTune, trainingOptionsFineTune);
trainingTimeFineTune = toc;

fprintf('  Fine-tuning training completed in %.2f seconds\n', ...
    trainingTimeFineTune);

%% Step 9: Evaluate fine-tuned model
predictedLabelsFineTune = classify(networkFineTuned, testImages);
accuracyFineTune = sum(predictedLabelsFineTune == testLabels) / numel(testLabels);

fprintf('  Fine-tuned model test accuracy: %.2f%%\n', accuracyFineTune * 100);

%% Step 10: Compare with training from scratch
fprintf('\nStep 10: Training baseline model from scratch...\n');

% Create simplified ResNet architecture for from-scratch training
layersFromScratch = [
    imageInputLayer(imageSize, 'Name', 'input')
    
    convolution2dLayer(7, 64, 'Stride', 2, 'Padding', 3, 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(3, 'Stride', 2, 'Padding', 1, 'Name', 'pool1')
    
    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')
    
    convolution2dLayer(3, 256, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')
    
    globalAveragePooling2dLayer('Name', 'gap')
    fullyConnectedLayer(numClasses, 'Name', 'fc')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')];

trainingOptionsFromScratch = trainingOptions('sgdm', ...
    'InitialLearnRate', 0.001, ...
    'MaxEpochs', 30, ...
    'MiniBatchSize', 16, ...
    'ValidationData', {valImages, valLabels}, ...
    'ValidationFrequency', 10, ...
    'Verbose', false, ...
    'Plots', 'none');

tic;
networkFromScratch = trainNetwork(trainImages, trainLabels, ...
    layersFromScratch, trainingOptionsFromScratch);
trainingTimeFromScratch = toc;

fprintf('  From-scratch training completed in %.2f seconds\n', ...
    trainingTimeFromScratch);

%% Step 11: Evaluate from-scratch model
predictedLabelsFromScratch = classify(networkFromScratch, testImages);
accuracyFromScratch = sum(predictedLabelsFromScratch == testLabels) / numel(testLabels);

fprintf('  From-scratch model test accuracy: %.2f%%\n', accuracyFromScratch * 100);

%% Step 12: Summary comparison
fprintf('\n=== Performance Summary ===\n');
fprintf('Feature Extraction:\n');
fprintf('  Test Accuracy: %.2f%%\n', accuracyFeatureExtraction * 100);
fprintf('  Training Time: %.2f seconds\n', trainingTimeFeatureExtraction);
fprintf('\nFine-Tuning:\n');
fprintf('  Test Accuracy: %.2f%%\n', accuracyFineTune * 100);
fprintf('  Training Time: %.2f seconds\n', trainingTimeFineTune);
fprintf('\nFrom Scratch:\n');
fprintf('  Test Accuracy: %.2f%%\n', accuracyFromScratch * 100);
fprintf('  Training Time: %.2f seconds\n', trainingTimeFromScratch);

fprintf('\nProblem 2 completed successfully.\n');
