%% chapter_FundamentalMathematics_MATLABexample_DirectArrayCreation.m
% Direct creation of matrices and vectors in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_DirectArrayCreation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_1_1_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates direct creation of matrices and vectors
%              using explicit element specification.

% Creating a 3*x3 matrix representing a rotation-scaling transformation
% This matrix combines 30-degree rotation with uniform scaling by factor 2
angleRadians = pi / 6; % 30 degrees in radians
scaleFactor = 2.0;
transformationMatrix = scaleFactor * [cos(angleRadians), -sin(angleRadians), 0;
                                       sin(angleRadians),  cos(angleRadians), 0;
                                       0,                  0,                 1];
disp('Transformation Matrix (3*x3) - Rotation and Scaling:');
disp(transformationMatrix);

% Creating a row vector representing measurement time points (seconds)
measurementTimes = [0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0];
disp('Measurement Time Points (Row Vector):');
disp(measurementTimes);

% Creating a column vector representing temperature readings (degrees Celsius)
temperatureReadings = [20.5; 21.3; 22.1; 21.8; 20.9; 20.2];
disp('Temperature Readings (Column Vector):');
disp(temperatureReadings);

% Creating an empty matrix for dynamic population
dynamicMatrix = [];
disp('Empty Matrix (to be populated dynamically):');
disp(dynamicMatrix);
disp(['Size of empty matrix: ', num2str(size(dynamicMatrix))]);
