%% chapter_FundamentalMathematics_lst_heat_equation.m
% Heat equation solution using finite differences.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_lst_heat_equation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section5.5_example1.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Solves 1*D heat equation using finite difference method

fprintf('=== Heat Equation Solution (Finite Differences) ===\n\n');

% Physical parameters
L = 1.0;              % Domain length (m)
alpha = 0.01;         % Thermal diffusivity (m^2/s)
T_final = 0.5;        % Final time (s)

% Discretisation parameters
nx = 50;              % Number of spatial points
dx = L / (nx - 1);    % Spatial step size
dt = 0.0001;          % Time step size
nt = round(T_final / dt);  % Number of time steps

% Check CFL stability condition
r = alpha * dt / dx^2;
fprintf('Grid parameters:\n');
fprintf('  Spatial points: %d, dx = %.4e\n', nx, dx);
fprintf('  Time steps: %d, dt = %.4e\n', nt, dt);
fprintf('  CFL number r = %.4f (must be <= 0.5 for stability)\n', r);

if r > 0.5
    warning('CFL condition violated. Solution may be unstable.');
end

% Initialise spatial grid
x = linspace(0, L, nx);

% Initial condition: u(x,0) = sin(pi*x/L)
u = sin(pi * x / L);
u_initial = u;

% Boundary conditions: u(0,t) = 0, u(L,t) = 0 (Dirichlet)
u(1) = 0;
u(end) = 0;

% Storage for snapshots at specific times
snapshot_times = [0, 0.01, 0.05, 0.1, 0.2, 0.5];
snapshots = zeros(length(snapshot_times), nx);
snapshot_idx = 1;
snapshots(snapshot_idx, :) = u;

% Explicit finite difference time-stepping
fprintf('\nSolving heat equation using explicit finite differences...\n');
u_new = zeros(size(u));

for n = 1:nt
    % Update interior points using explicit scheme
    for i = 2:nx-1
        u_new(i) = u(i) + r * (u(i+1) - 2*u(i) + u(i-1));
    end
    
    % Apply boundary conditions
    u_new(1) = 0;
    u_new(end) = 0;
    
    % Update solution
    u = u_new;
    
    % Store snapshots
    current_time = n * dt;
    if snapshot_idx < length(snapshot_times) && ...
       current_time >= snapshot_times(snapshot_idx + 1)
        snapshot_idx = snapshot_idx + 1;
        snapshots(snapshot_idx, :) = u;
    end
    
    % Progress indicator
    if mod(n, round(nt/10)) == 0
        fprintf('  Progress: %.0f%%\n', 100*n/nt);
    end
end

fprintf('Time integration complete.\n');

% Analytical solution for comparison
fprintf('\nComparing with analytical solution...\n');
u_analytical = @(x_val, t_val) sin(pi * x_val / L) .* ...
    exp(-alpha * (pi/L)^2 * t_val);

% Plot solutions at various times
figure('Position', [100, 100, 1400, 900]);

% Subplot 1: Evolution snapshots
subplot(2, 3, 1);
colours = lines(length(snapshot_times));
for idx = 1:length(snapshot_times)
    plot(x, snapshots(idx, :), 'Color', colours(idx,:), 'LineWidth', 2, ...
        'DisplayName', sprintf('$t = %.2f$ s', snapshot_times(idx)));
    hold on;
end
grid on;
xlabel('Position $x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Temperature $u(x,t)$', 'Interpreter', 'latex', 'FontSize', 12);
title('Heat Equation Solution Evolution', 'Interpreter', 'latex', 'FontSize', 14);
legend('show', 'Interpreter', 'latex', 'Location', 'best');
hold off;

% Subplot 2: Numerical vs analytical at final time
subplot(2, 3, 2);
t_compare = snapshot_times(end);
u_analytical_final = u_analytical(x, t_compare);
plot(x, snapshots(end, :), 'b-', 'LineWidth', 2, 'DisplayName', 'Numerical');
hold on;
plot(x, u_analytical_final, 'r--', 'LineWidth', 2, 'DisplayName', 'Analytical');
grid on;
xlabel('Position $x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Temperature $u(x,t)$', 'Interpreter', 'latex', 'FontSize', 12);
title(sprintf('Comparison at $t = %.2f$ s', t_compare), 'Interpreter', 'latex', ...
    'FontSize', 14);
legend('show', 'Interpreter', 'latex', 'Location', 'best');
hold off;

% Subplot 3: Error analysis
subplot(2, 3, 3);
error = abs(snapshots(end, :) - u_analytical_final);
semilogy(x, error, 'k-', 'LineWidth', 2);
grid on;
xlabel('Position $x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Absolute error', 'Interpreter', 'latex', 'FontSize', 12);
title('Numerical Error Distribution', 'Interpreter', 'latex', 'FontSize', 14);

max_error = max(error);
mean_error = mean(error);
fprintf('Maximum error: %.6e\n', max_error);
fprintf('Mean error: %.6e\n', mean_error);

% Subplot 4: Space-time diagram
subplot(2, 3, [4, 5, 6]);
[T_grid, X_grid] = meshgrid(linspace(0, T_final, 100), x);
U_analytical_grid = u_analytical(X_grid, T_grid);
surf(T_grid, X_grid, U_analytical_grid, 'EdgeColor', 'none');
hold on;
for idx = 1:length(snapshot_times)
    plot3(snapshot_times(idx) * ones(size(x)), x, snapshots(idx, :), ...
        'k-', 'LineWidth', 2);
end
colormap('hot');
colorbar;
xlabel('Time $t$ (s)', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Position $x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
zlabel('Temperature $u(x,t)$', 'Interpreter', 'latex', 'FontSize', 12);
title('Space-Time Evolution of Temperature', 'Interpreter', 'latex', 'FontSize', 14);
view(45, 30);
hold off;

saveas(gcf, 'heat_equation_solution.png');

fprintf('\nHeat equation example complete.\n');
fprintf('Figure saved as: heat_equation_solution.png\n');

% - Demonstrate stability violation -
fprintf('\n- Demonstrating CFL Stability Violation -\n');

% Use larger time step that violates CFL condition
dt_unstable = 0.005;  % Much larger than stable value
r_unstable = alpha * dt_unstable / dx^2;
fprintf('Using unstable parameters: dt = %.4e, r = %.4f\n', dt_unstable, r_unstable);

u_unstable = sin(pi * x / L);
nt_unstable = 20;  % Just a few time steps to show instability

figure('Position', [100, 100, 800, 400]);
for n = 1:nt_unstable
    for i = 2:nx-1
        u_new(i) = u_unstable(i) + r_unstable * ...
            (u_unstable(i+1) - 2*u_unstable(i) + u_unstable(i-1));
    end
    u_unstable = u_new;
    
    if mod(n, 5) == 0 || n == 1
        subplot(1, 2, 1);
        plot(x, u_unstable, 'LineWidth', 2, ...
            'DisplayName', sprintf('Step %d', n));
        hold on;
    end
end
grid on;
xlabel('Position $x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Temperature $u$', 'Interpreter', 'latex', 'FontSize', 12);
title('Unstable Solution (CFL Violated)', 'Interpreter', 'latex', 'FontSize', 14);
legend('show', 'Interpreter', 'latex');
hold off;

% Stable solution for comparison
u_stable = sin(pi * x / L);
dt_stable = 0.0001;
r_stable = alpha * dt_stable / dx^2;
nt_stable = round(nt_unstable * dt_unstable / dt_stable);

for n = 1:nt_stable
    for i = 2:nx-1
        u_new(i) = u_stable(i) + r_stable * ...
            (u_stable(i+1) - 2*u_stable(i) + u_stable(i-1));
    end
    u_stable = u_new;
end

subplot(1, 2, 2);
plot(x, u_initial, 'k--', 'LineWidth', 2, 'DisplayName', 'Initial');
hold on;
plot(x, u_stable, 'b-', 'LineWidth', 2, 'DisplayName', 'Stable solution');
grid on;
xlabel('Position $x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Temperature $u$', 'Interpreter', 'latex', 'FontSize', 12);
title('Stable Solution (CFL Satisfied)', 'Interpreter', 'latex', 'FontSize', 14);
legend('show', 'Interpreter', 'latex');
hold off;

saveas(gcf, 'cfl_stability_demonstration.png');
fprintf('Stability demonstration complete.\n');
fprintf('Figure saved as: cfl_stability_demonstration.png\n');
