%% listing_problem2_pole_placement.m
% Problem 2: State-space pole placement design for DC motor position control with full controllability analysis, Ackermann's formula implementation, and comprehensive robustness validation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : listing:problem2_pole_placement
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% MATLAB Code: Problem 2 - State-Space Pole Placement Design
% Book: MATLAB Roadmap to Applications - Volume II
% Chapter: AI in Advanced Control Engineering - Problems
% Author: Dr Yi Chen
% Date: December 2023
% MATLAB Version: R2023b
% Description: Design full-state feedback controller for DC motor position
%              control via pole placement. Verify controllability, compute
%              gains using Ackermann's formula and MATLAB place(), validate
%              closed-loop performance, and assess robustness.
% =========================================================================

clear; close all; clc;

fprintf('==================================================================\n');
fprintf('Problem 2: State-Space Pole Placement for DC Motor Control\n');
fprintf('==================================================================\n\n');

%% Physical Parameters
J = 0.01;      % Rotor inertia (kg.m^2)
b = 0.1;       % Viscous friction (N.m.s)
Km = 0.05;     % Motor torque constant (N.m/A)
Ke = 0.05;     % Back-EMF constant (V.s/rad)
R = 1;         % Armature resistance (Ohm)
L = 0.5;       % Armature inductance (H)

fprintf('=== DC Motor Physical Parameters ===\n');
fprintf('Rotor inertia (J): %.4f kg.m^2\n', J);
fprintf('Viscous friction (b): %.4f N.m.s\n', b);
fprintf('Motor torque constant (Km): %.4f N.m/A\n', Km);
fprintf('Back-EMF constant (Ke): %.4f V.s/rad\n', Ke);
fprintf('Armature resistance (R): %.4f Ohm\n', R);
fprintf('Armature inductance (L): %.4f H\n\n', L);

%% State-Space Model Construction
% State vector: x = [theta; omega; i]
% Input: u = V (voltage)
% Output: y = theta (position)

A = [0,    1,      0;
     0,   -b/J,   Km/J;
     0,   -Ke/L,  -R/L];

B = [0;
     0;
     1/L];

C = [1, 0, 0];

D = 0;

fprintf('=== State-Space Matrices ===\n');
fprintf('A matrix:\n');
disp(A);
fprintf('B matrix:\n');
disp(B);
fprintf('C matrix:\n');
disp(C);
fprintf('D: %.0f\n\n', D);

% Create state-space object
sys_ss = ss(A, B, C, D, 'StateName', {'theta', 'omega', 'i'}, ...
    'InputName', 'V', 'OutputName', 'theta');

fprintf('State-Space System:\n');
disp(sys_ss);

%% Open-Loop Analysis
fprintf('=== Open-Loop System Analysis ===\n');

% Open-loop poles
openLoopPoles = eig(A);

fprintf('Open-loop poles:\n');
for idx = 1:length(openLoopPoles)
    if abs(imag(openLoopPoles(idx))) < 1e-6
        fprintf('  p_%d = %.6f (real)\n', idx, real(openLoopPoles(idx)));
    else
        fprintf('  p_%d = %.6f %+.6fi\n', idx, real(openLoopPoles(idx)), imag(openLoopPoles(idx)));
    end
end

% Stability check
if all(real(openLoopPoles) < 0)
    fprintf('Open-loop system: STABLE\n\n');
elseif any(real(openLoopPoles) > 0)
    fprintf('Open-loop system: UNSTABLE\n\n');
else
    fprintf('Open-loop system: MARGINALLY STABLE\n\n');
end

% Open-loop step response
figure('Position', [100, 100, 1400, 800]);

subplot(3,3,1);
step(sys_ss, 10);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Position (rad)', 'Interpreter', 'latex', 'FontSize', 11);
title('Open-Loop Step Response', 'Interpreter', 'latex', 'FontSize', 13);

stepInfo_openloop = stepinfo(sys_ss);
fprintf('Open-loop step response metrics:\n');
fprintf('  Settling time: %.4f s\n', stepInfo_openloop.SettlingTime);
fprintf('  Overshoot: %.2f %%\n', stepInfo_openloop.Overshoot);
fprintf('  Steady-state: %.4f rad\n\n', dcgain(sys_ss));

%% Controllability Analysis
fprintf('=== Controllability Analysis ===\n');

% Controllability matrix: C = [B AB A^2B]
controllability_matrix = ctrb(A, B);

fprintf('Controllability matrix:\n');
disp(controllability_matrix);

% Rank check
rank_C = rank(controllability_matrix);
n_states = size(A, 1);

fprintf('Rank of controllability matrix: %d\n', rank_C);
fprintf('Number of states: %d\n', n_states);

if rank_C == n_states
    fprintf('RESULT: System is FULLY CONTROLLABLE (rank = n)\n\n');
else
    fprintf('WARNING: System is NOT fully controllable (rank < n)\n\n');
    error('Cannot proceed with pole placement - system not controllable');
end

% Determinant (additional check)
det_C = det(controllability_matrix);
fprintf('Determinant of controllability matrix: %.6f\n', det_C);
fprintf('Non-zero determinant confirms full controllability.\n\n');

%% Design Specifications and Desired Pole Placement
fprintf('=== Design Specifications ===\n');

% Performance requirements
Ts_spec = 0.5;      % Settling time < 0.5 s
Mp_spec = 10;       % Percent overshoot < 10%

fprintf('Settling time specification: Ts < %.2f s\n', Ts_spec);
fprintf('Overshoot specification: Mp < %.0f %%\n\n', Mp_spec);

% Translate to pole locations
sigma_min = 4 / Ts_spec;  % Minimum real part for settling time
zeta_min = sqrt((log(Mp_spec/100))^2 / (pi^2 + (log(Mp_spec/100))^2));  % Damping ratio

fprintf('Pole placement requirements:\n');
fprintf('  Real part (sigma): > %.2f (from Ts requirement)\n', sigma_min);
fprintf('  Damping ratio (zeta): > %.4f (from Mp requirement)\n\n', zeta_min);

% Select desired poles
sigma_desired = 8;       % Real part (conservative choice)
zeta_desired = 0.6;      % Damping ratio (conservative)
wn_desired = sigma_desired / zeta_desired;  % Natural frequency

% Dominant complex conjugate pair
p1 = -sigma_desired + 1j * wn_desired * sqrt(1 - zeta_desired^2);
p2 = conj(p1);

% Fast real pole (5x dominant pole real part)
p3 = -5 * sigma_desired;

desired_poles = [p1; p2; p3];

fprintf('Selected desired poles:\n');
fprintf('  p1 = %.4f + %.4fi (zeta = %.2f, wn = %.2f rad/s)\n', ...
    real(p1), imag(p1), zeta_desired, wn_desired);
fprintf('  p2 = %.4f - %.4fi (complex conjugate)\n', real(p2), imag(p2));
fprintf('  p3 = %.4f (fast real pole)\n\n', p3);

%% Feedback Gain Computation - Method 1: Ackermann's Formula
fprintf('=== Method 1: Ackermann''s Formula ===\n');

% Desired characteristic polynomial coefficients
% alpha_c(s) = (s - p1)(s - p2)(s - p3)
alpha_c_poly = poly(desired_poles);  % Returns coefficients [1, a2, a1, a0]

fprintf('Desired characteristic polynomial:\n');
fprintf('  s^3 + %.4f*s^2 + %.4f*s + %.4f\n', alpha_c_poly(2), alpha_c_poly(3), alpha_c_poly(4));

% Evaluate characteristic polynomial at A: alpha_c(A)
alpha_c_at_A = alpha_c_poly(1) * A^3 + alpha_c_poly(2) * A^2 + ...
               alpha_c_poly(3) * A + alpha_c_poly(4) * eye(size(A));

% Ackermann's formula: K = [0 0 ... 1] * C^(-1) * alpha_c(A)
e_n = zeros(1, n_states);
e_n(end) = 1;  % [0 0 1] for 3-state system

K_ackermann = e_n * (controllability_matrix \ alpha_c_at_A);

fprintf('State feedback gain (Ackermann):\n');
fprintf('  K = [%.4f  %.4f  %.4f]\n\n', K_ackermann);

%% Feedback Gain Computation - Method 2: MATLAB place()
fprintf('=== Method 2: MATLAB place() Function ===\n');

K_place = place(A, B, desired_poles);

fprintf('State feedback gain (place):\n');
fprintf('  K = [%.4f  %.4f  %.4f]\n\n', K_place);

% Compare methods
K_diff = norm(K_ackermann - K_place);
fprintf('Difference between methods: ||K_ackermann - K_place|| = %.8f\n', K_diff);

if K_diff < 1e-6
    fprintf('VERIFIED: Both methods produce identical results.\n\n');
else
    fprintf('NOTE: Small numerical difference between methods.\n\n');
end

% Use place() result for remainder of analysis
K = K_place;

%% Closed-Loop Verification
fprintf('=== Closed-Loop System Verification ===\n');

% Closed-loop A matrix
A_cl = A - B * K;

fprintf('Closed-loop A matrix:\n');
disp(A_cl);

% Closed-loop poles
closedLoopPoles = eig(A_cl);

fprintf('Closed-loop poles (achieved):\n');
for idx = 1:length(closedLoopPoles)
    if abs(imag(closedLoopPoles(idx))) < 1e-6
        fprintf('  p_%d = %.6f (real)\n', idx, real(closedLoopPoles(idx)));
    else
        fprintf('  p_%d = %.6f %+.6fi\n', idx, real(closedLoopPoles(idx)), imag(closedLoopPoles(idx)));
    end
end

% Compare with desired poles
fprintf('\nComparison with desired poles:\n');
pole_errors = sort(closedLoopPoles) - sort(desired_poles);
for idx = 1:length(pole_errors)
    fprintf('  Error in p_%d: %.8f %+.8fi\n', idx, real(pole_errors(idx)), imag(pole_errors(idx)));
end

max_pole_error = max(abs(pole_errors));
fprintf('Maximum pole placement error: %.10f\n', max_pole_error);

if max_pole_error < 1e-6
    fprintf('SUCCESS: Poles placed at desired locations (within numerical precision)\n\n');
else
    fprintf('WARNING: Pole placement error exceeds tolerance\n\n');
end

%% Feedforward Gain for Reference Tracking
fprintf('=== Feedforward Gain for Reference Tracking ===\n');

% Steady-state gain from reference to output
% y_ss = C * (A - BK)^(-1) * B * kr * r
% For unity gain: kr = 1 / [C * (A - BK)^(-1) * B]

Nbar = -1 / (C * (A_cl \ B));

fprintf('Feedforward gain (Nbar): %.4f\n\n', Nbar);

% Verify steady-state tracking
fprintf('Verification: For unit step r = 1, steady-state output should be 1.0\n');
y_ss_predicted = -C * (A_cl \ B) * Nbar;
fprintf('  Predicted y_ss = %.6f\n\n', y_ss_predicted);

%% Closed-Loop Step Response Simulation
fprintf('=== Closed-Loop Step Response ===\n');

% Closed-loop system with feedforward
% x_dot = (A - BK)x + B*Nbar*r
% y = Cx

sys_cl = ss(A_cl, B*Nbar, C, 0, 'StateName', {'theta', 'omega', 'i'}, ...
    'InputName', 'r', 'OutputName', 'theta');

fprintf('Closed-Loop Transfer Function (with feedforward):\n');
disp(sys_cl);

% Step response
subplot(3,3,2);
[y_cl, t_cl] = step(sys_cl, 2);
plot(t_cl, y_cl, 'b-', 'LineWidth', 1.5);
grid on;
hold on;
yline(1, 'r-', 'Reference');
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Position (rad)', 'Interpreter', 'latex', 'FontSize', 11);
title('Closed-Loop Step Response (Position)', 'Interpreter', 'latex', 'FontSize', 13);
legend('Output', 'Reference', 'Interpreter', 'latex', 'Location', 'best');

stepInfo_cl = stepinfo(sys_cl);

fprintf('Closed-loop step response metrics:\n');
fprintf('  Rise time (Tr): %.4f s\n', stepInfo_cl.RiseTime);
fprintf('  Peak time (Tp): %.4f s\n', stepInfo_cl.PeakTime);
fprintf('  Settling time (Ts): %.4f s\n', stepInfo_cl.SettlingTime);
fprintf('  Overshoot (Mp): %.2f %%\n', stepInfo_cl.Overshoot);
fprintf('  Peak value: %.4f\n', stepInfo_cl.Peak);
fprintf('  Steady-state: %.6f\n\n', dcgain(sys_cl));

% Specification check
fprintf('Specification Verification:\n');
if stepInfo_cl.SettlingTime < Ts_spec
    fprintf('  PASS: Ts = %.4f s < %.2f s\n', stepInfo_cl.SettlingTime, Ts_spec);
else
    fprintf('  FAIL: Ts = %.4f s >= %.2f s\n', stepInfo_cl.SettlingTime, Ts_spec);
end

if stepInfo_cl.Overshoot < Mp_spec
    fprintf('  PASS: Mp = %.2f %% < %.0f %%\n', stepInfo_cl.Overshoot, Mp_spec);
else
    fprintf('  FAIL: Mp = %.2f %% >= %.0f %%\n', stepInfo_cl.Overshoot, Mp_spec);
end

e_ss = abs(1 - dcgain(sys_cl));
if e_ss < 0.01
    fprintf('  PASS: Steady-state error = %.6f < 0.01\n\n', e_ss);
else
    fprintf('  FAIL: Steady-state error = %.6f >= 0.01\n\n', e_ss);
end

%% State Trajectories
fprintf('=== Full State Trajectories ===\n');

% Simulate all states
sys_cl_fullstate = ss(A_cl, B*Nbar, eye(3), zeros(3,1), ...
    'StateName', {'theta', 'omega', 'i'}, 'InputName', 'r', ...
    'OutputName', {'theta', 'omega', 'i'});

[x_traj, t_traj] = step(sys_cl_fullstate, 2);

subplot(3,3,3);
plot(t_traj, x_traj(:,1), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$\theta$ (rad)', 'Interpreter', 'latex', 'FontSize', 11);
title('State 1: Position', 'Interpreter', 'latex', 'FontSize', 13);

subplot(3,3,4);
plot(t_traj, x_traj(:,2), 'r-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$\omega$ (rad/s)', 'Interpreter', 'latex', 'FontSize', 11);
title('State 2: Angular Velocity', 'Interpreter', 'latex', 'FontSize', 13);

subplot(3,3,5);
plot(t_traj, x_traj(:,3), 'g-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$i$ (A)', 'Interpreter', 'latex', 'FontSize', 11);
title('State 3: Armature Current', 'Interpreter', 'latex', 'FontSize', 13);

fprintf('Peak armature current: %.4f A\n', max(abs(x_traj(:,3))));
fprintf('Peak angular velocity: %.4f rad/s\n\n', max(abs(x_traj(:,2))));

%% Control Signal Analysis
fprintf('=== Control Signal (Voltage) ===\n');

% Control signal: u = -Kx + Nbar*r
u_control = -x_traj * K' + Nbar * ones(size(t_traj));

subplot(3,3,6);
plot(t_traj, u_control, 'k-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('$u$ (V)', 'Interpreter', 'latex', 'FontSize', 11);
title('Control Signal (Voltage)', 'Interpreter', 'latex', 'FontSize', 13);
hold on;
yline(12, 'r-', 'V_{max}');
yline(-12, 'r-', 'V_{min}');
legend('Control', 'Saturation Limits', 'Interpreter', 'latex', 'Location', 'best');

fprintf('Peak control voltage: %.4f V\n', max(abs(u_control)));
fprintf('Initial control voltage: %.4f V\n', u_control(1));

if max(abs(u_control)) > 12
    fprintf('WARNING: Control exceeds typical motor voltage limits ( 12V)\n\n');
else
    fprintf('Control signal within typical limits ( 12V)\n\n');
end

%% Comparison: Different Pole Placements
fprintf('=== Comparison: Conservative vs Aggressive Pole Placement ===\n');

% Design 1: More conservative (slower but more robust)
sigma_conservative = 6;
zeta_conservative = 0.7;
wn_conservative = sigma_conservative / zeta_conservative;
p1_cons = -sigma_conservative + 1j * wn_conservative * sqrt(1 - zeta_conservative^2);
p2_cons = conj(p1_cons);
p3_cons = -3 * sigma_conservative;
poles_conservative = [p1_cons; p2_cons; p3_cons];

K_conservative = place(A, B, poles_conservative);
A_cl_cons = A - B * K_conservative;
Nbar_cons = -1 / (C * (A_cl_cons \ B));
sys_cl_cons = ss(A_cl_cons, B*Nbar_cons, C, 0);

fprintf('Conservative design:\n');
fprintf('  Poles: %.2f %.2fi, %.2f\n', real(p1_cons), imag(p1_cons), p3_cons);
fprintf('  K = [%.4f  %.4f  %.4f]\n', K_conservative);

% Design 2: More aggressive (faster but less robust)
sigma_aggressive = 12;
zeta_aggressive = 0.5;
wn_aggressive = sigma_aggressive / zeta_aggressive;
p1_agg = -sigma_aggressive + 1j * wn_aggressive * sqrt(1 - zeta_aggressive^2);
p2_agg = conj(p1_agg);
p3_agg = -6 * sigma_aggressive;
poles_aggressive = [p1_agg; p2_agg; p3_agg];

K_aggressive = place(A, B, poles_aggressive);
A_cl_agg = A - B * K_aggressive;
Nbar_agg = -1 / (C * (A_cl_agg \ B));
sys_cl_agg = ss(A_cl_agg, B*Nbar_agg, C, 0);

fprintf('Aggressive design:\n');
fprintf('  Poles: %.2f %.2fi, %.2f\n', real(p1_agg), imag(p1_agg), p3_agg);
fprintf('  K = [%.4f  %.4f  %.4f]\n\n', K_aggressive);

% Compare step responses
subplot(3,3,7);
step(sys_cl_cons, sys_cl, sys_cl_agg, 2);
grid on;
legend('Conservative', 'Nominal', 'Aggressive', 'Interpreter', 'latex', 'Location', 'best');
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Position (rad)', 'Interpreter', 'latex', 'FontSize', 11);
title('Pole Placement Comparison', 'Interpreter', 'latex', 'FontSize', 13);

stepInfo_cons = stepinfo(sys_cl_cons);
stepInfo_agg = stepinfo(sys_cl_agg);

fprintf('Performance comparison:\n');
fprintf('  Conservative: Ts=%.3fs, Mp=%.1f%%, u_max=%.2fV\n', ...
    stepInfo_cons.SettlingTime, stepInfo_cons.Overshoot, ...
    max(abs(-step(ss(A_cl_cons, B*Nbar_cons, K_conservative, 0), 2))));
fprintf('  Nominal:      Ts=%.3fs, Mp=%.1f%%, u_max=%.2fV\n', ...
    stepInfo_cl.SettlingTime, stepInfo_cl.Overshoot, max(abs(u_control)));
fprintf('  Aggressive:   Ts=%.3fs, Mp=%.1f%%, u_max=%.2fV\n\n', ...
    stepInfo_agg.SettlingTime, stepInfo_agg.Overshoot, ...
    max(abs(-step(ss(A_cl_agg, B*Nbar_agg, K_aggressive, 0), 2))));

%% Pole-Zero Map
subplot(3,3,8);
pzmap(sys_cl);
grid on;
hold on;

% Mark desired poles
plot(real(desired_poles), imag(desired_poles), 'rx', 'MarkerSize', 15, 'LineWidth', 3);

% Add damping ratio lines
zeta_lines = [0.3, 0.5, 0.7];
theta_lines = acos(zeta_lines);
r_max = 50;
for idx_zeta = 1:length(zeta_lines)
    theta = theta_lines(idx_zeta);
    plot([-r_max*cos(theta), 0], [r_max*sin(theta), 0], 'k-', 'LineWidth', 0.5);
    plot([-r_max*cos(theta), 0], [-r_max*sin(theta), 0], 'k-', 'LineWidth', 0.5);
end

title('Pole-Zero Map (Closed-Loop)', 'Interpreter', 'latex', 'FontSize', 13);
legend('Poles', 'Zeros', 'Desired Poles', 'Interpreter', 'latex', 'Location', 'best');

%% Bode Plot (Loop Transfer Function)
subplot(3,3,9);

% Loop transfer function: L(s) = K * (sI - A)^(-1) * B
% This is for stability margin analysis
sys_loop = ss(A, B, K, 0);

bode(sys_loop);
grid on;
title('Loop Transfer Function Bode', 'Interpreter', 'latex', 'FontSize', 13);

[Gm, Pm, Wgc, Wpc] = margin(sys_loop);
fprintf('=== Stability Margins ===\n');
fprintf('Gain Margin (GM): %.2f dB at %.2f rad/s\n', 20*log10(Gm), Wgc);
fprintf('Phase Margin (PM): %.2f deg at %.2f rad/s\n\n', Pm, Wpc);

saveas(gcf, 'Problem02_StateSpace_Analysis.fig');
saveas(gcf, 'Problem02_StateSpace_Analysis.eps', 'epsc');
saveas(gcf, 'Problem02_StateSpace_Analysis.jpg');

fprintf('Saved: Problem02_StateSpace_Analysis.fig/.eps/.jpg\n\n');

%% Robustness Analysis: Parameter Variations
fprintf('=== Robustness Analysis: Plant Parameter Variations ===\n');

param_variations = -0.2:0.1:0.2;  % -20% to +20%

figure('Position', [100, 100, 1200, 500]);

% Vary inertia J
subplot(1,2,1);
hold on;

for idx = 1:length(param_variations)
    var = param_variations(idx);
    J_pert = J * (1 + var);
    
    A_pert = [0,    1,      0;
              0,   -b/J_pert,   Km/J_pert;
              0,   -Ke/L,  -R/L];
    
    % Use SAME feedback gain K (robustness test)
    A_cl_pert = A_pert - B * K;
    sys_cl_pert = ss(A_cl_pert, B*Nbar, C, 0);
    
    step(sys_cl_pert, 2);
    
    % Check stability
    poles_pert = eig(A_cl_pert);
    if any(real(poles_pert) >= 0)
        fprintf('WARNING: Unstable for J variation %+.0f%%\n', var*100);
    end
end

grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Position (rad)', 'Interpreter', 'latex', 'FontSize', 11);
title('Robustness: Inertia $J$ Variations ($\pm 20\%$)', 'Interpreter', 'latex', 'FontSize', 13);
legend(arrayfun(@(x) sprintf('%+.0f\\%%', x*100), param_variations, 'UniformOutput', false), ...
    'Interpreter', 'latex', 'Location', 'best', 'FontSize', 8);

% Vary resistance R
subplot(1,2,2);
hold on;

for idx = 1:length(param_variations)
    var = param_variations(idx);
    R_pert = R * (1 + var);
    
    A_pert = [0,    1,      0;
              0,   -b/J,   Km/J;
              0,   -Ke/L,  -R_pert/L];
    
    A_cl_pert = A_pert - B * K;
    sys_cl_pert = ss(A_cl_pert, B*Nbar, C, 0);
    
    step(sys_cl_pert, 2);
    
    stepInfo_pert = stepinfo(sys_cl_pert);
    fprintf('R variation %+.0f%%: Ts=%.3fs, Mp=%.1f%%\n', ...
        var*100, stepInfo_pert.SettlingTime, stepInfo_pert.Overshoot);
end

grid on;
xlabel('Time (s)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Position (rad)', 'Interpreter', 'latex', 'FontSize', 11);
title('Robustness: Resistance $R$ Variations ($\pm 20\%$)', 'Interpreter', 'latex', 'FontSize', 13);
legend(arrayfun(@(x) sprintf('%+.0f\\%%', x*100), param_variations, 'UniformOutput', false), ...
    'Interpreter', 'latex', 'Location', 'best', 'FontSize', 8);

saveas(gcf, 'Problem02_Robustness.fig');
saveas(gcf, 'Problem02_Robustness.eps', 'epsc');
saveas(gcf, 'Problem02_Robustness.jpg');

fprintf('\nSaved: Problem02_Robustness.fig/.eps/.jpg\n\n');

fprintf('=== Problem 2 Complete ===\n');
