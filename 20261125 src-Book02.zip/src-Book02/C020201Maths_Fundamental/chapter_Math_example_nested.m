%% chapter_Math_example_nested.m
% Nested and local functions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_nested
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function result = complexComputation(x, y)
    % Main function with nested and local functions
    
    % Nested function (accesses parent variables)
    function out = helperNested
        % Can access x and y from parent
        out = sqrt(x^2 + y^2);
    end
    
    % Call nested function
    magnitude = helperNested();
    
    % Call local function
    angle = computeAngle(x, y);
    
    % Combine results
    result = struct('magnitude', magnitude, 'angle', angle);
end

% Local function (separate workspace)
function theta = computeAngle(a, b)
    % Cannot access variables from complexComputation directly
    % Must receive values as arguments
    theta = atan2(b, a);
end
