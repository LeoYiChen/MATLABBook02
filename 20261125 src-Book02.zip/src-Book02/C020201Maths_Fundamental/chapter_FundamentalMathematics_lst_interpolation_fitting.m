%% chapter_FundamentalMathematics_lst_interpolation_fitting.m
% Interpolation and polynomial fitting in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_lst_interpolation_fitting
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter01_section5.2_example1.m
% Author: Dr Leo Chen  
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates 1*D interpolation and polynomial curve fitting

% - Part 1: Interpolation Methods Comparison -
% Sample data points from sin(x)
x_data_points = 0:pi/4:2*pi; % Data points for x
y_data_points = sin(x_data_points);   % Corresponding y values

% Points at which to interpolate  
x_query_points = linspace(0, 2*pi, 100); % Finer grid for querying

% Linear interpolation
y_linear_interp = interp1(x_data_points, y_data_points, x_query_points, 'linear');

% Cubic spline interpolation  
y_spline_interp = interp1(x_data_points, y_data_points, x_query_points, 'spline');

% PCHIP - shape preserving
y_pchip_interp = interp1(x_data_points, y_data_points, x_query_points, 'pchip');

% Plotting the interpolation results
figure('Position', [100, 100, 1200, 800]);

subplot(2, 2, 1);
plot(x_data_points, y_data_points, 'ko', 'MarkerFaceColor', 'k', ...
    'MarkerSize', 8, 'DisplayName', 'Original Data Points');
hold on;
plot(x_query_points, y_linear_interp, 'b-', 'LineWidth', 1.5, ...
    'DisplayName', 'Linear Interpolation');
plot(x_query_points, y_spline_interp, 'r--', 'LineWidth', 1.5, ...
    'DisplayName', 'Cubic Spline Interpolation');
plot(x_query_points, y_pchip_interp, 'g-.', 'LineWidth', 1.5, ...
    'DisplayName', 'PCHIP Interpolation');
plot(x_query_points, sin(x_query_points), 'm:', 'LineWidth', 2, ...
    'DisplayName', 'True $\sin(x)$ function');
legend('show', 'Location', 'southwest', 'Interpreter', 'latex');
title('Comparison of 1*D Interpolation Methods (Data from $\sin(x)$)', ...
    'Interpreter', 'latex', 'FontSize', 14);
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
grid on;
hold off;

% - Part 2: Polynomial Curve Fitting -
% Generate noisy data around a quadratic function
rng('default'); % For reproducibility  
x_noisy_data = linspace(-2, 2, 30)'; % Column vector
y_true_quadratic = x_noisy_data.^2 - x_noisy_data + 1;
noise_level = 0.5;
y_noisy_data = y_true_quadratic + noise_level * randn(size(x_noisy_data));

% Fit polynomials of different degrees
degree_poly_fit_2 = 2;
degree_poly_fit_5 = 5;
poly_coefficients_2 = polyfit(x_noisy_data, y_noisy_data, degree_poly_fit_2);
poly_coefficients_5 = polyfit(x_noisy_data, y_noisy_data, degree_poly_fit_5);

% Evaluate fitted polynomials
x_fine_grid_fit = linspace(min(x_noisy_data), max(x_noisy_data), 200);
y_fitted_poly_2 = polyval(poly_coefficients_2, x_fine_grid_fit);
y_fitted_poly_5 = polyval(poly_coefficients_5, x_fine_grid_fit);

fprintf('Polynomial coefficients from polyfit (degree %d):\n', degree_poly_fit_2);
disp(poly_coefficients_2);
fprintf('Polynomial coefficients from polyfit (degree %d):\n', degree_poly_fit_5);
disp(poly_coefficients_5);

% Plotting the polynomial fitting results
subplot(2, 2, 2);
plot(x_noisy_data, y_noisy_data, 'bo', 'MarkerSize', 6, ...
    'DisplayName', 'Noisy Data Points');
hold on;
plot(x_fine_grid_fit, y_fitted_poly_2, 'r-', 'LineWidth', 2, ...
    'DisplayName', sprintf('Fitted Polynomial (Degree %d)', degree_poly_fit_2));
plot(x_fine_grid_fit, y_fitted_poly_5, 'm--', 'LineWidth', 2, ...
    'DisplayName', sprintf('Fitted Polynomial (Degree %d)', degree_poly_fit_5));
plot(x_fine_grid_fit, x_fine_grid_fit.^2 - x_fine_grid_fit + 1, 'k--', ...
    'LineWidth', 1.5, 'DisplayName', 'True Underlying Quadratic');
legend('show', 'Location', 'northwest', 'Interpreter', 'latex');
title('Polynomial Curve Fitting (Least Squares)', 'Interpreter', 'latex', ...
    'FontSize', 14);
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
grid on;
hold off;

% - Part 3: Demonstrate Runge's Phenomenon -
% Interpolate Runge's function
runge_function = @(x) 1 ./ (1 + 25*x.^2);
x_runge_data = linspace(-1, 1, 11); % 11 equally spaced points
y_runge_data = runge_function(x_runge_data);

x_runge_fine = linspace(-1, 1, 200);
y_runge_true = runge_function(x_runge_fine);

% High-degree polynomial interpolation
degree_high = length(x_runge_data) - 1;
poly_coeff_runge = polyfit(x_runge_data, y_runge_data, degree_high);
y_runge_poly = polyval(poly_coeff_runge, x_runge_fine);

% Spline interpolation
y_runge_spline = spline(x_runge_data, y_runge_data, x_runge_fine);

subplot(2, 2, 3);
plot(x_runge_data, y_runge_data, 'ko', 'MarkerFaceColor', 'k', ...
    'MarkerSize', 8, 'DisplayName', 'Data Points');
hold on;
plot(x_runge_fine, y_runge_true, 'k-', 'LineWidth', 2, ...
    'DisplayName', 'True Runge Function');
plot(x_runge_fine, y_runge_poly, 'r--', 'LineWidth', 1.5, ...
    'DisplayName', sprintf('Polynomial Degree %d', degree_high));
plot(x_runge_fine, y_runge_spline, 'b-.', 'LineWidth', 1.5, ...
    'DisplayName', 'Cubic Spline');
legend('show', 'Location', 'north', 'Interpreter', 'latex');
title('Runge''s Phenomenon Demonstration', 'Interpreter', 'latex', 'FontSize', 14);
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$f(x) = \frac{1}{1+25*x^2}$', 'Interpreter', 'latex', 'FontSize', 12);
grid on;
axis([-1 1 -1 1.5]);
hold off;

% - Part 4: Shape-Preserving Interpolation -
% Monotonic data
x_monotonic = [0, 1, 2, 3, 4, 5];
y_monotonic = [0, 1, 1.5, 2.5, 4, 6];

x_monotonic_fine = linspace(0, 5, 100);
y_monotonic_spline = spline(x_monotonic, y_monotonic, x_monotonic_fine);
y_monotonic_pchip = pchip(x_monotonic, y_monotonic, x_monotonic_fine);

subplot(2, 2, 4);
plot(x_monotonic, y_monotonic, 'ko', 'MarkerFaceColor', 'k', ...
    'MarkerSize', 8, 'DisplayName', 'Data Points');
hold on;
plot(x_monotonic_fine, y_monotonic_spline, 'r--', 'LineWidth', 1.5, ...
    'DisplayName', 'Cubic Spline');
plot(x_monotonic_fine, y_monotonic_pchip, 'b-', 'LineWidth', 1.5, ...
    'DisplayName', 'PCHIP (Shape-Preserving)');
legend('show', 'Location', 'northwest', 'Interpreter', 'latex');
title('Shape-Preserving Interpolation', 'Interpreter', 'latex', 'FontSize', 14);
xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
grid on;
hold off;

% Save figure
saveas(gcf, 'interpolation_and_fitting_methods.png');

fprintf('\nInterpolation and fitting examples complete.\n');
fprintf('Figure saved as: interpolation_and_fitting_methods.png\n');
