%% Appendix01-Solutions_code_212.m
% Bayesian Optimization (Condensed)
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern
from scipy.stats import norm

def objective_function(P, w0, lambda_val):
    """Simulated trapping efficiency"""
    Q_lambda = 0.5 + 0.5 * np.sin((lambda_val - 950) / 50)
    w_opt = 1.2
    eta = (P * Q_lambda / w0**2) * np.exp(-(w0 - w_opt)**2 / (2 * 0.3**2))
    return eta + np.random.normal(0, 0.05)

def expected_improvement(X, gp, y_max):
    """Acquisition function"""
    mu, sigma = gp.predict(X, return_std=True)
    Z = (mu - y_max) / (sigma + 1e-9)
    ei = (mu - y_max) * norm.cdf(Z) + sigma * norm.pdf(Z)
    return ei

# Bayesian optimization loop
gp = GaussianProcessRegressor(kernel=Matern(nu=2.5), alpha=1e-6)
X_observed, y_observed = [], []

# Initial random sampling
for _ in range(5):
    X_next = np.random.uniform([50, 0.5, 800], [500, 2.0, 1100])
    y_next = objective_function(*X_next)
    X_observed.append(X_next)
    y_observed.append(y_next)

# Iterative optimization
for iteration in range(30):
    gp.fit(X_observed, y_observed)
    
    # Find next point maximizing EI
    X_candidates = np.random.uniform([50, 0.5, 800], [500, 2.0, 1100], (1000, 3))
    ei_values = expected_improvement(X_candidates, gp, max(y_observed))
    X_next = X_candidates[np.argmax(ei_values)]
    
    y_next = objective_function(*X_next)
    X_observed.append(X_next)
    y_observed.append(y_next)
