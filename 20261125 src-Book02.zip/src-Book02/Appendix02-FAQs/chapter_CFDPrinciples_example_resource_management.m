%% chapter_CFDPrinciples_example_resource_management.m
% Computational resource management utilities.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_resource_management
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function resourceMetrics = manageComputationalResources(simulationConfig, ...
    hardwareConfig)
    % MANAGECOMPUTATIONALRESOURCES Strategic resource allocation and monitoring
    % Optimises computational resource utilisation
    %
    % Inputs:
    %   simulationConfig - Struct: mesh size, time steps, physics models
    %   hardwareConfig   - Struct: available CPUs, memory, storage
    %
    % Output:
    %   resourceMetrics  - Resource utilisation statistics
    %
    % Author: Dr Leo Chen
    % Institution: University of Oxford
    % Version: 3.0
    
    fprintf('=== Computational Resource Management ===\n\n');
    
    resourceMetrics = struct();
    
    % Estimate computational requirements
    requirements = estimateComputationalRequirements(simulationConfig);
    
    fprintf('ESTIMATED REQUIREMENTS:\n');
    fprintf('  Memory: %.2f GB\n', requirements.memory_GB);
    fprintf('  Storage: %.2f GB\n', requirements.storage_GB);
    fprintf('  CPU-hours: %.1f\n', requirements.cpuHours);
    fprintf('  Wall-clock time (serial): %.1f hours\n\n', requirements.wallClockSerial);
    
    % Determine optimal parallelisation strategy
    parallelConfig = optimiseParallelisation(requirements, hardwareConfig);
    
    fprintf('PARALLELISATION STRATEGY:\n');
    fprintf('  Processors: %d\n', parallelConfig.numProcessors);
    fprintf('  Domain decomposition: %dx%dx%d\n', parallelConfig.decomposition);
    fprintf('  Expected speedup: %.2fx\n', parallelConfig.expectedSpeedup);
    fprintf('  Parallel efficiency: %.1f%%\n', parallelConfig.efficiency * 100);
    fprintf('  Estimated wall-clock time: %.1f hours\n\n', ...
            parallelConfig.estimatedWallClock);
    
    % Adaptive timestepping strategy
    if simulationConfig.transient
        timestepConfig = designAdaptiveTimestepping(simulationConfig);
        
        fprintf('ADAPTIVE TIMESTEPPING:\n');
        fprintf('  Initial 뿯½뿯½t: %.6e s\n', timestepConfig.dt_initial);
        fprintf('  Maximum 뿯½뿯½t: %.6e s\n', timestepConfig.dt_max);
        fprintf('  CFL target: %.2f\n', timestepConfig.CFL_target);
        fprintf('  Adjustment factor: %.2f\n\n', timestepConfig.adjustmentFactor);
    end
    
    % Memory optimisation recommendations
    memoryOpt = recommendMemoryOptimisation(requirements, hardwareConfig);
    
    fprintf('MEMORY OPTIMISATION:\n');
    fprintf('  Compressed storage: %s\n', string(memoryOpt.useCompression));
    fprintf('  Out-of-core solution: %s\n', string(memoryOpt.outOfCore));
    fprintf('  Checkpoint frequency: every %d steps\n\n', memoryOpt.checkpointFreq);
    
    resourceMetrics.requirements = requirements;
    resourceMetrics.parallelisation = parallelConfig;
    
    if simulationConfig.transient
        resourceMetrics.timestepping = timestepConfig;
    end
    
    resourceMetrics.memoryOptimisation = memoryOpt;
    
    fprintf('Resource management planning completed.\n');
end

function req = estimateComputationalRequirements(simConfig)
    % Estimate computational requirements
    
    req = struct();
    
    numCells = simConfig.numCells;
    numTimeSteps = simConfig.numTimeSteps;
    
    % Memory estimation (GB)
    bytesPerCell = 100;  % Conservative estimate for velocity, pressure, turbulence
    
    if isfield(simConfig, 'thermal') && simConfig.thermal
        bytesPerCell = bytesPerCell + 20;  % Temperature, enthalpy
    end
    
    if isfield(simConfig, 'species') && simConfig.species
        bytesPerCell = bytesPerCell + 40 * simConfig.numSpecies;
    end
    
    req.memory_GB = numCells * bytesPerCell / 1e9;
    
    % Storage estimation (GB) - for time history/checkpoints
    checkpointSize = req.memory_GB;
    numCheckpoints = ceil(numTimeSteps / 100);  % Checkpoint every 100 steps
    
    req.storage_GB = numCheckpoints * checkpointSize;
    
    % CPU time estimation (very rough)
    cellUpdatesPerSecond = 1e5;  % Typical performance metric
    iterationsPerTimeStep = 20;
    
    totalCellUpdates = numCells * numTimeSteps * iterationsPerTimeStep;
    req.cpuHours = totalCellUpdates / cellUpdatesPerSecond / 3600;
    req.wallClockSerial = req.cpuHours;
end

function parallelCfg = optimiseParallelisation(req, hwConfig)
    % Determine optimal parallel configuration
    
    parallelCfg = struct();
    
    availableProcs = hwConfig.numProcessors;
    availableMemory = hwConfig.memory_GB;
    
    % Determine maximum usable processors based on memory
    memoryPerProc = 2;  % Minimum GB per processor
    maxProcsMemory = floor(availableMemory / memoryPerProc);
    
    % Amdahl's law: account for serial fraction
    serialFraction = 0.05;  % 5% serial overhead typical
    
    % Find optimal processor count
    optimalProcs = min([availableProcs, maxProcsMemory, 128]);  % Cap at 128
    
    parallelCfg.numProcessors = optimalProcs;
    
    % Domain decomposition (attempt to balance)
    nx = round(optimalProcs^(1/3));
    ny = nx;
    nz = ceil(optimalProcs / (nx * ny));
    
    parallelCfg.decomposition = [nx, ny, nz];
    
    % Expected parallel performance
    parallelCfg.expectedSpeedup = optimalProcs / (1 + serialFraction * (optimalProcs - 1));
    parallelCfg.efficiency = parallelCfg.expectedSpeedup / optimalProcs;
    
    parallelCfg.estimatedWallClock = req.wallClockSerial / parallelCfg.expectedSpeedup;
end

function timestepCfg = designAdaptiveTimestepping(simConfig)
    % Design adaptive timestepping strategy
    
    timestepCfg = struct();
    
    % Initial timestep from CFL condition
    characteristicLength = simConfig.characteristicLength;
    characteristicVelocity = simConfig.characteristicVelocity;
    soundSpeed = 340;  % m/s for air
    
    CFL_target = 0.8;
    
    dt_CFL = CFL_target * characteristicLength / (characteristicVelocity + soundSpeed);
    
    timestepCfg.dt_initial = dt_CFL;
    timestepCfg.dt_max = dt_CFL * 5;  % Allow up to 5x increase
    timestepCfg.CFL_target = CFL_target;
    timestepCfg.adjustmentFactor = 1.2;  % Increase/decrease by 20% when adapting
end

function memOpt = recommendMemoryOptimisation(req, hwConfig)
    % Recommend memory optimisation strategies
    
    memOpt = struct();
    
    % Use compression if memory-constrained
    memOpt.useCompression = req.memory_GB > 0.8 * hwConfig.memory_GB;
    
    % Use out-of-core if severely constrained
    memOpt.outOfCore = req.memory_GB > hwConfig.memory_GB;
    
    % Checkpoint frequency balances restart capability vs storage
    if req.storage_GB < hwConfig.storage_GB
        memOpt.checkpointFreq = 100;
    else
        memOpt.checkpointFreq = 500;  % Less frequent if storage limited
    end
end
