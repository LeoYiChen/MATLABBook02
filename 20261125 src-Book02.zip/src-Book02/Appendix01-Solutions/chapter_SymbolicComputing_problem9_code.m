%% chapter_SymbolicComputing_problem9_code.m
% Control systems design with comprehensive symbolic root locus analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_SymbolicComputing_problem9_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter_SymbolicComputing_Problem09.m
%
% Control Systems Design with Symbolic Root Locus
%
% Author: Dr Yi Chen
% Institution: University Engineering Department
% Date: 2024
% Version: 1.0
% MATLAB Version: R2024a
%
% Description: Advanced control systems design using symbolic computation
% for root locus, frequency response, and modern control techniques

function control_systems_symbolic_design_system()
    %CONTROL_SYSTEMS_SYMBOLIC_DESIGN_SYSTEM Control design analyser
    %   Comprehensive symbolic control system design and analysis
    
    clear; clc;
    
    % Display system header
    fprintf('Control Systems Design with Symbolic Root Locus\n');
    fprintf('===============================================\n\n');
    
    % Problem 1: Symbolic root locus construction
    construct_symbolic_root_locus();
    
    % Problem 2: LQR controller design
    design_lqr_controller();
    
    % Problem 3: H  controller synthesis
    synthesise_hinf_controller();
    
    % Problem 4: Robust control with uncertainty
    design_robust_controller();
    
    % Advanced demonstrations
    demonstrate_advanced_control_techniques();
    
end

function construct_symbolic_root_locus()
    %CONSTRUCT_SYMBOLIC_ROOT_LOCUS Symbolic root locus analysis
    %   Constructs root locus plots using symbolic methods
    
    fprintf('Problem 1: Symbolic Root Locus Construction\n');
    fprintf('===========================================\n');
    
    syms s K real
    syms num_coeffs [1 inf] real
    syms den_coeffs [1 inf] real
    
    fprintf('Root Locus Theory:\n');
    fprintf(' Characteristic equation: 1 + KG(s)H(s) = 0\n');
    fprintf(' Root locus: Path of closed-loop poles as K varies\n');
    fprintf(' Design tool: Select K for desired pole locations\n\n');
    
    % Standard form
    fprintf('Standard Form:\n');
    fprintf('G(s)H(s) = K   N(s)/D(s)\n');
    fprintf('Characteristic equation: D(s) + KN(s) = 0\n');
    fprintf('Root locus equation: K = -D(s)/N(s)\n\n');
    
    % Root locus rules
    fprintf('Root Locus Construction Rules:\n');
    fprintf('=============================\n');
    
    fprintf('1. Number of branches: n = max(degree of N(s), degree of D(s))\n');
    fprintf('2. Starting points (K=0): Poles of G(s)H(s)\n');
    fprintf('3. Ending points (K= ): Zeros of G(s)H(s)\n');
    fprintf('4. Asymptotes to infinity:\n');
    fprintf('    Number: n - m (n = poles, m = zeros)\n');
    fprintf('    Angles: (2k+1) /(n-m), k = 0,1,...,n-m-1\n');
    fprintf('    Centroid:   = ( poles -  zeros)/(n-m)\n\n');
    
    fprintf('5. Real axis segments: K > 0 when total number of\n');
    fprintf('   poles and zeros to the right is odd\n\n');
    
    fprintf('6. Breakaway/break-in points: Solutions to dK/ds = 0\n');
    fprintf('   or equivalently N''(s)D(s) - N(s)D''(s) = 0\n\n');
    
    fprintf('7. Departure/arrival angles:\n');
    fprintf('     = 180  +  (angles from zeros) -  (angles from other poles)\n\n');
    
    % Example system
    fprintf('Example System Analysis:\n');
    fprintf('=======================\n');
    
    % Transfer function: G(s) = K/[s(s+2)(s+5)]
    fprintf('Plant: G(s) = K/[s(s+2)(s+5)]\n');
    fprintf('Unity feedback: H(s) = 1\n\n');
    
    % Symbolic analysis
    syms s K real
    
    % Numerator and denominator
    N_s = 1;
    D_s = s * (s + 2) * (s + 5);
    D_s_expanded = expand(D_s);
    
    fprintf('Open-loop transfer function:\n');
    fprintf('G(s)H(s) = %s/(%s)\n', char(N_s), char(D_s_expanded));
    fprintf('         = 1/(s + 7s + 10s)\n\n');
    
    % Poles and zeros
    poles = solve(D_s == 0, s);
    fprintf('Poles: ');
    for i = 1:length(poles)
        fprintf('s = %s', char(poles(i)));
        if i < length(poles)
            fprintf(', ');
        end
    end
    fprintf('\n');
    fprintf('Zeros: None (except at infinity)\n\n');
    
    % Asymptotes
    n_poles = 3;
    n_zeros = 0;
    n_asymptotes = n_poles - n_zeros;
    
    sum_poles = sum(double(poles));
    sum_zeros = 0;
    centroid = (sum_poles - sum_zeros) / n_asymptotes;
    
    fprintf('Asymptotes:\n');
    fprintf('Number of asymptotes: %d\n', n_asymptotes);
    fprintf('Centroid:   = %.3f\n', centroid);
    fprintf('Angles: ');
    for k = 0:n_asymptotes-1
        angle = (2*k + 1) * 180 / n_asymptotes;
        fprintf('%.0f ', angle);
        if k < n_asymptotes-1
            fprintf(', ');
        end
    end
    fprintf('\n\n');
    
    % Breakaway points
    fprintf('Breakaway Points:\n');
    
    % For this system: K = -s(s+2)(s+5) = -s - 7s - 10s
    K_expr = -s^3 - 7*s^2 - 10*s;
    dK_ds = diff(K_expr, s);
    
    fprintf('K(s) = %s\n', char(K_expr));
    fprintf('dK/ds = %s\n', char(dK_ds));
    
    breakaway_points = solve(dK_ds == 0, s);
    
    fprintf('Breakaway point candidates:\n');
    for i = 1:length(breakaway_points)
        s_val = double(breakaway_points(i));
        K_val = double(subs(K_expr, s, breakaway_points(i)));
        
        if isreal(s_val) && K_val > 0
            fprintf('s = %.3f, K = %.3f (valid)\n', s_val, K_val);
        else
            fprintf('s = %.3f + %.3fj (invalid)\n', real(s_val), imag(s_val));
        end
    end
    fprintf('\n');
    
    % Demonstrate specific design
    demonstrate_root_locus_design();
end

function demonstrate_root_locus_design()
    %DEMONSTRATE_ROOT_LOCUS_DESIGN Specific root locus design example
    %   Shows controller design using root locus method
    
    fprintf('Root Locus Design Example:\n');
    fprintf('-------------\n');
    
    fprintf('Design specifications:\n');
    fprintf(' Settling time: ts   2 seconds (2%% criterion)\n');
    fprintf(' Overshoot: Mp   20%%\n');
    fprintf(' Zero steady-state error to step input\n\n');
    
    % Convert specifications to pole locations
    Mp_spec = 0.20;  % 20% overshoot
    ts_spec = 2.0;   % 2 second settling time
    
    % Damping ratio from overshoot
    zeta = sqrt((log(Mp_spec))^2 / (pi^2 + (log(Mp_spec))^2));
    
    % Natural frequency from settling time
    omega_n = 4 / (zeta * ts_spec);
    
    fprintf('Translated specifications:\n');
    fprintf('Damping ratio:   = %.3f\n', zeta);
    fprintf('Natural frequency:   = %.2f rad/s\n', omega_n);
    
    % Desired pole locations
    s1_desired = -zeta * omega_n + 1j * omega_n * sqrt(1 - zeta^2);
    s2_desired = -zeta * omega_n - 1j * omega_n * sqrt(1 - zeta^2);
    
    fprintf('Desired closed-loop poles:\n');
    fprintf('s, = %.3f   %.3fj\n\n', real(s1_desired), imag(s1_desired));
    
    % Check if desired poles are on root locus
    s_test = s1_desired;
    K_required = -s_test * (s_test + 2) * (s_test + 5);
    
    fprintf('Required gain for desired poles:\n');
    fprintf('K = %.3f\n', abs(K_required));
    
    if abs(imag(K_required)) < 1e-6 && real(K_required) > 0
        fprintf(' Desired poles are on root locus\n');
    else
        fprintf(' Desired poles are NOT on root locus\n');
        fprintf('  Need to modify design (add compensator)\n');
    end
    
    % Lead compensator design
    if abs(imag(K_required)) > 1e-6 || real(K_required) <= 0
        fprintf('\nLead Compensator Design:\n');
        fprintf('=======================\n');
        
        % Calculate required angle contribution
        angles_from_poles = angle(s1_desired - 0) + angle(s1_desired - (-2)) + angle(s1_desired - (-5));
        angles_from_zeros = 0;  % No zeros in original system
        
        angle_deficiency = pi - (angles_from_poles - angles_from_zeros);
        
        fprintf('Angle deficiency: %.1f \n', angle_deficiency * 180/pi);
        fprintf('Lead compensator must contribute: %.1f \n', angle_deficiency * 180/pi);
        
        % Lead compensator: Gc(s) = (s + z)/(s + p) where p > z
        % Place zero to contribute desired angle
        
        % Trial zero location
        z_c = 3;  % Trial value
        
        % Calculate required pole location
        angle_from_zero = angle(s1_desired - (-z_c));
        required_angle_from_pole = angle_from_zero - angle_deficiency;
        
        % Solve for pole location
        p_c = real(s1_desired) - imag(s1_desired) / tan(required_angle_from_pole);
        
        fprintf('Lead compensator:\n');
        fprintf('Zero: z = %.2f\n', z_c);
        fprintf('Pole: p = %.2f\n', p_c);
        fprintf('Gc(s) = (s + %.2f)/(s + %.2f)\n\n', z_c, p_c);
        
        % Verify angle condition
        total_angle = angle(s1_desired - 0) + angle(s1_desired - (-2)) + angle(s1_desired - (-5)) + ...
                     angle(s1_desired - (-z_c)) - angle(s1_desired - (-p_c));
        
        fprintf('Verification:\n');
        fprintf('Total angle: %.1f  (should be  180 )\n', total_angle * 180/pi);
        
        if abs(abs(total_angle) - pi) < 0.1
            fprintf(' Angle condition satisfied\n');
        else
            fprintf(' Angle condition not satisfied - adjust compensator\n');
        end
    end
    
    fprintf('\n');
end

function design_lqr_controller()
    %DESIGN_LQR_CONTROLLER Linear Quadratic Regulator design
    %   Implements optimal LQR controller using symbolic methods
    
    fprintf('Problem 2: LQR Controller Design\n');
    fprintf('================================\n');
    
    syms A B Q R P K real
    syms x u J real
    
    fprintf('Linear Quadratic Regulator Theory:\n');
    fprintf(' System:  = Ax + Bu\n');
    fprintf(' Cost function: J =  ^  (xQx + uRu) dt\n');
    fprintf(' Optimal control: u* = -Kx where K = RBP\n');
    fprintf(' Riccati equation: AP + PA - PBRBP + Q = 0\n\n');
    
    % Properties of LQR
    fprintf('LQR Properties:\n');
    fprintf(' Guaranteed stability for Q   0, R > 0\n');
    fprintf(' Infinite gain margin\n');
    fprintf(' Phase margin:   60 \n');
    fprintf(' Good robustness properties\n\n');
    
    % Design procedure
    fprintf('Design Procedure:\n');
    fprintf('1. Choose weighting matrices Q and R\n');
    fprintf('2. Solve Riccati equation for P\n');
    fprintf('3. Compute feedback gain: K = RBP\n');
    fprintf('4. Verify closed-loop stability\n\n');
    
    % Weighting matrix selection
    fprintf('Weighting Matrix Selection:\n');
    fprintf(' Q: Penalises state deviations\n');
    fprintf('  - Large Q   aggressive regulation\n');
    fprintf('  - Small Q   conservative regulation\n');
    fprintf(' R: Penalises control effort\n');
    fprintf('  - Large R   less control action\n');
    fprintf('  - Small R   more aggressive control\n\n');
    
    % Example design
    demonstrate_lqr_design();
    
    % LQG extension
    fprintf('LQG (Linear Quadratic Gaussian):\n');
    fprintf('================================\n');
    
    fprintf('System with noise:\n');
    fprintf(' = Ax + Bu + Gw (process noise)\n');
    fprintf('y = Cx + v (measurement noise)\n\n');
    
    fprintf('Separation principle:\n');
    fprintf(' Design LQR for full state feedback\n');
    fprintf(' Design Kalman filter for state estimation\n');
    fprintf(' Combine: u = -Kx (certainty equivalence)\n\n');
    
    fprintf('Kalman filter:\n');
    fprintf('x = Ax + Bu + L(y - Cx)\n');
    fprintf('where L = PCR_v (Kalman gain)\n');
    fprintf('P satisfies: APc + PcA - PcCRvCPc + GQwG = 0\n\n');
end

function demonstrate_lqr_design()
    %DEMONSTRATE_LQR_DESIGN Example LQR design for inverted pendulum
    %   Shows LQR design for cart-pole system
    
    fprintf('Example: Inverted Pendulum LQR Design\n');
    fprintf('-------------------\n');
    
    fprintf('Cart-pole system:\n');
    fprintf('States: x = [position, velocity, angle, angular_velocity]\n');
    fprintf('Control: u = force on cart\n\n');
    
    % System parameters
    M = 1.0;    % Cart mass (kg)
    m = 0.1;    % Pendulum mass (kg)
    l = 0.5;    % Pendulum length (m)
    g = 9.81;   % Gravity (m/s)
    
    fprintf('Parameters:\n');
    fprintf('Cart mass: M = %.1f kg\n', M);
    fprintf('Pendulum mass: m = %.1f kg\n', m);
    fprintf('Pendulum length: l = %.1f m\n', l);
    fprintf('Gravity: g = %.2f m/s\n\n', g);
    
    % Linearised state-space model (around upright position)
    A = [0,    1,           0,                    0;
         0,    0,    -m*g/M,                     0;
         0,    0,           0,                    1;
         0,    0,    g*(M+m)/(M*l),              0];
    
    B = [0; 1/M; 0; 1/(M*l)];
    
    C = [1, 0, 0, 0;  % Position measurement
         0, 0, 1, 0]; % Angle measurement
    
    D = [0; 0];
    
    fprintf('State-space matrices:\n');
    fprintf('A matrix:\n');
    disp(A);
    fprintf('B matrix:\n');
    disp(B);
    fprintf('C matrix:\n');
    disp(C);
    
    % Check controllability
    Co = ctrb(A, B);
    rank_Co = rank(Co);
    
    fprintf('Controllability analysis:\n');
    fprintf('Controllability matrix rank: %d (system order: %d)\n', rank_Co, size(A,1));
    
    if rank_Co == size(A,1)
        fprintf(' System is completely controllable\n');
    else
        fprintf(' System is not completely controllable\n');
    end
    fprintf('\n');
    
    % Design LQR controller
    fprintf('LQR Design:\n');
    
    % Weighting matrices
    Q = diag([10, 1, 100, 1]);  % Penalise position and angle more
    R = 0.1;                    % Control effort penalty
    
    fprintf('Weighting matrices:\n');
    fprintf('Q = diag([%.0f, %.0f, %.0f, %.0f])\n', diag(Q));
    fprintf('R = %.1f\n\n', R);
    
    % Solve Riccati equation
    [P, ~, K] = care(A, B, Q, R);
    
    fprintf('LQR gains:\n');
    fprintf('K = [%.3f, %.3f, %.3f, %.3f]\n', K);
    
    % Closed-loop analysis
    A_cl = A - B*K;
    eigenvalues_cl = eig(A_cl);
    
    fprintf('\nClosed-loop eigenvalues:\n');
    for i = 1:length(eigenvalues_cl)
        lambda = eigenvalues_cl(i);
        if isreal(lambda)
            fprintf(' %d = %.3f\n', i, lambda);
        else
            fprintf(' %d = %.3f   %.3fj\n', i, real(lambda), abs(imag(lambda)));
            i = i + 1;  % Skip complex conjugate
        end
    end
    
    % Stability check
    if all(real(eigenvalues_cl) < 0)
        fprintf(' Closed-loop system is stable\n');
    else
        fprintf(' Closed-loop system is unstable\n');
    end
    
    % Performance analysis
    fprintf('\nPerformance characteristics:\n');
    
    % Settling times (approximation)
    settling_times = -4 ./ real(eigenvalues_cl);
    settling_times = settling_times(settling_times > 0);  % Only stable modes
    
    fprintf('Fastest settling time: %.3f s\n', min(settling_times));
    fprintf('Slowest settling time: %.3f s\n', max(settling_times));
    
    % Cost analysis
    fprintf('\nOptimal cost: J* = xPx for initial condition x\n');
    fprintf('P matrix computed from Riccati equation\n');
    
    fprintf('\n');
end

function synthesise_hinf_controller()
    %SYNTHESISE_HINF_CONTROLLER H-infinity controller synthesis
    %   Implements H  optimal control design
    
    fprintf('Problem 3: H  Controller Synthesis\n');
    fprintf('===================================\n');
    
    syms s gamma P_11 P_12 P_21 P_22 real
    
    fprintf('H  Control Problem:\n');
    fprintf(' Minimise ||T_zw||_  subject to internal stability\n');
    fprintf(' T_zw: closed-loop transfer function from w to z\n');
    fprintf(' w: exogenous inputs (disturbances, references)\n');
    fprintf(' z: regulated outputs (errors, control effort)\n\n');
    
    % Standard H  problem setup
    fprintf('Standard H  Problem Setup:\n');
    fprintf('=========================\n');
    
    fprintf('Generalised plant P(s):\n');
    fprintf('z   P P w\n');
    fprintf('y = P P u\n\n');
    
    fprintf('Controller K(s): u = K(s)y\n');
    fprintf('Closed-loop: T_zw = P + PK(I - PK)P\n\n');
    
    % Mixed sensitivity problem
    fprintf('Mixed Sensitivity Problem:\n');
    fprintf('=========================\n');
    
    fprintf('Typical formulation:\n');
    fprintf(' Sensitivity: S = (I + GK)\n');
    fprintf(' Complementary: T = GK(I + GK)\n');
    fprintf(' Control sensitivity: U = K(I + GK)\n\n');
    
    fprintf('Cost function:\n');
    fprintf('||WS ||    \n');
    fprintf('  WU ||_   \n');
    fprintf('  WT ||    \n\n');
    
    fprintf('Design objectives:\n');
    fprintf(' W: Performance (tracking, disturbance rejection)\n');
    fprintf(' W: Control effort limitation\n');
    fprintf(' W: Robust stability (unmodeled dynamics)\n\n');
    
    % Solution method
    fprintf('Solution via Riccati Equations:\n');
    fprintf('==============================\n');
    
    fprintf('Two Riccati equations:\n');
    fprintf('1. X : State feedback problem\n');
    fprintf('2. Y : Filtering problem\n\n');
    
    fprintf('Solvability conditions:\n');
    fprintf(' (A,B) stabilisable\n');
    fprintf(' (C,A) detectable\n');
    fprintf(' No finite zeros on j  axis\n');
    fprintf('  (X Y ) <   (spectral radius condition)\n\n');
    
    fprintf('Controller construction:\n');
    fprintf('K (s) = -(BX  + DC)(I + Y X / )(C + BX / )\n\n');
    
    % Demonstrate mixed sensitivity design
    demonstrate_mixed_sensitivity_design();
    
    %  -synthesis
    fprintf(' -Synthesis (Structured Uncertainty):\n');
    fprintf('====================================\n');
    
    fprintf('Structured singular value  :\n');
    fprintf(' Extension of H  for structured uncertainty\n');
    fprintf(' Handles parametric uncertainty\n');
    fprintf(' D-K iteration algorithm\n\n');
    
    fprintf('Uncertainty description:\n');
    fprintf('  = diag( I_{r}, ...,  I_{r},  , ...,  )\n');
    fprintf('where | |   1 and || ||   1\n\n');
    
    fprintf('Robust stability condition:\n');
    fprintf(' _ (M(j )) < 1 for all  \n');
    fprintf('where M is the closed-loop transfer matrix\n\n');
end

function demonstrate_mixed_sensitivity_design()
    %DEMONSTRATE_MIXED_SENSITIVITY_DESIGN Example mixed sensitivity design
    %   Shows H  design for aircraft pitch control
    
    fprintf('Example: Aircraft Pitch Control H  Design\n');
    fprintf('---------------------\n');
    
    fprintf('Aircraft longitudinal dynamics:\n');
    fprintf('  + 2    +    =   \n');
    fprintf('where   = pitch angle,   = elevator deflection\n\n');
    
    % System parameters
    omega_n = 2.0;    % Natural frequency (rad/s)
    zeta = 0.1;       % Damping ratio (lightly damped)
    
    fprintf('Parameters:\n');
    fprintf('Natural frequency:   = %.1f rad/s\n', omega_n);
    fprintf('Damping ratio:   = %.1f\n\n', zeta);
    
    % Transfer function
    fprintf('Plant transfer function:\n');
    fprintf('G(s) =  /(s + 2  s +  )\n');
    fprintf('     = %.1f/(s + %.1fs + %.1f)\n\n', omega_n^2, 2*zeta*omega_n, omega_n^2);
    
    % Design requirements
    fprintf('Design requirements:\n');
    fprintf(' Tracking: error < 5%% for step reference\n');
    fprintf(' Disturbance rejection: -40 dB at low frequencies\n');
    fprintf(' Control bandwidth: < 10 rad/s\n');
    fprintf(' Robust stability: 6 dB gain margin, 45  phase margin\n\n');
    
    % Weight selection
    fprintf('Weight function design:\n');
    fprintf('======================\n');
    
    % Performance weight W1 (tracking and disturbance rejection)
    fprintf('W(s): Performance weight\n');
    fprintf('Inverse desired sensitivity shape\n');
    fprintf('W(s) = (s/M +  B)/(s +  B A)\n');
    fprintf('where M = 2 (6 dB peak),  B = 0.1 rad/s, A = 0.01\n\n');
    
    M_s = 2;      % Sensitivity peak
    omega_B = 0.1; % Bandwidth
    A_s = 0.01;   % High frequency gain
    
    % Control effort weight W2
    fprintf('W(s): Control weight\n');
    fprintf('Limit control bandwidth and effort\n');
    fprintf('W(s) = 0.1(s + 1)/(0.1s + 1)\n\n');
    
    % Robustness weight W3
    fprintf('W(s): Robustness weight\n');
    fprintf('Model uncertainty at high frequencies\n');
    fprintf('W(s) = (s/10 + 0.1)/(s + 10)\n\n');
    
    % Closed-loop specifications
    fprintf('Resulting closed-loop requirements:\n');
    fprintf(' |S(j )| < 1/|W(j )| (performance)\n');
    fprintf(' |U(j )| < 1/|W(j )| (control effort)\n');
    fprintf(' |T(j )| < 1/|W(j )| (robustness)\n\n');
    
    % H  norm bound
    fprintf('H  optimisation:\n');
    fprintf('minimise   such that ||WS||     <  \n');
    fprintf('                     WU||_    \n');
    fprintf('                     WT||     \n\n');
    
    % Solution characteristics
    fprintf('Typical solution characteristics:\n');
    fprintf('  _opt   1.1 (achievable with good design)\n');
    fprintf(' Controller order: typically n_plant + n_weights\n');
    fprintf(' Waterbed effect: improvement in one frequency\n');
    fprintf('  range requires degradation in another\n\n');
    
    % Implementation considerations
    fprintf('Implementation considerations:\n');
    fprintf(' High-order controllers may require reduction\n');
    fprintf(' Balanced truncation preserves H  norm bounds\n');
    fprintf(' Hankel norm approximation for optimal reduction\n');
    fprintf(' Verify robustness with reduced controller\n\n');
end

function design_robust_controller()
    %DESIGN_ROBUST_CONTROLLER Robust control with uncertainty
    %   Designs controllers for systems with parametric uncertainty
    
    fprintf('Problem 4: Robust Control with Uncertainty Modelling\n');
    fprintf('====================================================\n');
    
    syms delta real
    syms G_nom G_pert real
    
    fprintf('Uncertainty Modelling:\n');
    fprintf('=====================\n');
    
    fprintf('Types of uncertainty:\n');
    fprintf(' Parametric: uncertain parameters in known structure\n');
    fprintf(' Unstructured: unmodeled dynamics\n');
    fprintf(' Structured: combination of both\n\n');
    
    % Additive uncertainty
    fprintf('Additive Uncertainty:\n');
    fprintf('G(s) = G(s) + W_a(s) _a(s)\n');
    fprintf('where || _a||_    1, |W_a(j )| = bound on uncertainty\n\n');
    
    % Multiplicative uncertainty
    fprintf('Multiplicative Uncertainty:\n');
    fprintf('G(s) = G(s)[I + W_m(s) _m(s)]\n');
    fprintf('where || _m||_    1\n\n');
    
    % Robust stability
    fprintf('Robust Stability Conditions:\n');
    fprintf('===========================\n');
    
    fprintf('Small gain theorem:\n');
    fprintf('System stable for all allowable   if:\n');
    fprintf('||M(s) (s)||_  < 1\n');
    fprintf('where M(s) is the transfer function seen by  \n\n');
    
    fprintf('For multiplicative uncertainty:\n');
    fprintf('|W_m(j )T(j )| < 1 for all  \n');
    fprintf('where T = complementary sensitivity\n\n');
    
    fprintf('For additive uncertainty:\n');
    fprintf('|W_a(j )KS(j )| < 1 for all  \n');
    fprintf('where S = sensitivity, K = controller\n\n');
    
    % Robust performance
    fprintf('Robust Performance:\n');
    fprintf('==================\n');
    
    fprintf('Performance requirement:\n');
    fprintf('||W_p(s)S(s)||_  < 1 for all allowable plants\n\n');
    
    fprintf('Combined robust stability and performance:\n');
    fprintf('||W_p S ||     < 1\n');
    fprintf('  W_m T ||_      \n\n');
    
    % Demonstrate uncertainty analysis
    demonstrate_uncertainty_analysis();
    
    % QFT (Quantitative Feedback Theory)
    fprintf('Quantitative Feedback Theory (QFT):\n');
    fprintf('===================================\n');
    
    fprintf('Frequency domain design method:\n');
    fprintf(' Handle parametric uncertainty directly\n');
    fprintf(' Nichols chart based design\n');
    fprintf(' Loop shaping for robust performance\n\n');
    
    fprintf('Design procedure:\n');
    fprintf('1. Plant uncertainty templates\n');
    fprintf('2. Robust stability bounds\n');
    fprintf('3. Robust performance bounds\n');
    fprintf('4. Loop shaping to satisfy bounds\n');
    fprintf('5. Prefilter design\n\n');
    
    % Linear Parameter Varying (LPV) control
    fprintf('Linear Parameter Varying (LPV) Control:\n');
    fprintf('======================================\n');
    
    fprintf('System description:\n');
    fprintf(' = A( )x + B( )u\n');
    fprintf('y = C( )x + D( )u\n');
    fprintf('where  (t) is time-varying parameter\n\n');
    
    fprintf('Gain scheduling approach:\n');
    fprintf(' Design controllers at operating points\n');
    fprintf(' Interpolate between designs\n');
    fprintf(' LPV synthesis for guaranteed performance\n\n');
end

function demonstrate_uncertainty_analysis()
    %DEMONSTRATE_UNCERTAINTY_ANALYSIS Example uncertainty analysis
    %   Shows robust stability analysis with parameter variations
    
    fprintf('Example: DC Motor with Parameter Uncertainty\n');
    fprintf('----------------------\n');
    
    fprintf('DC motor model:\n');
    fprintf('Transfer function: G(s) = K/(s(Ts + 1))\n');
    fprintf('where K = motor gain, T = time constant\n\n');
    
    % Nominal parameters
    K_nom = 10;   % Nominal gain
    T_nom = 0.1;  % Nominal time constant (s)
    
    % Parameter uncertainty
    K_uncertainty = 0.5;  %  50% gain uncertainty
    T_uncertainty = 0.3;  %  30% time constant uncertainty
    
    fprintf('Nominal parameters:\n');
    fprintf('K_nom = %.0f, T_nom = %.1f s\n\n', K_nom, T_nom);
    
    fprintf('Parameter uncertainty:\n');
    fprintf('K   [%.1f, %.1f] ( %.0f%%)\n', ...
           K_nom*(1-K_uncertainty), K_nom*(1+K_uncertainty), K_uncertainty*100);
    fprintf('T   [%.2f, %.2f] ( %.0f%%)\n\n', ...
           T_nom*(1-T_uncertainty), T_nom*(1+T_uncertainty), T_uncertainty*100);
    
    % Controller design
    fprintf('Controller design:\n');
    fprintf('PI controller: C(s) = Kp + Ki/s\n');
    fprintf('Designed for nominal plant\n\n');
    
    % PI parameters (designed for nominal case)
    Kp = 0.5;
    Ki = 2.0;
    
    fprintf('PI parameters:\n');
    fprintf('Kp = %.1f, Ki = %.1f\n\n', Kp, Ki);
    
    % Stability analysis
    fprintf('Robust stability analysis:\n');
    fprintf('=========================\n');
    
    % Generate parameter grid
    K_values = K_nom * [1-K_uncertainty, 1, 1+K_uncertainty];
    T_values = T_nom * [1-T_uncertainty, 1, 1+T_uncertainty];
    
    fprintf('Parameter combinations tested:\n');
    fprintf('K values: [%.1f, %.1f, %.1f]\n', K_values);
    fprintf('T values: [%.3f, %.3f, %.3f]\n\n', T_values);
    
    stable_count = 0;
    total_combinations = length(K_values) * length(T_values);
    
    fprintf('Closed-loop pole analysis:\n');
    for i = 1:length(K_values)
        for j = 1:length(T_values)
            K_val = K_values(i);
            T_val = T_values(j);
            
            % Closed-loop characteristic polynomial
            % 1 + C(s)G(s) = 1 + (Kp + Ki/s) * K/(s(Ts+1)) = 0
            % s(Ts+1) + (Kp + Ki/s) * K = 0
            % sT + s + KKp + KKi = 0
            % sT + s(1 + KKp) + KKi = 0
            
            % Characteristic polynomial coefficients
            a2 = T_val;
            a1 = 1 + K_val * Kp;
            a0 = K_val * Ki;
            
            % Compute roots
            char_poly = [a2, a1, a0];
            poles = roots(char_poly);
            
            % Check stability
            is_stable = all(real(poles) < 0);
            
            fprintf('K=%.1f, T=%.3f: poles = [%.3f, %.3f]', ...
                   K_val, T_val, poles(1), poles(2));
            
            if is_stable
                fprintf('  Stable\n');
                stable_count = stable_count + 1;
            else
                fprintf('  Unstable\n');
            end
        end
    end
    
    fprintf('\nRobustness summary:\n');
    fprintf('Stable combinations: %d/%d (%.1f%%)\n', ...
           stable_count, total_combinations, stable_count/total_combinations*100);
    
    if stable_count == total_combinations
        fprintf(' Controller is robust to specified uncertainty\n');
    else
        fprintf(' Controller lacks robustness - redesign required\n');
    end
    
    fprintf('\n');
end

function demonstrate_advanced_control_techniques()
    %DEMONSTRATE_ADVANCED_CONTROL_TECHNIQUES Show sophisticated methods
    %   Demonstrates advanced control analysis and design techniques
    
    fprintf('Advanced Control Techniques\n');
    fprintf('==========================\n');
    
    % Technique 1: Adaptive control
    fprintf('1. Adaptive Control:\n');
    fprintf(' Model Reference Adaptive Control (MRAC)\n');
    fprintf(' Self-Tuning Regulators (STR)\n');
    fprintf(' Direct and indirect adaptation\n');
    fprintf(' Lyapunov stability analysis\n\n');
    
    % Technique 2: Nonlinear control
    fprintf('2. Nonlinear Control:\n');
    fprintf(' Feedback linearisation\n');
    fprintf(' Sliding mode control\n');
    fprintf(' Backstepping design\n');
    fprintf(' Lyapunov-based methods\n\n');
    
    % Technique 3: Predictive control
    fprintf('3. Model Predictive Control (MPC):\n');
    fprintf(' Finite horizon optimisation\n');
    fprintf(' Constraint handling\n');
    fprintf(' Receding horizon implementation\n');
    fprintf(' Economic MPC formulations\n\n');
    
    % Technique 4: Distributed control
    fprintf('4. Distributed Control:\n');
    fprintf(' Multi-agent consensus\n');
    fprintf(' Formation control\n');
    fprintf(' Networked control systems\n');
    fprintf(' Communication constraints\n\n');
    
    % Technique 5: Machine learning integration
    fprintf('5. Machine Learning in Control:\n');
    fprintf(' Reinforcement learning control\n');
    fprintf(' Neural network controllers\n');
    fprintf(' Learning-based MPC\n');
    fprintf(' Safe learning with guarantees\n\n');
    
    % Technique 6: Quantum control
    fprintf('6. Quantum Control:\n');
    fprintf(' Quantum gate synthesis\n');
    fprintf(' Optimal control for quantum systems\n');
    fprintf(' Decoherence and noise handling\n');
    fprintf(' Quantum error correction\n\n');
    
    fprintf('Advanced control techniques demonstration complete.\n\n');
end
