%% chapter_ES_code_problem3.m
% Real-Time PID Controller Simulation with Performance Monitoring
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem3
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem3
    % MATLABBook_ChapterES_Problem3.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Real-time PID controller simulation for second-order system
    %   with comprehensive performance monitoring, tuning comparison,
    %   and disturbance rejection analysis.
    %
    % Dependencies: Control System Toolbox
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 3
    
    fprintf('\n=== Problem 3: Real-Time PID Controller Simulation ===\n\n');
    
    %% System Configuration
    
    % Second-order plant (e.g., DC motor position control)
    wn = 2.0;        % Natural frequency [rad/s]
    zeta = 0.3;      % Damping ratio (underdamped)
    
    % Continuous-time transfer function
    num_c = wn^2;
    den_c = [1, 2*zeta*wn, wn^2];
    G_c = tf(num_c, den_c);
    
    fprintf('Plant Model (continuous): G(s) = %.1f / (s^2 + %.2fs + %.1f)\n', ...
            wn^2, 2*zeta*wn, wn^2);
    fprintf('Natural frequency: %.2f rad/s\n', wn);
    fprintf('Damping ratio: %.2f (underdamped)\n\n', zeta);
    
    % Discretization
    Ts = 0.01;       % Sampling time [s] (100 Hz)
    G_d = c2d(G_c, Ts, 'zoh');  % Zero-order hold discretization
    [num_d, den_d] = tfdata(G_d, 'v');
    
    fprintf('Sampling time: %.3f s (%.0f Hz)\n', Ts, 1/Ts);
    fprintf('Discrete plant: G(z)\n\n');
    
    %% Simulation Parameters
    
    T_sim = 10;      % Simulation duration [s]
    t = 0:Ts:T_sim;
    N = length(t);
    
    % Reference setpoint (step input)
    r = ones(1, N);  % Unit step
    
    % Add setpoint change at t=5s
    r(t >= 5) = 1.5;
    
    % Disturbance injection at t=7s
    d = zeros(1, N);
    d(t >= 7) = 0.3;
    
    % Measurement noise
    noise_std = 0.01;
    rng(42);
    noise = noise_std * randn(1, N);
    
    %% PID Controller Design - Method 1: Ziegler-Nichols
    
    fprintf('=== Tuning Method 1: Ziegler-Nichols ===\n');
    
    % Find ultimate gain and period (closed-loop stability boundary)
    % Using relay feedback test (simplified analytical approach here)
    Ku = 15.0;       % Ultimate gain (from stability analysis)
    Tu = 2.5;        % Ultimate period [s]
    
    % Ziegler-Nichols PID tuning rules
    Kp_zn = 0.6 * Ku;
    Ki_zn = 2 * Kp_zn / Tu;
    Kd_zn = Kp_zn * Tu / 8;
    
    fprintf('Ultimate gain Ku: %.2f\n', Ku);
    fprintf('Ultimate period Tu: %.2f s\n', Tu);
    fprintf('PID gains: Kp=%.2f, Ki=%.2f, Kd=%.2f\n\n', Kp_zn, Ki_zn, Kd_zn);
    
    % Simulate with Ziegler-Nichols tuning
    [y_zn, u_zn, e_zn, perf_zn] = simulatePID(G_d, r, d, noise, Ts, ...
                                               Kp_zn, Ki_zn, Kd_zn);
    
    displayPerformance('Ziegler-Nichols', perf_zn);
    
    %% PID Controller Design - Method 2: Manual Tuning
    
    fprintf('=== Tuning Method 2: Manual Tuning ===\n');
    
    % Manual tuning for better performance
    Kp_man = 8.0;
    Ki_man = 4.0;
    Kd_man = 2.0;
    
    fprintf('PID gains: Kp=%.2f, Ki=%.2f, Kd=%.2f\n\n', Kp_man, Ki_man, Kd_man);
    
    [y_man, u_man, e_man, perf_man] = simulatePID(G_d, r, d, noise, Ts, ...
                                                   Kp_man, Ki_man, Kd_man);
    
    displayPerformance('Manual Tuning', perf_man);
    
    %% PID Controller Design - Method 3: Optimization-based
    
    fprintf('=== Tuning Method 3: Optimization (ITAE minimization) ===\n');
    
    % Optimize PID gains to minimize ITAE
    objective = @(K) simulateAndComputeITAE(G_d, r, d, noise, Ts, K(1), K(2), K(3));
    
    K0 = [5, 3, 1];  % Initial guess
    lb = [0, 0, 0];  % Lower bounds
    ub = [20, 10, 5]; % Upper bounds
    
    options = optimoptions('fmincon', 'Display', 'off', 'MaxIterations', 100);
    K_opt = fmincon(objective, K0, [], [], [], [], lb, ub, [], options);
    
    Kp_opt = K_opt(1);
    Ki_opt = K_opt(2);
    Kd_opt = K_opt(3);
    
    fprintf('Optimized PID gains: Kp=%.2f, Ki=%.2f, Kd=%.2f\n\n', ...
            Kp_opt, Ki_opt, Kd_opt);
    
    [y_opt, u_opt, e_opt, perf_opt] = simulatePID(G_d, r, d, noise, Ts, ...
                                                   Kp_opt, Ki_opt, Kd_opt);
    
    displayPerformance('Optimized', perf_opt);
    
    %% Comparative Analysis: P vs PI vs PD vs PID
    
    fprintf('=== Component Analysis (Manual gains) ===\n');
    
    % P controller only
    [y_p, ~, ~, perf_p] = simulatePID(G_d, r, d, noise, Ts, Kp_man, 0, 0);
    
    % PI controller
    [y_pi, ~, ~, perf_pi] = simulatePID(G_d, r, d, noise, Ts, Kp_man, Ki_man, 0);
    
    % PD controller
    [y_pd, ~, ~, perf_pd] = simulatePID(G_d, r, d, noise, Ts, Kp_man, 0, Kd_man);
    
    % Full PID (already computed)
    
    displayPerformance('P only', perf_p);
    displayPerformance('PI', perf_pi);
    displayPerformance('PD', perf_pd);
    displayPerformance('PID', perf_man);
    
    %% Summary Table
    
    fprintf('\n=== Performance Comparison Table ===\n\n');
    fprintf('%-15s %8s %8s %8s %8s %8s\n', 'Controller', 'Rise[s]', ...
            'Settle[s]', 'Over[%%]', 'SSE', 'ITAE');
    fprintf('%s\n', repmat('-', 1, 70));
    
    controllers = {'P-only', 'PI', 'PD', 'PID-Manual', 'PID-ZN', 'PID-Opt'};
    perfs = {perf_p, perf_pi, perf_pd, perf_man, perf_zn, perf_opt};
    
    for i = 1:length(controllers)
        p = perfs{i};
        fprintf('%-15s %8.3f %8.3f %8.2f %8.4f %8.3f\n', controllers{i}, ...
                p.riseTime, p.settlingTime, p.overshoot, p.steadyStateError, p.ITAE);
    end
    fprintf('\n');
    
    %% Visualization
    
    figure('Position', [100 100 1400 900]);
    
    % Subplot 1: Step response comparison (tuning methods)
    subplot(3, 3, 1);
    hold on;
    plot(t, r, 'k-', 'LineWidth', 1.5, 'DisplayName', 'Setpoint');
    plot(t, y_zn, 'r-', 'LineWidth', 1.2, 'DisplayName', 'Ziegler-Nichols');
    plot(t, y_man, 'b-', 'LineWidth', 1.2, 'DisplayName', 'Manual');
    plot(t, y_opt, 'g-', 'LineWidth', 1.2, 'DisplayName', 'Optimized');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Output $y(t)$', 'Interpreter', 'latex');
    title('Step Response: Tuning Comparison', 'Interpreter', 'latex');
    legend('Location', 'southeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 T_sim]);
    
    % Subplot 2: Control effort comparison
    subplot(3, 3, 2);
    hold on;
    plot(t, u_zn, 'r-', 'LineWidth', 1.2, 'DisplayName', 'Ziegler-Nichols');
    plot(t, u_man, 'b-', 'LineWidth', 1.2, 'DisplayName', 'Manual');
    plot(t, u_opt, 'g-', 'LineWidth', 1.2, 'DisplayName', 'Optimized');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Control Signal $u(t)$', 'Interpreter', 'latex');
    title('Control Effort', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 T_sim]);
    
    % Subplot 3: Error signals
    subplot(3, 3, 3);
    hold on;
    plot(t, abs(e_zn), 'r-', 'LineWidth', 1.2, 'DisplayName', 'Ziegler-Nichols');
    plot(t, abs(e_man), 'b-', 'LineWidth', 1.2, 'DisplayName', 'Manual');
    plot(t, abs(e_opt), 'g-', 'LineWidth', 1.2, 'DisplayName', 'Optimized');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('$|e(t)|$', 'Interpreter', 'latex');
    title('Absolute Error', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    set(gca, 'YScale', 'log');
    xlim([0 T_sim]);
    
    % Subplot 4: Component analysis (P, PI, PD, PID)
    subplot(3, 3, 4);
    hold on;
    plot(t, r, 'k-', 'LineWidth', 1.5, 'DisplayName', 'Setpoint');
    plot(t, y_p, 'c-', 'LineWidth', 1.2, 'DisplayName', 'P');
    plot(t, y_pi, 'm-', 'LineWidth', 1.2, 'DisplayName', 'PI');
    plot(t, y_pd, 'y-', 'LineWidth', 1.2, 'DisplayName', 'PD');
    plot(t, y_man, 'b-', 'LineWidth', 1.5, 'DisplayName', 'PID');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Output $y(t)$', 'Interpreter', 'latex');
    title('Controller Component Analysis', 'Interpreter', 'latex');
    legend('Location', 'southeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 T_sim]);
    
    % Subplot 5: Performance metrics bar chart
    subplot(3, 3, 5);
    metrics = [perf_zn.ITAE; perf_man.ITAE; perf_opt.ITAE];
    bar(metrics, 'FaceColor', [0.3 0.6 0.9]);
    set(gca, 'XTickLabel', {'ZN', 'Manual', 'Optimized'});
    ylabel('ITAE', 'Interpreter', 'latex');
    title('Performance Index Comparison', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 6: Overshoot comparison
    subplot(3, 3, 6);
    overshoots = [perf_p.overshoot; perf_pi.overshoot; perf_pd.overshoot; perf_man.overshoot];
    bar(overshoots, 'FaceColor', [0.9 0.5 0.3]);
    set(gca, 'XTickLabel', {'P', 'PI', 'PD', 'PID'});
    ylabel('Overshoot [\%]', 'Interpreter', 'latex');
    title('Overshoot Analysis', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 7: Settling time comparison
    subplot(3, 3, 7);
    settlingTimes = [perf_p.settlingTime; perf_pi.settlingTime; ...
                     perf_pd.settlingTime; perf_man.settlingTime];
    bar(settlingTimes, 'FaceColor', [0.5 0.8 0.5]);
    set(gca, 'XTickLabel', {'P', 'PI', 'PD', 'PID'});
    ylabel('Settling Time [s]', 'Interpreter', 'latex');
    title('Settling Time Analysis', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 8: Disturbance response (zoomed)
    subplot(3, 3, 8);
    idx_zoom = (t >= 6.5 & t <= 9);
    hold on;
    plot(t(idx_zoom), r(idx_zoom), 'k-', 'LineWidth', 1.5);
    plot(t(idx_zoom), y_man(idx_zoom), 'b-', 'LineWidth', 1.5);
    xline(7, 'r-', 'LineWidth', 1, 'DisplayName', 'Disturbance');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Output $y(t)$', 'Interpreter', 'latex');
    title('Disturbance Rejection (Zoomed)', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 9: Phase plane (error vs derivative)
    subplot(3, 3, 9);
    de_man = [0, diff(e_man)] / Ts;  % Numerical derivative
    plot(e_man, de_man, 'b.', 'MarkerSize', 2);
    xlabel('Error $e(t)$', 'Interpreter', 'latex');
    ylabel('$de/dt$', 'Interpreter', 'latex');
    title('Phase Plane Portrait', 'Interpreter', 'latex');
    grid on;
    
    sgtitle('PID Controller Performance Analysis', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Figures generated.\n\n');
end

%% Helper Functions

function [y, u, e, perf] = simulatePID(G_d, r, d, noise, Ts, Kp, Ki, Kd)
    % Simulate closed-loop PID control with discrete plant
    
    [num, den] = tfdata(G_d, 'v');
    N = length(r);
    
    % Initialize signals
    y = zeros(1, N);
    u = zeros(1, N);
    e = zeros(1, N);
    
    % State variables for discrete plant (direct form II)
    x_plant = zeros(length(den)-1, 1);
    
    % PID state variables
    integral = 0;
    e_prev = 0;
    
    % Anti-windup limits
    u_max = 10;
    u_min = -10;
    
    % Derivative filter coefficient (low-pass filter)
    N_filter = 10;
    derivative = 0;
    
    for k = 1:N
        % Measurement (with noise)
        y_meas = y(k) + noise(k);
        
        % Error calculation
        e(k) = r(k) - y_meas;
        
        % PID components
        P_term = Kp * e(k);
        integral = integral + e(k) * Ts;
        I_term = Ki * integral;
        
        % Filtered derivative
        derivative = (N_filter * derivative + Kd * (e(k) - e_prev)) / (N_filter + 1);
        D_term = derivative / Ts;
        
        % Control signal
        u_unsat = P_term + I_term + D_term;
        
        % Saturation and anti-windup
        if u_unsat > u_max
            u(k) = u_max;
            integral = integral - e(k) * Ts;  % Back-calculation anti-windup
        elseif u_unsat < u_min
            u(k) = u_min;
            integral = integral - e(k) * Ts;
        else
            u(k) = u_unsat;
        end
        
        % Add disturbance to control signal
        u_total = u(k) + d(k);
        
        % Plant update (discrete-time state-space simulation)
        if k < N
            % Compute output
            y_temp = num(1) * u_total;
            for j = 2:length(num)
                if length(x_plant) >= j-1
                    y_temp = y_temp + num(j) * x_plant(j-1);
                end
            end
            
            % Update states
            x_new = [u_total; x_plant(1:end-1)];
            for j = 2:length(den)
                if length(x_plant) >= j-1
                    x_new(j-1) = x_new(j-1) - den(j) * y(k);
                end
            end
            x_plant = x_new;
            y(k+1) = y_temp;
        end
        
        e_prev = e(k);
    end
    
    % Compute performance metrics
    perf = computePerformance(r, y, e, Ts);
end

function perf = computePerformance(r, y, e, Ts)
    % Compute controller performance metrics
    
    N = length(y);
    t = (0:N-1) * Ts;
    
    % Steady-state value (average of last 10% of response)
    y_ss = mean(y(round(0.9*N):end));
    r_final = r(end);
    
    % Steady-state error
    perf.steadyStateError = abs(r_final - y_ss);
    
    % Rise time (10% to 90% of final value)
    idx_10 = find(y >= 0.1 * r_final, 1, 'first');
    idx_90 = find(y >= 0.9 * r_final, 1, 'first');
    
    if ~isempty(idx_10) && ~isempty(idx_90)
        perf.riseTime = t(idx_90) - t(idx_10);
    else
        perf.riseTime = NaN;
    end
    
    % Overshoot
    y_max = max(y);
    if y_ss > 0
        perf.overshoot = ((y_max - y_ss) / y_ss) * 100;
    else
        perf.overshoot = 0;
    end
    perf.overshoot = max(0, perf.overshoot);  % No negative overshoot
    
    % Settling time (2% criterion)
    tol = 0.02 * abs(r_final);
    settled = abs(y - r_final) <= tol;
    
    % Find last time before permanent settling
    idx_settle = find(~settled, 1, 'last');
    if ~isempty(idx_settle) && idx_settle < N
        perf.settlingTime = t(idx_settle + 1);
    else
        perf.settlingTime = t(end);
    end
    
    % Integral performance indices
    perf.ISE = sum(e.^2) * Ts;
    perf.IAE = sum(abs(e)) * Ts;
    perf.ITAE = sum(t .* abs(e)) * Ts;
end

function displayPerformance(name, perf)
    % Display performance metrics in formatted output
    
    fprintf('%s:\n', name);
    fprintf('  Rise time:      %.3f s\n', perf.riseTime);
    fprintf('  Settling time:  %.3f s\n', perf.settlingTime);
    fprintf('  Overshoot:      %.2f %%\n', perf.overshoot);
    fprintf('  Steady-state error: %.4f\n', perf.steadyStateError);
    fprintf('  ISE:  %.3f\n', perf.ISE);
    fprintf('  IAE:  %.3f\n', perf.IAE);
    fprintf('  ITAE: %.3f\n\n', perf.ITAE);
end

function ITAE = simulateAndComputeITAE(G_d, r, d, noise, Ts, Kp, Ki, Kd)
    % Objective function for optimization (minimize ITAE)
    
    [~, ~, e, perf] = simulatePID(G_d, r, d, noise, Ts, Kp, Ki, Kd);
    ITAE = perf.ITAE;
    
    % Penalty for excessive overshoot or instability
    if perf.overshoot > 50 || max(abs(e)) > 10
        ITAE = ITAE * 10;  % Heavy penalty
    end
end
