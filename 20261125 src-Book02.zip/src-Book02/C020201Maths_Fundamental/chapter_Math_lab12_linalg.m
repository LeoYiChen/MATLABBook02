%% chapter_Math_lab12_linalg.m
% Advanced Numerical Linear Algebra Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab12_linalg
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory
Lab12_AdvancedNumericalLinearAlgebra();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab12_AdvancedNumericalLinearAlgebra()
    % LAB12_ADVANCEDNUMERICALLINEARALGEBRA Sparse matrices and iterative solvers
    %   Implements CG, GMRES, and preconditioned methods
    
    fprintf('\\textbf{Laboratory 12: Advanced Numerical Linear Algebra}\n');
    fprintf('==========================================================\n\n');
    
    % Task 1: Sparse matrix operations and storage formats
    exploreSparseMatrices();
    
    % Task 2: Conjugate Gradient method
    implementConjugateGradient();
    
    % Task 3: GMRES for non-symmetric systems
    implementGMRES();
    
    % Task 4: Preconditioning techniques
    demonstratePreconditioning();
    
    % Task 5: Performance comparison on large-scale problems
    compareLargeScaleSolvers();
end

function exploreSparseMatrices()
    % EXPLORESPARSEMATRICES Understand sparse matrix storage and operations
    
    fprintf('\\textbf{Task 1: Sparse Matrix Operations}\n');
    fprintf('-------\n');
    
    % Create a sparse matrix from 2*D Laplacian (5-point stencil)
    n = 100;  % Grid size
    fprintf('Creating %dx%d 2*D Laplacian matrix...\n', n, n);
    
    % Build using sparse function
    N = n * n;
    
    % Main diagonal
    i_main = 1:N;
    j_main = 1:N;
    v_main = 4 * ones(N, 1);
    
    % Upper/lower diagonals (within row)
    i_off1 = 1:N-1;
    j_off1 = 2:N;
    v_off1 = -ones(N-1, 1);
    
    % Eliminate wrap-around connections
    for k = n:n:N-1
        v_off1(k) = 0;
    end
    
    % Upper/lower diagonals (between rows)
    i_off2 = 1:N-n;
    j_off2 = (n+1):N;
    v_off2 = -ones(N-n, 1);
    
    % Combine all entries
    i_all = [i_main, j_main, i_off1, j_off1, i_off2, j_off2];
    j_all = [j_main, i_main, j_off1, i_off1, j_off2, i_off2];
    v_all = [v_main', v_main', v_off1', v_off1', v_off2', v_off2'];
    
    tic;
    A_sparse = sparse(i_all, j_all, v_all, N, N);
    time_construct = toc;
    
    fprintf('  Matrix size: %d x %d\n', N, N);
    fprintf('  Non-zero elements: %d\n', nnz(A_sparse));
    fprintf('  Density: %.6f%%\n', 100 * nnz(A_sparse) / N^2);
    fprintf('  Construction time: %.6f seconds\n\n', time_construct);
    
    % Compare memory usage
    fprintf('Memory Comparison:\n');
    
    % Sparse storage
    sparse_info = whos('A_sparse');
    sparse_memory = sparse_info.bytes;
    fprintf('  Sparse storage: %.2f KB\n', sparse_memory / 1024);
    
    % Full storage (hypothetical)
    full_memory = N * N * 8;  % 8 bytes per double
    fprintf('  Full storage (hypothetical): %.2f KB\n', full_memory / 1024);
    fprintf('  Memory savings: %.2fx\n\n', full_memory / sparse_memory);
    
    % Sparsity pattern visualisation
    fprintf('Visualizing sparsity pattern...\n\n');
    
    figure('Position', [100, 100, 1200, 500], 'Name', 'Sparse Matrix Analysis');
    
    % Subplot 1: Sparsity pattern
    subplot(1, 3, 1);
    spy(A_sparse);
    title('Sparsity Pattern: 2*D Laplacian', 'Interpreter', 'latex', 'FontSize', 13);
    xlabel('Column', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Row', 'Interpreter', 'latex', 'FontSize', 12);
    
    % Subplot 2: Bandwidth visualisation
    subplot(1, 3, 2);
    [i, j, ~] = find(A_sparse);
    bandwidth = max(abs(i - j));
    histogram(abs(i - j), 'BinWidth', 1);
    xlabel('Distance from Diagonal', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Count', 'Interpreter', 'latex', 'FontSize', 12);
    title(sprintf('Bandwidth = %d', bandwidth), 'Interpreter', 'latex', 'FontSize', 13);
    
    % Subplot 3: Eigenvalue distribution (sample)
    subplot(1, 3, 3);
    fprintf('Computing sample eigenvalues...\n');
    k = min(50, N-2);
    eigs_sample = eigs(A_sparse, k, 'smallestabs');
    plot(real(eigs_sample), imag(eigs_sample), 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b');
    xlabel('Real', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Imaginary', 'Interpreter', 'latex', 'FontSize', 12);
    title('Eigenvalue Distribution (Sample)', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Analyze condition number
    fprintf('  Smallest eigenvalue (magnitude): %.6f\n', min(abs(eigs_sample)));
    fprintf('  Largest eigenvalue (magnitude): %.6f\n', max(abs(eigs_sample)));
    condition_est = max(abs(eigs_sample)) / min(abs(eigs_sample));
    fprintf('  Estimated condition number: %.2e\n\n', condition_est);
    
    % Test sparse matrix-vector multiplication
    fprintf('Performance Test: Matrix-Vector Multiplication\n');
    x = rand(N, 1);
    
    % Sparse multiplication
    tic;
    for trial = 1:100
        y_sparse = A_sparse * x;
    end
    time_sparse = toc / 100;
    
    % Full multiplication (for small subset)
    if N <= 1000
        A_full = full(A_sparse);
        tic;
        for trial = 1:100
            y_full = A_full * x;
        end
        time_full = toc / 100;
        
        fprintf('  Sparse: %.6f seconds\n', time_sparse);
        fprintf('  Full:   %.6f seconds\n', time_full);
        fprintf('  Speedup: %.2fx\n\n', time_full / time_sparse);
    else
        fprintf('  Sparse: %.6f seconds\n', time_sparse);
        fprintf('  (Full not tested due to size)\n\n');
    end
end

function implementConjugateGradient()
    % IMPLEMENTCONJUGATEGRADIENT Implement CG from scratch
    
    fprintf('\\textbf{Task 2: Conjugate Gradient Method}\n');
    fprintf('--------\n');
    
    % Create test problem: 1*D Poisson equation
    n = 500;
    fprintf('Test Problem: 1*D Poisson Equation\n');
    fprintf('  Problem size: n = %d\n', n);
    
    % Build tridiagonal matrix
    e = ones(n, 1);
    A = spdiags([−e, 2*e, -e], -1:1, n, n);
    
    % Right-hand side (random)
    b = rand(n, 1);
    
    % True solution (using direct solver)
    fprintf('  Computing true solution (direct)...\n');
    tic;
    x_true = A \ b;
    time_direct = toc;
    fprintf('    Time: %.6f seconds\n\n', time_direct);
    
    % Implement Conjugate Gradient
    fprintf('Implementing Conjugate Gradient:\n');
    
    max_iter = n;
    tol = 1e-10;
    
    % Initialize
    x = zeros(n, 1);
    r = b - A * x;
    p = r;
    rsold = r' * r;
    
    residual_history = zeros(max_iter, 1);
    error_history = zeros(max_iter, 1);
    
    fprintf('  Tolerance: %.2e\n', tol);
    fprintf('  Max iterations: %d\n\n', max_iter);
    
    tic;
    for iter = 1:max_iter
        Ap = A * p;
        alpha = rsold / (p' * Ap);
        x = x + alpha * p;
        r = r - alpha * Ap;
        rsnew = r' * r;
        
        % Record convergence metrics
        residual_history(iter) = sqrt(rsnew);
        error_history(iter) = norm(x - x_true);
        
        % Check convergence
        if sqrt(rsnew) < tol
            fprintf('  Converged at iteration %d\n', iter);
            residual_history = residual_history(1:iter);
            error_history = error_history(1:iter);
            break;
        end
        
        % Compute next search direction
        beta = rsnew / rsold;
        p = r + beta * p;
        rsold = rsnew;
        
        % Print progress
        if mod(iter, 50) == 0
            fprintf('  Iteration %d: Residual = %.6e, Error = %.6e\n', ...
                iter, sqrt(rsnew), norm(x - x_true));
        end
    end
    time_cg = toc;
    
    fprintf('  Total time: %.6f seconds\n', time_cg);
    fprintf('  Final residual: %.6e\n', residual_history(end));
    fprintf('  Final error: %.6e\n\n', error_history(end));
    
    % Compare with MATLAB's pcg
    fprintf('Comparison with MATLAB pcg:\n');
    tic;
    [x_pcg, flag, relres, iter_pcg, resvec] = pcg(A, b, tol, max_iter);
    time_pcg = toc;
    
    fprintf('  Iterations: %d\n', iter_pcg);
    fprintf('  Time: %.6f seconds\n', time_pcg);
    fprintf('  Final residual: %.6e\n\n', relres * norm(b));
    
    % Visualize convergence
    visualizeCGConvergence(residual_history, error_history, resvec);
end

function visualizeCGConvergence(residual_history, error_history, matlab_resvec)
    % VISUALIZECGCONVERGENCE Plot CG convergence behavior
    
    figure('Position', [150, 150, 1400, 500], 'Name', 'Conjugate Gradient Convergence');
    
    % Subplot 1: Residual convergence
    subplot(1, 3, 1);
    semilogy(1:length(residual_history), residual_history, 'b-', 'LineWidth', 2, ...
        'DisplayName', 'Custom CG');
    hold on;
    semilogy(0:length(matlab_resvec)-1, matlab_resvec, 'r-', 'LineWidth', 2, ...
        'DisplayName', 'MATLAB pcg');
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Residual Norm', 'Interpreter', 'latex', 'FontSize', 12);
    title('Residual Convergence', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Subplot 2: Error convergence
    subplot(1, 3, 2);
    semilogy(1:length(error_history), error_history, 'b-', 'LineWidth', 2);
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Error Norm', 'Interpreter', 'latex', 'FontSize', 12);
    title('Error Convergence', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 3: Convergence rate
    subplot(1, 3, 3);
    if length(residual_history) > 1
        convergence_rate = residual_history(2:end) ./ residual_history(1:end-1);
        plot(2:length(residual_history), convergence_rate, 'b-', 'LineWidth', 2);
        xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('$\|r_{k+1}\| / \|r_k\|$', 'Interpreter', 'latex', 'FontSize', 12);
        title('Convergence Rate', 'Interpreter', 'latex', 'FontSize', 13);
        grid on;
        ylim([0, 1]);
    end
end

function implementGMRES()
    % IMPLEMENTGMRES Generalized Minimal Residual method
    
    fprintf('\\textbf{Task 3: GMRES for Non-Symmetric Systems}\n');
    fprintf('---------\n');
    
    % Create non-symmetric test problem
    n = 300;
    fprintf('Test Problem: Non-Symmetric Matrix\n');
    fprintf('  Problem size: n = %d\n', n);
    
    % Create convection-diffusion matrix
    h = 1 / (n + 1);
    e = ones(n, 1);
    
    % Diffusion part (symmetric)
    A_diff = spdiags([-e, 2*e, -e], -1:1, n, n) / h^2;
    
    % Convection part (non-symmetric)
    A_conv = spdiags([-e, e], [-1, 1], n, n) / (2*h);
    
    % Combined system (convection-diffusion)
    peclet = 10;  % Péclet number
    A = A_diff + peclet * A_conv;
    
    fprintf('  Péclet number: %d (higher = more convective)\n', peclet);
    fprintf('  Matrix is non-symmetric\n\n');
    
    % Right-hand side
    b = rand(n, 1);
    
    % True solution
    fprintf('  Computing true solution (direct)...\n');
    tic;
    x_true = A \ b;
    time_direct = toc;
    fprintf('    Time: %.6f seconds\n\n', time_direct);
    
    % Apply MATLAB's GMRES
    fprintf('Applying MATLAB GMRES:\n');
    restart = 20;
    tol = 1e-10;
    max_iter = 100;
    
    fprintf('  Restart parameter: %d\n', restart);
    fprintf('  Tolerance: %.2e\n', tol);
    fprintf('  Max iterations: %d\n\n', max_iter);
    
    tic;
    [x_gmres, flag, relres, iter, resvec] = gmres(A, b, restart, tol, max_iter);
    time_gmres = toc;
    
    fprintf('  Converged: %s\n', char(flag==0)*'Yes' + char(flag~=0)*'No');
    fprintf('  Outer iterations: %d\n', iter(1));
    fprintf('  Inner iterations (last): %d\n', iter(2));
    fprintf('  Time: %.6f seconds\n', time_gmres);
    fprintf('  Final relative residual: %.6e\n', relres);
    fprintf('  Solution error: %.6e\n\n', norm(x_gmres - x_true));
    
    % Visualize results
    visualizeGMRESResults(A, resvec, x_gmres, x_true);
end

function visualizeGMRESResults(A, resvec, x_gmres, x_true)
    % VISUALIZEGMRESRESULTS Plot GMRES convergence and solution
    
    figure('Position', [200, 200, 1400, 500], 'Name', 'GMRES Analysis');
    
    % Subplot 1: Residual history
    subplot(1, 3, 1);
    semilogy(0:length(resvec)-1, resvec, 'b-', 'LineWidth', 2);
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Relative Residual', 'Interpreter', 'latex', 'FontSize', 12);
    title('GMRES Convergence', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 2: Solution comparison
    subplot(1, 3, 2);
    plot(x_true, 'b-', 'LineWidth', 2, 'DisplayName', 'True Solution');
    hold on;
    plot(x_gmres, 'r-', 'LineWidth', 2, 'DisplayName', 'GMRES Solution');
    xlabel('Index', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Value', 'Interpreter', 'latex', 'FontSize', 12);
    title('Solution Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Subplot 3: Matrix structure
    subplot(1, 3, 3);
    spy(A);
    title('Matrix Sparsity Pattern', 'Interpreter', 'latex', 'FontSize', 13);
end

function demonstratePreconditioning()
    % DEMONSTRATEPRECONDITIONING Compare preconditioned vs unpreconditioned
    
    fprintf('\\textbf{Task 4: Preconditioning Techniques}\n');
    fprintf('--------\n');
    
    % Create ill-conditioned test problem
    n = 400;
    fprintf('Test Problem: Ill-Conditioned 2*D Laplacian\n');
    fprintf('  Problem size: n = %d\n', n);
    
    % 2*D Laplacian (as before)
    nx = floor(sqrt(n));
    ny = nx;
    N = nx * ny;
    
    % Build Laplacian
    e = ones(N, 1);
    A = spdiags([e, e, -4*e, e, e], [-ny, -1, 0, 1, ny], N, N);
    
    % Remove boundary wrap-around
    for k = ny:ny:N-1
        A(k, k+1) = 0;
        A(k+1, k) = 0;
    end
    
    fprintf('  Actual problem size: %d x %d\n', N, N);
    fprintf('  Non-zeros: %d\n\n', nnz(A));
    
    % Right-hand side
    b = rand(N, 1);
    
    % Solver parameters
    tol = 1e-8;
    max_iter = 500;
    
    % Method 1: Unpreconditioned CG
    fprintf('Method 1: Unpreconditioned PCG\n');
    tic;
    [x1, flag1, relres1, iter1, resvec1] = pcg(A, b, tol, max_iter);
    time1 = toc;
    fprintf('  Iterations: %d\n', iter1);
    fprintf('  Time: %.6f seconds\n', time1);
    fprintf('  Final residual: %.6e\n\n', relres1);
    
    % Method 2: Jacobi (diagonal) preconditioning
    fprintf('Method 2: Jacobi Preconditioned PCG\n');
    M_jacobi = spdiags(diag(A), 0, N, N);
    
    tic;
    [x2, flag2, relres2, iter2, resvec2] = pcg(A, b, tol, max_iter, M_jacobi);
    time2 = toc;
    fprintf('  Iterations: %d\n', iter2);
    fprintf('  Time: %.6f seconds\n', time2);
    fprintf('  Speedup: %.2fx\n', time1/time2);
    fprintf('  Final residual: %.6e\n\n', relres2);
    
    % Method 3: Incomplete Cholesky preconditioning
    fprintf('Method 3: Incomplete Cholesky Preconditioned PCG\n');
    try
        L_ichol = ichol(A);
        
        tic;
        [x3, flag3, relres3, iter3, resvec3] = pcg(A, b, tol, max_iter, L_ichol, L_ichol');
        time3 = toc;
        fprintf('  Iterations: %d\n', iter3);
        fprintf('  Time: %.6f seconds\n', time3);
        fprintf('  Speedup: %.2fx\n', time1/time3);
        fprintf('  Final residual: %.6e\n\n', relres3);
    catch
        fprintf('  Incomplete Cholesky failed (matrix not suitable)\n\n');
        x3 = x1;
        resvec3 = resvec1;
        iter3 = iter1;
    end
    
    % Visualize comparison
    visualizePreconditioningComparison(resvec1, resvec2, resvec3, ...
        iter1, iter2, iter3);
end

function visualizePreconditioningComparison(resvec1, resvec2, resvec3, ...
    iter1, iter2, iter3)
    % VISUALIZEPRECONDITIONINGCOMPARISON Plot preconditioning effects
    
    figure('Position', [250, 250, 1200, 500], 'Name', 'Preconditioning Comparison');
    
    % Convergence comparison
    subplot(1, 2, 1);
    semilogy(0:length(resvec1)-1, resvec1, 'b-', 'LineWidth', 2, ...
        'DisplayName', 'Unpreconditioned');
    hold on;
    semilogy(0:length(resvec2)-1, resvec2, 'r-', 'LineWidth', 2, ...
        'DisplayName', 'Jacobi');
    if length(resvec3) > 1
        semilogy(0:length(resvec3)-1, resvec3, 'g-', 'LineWidth', 2, ...
            'DisplayName', 'Incomplete Cholesky');
    end
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Relative Residual', 'Interpreter', 'latex', 'FontSize', 12);
    title('Convergence Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Iteration count comparison
    subplot(1, 2, 2);
    methods = {'Unprecond.', 'Jacobi', 'Inc. Cholesky'};
    iters = [iter1, iter2, iter3];
    bar(iters);
    set(gca, 'XTickLabel', methods);
    ylabel('Iterations to Convergence', 'Interpreter', 'latex', 'FontSize', 12);
    title('Iteration Count Comparison', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
end

function compareLargeScaleSolvers()
    % COMPARELARGESCALESOLVERS Performance on realistic large systems
    
    fprintf('\\textbf{Task 5: Large-Scale Solver Comparison}\n');
    fprintf('--------\n');
    
    % Create large 3*D Laplacian
    n = 30;  % Grid points per dimension
    N = n^3;
    
    fprintf('Test Problem: 3*D Laplacian\n');
    fprintf('  Grid: %d x %d x %d\n', n, n, n);
    fprintf('  Total unknowns: %d\n', N);
    
    % Build 3*D Laplacian using Kronecker products
    fprintf('  Building matrix...\n');
    e = ones(n, 1);
    T = spdiags([e, -2*e, e], -1:1, n, n);
    I = speye(n);
    
    % A = I ⊗ I ⊗ T + I ⊗ T ⊗ I + T ⊗ I ⊗ I
    tic;
    A = kron(kron(I, I), T) + kron(kron(I, T), I) + kron(kron(T, I), I);
    time_build = toc;
    
    fprintf('    Construction time: %.6f seconds\n', time_build);
    fprintf('  Non-zeros: %d (%.6f%% density)\n', nnz(A), 100*nnz(A)/N^2);
    fprintf('  Memory: %.2f MB\n\n', whos('A').bytes / 1024^2);
    
    % Right-hand side
    b = rand(N, 1);
    
    % Solver parameters
    tol = 1e-6;
    max_iter = 200;
    
    results = struct();
    
    % Solver 1: PCG (unpreconditioned)
    fprintf('Solver 1: PCG (Unpreconditioned)\n');
    tic;
    [x1, flag1, relres1, iter1] = pcg(A, b, tol, max_iter);
    time1 = toc;
    results.pcg_unpre = struct('time', time1, 'iter', iter1, 'relres', relres1);
    fprintf('  Time: %.6f seconds\n', time1);
    fprintf('  Iterations: %d\n', iter1);
    fprintf('  Residual: %.6e\n\n', relres1);
    
    % Solver 2: PCG (Jacobi preconditioned)
    fprintf('Solver 2: PCG (Jacobi Preconditioned)\n');
    M = spdiags(diag(A), 0, N, N);
    tic;
    [x2, flag2, relres2, iter2] = pcg(A, b, tol, max_iter, M);
    time2 = toc;
    results.pcg_jacobi = struct('time', time2, 'iter', iter2, 'relres', relres2);
    fprintf('  Time: %.6f seconds\n', time2);
    fprintf('  Iterations: %d\n', iter2);
    fprintf('  Speedup: %.2fx\n', time1/time2);
    fprintf('  Residual: %.6e\n\n', relres2);
    
    % Solver 3: GMRES
    fprintf('Solver 3: GMRES(20)\n');
    restart = 20;
    tic;
    [x3, flag3, relres3, iter3] = gmres(A, b, restart, tol, max_iter/restart);
    time3 = toc;
    results.gmres = struct('time', time3, 'iter', iter3, 'relres', relres3);
    fprintf('  Time: %.6f seconds\n', time3);
    fprintf('  Outer iterations: %d\n', iter3(1));
    fprintf('  Residual: %.6e\n\n', relres3);
    
    % Solver 4: BiCGSTAB
    fprintf('Solver 4: BiCGSTAB\n');
    tic;
    [x4, flag4, relres4, iter4] = bicgstab(A, b, tol, max_iter);
    time4 = toc;
    results.bicgstab = struct('time', time4, 'iter', iter4, 'relres', relres4);
    fprintf('  Time: %.6f seconds\n', time4);
    fprintf('  Iterations: %d\n', iter4);
    fprintf('  Residual: %.6e\n\n', relres4);
    
    % Summary visualisation
    visualizeSolverComparison(results);
end

function visualizeSolverComparison(results)
    % VISUALIZESOLVERCOMPARISON Create comparison charts
    
    figure('Position', [300, 300, 1200, 500], 'Name', 'Solver Comparison');
    
    % Extract data
    solvers = fieldnames(results);
    n_solvers = length(solvers);
    
    times = zeros(n_solvers, 1);
    iters = zeros(n_solvers, 1);
    
    for i = 1:n_solvers
        times(i) = results.*(solvers{i}).time;
        iter_val = results.*(solvers{i}).iter;
        if length(iter_val) == 2
            iters(i) = iter_val(1);  % Outer iterations for GMRES
        else
            iters(i) = iter_val;
        end
    end
    
    solver_names = {'PCG', 'PCG-Jacobi', 'GMRES', 'BiCGSTAB'};
    
    % Subplot 1: Computation time
    subplot(1, 2, 1);
    bar(times);
    set(gca, 'XTickLabel', solver_names);
    ylabel('Time (seconds)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Solver Computation Time', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 2: Iterations
    subplot(1, 2, 2);
    bar(iters);
    set(gca, 'XTickLabel', solver_names);
    ylabel('Iterations', 'Interpreter', 'latex', 'FontSize', 12);
    title('Iterations to Convergence', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
end
