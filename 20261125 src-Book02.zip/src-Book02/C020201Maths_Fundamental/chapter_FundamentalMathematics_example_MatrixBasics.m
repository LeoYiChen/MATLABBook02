%% chapter_FundamentalMathematics_example_MatrixBasics.m
% Fundamental matrix operations in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_MatrixBasics
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Fundamental Matrix Operations in MATLAB
% Demonstrates basic linear algebra operations

% Create example matrices
matrixA = [1, 2, 3; 4, 5, 6; 7, 8, 9];
matrixB = [9, 8, 7; 6, 5, 4; 3, 2, 1];
vectorX = [1; 2; 3];

% Matrix addition and subtraction
matrixSum = matrixA + matrixB;
matrixDifference = matrixA - matrixB;

% Matrix multiplication (linear transformation)
matrixProduct = matrixA * matrixB;

% Element-wise operations (note the dot operator)
elementwiseProduct = matrixA .* matrixB;
elementwiseDivision = matrixA ./ matrixB;

% Matrix-vector multiplication
resultVector = matrixA * vectorX;

% Transpose operations
matrixATranspose = matrixA';  % Complex conjugate transpose
matrixARealTranspose = matrixA.';  % Real transpose

% Matrix powers
matrixSquared = matrixA^2;  % matrixA * matrixA
elementwiseSquared = matrixA.^2;  % Each element squared

% Display results
fprintf('Matrix A:\n');
disp(matrixA);
fprintf('Matrix B:\n');
disp(matrixB);
fprintf('Matrix A * B (matrix multiplication):\n');
disp(matrixProduct);
fprintf('Matrix A .* B (element-wise multiplication):\n');
disp(elementwiseProduct);
fprintf('Matrix A * vector x:\n');
disp(resultVector);
