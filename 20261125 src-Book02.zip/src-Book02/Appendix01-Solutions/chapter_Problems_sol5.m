%% chapter_Problems_sol5.m
% Reproducible research framework
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Problems_sol5
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Reproducible Research Framework in MATLAB
% This script demonstrates best practices for ensuring reproducibility in
% scientific computing with MATLAB. It includes environment recording,
% fixed random seeds, documented data generation, structured analysis,
% comprehensive result saving, and self-documentation.

%% 1. Environment Setup and Documentation
% Record start time for benchmarking
start_time = tic;

% Create a results directory with timestamp
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
results_dir = ['results_', timestamp];
if ~exist(results_dir, 'dir')
mkdir(results_dir);
end

% Set fixed random seed for reproducibility
rng_seed = 42;
rng(rng_seed, 'twister');
fprintf('Random number generator initialised with seed %d\n', rng_seed);

% Record MATLAB version and environment information
environment = struct();
environment.matlab_version = version;
environment.computer = computer;
environment.date_time = datetime('now');
environment.user = getenv('USERNAME');
environment.rng_seed = rng_seed;
environment.rng_type = 'twister';

% Record installed toolboxes
v = ver;
environment.toolboxes = {v.Name};

% Display environment information
fprintf('MATLAB Version: %s\n', environment.matlab_version);
fprintf('Computer: %s\n', environment.computer);
fprintf('Date and Time: %s\n', char(environment.date_time));
fprintf('User: %s\n', environment.user);

fprintf('Installed Toolboxes:\n');
for i = 1:length(environment.toolboxes)
fprintf(' %s\n', environment.toolboxes{i});
end

% Save environment information
save(fullfile(results_dir, 'environment.mat'), 'environment');

% Create a configuration structure for experiment parameters
config = struct();
config.n_samples = 500; % Number of data points
config.n_features = 5; % Number of features
config.noise_level = 0.3; % Noise level for data generation
config.train_ratio = 0.7; % Training data ratio
config.k_folds = 5; % Number of cross-validation folds
config.model_type = 'linear'; % Model type (can be 'linear', 'tree', 'svm')

% Save configuration
save(fullfile(results_dir, 'config.mat'), 'config');

%% 2. Data Generation with Documentation
fprintf('\nGenerating synthetic dataset with %d samples and %d features\n', ...
config.n_samples, config.n_features);

% Create a function for data generation
% This ensures the data generation process is clearly documented and reusable
data = generate_synthetic_data(config.n_samples, config.n_features, ...
config.noise_level, rng_seed);

% Display basic statistics of the generated data
fprintf('Data generation complete. Basic statistics:\n');
fprintf(' Features shape: %d x %d\n', size(data.X, 1), size(data.X, 2));
fprintf(' Target shape: %d x %d\n', size(data.y, 1), size(data.y, 2));
fprintf(' Feature means: ');
fprintf('%.4f ', mean(data.X));
fprintf('\n');
fprintf(' Feature standard deviations: ');
fprintf('%.4f ', std(data.X));
fprintf('\n');
fprintf(' Target mean: %.4f\n', mean(data.y));
fprintf(' Target standard deviation: %.4f\n', std(data.y));

% Save raw data
save(fullfile(results_dir, 'raw_data.mat'), 'data');
writetable(array2table([data.X, data.y], 'VariableNames', ...
[arrayfun(@(i) sprintf('X%d', i), 1:config.n_features, 'UniformOutput', false), {'y'}]), ...
fullfile(results_dir, 'raw_data.csv'));

%% 3. Data Preprocessing
fprintf('\nPreprocessing data...\n');

% Split data into training and testing sets
cv = cvpartition(config.n_samples, 'HoldOut', 1-config.train_ratio);
train_idx = cv.training;
test_idx = cv.test;

X_train = data.X(train_idx, :);
y_train = data.y(train_idx);
X_test = data.X(test_idx, :);
y_test = data.y(test_idx);

fprintf('Data split into %d training and %d testing samples\n', ...
sum(train_idx), sum(test_idx));

% Standardize features
[X_train_scaled, mu, sigma] = standardize_features(X_train);
X_test_scaled = (X_test - mu) ./ sigma;

% Save preprocessing information
preprocessing = struct();
preprocessing.train_idx = train_idx;
preprocessing.test_idx = test_idx;
preprocessing.feature_means = mu;
preprocessing.feature_stds = sigma;
save(fullfile(results_dir, 'preprocessing.mat'), 'preprocessing');

% Save preprocessed data
preprocessed_data = struct();
preprocessed_data.X_train = X_train;
preprocessed_data.X_train_scaled = X_train_scaled;
preprocessed_data.y_train = y_train;
preprocessed_data.X_test = X_test;
preprocessed_data.X_test_scaled = X_test_scaled;
preprocessed_data.y_test = y_test;
save(fullfile(results_dir, 'preprocessed_data.mat'), 'preprocessed_data');

%% 4. Model Training and Evaluation
fprintf('\nTraining and evaluating models...\n');

% Initialize k-fold cross-validation
cv_folds = cvpartition(length(y_train), 'KFold', config.k_folds);

% Initialize structures to store results
cv_results = struct();
cv_results.mse = zeros(config.k_folds, 1);
cv_results.r2 = zeros(config.k_folds, 1);

% Perform cross-validation
for fold = 1:config.k_folds
fprintf('Cross-validation fold %d/%d\n', fold, config.k_folds);

% Get training and validation indices for this fold
fold_train_idx = cv_folds.training(fold);
fold_val_idx = cv_folds.test(fold);

% Extract training and validation data for this fold
X_fold_train = X_train_scaled(fold_train_idx, :);
y_fold_train = y_train(fold_train_idx);
X_fold_val = X_train_scaled(fold_val_idx, :);
y_fold_val = y_train(fold_val_idx);

% Train model based on config.model_type
model = train_model(X_fold_train, y_fold_train, config.model_type);

% Make predictions on validation set
y_fold_pred = predict_model(model, X_fold_val, config.model_type);

% Evaluate model performance
cv_results.mse(fold) = mean((y_fold_val - y_fold_pred).^2);
cv_results.r2(fold) = 1 - sum((y_fold_val - y_fold_pred).^2) / sum((y_fold_val - mean(y_fold_val)).^2);

% Store the model for this fold
cv_results.models{fold} = model;

end

% Calculate and display cross-validation performance
fprintf('Cross-validation results:\n');
fprintf(' Mean MSE: %.4f ( %.4f)\n', mean(cv_results.mse), std(cv_results.mse));
fprintf(' Mean R: %.4f ( %.4f)\n', mean(cv_results.r2), std(cv_results.r2));

% Train final model on all training data
final_model = train_model(X_train_scaled, y_train, config.model_type);

% Make predictions on test set
y_pred = predict_model(final_model, X_test_scaled, config.model_type);

% Evaluate final model performance
test_mse = mean((y_test - y_pred).^2);
test_r2 = 1 - sum((y_test - y_pred).^2) / sum((y_test - mean(y_test)).^2);

fprintf('Test set performance:\n');
fprintf(' MSE: %.4f\n', test_mse);
fprintf(' R: %.4f\n', test_r2);

% Save cross-validation and final model results
cv_results.mean_mse = mean(cv_results.mse);
cv_results.std_mse = std(cv_results.mse);
cv_results.mean_r2 = mean(cv_results.r2);
cv_results.std_r2 = std(cv_results.r2);
save(fullfile(results_dir, 'cv_results.mat'), 'cv_results');

final_results = struct();
final_results.model = final_model;
final_results.model_type = config.model_type;
final_results.test_mse = test_mse;
final_results.test_r2 = test_r2;
final_results.y_test = y_test;
final_results.y_pred = y_pred;
save(fullfile(results_dir, 'final_results.mat'), 'final_results');

% Save predictions for further analysis
predictions_table = table(y_test, y_pred, 'VariableNames', {'y_test', 'y_pred'});
writetable(predictions_table, fullfile(results_dir, 'predictions.csv'));

%% 5. Results Visualization
fprintf('\nGenerating visualizations...\n');

% Create a figure for cross-validation results
figure('Position', [100, 100, 800, 400]);
subplot(1, 2, 1);
boxplot(cv_results.mse);
title('Cross-validation MSE');
ylabel('Mean Squared Error');
grid on;

subplot(1, 2, 2);
boxplot(cv_results.r2);
title('Cross-validation R');
ylabel('RScore');
grid on;

% Save the figure
saveas(gcf, fullfile(results_dir, 'cv_results.png'));
saveas(gcf, fullfile(results_dir, 'cv_results.fig'));

% Create a figure for test set predictions
figure('Position', [100, 100, 800, 400]);
subplot(1, 2, 1);
scatter(y_test, y_pred, 25, 'b', 'filled');
hold on;
plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], 'r-', 'LineWidth', 2);
title('Actual vs Predicted Values');
xlabel('Actual Values');
ylabel('Predicted Values');
grid on;

subplot(1, 2, 2);
residuals = y_test - y_pred;
histogram(residuals, 20);
title('Prediction Residuals');
xlabel('Residual Value');
ylabel('Frequency');
grid on;

% Save the figure
saveas(gcf, fullfile(results_dir, 'test_predictions.png'));
saveas(gcf, fullfile(results_dir, 'test_predictions.fig'));

% Create a comprehensive summary figure
figure('Position', [100, 100, 1000, 800]);

% Data distribution
subplot(2, 3, 1);
histogram(data.y, 20, 'FaceColor', [0.3, 0.6, 0.3], 'FaceAlpha', 0.7);
title('Target Variable Distribution');
xlabel('Value');
ylabel('Frequency');
grid on;

% Feature correlation heatmap
subplot(2, 3, 2);
feature_corr = corr(data.X);
heatmap(1:config.n_features, 1:config.n_features, feature_corr, ...
'ColorbarVisible', 'on', 'XLabel', 'Feature Index', 'YLabel', 'Feature Index');
title('Feature Correlations');

% Feature-target correlations
subplot(2, 3, 3);
feature_target_corr = zeros(config.n_features, 1);
for i = 1:config.n_features
feature_target_corr(i) = corr(data.X(:,i), data.y);
end
bar(feature_target_corr);
title('Feature-Target Correlations');
xlabel('Feature Index');
ylabel('Correlation with Target');
grid on;

% Cross-validation performance
subplot(2, 3, 4);
bar([cv_results.mean_mse, test_mse]);
title('Model MSE Performance');
xticklabels({'Cross-validation', 'Test Set'});
ylabel('Mean Squared Error');
grid on;
hold on;
errorbar([1], cv_results.mean_mse, cv_results.std_mse, 'k', 'LineStyle', 'none', 'LineWidth', 1.5);

% Rperformance
subplot(2, 3, 5);
bar([cv_results.mean_r2, test_r2]);
title('Model RPerformance');
xticklabels({'Cross-validation', 'Test Set'});
ylabel('RScore');
grid on;
hold on;
errorbar([1], cv_results.mean_r2, cv_results.std_r2, 'k', 'LineStyle', 'none', 'LineWidth', 1.5);

% Residuals against predicted values
subplot(2, 3, 6);
scatter(y_pred, residuals, 25, 'filled');
title('Residuals vs Predicted');
xlabel('Predicted Value');
ylabel('Residual');
grid on;
hold on;
plot([min(y_pred), max(y_pred)], [0, 0], 'r-', 'LineWidth', 1.5);

% Set title for the entire figure
sgtitle('Experiment Summary', 'FontSize', 14, 'FontWeight', 'bold');

% Save the summary figure
saveas(gcf, fullfile(results_dir, 'experiment_summary.png'));
saveas(gcf, fullfile(results_dir, 'experiment_summary.fig'));

%% 6. Save Results in Multiple Formats for Maximum Reproducibility
fprintf('\nSaving results in multiple formats...\n');

% Compile all results into a single structure
all_results = struct();
all_results.environment = environment;
all_results.config = config;
all_results.data_stats = struct(...
'n_samples', config.n_samples, ...
'n_features', config.n_features, ...
'feature_means', mean(data.X), ...
'feature_stds', std(data.X), ...
'target_mean', mean(data.y), ...
'target_std', std(data.y), ...
'feature_target_corr', feature_target_corr);
all_results.preprocessing = preprocessing;
all_results.cv_results = rmfield(cv_results, 'models'); % Remove large model objects
all_results.test_results = struct(...
'mse', test_mse, ...
'r2', test_r2);

% Save as MAT file (MATLAB native format)
save(fullfile(results_dir, 'all_results.mat'), 'all_results');

% Save as JSON (for platform-independent sharing)
jsonStr = jsonencode(all_results);
fid = fopen(fullfile(results_dir, 'all_results.json'), 'w');
fprintf(fid, '%s', jsonStr);
fclose(fid);

% Create a summary table for CSV export
summary_table = struct2table(struct(...
'Date', {char(environment.date_time)}, ...
'MatlabVersion', {environment.matlab_version}, ...
'Computer', {environment.computer}, ...
'User', {environment.user}, ...
'RNGSeed', rng_seed, ...
'NumSamples', config.n_samples, ...
'NumFeatures', config.n_features, ...
'ModelType', {config.model_type}, ...
'CV_MSE_Mean', cv_results.mean_mse, ...
'CV_MSE_Std', cv_results.std_mse, ...
'CV_R2_Mean', cv_results.mean_r2, ...
'CV_R2_Std', cv_results.std_r2, ...
'Test_MSE', test_mse, ...
'Test_R2', test_r2));

% Save summary as CSV
writetable(summary_table, fullfile(results_dir, 'summary.csv'));

%% 7. Generate Reproducibility Report
fprintf('\nGenerating reproducibility report...\n');

% Calculate total execution time
total_time = toc(start_time);
fprintf('Total execution time: %.2f seconds\n', total_time);

% Create a reproducibility report as a markdown file
fid = fopen(fullfile(results_dir, 'reproducibility_report.md'), 'w');

fprintf(fid, '# Reproducibility Report\n\n');
fprintf(fid, '## Environment Information\n\n');
fprintf(fid, '- MATLAB Version: %s\n', environment.matlab_version);
fprintf(fid, '- Computer: %s\n', environment.computer);
fprintf(fid, '- Date and Time: %s\n', char(environment.date_time));
fprintf(fid, '- User: %s\n', environment.user);
fprintf(fid, '- Random Seed: %d\n', environment.rng_seed);
fprintf(fid, '- RNG Type: %s\n', environment.rng_type);
fprintf(fid, '- Execution Time: %.2f seconds\n\n', total_time);

fprintf(fid, '### Installed Toolboxes\n\n');
for i = 1:length(environment.toolboxes)
fprintf(fid, '- %s\n', environment.toolboxes{i});
end
fprintf(fid, '\n');

fprintf(fid, '## Experiment Configuration\n\n');
fprintf(fid, '- Number of Samples: %d\n', config.n_samples);
fprintf(fid, '- Number of Features: %d\n', config.n_features);
fprintf(fid, '- Noise Level: %.2f\n', config.noise_level);
fprintf(fid, '- Training Ratio: %.2f\n', config.train_ratio);
fprintf(fid, '- Cross-validation Folds: %d\n', config.k_folds);
fprintf(fid, '- Model Type: %s\n\n', config.model_type);

fprintf(fid, '## Data Statistics\n\n');
fprintf(fid, '- Feature Means: %s\n', mat2str(mean(data.X), 4));
fprintf(fid, '- Feature Standard Deviations: %s\n', mat2str(std(data.X), 4));
fprintf(fid, '- Target Mean: %.4f\n', mean(data.y));
fprintf(fid, '- Target Standard Deviation: %.4f\n\n', std(data.y));

fprintf(fid, '## Cross-validation Results\n\n');
fprintf(fid, '- Mean MSE: %.4f ( %.4f)\n', cv_results.mean_mse, cv_results.std_mse);
fprintf(fid, '- Mean R: %.4f ( %.4f)\n\n', cv_results.mean_r2, cv_results.std_r2);

fprintf(fid, '## Test Set Results\n\n');
fprintf(fid, '- MSE: %.4f\n', test_mse);
fprintf(fid, '- R: %.4f\n\n', test_r2);

fprintf(fid, '## Reproducibility Instructions\n\n');
fprintf(fid, 'To reproduce these results:\n\n');
fprintf(fid, '1. Ensure you have MATLAB %s installed with the required toolboxes\n', environment.matlab_version);
fprintf(fid, '2. Set the random seed to %d using: rng(%d, ''%s'')\n', rng_seed, rng_seed, environment.rng_type);
fprintf(fid, '3. Use the provided configuration parameters in config.mat\n');
fprintf(fid, '4. Run the script with the same data generation parameters\n');
fprintf(fid, '5. Compare your results with those saved in all_results.mat and summary.csv\n\n');

fprintf(fid, '## Data and Results Files\n\n');
fprintf(fid, '- environment.mat: Environment information\n');
fprintf(fid, '- config.mat: Configuration parameters\n');
fprintf(fid, '- raw_data.mat/.csv: Generated data\n');
fprintf(fid, '- preprocessing.mat: Preprocessing information\n');
fprintf(fid, '- preprocessed_data.mat: Processed training and testing data\n');
fprintf(fid, '- cv_results.mat: Cross-validation results\n');
fprintf(fid, '- final_results.mat: Final model and test results\n');
fprintf(fid, '- predictions.csv: Test set predictions\n');
fprintf(fid, '- all_results.mat/.json: Combined results\n');
fprintf(fid, '- summary.csv: Summary statistics in CSV format\n');
fprintf(fid, '- Various .png and .fig files: Visualizations\n');

fclose(fid);

fprintf('Reproducibility report generated: %s\n', fullfile(results_dir, 'reproducibility_report.md'));

% Create a ZIP archive of all results for easy sharing
fprintf('\nCreating ZIP archive of all results...\n');
zip_filename = ['experiment_results_', timestamp, '.zip'];
zip(zip_filename, results_dir);
fprintf('Results archived in %s\n', zip_filename);

fprintf('\nReproducible research framework execution complete!\n');
fprintf('All results saved in directory: %s\n', results_dir);
fprintf('and archived in: %s\n', zip_filename);

%% 8. Helper Functions
% These functions are defined inline for complete reproducibility

% Function to generate synthetic data
function data = generate_synthetic_data(n_samples, n_features, noise_level, seed)
% Ensure reproducibility within the function
rng(seed, 'twister');

% Generate feature matrix with some correlation structure
Sigma = eye(n_features);
% Add correlation between some features
for i = 1:n_features
    for j = i+1:n_features
        if j <= n_features
            Sigma(i,j) = 0.3 / abs(i-j);
            Sigma(j,i) = Sigma(i,j);
        end
    end
end

X = mvnrnd(zeros(1, n_features), Sigma, n_samples);

% Generate target variable with nonlinear relationship and noise
% Use a combination of linear, quadratic and interaction terms
beta = randn(n_features, 1);  % Linear coefficients
y = X * beta;  % Linear component

% Add some nonlinear components
if n_features >= 3
    y = y + 0.5 * X(:,1).^2 - 0.3 * X(:,2).^2 + 0.7 * X(:,1) .* X(:,2);  % Quadratic and interaction
end

% Add controlled noise
y = y + noise_level * randn(n_samples, 1);

% Return data structure
data = struct('X', X, 'y', y, 'beta', beta, 'Sigma', Sigma);

end

% Function to standardize features
function [X_scaled, mu, sigma] = standardize_features(X)
mu = mean(X);
sigma = std(X);
X_scaled = (X - mu) ./ sigma;
end

% Function to train a model based on specified type
function model = train_model(X, y, model_type)
switch lower(model_type)
case 'linear'
% Linear regression
model = fitlm(X, y);
case 'tree'
% Decision tree
model = fitrtree(X, y);
case 'svm'
% Support Vector Machine regression
model = fitrsvm(X, y, 'KernelFunction', 'rbf', 'Standardize', true);
otherwise
error('Unsupported model type: %s', model_type);
end
end

% Function to make predictions with a trained model
function y_pred = predict_model(model, X, model_type)
switch lower(model_type)
case 'linear'
% Linear regression prediction
y_pred = predict(model, X);
case 'tree'
% Decision tree prediction
y_pred = predict(model, X);
case 'svm'
% SVM prediction
y_pred = predict(model, X);
otherwise
error('Unsupported model type: %s', model_type);
end
end
