%% problem1_code.m
% Bayesian Uncertainty Quantification for Transformer DGA Analysis
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem1_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Bayesian Uncertainty Quantification for Transformer Condition Monitoring
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-15
% Description: Implements Bayesian neural network classifier for transformer
%              fault diagnosis using dissolved gas analysis with Monte Carlo
%              dropout and conformal prediction for uncertainty quantification

clear; close all; clc;

%% 1. Data Generation - Synthetic DGA Dataset
fprintf('========================================\n');
fprintf('Transformer Condition Monitoring - Bayesian Uncertainty Quantification\n');
fprintf('========================================\n\n');

fprintf('Step 1: Generating synthetic DGA dataset...\n');

rng(42); % Reproducibility

% Number of samples per class
numSamplesPerClass = 250;
totalSamples = 4 * numSamplesPerClass;

% Fault class definitions with characteristic gas concentration patterns
% Classes: 1-Normal, 2-Thermal, 3-Electrical, 4-Arcing
% Features: [H2, CH4, C2H4, C2H6, C2H2] in ppm

% Mean gas concentrations for each fault type
classMeans = [
    50,  20,  10,  15,   5;  % Normal
   150,  80,  40,  30,  10;  % Thermal
   200, 100, 120,  40,  80;  % Electrical
   300, 150, 180,  50, 200   % Arcing
];

% Covariance structure (shared across classes for simplicity)
classStd = 20; % Standard deviation
covMatrix = classStd^2 * eye(5);

% Generate data
data = zeros(totalSamples, 5);
labels = zeros(totalSamples, 1);
classNames = {'Normal', 'Thermal', 'Electrical', 'Arcing'};

for classIdx = 1:4
    startIdx = (classIdx-1)*numSamplesPerClass + 1;
    endIdx = classIdx*numSamplesPerClass;
    
    data(startIdx:endIdx, :) = mvnrnd(classMeans(classIdx, :), ...
                                      covMatrix, numSamplesPerClass);
    labels(startIdx:endIdx) = classIdx;
end

% Ensure non-negative concentrations
data = max(data, 0);

fprintf('Generated %d samples across 4 fault classes\n', totalSamples);
fprintf('Features: H$_2$, CH$_4$, C$_2$H$_4$, C$_2$H$_6$, C$_2$H$_2$ concentrations\n\n');

%% 2. Data Partitioning
fprintf('Step 2: Partitioning dataset...\n');

% Stratified split: 60% train, 20% calibration, 20% test
cv = cvpartition(labels, 'HoldOut', 0.4);
trainIdx = training(cv);
tempIdx = test(cv);

tempLabels = labels(tempIdx);
cvTemp = cvpartition(tempLabels, 'HoldOut', 0.5);
calIdx = find(tempIdx);
calIdx = calIdx(training(cvTemp));
testIdx = find(tempIdx);
testIdx = testIdx(test(cvTemp));

XTrain = data(trainIdx, :);
YTrain = labels(trainIdx);
XCal = data(calIdx, :);
YCal = labels(calIdx);
XTest = data(testIdx, :);
YTest = labels(testIdx);

fprintf('Training set: %d samples\n', size(XTrain, 1));
fprintf('Calibration set: %d samples\n', size(XCal, 1));
fprintf('Test set: %d samples\n\n', size(XTest, 1));

%% 3. Feature Normalisation
fprintf('Step 3: Normalising features...\n');

[XTrainNorm, mu, sigma] = zscore(XTrain);
XCalNorm = (XCal - mu) ./ sigma;
XTestNorm = (XTest - mu) ./ sigma;

fprintf('Features normalised to zero mean and unit variance\n\n');

%% 4. Baseline Neural Network (Without Dropout)
fprintf('Step 4: Training baseline neural network...\n');

% Network architecture
hiddenLayerSize = [20, 10];
net = fitcnet(XTrainNorm, YTrain, 'LayerSizes', hiddenLayerSize, ...
              'Standardize', false, 'IterationLimit', 200);

% Baseline predictions
YPredBaseline = predict(net, XTestNorm);
baselineAccuracy = sum(YPredBaseline == YTest) / length(YTest);

fprintf('Baseline network architecture: [5 -> 20 -> 10 -> 4]\n');
fprintf('Baseline test accuracy: %.2f%%\n\n', baselineAccuracy * 100);

%% 5. Monte Carlo Dropout Implementation
fprintf('Step 5: Implementing Monte Carlo dropout...\n');

% For pedagogical purposes, we simulate MC Dropout by training multiple
% networks with different random initialisations (approximating dropout effect)
% In production, one would modify network architecture to retain dropout at test time

numMCsamples = 100;
numTestSamples = size(XTestNorm, 1);
numClasses = 4;

% Preallocate prediction matrix
MCpredictions = zeros(numTestSamples, numClasses, numMCsamples);

fprintf('Performing %d Monte Carlo forward passes...\n', numMCsamples);

for mcIdx = 1:numMCsamples
    if mod(mcIdx, 20) == 0
        fprintf('  Completed %d/%d samples\n', mcIdx, numMCsamples);
    end
    
    % Train network with different random seed (simulating dropout stochasticity)
    rng(mcIdx + 100);
    netMC = fitcnet(XTrainNorm, YTrain, 'LayerSizes', hiddenLayerSize, ...
                    'Standardize', false, 'IterationLimit', 150);
    
    % Get prediction probabilities
    [~, scores] = predict(netMC, XTestNorm);
    MCpredictions(:, :, mcIdx) = scores;
end

% Compute mean predictions and uncertainty
meanPredictions = mean(MCpredictions, 3);
[~, YPredMC] = max(meanPredictions, [], 2);
mcAccuracy = sum(YPredMC == YTest) / length(YTest);

% Epistemic uncertainty (prediction entropy)
epsilon = 1e-10; % Numerical stability
epistemicUncertainty = -sum(meanPredictions .* log(meanPredictions + epsilon), 2);

fprintf('\nMonte Carlo Dropout Results:\n');
fprintf('MC test accuracy: %.2f%%\n', mcAccuracy * 100);
fprintf('Mean epistemic uncertainty: %.3f (max entropy: %.3f)\n', ...
        mean(epistemicUncertainty), log(numClasses));

%% 6. Conformal Prediction
fprintf('\nStep 6: Implementing conformal prediction...\n');

% Compute non-conformity scores on calibration set
[~, calScores] = predict(net, XCalNorm);
nonConformityScores = 1 - calScores(sub2ind(size(calScores), ...
                                    (1:length(YCal))', YCal));

% Define coverage levels
coverageLevels = [0.90, 0.95, 0.99];
predictionSets = cell(length(coverageLevels), 1);

fprintf('Calibrating prediction sets for coverage levels:\n');

for covIdx = 1:length(coverageLevels)
    alpha = 1 - coverageLevels(covIdx);
    % Compute quantile threshold
    quantileThreshold = quantile(nonConformityScores, 1 - alpha);
    
    % Generate prediction sets for test samples
    [~, testScores] = predict(net, XTestNorm);
    testNonConformity = 1 - testScores;
    
    % Prediction set includes all classes with non-conformity <= threshold
    predSet = testNonConformity <= quantileThreshold;
    predictionSets{covIdx} = predSet;
    
    % Empirical coverage
    correctlyIncluded = zeros(numTestSamples, 1);
    for sampleIdx = 1:numTestSamples
        if predSet(sampleIdx, YTest(sampleIdx))
            correctlyIncluded(sampleIdx) = 1;
        end
    end
    empiricalCoverage = mean(correctlyIncluded);
    avgSetSize = mean(sum(predSet, 2));
    
    fprintf('  Coverage %.0f%%: Empirical coverage %.2f%%, Avg set size %.2f\n', ...
            coverageLevels(covIdx)*100, empiricalCoverage*100, avgSetSize);
end

%% 7. Uncertainty-Accuracy Analysis
fprintf('\nStep 7: Analysing uncertainty-accuracy correlation...\n');

% Classify predictions as correct/incorrect
correctPredictions = (YPredMC == YTest);

% Stratify by uncertainty quartiles
uncertaintyQuartiles = quantile(epistemicUncertainty, [0.25, 0.5, 0.75]);
quartileAccuracy = zeros(4, 1);
quartileLabels = {'Q1 (Low)', 'Q2', 'Q3', 'Q4 (High)'};

for quartIdx = 1:4
    if quartIdx == 1
        mask = epistemicUncertainty <= uncertaintyQuartiles(1);
    elseif quartIdx == 4
        mask = epistemicUncertainty > uncertaintyQuartiles(3);
    else
        mask = (epistemicUncertainty > uncertaintyQuartiles(quartIdx-1)) & ...
               (epistemicUncertainty <= uncertaintyQuartiles(quartIdx));
    end
    
    quartileAccuracy(quartIdx) = mean(correctPredictions(mask));
    fprintf('  %s uncertainty: Accuracy %.2f%% (n=%d)\n', ...
            quartileLabels{quartIdx}, quartileAccuracy(quartIdx)*100, sum(mask));
end

% Correlation coefficient
correlationCoeff = corr(epistemicUncertainty, double(correctPredictions));
fprintf('Uncertainty-Accuracy correlation: %.3f\n', correlationCoeff);

%% 8. Visualisation
fprintf('\nStep 8: Generating visualisations...\n');

% Create figure directory
if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: MC Dropout Prediction Distributions
fig1 = figure('Position', [100, 100, 1200, 800]);

% Select representative samples (correct high-conf, correct low-conf, incorrect)
[~, sortedConfIdx] = sort(epistemicUncertainty);
highConfCorrectIdx = sortedConfIdx(find(correctPredictions(sortedConfIdx), 1, 'first'));
lowConfCorrectIdx = sortedConfIdx(find(correctPredictions(sortedConfIdx), 1, 'last'));
incorrectIdx = find(~correctPredictions, 1, 'first');

representativeSamples = [highConfCorrectIdx, lowConfCorrectIdx, incorrectIdx];
sampleTitles = {'High Confidence Correct', 'Low Confidence Correct', 'Incorrect'};

for plotIdx = 1:3
    sampleIdx = representativeSamples(plotIdx);
    
    subplot(2, 3, plotIdx);
    probDist = squeeze(MCpredictions(sampleIdx, :, :))';
    violinplot_custom(probDist, classNames);
    ylabel('Predicted Probability', 'Interpreter', 'latex', 'FontSize', 11);
    title(sprintf('%s (True: %s, Pred: %s)', sampleTitles{plotIdx}, ...
                  classNames{YTest(sampleIdx)}, classNames{YPredMC(sampleIdx)}), ...
          'Interpreter', 'latex', 'FontSize', 12);
    ylim([0, 1]);
    grid on;
end

% Uncertainty histogram
subplot(2, 3, 4);
histogram(epistemicUncertainty(correctPredictions), 20, ...
          'FaceColor', [0.2, 0.7, 0.2], 'FaceAlpha', 0.6, 'EdgeColor', 'none');
hold on;
histogram(epistemicUncertainty(~correctPredictions), 20, ...
          'FaceColor', [0.8, 0.2, 0.2], 'FaceAlpha', 0.6, 'EdgeColor', 'none');
xlabel('Epistemic Uncertainty (Entropy)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 11);
legend({'Correct', 'Incorrect'}, 'Interpreter', 'latex', 'Location', 'best');
title('Uncertainty Distribution', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

% Uncertainty vs Accuracy by quartile
subplot(2, 3, 5);
bar(quartileAccuracy * 100, 'FaceColor', [0.3, 0.5, 0.8]);
set(gca, 'XTickLabel', quartileLabels, 'TickLabelInterpreter', 'latex');
ylabel('Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 11);
xlabel('Uncertainty Quartile', 'Interpreter', 'latex', 'FontSize', 11);
title('Accuracy by Uncertainty Level', 'Interpreter', 'latex', 'FontSize', 12);
ylim([0, 100]);
grid on;

% Scatter: Uncertainty vs Correctness
subplot(2, 3, 6);
scatter(epistemicUncertainty(correctPredictions), ones(sum(correctPredictions), 1), ...
        30, [0.2, 0.7, 0.2], 'filled', 'MarkerFaceAlpha', 0.5);
hold on;
scatter(epistemicUncertainty(~correctPredictions), zeros(sum(~correctPredictions), 1), ...
        30, [0.8, 0.2, 0.2], 'filled', 'MarkerFaceAlpha', 0.5);
xlabel('Epistemic Uncertainty', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Prediction Outcome', 'Interpreter', 'latex', 'FontSize', 11);
set(gca, 'YTick', [0, 1], 'YTickLabel', {'Incorrect', 'Correct'}, ...
    'TickLabelInterpreter', 'latex');
title(sprintf('Correlation: $\\rho = %.3f$', correlationCoeff), ...
      'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle('\textbf{Monte Carlo Dropout Uncertainty Quantification}', ...
        'Interpreter', 'latex', 'FontSize', 14);

saveas(fig1, 'figures/Problem1_MCDropout_Analysis.fig');
saveas(fig1, 'figures/Problem1_MCDropout_Analysis.eps', 'epsc');
saveas(fig1, 'figures/Problem1_MCDropout_Analysis.jpg');
fprintf('Saved: Problem1_MCDropout_Analysis\n');

% Figure 2: Conformal Prediction Calibration
fig2 = figure('Position', [150, 150, 900, 600]);

% Calibration curve
subplot(1, 2, 1);
targetCoverage = coverageLevels * 100;
empiricalCoverage = zeros(size(coverageLevels));
avgSetSizes = zeros(size(coverageLevels));

for covIdx = 1:length(coverageLevels)
    predSet = predictionSets{covIdx};
    correctlyIncluded = zeros(numTestSamples, 1);
    for sampleIdx = 1:numTestSamples
        if predSet(sampleIdx, YTest(sampleIdx))
            correctlyIncluded(sampleIdx) = 1;
        end
    end
    empiricalCoverage(covIdx) = mean(correctlyIncluded) * 100;
    avgSetSizes(covIdx) = mean(sum(predSet, 2));
end

plot(targetCoverage, targetCoverage, 'k-', 'LineWidth', 1.5);
hold on;
plot(targetCoverage, empiricalCoverage, 'bo-', 'LineWidth', 2, 'MarkerSize', 8);
xlabel('Target Coverage (\%)', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Empirical Coverage (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('Conformal Prediction Calibration', 'Interpreter', 'latex', 'FontSize', 12);
legend({'Perfect Calibration', 'Achieved Coverage'}, 'Interpreter', 'latex', ...
       'Location', 'southeast');
grid on;
axis square;

% Set size vs coverage
subplot(1, 2, 2);
yyaxis left;
plot(targetCoverage, avgSetSizes, 'bs-', 'LineWidth', 2, 'MarkerSize', 8);
ylabel('Average Prediction Set Size', 'Interpreter', 'latex', 'FontSize', 11);
ylim([0, 4]);

yyaxis right;
plot(targetCoverage, empiricalCoverage - targetCoverage, 'ro-', ...
     'LineWidth', 2, 'MarkerSize', 8);
ylabel('Coverage Deviation (\%)', 'Interpreter', 'latex', 'FontSize', 11);
yline(0, 'k-');

xlabel('Target Coverage (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('Set Size and Coverage Deviation', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle('\textbf{Conformal Prediction Performance}', ...
        'Interpreter', 'latex', 'FontSize', 14);

saveas(fig2, 'figures/Problem1_Conformal_Calibration.fig');
saveas(fig2, 'figures/Problem1_Conformal_Calibration.eps', 'epsc');
saveas(fig2, 'figures/Problem1_Conformal_Calibration.jpg');
fprintf('Saved: Problem1_Conformal_Calibration\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');

%% Helper Function: Custom Violin Plot
function violinplot_custom(data, labels)
    % Simple violin plot implementation
    numGroups = size(data, 2);
    colors = lines(numGroups);
    
    hold on;
    for groupIdx = 1:numGroups
        groupData = data(:, groupIdx);
        
        % Kernel density estimation
        [f, xi] = ksdensity(groupData);
        f = f / max(f) * 0.3; % Normalise width
        
        % Plot violin
        fill([groupIdx - f, fliplr(groupIdx + f)], ...
             [xi, fliplr(xi)], colors(groupIdx, :), ...
             'FaceAlpha', 0.6, 'EdgeColor', 'none');
        
        % Plot median
        plot(groupIdx, median(groupData), 'ko', 'MarkerSize', 6, 'LineWidth', 1.5);
    end
    
    set(gca, 'XTick', 1:numGroups, 'XTickLabel', labels, ...
        'TickLabelInterpreter', 'latex');
    xlim([0.5, numGroups + 0.5]);
end
