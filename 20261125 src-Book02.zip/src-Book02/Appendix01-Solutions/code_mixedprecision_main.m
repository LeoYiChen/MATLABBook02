%% code_mixedprecision_main.m
% Main script for mixed precision eigenvalue solver.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:mixedprecision_main
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Mixed Precision Eigenvalue Solver
% Author: Dr Yi Chen
% MATLAB Version: R2023b
% Date: 2024
% Description: Demonstrates mixed precision methods for sparse eigenvalue
% problems, comparing single, double, and mixed precision approaches

%% Initialisation
clear; close all; clc;

fprintf('=== Mixed Precision Eigenvalue Solver ===\n\n');

% Problem size
n = 1000;  % Matrix dimension
nEigenvalues = 10;  % Number of eigenvalues to compute

%% Generate Sparse Test Matrix
fprintf('Generating sparse test matrix (n = %d)...\n', n);
A = generateSparseTestMatrix(n);
fprintf('  Matrix density: %.2f%%\n', 100 * nnz(A) / n^2);
fprintf('  Condition number estimate: %.2e\n\n', condest(A));

%% Compute Reference Solution (Double Precision)
fprintf('Computing reference solution (double precision)...\n');
tic;
[V_ref, D_ref] = eigs(A, nEigenvalues, 'smallestabs');
lambda_ref = diag(D_ref);
time_double = toc;
fprintf('  Time: %.4f seconds\n', time_double);
fprintf('  Smallest eigenvalue: %.6e\n\n', min(abs(lambda_ref)));

%% Single Precision Solver
fprintf('Computing solution (single precision)...\n');
tic;
[V_single, lambda_single] = singlePrecisionEigenSolver(A, nEigenvalues);
time_single = toc;

% Compute errors
error_single = computeEigenvalueError(lambda_single, lambda_ref);
fprintf('  Time: %.4f seconds\n', time_single);
fprintf('  Speedup: %.2fx\n', time_double / time_single);
fprintf('  Mean relative error: %.2e\n\n', mean(error_single));

%% Mixed Precision Iterative Refinement
fprintf('Computing solution (mixed precision refinement)...\n');
tic;
[V_mixed, lambda_mixed, refinement_history] = ...
    mixedPrecisionEigenSolver(A, nEigenvalues, V_single, lambda_single);
time_mixed = toc;

error_mixed = computeEigenvalueError(lambda_mixed, lambda_ref);
fprintf('  Time: %.4f seconds\n', time_mixed);
fprintf('  Speedup vs. double: %.2fx\n', time_double / time_mixed);
fprintf('  Mean relative error: %.2e\n', mean(error_mixed));
fprintf('  Refinement iterations: %d\n\n', length(refinement_history));

%% Performance Comparison
fprintf('=== Performance Summary ===\n');
fprintf('Method               Time (s)   Speedup   Mean Error\n');
fprintf('--------------------------\n');
fprintf('Double Precision     %.4f     1.00x     %.2e\n', ...
    time_double, 0);
fprintf('Single Precision     %.4f     %.2fx     %.2e\n', ...
    time_single, time_double/time_single, mean(error_single));
fprintf('Mixed Precision      %.4f     %.2fx     %.2e\n', ...
    time_mixed, time_double/time_mixed, mean(error_mixed));
fprintf('--------------------------\n\n');

%% Visualisation
visualiseResults(lambda_ref, lambda_single, lambda_mixed, ...
    error_single, error_mixed, refinement_history);

%% Memory Usage Analysis
fprintf('=== Memory Usage Analysis ===\n');
analyseMemoryUsage(n, nEigenvalues);
