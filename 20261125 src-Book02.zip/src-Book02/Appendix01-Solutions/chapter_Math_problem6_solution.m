%% chapter_Math_problem6_solution.m
% Comprehensive polynomial curve fitting.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem6_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem6_CurveFitting()
    % PROBLEM6_CURVEFITTING Comprehensive polynomial regression analysis
    %
    % This function demonstrates:
    % - Polynomial fitting using normal equations
    % - QR decomposition method (more stable)
    % - SVD-based pseudoinverse
    % - Multiple polynomial degrees comparison
    % - Residual analysis and diagnostic plots
    % - Quality metrics (R뿯½, RMSE, MAE)
    % - Cross-validation for model selection
    % - Overfitting demonstration
    % - Ridge regression (regularization)
    % - Confidence intervals and prediction bands
    %
    % References:
    % - Bj뿯½rck, "Numerical Methods for Least Squares Problems" (1996)
    % - Hastie, Tibshirani & Friedman, "Elements of Statistical Learning" (2009)
    % - Press et al., "Numerical Recipes" (2007)
    %
    % Author: Dr Yi Chen
    % Date: 2025
    % MATLAB Version: R2023b or later
    
    fprintf('\n=== Problem 6: Polynomial Curve Fitting ===\n\n');
    
    % Define data
    x_data = [0, 1, 2, 3, 4, 5]';
    y_data = [2.1, 7.7, 13.6, 27.2, 40.9, 61.1]';
    
    fprintf('Data points:\n');
    fprintf('%5s  %8s\n', 'x', 'y');
    fprintf('%s\n', repmat('-', 1, 20));
    for i = 1:length(x_data)
        fprintf('%5.1f  %8.2f\n', x_data(i), y_data(i));
    end
    fprintf('\n');
    
    % Fit polynomial of degree 2 (as requested)
    degree = 2;
    fprintf('=== Fitting Polynomial of Degree %d ===\n\n', degree);
    
    % Method 1: Normal equations
    fprintf('Method 1: Normal Equations\n');
    [coeffs_normal, metrics_normal] = fitPolynomialNormal(x_data, y_data, degree);
    
    % Method 2: QR decomposition
    fprintf('\nMethod 2: QR Decomposition\n');
    [coeffs_qr, metrics_qr] = fitPolynomialQR(x_data, y_data, degree);
    
    % Method 3: SVD (pseudoinverse)
    fprintf('\nMethod 3: SVD Pseudoinverse\n');
    [coeffs_svd, metrics_svd] = fitPolynomialSVD(x_data, y_data, degree);
    
    % Method 4: MATLAB's polyfit
    fprintf('\nMethod 4: MATLAB polyfit()\n');
    coeffs_matlab = polyfit(x_data, y_data, degree);
    y_fit_matlab = polyval(coeffs_matlab, x_data);
    metrics_matlab = computeMetrics(y_data, y_fit_matlab, degree);
    displayCoefficients(coeffs_matlab, degree);
    displayMetrics(metrics_matlab);
    
    % Compare methods
    fprintf('\n=== Method Comparison ===\n\n');
    compareMethodss(coeffs_normal, coeffs_qr, coeffs_svd, coeffs_matlab);
    
    % Detailed analysis for best method (QR)
    coeffs = coeffs_qr;
    fprintf('\n=== Detailed Analysis (QR Method) ===\n\n');
    
    % Residual analysis
    y_fit = polyval(coeffs, x_data);
    residuals = y_data - y_fit;
    
    fprintf('Residual Analysis:\n');
    fprintf('%5s  %8s  %8s  %8s\n', 'x', 'y_obs', 'y_fit', 'residual');
    fprintf('%s\n', repmat('-', 1, 40));
    for i = 1:length(x_data)
        fprintf('%5.1f  %8.2f  %8.2f  %8.4f\n', ...
            x_data(i), y_data(i), y_fit(i), residuals(i));
    end
    fprintf('\n');
    
    % Test for patterns in residuals
    fprintf('Residual statistics:\n');
    fprintf('  Mean: %.6f (should be ≈0)\n', mean(residuals));
    fprintf('  Std dev: %.6f\n', std(residuals));
    fprintf('  Min: %.6f, Max: %.6f\n', min(residuals), max(residuals));
    
    % Durbin-Watson test for autocorrelation
    dw = sum(diff(residuals).^2) / sum(residuals.^2);
    fprintf('  Durbin-Watson: %.4f (2 = no autocorrelation)\n', dw);
    
    % Compare multiple polynomial degrees
    fprintf('\n=== Polynomial Degree Comparison ===\n\n');
    degrees = 1:6;
    comparePolynomialDegrees(x_data, y_data, degrees);
    
    % Demonstrate overfitting
    fprintf('\n=== Overfitting Demonstration ===\n\n');
    demonstrateOverfitting(x_data, y_data);
    
    % Ridge regression
    fprintf('\n=== Ridge Regression (Regularization) ===\n\n');
    demonstrateRidgeRegression(x_data, y_data, degree);
    
    % Cross-validation
    fprintf('\n=== Cross-Validation for Model Selection ===\n\n');
    crossValidateModels(x_data, y_data, 1:5);
    
    % Confidence intervals
    fprintf('\n=== Confidence Intervals ===\n\n');
    computeConfidenceIntervals(x_data, y_data, coeffs, degree);
    
    % Create visualizations
    createVisualizationPlots(x_data, y_data, coeffs, degree, residuals);
    
    fprintf('\nAnalysis complete!\n');
end

function [coeffs, metrics] = fitPolynomialNormal(x, y, degree)
    % FITPOLYNOMIALNORMAL Fit using normal equations
    %
    % Solves: (X'X)a = X'y
    % WARNING: Can be numerically unstable!
    
    X = createDesignMatrix(x, degree);
    
    % Form normal equations
    XtX = X' * X;
    Xty = X' * y;
    
    fprintf('  Design matrix X: %d 뿯½ %d\n', size(X, 1), size(X, 2));
    fprintf('  X''X matrix: %d 뿯½ %d\n', size(XtX, 1), size(XtX, 2));
    fprintf('  Condition number of X''X: %.2e\n', cond(XtX));
    
    % Solve normal equations
    coeffs = XtX \ Xty;
    coeffs = flipud(coeffs);  % Convention: highest degree first
    
    % Compute metrics
    y_fit = polyval(coeffs, x);
    metrics = computeMetrics(y, y_fit, degree);
    
    displayCoefficients(coeffs, degree);
    displayMetrics(metrics);
end

function [coeffs, metrics] = fitPolynomialQR(x, y, degree)
    % FITPOLYNOMIALQR Fit using QR decomposition (more stable)
    %
    % Solves: Xa = y using QR factorization
    % This is what MATLAB's backslash operator uses!
    
    X = createDesignMatrix(x, degree);
    
    fprintf('  Using QR factorization...\n');
    [Q, R] = qr(X, 0);  % Economy-size QR
    
    fprintf('  Q matrix: %d 뿯½ %d\n', size(Q, 1), size(Q, 2));
    fprintf('  R matrix: %d 뿯½ %d\n', size(R, 1), size(R, 2));
    fprintf('  Condition number of R: %.2e\n', cond(R));
    
    % Solve Ra = Q'y
    coeffs = R \ (Q' * y);
    coeffs = flipud(coeffs);
    
    % Compute metrics
    y_fit = polyval(coeffs, x);
    metrics = computeMetrics(y, y_fit, degree);
    
    displayCoefficients(coeffs, degree);
    displayMetrics(metrics);
end

function [coeffs, metrics] = fitPolynomialSVD(x, y, degree)
    % FITPOLYNOMIALSVD Fit using SVD pseudoinverse
    %
    % Most stable method, handles rank-deficient cases
    
    X = createDesignMatrix(x, degree);
    
    fprintf('  Using SVD...\n');
    [U, S, V] = svd(X, 0);  % Economy SVD
    
    singular_values = diag(S);
    fprintf('  Singular values: [');
    fprintf('%.2e ', singular_values);
    fprintf(']\n');
    fprintf('  Condition number: %.2e\n', cond(X));
    
    % Compute pseudoinverse: X⁺ = V S⁻뿯½ U'
    % For full rank: X⁺ = (X'X)⁻뿯½X'
    coeffs = V * (S \ (U' * y));
    coeffs = flipud(coeffs);
    
    % Compute metrics
    y_fit = polyval(coeffs, x);
    metrics = computeMetrics(y, y_fit, degree);
    
    displayCoefficients(coeffs, degree);
    displayMetrics(metrics);
end

function X = createDesignMatrix(x, degree)
    % CREATEDESIGNMATRIX Build Vandermonde matrix
    %
    % X = [1, x, x뿯½, ..., x^degree]
    
    n = length(x);
    X = zeros(n, degree + 1);
    
    for j = 0:degree
        X(:, j+1) = x.^j;
    end
end

function metrics = computeMetrics(y_true, y_pred, degree)
    % COMPUTEMETRICS Calculate quality metrics
    
    n = length(y_true);
    residuals = y_true - y_pred;
    
    % Sum of squared residuals
    RSS = sum(residuals.^2);
    
    % Total sum of squares
    y_mean = mean(y_true);
    TSS = sum((y_true - y_mean).^2);
    
    % R-squared
    R2 = 1 - RSS / TSS;
    
    % Adjusted R-squared (penalizes additional parameters)
    R2_adj = 1 - (1 - R2) * (n - 1) / (n - degree - 1);
    
    % Root mean square error
    RMSE = sqrt(RSS / n);
    
    % Mean absolute error
    MAE = mean(abs(residuals));
    
    % Akaike Information Criterion
    AIC = n * log(RSS / n) + 2 * (degree + 1);
    
    % Bayesian Information Criterion
    BIC = n * log(RSS / n) + (degree + 1) * log(n);
    
    metrics.RSS = RSS;
    metrics.TSS = TSS;
    metrics.R2 = R2;
    metrics.R2_adj = R2_adj;
    metrics.RMSE = RMSE;
    metrics.MAE = MAE;
    metrics.AIC = AIC;
    metrics.BIC = BIC;
end

function displayCoefficients(coeffs, degree)
    % DISPLAYCOEFFICIENTS Pretty print polynomial coefficients
    
    fprintf('  Polynomial: p(x) = ');
    for i = 1:length(coeffs)
        power = degree - i + 1;
        coeff = coeffs(i);
        
        if i > 1
            if coeff >= 0
                fprintf(' + ');
            else
                fprintf(' - ');
                coeff = abs(coeff);
            end
        end
        
        if power == 0
            fprintf('%.6f', coeff);
        elseif power == 1
            fprintf('%.6f뿯½x', coeff);
        else
            fprintf('%.6f뿯½x^%d', coeff, power);
        end
    end
    fprintf('\n');
end

function displayMetrics(metrics)
    % DISPLAYMETRICS Pretty print quality metrics
    
    fprintf('  Quality metrics:\n');
    fprintf('    R뿯½ = %.6f (%.2f%% variance explained)\n', ...
        metrics.R2, 100 * metrics.R2);
    fprintf('    R뿯½_adj = %.6f\n', metrics.R2_adj);
    fprintf('    RMSE = %.6f\n', metrics.RMSE);
    fprintf('    MAE = %.6f\n', metrics.MAE);
    fprintf('    RSS = %.6f\n', metrics.RSS);
    fprintf('    AIC = %.6f (lower is better)\n', metrics.AIC);
    fprintf('    BIC = %.6f (lower is better)\n', metrics.BIC);
end

function compareMethodss(c1, c2, c3, c4)
    % COMPAREMETHODS Compare coefficient results
    
    methods = {'Normal Eqs', 'QR Decomp', 'SVD', 'MATLAB'};
    coeffs_all = [c1, c2, c3, c4'];
    
    fprintf('Coefficient comparison:\n');
    fprintf('%12s', 'Method');
    for i = 1:length(c1)
        fprintf('  %12s', sprintf('a_%d', length(c1)-i));
    end
    fprintf('\n');
    fprintf('%s\n', repmat('-', 1, 12 + 14*length(c1)));
    
    for m = 1:length(methods)
        fprintf('%12s', methods{m});
        for i = 1:length(c1)
            fprintf('  %12.6f', coeffs_all(i, m));
        end
        fprintf('\n');
    end
    
    % Check agreement
    max_diff = max(max(abs(coeffs_all - coeffs_all(:,1))));
    fprintf('\nMaximum difference between methods: %.2e\n', max_diff);
    if max_diff < 1e-10
        fprintf('✓ All methods agree!\n');
    else
        fprintf('뿯⚽ Methods show differences (possible numerical issues)\n');
    end
end

function comparePolynomialDegrees(x, y, degrees)
    % COMPAREPOLYNOMIALDEGREES Compare fits of various polynomial degrees
    
    fprintf('Comparing polynomial degrees %d to %d:\n\n', ...
        min(degrees), max(degrees));
    
    fprintf('%6s  %10s  %10s  %10s  %10s  %10s\n', ...
        'Degree', 'R뿯½', 'R뿯½_adj', 'RMSE', 'AIC', 'BIC');
    fprintf('%s\n', repmat('-', 1, 70));
    
    results = zeros(length(degrees), 6);
    
    for i = 1:length(degrees)
        d = degrees(i);
        
        % Fit polynomial
        try
            coeffs = polyfit(x, y, d);
            y_fit = polyval(coeffs, x);
            metrics = computeMetrics(y, y_fit, d);
            
            results(i, :) = [d, metrics.R2, metrics.R2_adj, ...
                metrics.RMSE, metrics.AIC, metrics.BIC];
            
            fprintf('%6d  %10.6f  %10.6f  %10.6f  %10.2f  %10.2f', ...
                d, metrics.R2, metrics.R2_adj, metrics.RMSE, ...
                metrics.AIC, metrics.BIC);
            
            % Flag best by different criteria
            fprintf('  ');
            if i > 1
                if metrics.AIC == min(results(1:i, 5))
                    fprintf('AIC* ');
                end
                if metrics.BIC == min(results(1:i, 6))
                    fprintf('BIC* ');
                end
            end
            fprintf('\n');
            
        catch
            fprintf('%6d  (Failed - ill-conditioned)\n', d);
        end
    end
    
    fprintf('\n* = Best by this criterion\n');
    
    % Recommendations
    [~, best_aic] = min(results(:, 5));
    [~, best_bic] = min(results(:, 6));
    
    fprintf('\nRecommendations:\n');
    fprintf('  AIC suggests degree %d\n', degrees(best_aic));
    fprintf('  BIC suggests degree %d (more conservative)\n', degrees(best_bic));
    
    if degrees(best_aic) < 3
        fprintf('  ✓ Recommended degrees avoid overfitting\n');
    else
        fprintf('  뿯⚽ High degree - check for overfitting!\n');
    end
end

function demonstrateOverfitting(x, y)
    % DEMONSTRATEOVERFITTING Show dangers of high-degree polynomials
    
    fprintf('Fitting polynomials of increasing degree...\n\n');
    
    % With n = 6 points, degree 5 polynomial fits perfectly
    n = length(x);
    fprintf('Note: With %d data points, degree %d polynomial\n', n, n-1);
    fprintf('      will fit PERFECTLY (RSS = 0) but is meaningless!\n\n');
    
    % Fit degree 5 (n-1)
    degree_high = n - 1;
    coeffs_high = polyfit(x, y, degree_high);
    y_fit_high = polyval(coeffs_high, x);
    
    fprintf('Degree %d polynomial:\n', degree_high);
    fprintf('  RSS = %.2e (perfect fit!)\n', sum((y - y_fit_high).^2));
    fprintf('  But coefficients are:\n');
    for i = 1:length(coeffs_high)
        fprintf('    a_%d = %.6f\n', degree_high-i+1, coeffs_high(i));
    end
    fprintf('\n');
    
    % Test on interpolation
    x_test = linspace(min(x), max(x), 100);
    y_test_low = polyval(polyfit(x, y, 2), x_test);
    y_test_high = polyval(coeffs_high, x_test);
    
    fprintf('Behavior between data points (interpolation):\n');
    fprintf('  Degree 2: smooth, reasonable\n');
    fprintf('  Degree %d: wild oscillations (Runge phenomenon)\n', degree_high);
    
    % Test on extrapolation
    x_extrap = [min(x)-1, max(x)+1];
    y_extrap_low = polyval(polyfit(x, y, 2), x_extrap);
    y_extrap_high = polyval(coeffs_high, x_extrap);
    
    fprintf('\nExtrapolation to x = %.1f and %.1f:\n', x_extrap);
    fprintf('  Degree 2: y = [%.2f, %.2f] (reasonable)\n', y_extrap_low);
    fprintf('  Degree %d: y = [%.2f, %.2f] (unreasonable!)\n', ...
        degree_high, y_extrap_high);
    
    fprintf('\nLesson: High-degree polynomials overfit the noise!\n');
    fprintf('         Use cross-validation to choose appropriate degree.\n');
end

function demonstrateRidgeRegression(x, y, degree)
    % DEMONSTRATERIDGEREGRESSION Show regularization effects
    
    fprintf('Ridge regression adds penalty 뿯ν||a||뿯½ to prevent overfitting\n\n');
    
    X = createDesignMatrix(x, degree);
    X_normalized = (X - mean(X)) ./ std(X);  % Standardize
    
    lambdas = [0, 0.01, 0.1, 1, 10];
    
    fprintf('%10s  %10s  %10s  %10s\n', '뿯ν', 'RMSE', '||a||', 'Condition');
    fprintf('%s\n', repmat('-', 1, 50));
    
    for lambda = lambdas
        % Solve: (X'X + 뿯νI)a = X'y
        XtX = X_normalized' * X_normalized;
        Xty = X_normalized' * y;
        
        a_ridge = (XtX + lambda * eye(size(XtX))) \ Xty;
        
        % Compute predictions
        y_pred = X_normalized * a_ridge;
        rmse = sqrt(mean((y - y_pred).^2));
        norm_a = norm(a_ridge);
        cond_num = cond(XtX + lambda * eye(size(XtX)));
        
        fprintf('%10.2f  %10.6f  %10.6f  %10.2e\n', ...
            lambda, rmse, norm_a, cond_num);
    end
    
    fprintf('\nObservations:\n');
    fprintf('  • As 뿯ν increases, coefficients shrink (||a|| decreases)\n');
    fprintf('  • Conditioning improves dramatically\n');
    fprintf('  • Small RMSE increase is acceptable for stability\n');
    fprintf('  • Choose 뿯ν by cross-validation\n');
end

function crossValidateModels(x, y, degrees)
    % CROSSVALIDATEMODELS Leave-one-out cross-validation
    
    fprintf('Leave-one-out cross-validation:\n');
    fprintf('(Train on n-1 points, test on remaining point)\n\n');
    
    n = length(x);
    
    fprintf('%6s  %12s  %12s\n', 'Degree', 'CV Error', 'Training RMSE');
    fprintf('%s\n', repmat('-', 1, 40));
    
    cv_errors = zeros(length(degrees), 1);
    
    for d_idx = 1:length(degrees)
        d = degrees(d_idx);
        
        cv_error = 0;
        
        for i = 1:n
            % Leave out point i
            x_train = x([1:i-1, i+1:n]);
            y_train = y([1:i-1, i+1:n]);
            x_test = x(i);
            y_test = y(i);
            
            % Fit on training data
            coeffs = polyfit(x_train, y_train, d);
            
            % Predict on test point
            y_pred = polyval(coeffs, x_test);
            
            % Accumulate error
            cv_error = cv_error + (y_test - y_pred)^2;
        end
        
        cv_error = sqrt(cv_error / n);
        cv_errors(d_idx) = cv_error;
        
        % Also compute training error
        coeffs_full = polyfit(x, y, d);
        y_pred_full = polyval(coeffs_full, x);
        train_rmse = sqrt(mean((y - y_pred_full).^2));
        
        fprintf('%6d  %12.6f  %12.6f', d, cv_error, train_rmse);
        
        if d_idx > 1 && cv_error == min(cv_errors(1:d_idx))
            fprintf('  뿯↽ Best CV');
        end
        fprintf('\n');
    end
    
    [min_cv, best_d_idx] = min(cv_errors);
    best_d = degrees(best_d_idx);
    
    fprintf('\nCross-validation selects degree %d\n', best_d);
    fprintf('CV error: %.6f\n', min_cv);
    
    fprintf('\nNote: CV error > training error (expected!)\n');
    fprintf('      Model must generalize to unseen data.\n');
end

function computeConfidenceIntervals(x, y, coeffs, degree)
    % COMPUTECONFIDENCEINTERVALS Estimate uncertainty in predictions
    
    fprintf('Computing 95%% confidence intervals...\n\n');
    
    n = length(x);
    y_fit = polyval(coeffs, x);
    residuals = y - y_fit;
    
    % Residual standard error
    sigma = sqrt(sum(residuals.^2) / (n - degree - 1));
    
    fprintf('Residual standard error: 뿯ν = %.6f\n', sigma);
    fprintf('Degrees of freedom: %d\n', n - degree - 1);
    
    % t-statistic for 95% confidence
    alpha = 0.05;
    t_val = tinv(1 - alpha/2, n - degree - 1);
    fprintf('t-value (95%% confidence): %.4f\n\n', t_val);
    
    % Confidence intervals for predictions
    X = createDesignMatrix(x, degree);
    H = X * ((X' * X) \ X');  % Hat matrix
    
    fprintf('%5s  %8s  %8s  %s\n', 'x', 'y_fit', 'CI width', '95% Interval');
    fprintf('%s\n', repmat('-', 1, 60));
    
    for i = 1:n
        % Standard error of fit at this point
        se_fit = sigma * sqrt(H(i,i));
        ci_width = t_val * se_fit;
        
        fprintf('%5.1f  %8.4f  %8.4f  [%7.4f, %7.4f]\n', ...
            x(i), y_fit(i), ci_width, ...
            y_fit(i) - ci_width, y_fit(i) + ci_width);
    end
    
    fprintf('\nInterpretation: We are 95%% confident the true mean\n');
    fprintf('                response lies within these intervals.\n');
end

function createVisualizationPlots(x, y, coeffs, degree, residuals)
    % CREATEVISUALIZATIONPLOTS Comprehensive visualization
    
    fprintf('\nCreating visualization plots...\n');
    
    figure('Position', [100, 100, 1400, 800], ...
        'Name', 'Polynomial Curve Fitting Analysis');
    
    % Generate fine grid for smooth curve
    x_plot = linspace(min(x) - 0.5, max(x) + 0.5, 200);
    y_plot = polyval(coeffs, x_plot);
    y_fit = polyval(coeffs, x);
    
    % Subplot 1: Data and fitted curve
    subplot(2, 3, 1);
    plot(x, y, 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'b', ...
        'DisplayName', 'Data');
    hold on;
    plot(x_plot, y_plot, 'r-', 'LineWidth', 2, ...
        'DisplayName', sprintf('Degree %d fit', degree));
    
    % Add vertical lines showing residuals
    for i = 1:length(x)
        plot([x(i), x(i)], [y(i), y_fit(i)], 'k-', ...
            'HandleVisibility', 'off');
    end
    
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Data and Polynomial Fit', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Location', 'northwest', 'Interpreter', 'latex');
    
    % Subplot 2: Residuals vs x
    subplot(2, 3, 2);
    plot(x, residuals, 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
    hold on;
    plot([min(x), max(x)], [0, 0], 'k-', 'LineWidth', 1);
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Residuals', 'Interpreter', 'latex', 'FontSize', 12);
    title('Residual Plot', 'Interpreter', 'latex', 'FontSize', 14);
    
    % Subplot 3: Residuals vs fitted values
    subplot(2, 3, 3);
    plot(y_fit, residuals, 'bo', 'MarkerSize', 10, 'MarkerFaceColor', 'b');
    hold on;
    plot([min(y_fit), max(y_fit)], [0, 0], 'k-', 'LineWidth', 1);
    hold off;
    grid on;
    xlabel('Fitted values', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Residuals', 'Interpreter', 'latex', 'FontSize', 12);
    title('Residuals vs Fitted', 'Interpreter', 'latex', 'FontSize', 14);
    
    % Subplot 4: Normal Q-Q plot
    subplot(2, 3, 4);
    qqplot(residuals);
    title('Normal Q-Q Plot of Residuals', 'Interpreter', 'latex', 'FontSize', 14);
    
    % Subplot 5: Histogram of residuals
    subplot(2, 3, 5);
    histogram(residuals, 'Normalization', 'pdf', 'FaceColor', 'b', 'EdgeColor', 'k');
    hold on;
    
    % Overlay normal distribution
    x_norm = linspace(min(residuals), max(residuals), 100);
    y_norm = normpdf(x_norm, mean(residuals), std(residuals));
    plot(x_norm, y_norm, 'r-', 'LineWidth', 2);
    
    hold off;
    xlabel('Residuals', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Density', 'Interpreter', 'latex', 'FontSize', 12);
    title('Residual Distribution', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Residuals', 'Normal fit', 'Interpreter', 'latex');
    
    % Subplot 6: Compare multiple degrees
    subplot(2, 3, 6);
    hold on;
    colors = lines(5);
    
    for d = 1:5
        c = polyfit(x, y, d);
        y_p = polyval(c, x_plot);
        plot(x_plot, y_p, 'LineWidth', 2, 'Color', colors(d,:), ...
            'DisplayName', sprintf('Degree %d', d));
    end
    
    plot(x, y, 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k', ...
        'DisplayName', 'Data');
    hold off;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Comparison of Polynomial Degrees', 'Interpreter', 'latex', 'FontSize', 14);
    legend('Location', 'northwest', 'Interpreter', 'latex', 'FontSize', 10);
end

% Execute problem
Problem6_CurveFitting();
