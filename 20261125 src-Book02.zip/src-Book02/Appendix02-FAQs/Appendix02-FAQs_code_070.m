%% Appendix02-FAQs_code_070.m
% Trigonometric Encoding of Cyclic Features for AI Time-Series Forecasting
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Create time-series data (1 week of hourly data)
hours = 0:(7*24 - 1); % 0 to 167 hours
daily_period = 24; % Period for daily cycles (24 hours)

% Encode cyclic hour-of-day feature (critical for AI model performance)
hour_sin = sin(2 * pi * hours / daily_period); % Sine component (captures cyclicity)
hour_cos = cos(2 * pi * hours / daily_period); % Cosine component (avoids 0/24 ambiguity)

% Generate synthetic energy demand data (with daily cyclic trend)
base_demand = 100; % Base energy demand (kW)
cyclic_demand = 20 * hour_sin; % Daily variation
noise = 5 * randn(size(hours)); % Random noise
energy_demand = base_demand + cyclic_demand + noise;

% Plot encoded features + demand data
figure;
subplot(2,1,1);
plot(hours, hour_sin, 'b', hours, hour_cos, 'r');
title('Sin/Cos Encoding of Hour-of-Day (Cyclic Feature)');
xlabel('Hour'); ylabel('Encoded Value');
legend('Sin(Hour/24)', 'Cos(Hour/24)');

subplot(2,1,2);
plot(hours, energy_demand);
title('Energy Demand (Cyclic Trend + Noise)');
xlabel('Hour'); ylabel('Demand (kW)');

% These features would be fed into MATLAB's Deep Learning Toolbox
% Example: trainLSTMNetwork([hour_sin, hour_cos], energy_demand)
