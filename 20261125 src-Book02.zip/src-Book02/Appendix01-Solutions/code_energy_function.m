%% code_energy_function.m
% Energy computation function.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:energy_function
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function E_total = computeTotalEnergy(u, X, Y, F_active, E_young, nu, h, dx, dy)
    % Compute total energy of the morphing membrane
    % Inputs:
    %   u - Vectorised displacement field
    %   X, Y - Coordinate meshgrids
    %   F_active - Active forcing field
    %   E_young - Young's modulus
    %   nu - Poisson's ratio
    %   h - Thickness
    %   dx, dy - Grid spacing
    % Output:
    %   E_total - Total energy (elastic + active)
    
    % Reshape displacement
    [Ny, Nx] = size(X);
    U = reshape(u, Ny, Nx);
    
    % Compute strain components using central differences
    [dU_dx, dU_dy] = computeGradients(U, dx, dy);
    
    % Elastic energy (simplified for small deformations)
    epsilon_xx = dU_dx;
    epsilon_yy = dU_dy;
    
    % Strain energy density
    strainEnergyDensity = 0.5 * E_young * h / (1 - nu^2) * ...
        (epsilon_xx.^2 + epsilon_yy.^2 + 2 * nu * epsilon_xx .* epsilon_yy);
    
    % Integrate elastic energy
    E_elastic = sum(strainEnergyDensity(:)) * dx * dy;
    
    % Active work (negative because actuation does work on system)
    E_active = -sum(F_active(:) .* U(:)) * dx * dy;
    
    % Total energy
    E_total = E_elastic + E_active;
end

function [grad_x, grad_y] = computeGradients(U, dx, dy)
    % Compute gradients using central finite differences
    
    [Ny, Nx] = size(U);
    grad_x = zeros(Ny, Nx);
    grad_y = zeros(Ny, Nx);
    
    % Interior points: central differences
    grad_x(:, 2:end-1) = (U(:, 3:end) - U(:, 1:end-2)) / (2 * dx);
    grad_y(2:end-1, :) = (U(3:end, :) - U(1:end-2, :)) / (2 * dy);
    
    % Boundary points: forward/backward differences
    grad_x(:, 1) = (U(:, 2) - U(:, 1)) / dx;
    grad_x(:, end) = (U(:, end) - U(:, end-1)) / dx;
    grad_y(1, :) = (U(2, :) - U(1, :)) / dy;
    grad_y(end, :) = (U(end, :) - U(end-1, :)) / dy;
end
