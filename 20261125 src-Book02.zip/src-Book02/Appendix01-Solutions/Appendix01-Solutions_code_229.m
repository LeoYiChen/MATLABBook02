%% Appendix01-Solutions_code_229.m
% Problem 11: Human-in-the-Loop Bayesian Optimization for Photocatalyst Discovery
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% ========================================================================
%% Problem 11: Human-in-the-Loop Bayesian Optimization 
%%             for Photocatalyst Discovery
%% ========================================================================
% Scientific Goal:
%   Simulate a closed-loop BO workflow where human expert feedback is
%   dynamically integrated to guide the search for optimal photocatalysts.
%   The algorithm proposes batches of candidate molecules (encoded by
%   molecular descriptors), and the human provides three types of feedback:
%     (1) Acceptance/rejection based on synthetic feasibility
%     (2) Priority scoring (1-5) based on chemical intuition
%     (3) Constraint enforcement (e.g., avoid toxic moieties, Ea < 70 kJ/mol)
%
% Approach:
%   - Virtual library: 200 candidate photocatalysts (simplified CNP-like)
%   - Molecular descriptors: 8 features (Ea, LogP, HOMO, LUMO, MW, Steric, 
%                                        SolvPol, OscStrength)
%   - Objective: Maximize photocatalytic yield (ground truth = nonlinear
%                function of descriptors + noise)
%   - BO with GP surrogate model + UCB acquisition function
%   - HITL: Human simulator accepts/rejects based on rules, assigns priorities
%   - Adaptive sampling: Weight acquisition scores by human priority
%
% Demonstrates: Active learning, preference elicitation, constraint handling
%% ------------------------------------

clear; clc; close all;
rng(42); % Reproducibility

fprintf('========================================\n');
fprintf('Problem 11: Human-in-the-Loop Bayesian Optimization\n');
fprintf('========================================\n\n');

%% Step 1: Generate Virtual Library of Photocatalysts
fprintf('Step 1: Generating virtual library of 200 photocatalysts...\n\n');

numCandidates = 200;
numFeatures = 8;

% Feature names
featureNames = {'Ea (kJ/mol)', 'LogP', 'HOMO (eV)', 'LUMO (eV)', ...
                'MW (g/mol)', 'Steric', 'SolvPol', 'OscStr'};

% Generate random molecular descriptors (realistic ranges)
descriptors = zeros(numCandidates, numFeatures);
descriptors(:, 1) = 40 + 40*rand(numCandidates, 1);      % Ea: 40-80 kJ/mol
descriptors(:, 2) = -1 + 7*rand(numCandidates, 1);       % LogP: -1 to 6
descriptors(:, 3) = -6.5 - 1.5*rand(numCandidates, 1);   % HOMO: -8 to -6.5 eV
descriptors(:, 4) = -3.5 - 1.5*rand(numCandidates, 1);   % LUMO: -5 to -3.5 eV
descriptors(:, 5) = 200 + 300*rand(numCandidates, 1);    % MW: 200-500 g/mol
descriptors(:, 6) = rand(numCandidates, 1);              % Steric: 0-1
descriptors(:, 7) = rand(numCandidates, 1);              % SolvPol: 0-1
descriptors(:, 8) = 0.1 + 0.9*rand(numCandidates, 1);    % OscStr: 0.1-1.0

% Ground truth yield function (unknown to algorithm, known to us for simulation)
% High yield favours: low Ea, moderate LogP (~2.5), high LUMO-HOMO gap, 
% low MW, low steric, high SolvPol, high OscStr
yieldGroundTruth = @(X) max(0, min(100, ...
    50 ...
    - 0.5 * (X(:,1) - 50) ...              % Ea penalty (optimal ~50)
    - 3 * abs(X(:,2) - 2.5) ...            % LogP penalty (optimal 2.5)
    + 8 * (X(:,3) - X(:,4)) ...            % HOMO-LUMO gap bonus
    - 0.05 * (X(:,5) - 300) ...            % MW penalty (optimal 300)
    - 15 * X(:,6) ...                      % Steric penalty
    + 20 * X(:,7) ...                      % SolvPol bonus
    + 10 * X(:,8) ...                      % OscStr bonus
    + 10 * randn(size(X,1), 1) ...         % Experimental noise (std=10%)
));

trueYields = yieldGroundTruth(descriptors);

fprintf('  Virtual library created:\n');
fprintf('    - %d candidate photocatalysts\n', numCandidates);
fprintf('    - %d molecular descriptors per molecule\n', numFeatures);
fprintf('    - True yield range: %.1f%% to %.1f%%\n\n', min(trueYields), max(trueYields));

%% Step 2: Initialize BO with Diverse Initial Samples (Kennard-Stone)
fprintf('Step 2: Selecting initial diverse samples (Kennard-Stone)...\n\n');

numInitial = 10;
% Kennard-Stone algorithm: select maximally diverse samples
XNorm = (descriptors - mean(descriptors)) ./ std(descriptors);
selectedIdx = zeros(numInitial, 1);
selectedIdx(1) = randi(numCandidates); % Random first point
remainingIdx = setdiff(1:numCandidates, selectedIdx(1));

for i = 2:numInitial
    % Find point farthest from all selected points
    minDist = inf(length(remainingIdx), 1);
    for j = 1:length(selectedIdx(1:i-1))
        dist = sqrt(sum((XNorm(remainingIdx, :) - XNorm(selectedIdx(j), :)).^2, 2));
        minDist = min(minDist, dist);
    end
    [~, maxIdx] = max(minDist);
    selectedIdx(i) = remainingIdx(maxIdx);
    remainingIdx(maxIdx) = [];
end

XTrain = descriptors(selectedIdx, :);
yTrain = trueYields(selectedIdx);

fprintf('  Initial %d samples selected (Kennard-Stone diversity)\n', numInitial);
fprintf('  Initial yield range: %.1f%% to %.1f%%\n\n', min(yTrain), max(yTrain));

%% Step 3: Human-in-the-Loop BO Iterations
fprintf('Step 3: Starting Human-in-the-Loop BO iterations...\n\n');

numIterations = 15;
batchSize = 8; % Algorithm proposes 8 candidates per iteration
humanSelectSize = 5; % Human selects 5 from 8 proposed

% Storage for optimization history
iterHistory = struct('iteration', {}, 'proposed', {}, 'humanSelected', {}, ...
                     'yields', {}, 'maxYield', {}, 'humanFeedback', {});

% Hyperparameters for GP
sigma0 = 5.0;  % Initial noise std
sigmaF = 15.0; % Signal variance
lengthScale = ones(1, numFeatures); % ARD length scales

for iter = 1:numIterations
    fprintf('  -- Iteration %d/%d --\n', iter, numIterations);
    
    % Step 3a: Train GP surrogate model on current data
    % Normalize features
    muX = mean(XTrain);
    stdX = std(XTrain);
    stdX(stdX == 0) = 1; % Avoid division by zero
    XTrainNorm = (XTrain - muX) ./ stdX;
    
    % Kernel: Squared Exponential (RBF) with ARD
    K = @(X1, X2) sigmaF^2 * exp(-0.5 * sum(((X1 - X2) ./ lengthScale).^2));
    
    % Build covariance matrix
    n = size(XTrainNorm, 1);
    Ktrain = zeros(n, n);
    for i = 1:n
        for j = i:n
            Ktrain(i,j) = K(XTrainNorm(i,:), XTrainNorm(j,:));
            Ktrain(j,i) = Ktrain(i,j);
        end
    end
    Ktrain = Ktrain + sigma0^2 * eye(n); % Add noise
    
    % Precompute Cholesky decomposition for predictions
    LTrain = chol(Ktrain, 'lower');
    alpha = LTrain' \ (LTrain \ yTrain);
    
    % Step 3b: Predict for all unselected candidates
    unselectedIdx = setdiff(1:numCandidates, selectedIdx);
    XUnselected = descriptors(unselectedIdx, :);
    XUnselectedNorm = (XUnselected - muX) ./ stdX;
    
    nTest = size(XUnselectedNorm, 1);
    muPred = zeros(nTest, 1);
    sigmaPred = zeros(nTest, 1);
    
    for i = 1:nTest
        % Covariance between test point and training points
        kStar = zeros(n, 1);
        for j = 1:n
            kStar(j) = K(XUnselectedNorm(i,:), XTrainNorm(j,:));
        end
        
        % Predictive mean and variance
        muPred(i) = kStar' * alpha;
        vTmp = LTrain \ kStar;
        sigmaPred(i) = sqrt(max(0, sigmaF^2 - vTmp' * vTmp + sigma0^2));
    end
    
    % Step 3c: Compute UCB acquisition scores
    beta = 2.0 + 0.1 * iter; % Increasing exploration over iterations
    ucbScores = muPred + beta * sigmaPred;
    
    % Step 3d: Propose top batchSize candidates
    [~, sortedIdx] = sort(ucbScores, 'descend');
    proposedLocalIdx = sortedIdx(1:batchSize);
    proposedGlobalIdx = unselectedIdx(proposedLocalIdx);
    proposedDescriptors = descriptors(proposedGlobalIdx, :);
    
    fprintf('    Algorithm proposed %d candidates (UCB acquisition)\n', batchSize);
    
    % Step 3e: Simulate Human Feedback
    % Human evaluates each proposed molecule based on:
    %   (1) Synthetic feasibility (reject if Ea > 75 or MW > 450)
    %   (2) Chemical intuition priority (1-5 scale based on descriptor values)
    %   (3) Safety constraints (reject if LogP < -0.5, toxic-like)
    
    humanAccept = true(batchSize, 1);
    humanPriority = zeros(batchSize, 1);
    
    for i = 1:batchSize
        desc = proposedDescriptors(i, :);
        
        % Rule 1: Reject high Ea (hard to synthesize)
        if desc(1) > 75
            humanAccept(i) = false;
        end
        
        % Rule 2: Reject high MW (difficult purification)
        if desc(5) > 450
            humanAccept(i) = false;
        end
        
        % Rule 3: Reject very hydrophilic compounds (poor cell permeability)
        if desc(2) < -0.5
            humanAccept(i) = false;
        end
        
        % Priority scoring (1-5, higher = more interesting)
        if humanAccept(i)
            % Favour: low Ea, moderate LogP, high LUMO-LUMO gap, high SolvPol
            priority = 1; % Baseline
            if desc(1) < 55, priority = priority + 1; end % Low Ea
            if abs(desc(2) - 2.5) < 1.5, priority = priority + 1; end % Good LogP
            if (desc(3) - desc(4)) > 2.5, priority = priority + 1; end % Large gap
            if desc(7) > 0.6, priority = priority + 1; end % High SolvPol
            humanPriority(i) = min(5, priority);
        end
    end
    
    fprintf('    Human feedback: %d/%d accepted, priority range [%d, %d]\n', ...
            sum(humanAccept), batchSize, min(humanPriority(humanAccept)), ...
            max(humanPriority(humanAccept)));
    
    % Step 3f: Human selects top humanSelectSize from accepted candidates
    acceptedLocalIdx = find(humanAccept);
    if length(acceptedLocalIdx) < humanSelectSize
        % If too many rejections, fill with next-best from algorithm
        fprintf('    Warning: Only %d accepted, adding %d from algorithm\n', ...
                length(acceptedLocalIdx), humanSelectSize - length(acceptedLocalIdx));
        rejectedLocalIdx = find(~humanAccept);
        additionalIdx = rejectedLocalIdx(1:min(length(rejectedLocalIdx), ...
                                               humanSelectSize - length(acceptedLocalIdx)));
        acceptedLocalIdx = [acceptedLocalIdx; additionalIdx];
        humanAccept(additionalIdx) = true; % Override rejection
        humanPriority(additionalIdx) = 1; % Low priority
    end
    
    % Sort accepted by priority, select top humanSelectSize
    [~, prioritySort] = sort(humanPriority(acceptedLocalIdx), 'descend');
    selectedLocalIdx = acceptedLocalIdx(prioritySort(1:humanSelectSize));
    selectedGlobalIdx = proposedGlobalIdx(selectedLocalIdx);
    
    % Measure true yields for selected molecules
    selectedYields = trueYields(selectedGlobalIdx);
    
    fprintf('    Human selected %d molecules, yields: [%.1f%%, ..., %.1f%%]\n', ...
            humanSelectSize, min(selectedYields), max(selectedYields));
    fprintf('    Best yield this iteration: %.1f%%\n', max(selectedYields));
    
    % Step 3g: Update training data
    XTrain = [XTrain; descriptors(selectedGlobalIdx, :)];
    yTrain = [yTrain; selectedYields];
    selectedIdx = [selectedIdx; selectedGlobalIdx];
    
    % Store iteration history
    iterHistory(iter).iteration = iter;
    iterHistory(iter).proposed = proposedGlobalIdx;
    iterHistory(iter).humanSelected = selectedGlobalIdx;
    iterHistory(iter).yields = selectedYields;
    iterHistory(iter).maxYield = max(yTrain);
    iterHistory(iter).humanFeedback = struct('accept', humanAccept, ...
                                             'priority', humanPriority);
    
    fprintf('    Cumulative best yield: %.1f%% (%d samples evaluated)\n\n', ...
            max(yTrain), length(yTrain));
end

fprintf('  BO completed: %d iterations, %d total samples evaluated\n\n', ...
        numIterations, length(yTrain));

%% Step 4: Baseline Comparison - Random Sampling
fprintf('Step 4: Baseline comparison with random sampling...\n\n');

numRandom = length(yTrain); % Same number as BO
randomIdx = randperm(numCandidates, numRandom);
yRandom = trueYields(randomIdx);

fprintf('  Random sampling: %d molecules, best yield = %.1f%%\n\n', ...
        numRandom, max(yRandom));

%% Step 5: Baseline Comparison - Pure BO (No Human Feedback)
fprintf('Step 5: Baseline comparison with pure BO (no human)...\n\n');

% Reset to initial samples
XTrainPure = descriptors(selectedIdx(1:numInitial), :);
yTrainPure = trueYields(selectedIdx(1:numInitial));
selectedIdxPure = selectedIdx(1:numInitial);

for iter = 1:numIterations
    % Train GP (same as HITL)
    muX = mean(XTrainPure);
    stdX = std(XTrainPure);
    stdX(stdX == 0) = 1;
    XTrainNorm = (XTrainPure - muX) ./ stdX;
    
    n = size(XTrainNorm, 1);
    Ktrain = zeros(n, n);
    for i = 1:n
        for j = i:n
            Ktrain(i,j) = sigmaF^2 * exp(-0.5 * sum(((XTrainNorm(i,:) - ...
                          XTrainNorm(j,:)) ./ lengthScale).^2));
            Ktrain(j,i) = Ktrain(i,j);
        end
    end
    Ktrain = Ktrain + sigma0^2 * eye(n);
    LTrain = chol(Ktrain, 'lower');
    alpha = LTrain' \ (LTrain \ yTrainPure);
    
    % Predict for unselected
    unselectedIdx = setdiff(1:numCandidates, selectedIdxPure);
    XUnselected = descriptors(unselectedIdx, :);
    XUnselectedNorm = (XUnselected - muX) ./ stdX;
    nTest = size(XUnselectedNorm, 1);
    muPred = zeros(nTest, 1);
    sigmaPred = zeros(nTest, 1);
    
    for i = 1:nTest
        kStar = zeros(n, 1);
        for j = 1:n
            kStar(j) = sigmaF^2 * exp(-0.5 * sum(((XUnselectedNorm(i,:) - ...
                        XTrainNorm(j,:)) ./ lengthScale).^2));
        end
        muPred(i) = kStar' * alpha;
        vTmp = LTrain \ kStar;
        sigmaPred(i) = sqrt(max(0, sigmaF^2 - vTmp' * vTmp + sigma0^2));
    end
    
    beta = 2.0 + 0.1 * iter;
    ucbScores = muPred + beta * sigmaPred;
    
    % Select top humanSelectSize (no human filtering)
    [~, sortedIdx] = sort(ucbScores, 'descend');
    selectedLocalIdx = sortedIdx(1:humanSelectSize);
    selectedGlobalIdx = unselectedIdx(selectedLocalIdx);
    
    % Measure yields
    selectedYields = trueYields(selectedGlobalIdx);
    XTrainPure = [XTrainPure; descriptors(selectedGlobalIdx, :)];
    yTrainPure = [yTrainPure; selectedYields];
    selectedIdxPure = [selectedIdxPure; selectedGlobalIdx];
end

fprintf('  Pure BO (no human): %d samples, best yield = %.1f%%\n\n', ...
        length(yTrainPure), max(yTrainPure));

%% Step 6: Analysis and Visualisation
fprintf('Step 6: Analysing and visualising results...\n\n');

% Best molecules found by each method
[bestYieldHITL, bestIdxHITL] = max(yTrain);
[bestYieldPure, bestIdxPure] = max(yTrainPure);
[bestYieldRandom, bestIdxRandom] = max(yRandom);
[bestYieldTrue, bestIdxTrue] = max(trueYields);

bestMolHITL = selectedIdx(bestIdxHITL);
bestMolPure = selectedIdxPure(bestIdxPure);
bestMolRandom = randomIdx(bestIdxRandom);

fprintf('  Best molecules found:\n');
fprintf('    - HITL BO:  Molecule %d, Yield = %.1f%%\n', bestMolHITL, bestYieldHITL);
fprintf('    - Pure BO:  Molecule %d, Yield = %.1f%%\n', bestMolPure, bestYieldPure);
fprintf('    - Random:   Molecule %d, Yield = %.1f%%\n', bestMolRandom, bestYieldRandom);
fprintf('    - True Opt: Molecule %d, Yield = %.1f%%\n\n', bestIdxTrue, bestYieldTrue);

% Convergence plots
figure('Name', 'HITL BO Convergence', 'Position', [100, 100, 1400, 500]);

subplot(1, 3, 1);
iterNums = 0:numIterations;
maxYieldHITL = [max(yTrain(1:numInitial)); arrayfun(@(i) iterHistory(i).maxYield, 1:numIterations)'];
maxYieldPure = zeros(numIterations+1, 1);
maxYieldPure(1) = max(yTrainPure(1:numInitial));
for i = 1:numIterations
    maxYieldPure(i+1) = max(yTrainPure(1:numInitial + i*humanSelectSize));
end

plot(iterNums, maxYieldHITL, '-o', 'LineWidth', 2, 'MarkerSize', 8, ...
     'Color', [0.2, 0.6, 0.8], 'DisplayName', 'HITL BO');
hold on;
plot(iterNums, maxYieldPure, '-s', 'LineWidth', 2, 'MarkerSize', 8, ...
     'Color', [0.9, 0.4, 0.2], 'DisplayName', 'Pure BO');
yline(bestYieldRandom, '-', 'LineWidth', 2, 'Color', [0.5, 0.5, 0.5], ...
      'DisplayName', 'Random Best');
yline(bestYieldTrue, '-.', 'LineWidth', 2, 'Color', [0.3, 0.7, 0.3], ...
      'DisplayName', 'True Optimum');
hold off;
xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Best Yield (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('Optimization Convergence', 'Interpreter', 'latex', 'FontSize', 14);
legend('Location', 'southeast', 'Interpreter', 'latex');
grid on;

subplot(1, 3, 2);
cumSamplesHITL = numInitial + (0:numIterations) * humanSelectSize;
cumSamplesPure = numInitial + (0:numIterations) * humanSelectSize;
plot(cumSamplesHITL, maxYieldHITL, '-o', 'LineWidth', 2, 'MarkerSize', 8, ...
     'Color', [0.2, 0.6, 0.8], 'DisplayName', 'HITL BO');
hold on;
plot(cumSamplesPure, maxYieldPure, '-s', 'LineWidth', 2, 'MarkerSize', 8, ...
     'Color', [0.9, 0.4, 0.2], 'DisplayName', 'Pure BO');
yline(bestYieldRandom, '-', 'LineWidth', 2, 'Color', [0.5, 0.5, 0.5], ...
      'DisplayName', 'Random Best');
hold off;
xlabel('Number of Samples Evaluated', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Best Yield (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('Sample Efficiency', 'Interpreter', 'latex', 'FontSize', 14);
legend('Location', 'southeast', 'Interpreter', 'latex');
grid on;

subplot(1, 3, 3);
humanAcceptRate = zeros(numIterations, 1);
humanAvgPriority = zeros(numIterations, 1);
for i = 1:numIterations
    humanAcceptRate(i) = sum(iterHistory(i).humanFeedback.accept) / batchSize * 100;
    acceptedPriorities = iterHistory(i).humanFeedback.priority(...
                         iterHistory(i).humanFeedback.accept);
    humanAvgPriority(i) = mean(acceptedPriorities);
end

yyaxis left;
plot(1:numIterations, humanAcceptRate, '-o', 'LineWidth', 2, 'MarkerSize', 8);
ylabel('Acceptance Rate (\%)', 'Interpreter', 'latex', 'FontSize', 13);
ylim([0, 100]);

yyaxis right;
plot(1:numIterations, humanAvgPriority, '-s', 'LineWidth', 2, 'MarkerSize', 8);
ylabel('Average Priority (1-5)', 'Interpreter', 'latex', 'FontSize', 13);
ylim([1, 5]);

xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 13);
title('Human Feedback Dynamics', 'Interpreter', 'latex', 'FontSize', 14);
grid on;

saveas(gcf, 'Problem11_HITL_Convergence.fig');
saveas(gcf, 'Problem11_HITL_Convergence.eps', 'epsc');
saveas(gcf, 'Problem11_HITL_Convergence.jpg');

fprintf('  Convergence plots saved\n\n');

% Feature importance analysis (which descriptors correlate with high yields)
figure('Name', 'Feature Importance', 'Position', [100, 100, 1200, 600]);

for i = 1:numFeatures
    subplot(2, 4, i);
    scatter(XTrain(:, i), yTrain, 50, yTrain, 'filled', 'MarkerEdgeColor', 'k');
    colormap('hot');
    xlabel(featureNames{i}, 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Yield (\%)', 'Interpreter', 'latex', 'FontSize', 11);
    title(sprintf('Correlation: %.2f', corr(XTrain(:,i), yTrain)), ...
          'Interpreter', 'latex', 'FontSize', 12);
    grid on;
end

saveas(gcf, 'Problem11_FeatureImportance.fig');
saveas(gcf, 'Problem11_FeatureImportance.eps', 'epsc');
saveas(gcf, 'Problem11_FeatureImportance.jpg');

fprintf('  Feature importance plots saved\n\n');

%% Summary
fprintf('========================================\n');
fprintf('Problem 11 Complete: Summary\n');
fprintf('========================================\n\n');

fprintf('Optimization Results:\n');
fprintf('  HITL BO:    %.1f%% yield (Molecule %d) after %d samples\n', ...
        bestYieldHITL, bestMolHITL, length(yTrain));
fprintf('  Pure BO:    %.1f%% yield (Molecule %d) after %d samples\n', ...
        bestYieldPure, bestMolPure, length(yTrainPure));
fprintf('  Random:     %.1f%% yield (Molecule %d) after %d samples\n', ...
        bestYieldRandom, bestMolRandom, numRandom);
fprintf('  True Opt:   %.1f%% yield (Molecule %d)\n\n', bestYieldTrue, bestIdxTrue);

fprintf('Human Feedback Statistics:\n');
fprintf('  Average acceptance rate: %.1f%% (%d/%d proposed)\n', ...
        mean(humanAcceptRate), round(mean(humanAcceptRate)/100*batchSize), batchSize);
fprintf('  Average priority score:  %.2f / 5.0\n', mean(humanAvgPriority));
fprintf('  Constraint violations prevented: %d molecules rejected\n\n', ...
        sum(arrayfun(@(i) sum(~iterHistory(i).humanFeedback.accept), 1:numIterations)));

fprintf('Key Insights:\n');
fprintf('  - HITL BO achieves %.1f%% higher yield than random sampling\n', ...
        bestYieldHITL - bestYieldRandom);
fprintf('  - HITL BO reaches %.1f%% of true optimum vs. %.1f%% for pure BO\n', ...
        bestYieldHITL/bestYieldTrue*100, bestYieldPure/bestYieldTrue*100);
fprintf('  - Human constraints prevent %d unsafe/impractical syntheses\n', ...
        sum(arrayfun(@(i) sum(~iterHistory(i).humanFeedback.accept), 1:numIterations)));
fprintf('  - Average %.1f iterations to reach 90%% of optimum\n', ...
        find(maxYieldHITL > 0.9*bestYieldTrue, 1));
fprintf('  - Sample efficiency: HITL %.1f samples/%%yield vs. Random %.1f\n\n', ...
        length(yTrain)/bestYieldHITL, numRandom/bestYieldRandom);

fprintf('Figures saved:\n');
fprintf('  - Problem11_HITL_Convergence (.fig, .eps, .jpg)\n');
fprintf('  - Problem11_FeatureImportance (.fig, .eps, .jpg)\n\n');

fprintf('========================================\n');
