%% Appendix02-FAQs_code_036.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLAB Code for Local Magnification of 2D Plots

% Add magnify.m to MATLAB search path or current working directory
% After completing the basic drawing, enter the following two lines of code
magnify(gcf);

% Example usage with a simple 2D plot
clc;
clear;
close all;

% Data
x = linspace(-0.1*pi, 2*pi, 30);
y = cell(1, 3);
y{1, 1} = 0.4 * sinc(x) + 0.8;
y{1, 2} = tanh(x);
y{1, 3} = exp(-sinc(x));

% Main axes
figure;
color_ = [0, 114, 189; 126, 47, 142; 162, 20, 47] / 255;
axes1 = axes('Units', 'normalized');
hold(axes1, 'on');
box(axes1, 'on');
set(axes1, 'LineWidth', 1.2, 'TickDir', 'in');
for i = 1:3
    plot(x, y{1, i}, 'Parent', axes1, 'Color', color_(i, :), 'LineWidth', 3);
end
legend(axes1, 'line-1', 'line-2', 'line-3');

% Enable magnification
magnify(gcf);
