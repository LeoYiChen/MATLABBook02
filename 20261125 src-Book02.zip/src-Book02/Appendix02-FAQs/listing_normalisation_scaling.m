%% listing_normalisation_scaling.m
% Advanced feature scaling and normalisation framework with multiple methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : listing_normalisation_scaling
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [scaled_data, scaling_params, scaling_stats] = scaleFeatures(data, method, options)
% scaleFeatures - Comprehensive feature scaling and normalisation
%
% Syntax: [scaled_data, params, stats] = scaleFeatures(data, method, options)
%
% Inputs:
%   data    - Input data matrix (rows: observations, columns: features)
%   method  - Scaling method: 'minmax', 'zscore', 'robust', 'unit', 'quantile', 'power'
%   options - Structure with method-specific parameters
%
% Outputs:
%   scaled_data    - Scaled feature matrix
%   scaling_params - Parameters for applying same scaling to new data
%   scaling_stats  - Statistics about the scaling transformation

    % Input validation and default parameters
    if nargin < 2, method = 'zscore'; end
    if nargin < 3, options = struct(); end
    
    % Set default options
    if ~isfield(options, 'robust_outliers'), options.robust_outliers = false; end
    if ~isfield(options, 'handle_zeros'), options.handle_zeros = true; end
    if ~isfield(options, 'preserve_sparsity'), options.preserve_sparsity = false; end
    if ~isfield(options, 'feature_range'), options.feature_range = [0, 1]; end
    if ~isfield(options, 'copy_data'), options.copy_data = true; end
    
    % Initialise outputs
    if options.copy_data
        scaled_data = data;
    else
        scaled_data = data; % Still create copy to avoid modifying input
    end
    
    [n_samples, n_features] = size(data);
    scaling_params = struct();
    scaling_params.method = method;
    scaling_params.feature_count = n_features;
    scaling_params.sample_count = n_samples;
    
    scaling_stats = struct();
    scaling_stats.original_ranges = [min(data, [], 1); max(data, [], 1)];
    scaling_stats.original_means = mean(data, 1, 'omitnan');
    scaling_stats.original_stds = std(data, 0, 1, 'omitnan');
    scaling_stats.processing_time = tic;
    
    % Apply selected scaling method
    switch lower(method)
        case 'minmax'
            [scaled_data, scaling_params] = applyMinMaxScaling(scaled_data, scaling_params, options);
            
        case 'zscore'
            [scaled_data, scaling_params] = applyZScoreScaling(scaled_data, scaling_params, options);
            
        case 'robust'
            [scaled_data, scaling_params] = applyRobustScaling(scaled_data, scaling_params, options);
            
        case 'unit'
            [scaled_data, scaling_params] = applyUnitVectorScaling(scaled_data, scaling_params, options);
            
        case 'quantile'
            [scaled_data, scaling_params] = applyQuantileScaling(scaled_data, scaling_params, options);
            
        case 'power'
            [scaled_data, scaling_params] = applyPowerTransformation(scaled_data, scaling_params, options);
            
        case 'maxabs'
            [scaled_data, scaling_params] = applyMaxAbsScaling(scaled_data, scaling_params, options);
            
        otherwise
            error('Unknown scaling method: %s', method);
    end
    
    % Calculate post-scaling statistics
    scaling_stats.scaled_ranges = [min(scaled_data, [], 1); max(scaled_data, [], 1)];
    scaling_stats.scaled_means = mean(scaled_data, 1, 'omitnan');
    scaling_stats.scaled_stds = std(scaled_data, 0, 1, 'omitnan');
    scaling_stats.processing_time = toc(scaling_stats.processing_time);
    scaling_stats.transformation_quality = assessTransformationQuality(data, scaled_data, method);
end

function [scaled_data, params] = applyMinMaxScaling(data, params, options)
% Apply min-max scaling to specified range
    
    % Calculate scaling parameters
    data_min = min(data, [], 1);
    data_max = max(data, [], 1);
    data_range = data_max - data_min;
    
    % Handle zero ranges (constant features)
    zero_range_mask = (data_range == 0);
    if any(zero_range_mask)
        warning('Constant features detected in min-max scaling. Setting range to 1.');
        data_range(zero_range_mask) = 1;
    end
    
    % Calculate target range
    target_min = options.feature_range(1);
    target_max = options.feature_range(2);
    target_range = target_max - target_min;
    
    % Apply scaling transformation
    scaled_data = ((data - data_min) ./ data_range) * target_range + target_min;
    
    % Handle constant features
    if any(zero_range_mask)
        scaled_data(:, zero_range_mask) = target_min;
    end
    
    % Store parameters for inverse transformation
    params.data_min = data_min;
    params.data_max = data_max;
    params.data_range = data_range;
    params.target_min = target_min;
    params.target_max = target_max;
    params.target_range = target_range;
    params.zero_range_features = find(zero_range_mask);
end

function [scaled_data, params] = applyZScoreScaling(data, params, options)
% Apply z-score standardisation (zero mean, unit variance)
    
    if options.robust_outliers
        % Use median and MAD for robust scaling
        data_center = median(data, 1, 'omitnan');
        data_scale = mad(data, 1, 1); % Median absolute deviation
        data_scale(data_scale == 0) = 1; % Handle zero MAD
    else
        % Use mean and standard deviation
        data_center = mean(data, 1, 'omitnan');
        data_scale = std(data, 0, 1, 'omitnan');
        data_scale(data_scale == 0) = 1; % Handle zero standard deviation
    end
    
    % Apply scaling transformation
    scaled_data = (data - data_center) ./ data_scale;
    
    % Store parameters for inverse transformation
    params.data_center = data_center;
    params.data_scale = data_scale;
    params.robust_mode = options.robust_outliers;
end

function [scaled_data, params] = applyRobustScaling(data, params, options)
% Apply robust scaling using median and interquartile range
    
    % Calculate robust statistics
    data_median = median(data, 1, 'omitnan');
    data_q25 = prctile(data, 25, 1);
    data_q75 = prctile(data, 75, 1);
    data_iqr = data_q75 - data_q25;
    
    % Handle zero IQR (constant features)
    zero_iqr_mask = (data_iqr == 0);
    if any(zero_iqr_mask)
        warning('Constant features detected in robust scaling. Using MAD as fallback.');
        data_iqr(zero_iqr_mask) = mad(data(:, zero_iqr_mask), 1, 1);
        data_iqr(data_iqr == 0) = 1; % Final fallback
    end
    
    % Apply scaling transformation
    scaled_data = (data - data_median) ./ data_iqr;
    
    % Store parameters for inverse transformation
    params.data_median = data_median;
    params.data_q25 = data_q25;
    params.data_q75 = data_q75;
    params.data_iqr = data_iqr;
    params.zero_iqr_features = find(zero_iqr_mask);
end

function [scaled_data, params] = applyUnitVectorScaling(data, params, options)
% Apply unit vector scaling (L2 normalisation)
    
    % Calculate L2 norms for each sample
    if options.preserve_sparsity
        % Preserve sparse structure if applicable
        data_norms = sqrt(sum(data.^2, 2));
    else
        data_norms = vecnorm(data, 2, 2);
    end
    
    % Handle zero norms
    zero_norm_mask = (data_norms == 0);
    data_norms(zero_norm_mask) = 1;
    
    % Apply scaling transformation
    scaled_data = data ./ data_norms;
    
    % Handle zero norm samples
    if any(zero_norm_mask)
        scaled_data(zero_norm_mask, :) = 0;
    end
    
    % Store parameters
    params.scaling_type = 'unit_vector';
    params.zero_norm_samples = find(zero_norm_mask);
end

function [scaled_data, params] = applyQuantileScaling(data, params, options)
% Apply quantile uniform transformation
    
    if ~isfield(options, 'n_quantiles')
        options.n_quantiles = min(1000, size(data, 1));
    end
    
    [n_samples, n_features] = size(data);
    scaled_data = zeros(size(data));
    quantiles = cell(n_features, 1);
    
    for feature_idx = 1:n_features
        feature_data = data(:, feature_idx);
        
        % Remove NaN values for quantile calculation
        valid_data = feature_data(~isnan(feature_data));
        
        if length(valid_data) > 1
            % Calculate quantiles
            quantile_values = quantile(valid_data, linspace(0, 1, options.n_quantiles));
            quantiles{feature_idx} = quantile_values;
            
            % Transform data to uniform distribution
            scaled_feature = zeros(size(feature_data));
            for i = 1:length(feature_data)
                if ~isnan(feature_data(i))
                    % Find position in quantile distribution
                    rank_position = sum(quantile_values <= feature_data(i)) / length(quantile_values);
                    scaled_feature(i) = rank_position;
                else
                    scaled_feature(i) = NaN;
                end
            end
            
            scaled_data(:, feature_idx) = scaled_feature;
        else
            scaled_data(:, feature_idx) = feature_data;
            quantiles{feature_idx} = [];
        end
    end
    
    % Store parameters
    params.quantiles = quantiles;
    params.n_quantiles = options.n_quantiles;
end

function [scaled_data, params] = applyPowerTransformation(data, params, options)
% Apply Box-Cox power transformation
    
    if ~isfield(options, 'lambda_search')
        options.lambda_search = 'auto';
    end
    
    [n_samples, n_features] = size(data);
    scaled_data = zeros(size(data));
    lambda_values = zeros(n_features, 1);
    
    for feature_idx = 1:n_features
        feature_data = data(:, feature_idx);
        
        % Box-Cox requires positive values
        if any(feature_data <= 0)
            % Apply Yeo-Johnson transformation for data with non-positive values
            [transformed_feature, optimal_lambda] = applyYeoJohnsonTransform(feature_data, options);
        else
            % Apply Box-Cox transformation
            [transformed_feature, optimal_lambda] = applyBoxCoxTransform(feature_data, options);
        end
        
        scaled_data(:, feature_idx) = transformed_feature;
        lambda_values(feature_idx) = optimal_lambda;
    end
    
    % Store parameters
    params.lambda_values = lambda_values;
    params.transformation_type = 'power';
end

function [transformed_data, optimal_lambda] = applyBoxCoxTransform(data, options)
% Apply Box-Cox transformation to positive data
    
    % Remove NaN and non-positive values for lambda estimation
    valid_data = data(~isnan(data) & data > 0);
    
    if length(valid_data) < 10
        % Insufficient data for transformation
        transformed_data = data;
        optimal_lambda = 1;
        return;
    end
    
    % Search for optimal lambda
    if strcmp(options.lambda_search, 'auto')
        lambda_candidates = linspace(-2, 2, 41);
        best_lambda = 1;
        best_score = -inf;
        
        for lambda = lambda_candidates
            try
                if lambda == 0
                    transformed = log(valid_data);
                else
                    transformed = (valid_data.^lambda - 1) / lambda;
                end
                
                % Use Shapiro-Wilk test statistic as optimisation criterion
                score = -calculateNormalityScore(transformed);
                
                if score > best_score
                    best_score = score;
                    best_lambda = lambda;
                end
            catch
                continue;
            end
        end
        
        optimal_lambda = best_lambda;
    else
        optimal_lambda = options.lambda_search;
    end
    
    % Apply transformation with optimal lambda
    transformed_data = data;
    valid_mask = ~isnan(data) & data > 0;
    
    if optimal_lambda == 0
        transformed_data(valid_mask) = log(data(valid_mask));
    else
        transformed_data(valid_mask) = (data(valid_mask).^optimal_lambda - 1) / optimal_lambda;
    end
end

function [transformed_data, optimal_lambda] = applyYeoJohnsonTransform(data, options)
% Apply Yeo-Johnson transformation (handles negative values)
    
    % Remove NaN values for lambda estimation
    valid_data = data(~isnan(data));
    
    if length(valid_data) < 10
        transformed_data = data;
        optimal_lambda = 1;
        return;
    end
    
    % Search for optimal lambda
    if strcmp(options.lambda_search, 'auto')
        lambda_candidates = linspace(-2, 2, 41);
        best_lambda = 1;
        best_score = -inf;
        
        for lambda = lambda_candidates
            try
                transformed = applyYeoJohnsonForLambda(valid_data, lambda);
                score = -calculateNormalityScore(transformed);
                
                if score > best_score
                    best_score = score;
                    best_lambda = lambda;
                end
            catch
                continue;
            end
        end
        
        optimal_lambda = best_lambda;
    else
        optimal_lambda = options.lambda_search;
    end
    
    % Apply transformation with optimal lambda
    transformed_data = data;
    valid_mask = ~isnan(data);
    transformed_data(valid_mask) = applyYeoJohnsonForLambda(data(valid_mask), optimal_lambda);
end

function transformed = applyYeoJohnsonForLambda(data, lambda)
% Apply Yeo-Johnson transformation for specific lambda
    
    transformed = zeros(size(data));
    
    % Handle positive values
    pos_mask = data >= 0;
    if any(pos_mask)
        pos_data = data(pos_mask);
        if lambda == 0
            transformed(pos_mask) = log(pos_data + 1);
        else
            transformed(pos_mask) = ((pos_data + 1).^lambda - 1) / lambda;
        end
    end
    
    % Handle negative values
    neg_mask = data < 0;
    if any(neg_mask)
        neg_data = data(neg_mask);
        if lambda == 2
            transformed(neg_mask) = -log(-neg_data + 1);
        else
            transformed(neg_mask) = -((-neg_data + 1).^(2 - lambda) - 1) / (2 - lambda);
        end
    end
end

function score = calculateNormalityScore(data)
% Calculate normality score (lower is more normal)
    
    % Use Anderson-Darling test statistic as normality measure
    data_sorted = sort(data);
    n = length(data);
    
    % Standardise data
    data_mean = mean(data);
    data_std = std(data);
    standardised_data = (data_sorted - data_mean) / data_std;
    
    % Calculate empirical CDF values
    expected_normal = normcdf(standardised_data);
    
    % Anderson-Darling statistic
    i_values = (1:n)';
    ad_stat = -n - (1/n) * sum((2*i_values - 1) .* (log(expected_normal) + log(1 - expected_normal(end:-1:1))));
    
    score = ad_stat;
end

function [scaled_data, params] = applyMaxAbsScaling(data, params, options)
% Apply maximum absolute value scaling
    
    % Calculate maximum absolute values
    data_max_abs = max(abs(data), [], 1);
    
    % Handle zero maximum (constant zero features)
    zero_max_mask = (data_max_abs == 0);
    data_max_abs(zero_max_mask) = 1;
    
    % Apply scaling transformation
    scaled_data = data ./ data_max_abs;
    
    % Store parameters
    params.data_max_abs = data_max_abs;
    params.zero_max_features = find(zero_max_mask);
end

function quality_metrics = assessTransformationQuality(original_data, scaled_data, method)
% Assess quality of scaling transformation
    
    quality_metrics = struct();
    
    % Calculate variance preservation (for z-score)
    if strcmp(method, 'zscore')
        original_vars = var(original_data, 0, 1, 'omitnan');
        scaled_vars = var(scaled_data, 0, 1, 'omitnan');
        quality_metrics.variance_ratio = mean(scaled_vars ./ (original_vars + eps));
    end
    
    % Calculate range preservation (for minmax)
    if strcmp(method, 'minmax')
        original_ranges = max(original_data, [], 1) - min(original_data, [], 1);
        scaled_ranges = max(scaled_data, [], 1) - min(scaled_data, [], 1);
        quality_metrics.range_consistency = mean(abs(scaled_ranges - 1)); % Should be close to 1 for [0,1] scaling
    end
    
    % Calculate correlation preservation
    if size(original_data, 2) > 1
        original_corr = corrcoef(original_data, 'rows', 'complete');
        scaled_corr = corrcoef(scaled_data, 'rows', 'complete');
        
        % Extract upper triangle (excluding diagonal)
        mask = triu(true(size(original_corr)), 1);
        orig_corr_vals = original_corr(mask);
        scaled_corr_vals = scaled_corr(mask);
        
        quality_metrics.correlation_preservation = corr(orig_corr_vals, scaled_corr_vals, 'rows', 'complete');
    end
    
    % Calculate outlier impact
    original_outliers = sum(isoutlier(original_data, 'median'), 1);
    scaled_outliers = sum(isoutlier(scaled_data, 'median'), 1);
    quality_metrics.outlier_impact = mean(abs(scaled_outliers - original_outliers));
    
    % Calculate information preservation (entropy-based)
    quality_metrics.information_preservation = calculateInformationPreservation(original_data, scaled_data);
end

function info_preservation = calculateInformationPreservation(original_data, scaled_data)
% Calculate information preservation using entropy measures
    
    [n_samples, n_features] = size(original_data);
    preservation_scores = zeros(n_features, 1);
    
    for feature_idx = 1:n_features
        orig_feature = original_data(:, feature_idx);
        scaled_feature = scaled_data(:, feature_idx);
        
        % Remove NaN values
        valid_mask = ~isnan(orig_feature) & ~isnan(scaled_feature);
        orig_valid = orig_feature(valid_mask);
        scaled_valid = scaled_feature(valid_mask);
        
        if length(orig_valid) > 10
            % Discretise for entropy calculation
            orig_bins = discretise(orig_valid, min(10, floor(sqrt(length(orig_valid)))));
            scaled_bins = discretise(scaled_valid, min(10, floor(sqrt(length(scaled_valid)))));
            
            % Calculate mutual information
            mutual_info = calculateMutualInformation(orig_bins, scaled_bins);
            
            % Calculate individual entropies
            orig_entropy = calculateEntropy(orig_bins);
            
            % Information preservation as normalised mutual information
            if orig_entropy > 0
                preservation_scores(feature_idx) = mutual_info / orig_entropy;
            else
                preservation_scores(feature_idx) = 1; % Perfect preservation for constant features
            end
        else
            preservation_scores(feature_idx) = 1;
        end
    end
    
    info_preservation = mean(preservation_scores);
end

function entropy = calculateEntropy(data)
% Calculate Shannon entropy of discrete data
    
    [unique_vals, ~, indices] = unique(data);
    counts = accumarray(indices, 1);
    probabilities = counts / sum(counts);
    
    % Calculate entropy
    log_probs = log2(probabilities);
    entropy = -sum(probabilities .* log_probs);
end

function mutual_info = calculateMutualInformation(data1, data2)
% Calculate mutual information between two discrete variables
    
    % Create joint distribution
    [unique_pairs, ~, pair_indices] = unique([data1, data2], 'rows');
    joint_counts = accumarray(pair_indices, 1);
    joint_probs = joint_counts / sum(joint_counts);
    
    % Calculate marginal distributions
    [unique_vals1, ~, indices1] = unique(data1);
    marginal_counts1 = accumarray(indices1, 1);
    marginal_probs1 = marginal_counts1 / sum(marginal_counts1);
    
    [unique_vals2, ~, indices2] = unique(data2);
    marginal_counts2 = accumarray(indices2, 1);
    marginal_probs2 = marginal_counts2 / sum(marginal_counts2);
    
    % Calculate mutual information
    mutual_info = 0;
    for i = 1:length(joint_probs)
        if joint_probs(i) > 0
            pair = unique_pairs(i, :);
            val1_idx = find(unique_vals1 == pair(1));
            val2_idx = find(unique_vals2 == pair(2));
            
            p_joint = joint_probs(i);
            p_marginal1 = marginal_probs1(val1_idx);
            p_marginal2 = marginal_probs2(val2_idx);
            
            mutual_info = mutual_info + p_joint * log2(p_joint / (p_marginal1 * p_marginal2));
        end
    end
end

% Utility function for applying learned scaling to new data
function scaled_new_data = applyLearnedScaling(new_data, scaling_params)
% Apply previously learned scaling parameters to new data
%
% Inputs:
%   new_data      - New data to be scaled
%   scaling_params - Parameters from previous scaling operation
%
% Output:
%   scaled_new_data - New data scaled using learned parameters

    method = scaling_params.method;
    
    switch lower(method)
        case 'minmax'
            scaled_new_data = ((new_data - scaling_params.data_min) ./ scaling_params.data_range) * ...
                             scaling_params.target_range + scaling_params.target_min;
            
            % Handle constant features
            if ~isempty(scaling_params.zero_range_features)
                scaled_new_data(:, scaling_params.zero_range_features) = scaling_params.target_min;
            end
            
        case 'zscore'
            scaled_new_data = (new_data - scaling_params.data_center) ./ scaling_params.data_scale;
            
        case 'robust'
            scaled_new_data = (new_data - scaling_params.data_median) ./ scaling_params.data_iqr;
            
        case 'unit'
            data_norms = vecnorm(new_data, 2, 2);
            data_norms(data_norms == 0) = 1;
            scaled_new_data = new_data ./ data_norms;
            
        case 'maxabs'
            scaled_new_data = new_data ./ scaling_params.data_max_abs;
            
        otherwise
            error('Inverse transformation not implemented for method: %s', method);
    end
end
