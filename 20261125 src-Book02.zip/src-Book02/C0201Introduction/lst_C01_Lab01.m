%% lst_C01_Lab01.m
% Basic MATLAB operations with AI preprocessing context
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C0201Introduction/
% Listing label         : lst:C01_Lab01
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter01_Lab01.m
% Demonstrates basic MATLAB operations whilst preparing data for AI applications
% Author: [Your Name]
% Date: [Date]

%% Generate sample dataset representing sensor readings
time = 0:0.01:5;  % 5 seconds at 100 Hz sampling
signal1 = sin(2*pi*time) + 0.2*randn(size(time));  % Sinusoid with noise
signal2 = cos(2*pi*time) + 0.2*randn(size(time));  % Cosine with noise

%% Data preprocessing - critical step in AI workflows
% Normalisation: (x - mean) / std transforms to zero mean, unit variance
normalized_signal1 = (signal1 - mean(signal1)) / std(signal1);
normalized_signal2 = (signal2 - mean(signal2)) / std(signal2);

%% Feature extraction (simple statistical features)
features = [
    max(normalized_signal1), min(normalized_signal1), std(normalized_signal1);
    max(normalized_signal2), min(normalized_signal2), std(normalized_signal2)
];

%% Visualise the data
figure('Name', 'Signal Preprocessing', 'Position', [100, 100, 900, 600]);

subplot(2,1,1);
plot(time, signal1, 'b-', 'LineWidth', 1.0);
hold on;
plot(time, normalized_signal1, 'r-', 'LineWidth', 1.2);
legend('Original Signal 1', 'Normalised Signal 1', 'Location', 'best');
xlabel('Time (s)');
ylabel('Amplitude');
title('Signal 1: Original vs Normalised');
grid on;

subplot(2,1,2);
plot(time, signal2, 'b-', 'LineWidth', 1.0);
hold on;
plot(time, normalized_signal2, 'r-', 'LineWidth', 1.2);
legend('Original Signal 2', 'Normalised Signal 2', 'Location', 'best');
xlabel('Time (s)');
ylabel('Amplitude');
title('Signal 2: Original vs Normalised');
grid on;

%% Display extracted features
fprintf('\n=== Extracted Features ===\n');
fprintf('Features matrix (rows: signals, columns: max, min, std):\n');
disp(features);

%% Feature importance analysis (simulated)
feature_importance = [0.7, 0.2, 0.1; 0.6, 0.3, 0.1];
feature_names = {'Maximum', 'Minimum', 'Standard Deviation'};

figure('Name', 'Feature Importance', 'Position', [150, 150, 600, 400]);
bar(feature_importance);
title('Feature Importance Analysis');
xlabel('Feature');
ylabel('Importance Score');
legend('Signal 1', 'Signal 2', 'Location', 'northeast');
set(gca, 'XTickLabel', feature_names);
grid on;

fprintf('\nLaboratory Exercise 1 completed successfully.\n');
fprintf('Key observations:\n');
fprintf('1. Normalisation centres data around zero with unit variance\n');
fprintf('2. Feature extraction reduces dimensionality whilst preserving information\n');
fprintf('3. Feature importance guides which features to retain for modelling\n');
