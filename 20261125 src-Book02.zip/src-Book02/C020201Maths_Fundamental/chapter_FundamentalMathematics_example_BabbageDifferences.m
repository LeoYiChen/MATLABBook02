%% chapter_FundamentalMathematics_example_BabbageDifferences.m
% Demonstration of Babbage's method of differences in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_example_BabbageDifferences
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Babbage's Method of Differences - Polynomial Evaluation
% This demonstrates the principle behind the Difference Engine

% Define a quadratic polynomial: f(x) = 2*x^2 + 3*x + 1
coefficients = [2, 3, 1];
xValues = 0:10;

% Calculate polynomial values directly
polynomialValues = polyval(coefficients, xValues);

% Calculate using method of differences
numPoints = length(xValues);
differences = zeros(3, numPoints);
differences(1, :) = polynomialValues;

% Calculate first differences
for idx = 1:numPoints-1
    differences(2, idx) = differences(1, idx+1) - differences(1, idx);
end

% Calculate second differences
for idx = 1:numPoints-2
    differences(3, idx) = differences(2, idx+1) - differences(2, idx);
end

% Display results
fprintf('Polynomial values: ');
fprintf('%d ', polynomialValues);
fprintf('\nSecond differences (constant): ');
fprintf('%d ', differences(3, 1:5));
fprintf('\n');
