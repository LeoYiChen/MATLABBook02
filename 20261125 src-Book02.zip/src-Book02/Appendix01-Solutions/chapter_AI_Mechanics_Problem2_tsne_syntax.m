%% chapter_AI_Mechanics_Problem2_tsne_syntax.m
% t-SNE dimensionality reduction syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem2_tsne_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Apply t-SNE to snapshot matrix (or PCA-reduced representation)
% For large datasets, first reduce to ~50 PCA modes
pcaReduced = snapshotMatrix' * U(:, 1:50);  % (numSnapshots   50)

% Perform t-SNE with perplexity tuning
perplexity = 30;  % Typical range: 5-50
tsneEmbedding = tsne(pcaReduced, ...
    'Algorithm', 'barneshut', ...   % Fast approximate method
    'NumDimensions', 2, ...          % 2D embedding for visualisation
    'Perplexity', perplexity, ...
    'Exaggeration', 4, ...           % Early exaggeration factor
    'LearnRate', 500, ...
    'Verbose', 1);

% Visualise with temporal colouring
timeIndices = 1:size(tsneEmbedding, 1);
scatter(tsneEmbedding(:, 1), tsneEmbedding(:, 2), 50, timeIndices, 'filled');
colorbar;
xlabel('t-SNE Dimension 1', 'Interpreter', 'latex');
ylabel('t-SNE Dimension 2', 'Interpreter', 'latex');
title('t-SNE Embedding (coloured by time)', 'Interpreter', 'latex');
