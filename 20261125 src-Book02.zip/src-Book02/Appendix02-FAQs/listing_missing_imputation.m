%% listing_missing_imputation.m
% Comprehensive missing value imputation framework.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : listing_missing_imputation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [X_imputed, imputation_stats] = imputeMissingValues(X, method, options)
% imputeMissingValues - Robust missing value imputation with multiple strategies
%
% Syntax: [X_imputed, stats] = imputeMissingValues(X, method, options)
%
% Inputs:
%   X      - Input data matrix (rows: observations, columns: variables)
%   method - Imputation method: 'mean', 'median', 'mode', 'forward', 'linear'
%   options - Structure with optional parameters
%
% Outputs:
%   X_imputed        - Data matrix with imputed values
%   imputation_stats - Structure containing imputation statistics

    % Input validation and default parameters
    if nargin < 2, method = 'mean'; end
    if nargin < 3, options = struct(); end
    
    % Initialise output matrix and statistics
    X_imputed = X;
    [n_rows, n_cols] = size(X);
    imputation_stats = struct();
    imputation_stats.missing_count = sum(isnan(X(:)));
    imputation_stats.missing_percentage = (imputation_stats.missing_count / numel(X)) * 100;
    imputation_stats.columns_with_missing = sum(any(isnan(X), 1));
    
    % Column-wise imputation
    for col_idx = 1:n_cols
        column_data = X(:, col_idx);
        missing_mask = isnan(column_data);
        
        if any(missing_mask)
            observed_values = column_data(~missing_mask);
            
            % Select imputation strategy
            switch lower(method)
                case 'mean'
                    if ~isempty(observed_values)
                        imputation_value = mean(observed_values, 'omitnan');
                        X_imputed(missing_mask, col_idx) = imputation_value;
                    end
                    
                case 'median'
                    if ~isempty(observed_values)
                        imputation_value = median(observed_values, 'omitnan');
                        X_imputed(missing_mask, col_idx) = imputation_value;
                    end
                    
                case 'mode'
                    if ~isempty(observed_values)
                        imputation_value = mode(observed_values);
                        X_imputed(missing_mask, col_idx) = imputation_value;
                    end
                    
                case 'forward'
                    % Forward-fill for time series data
                    X_imputed(:, col_idx) = fillmissing(column_data, 'previous');
                    
                case 'linear'
                    % Linear interpolation
                    X_imputed(:, col_idx) = fillmissing(column_data, 'linear');
                    
                otherwise
                    warning('Unknown imputation method. Using mean imputation.');
                    if ~isempty(observed_values)
                        imputation_value = mean(observed_values, 'omitnan');
                        X_imputed(missing_mask, col_idx) = imputation_value;
                    end
            end
        end
    end
    
    % Calculate post-imputation statistics
    imputation_stats.method_used = method;
    imputation_stats.remaining_missing = sum(isnan(X_imputed(:)));
    imputation_stats.successfully_imputed = imputation_stats.missing_count - imputation_stats.remaining_missing;
end
