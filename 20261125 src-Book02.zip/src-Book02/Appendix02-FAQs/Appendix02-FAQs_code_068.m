%% Appendix02-FAQs_code_068.m
% Trigonometry-Based Signal Denoising for AI Preprocessing
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Generate periodic sine wave (mimicking sensor/biomedical data)
fs = 1000; % Sampling frequency (1000 Hz)
t = 0:1/fs:2; % Time vector (0 to 2 seconds)
freq = 5; % Frequency of the sine wave (5 Hz)

% Create clean signal + additive Gaussian noise (real-world data)
clean_signal = sin(2 * pi * freq * t); % Core trigonometric wave
noisy_signal = clean_signal + 0.3 * randn(size(t)); % Add noise

% Plot clean vs noisy signal
figure;
subplot(2,1,1);
plot(t, clean_signal);
title('Clean 5 Hz Sine Wave');
xlabel('Time (s)'); ylabel('Amplitude');
subplot(2,1,2);
plot(t, noisy_signal);
title('Noisy 5 Hz Sine Wave (Real-World Sensor Data)');
xlabel('Time (s)'); ylabel('Amplitude');

% AI Preprocessing: Filter noise using Fourier transform (sin/cos decomposition)
fft_signal = fft(noisy_signal); % Fast Fourier Transform
freqs = fftshift(linspace(-fs/2, fs/2, length(fft_signal))); % Frequency axis

% Keep only the 5 Hz component (filter out noise)
threshold = 1; % Keep frequencies within 뿯½1 Hz of 5 Hz
fft_filtered = fft_signal;
fft_filtered(abs(freqs) < (freq - threshold) | abs(freqs) > (freq + threshold)) = 0;

% Reconstruct clean signal for AI model input
filtered_signal = ifft(fft_filtered);

% Plot filtered result
figure;
plot(t, real(filtered_signal)); % Remove small imaginary artifacts
title('Filtered Signal (Trigonometry-Based Denoising)');
xlabel('Time (s)'); ylabel('Amplitude');
