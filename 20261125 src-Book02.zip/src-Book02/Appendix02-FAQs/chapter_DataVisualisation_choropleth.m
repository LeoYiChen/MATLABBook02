%% chapter_DataVisualisation_choropleth.m
% Choropleth Map Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_choropleth
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Requires Mapping Toolbox
figure('Position', [100 100 800 600]);
worldmap('World');
load coastlines;
plotm(coastlat, coastlon);
title('Geographic Distribution Analysis');

% Export figure in multiple formats
exportFigure(gca, 'Choropleth_plot');

