%% prob5_complete.m
% Problem 5: Precision Format Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob5_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 5: Precision Format Trade-offs in Neural Network Training
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Analyses memory, speed, and numerical stability trade-offs
%              across different floating-point precision formats
%
% Revision History:
%   v1.0 (15-Jan-2025): Initial implementation
%   v1.1 (15-Jan-2025): Added dynamic loss scaling simulation

%% Initialisation
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 5: Precision Format Trade-offs in Training\n');
fprintf('================================================================\n\n');

%% Model Configuration
numParameters_billions = 175;  % GPT-3 scale model
numParameters = numParameters_billions * 1e9;

% Precision format specifications
formats = {'FP32', 'FP16', 'BF16', 'INT8'};
bytesPerElement = [4, 2, 2, 1];
mantissaBits = [23, 10, 7, 0];  % Precision bits
exponentBits = [8, 5, 8, 0];
minNormalValues = [1.175e-38, 6.104e-5, 1.175e-38, 0];
maxValues = [3.403e38, 65504, 3.403e38, 127];

% Training configuration
baselineTrainingTime_hours = 1000;  % FP32 baseline
gpuMemoryBandwidth_GBps = 2000;     % A100 HBM2e bandwidth

fprintf('Model Configuration:\n');
fprintf('  Total parameters: %.0fB (%.2e)\n', ...
        numParameters_billions, numParameters);
fprintf('  GPU memory bandwidth: %d GB/s\n', gpuMemoryBandwidth_GBps);
fprintf('  Baseline training time (FP32): %d hours\n\n', ...
        baselineTrainingTime_hours);

%% Part (a): Memory Footprint Analysis

memorySizes_GB = (numParameters * bytesPerElement) / 1e9;

% Additional memory for optimizer states (Adam: 2x parameters for momentum + variance)
optimizerMultiplier = 2;  % Adam stores 2 states per parameter
totalMemory_GB = memorySizes_GB * (1 + optimizerMultiplier);

fprintf('========================================\n');
fprintf('(a) Memory Footprint Comparison\n');
fprintf('========================================\n');
fprintf('%-8s %-15s %-20s %-25s %-20s\n', 'Format', 'Bytes/Elem', ...
        'Model Size (GB)', 'Total w/ Optimizer (GB)', 'Saving vs FP32');
fprintf('%s\n', repmat('-', 1, 92));

for i = 1:length(formats)
    savingPercent = (1 - memorySizes_GB(i) / memorySizes_GB(1)) * 100;
    savingGB = memorySizes_GB(1) - memorySizes_GB(i);
    
    fprintf('%-8s %-15d %-20.1f %-25.1f ', ...
            formats{i}, bytesPerElement(i), memorySizes_GB(i), ...
            totalMemory_GB(i));
    
    if i == 1
        fprintf('%-20s\n', 'Baseline');
    else
        fprintf('%.1f%% (%.0f GB)\n', savingPercent, savingGB);
    end
end
fprintf('\n');

% FP32 to FP16 specific analysis
fp32_memory = memorySizes_GB(1);
fp16_memory = memorySizes_GB(2);
memory_savings = fp32_memory - fp16_memory;

fprintf('FP32   FP16 Conversion:\n');
fprintf('  Memory reduction: %.0f GB   %.0f GB\n', ...
        fp32_memory, fp16_memory);
fprintf('  Savings: %.0f GB (%.0f%% reduction)\n', ...
        memory_savings, (memory_savings / fp32_memory) * 100);
fprintf('  GPU cards saved (80GB A100): %.1f cards\n\n', ...
        memory_savings / 80);

%% Part (b): Training Speed Analysis

% Memory-bound speedup estimation
memorySpeedup = bytesPerElement(1) ./ bytesPerElement;

% Tensor Core boost (hardware acceleration for FP16/BF16)
tensorCoreBoost = [1.0, 2.5, 2.5, 4.0];  % Relative to FP32

% Combined speedup (memory + compute)
totalSpeedup = memorySpeedup .* tensorCoreBoost;

% Estimated training times
estimatedTrainingTime_hours = baselineTrainingTime_hours ./ totalSpeedup;

fprintf('========================================\n');
fprintf('(b) Training Speed Estimation\n');
fprintf('========================================\n');
fprintf('%-8s %-18s %-20s %-22s %-20s\n', 'Format', ...
        'Memory Speedup', 'Tensor Core Boost', 'Total Speedup', ...
        'Training Time (hrs)');
fprintf('%s\n', repmat('-', 1, 92));

for i = 1:length(formats)
    fprintf('%-8s %-18.2fx %-20.2fx %-22.2fx %-20.0f\n', ...
            formats{i}, memorySpeedup(i), tensorCoreBoost(i), ...
            totalSpeedup(i), estimatedTrainingTime_hours(i));
end
fprintf('\n');

fprintf('Time Savings with FP16:\n');
fprintf('  Training time reduction: %d hrs   %.0f hrs\n', ...
        baselineTrainingTime_hours, estimatedTrainingTime_hours(2));
fprintf('  Time saved: %.0f hours (%.1f%%)\n', ...
        baselineTrainingTime_hours - estimatedTrainingTime_hours(2), ...
        (1 - estimatedTrainingTime_hours(2) / baselineTrainingTime_hours) * 100);
fprintf('  At $2/GPU-hour: Cost saving = $%.0f\n\n', ...
        (baselineTrainingTime_hours - estimatedTrainingTime_hours(2)) * 2);

%% Part (c): Numerical Stability Analysis - Gradient Underflow Risk

% Simulate gradient distribution (log-normal)
gradientMagnitudes = logspace(-8, -1, 10000);
gradientDistribution = lognpdf(log10(gradientMagnitudes), -4, 1.5);
gradientDistribution = gradientDistribution / sum(gradientDistribution);

fprintf('========================================\n');
fprintf('(c) Numerical Stability Analysis\n');
fprintf('========================================\n');

% Calculate underflow risk for each format
fprintf('%-8s %-20s %-25s %-25s\n', 'Format', 'Min Normal Value', ...
        'Precision (bits)', 'Underflow Risk');
fprintf('%s\n', repmat('-', 1, 82));

for i = 1:3  % Only FP32, FP16, BF16
    underflowMask = gradientMagnitudes < minNormalValues(i);
    underflowRisk = sum(gradientDistribution(underflowMask)) * 100;
    
    fprintf('%-8s %-20.2e %-25d %-25.2f%%\n', ...
            formats{i}, minNormalValues(i), mantissaBits(i), underflowRisk);
end
fprintf('\n');

% Specific gradient ranges
gradientRanges = [1e-7, 1e-5, 1e-3];
fprintf('Gradient Magnitude Analysis:\n');
fprintf('  Typical gradients in deep networks:\n');
for g = gradientRanges
    fp16_representable = g >= minNormalValues(2);
    fprintf('    %.0e: FP16 %s\n', g, ...
            ternary(fp16_representable, 'OK', 'UNDERFLOWS'));
end
fprintf('\n');

%% Part (d): Loss Scaling Strategy

fprintf('========================================\n');
fprintf('(d) Loss Scaling for FP16 Training\n');
fprintf('========================================\n');

% Dynamic loss scaling parameters
initialScale = 2^15;  % 32768
scaleWindow = 2000;   % Check every 2000 iterations
backoffFactor = 0.5;
growthFactor = 2.0;

fprintf('Dynamic Loss Scaling Configuration:\n');
fprintf('  Initial scale factor: %.0f (2^{%.0f})\n', ...
        initialScale, log2(initialScale));
fprintf('  Scale update window: %d iterations\n', scaleWindow);
fprintf('  Backoff factor (overflow): %.1f\n', backoffFactor);
fprintf('  Growth factor (stable): %.1f\n\n', growthFactor);

% Demonstrate scaling effect
exampleGradient = 1e-6;
scaledGradient = exampleGradient * initialScale;

fprintf('Example: Gradient Scaling\n');
fprintf('  Original gradient: %.2e\n', exampleGradient);
fprintf('  Scaled gradient: %.2e\n', scaledGradient);
fprintf('  FP16 representable: %s\n', ...
        ternary(scaledGradient >= minNormalValues(2), 'YES', 'NO'));
fprintf('  After backward pass: Unscale by dividing by %.0f\n\n', ...
        initialScale);

% Simulate loss scaling over training
numIterations = 10000;
lossScales = zeros(1, numIterations);
currentScale = initialScale;
consecutiveStable = 0;

for iter = 1:numIterations
    lossScales(iter) = currentScale;
    
    % Simulate overflow probability (decreases over training)
    overflowProb = 0.001 * exp(-iter / 5000);
    hasOverflow = rand() < overflowProb;
    
    if hasOverflow
        currentScale = currentScale * backoffFactor;
        consecutiveStable = 0;
    else
        consecutiveStable = consecutiveStable + 1;
        
        % Increase scale after stable window
        if consecutiveStable >= scaleWindow
            currentScale = min(currentScale * growthFactor, 2^24);
            consecutiveStable = 0;
        end
    end
end

fprintf('Loss Scale Evolution Statistics:\n');
fprintf('  Initial scale: %.0f\n', lossScales(1));
fprintf('  Final scale: %.0f\n', lossScales(end));
fprintf('  Mean scale: %.0f\n', mean(lossScales));
fprintf('  Min scale: %.0f (encountered overflow)\n', min(lossScales));
fprintf('  Max scale: %.0f\n\n', max(lossScales));

%% Part (e): Mixed Precision Training Strategies

fprintf('========================================\n');
fprintf('(e) Mixed Precision Training Strategies\n');
fprintf('========================================\n\n');

strategies = {'Pure FP32', 'Pure FP16', 'Mixed (FP16/FP32)', ...
              'Mixed + Loss Scaling', 'BF16 (no scaling)'};
speeds = [1.0, 3.5, 3.2, 3.0, 2.8];
stabilities = {'Excellent', 'Poor', 'Moderate', 'Excellent', 'Good'};
memoryEffs = [1.0, 2.0, 1.5, 1.5, 2.0];
recommendations = {'Baseline', 'Not recommended', 'Research only', ...
                   'Production standard', 'Emerging option'};

fprintf('%-25s %-12s %-15s %-18s %-20s\n', 'Strategy', 'Speedup', ...
        'Stability', 'Memory Efficiency', 'Recommendation');
fprintf('%s\n', repmat('-', 1, 95));

for i = 1:length(strategies)
    fprintf('%-25s %-12.1fx %-15s %-18.1fx %-20s\n', ...
            strategies{i}, speeds(i), stabilities{i}, memoryEffs(i), ...
            recommendations{i});
end
fprintf('\n');

fprintf('RECOMMENDED APPROACH: Mixed Precision + Loss Scaling\n');
fprintf('  - Forward/backward passes: FP16 (speed + memory)\n');
fprintf('  - Master weights: FP32 (numerical accuracy)\n');
fprintf('  - Loss scaling: Dynamic (prevent underflow)\n');
fprintf('  - Weight updates: FP32 precision\n');
fprintf('  - Expected speedup: %.1fx with stable training\n\n', speeds(4));

%% Visualisation

figure('Position', [50, 50, 1600, 500], 'Color', 'w');

% Panel 1: Memory Comparison
subplot(1, 3, 1);
bar(memorySizes_GB, 'FaceColor', [0.3, 0.5, 0.8], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);
ylabel('Model Memory (GB)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(a) Memory Footprint}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', formats, 'FontSize', 12);
grid on; box on;
ylim([0, max(memorySizes_GB) * 1.15]);

% Panel 2: Training Speed
subplot(1, 3, 2);
bar(totalSpeedup, 'FaceColor', [0.2, 0.7, 0.4], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);
ylabel('Speedup Factor', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(b) Training Speedup}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', formats, 'FontSize', 12);
yline(1, 'r-', 'LineWidth', 2);
grid on; box on;
ylim([0, max(totalSpeedup) * 1.15]);

% Panel 3: Loss Scale Evolution
subplot(1, 3, 3);
plot(1:numIterations, log2(lossScales), 'b-', 'LineWidth', 1.5);
xlabel('Training Iteration', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('$\log_2(\text{Loss Scale})$', 'Interpreter', 'latex', ...
       'FontSize', 13);
title('\textbf{(c) Dynamic Loss Scaling}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);
ylim([0, 25]);

%% Helper Function
function result = ternary(condition, trueVal, falseVal)
    if condition
        result = trueVal;
    else
        result = falseVal;
    end
end
