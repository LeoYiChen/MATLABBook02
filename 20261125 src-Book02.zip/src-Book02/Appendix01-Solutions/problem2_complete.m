%% problem2_complete.m
% Complete solution for Problem 2: Neural network for Wien's law.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem2_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 2: Neural Network Approximation of Wien's Displacement Law
% Author: Dr Yi Chen
% Date: 2024-02-09
% MATLAB Version: R2024a
% Dependencies: Deep Learning Toolbox
%
% Purpose: Train neural network to learn Wien's displacement law from
%          synthetic stellar temperature-wavelength observations.
%
% Physics Context:  _max T = b where b   2.898 10 m K (Wien's constant)

%% Initialisation
clear all; close all; clc;
rng(2024, 'twister');

fprintf('=== Problem 2: Neural Network for Wien''s Displacement Law ===\n\n');

%% Step 1: Generate Synthetic Stellar Dataset

% Wien's displacement constant (m K)
wienConstant = 2.898e-3;

% Generate stellar temperatures (K)
numStars = 500;
minTemperature = 3000;   % M-dwarf
maxTemperature = 50000;  % O-type star

stellarTemperatures = minTemperature + (maxTemperature - minTemperature) * rand(numStars, 1);

% Compute peak wavelengths (m)
peakWavelengths = wienConstant ./ stellarTemperatures;

% Add observational noise (5% Gaussian)
noiseLevel = 0.05;
observedWavelengths = peakWavelengths .* (1 + noiseLevel * randn(numStars, 1));

fprintf('Step 1: Generating synthetic stellar dataset\n');
fprintf('  Number of stars: %d\n', numStars);
fprintf('  Temperature range: [%.0f, %.0f] K\n', minTemperature, maxTemperature);
fprintf('  Wien constant: b = %.3e m K\n', wienConstant);
fprintf('  Observational noise: %.1f%%\n\n', noiseLevel * 100);

%% Step 2: Data Preprocessing

% Split dataset (80% training, 20% validation)
splitRatio = 0.8;
numTrain = floor(splitRatio * numStars);

% Shuffle
shuffleIndices = randperm(numStars);
stellarTemperatures = stellarTemperatures(shuffleIndices);
observedWavelengths = observedWavelengths(shuffleIndices);

% Split
temperaturesTrain = stellarTemperatures(1:numTrain);
wavelengthsTrain = observedWavelengths(1:numTrain);

temperaturesValid = stellarTemperatures(numTrain+1:end);
wavelengthsValid = observedWavelengths(numTrain+1:end);

% Normalise data (Z-score normalisation)
[temperaturesTrainNorm, temperatureMean, temperatureStd] = zscore(temperaturesTrain);
[wavelengthsTrainNorm, wavelengthMean, wavelengthStd] = zscore(wavelengthsTrain);

temperaturesValidNorm = (temperaturesValid - temperatureMean) / temperatureStd;
wavelengthsValidNorm = (wavelengthsValid - wavelengthMean) / wavelengthStd;

fprintf('Step 2: Data preprocessing\n');
fprintf('  Training samples: %d\n', numTrain);
fprintf('  Validation samples: %d\n', numStars - numTrain);
fprintf('  Normalisation: Z-score ( =0,  =1)\n\n');

%% Step 3: Design Neural Network Architecture

% Network layers
numHiddenNeurons = 30;

layers = [
    featureInputLayer(1, 'Name', 'temperature_input')
    fullyConnectedLayer(numHiddenNeurons, 'Name', 'hidden1')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(1, 'Name', 'wavelength_output')
    regressionLayer('Name', 'mse_loss')
];

fprintf('Step 3: Neural network architecture\n');
fprintf('  Input: Temperature T (1 neuron)\n');
fprintf('  Hidden layer: %d neurons, ReLU activation\n', numHiddenNeurons);
fprintf('  Output: Peak wavelength  _max (1 neuron)\n');
fprintf('  Loss function: Mean Squared Error (MSE)\n\n');

%% Step 4: Configure Training Options

options = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.01, ...
    'ValidationData', {temperaturesValidNorm, wavelengthsValidNorm}, ...
    'ValidationFrequency', 10, ...
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'none');

fprintf('Step 4: Training configuration\n');
fprintf('  Optimiser: ADAM\n');
fprintf('  Epochs: %d\n', options.MaxEpochs);
fprintf('  Mini-batch size: %d\n', options.MiniBatchSize);
fprintf('  Learning rate: %.4f\n\n', options.InitialLearnRate);

%% Step 5: Train Neural Network

fprintf('Step 5: Training neural network...\n');

tic;
trainedNetwork = trainNetwork(temperaturesTrainNorm, wavelengthsTrainNorm, layers, options);
trainingTime = toc;

fprintf('  Training complete! Time: %.2f seconds\n\n', trainingTime);

%% Step 6: Evaluate Performance

% Predictions on validation set (denormalised)
wavelengthsPredNorm = predict(trainedNetwork, temperaturesValidNorm);
wavelengthsPred = wavelengthsPredNorm * wavelengthStd + wavelengthMean;

% Compute metrics
mse = mean((wavelengthsValid - wavelengthsPred).^2);
rmse = sqrt(mse);
mae = mean(abs(wavelengthsValid - wavelengthsPred));

% R score
ssRes = sum((wavelengthsValid - wavelengthsPred).^2);
ssTot = sum((wavelengthsValid - mean(wavelengthsValid)).^2);
r2Score = 1 - ssRes / ssTot;

fprintf('Step 6: Validation performance\n');
fprintf('  RMSE: %.3e m\n', rmse);
fprintf('  MAE: %.3e m\n', mae);
fprintf('  R score: %.6f\n\n', r2Score);

%% Step 7: Extract Effective Wien Constant

% Fit   = b_eff / T to network predictions across full temperature range
temperatureGrid = linspace(minTemperature, maxTemperature, 200)';
temperatureGridNorm = (temperatureGrid - temperatureMean) / temperatureStd;

wavelengthPredGrid = predict(trainedNetwork, temperatureGridNorm);
wavelengthPredGrid = wavelengthPredGrid * wavelengthStd + wavelengthMean;

% Least-squares fit:   = b/T     T   = b
effectiveWienConstant = mean(temperatureGrid .* wavelengthPredGrid);

fprintf('Step 7: Wien constant extraction\n');
fprintf('  True Wien constant: b = %.3e m K\n', wienConstant);
fprintf('  NN-learned constant: b_eff = %.3e m K\n', effectiveWienConstant);
fprintf('  Relative error: %.2f%%\n\n', ...
        abs(effectiveWienConstant - wienConstant) / wienConstant * 100);

%% Step 8: Visualisation

figure('Position', [100, 100, 1400, 900]);

% Subplot 1: Training data and NN fit
subplot(2, 3, 1);
scatter(temperaturesTrain / 1000, wavelengthsTrain * 1e9, 30, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
hold on;
plot(temperatureGrid / 1000, wavelengthPredGrid * 1e9, 'r-', 'LineWidth', 2.5);
plot(temperatureGrid / 1000, (wienConstant ./ temperatureGrid) * 1e9, 'k-', 'LineWidth', 2);
hold off;
xlabel('Temperature $T$ [1000 K]', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Peak Wavelength $\lambda_{\max}$ [nm]', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{NN Approximation of Wien''s Law}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'Training Data', 'NN Prediction', 'True Wien Law'}, 'Interpreter', 'latex', 'Location', 'northeast');
grid on;

% Subplot 2: Validation predictions vs. true
subplot(2, 3, 2);
scatter(wavelengthsValid * 1e9, wavelengthsPred * 1e9, 50, 'filled', 'MarkerFaceAlpha', 0.7);
hold on;
minWavelength = min([wavelengthsValid; wavelengthsPred]);
maxWavelength = max([wavelengthsValid; wavelengthsPred]);
plot([minWavelength, maxWavelength] * 1e9, [minWavelength, maxWavelength] * 1e9, 'r-', 'LineWidth', 2);
hold off;
xlabel('True $\lambda_{\max}$ [nm]', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Predicted $\lambda_{\max}$ [nm]', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Prediction Accuracy}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'Validation Data', 'Perfect Prediction'}, 'Interpreter', 'latex', 'Location', 'southeast');
axis equal;
grid on;

% Subplot 3: Relative error vs. temperature
subplot(2, 3, 3);
relativeErrors = abs(wavelengthsValid - wavelengthsPred) ./ wavelengthsValid * 100;
scatter(temperaturesValid / 1000, relativeErrors, 50, 'filled', 'MarkerFaceAlpha', 0.7);
xlabel('Temperature $T$ [1000 K]', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Relative Error [\%]', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Error Distribution}', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Subplot 4: Wien constant recovery across temperatures
subplot(2, 3, 4);
localWienConstants = temperatureGrid .* wavelengthPredGrid;
plot(temperatureGrid / 1000, localWienConstants * 1e3, 'b-', 'LineWidth', 2);
hold on;
yline(wienConstant * 1e3, 'r-', 'LineWidth', 2, 'Label', 'True $b$');
hold off;
xlabel('Temperature $T$ [1000 K]', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('$T \cdot \lambda_{\max}$ [mm K]', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Wien Constant Consistency}', 'Interpreter', 'latex', 'FontSize', 13);
legend({'NN-Predicted', 'True Value'}, 'Interpreter', 'latex', 'Location', 'best');
grid on;

% Subplot 5: Residual histogram
subplot(2, 3, 5);
residuals = (wavelengthsValid - wavelengthsPred) * 1e9;
histogram(residuals, 20, 'FaceColor', [0.3, 0.6, 0.9], 'EdgeColor', 'k', 'FaceAlpha', 0.7);
xlabel('Residuals [nm]', 'Interpreter', 'latex', 'FontSize', 12);
ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 12);
title('\textbf{Residual Distribution}', 'Interpreter', 'latex', 'FontSize', 13);
grid on;

% Subplot 6: Summary statistics
subplot(2, 3, 6);
axis off;
summaryText = {
    '\textbf{Neural Network Performance Summary}', ...
    '', ...
    sprintf('\\textbf{Dataset:} %d stars', numStars), ...
    sprintf('Temperature range: [%d, %d] K', minTemperature, maxTemperature), ...
    '', ...
    '\textbf{Network Architecture:}', ...
    sprintf('  Hidden neurons: %d', numHiddenNeurons), ...
    sprintf('  Activation: ReLU'), ...
    sprintf('  Training epochs: %d', options.MaxEpochs), ...
    '', ...
    '\textbf{Performance Metrics:}', ...
    sprintf('  RMSE: %.2f nm', rmse * 1e9), ...
    sprintf('  MAE: %.2f nm', mae * 1e9), ...
    sprintf('  $R^2$: %.6f', r2Score), ...
    '', ...
    '\textbf{Wien Constant Recovery:}', ...
    sprintf('  True: $b = %.3f$ mm K', wienConstant * 1e3), ...
    sprintf('  Learned: $\\hat{b} = %.3f$ mm K', effectiveWienConstant * 1e3), ...
    sprintf('  Error: %.2f\\%%', abs(effectiveWienConstant - wienConstant) / wienConstant * 100)
};

yPosition = 0.95;
for lineIndex = 1:length(summaryText)
    text(0.05, yPosition, summaryText{lineIndex}, ...
         'Interpreter', 'latex', 'FontSize', 10, 'VerticalAlignment', 'top');
    yPosition = yPosition - 0.05;
end

sgtitle('\textbf{Problem 2: Neural Network Approximation of Wien''s Displacement Law}', ...
        'Interpreter', 'latex', 'FontSize', 15);

%% Step 9: Summary

fprintf('=== Problem 2 Summary ===\n\n');
fprintf('Objective: Learn Wien''s displacement law via neural network\n');
fprintf('Dataset: %d synthetic stellar observations\n', numStars);
fprintf('Network: 1 hidden layer (%d neurons, ReLU)\n\n', numHiddenNeurons);

fprintf('Key Results:\n');
fprintf('   Validation R: %.6f (near-perfect fit)\n', r2Score);
fprintf('   Wien constant recovery: %.3e m K (%.2f%% error)\n', ...
        effectiveWienConstant, abs(effectiveWienConstant - wienConstant) / wienConstant * 100);
fprintf('   Mean absolute error: %.2f nm\n\n', mae * 1e9);

fprintf('Physics Insights:\n');
fprintf('  - Neural networks can discover empirical laws from data\n');
fprintf('  - No explicit 1/T relationship programmed, yet learned!\n');
fprintf('  - Demonstrates AI''s potential for scientific law discovery\n\n');

fprintf('Historical Note:\n');
fprintf('  Wien''s 1893 empirical discovery preceded quantum theory.\n');
fprintf('  Modern ML recapitulates this empirical-to-theoretical path.\n\n');

fprintf('Problem 2 complete!\n\n');
