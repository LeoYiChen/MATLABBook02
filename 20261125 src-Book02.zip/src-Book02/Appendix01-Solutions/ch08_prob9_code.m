%% ch08_prob9_code.m
% NLP topic modelling on a large text corpus (MATLABBook02_Chapter08_Problem9.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob9_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem9.m
% --------------------------------
% Purpose : NLP pipeline - tokenisation, TF-IDF, LDA, word cloud.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later; Text Analytics Toolbox required
% --------------------------------
clc; clear; close all;

%% Step 1 - Generate synthetic corpus
fprintf('=== Step 1: Generating synthetic corpus ===\n');
rng(42, 'twister');
numDocuments = 10000;
numTopics    = 4;

% Define topic-specific vocabularies
topicVocabs = { ...
    {'robot','sensor','actuator','gripper','kinematics', ...
     'trajectory','manipulator','servo','joint','torque', ...
     'control','precision','motion','assembly','arm'}, ...
    {'neural','network','training','gradient','loss', ...
     'epoch','batch','layer','activation','optimiser', ...
     'convolution','weight','backpropagation','learning','deep'}, ...
    {'turbine','blade','combustion','pressure','temperature', ...
     'efficiency','thrust','nozzle','compressor','rotor', ...
     'vibration','fatigue','thermal','alloy','maintenance'}, ...
    {'digital','twin','simulation','model','virtual', ...
     'physics','calibration','fidelity','synchronisation', ...
     'lifecycle','update','mesh','parameter','validation','cloud'}};

generalWords = {'system','data','analysis','method','result', ...
    'performance','study','design','approach','based', ...
    'proposed','using','applied','research','process'};

documentTexts = strings(numDocuments, 1);
trueTopicAssignments = zeros(numDocuments, 1);
for docIdx = 1:numDocuments
    assignedTopic = randi(numTopics);
    trueTopicAssignments(docIdx) = assignedTopic;
    topicWords   = topicVocabs{assignedTopic};
    numTopicW    = randi([8, 15]);
    numGeneralW  = randi([5, 10]);
    selectedTopic   = topicWords(randi(numel(topicWords), 1, numTopicW));
    selectedGeneral = generalWords(randi(numel(generalWords), 1, numGeneralW));
    allWords = [selectedTopic, selectedGeneral];
    allWords = allWords(randperm(numel(allWords)));
    documentTexts(docIdx) = strjoin(allWords, ' ');
end
fprintf('  Generated %d documents across %d topics.\n', ...
    numDocuments, numTopics);

%% Step 2 - Tokenise
fprintf('\n=== Step 2: Tokenising documents ===\n');
documents = tokenizedDocument(documentTexts);
documents = removeStopWords(documents);
documents = removeShortWords(documents, 2);
documents = normalizeWords(documents, 'Style', 'lemma');
fprintf('  Tokenisation complete.\n');

%% Step 3 - Build bag-of-words model
fprintf('\n=== Step 3: Building bag-of-words model ===\n');
bowModel = bagOfWords(documents);
% Prune: remove words appearing in < 5 or > 80% of documents
bowModel = removeInfrequentWords(bowModel, 5);
bowModel = removeEmptyDocuments(bowModel);
fprintf('  Vocabulary size: %d\n', bowModel.NumWords);
fprintf('  Documents retained: %d\n', bowModel.NumDocuments);

%% Step 4 - Compute TF-IDF
fprintf('\n=== Step 4: Computing TF-IDF matrix ===\n');
tfidfMatrix = tfidf(bowModel);
[numDocs, numTerms] = size(tfidfMatrix);
fprintf('  TF-IDF matrix: %d x %d (sparse)\n', numDocs, numTerms);
fprintf('  Non-zero entries: %d (%.2f%% density)\n', ...
    nnz(tfidfMatrix), 100*nnz(tfidfMatrix)/(numDocs*numTerms));

%% Step 5 - LDA topic modelling
fprintf('\n=== Step 5: Training LDA model (%d topics) ===\n', ...
    numTopics);
ldaModel = fitlda(bowModel, numTopics, 'Verbose', 0);
fprintf('  LDA training complete.\n');

%% Step 6 - Display top words per topic
fprintf('\n-- Top 10 Words per Topic --\n');
for topicIdx = 1:numTopics
    topWords = topkwords(ldaModel, 10, topicIdx);
    wordList = strjoin(topWords.Word', ', ');
    fprintf('  Topic %d: %s\n', topicIdx, wordList);
end

%% Step 7 - Word cloud visualisation
figWordCloud = figure('Name', 'LDA Word Clouds', ...
    'Position', [50 50 1400 800]);
for topicIdx = 1:numTopics
    subplot(2, 2, topicIdx);
    wordcloud(ldaModel, topicIdx);
    title(sprintf('\\textbf{Topic %d}', topicIdx), ...
        'Interpreter', 'latex', 'FontSize', 12);
end
sgtitle('\textbf{LDA Topic Word Clouds}', ...
    'Interpreter', 'latex', 'FontSize', 14);

savefig(figWordCloud, 'Ch08_Problem9_WordClouds.fig');
exportgraphics(figWordCloud, 'Ch08_Problem9_WordClouds.eps', ...
    'ContentType', 'vector');
exportgraphics(figWordCloud, 'Ch08_Problem9_WordClouds.jpg', ...
    'Resolution', 300);

%% Step 8 - Document-topic heat map
fprintf('\n=== Step 8: Document-topic distribution ===\n');
topicDistributions = transform(ldaModel, documents);
% Show first 100 documents for clarity
sampleSize = min(100, size(topicDistributions, 1));

figHeatMap = figure('Name', 'Topic Distribution Heat Map', ...
    'Position', [100 100 800 600]);
imagesc(topicDistributions(1:sampleSize, :));
colorbar;
colormap(hot);
xlabel('Topic Index', 'Interpreter', 'latex');
ylabel('Document Index', 'Interpreter', 'latex');
title('\textbf{Document-Topic Distribution (First 100 Documents)}', ...
    'Interpreter', 'latex', 'FontSize', 13);
set(gca, 'XTick', 1:numTopics);

savefig(figHeatMap, 'Ch08_Problem9_TopicHeatMap.fig');
exportgraphics(figHeatMap, 'Ch08_Problem9_TopicHeatMap.eps', ...
    'ContentType', 'vector');
exportgraphics(figHeatMap, 'Ch08_Problem9_TopicHeatMap.jpg', ...
    'Resolution', 300);

fprintf('\n=== Problem 9 Complete ===\n');
% --------------------------------
% Computational Complexity:
% Tokenisation is O(N * L) where N is number of documents and L is
% average document length. Bag-of-words construction is O(N * L).
% TF-IDF computation is O(nnz) where nnz is the number of non-zero
% entries in the term-document matrix. LDA via collapsed Gibbs
% sampling is O(iterations * N * L * K) where K is the number of
% topics. Word-cloud rendering is O(V) per topic where V is the
% vocabulary size. Overall dominated by LDA: O(iter * N * L * K).
% --------------------------------
