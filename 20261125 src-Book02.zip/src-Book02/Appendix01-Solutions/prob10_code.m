%% prob10_code.m
% Advanced multi-panel data dashboard.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob10_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Advanced Multi-Panel Data Dashboard
% File: MATLABBook02_Chapter07_Problem10.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Creates comprehensive wind farm monitoring dashboard with
%              multiple integrated visualisation panels
% =========================================================================

function MATLABBook02_Chapter07_Problem10()
    % Main function for Problem 10: Multi-Panel Dashboard
    
    clc; clear; close all;
    
    % Generate wind farm operational data
    data = generateWindFarmData();
    
    % Calculate derived metrics
    metrics = calculatePerformanceMetrics(data);
    
    % Create comprehensive dashboard
    createWindFarmDashboard(data, metrics);
    
    % Create alternative compact dashboard
    createCompactDashboard(data, metrics);
    
    % Display summary statistics
    displayDashboardSummary(metrics);
end

function data = generateWindFarmData()
    % GENERATEWINDFARMDATA - Creates synthetic wind farm operational data
    
    rng(456);  % Reproducible random numbers
    
    % Time vector: 30 days at hourly resolution
    data.time = datetime(2024,1,1):hours(1):datetime(2024,1,30,23,0,0);
    numHours = length(data.time);
    
    % Wind speed (m/s) with diurnal and weather patterns
    baseWindSpeed = 8;  % Average wind speed
    diurnalAmplitude = 2;  % Day-night variation
    hourOfDay = hour(data.time);
    
    % Diurnal pattern (stronger during day)
    diurnalPattern = diurnalAmplitude * sin(2*pi * (hourOfDay - 6) / 24);
    
    % Weather fronts (multi-day variation)
    weatherPattern = 3 * sin(2*pi * (1:numHours) / (24*5));
    
    % Random turbulence
    turbulence = 1.5 * randn(1, numHours);
    
    % Combined wind speed
    data.windSpeed = max(0, baseWindSpeed + diurnalPattern + ...
                          weatherPattern + turbulence);
    
    % Wind direction (degrees) - prevailing westerly with variation
    prevailingDirection = 270;  % West
    directionVariation = 60 * randn(1, numHours);
    data.windDirection = mod(prevailingDirection + directionVariation, 360);
    
    % Power output (MW) using power curve
    data.powerOutput = calculatePowerOutput(data.windSpeed);
    
    % Temperature ( C)
    data.temperature = 15 + 8*sin(2*pi * (1:numHours) / (24*365)) + ...
                       5*sin(2*pi * hourOfDay / 24) + randn(1, numHours);
    
    % Turbine availability (0-1)
    data.availability = 0.95 + 0.05*rand(1, numHours);
    data.availability(rand(1, numHours) < 0.02) = 0;  % 2% downtime events
    
    % Adjust power for availability
    data.powerOutput = data.powerOutput .* data.availability;
end

function power = calculatePowerOutput(windSpeed)
    % CALCULATEPOWEROUTPUT - Wind turbine power curve model
    %
    % Typical power curve characteristics:
    %   Cut-in speed: 3 m/s
    %   Rated speed: 12 m/s
    %   Cut-out speed: 25 m/s
    %   Rated power: 5 MW
    
    cutIn = 3;
    rated = 12;
    cutOut = 25;
    ratedPower = 5;  % MW
    
    power = zeros(size(windSpeed));
    
    for i = 1:length(windSpeed)
        v = windSpeed(i);
        
        if v < cutIn || v > cutOut
            power(i) = 0;
        elseif v >= cutIn && v < rated
            % Cubic relationship in transition region
            power(i) = ratedPower * ((v - cutIn) / (rated - cutIn))^3;
        else  % v >= rated && v <= cutOut
            power(i) = ratedPower;
        end
    end
end

function metrics = calculatePerformanceMetrics(data)
    % CALCULATEPERFORMANCEMETRICS - Computes dashboard KPIs
    
    % Total energy production (MWh)
    metrics.totalEnergy = sum(data.powerOutput);  % Sum of hourly MW gives MWh
    
    % Capacity factor
    ratedPower = 5;  % MW
    numHours = length(data.powerOutput);
    metrics.capacityFactor = 100 * metrics.totalEnergy / (ratedPower * numHours);
    
    % Average power
    metrics.avgPower = mean(data.powerOutput);
    
    % Maximum power
    metrics.maxPower = max(data.powerOutput);
    
    % Average wind speed
    metrics.avgWindSpeed = mean(data.windSpeed);
    
    % Availability
    metrics.avgAvailability = 100 * mean(data.availability);
    
    % Wind direction statistics (mode direction)
    [~, edges] = histcounts(data.windDirection, 16);
    metrics.prevailingDirection = edges(1);
    
    % Power-weighted average wind speed
    metrics.powerWeightedWindSpeed = sum(data.powerOutput .* data.windSpeed) / ...
                                     sum(data.powerOutput);
end

function createWindFarmDashboard(data, metrics)
    % CREATEWINDFARMDASHBOARD - Main comprehensive dashboard
    
    fig = figure('Name', 'Wind Farm Performance Dashboard', ...
                 'Position', [50, 50, 1600, 1200], ...
                 'Color', [0.95, 0.95, 0.95]);
    
    % Use tiledlayout for modern layout control
    tl = tiledlayout(4, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
    
    % Panel 1: Time series - Power output (spanning 2 columns)
    nexttile([1, 2]);
    plot(data.time, data.powerOutput, 'b-', 'LineWidth', 1.5);
    hold on;
    plot(data.time, movmean(data.powerOutput, 24), 'r-', 'LineWidth', 2.5);
    ylabel('Power (MW)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Power Output Time Series', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    legend('Hourly', '24-hr Moving Avg', 'Location', 'best', ...
           'Interpreter', 'latex', 'FontSize', 9);
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    hold off;
    
    % Panel 2: KPI Summary (text panel)
    nexttile;
    axis off;
    
    % Create text summary
    summaryText = {
        sprintf('\\textbf{Key Performance Indicators}');
        sprintf('');
        sprintf('Total Energy: \\textbf{%.0f MWh}', metrics.totalEnergy);
        sprintf('Capacity Factor: \\textbf{%.1f\\%%}', metrics.capacityFactor);
        sprintf('Avg Power: \\textbf{%.2f MW}', metrics.avgPower);
        sprintf('Max Power: \\textbf{%.2f MW}', metrics.maxPower);
        sprintf('Avg Wind Speed: \\textbf{%.1f m/s}', metrics.avgWindSpeed);
        sprintf('Availability: \\textbf{%.1f\\%%}', metrics.avgAvailability);
    };
    
    text(0.05, 0.95, summaryText, 'Units', 'normalized', ...
        'Interpreter', 'latex', 'FontSize', 10, ...
        'VerticalAlignment', 'top', 'FontWeight', 'normal', ...
        'BackgroundColor', 'w', 'EdgeColor', 'k', 'LineWidth', 1.5, ...
        'Margin', 5);
    
    % Panel 3: Wind speed time series
    nexttile([1, 2]);
    plot(data.time, data.windSpeed, 'Color', [0.2, 0.6, 0.8], 'LineWidth', 1.2);
    ylabel('Wind Speed (m/s)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Wind Speed Time Series', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    
    % Panel 4: Wind rose diagram
    nexttile;
    createWindRose(data.windDirection, data.windSpeed);
    title('Wind Rose', 'Interpreter', 'latex', 'FontSize', 11, 'FontWeight', 'bold');
    
    % Panel 5: Power curve scatter
    nexttile([1, 2]);
    scatter(data.windSpeed, data.powerOutput, 20, data.windSpeed, ...
           'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    % Overlay theoretical power curve
    v_theory = linspace(0, 25, 100);
    p_theory = calculatePowerOutput(v_theory);
    plot(v_theory, p_theory, 'r-', 'LineWidth', 3);
    xlabel('Wind Speed (m/s)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Power Output (MW)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Power Curve: Wind Speed vs Output', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    colormap(gca, jet);
    cb = colorbar;
    ylabel(cb, 'Wind Speed (m/s)', 'Interpreter', 'latex', 'FontSize', 9);
    legend('Actual', 'Theoretical', 'Location', 'southeast', ...
           'Interpreter', 'latex', 'FontSize', 9);
    grid on;
    set(gca, 'FontSize', 10, 'LineWidth', 1.2);
    xlim([0, 25]);
    ylim([0, 5.5]);
    hold off;
    
    % Panel 6: Histogram - Wind speed distribution
    nexttile;
    histogram(data.windSpeed, 30, 'FaceColor', [0.4, 0.7, 0.9], ...
             'EdgeColor', 'k', 'FaceAlpha', 0.8);
    xlabel('Wind Speed (m/s)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 10);
    title('Wind Speed Distribution', 'Interpreter', 'latex', ...
          'FontSize', 11, 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 9, 'LineWidth', 1.2);
    
    % Panel 7: Heatmap - Hourly power by day
    nexttile([2, 2]);
    createPowerHeatmap(data);
    title('Daily Power Production Heatmap', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    
    % Panel 8: Histogram - Power output distribution
    nexttile;
    histogram(data.powerOutput, 30, 'FaceColor', [0.9, 0.5, 0.3], ...
             'EdgeColor', 'k', 'FaceAlpha', 0.8);
    xlabel('Power Output (MW)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Frequency', 'Interpreter', 'latex', 'FontSize', 10);
    title('Power Distribution', 'Interpreter', 'latex', ...
          'FontSize', 11, 'FontWeight', 'bold');
    grid on;
    set(gca, 'FontSize', 9, 'LineWidth', 1.2);
    
    % Overall title
    title(tl, 'Wind Farm Performance Dashboard - 30 Day Analysis', ...
         'Interpreter', 'latex', 'FontSize', 14, 'FontWeight', 'bold');
end

function createWindRose(directions, speeds)
    % CREATEWINDROSE - Generates wind rose polar diagram
    
    % Bin directions into 16 sectors (22.5  each)
    numSectors = 16;
    sectorWidth = 360 / numSectors;
    directionBins = 0:sectorWidth:360-sectorWidth;
    
    % Speed bins
    speedBins = [0, 5, 10, 15, 20, 25];
    numSpeedBins = length(speedBins) - 1;
    
    % Initialize frequency matrix
    freqMatrix = zeros(numSpeedBins, numSectors);
    
    % Count occurrences
    for i = 1:length(directions)
        dirIdx = floor(mod(directions(i), 360) / sectorWidth) + 1;
        speedIdx = find(speeds(i) >= speedBins, 1, 'last');
        if speedIdx <= numSpeedBins && dirIdx <= numSectors
            freqMatrix(speedIdx, dirIdx) = freqMatrix(speedIdx, dirIdx) + 1;
        end
    end
    
    % Convert to percentages
    freqMatrix = 100 * freqMatrix / length(directions);
    
    % Create polar bar chart
    theta = deg2rad(directionBins + sectorWidth/2);
    colors = parula(numSpeedBins);
    
    % Plot from inside out
    hold on;
    for speedIdx = 1:numSpeedBins
        if speedIdx == 1
            innerRadius = zeros(size(theta));
        else
            innerRadius = sum(freqMatrix(1:speedIdx-1, :), 1);
        end
        outerRadius = innerRadius + freqMatrix(speedIdx, :);
        
        polarplot([theta; theta], [innerRadius; outerRadius], ...
                 'Color', colors(speedIdx,:), 'LineWidth', 8);
    end
    hold off;
    
    % Add legend
    legendLabels = cell(numSpeedBins, 1);
    for i = 1:numSpeedBins
        legendLabels{i} = sprintf('%.0f-%.0f m/s', speedBins(i), speedBins(i+1));
    end
    legend(legendLabels, 'Location', 'eastoutside', ...
          'Interpreter', 'latex', 'FontSize', 8);
    
    % Configure polar axes
    ax = gca;
    ax.ThetaDir = 'clockwise';
    ax.ThetaZeroLocation = 'top';
end

function createPowerHeatmap(data)
    % CREATEPOWERHEATMAP - Daily x hourly heatmap
    
    % Extract day and hour
    dayOfMonth = day(data.time);
    hourOfDay = hour(data.time);
    
    % Create matrix: rows = hours (0-23), columns = days (1-30)
    powerMatrix = NaN(24, 30);
    
    for i = 1:length(data.time)
        powerMatrix(hourOfDay(i)+1, dayOfMonth(i)) = data.powerOutput(i);
    end
    
    % Create heatmap
    imagesc(1:30, 0:23, powerMatrix);
    colormap(jet);
    cb = colorbar;
    ylabel(cb, 'Power (MW)', 'Interpreter', 'latex', 'FontSize', 10);
    
    xlabel('Day of Month', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Hour of Day', 'Interpreter', 'latex', 'FontSize', 11);
    
    set(gca, 'YDir', 'normal', 'FontSize', 10, 'LineWidth', 1.2);
    axis tight;
end

function createCompactDashboard(data, metrics)
    % CREATECOMPACTDASHBOARD - Alternative condensed layout
    
    figure('Name', 'Compact Dashboard', 'Position', [100, 100, 1400, 800]);
    
    % 2x3 layout
    subplot(2, 3, 1);
    plot(data.time, data.powerOutput, 'b-', 'LineWidth', 1.2);
    ylabel('Power (MW)', 'Interpreter', 'latex', 'FontSize', 10);
    title('Power Output', 'Interpreter', 'latex', 'FontSize', 11);
    grid on; set(gca, 'FontSize', 9);
    
    subplot(2, 3, 2);
    scatter(data.windSpeed, data.powerOutput, 15, data.windSpeed, 'filled', 'MarkerFaceAlpha', 0.5);
    xlabel('Wind Speed (m/s)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Power (MW)', 'Interpreter', 'latex', 'FontSize', 10);
    title('Power Curve', 'Interpreter', 'latex', 'FontSize', 11);
    colormap(jet); colorbar;
    grid on; set(gca, 'FontSize', 9);
    
    subplot(2, 3, 3);
    histogram(data.powerOutput, 25, 'FaceColor', [0.9, 0.5, 0.3], 'EdgeColor', 'k');
    xlabel('Power (MW)', 'Interpreter', 'latex', 'FontSize', 10);
    ylabel('Count', 'Interpreter', 'latex', 'FontSize', 10);
    title('Power Distribution', 'Interpreter', 'latex', 'FontSize', 11);
    grid on; set(gca, 'FontSize', 9);
    
    subplot(2, 3, 4);
    plot(data.time, data.windSpeed, 'Color', [0.2, 0.6, 0.8], 'LineWidth', 1.2);
    ylabel('Wind Speed (m/s)', 'Interpreter', 'latex', 'FontSize', 10);
    title('Wind Speed', 'Interpreter', 'latex', 'FontSize', 11);
    grid on; set(gca, 'FontSize', 9);
    
    subplot(2, 3, 5);
    createWindRose(data.windDirection, data.windSpeed);
    title('Wind Rose', 'Interpreter', 'latex', 'FontSize', 11);
    
    subplot(2, 3, 6);
    % KPI text panel
    axis off;
    kpiText = {
        sprintf('\\textbf{Performance Metrics}');
        sprintf('Energy: %.0f MWh', metrics.totalEnergy);
        sprintf('Capacity: %.1f\\%%', metrics.capacityFactor);
        sprintf('Avg Power: %.2f MW', metrics.avgPower);
        sprintf('Availability: %.1f\\%%', metrics.avgAvailability);
    };
    text(0.1, 0.9, kpiText, 'Units', 'normalized', ...
        'Interpreter', 'latex', 'FontSize', 11, ...
        'VerticalAlignment', 'top', ...
        'BackgroundColor', 'w', 'EdgeColor', 'k', 'LineWidth', 1.5);
    
    sgtitle('Compact Wind Farm Dashboard', 'Interpreter', 'latex', ...
           'FontSize', 13, 'FontWeight', 'bold');
end

function displayDashboardSummary(metrics)
    % DISPLAYDASHBOARDSUMMARY - Console output of key metrics
    
    fprintf('\n========================================\n');
    fprintf('   WIND FARM DASHBOARD SUMMARY\n');
    fprintf('========================================\n');
    fprintf('Total Energy Production: %.0f MWh\n', metrics.totalEnergy);
    fprintf('Capacity Factor: %.2f%%\n', metrics.capacityFactor);
    fprintf('Average Power Output: %.3f MW\n', metrics.avgPower);
    fprintf('Maximum Power Output: %.3f MW\n', metrics.maxPower);
    fprintf('Average Wind Speed: %.2f m/s\n', metrics.avgWindSpeed);
    fprintf('Power-Weighted Wind Speed: %.2f m/s\n', metrics.powerWeightedWindSpeed);
    fprintf('Average Availability: %.2f%%\n', metrics.avgAvailability);
    fprintf('========================================\n');
end
