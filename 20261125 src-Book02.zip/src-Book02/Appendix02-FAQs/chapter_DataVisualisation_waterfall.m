%% chapter_DataVisualisation_waterfall.m
% Waterfall Chart Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_waterfall
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createWaterfallChart(values, labels)
figure('Position', [100 100 800 600]);

% Calculate cumulative positions
cumsum_vals = cumsum(values);
bottom = [0; cumsum_vals(1:end-1)];

% Create bars
for i = 1:length(values)
    if values(i) >= 0
        bar(i, values(i), 'b', 'BaseValue', bottom(i));
    else
        bar(i, values(i), 'r', 'BaseValue', bottom(i));
    end
    hold on;
end

set(gca, 'XTick', 1:length(labels), 'XTickLabel', labels);
grid on;
title('Cumulative Change Analysis');
ylabel('Value');
end

% Export figure in multiple formats
exportFigure(gca, 'Waterfall_plot');

