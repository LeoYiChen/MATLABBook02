%% chapter_Problems_sol3.m
% Simple neural network implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Problems_sol3
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define the XOR problem
X = [0 0; 0 1; 1 0; 1 1]; % Input patterns
y = [0; 1; 1; 0]; % Target outputs

% Network architecture parameters
input_size = 2;
hidden_size = 3;
output_size = 1;

% Initialize weights and biases with small random values
rng(42); % For reproducibility
W1 = 0.1 * randn(input_size, hidden_size);
b1 = zeros(1, hidden_size);
W2 = 0.1 * randn(hidden_size, output_size);
b2 = zeros(1, output_size);

% Training parameters
learning_rate = 0.5;
max_epochs = 10000;
error_threshold = 1e-4;

% Storage for training history
history = struct('epoch', [], 'loss', []);

% Helper Functions
% Sigmoid activation function
sigmoid = @(x) 1 ./ (1 + exp(-x));

% Derivative of sigmoid function
sigmoid_derivative = @(x) x .* (1 - x);

% Mean squared error loss function
mse_loss = @(y_pred, y_true) mean((y_pred - y_true).^2);

% Forward propagation function
function [a1, z2, a2] = forward_pass(X, W1, b1, W2, b2, sigmoid)
% First layer
z1 = X * W1 + b1;
a1 = sigmoid(z1);
% Output layer
z2 = a1 * W2 + b2;
a2 = sigmoid(z2);

end

% Backpropagation function
function [dW1, db1, dW2, db2] = backward_pass(X, y, a1, a2, W2, sigmoid_derivative)
% Output layer error
error_output = y - a2;
delta_output = error_output .* sigmoid_derivative(a2);

% Hidden layer error
error_hidden = delta_output * W2';
delta_hidden = error_hidden .* sigmoid_derivative(a1);

% Gradients
dW2 = a1' * delta_output;
db2 = sum(delta_output, 1);
dW1 = X' * delta_hidden;
db1 = sum(delta_hidden, 1);

end

% Create a figure for live updating
figure;
title('XOR Problem - Decision Boundary Evolution');
xlabel('Input 1');
ylabel('Input 2');
hold on;
grid on;

% Plot the training data
scatter(X(y==0,1), X(y==0,2), 'ro', 'filled', 'DisplayName', 'Class 0');
scatter(X(y==1,1), X(y==1,2), 'bo', 'filled', 'DisplayName', 'Class 1');
legend('Location', 'best');

% Create a meshgrid for visualizing the decision boundary
[X1, X2] = meshgrid(linspace(-0.5, 1.5, 100), linspace(-0.5, 1.5, 100));
X_grid = [X1(:), X2(:)];
contour_handle = [];

% Training loop
fprintf('Beginning training...\n');
epoch = 1;
best_loss = Inf;
patience = 500; % Number of epochs to wait for improvement
patience_counter = 0;

while epoch <= max_epochs
% Forward pass
[a1, ~, a2] = forward_pass(X, W1, b1, W2, b2, sigmoid);

% Calculate loss
loss = mse_loss(a2, y);

% Store training history
history.epoch(epoch) = epoch;
history.loss(epoch) = loss;

% Check for convergence
if loss < error_threshold
    fprintf('Converged at epoch %d with loss %.6f\n', epoch, loss);
    break;
end

% Early stopping check
if loss < best_loss
    best_loss = loss;
    patience_counter = 0;
else
    patience_counter = patience_counter + 1;
    if patience_counter >= patience
        fprintf('Early stopping at epoch %d with loss %.6f\n', epoch, loss);
        break;
    end
end

% Backward pass
[dW1, db1, dW2, db2] = backward_pass(X, y, a1, a2, W2, sigmoid_derivative);

% Update weights and biases
W1 = W1 + learning_rate * dW1;
b1 = b1 + learning_rate * db1;
W2 = W2 + learning_rate * dW2;
b2 = b2 + learning_rate * db2;

% Visualize decision boundary every 100 epochs or at the end
if mod(epoch, 100) == 0 || epoch == max_epochs || loss < error_threshold
    % Forward pass through the grid points
    [a1_grid, ~, a2_grid] = forward_pass(X_grid, W1, b1, W2, b2, sigmoid);
    
    % Reshape predictions for contour plot
    Z = reshape(a2_grid, size(X1));
    
    % Update or create contour plot
    if isempty(contour_handle) || ~isvalid(contour_handle)
        [~, contour_handle] = contour(X1, X2, Z, [0.5 0.5], 'k');
        title(sprintf('Decision Boundary (Epoch %d, Loss %.4f)', epoch, loss));
    else
        delete(contour_handle);
        [~, contour_handle] = contour(X1, X2, Z, [0.5 0.5], 'k');
        title(sprintf('Decision Boundary (Epoch %d, Loss %.4f)', epoch, loss));
    end
    drawnow;
end

% Print progress
if mod(epoch, 500) == 0
    fprintf('Epoch %d: Loss = %.6f\n', epoch, loss);
end

epoch = epoch + 1;

end

% Final evaluation
[a1, ~, a2] = forward_pass(X, W1, b1, W2, b2, sigmoid);
predicted = round(a2);
accuracy = mean(predicted == y);
fprintf('Final accuracy: %.2f%%\n', accuracy * 100);

% Plot training curve
figure;
plot(history.epoch, history.loss);
title('Training Curve');
xlabel('Epoch');
ylabel('Mean Squared Error');
grid on;

% Compare with MATLAB's built-in Neural Network
fprintf('\nComparing with MATLAB''s Neural Network Toolbox:\n');

% Create a pattern recognition network
net = patternnet(hidden_size);
net.trainParam.showWindow = false; % Don't show the training window
net.trainParam.epochs = max_epochs;
net.trainParam.goal = error_threshold;

% Train the network
[net, tr] = train(net, X', y');

% Test the network
y_matlab = net(X');
y_matlab = y_matlab';
matlab_accuracy = mean(round(y_matlab) == y);
fprintf('MATLAB NN accuracy: %.2f%%\n', matlab_accuracy * 100);

% Visualize MATLAB's decision boundary
figure;
title('MATLAB Neural Network - Decision Boundary');
xlabel('Input 1');
ylabel('Input 2');
hold on;
grid on;

% Plot the training data
scatter(X(y==0,1), X(y==0,2), 'ro', 'filled', 'DisplayName', 'Class 0');
scatter(X(y==1,1), X(y==1,2), 'bo', 'filled', 'DisplayName', 'Class 1');
legend('Location', 'best');

% Create predictions for the grid
matlab_output = net(X_grid');
Z_matlab = reshape(matlab_output, size(X1));
contour(X1, X2, Z_matlab, [0.5 0.5], 'k');

% Summary table comparing our implementation with MATLAB's
comparison = table(...
{'Our Implementation'; 'MATLAB Toolbox'}, ...
[accuracy; matlab_accuracy] * 100, ...
[loss; mse_loss(y_matlab, y)], ...
'VariableNames', {'Implementation', 'Accuracy_Percent', 'MSE_Loss'});
disp('Comparison of Implementations:');
disp(comparison);

% Create a final figure showing both decision boundaries
figure;
title('Decision Boundaries Comparison');
xlabel('Input 1');
ylabel('Input 2');
hold on;
grid on;

% Plot the training data
scatter(X(y==0,1), X(y==0,2), 'ro', 'filled', 'DisplayName', 'Class 0');
scatter(X(y==1,1), X(y==1,2), 'bo', 'filled', 'DisplayName', 'Class 1');

% Plot our implementation's boundary
[a1_grid, ~, a2_grid] = forward_pass(X_grid, W1, b1, W2, b2, sigmoid);
Z = reshape(a2_grid, size(X1));
[C1, h1] = contour(X1, X2, Z, [0.5 0.5], 'k-', 'LineWidth', 2);
set(h1, 'DisplayName', 'Our Implementation');

% Plot MATLAB's boundary
[C2, h2] = contour(X1, X2, Z_matlab, [0.5 0.5], 'r-', 'LineWidth', 2);
set(h2, 'DisplayName', 'MATLAB Toolbox');

legend('Location', 'best');
