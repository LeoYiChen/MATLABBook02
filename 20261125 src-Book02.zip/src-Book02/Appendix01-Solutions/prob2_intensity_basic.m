%% prob2_intensity_basic.m
% Arithmetic intensity computation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob2_intensity_basic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function intensity = calculateArithmeticIntensity(totalFLOPs, totalBytes)
    % Computes arithmetic intensity (FLOP per Byte)
    intensity = totalFLOPs / totalBytes;
end
