%% code_comparison.m
% Model comparison function.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:comparison
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function compareModels(X, Y, U_continuum, U_discrete)
    % Compare continuum and discrete model predictions
    
    figure('Position', [100, 100, 1400, 400]);
    
    % Continuum model
    subplot(1, 3, 1);
    surf(X, Y, U_continuum, 'EdgeColor', 'none');
    colormap(jet);
    colorbar;
    title('Continuum Model', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel('$x$ (m)', 'Interpreter', 'latex');
    ylabel('$y$ (m)', 'Interpreter', 'latex');
    zlabel('$u$ (m)', 'Interpreter', 'latex');
    view(45, 30);
    
    % Discrete model
    subplot(1, 3, 2);
    surf(X, Y, U_discrete, 'EdgeColor', 'none');
    colormap(jet);
    colorbar;
    title('Discrete Spring-Mass Model', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel('$x$ (m)', 'Interpreter', 'latex');
    ylabel('$y$ (m)', 'Interpreter', 'latex');
    zlabel('$u$ (m)', 'Interpreter', 'latex');
    view(45, 30);
    
    % Difference
    subplot(1, 3, 3);
    surf(X, Y, abs(U_continuum - U_discrete), 'EdgeColor', 'none');
    colormap(hot);
    colorbar;
    title('Absolute Difference', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel('$x$ (m)', 'Interpreter', 'latex');
    ylabel('$y$ (m)', 'Interpreter', 'latex');
    zlabel('$|u_c - u_d|$ (m)', 'Interpreter', 'latex');
    view(45, 30);
    
    sgtitle('\textbf{Continuum vs. Discrete Model Comparison}', ...
        'Interpreter', 'latex', 'FontSize', 16);
    
    % Compute error metrics
    rmse = sqrt(mean((U_continuum(:) - U_discrete(:)).^2));
    max_error = max(abs(U_continuum(:) - U_discrete(:)));
    
    fprintf('RMSE between models: %.6e m\n', rmse);
    fprintf('Maximum difference: %.6e m\n', max_error);
end
