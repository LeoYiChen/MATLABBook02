%% chapter_FundamentalMathematics_MATLABexample_RiceProblem.m
% Solving the Ancient Rice Problem
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_RiceProblem
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Define the rice problem from Jiuzhang Suanshu
% Coefficient matrix (column-wise, Chinese format)
A = [2 1 3;
     3 2 1;
     1 3 2];

% Right-hand side (total costs)
b = [39; 34; 26];

% Solve using ancient Chinese method
fprintf('════════════════════════════════════════════════\n');
fprintf('Solving the Rice Problem from Jiuzhang Suanshu\n');
fprintf('════════════════════════════════════════════════\n\n');

[prices, transformationSteps] = chineseFangcheng(A, b);

fprintf('\n════════════════════════════════════════════════\n');
fprintf('SOLUTION\n');
fprintf('════════════════════════════════════════════════\n');
fprintf('Price of first grade rice:  %.2f coins per dǒu\n', prices(1));
fprintf('Price of second grade rice: %.2f coins per dǒu\n', prices(2));
fprintf('Price of third grade rice:  %.2f coins per dǒu\n', prices(3));

% Verification
fprintf('\nVerification:\n');
fprintf('Transaction 1: 2*(%.2f) + 3*(%.2f) + 1*(%.2f) = %.2f ✓\n', ...
        prices(1), prices(2), prices(3), A(1,:)*prices);
fprintf('Transaction 2: 1*(%.2f) + 2*(%.2f) + 3*(%.2f) = %.2f ✓\n', ...
        prices(1), prices(2), prices(3), A(2,:)*prices);
fprintf('Transaction 3: 3*(%.2f) + 1*(%.2f) + 2*(%.2f) = %.2f ✓\n', ...
        prices(1), prices(2), prices(3), A(3,:)*prices);
