%% chapter_Math_lab11_ml.m
% Machine Learning Algorithms from Scratch
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab11_ml
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute laboratory
Lab11_MachineLearningImplementation();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab11_MachineLearningImplementation()
    % LAB11_MACHINELEARNINGIMPLEMENTATION Implement ML algorithms from scratch
    %   Covers regression, classification, clustering, and neural networks
    
    fprintf('\\textbf{Laboratory 11: Machine Learning Implementation}\n');
    fprintf('========================================================\n\n');
    
    % Set random seed for reproducibility
    rng(42);
    
    % Task 1: Linear Regression
    implementLinearRegression();
    
    % Task 2: Logistic Regression
    implementLogisticRegression();
    
    % Task 3: K-Means Clustering
    implementKMeansClustering();
    
    % Task 4: Simple Neural Network
    implementNeuralNetwork();
    
    % Task 5: Model Comparison and Evaluation
    compareMLModels();
end

function implementLinearRegression()
    % IMPLEMENTLINEARREGRESSION Linear regression with gradient descent
    
    fprintf('\\textbf{Task 1: Linear Regression}\n');
    fprintf('-------\n');
    
    % Generate synthetic dataset
    fprintf('Generating synthetic dataset...\n');
    m = 100;  % Number of examples
    X = 2 * rand(m, 1);  % Feature in [0, 2]
    y = 4 + 3*X + randn(m, 1);  % True relationship: y = 4 + 3*x + noise
    
    fprintf('  True parameters: theta0 = 4, theta1 = 3\n');
    fprintf('  Training examples: %d\n', m);
    fprintf('  Noise level: σ = 1.0\n\n');
    
    % Add bias term (x0 = 1)
    X_with_bias = [ones(m, 1), X];
    
    % Method 1: Normal Equation (closed-form solution)
    fprintf('Method 1: Normal Equation\n');
    tic;
    theta_normal = (X_with_bias' * X_with_bias) \ (X_with_bias' * y);
    time_normal = toc;
    
    fprintf('  Computation time: %.6f seconds\n', time_normal);
    fprintf('  Parameters: theta0 = %.4f, theta1 = %.4f\n', ...
        theta_normal(1), theta_normal(2));
    
    % Compute cost
    predictions_normal = X_with_bias * theta_normal;
    cost_normal = (1/(2*m)) * sum((predictions_normal - y).^2);
    fprintf('  Final cost: %.6f\n\n', cost_normal);
    
    % Method 2: Gradient Descent
    fprintf('Method 2: Batch Gradient Descent\n');
    
    % Initialize parameters
    theta_gd = zeros(2, 1);
    alpha = 0.1;  % Learning rate
    num_iters = 1000;
    
    fprintf('  Learning rate: %.3f\n', alpha);
    fprintf('  Iterations: %d\n', num_iters);
    
    % Track cost history
    cost_history = zeros(num_iters, 1);
    theta_history = zeros(num_iters, 2);
    
    tic;
    for iter = 1:num_iters
        % Compute predictions
        predictions = X_with_bias * theta_gd;
        
        % Compute gradients
        errors = predictions - y;
        gradients = (1/m) * X_with_bias' * errors;
        
        % Update parameters
        theta_gd = theta_gd - alpha * gradients;
        
        % Record cost and parameters
        cost_history(iter) = (1/(2*m)) * sum(errors.^2);
        theta_history(iter, :) = theta_gd';
        
        % Print progress every 100 iterations
        if mod(iter, 100) == 0
            fprintf('  Iteration %d: Cost = %.6f\n', iter, cost_history(iter));
        end
    end
    time_gd = toc;
    
    fprintf('  Computation time: %.6f seconds\n', time_gd);
    fprintf('  Final parameters: theta0 = %.4f, theta1 = %.4f\n', ...
        theta_gd(1), theta_gd(2));
    fprintf('  Final cost: %.6f\n\n', cost_history(end));
    
    % Method 3: Stochastic Gradient Descent
    fprintf('Method 3: Stochastic Gradient Descent\n');
    
    theta_sgd = zeros(2, 1);
    alpha_sgd = 0.01;
    num_epochs = 50;
    
    fprintf('  Learning rate: %.3f\n', alpha_sgd);
    fprintf('  Epochs: %d\n', num_epochs);
    
    cost_history_sgd = zeros(num_epochs, 1);
    
    tic;
    for epoch = 1:num_epochs
        % Shuffle training data
        indices = randperm(m);
        X_shuffled = X_with_bias(indices, :);
        y_shuffled = y(indices);
        
        % Update using each example
        for i = 1:m
            prediction = X_shuffled(i, :) * theta_sgd;
            error = prediction - y_shuffled(i);
            gradient = X_shuffled(i, :)' * error;
            theta_sgd = theta_sgd - alpha_sgd * gradient;
        end
        
        % Compute cost for this epoch
        predictions_sgd = X_with_bias * theta_sgd;
        cost_history_sgd(epoch) = (1/(2*m)) * sum((predictions_sgd - y).^2);
        
        if mod(epoch, 10) == 0
            fprintf('  Epoch %d: Cost = %.6f\n', epoch, cost_history_sgd(epoch));
        end
    end
    time_sgd = toc;
    
    fprintf('  Computation time: %.6f seconds\n', time_sgd);
    fprintf('  Final parameters: theta0 = %.4f, theta1 = %.4f\n', ...
        theta_sgd(1), theta_sgd(2));
    fprintf('  Final cost: %.6f\n\n', cost_history_sgd(end));
    
    % Visualise results
    visualiseLinearRegression(X, y, theta_normal, theta_gd, theta_sgd, ...
        cost_history, theta_history, cost_history_sgd);
end

function visualiseLinearRegression(X, y, theta_normal, theta_gd, theta_sgd, ...
    cost_history, theta_history, cost_history_sgd)
    % VISUALISELINEARREGRESSION Plot regression results and convergence
    
    figure('Position', [100, 100, 1400, 500], 'Name', 'Linear Regression');
    
    % Subplot 1: Data and fitted lines
    subplot(1, 3, 1);
    scatter(X, y, 50, 'b', 'filled', 'MarkerFaceAlpha', 0.6);
    hold on;
    
    X_line = [min(X); max(X)];
    X_line_bias = [ones(2, 1), X_line];
    
    y_normal = X_line_bias * theta_normal;
    y_gd = X_line_bias * theta_gd;
    y_sgd = X_line_bias * theta_sgd;
    
    plot(X_line, y_normal, 'r-', 'LineWidth', 2, 'DisplayName', 'Normal Equation');
    plot(X_line, y_gd, 'g-', 'LineWidth', 2, 'DisplayName', 'Batch GD');
    plot(X_line, y_sgd, 'm-.', 'LineWidth', 2, 'DisplayName', 'Stochastic GD');
    
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Linear Regression: Data and Fits', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Subplot 2: Cost convergence (Batch GD)
    subplot(1, 3, 2);
    semilogy(1:length(cost_history), cost_history, 'g-', 'LineWidth', 2);
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Cost $J(\theta)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Batch GD: Cost Convergence', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 3: Parameter trajectory
    subplot(1, 3, 3);
    plot(theta_history(:, 1), theta_history(:, 2), 'g-', 'LineWidth', 1.5);
    hold on;
    plot(theta_normal(1), theta_normal(2), 'r*', 'MarkerSize', 15, 'LineWidth', 2);
    plot(theta_history(1, 1), theta_history(1, 2), 'go', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'g');
    plot(theta_history(end, 1), theta_history(end, 2), 'gs', 'MarkerSize', 10, ...
        'MarkerFaceColor', 'g');
    
    xlabel('$\theta_0$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$\theta_1$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Parameter Space Trajectory', 'Interpreter', 'latex', 'FontSize', 13);
    legend('GD Path', 'Optimal', 'Start', 'End', 'Interpreter', 'latex', ...
        'Location', 'best');
    grid on;
end

function implementLogisticRegression()
    % IMPLEMENTLOGISTICREGRESSION Binary classification with logistic regression
    
    fprintf('\\textbf{Task 2: Logistic Regression}\n');
    fprintf('------\n');
    
    % Generate synthetic binary classification dataset
    fprintf('Generating synthetic classification dataset...\n');
    
    % Class 0: centered at (-1, -1)
    m1 = 50;
    X1 = randn(m1, 2) * 0.5 + repmat([-1, -1], m1, 1);
    y1 = zeros(m1, 1);
    
    % Class 1: centered at (1, 1)
    m2 = 50;
    X2 = randn(m2, 2) * 0.5 + repmat([1, 1], m2, 1);
    y2 = ones(m2, 1);
    
    % Combine datasets
    X = [X1; X2];
    y = [y1; y2];
    m = m1 + m2;
    
    fprintf('  Class 0 examples: %d\n', m1);
    fprintf('  Class 1 examples: %d\n', m2);
    fprintf('  Total examples: %d\n\n', m);
    
    % Add bias term
    X_with_bias = [ones(m, 1), X];
    
    % Shuffle data
    indices = randperm(m);
    X_with_bias = X_with_bias(indices, :);
    y = y(indices);
    
    % Split into training (80%) and testing (20%)
    train_size = floor(0.8 * m);
    X_train = X_with_bias(1:train_size, :);
    y_train = y(1:train_size);
    X_test = X_with_bias(train_size+1:end, :);
    y_test = y(train_size+1:end);
    
    fprintf('Training set: %d examples\n', train_size);
    fprintf('Test set: %d examples\n\n', m - train_size);
    
    % Initialize parameters
    theta = zeros(size(X_train, 2), 1);
    
    % Training parameters
    alpha = 0.1;  % Learning rate
    num_iters = 1000;
    
    fprintf('Training logistic regression...\n');
    fprintf('  Learning rate: %.3f\n', alpha);
    fprintf('  Iterations: %d\n', num_iters);
    
    % Track cost history
    cost_history = zeros(num_iters, 1);
    
    tic;
    for iter = 1:num_iters
        % Compute hypothesis (sigmoid)
        z = X_train * theta;
        h = sigmoid(z);
        
        % Compute cost (negative log-likelihood)
        epsilon = 1e-10;  % For numerical stability
        cost = (-1/train_size) * sum(y_train .* log(h + epsilon) + ...
            (1 - y_train) .* log(1 - h + epsilon));
        cost_history(iter) = cost;
        
        % Compute gradient
        gradient = (1/train_size) * X_train' * (h - y_train);
        
        % Update parameters
        theta = theta - alpha * gradient;
        
        % Print progress
        if mod(iter, 100) == 0
            fprintf('  Iteration %d: Cost = %.6f\n', iter, cost);
        end
    end
    time_train = toc;
    
    fprintf('  Training time: %.6f seconds\n', time_train);
    fprintf('  Final cost: %.6f\n\n', cost_history(end));
    
    % Evaluate on training set
    fprintf('Training Set Performance:\n');
    h_train = sigmoid(X_train * theta);
    predictions_train = h_train >= 0.5;
    accuracy_train = 100 * mean(predictions_train == y_train);
    fprintf('  Accuracy: %.2f%%\n\n', accuracy_train);
    
    % Evaluate on test set
    fprintf('Test Set Performance:\n');
    h_test = sigmoid(X_test * theta);
    predictions_test = h_test >= 0.5;
    accuracy_test = 100 * mean(predictions_test == y_test);
    fprintf('  Accuracy: %.2f%%\n\n', accuracy_test);
    
    % Compute confusion matrix
    tp = sum((predictions_test == 1) & (y_test == 1));
    tn = sum((predictions_test == 0) & (y_test == 0));
    fp = sum((predictions_test == 1) & (y_test == 0));
    fn = sum((predictions_test == 0) & (y_test == 1));
    
    fprintf('Confusion Matrix:\n');
    fprintf('                Predicted 0  Predicted 1\n');
    fprintf('  Actual 0:     %6*d       %6*d\n', tn, fp);
    fprintf('  Actual 1:     %6*d       %6*d\n\n', fn, tp);
    
    precision = tp / (tp + fp);
    recall = tp / (tp + fn);
    f1_score = 2 * (precision * recall) / (precision + recall);
    
    fprintf('Classification Metrics:\n');
    fprintf('  Precision: %.4f\n', precision);
    fprintf('  Recall:    %.4f\n', recall);
    fprintf('  F1-Score:  %.4f\n\n', f1_score);
    
    % Visualise results
    visualiseLogisticRegression(X, y, theta, cost_history, X_test, y_test, ...
        predictions_test);
end

function h = sigmoid(z)
    % SIGMOID Sigmoid activation function
    h = 1 ./ (1 + exp(-z));
end

function visualiseLogisticRegression(X, y, theta, cost_history, X_test, ...
    y_test, predictions_test)
    % VISUALISELOGISTICREGRESSION Plot classification results
    
    figure('Position', [150, 150, 1400, 500], 'Name', 'Logistic Regression');
    
    % Subplot 1: Decision boundary
    subplot(1, 3, 1);
    
    % Plot data points
    class0 = y == 0;
    class1 = y == 1;
    scatter(X(class0, 1), X(class0, 2), 50, 'b', 'filled', ...
        'MarkerFaceAlpha', 0.6, 'DisplayName', 'Class 0');
    hold on;
    scatter(X(class1, 1), X(class1, 2), 50, 'r', 'filled', ...
        'MarkerFaceAlpha', 0.6, 'DisplayName', 'Class 1');
    
    % Plot decision boundary
    x1_vals = linspace(min(X(:,1))-0.5, max(X(:,1))+0.5, 100);
    x2_vals = -(theta(1) + theta(2)*x1_vals) / theta(3);
    plot(x1_vals, x2_vals, 'k-', 'LineWidth', 2, 'DisplayName', 'Decision Boundary');
    
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Decision Boundary', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    axis equal;
    
    % Subplot 2: Cost convergence
    subplot(1, 3, 2);
    plot(1:length(cost_history), cost_history, 'b-', 'LineWidth', 2);
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Cost $J(\theta)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Cost Function Convergence', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 3: Test set predictions
    subplot(1, 3, 3);
    
    correct = predictions_test == y_test;
    incorrect = ~correct;
    
    % Plot correctly classified
    scatter(X_test(correct, 2), X_test(correct, 3), 80, 'g', 'filled', ...
        'MarkerFaceAlpha', 0.6, 'DisplayName', 'Correct');
    hold on;
    
    % Plot misclassified
    scatter(X_test(incorrect, 2), X_test(incorrect, 3), 80, 'r', 'x', ...
        'LineWidth', 3, 'DisplayName', 'Incorrect');
    
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Test Set Predictions', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best');
    grid on;
    axis equal;
end

function implementKMeansClustering()
    % IMPLEMENTKMEANSCLUSTERING K-means clustering algorithm
    
    fprintf('\\textbf{Task 3: K-Means Clustering}\n');
    fprintf('------\n');
    
    % Generate synthetic dataset with 3 clusters
    fprintf('Generating synthetic clustering dataset...\n');
    
    % Cluster 1
    m1 = 50;
    X1 = randn(m1, 2) * 0.5 + repmat([0, 0], m1, 1);
    
    % Cluster 2
    m2 = 40;
    X2 = randn(m2, 2) * 0.5 + repmat([3, 3], m2, 1);
    
    % Cluster 3
    m3 = 60;
    X3 = randn(m3, 2) * 0.5 + repmat([6, 0], m3, 1);
    
    % Combine
    X = [X1; X2; X3];
    true_labels = [ones(m1, 1); 2*ones(m2, 1); 3*ones(m3, 1)];
    m = size(X, 1);
    
    fprintf('  Total points: %d\n', m);
    fprintf('  True number of clusters: 3\n\n');
    
    % K-means parameters
    k = 3;  % Number of clusters
    max_iters = 100;
    
    fprintf('K-Means Algorithm:\n');
    fprintf('  Number of clusters: %d\n', k);
    fprintf('  Maximum iterations: %d\n\n', max_iters);
    
    % Initialize centroids randomly
    initial_indices = randperm(m, k);
    centroids = X(initial_indices, :);
    
    fprintf('Initial centroids:\n');
    for i = 1:k
        fprintf('  Centroid %d: (%.4f, %.4f)\n', i, centroids(i, 1), centroids(i, 2));
    end
    fprintf('\n');
    
    % Track algorithm progress
    cost_history = zeros(max_iters, 1);
    centroid_history = zeros(max_iters, k, 2);
    
    fprintf('Running K-Means...\n');
    tic;
    
    for iter = 1:max_iters
        % Assignment step: assign each point to nearest centroid
        distances = zeros(m, k);
        for j = 1:k
            distances(:, j) = sum((X - repmat(centroids(j, :), m, 1)).^2, 2);
        end
        [~, assignments] = min(distances, [], 2);
        
        % Compute cost
        cost = 0;
        for i = 1:m
            cost = cost + sum((X(i, :) - centroids(assignments(i), :)).^2);
        end
        cost_history(iter) = cost;
        centroid_history(iter, :, :) = centroids;
        
        % Update step: recompute centroids
        new_centroids = zeros(k, 2);
        for j = 1:k
            cluster_points = X(assignments == j, :);
            if ~isempty(cluster_points)
                new_centroids(j, :) = mean(cluster_points, 1);
            else
                % If cluster is empty, reinitialize randomly
                new_centroids(j, :) = X(randi(m), :);
            end
        end
        
        % Check for convergence
        if norm(new_centroids - centroids) < 1e-6
            fprintf('  Converged at iteration %d\n', iter);
            cost_history = cost_history(1:iter);
            centroid_history = centroid_history(1:iter, :, :);
            break;
        end
        
        centroids = new_centroids;
        
        if mod(iter, 10) == 0
            fprintf('  Iteration %d: Cost = %.4f\n', iter, cost);
        end
    end
    
    time_kmeans = toc;
    fprintf('  Total time: %.6f seconds\n', time_kmeans);
    fprintf('  Final cost: %.4f\n\n', cost_history(end));
    
    fprintf('Final centroids:\n');
    for i = 1:k
        fprintf('  Centroid %d: (%.4f, %.4f)\n', i, centroids(i, 1), centroids(i, 2));
    end
    fprintf('\n');
    
    % Compute cluster sizes
    fprintf('Cluster sizes:\n');
    for j = 1:k
        cluster_size = sum(assignments == j);
        fprintf('  Cluster %d: %d points (%.1f%%)\n', j, cluster_size, ...
            100*cluster_size/m);
    end
    fprintf('\n');
    
    % Visualise results
    visualiseKMeans(X, true_labels, assignments, centroids, cost_history, ...
        centroid_history);
end

function visualiseKMeans(X, true_labels, assignments, centroids, cost_history, ...
    centroid_history)
    % VISUALISEKMEANS Plot clustering results
    
    figure('Position', [200, 200, 1400, 500], 'Name', 'K-Means Clustering');
    
    % Subplot 1: True clusters
    subplot(1, 3, 1);
    colors = ['r', 'g', 'b'];
    for i = 1:3
        cluster_points = X(true_labels == i, :);
        scatter(cluster_points(:, 1), cluster_points(:, 2), 50, colors(i), ...
            'filled', 'MarkerFaceAlpha', 0.6);
        hold on;
    end
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('True Clusters', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    axis equal;
    
    % Subplot 2: K-Means clustering result
    subplot(1, 3, 2);
    for i = 1:3
        cluster_points = X(assignments == i, :);
        scatter(cluster_points(:, 1), cluster_points(:, 2), 50, colors(i), ...
            'filled', 'MarkerFaceAlpha', 0.6);
        hold on;
    end
    plot(centroids(:, 1), centroids(:, 2), 'k*', 'MarkerSize', 20, 'LineWidth', 3);
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('K-Means Result', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    axis equal;
    
    % Subplot 3: Cost convergence
    subplot(1, 3, 3);
    plot(1:length(cost_history), cost_history, 'b-', 'LineWidth', 2);
    xlabel('Iteration', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Total Cost', 'Interpreter', 'latex', 'FontSize', 12);
    title('K-Means Cost Convergence', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Animation of centroid movement
    figure('Position', [250, 250, 600, 500], 'Name', 'K-Means Animation');
    for iter = 1:size(centroid_history, 1)
        clf;
        
        % Plot data points
        scatter(X(:, 1), X(:, 2), 30, [0.7, 0.7, 0.7], 'filled', ...
            'MarkerFaceAlpha', 0.3);
        hold on;
        
        % Plot centroid trajectory
        for j = 1:size(centroid_history, 2)
            trajectory = squeeze(centroid_history(1:iter, j, :));
            plot(trajectory(:, 1), trajectory(:, 2), 'k-', 'LineWidth', 1);
        end
        
        % Plot current centroids
        current_centroids = squeeze(centroid_history(iter, :, :));
        plot(current_centroids(:, 1), current_centroids(:, 2), 'r*', ...
            'MarkerSize', 20, 'LineWidth', 3);
        
        xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
        ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
        title(sprintf('K-Means Iteration %d', iter), 'Interpreter', 'latex', ...
            'FontSize', 14);
        grid on;
        axis equal;
        
        drawnow;
        pause(0.1);
    end
end

function implementNeuralNetwork()
    % IMPLEMENTNEURALNETWORK Simple feedforward neural network
    
    fprintf('\\textbf{Task 4: Simple Neural Network}\n');
    fprintf('-------\n');
    
    % Generate XOR dataset (not linearly separable)
    fprintf('Generating XOR dataset (non-linearly separable)...\n');
    
    X = [0, 0; 0, 1; 1, 0; 1, 1];
    y = [0; 1; 1; 0];  % XOR function
    m = size(X, 1);
    
    fprintf('  Input patterns: %d\n', m);
    fprintf('  Problem: XOR (non-linear)\n\n');
    
    % Display XOR truth table
    fprintf('XOR Truth Table:\n');
    fprintf('  x1  x2  |  y\n');
    fprintf('  ----\n');
    for i = 1:m
        fprintf('  %d   %d   |  %d\n', X(i, 1), X(i, 2), y(i));
    end
    fprintf('\n');
    
    % Network architecture
    input_size = 2;
    hidden_size = 4;
    output_size = 1;
    
    fprintf('Network Architecture:\n');
    fprintf('  Input layer: %d neurons\n', input_size);
    fprintf('  Hidden layer: %d neurons (sigmoid activation)\n', hidden_size);
    fprintf('  Output layer: %d neuron (sigmoid activation)\n\n', output_size);
    
    % Initialize weights randomly
    epsilon_init = 0.5;
    W1 = rand(hidden_size, input_size) * 2 * epsilon_init - epsilon_init;
    b1 = rand(hidden_size, 1) * 2 * epsilon_init - epsilon_init;
    W2 = rand(output_size, hidden_size) * 2 * epsilon_init - epsilon_init;
    b2 = rand(output_size, 1) * 2 * epsilon_init - epsilon_init;
    
    fprintf('Weights initialized randomly in [%.2f, %.2f]\n\n', ...
        -epsilon_init, epsilon_init);
    
    % Training parameters
    alpha = 1.0;  % Learning rate
    num_epochs = 10000;
    
    fprintf('Training Parameters:\n');
    fprintf('  Learning rate: %.2f\n', alpha);
    fprintf('  Epochs: %d\n\n', num_epochs);
    
    % Training
    fprintf('Training neural network...\n');
    cost_history = zeros(num_epochs, 1);
    
    tic;
    for epoch = 1:num_epochs
        % Forward propagation
        Z1 = W1 * X' + repmat(b1, 1, m);
        A1 = sigmoid(Z1);
        Z2 = W2 * A1 + repmat(b2, 1, m);
        A2 = sigmoid(Z2);
        
        % Compute cost (binary cross-entropy)
        epsilon = 1e-10;
        cost = -(1/m) * sum(y' .* log(A2 + epsilon) + ...
            (1 - y') .* log(1 - A2 + epsilon));
        cost_history(epoch) = cost;
        
        % Backpropagation
        dZ2 = A2 - y';
        dW2 = (1/m) * dZ2 * A1';
        db2 = (1/m) * sum(dZ2, 2);
        
        dA1 = W2' * dZ2;
        dZ1 = dA1 .* A1 .* (1 - A1);  % Sigmoid derivative
        dW1 = (1/m) * dZ1 * X;
        db1 = (1/m) * sum(dZ1, 2);
        
        % Update weights
        W2 = W2 - alpha * dW2;
        b2 = b2 - alpha * db2;
        W1 = W1 - alpha * dW1;
        b1 = b1 - alpha * db1;
        
        % Print progress
        if mod(epoch, 1000) == 0
            fprintf('  Epoch %d: Cost = %.6f\n', epoch, cost);
        end
    end
    
    time_train = toc;
    fprintf('  Training time: %.6f seconds\n', time_train);
    fprintf('  Final cost: %.6f\n\n', cost_history(end));
    
    % Test trained network
    fprintf('Testing trained network:\n');
    fprintf('  x1  x2  |  Predicted  Actual  Correct?\n');
    fprintf('  --------\n');
    
    accuracy = 0;
    for i = 1:m
        % Forward pass
        z1 = W1 * X(i, :)' + b1;
        a1 = sigmoid(z1);
        z2 = W2 * a1 + b2;
        prediction = sigmoid(z2);
        
        predicted_class = round(prediction);
        is_correct = (predicted_class == y(i));
        accuracy = accuracy + is_correct;
        
        fprintf('  %d   %d   |    %.4f      %d        %s\n', ...
            X(i, 1), X(i, 2), prediction, y(i), ...
            char(is_correct*'✓' + ~is_correct*'✗'));
    end
    
    accuracy = 100 * accuracy / m;
    fprintf('\n  Overall Accuracy: %.2f%%\n\n', accuracy);
    
    % Visualise results
    visualiseNeuralNetwork(X, y, W1, b1, W2, b2, cost_history);
end

function visualiseNeuralNetwork(X, y, W1, b1, W2, b2, cost_history)
    % VISUALISENEURALNETWORK Plot neural network results
    
    figure('Position', [300, 300, 1400, 500], 'Name', 'Neural Network');
    
    % Subplot 1: Decision boundary
    subplot(1, 3, 1);
    
    % Create mesh for decision boundary
    [x1_mesh, x2_mesh] = meshgrid(-0.5:0.01:1.5, -0.5:0.01:1.5);
    mesh_size = size(x1_mesh);
    predictions = zeros(mesh_size);
    
    for i = 1:numel(x1_mesh)
        x_point = [x1_mesh(i); x2_mesh(i)];
        z1 = W1 * x_point + b1;
        a1 = sigmoid(z1);
        z2 = W2 * a1 + b2;
        predictions(i) = sigmoid(z2);
    end
    
    % Plot decision regions
    contourf(x1_mesh, x2_mesh, predictions, 20);
    colorbar;
    hold on;
    
    % Plot data points
    class0 = y == 0;
    class1 = y == 1;
    scatter(X(class0, 1), X(class0, 2), 200, 'b', 'filled', ...
        'MarkerEdgeColor', 'k', 'LineWidth', 2);
    scatter(X(class1, 1), X(class1, 2), 200, 'r', 'filled', ...
        'MarkerEdgeColor', 'k', 'LineWidth', 2);
    
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Neural Network Decision Boundary', 'Interpreter', 'latex', 'FontSize', 13);
    xlim([-0.5, 1.5]);
    ylim([-0.5, 1.5]);
    
    % Subplot 2: Cost convergence
    subplot(1, 3, 2);
    semilogy(1:length(cost_history), cost_history, 'b-', 'LineWidth', 2);
    xlabel('Epoch', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Cost', 'Interpreter', 'latex', 'FontSize', 12);
    title('Training Cost Convergence', 'Interpreter', 'latex', 'FontSize', 13);
    grid on;
    
    % Subplot 3: Network visualisation
    subplot(1, 3, 3);
    axis off;
    
    % Draw network architecture
    input_pos = [0.1, 0.3; 0.1, 0.7];
    hidden_pos = [0.5, 0.2; 0.5, 0.4; 0.5, 0.6; 0.5, 0.8];
    output_pos = [0.9, 0.5];
    
    % Draw connections (weights)
    for i = 1:size(input_pos, 1)
        for j = 1:size(hidden_pos, 1)
            weight_color = [1, 0, 0] * (W1(j, i) > 0) + [0, 0, 1] * (W1(j, i) < 0);
            line([input_pos(i, 1), hidden_pos(j, 1)], ...
                [input_pos(i, 2), hidden_pos(j, 2)], ...
                'Color', weight_color, 'LineWidth', abs(W1(j, i)));
        end
    end
    
    for j = 1:size(hidden_pos, 1)
        weight_color = [1, 0, 0] * (W2(1, j) > 0) + [0, 0, 1] * (W2(1, j) < 0);
        line([hidden_pos(j, 1), output_pos(1)], ...
            [hidden_pos(j, 2), output_pos(2)], ...
            'Color', weight_color, 'LineWidth', abs(W2(1, j)));
    end
    
    % Draw neurons
    for i = 1:size(input_pos, 1)
        rectangle('Position', [input_pos(i, 1)-0.03, input_pos(i, 2)-0.03, 0.06, 0.06], ...
            'Curvature', [1, 1], 'FaceColor', 'g', 'EdgeColor', 'k', 'LineWidth', 2);
    end
    
    for j = 1:size(hidden_pos, 1)
        rectangle('Position', [hidden_pos(j, 1)-0.03, hidden_pos(j, 2)-0.03, 0.06, 0.06], ...
            'Curvature', [1, 1], 'FaceColor', 'y', 'EdgeColor', 'k', 'LineWidth', 2);
    end
    
    rectangle('Position', [output_pos(1)-0.03, output_pos(2)-0.03, 0.06, 0.06], ...
        'Curvature', [1, 1], 'FaceColor', 'r', 'EdgeColor', 'k', 'LineWidth', 2);
    
    % Labels
    text(0.05, 0.95, 'Input', 'FontSize', 12, 'FontWeight', 'bold');
    text(0.45, 0.95, 'Hidden', 'FontSize', 12, 'FontWeight', 'bold');
    text(0.85, 0.95, 'Output', 'FontSize', 12, 'FontWeight', 'bold');
    
    title('Network Architecture', 'Interpreter', 'latex', 'FontSize', 13);
    xlim([0, 1]);
    ylim([0, 1]);
end

function compareMLModels()
    % COMPAREMLMODELS Compare different ML algorithms on same dataset
    
    fprintf('\\textbf{Task 5: Model Comparison}\n');
    fprintf('-------\n\n');
    
    fprintf('Comparing ML models on classification tasks...\n\n');
    
    % Generate more complex dataset
    rng(42);
    m = 200;
    
    % Two moons dataset
    t = linspace(0, pi, m/2)';
    X_moon1 = [cos(t), sin(t)] + randn(m/2, 2)*0.1;
    X_moon2 = [1-cos(t), 0.5-sin(t)] + randn(m/2, 2)*0.1;
    
    X = [X_moon1; X_moon2];
    y = [zeros(m/2, 1); ones(m/2, 1)];
    
    % Add bias term
    X_with_bias = [ones(m, 1), X];
    
    % Shuffle
    indices = randperm(m);
    X_with_bias = X_with_bias(indices, :);
    X = X(indices, :);
    y = y(indices);
    
    % Split into train/test
    train_size = floor(0.8 * m);
    X_train_bias = X_with_bias(1:train_size, :);
    X_train = X(1:train_size, :);
    y_train = y(1:train_size);
    X_test_bias = X_with_bias(train_size+1:end, :);
    X_test = X(train_size+1:end, :);
    y_test = y(train_size+1:end);
    
    fprintf('Dataset: Two Moons (Non-Linear)\n');
    fprintf('  Training: %d examples\n', train_size);
    fprintf('  Testing: %d examples\n\n', m - train_size);
    
    % Train logistic regression
    fprintf('1. Training Logistic Regression...\n');
    theta_lr = trainLogisticRegression(X_train_bias, y_train);
    acc_lr = evaluateLogisticRegression(X_test_bias, y_test, theta_lr);
    fprintf('   Test Accuracy: %.2f%%\n\n', acc_lr);
    
    % Train neural network
    fprintf('2. Training Neural Network...\n');
    [W1_nn, b1_nn, W2_nn, b2_nn] = trainNeuralNetwork(X_train, y_train);
    acc_nn = evaluateNeuralNetwork(X_test, y_test, W1_nn, b1_nn, W2_nn, b2_nn);
    fprintf('   Test Accuracy: %.2f%%\n\n', acc_nn);
    
    % Visualise comparison
    visualiseModelComparison(X, y, theta_lr, W1_nn, b1_nn, W2_nn, b2_nn);
    
    fprintf('Summary:\n');
    fprintf('  Logistic Regression Accuracy: %.2f%%\n', acc_lr);
    fprintf('  Neural Network Accuracy:      %.2f%%\n', acc_nn);
    fprintf('\n  Winner: %s\n\n', char((acc_nn > acc_lr)*'Neural Network' + ...
        (acc_lr >= acc_nn)*'Logistic Regression'));
end

function theta = trainLogisticRegression(X, y)
    % TRAINLOGISTICREGRESSION Helper for logistic regression training
    theta = zeros(size(X, 2), 1);
    alpha = 0.1;
    num_iters = 1000;
    
    for iter = 1:num_iters
        h = sigmoid(X * theta);
        gradient = (1/size(X, 1)) * X' * (h - y);
        theta = theta - alpha * gradient;
    end
end

function accuracy = evaluateLogisticRegression(X, y, theta)
    % EVALUATELOGISTICREGRESSION Evaluate logistic regression model
    h = sigmoid(X * theta);
    predictions = h >= 0.5;
    accuracy = 100 * mean(predictions == y);
end

function [W1, b1, W2, b2] = trainNeuralNetwork(X, y)
    % TRAINNEURALNETWORK Helper for neural network training
    m = size(X, 1);
    input_size = size(X, 2);
    hidden_size = 10;
    output_size = 1;
    
    epsilon_init = 0.5;
    W1 = rand(hidden_size, input_size) * 2 * epsilon_init - epsilon_init;
    b1 = rand(hidden_size, 1) * 2 * epsilon_init - epsilon_init;
    W2 = rand(output_size, hidden_size) * 2 * epsilon_init - epsilon_init;
    b2 = rand(output_size, 1) * 2 * epsilon_init - epsilon_init;
    
    alpha = 1.0;
    num_epochs = 5000;
    
    for epoch = 1:num_epochs
        Z1 = W1 * X' + repmat(b1, 1, m);
        A1 = sigmoid(Z1);
        Z2 = W2 * A1 + repmat(b2, 1, m);
        A2 = sigmoid(Z2);
        
        dZ2 = A2 - y';
        dW2 = (1/m) * dZ2 * A1';
        db2 = (1/m) * sum(dZ2, 2);
        
        dA1 = W2' * dZ2;
        dZ1 = dA1 .* A1 .* (1 - A1);
        dW1 = (1/m) * dZ1 * X;
        db1 = (1/m) * sum(dZ1, 2);
        
        W2 = W2 - alpha * dW2;
        b2 = b2 - alpha * db2;
        W1 = W1 - alpha * dW1;
        b1 = b1 - alpha * db1;
    end
end

function accuracy = evaluateNeuralNetwork(X, y, W1, b1, W2, b2)
    % EVALUATENEURALNETWORK Evaluate neural network model
    m = size(X, 1);
    Z1 = W1 * X' + repmat(b1, 1, m);
    A1 = sigmoid(Z1);
    Z2 = W2 * A1 + repmat(b2, 1, m);
    A2 = sigmoid(Z2);
    
    predictions = A2 >= 0.5;
    accuracy = 100 * mean(predictions' == y);
end

function visualiseModelComparison(X, y, theta_lr, W1_nn, b1_nn, W2_nn, b2_nn)
    % VISUALISEMODELCOMPARISON Compare decision boundaries
    
    figure('Position', [100, 100, 1200, 500], 'Name', 'Model Comparison');
    
    % Create mesh
    [x1_mesh, x2_mesh] = meshgrid(min(X(:,1))-0.5:0.02:max(X(:,1))+0.5, ...
        min(X(:,2))-0.5:0.02:max(X(:,2))+0.5);
    mesh_size = size(x1_mesh);
    
    % Logistic regression predictions
    subplot(1, 2, 1);
    predictions_lr = zeros(mesh_size);
    for i = 1:numel(x1_mesh)
        x_point = [1; x1_mesh(i); x2_mesh(i)];
        predictions_lr(i) = sigmoid(theta_lr' * x_point);
    end
    
    contourf(x1_mesh, x2_mesh, predictions_lr, 20);
    colorbar;
    hold on;
    
    class0 = y == 0;
    class1 = y == 1;
    scatter(X(class0, 1), X(class0, 2), 50, 'b', 'filled', 'MarkerEdgeColor', 'k');
    scatter(X(class1, 1), X(class1, 2), 50, 'r', 'filled', 'MarkerEdgeColor', 'k');
    
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Logistic Regression', 'Interpreter', 'latex', 'FontSize', 13);
    
    % Neural network predictions
    subplot(1, 2, 2);
    predictions_nn = zeros(mesh_size);
    for i = 1:numel(x1_mesh)
        x_point = [x1_mesh(i); x2_mesh(i)];
        z1 = W1_nn * x_point + b1_nn;
        a1 = sigmoid(z1);
        z2 = W2_nn * a1 + b2_nn;
        predictions_nn(i) = sigmoid(z2);
    end
    
    contourf(x1_mesh, x2_mesh, predictions_nn, 20);
    colorbar;
    hold on;
    
    scatter(X(class0, 1), X(class0, 2), 50, 'b', 'filled', 'MarkerEdgeColor', 'k');
    scatter(X(class1, 1), X(class1, 2), 50, 'r', 'filled', 'MarkerEdgeColor', 'k');
    
    xlabel('$x_1$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$x_2$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Neural Network', 'Interpreter', 'latex', 'FontSize', 13);
end
