%% chapter_UQ_example_errorPropagation.m
% Error propagation: analytical, complex-step, and finite-difference gradients compared against Monte Carlo and against exact closed-form results for products of lognormal and correlated normal variables.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_UQ_example_errorPropagation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Error propagation: analytical, complex-step, and Monte Carlo routes
%  Requires: base MATLAB, R2016b or later. No toolboxes required.

clearvars; close all; clc;
rng(2024, 'twister');

idealGasPropagation();
nonlinearSecondOrderPropagation();
correlatedProductPropagation();

%% --------- local functions -----------
function idealGasPropagation()

    fprintf('Case 1: ideal gas law, T = P*V/(n*R)\n');
    fprintf('====================================\n\n');

    gasConstant  = 8.314462618;             % J/(mol K), CODATA exact value
    nominalValues = [101325, 0.0100, 0.400];   % P [Pa], V [m^3], n [mol]
    standardDevs  = [  1000, 0.0002, 0.008];
    relativeCoV   = standardDevs ./ nominalValues;

    temperatureModel = @(x) (x(:,1) .* x(:,2)) ./ (x(:,3) * gasConstant);
    nominalTemperature = temperatureModel(nominalValues);

    fprintf('Relative input uncertainties: %.2f%%, %.2f%%, %.2f%%\n', ...
        100*relativeCoV);
    fprintf('Nominal temperature: %.3f K\n\n', nominalTemperature);

    % -- Three routes to the same gradient -----------
    analyticalGradient = [ nominalValues(2)/(nominalValues(3)*gasConstant), ...
        nominalValues(1)/(nominalValues(3)*gasConstant), ...
        -nominalValues(1)*nominalValues(2)/(nominalValues(3)^2*gasConstant)];
    complexStepGrad = complexStepGradient(temperatureModel, nominalValues);
    finiteDiffGrad  = centralDifferenceGradient(temperatureModel, ...
        nominalValues);

    fprintf('%-22s %14s %14s %14s\n', 'Route', 'dT/dP', 'dT/dV', 'dT/dn');
    fprintf('%-22s %14.6e %14.6e %14.6e\n', 'Analytical', analyticalGradient);
    fprintf('%-22s %14.6e %14.6e %14.6e\n', 'Complex step', complexStepGrad);
    fprintf('%-22s %14.6e %14.6e %14.6e\n', 'Central difference', ...
        finiteDiffGrad);
    fprintf('Max complex-step error : %.3e (machine precision)\n', ...
        max(abs(complexStepGrad - analyticalGradient)));
    fprintf('Max finite-diff  error : %.3e (truncation limited)\n\n', ...
        max(abs(finiteDiffGrad - analyticalGradient)));

    % -- First-order variance and its budget ---------
    varianceTerms = (analyticalGradient .* standardDevs).^2;
    firstOrderStd = sqrt(sum(varianceTerms));

    fprintf('First-order uncertainty: %.4f K (%.3f%% relative)\n', ...
        firstOrderStd, 100*firstOrderStd/nominalTemperature);
    fprintf('Variance budget: P %.1f%%, V %.1f%%, n %.1f%%\n', ...
        100*varianceTerms/sum(varianceTerms));
    fprintf('Identity check: relative variances must add for a pure\n');
    fprintf('  product/quotient. Sum of squared CoV = %.6e, and\n', ...
        sum(relativeCoV.^2));
    fprintf('  (sigma_T/T)^2 = %.6e. Difference %.2e.\n\n', ...
        (firstOrderStd/nominalTemperature)^2, ...
        abs(sum(relativeCoV.^2) - (firstOrderStd/nominalTemperature)^2));

    % -- Exact result for lognormal inputs, then Monte Carlo -----
    exactCoV = sqrt(prod(1 + relativeCoV.^2) - 1);
    exactMeanFactor = 1 + relativeCoV(3)^2;   % E[1/n] = (1+CoV_n^2)/E[n]

    numSamples = 200000;
    sampleMatrix = drawLognormalSamples(nominalValues, standardDevs, ...
        numSamples);
    temperatureSamples = temperatureModel(sampleMatrix);

    fprintf('Exact lognormal result vs Monte Carlo (N = %d):\n', numSamples);
    fprintf('  Exact CoV        : %.6f\n', exactCoV);
    fprintf('  First-order CoV  : %.6f (underestimates, as expected)\n', ...
        firstOrderStd/nominalTemperature);
    fprintf('  Monte Carlo CoV  : %.6f\n', ...
        std(temperatureSamples)/mean(temperatureSamples));
    fprintf('  Exact mean       : %.4f K\n', ...
        nominalTemperature*exactMeanFactor);
    fprintf('  Monte Carlo mean : %.4f K\n', mean(temperatureSamples));
    fprintf('  Model at the mean: %.4f K (biased low by %.4f K)\n\n', ...
        nominalTemperature, ...
        mean(temperatureSamples) - nominalTemperature);

    visualiseIdealGasPropagation(temperatureSamples, nominalTemperature, ...
        firstOrderStd, varianceTerms);
end

function nonlinearSecondOrderPropagation()

    fprintf('Case 2: nonlinear response, y = exp(x1)*sin(x2) + x3^2\n');
    fprintf('======================================================\n\n');

    nonlinearModel = @(x) exp(x(:,1)) .* sin(x(:,2)) + x(:,3).^2;
    nominalValues  = [0.50, pi/4, 2.00];
    standardDevs   = [0.10, 0.05, 0.20];

    nominalResponse  = nonlinearModel(nominalValues);
    gradientVector   = complexStepGradient(nonlinearModel, nominalValues);
    hessianDiagonal  = centralDifferenceHessianDiagonal(nonlinearModel, ...
        nominalValues);

    firstOrderStd   = sqrt(sum((gradientVector .* standardDevs).^2));
    secondOrderMean = nominalResponse + ...
        0.5 * sum(hessianDiagonal .* standardDevs.^2);

    numSamples = 200000;
    sampleMatrix = nominalValues + standardDevs .* randn(numSamples, 3);
    responseSamples = nonlinearModel(sampleMatrix);

    fprintf('  Model at the mean     : %.5f\n', nominalResponse);
    fprintf('  Second-order mean     : %.5f\n', secondOrderMean);
    fprintf('  Monte Carlo mean      : %.5f\n', mean(responseSamples));
    fprintf('  Bias captured by the second-order term: %.1f%%\n', ...
        100*(secondOrderMean - nominalResponse) / ...
            (mean(responseSamples) - nominalResponse));
    fprintf('  First-order std       : %.5f\n', firstOrderStd);
    fprintf('  Monte Carlo std       : %.5f\n', std(responseSamples));
    fprintf('  Relative error in std : %.2f%%\n\n', ...
        100*abs(firstOrderStd - std(responseSamples))/std(responseSamples));

    visualiseNonlinearPropagation(responseSamples, secondOrderMean, ...
        firstOrderStd);
end

function correlatedProductPropagation()

    fprintf('Case 3: correlated inputs, z = a*b with rho = 0.7\n');
    fprintf('=================================================\n\n');

    meanA = 5.0;  stdA = 0.5;
    meanB = 3.0;  stdB = 0.3;
    correlation = 0.7;
    covarianceAB = correlation * stdA * stdB;

    covarianceMatrix = [stdA^2, covarianceAB; covarianceAB, stdB^2];
    gradientVector   = [meanB, meanA];

    firstOrderIndependent = sqrt(gradientVector.^2 * [stdA^2; stdB^2]);
    firstOrderCorrelated  = sqrt(gradientVector * covarianceMatrix * ...
        gradientVector.');

    % Exact moments of a product of jointly normal variables
    exactMean = meanA*meanB + covarianceAB;
    exactVariance = meanA^2*stdB^2 + meanB^2*stdA^2 + ...
        2*meanA*meanB*covarianceAB + stdA^2*stdB^2 + covarianceAB^2;

    numSamples = 200000;
    choleskyFactor = chol(covarianceMatrix, 'lower');
    correlatedSamples = randn(numSamples, 2) * choleskyFactor.' + ...
        [meanA, meanB];
    productSamples = correlatedSamples(:,1) .* correlatedSamples(:,2);

    fprintf('  First order, independence assumed : %.5f\n', ...
        firstOrderIndependent);
    fprintf('  First order, correlation included : %.5f\n', ...
        firstOrderCorrelated);
    fprintf('  Exact standard deviation          : %.5f\n', ...
        sqrt(exactVariance));
    fprintf('  Monte Carlo standard deviation    : %.5f\n', ...
        std(productSamples));
    fprintf('  Exact mean %.5f versus Monte Carlo %.5f\n', exactMean, ...
        mean(productSamples));
    fprintf('\n  Ignoring correlation understates the uncertainty by %.1f%%.\n', ...
        100*(firstOrderCorrelated - firstOrderIndependent) / ...
            firstOrderIndependent);
    fprintf('  The first-order form also omits the sigma^2*sigma^2 and\n');
    fprintf('  sigma_ab^2 terms, worth a further %.2f%% here.\n\n', ...
        100*(sqrt(exactVariance) - firstOrderCorrelated)/firstOrderCorrelated);

    visualiseCorrelatedPropagation(correlatedSamples, productSamples, ...
        covarianceMatrix, [meanA, meanB]);
end

function gradientVector = complexStepGradient(modelFun, nominalRow)
    % Complex-step differentiation: machine-precision first derivatives for
    % analytic models coded with element-wise operators.
    stepSize = 1e-20;
    gradientVector = zeros(1, numel(nominalRow));
    for variableIndex = 1:numel(nominalRow)
        perturbedRow = complex(nominalRow, 0);
        perturbedRow(variableIndex) = perturbedRow(variableIndex) + ...
            1i * stepSize;
        gradientVector(variableIndex) = ...
            imag(modelFun(perturbedRow)) / stepSize;
    end
end

function gradientVector = centralDifferenceGradient(modelFun, nominalRow)
    stepSizes = eps^(1/3) * max(abs(nominalRow), 1);
    gradientVector = zeros(1, numel(nominalRow));
    for variableIndex = 1:numel(nominalRow)
        forwardRow  = nominalRow;
        backwardRow = nominalRow;
        forwardRow(variableIndex)  = forwardRow(variableIndex)  + ...
            stepSizes(variableIndex);
        backwardRow(variableIndex) = backwardRow(variableIndex) - ...
            stepSizes(variableIndex);
        gradientVector(variableIndex) = (modelFun(forwardRow) - ...
            modelFun(backwardRow)) / (2 * stepSizes(variableIndex));
    end
end

function hessianDiagonal = centralDifferenceHessianDiagonal(modelFun, ...
    nominalRow)
    stepSizes = eps^(1/4) * max(abs(nominalRow), 1);
    baseResponse = modelFun(nominalRow);
    hessianDiagonal = zeros(1, numel(nominalRow));
    for variableIndex = 1:numel(nominalRow)
        forwardRow  = nominalRow;
        backwardRow = nominalRow;
        forwardRow(variableIndex)  = forwardRow(variableIndex)  + ...
            stepSizes(variableIndex);
        backwardRow(variableIndex) = backwardRow(variableIndex) - ...
            stepSizes(variableIndex);
        hessianDiagonal(variableIndex) = (modelFun(forwardRow) - ...
            2*baseResponse + modelFun(backwardRow)) / ...
            stepSizes(variableIndex)^2;
    end
end

function sampleMatrix = drawLognormalSamples(meanVector, stdVector, numSamples)
    sigmaLog = sqrt(log(1 + (stdVector ./ meanVector).^2));
    muLog    = log(meanVector) - 0.5 * sigmaLog.^2;
    sampleMatrix = exp(randn(numSamples, numel(meanVector)) .* sigmaLog + ...
        muLog);
end

function densityValues = standardNormalPdf(zValues)
    densityValues = exp(-0.5 * zValues.^2) / sqrt(2*pi);
end

function visualiseIdealGasPropagation(temperatureSamples, ...
    nominalTemperature, firstOrderStd, varianceTerms)

    figure('Position', [100, 100, 1300, 380], 'Name', 'Ideal gas law');

    subplot(1, 3, 1);
    histogram(temperatureSamples, 60, 'Normalization', 'pdf', ...
        'FaceColor', [0.40 0.65 0.85], 'EdgeColor', 'none'); hold on;
    gridPoints = linspace(min(temperatureSamples), ...
        max(temperatureSamples), 400);
    plot(gridPoints, standardNormalPdf((gridPoints - nominalTemperature) / ...
        firstOrderStd) / firstOrderStd, 'r-', 'LineWidth', 2);
    xline(nominalTemperature, 'k--', 'LineWidth', 1.5);
    xlabel('Temperature [K]'); ylabel('Probability density');
    title('(a) Propagated distribution');
    legend('Monte Carlo', 'First-order normal', 'Model at mean', ...
        'Location', 'northeast'); grid on;

    subplot(1, 3, 2);
    pie(varianceTerms, {'Pressure', 'Volume', 'Amount'});
    title('(b) First-order variance budget');

    subplot(1, 3, 3);
    sortedSamples = sort(temperatureSamples);
    plottingPosition = ((1:numel(sortedSamples))' - 0.5) / ...
        numel(sortedSamples);
    theoreticalZ = -sqrt(2) * erfcinv(2 * plottingPosition);
    plot(theoreticalZ, sortedSamples, '.', 'MarkerSize', 4); hold on;
    plot(theoreticalZ, nominalTemperature + firstOrderStd * theoreticalZ, ...
        'r-', 'LineWidth', 1.8);
    xlabel('Standard normal quantile'); ylabel('Temperature [K]');
    title('(c) First-order model adequacy'); grid on;
end

function visualiseNonlinearPropagation(responseSamples, secondOrderMean, ...
    firstOrderStd)

    figure('Position', [100, 100, 900, 380], 'Name', 'Nonlinear response');

    subplot(1, 2, 1);
    histogram(responseSamples, 60, 'Normalization', 'pdf', ...
        'FaceColor', [0.90 0.65 0.35], 'EdgeColor', 'none'); hold on;
    gridPoints = linspace(min(responseSamples), max(responseSamples), 400);
    plot(gridPoints, standardNormalPdf((gridPoints - secondOrderMean) / ...
        firstOrderStd) / firstOrderStd, 'r-', 'LineWidth', 2);
    xlabel('Response y'); ylabel('Probability density');
    title('(a) Second-order approximation');
    legend('Monte Carlo', 'Analytical', 'Location', 'northeast'); grid on;

    subplot(1, 2, 2);
    sortedSamples = sort(responseSamples);
    plottingPosition = ((1:numel(sortedSamples))' - 0.5) / ...
        numel(sortedSamples);
    theoreticalZ = -sqrt(2) * erfcinv(2 * plottingPosition);
    plot(theoreticalZ, sortedSamples, '.', 'MarkerSize', 4); hold on;
    plot(theoreticalZ, secondOrderMean + firstOrderStd * theoreticalZ, ...
        'r-', 'LineWidth', 1.8);
    xlabel('Standard normal quantile'); ylabel('Response y');
    title('(b) Departure from normality'); grid on;
end

function visualiseCorrelatedPropagation(correlatedSamples, ...
    productSamples, covarianceMatrix, meanRow)

    figure('Position', [100, 100, 1300, 380], 'Name', 'Correlated inputs');

    subplot(1, 3, 1);
    scatter(correlatedSamples(:,1), correlatedSamples(:,2), 6, 'filled', ...
        'MarkerFaceAlpha', 0.08); hold on;
    ellipseAngle = linspace(0, 2*pi, 200);
    choleskyFactor = chol(covarianceMatrix, 'lower');
    ellipsePoints = 2 * choleskyFactor * [cos(ellipseAngle); ...
        sin(ellipseAngle)] + meanRow.';
    plot(ellipsePoints(1,:), ellipsePoints(2,:), 'r-', 'LineWidth', 2);
    xlabel('Variable a'); ylabel('Variable b');
    title('(a) Joint input distribution'); axis equal; grid on;

    subplot(1, 3, 2);
    histogram(productSamples, 60, 'Normalization', 'pdf', ...
        'FaceColor', [0.55 0.85 0.45], 'EdgeColor', 'none');
    xlabel('Product z = a b'); ylabel('Probability density');
    title('(b) Output distribution'); grid on;

    subplot(1, 3, 3);
    correlationRange = linspace(-0.95, 0.95, 200);
    exactStd = sqrt(meanRow(1)^2*covarianceMatrix(2,2) + ...
        meanRow(2)^2*covarianceMatrix(1,1) + ...
        2*meanRow(1)*meanRow(2)*correlationRange*sqrt(prod(diag( ...
        covarianceMatrix))) + prod(diag(covarianceMatrix)) + ...
        correlationRange.^2*prod(diag(covarianceMatrix)));
    plot(correlationRange, exactStd, 'b-', 'LineWidth', 2);
    xlabel('Input correlation \rho'); ylabel('Output std dev');
    title('(c) Sensitivity to correlation'); grid on;
end

% -----------------------
% Computational complexity. First-order propagation costs n+1 model
% evaluations by complex step, or 2n by central differences, against
% O(N) for Monte Carlo, so analysis is cheaper by three to five orders of
% magnitude for modest n. Second-order corrections add O(n) evaluations
% for the Hessian diagonal and O(n^2) for the full Hessian, which becomes
% the binding constraint above roughly fifty inputs. Correlated sampling
% costs O(n^3) once for the Cholesky factor plus O(N n^2) per draw.
% -----------------------
