%% Appendix01-Solutions_code_254.m
% Hybrid AI-Classical Control: Neural Network + PID
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Hybrid AI-Classical Control: Neural Network + PID
% Problem 20: Combining Neural Networks with PID Control
% Author: Control Systems Course
% Description: Complete framework for hybrid NN+PID control with multiple examples
% Requires: Deep Learning Toolbox, Control System Toolbox

clear all; close all; clc;
rng(42);

fprintf('=== Hybrid AI-Classical Control (Neural Network + PID) ===\n\n');

%% Part 1: Robotic Manipulator - Inverse Dynamics Learning

fprintf('PART 1: ROBOTIC MANIPULATOR CONTROL\n');
fprintf('=====================================\n\n');

% Robot parameters (2-link planar arm)
robot = struct();
robot.m1 = 1.0;          % Link 1 mass (kg)
robot.m2 = 0.8;          % Link 2 mass (kg)
robot.l1 = 1.0;          % Link 1 length (m)
robot.l2 = 0.8;          % Link 2 length (m)
robot.lc1 = 0.5;         % Link 1 COM distance (m)
robot.lc2 = 0.4;         % Link 2 COM distance (m)
robot.I1 = 0.083;        % Link 1 inertia (kg.m^2)
robot.I2 = 0.053;        % Link 2 inertia (kg.m^2)
robot.g = 9.81;          % Gravity (m/s^2)

fprintf('Robot Parameters:\n');
fprintf('  Link 1: mass=%.1f kg, length=%.1f m\n', robot.m1, robot.l1);
fprintf('  Link 2: mass=%.1f kg, length=%.1f m\n\n', robot.m2, robot.l2);

% Dynamics functions
M_matrix = @(q, robot) [
    robot.m1*robot.lc1^2 + robot.m2*(robot.l1^2 + robot.lc2^2 + 2*robot.l1*robot.lc2*cos(q(2))) + robot.I1 + robot.I2, ...
    robot.m2*(robot.lc2^2 + robot.l1*robot.lc2*cos(q(2))) + robot.I2;
    robot.m2*(robot.lc2^2 + robot.l1*robot.lc2*cos(q(2))) + robot.I2, ...
    robot.m2*robot.lc2^2 + robot.I2
];

C_matrix = @(q, dq, robot) [
    -robot.m2*robot.l1*robot.lc2*sin(q(2))*dq(2), ...
    -robot.m2*robot.l1*robot.lc2*sin(q(2))*(dq(1)+dq(2));
    robot.m2*robot.l1*robot.lc2*sin(q(2))*dq(1), 0
];

G_vector = @(q, robot) [
    (robot.m1*robot.lc1 + robot.m2*robot.l1)*robot.g*cos(q(1)) + robot.m2*robot.lc2*robot.g*cos(q(1)+q(2));
    robot.m2*robot.lc2*robot.g*cos(q(1)+q(2))
];

% Simulation parameters
dt = 0.001;
t_end = 10;
t = 0:dt:t_end;
N = length(t);

% Desired trajectory (figure-8 in joint space)
freq = 0.5;
q1_d = 0.5*sin(2*pi*freq*t);
q2_d = 0.8*sin(4*pi*freq*t);
dq1_d = 0.5*2*pi*freq*cos(2*pi*freq*t);
dq2_d = 0.8*4*pi*freq*cos(4*pi*freq*t);
ddq1_d = -0.5*(2*pi*freq)^2*sin(2*pi*freq*t);
ddq2_d = -0.8*(4*pi*freq)^2*sin(4*pi*freq*t);

fprintf('Desired trajectory: Figure-8 pattern in joint space\n');
fprintf('  Frequency: %.1f Hz\n\n', freq);

% PID gains (baseline control)
Kp = diag([50, 30]);
Kd = diag([15, 10]);
Ki = diag([5, 3]);

fprintf('Baseline PID Gains:\n');
fprintf('  Joint 1: Kp=%.0f, Kd=%.0f, Ki=%.0f\n', Kp(1,1), Kd(1,1), Ki(1,1));
fprintf('  Joint 2: Kp=%.0f, Kd=%.0f, Ki=%.0f\n\n', Kp(2,2), Kd(2,2), Ki(2,2));

%% Step 1: Collect Training Data with PID-only Control

fprintf('Step 1: Collecting training data with PID control...\n');

% Initialize states
q_pid = zeros(2, N);
dq_pid = zeros(2, N);
tau_pid = zeros(2, N);
e_int_pid = zeros(2, N);

q_pid(:, 1) = [0; 0];
dq_pid(:, 1) = [0; 0];

% Data collection
for k = 1:N-1
    % Current state
    q = q_pid(:, k);
    dq = dq_pid(:, k);
    
    % Desired state at this time
    qd = [q1_d(k); q2_d(k)];
    dqd = [dq1_d(k); dq2_d(k)];
    
    % Error
    e = qd - q;
    de = dqd - dq;
    
    % Integral error
    if k > 1
        e_int_pid(:, k) = e_int_pid(:, k-1) + e * dt;
    end
    
    % PID control
    tau = Kp*e + Kd*de + Ki*e_int_pid(:, k);
    tau_pid(:, k) = tau;
    
    % Robot dynamics
    M = M_matrix(q, robot);
    C = C_matrix(q, dq, robot);
    G = G_vector(q, robot);
    
    % Acceleration
    ddq = M \ (tau - C*dq - G);
    
    % Euler integration
    dq_pid(:, k+1) = dq + ddq * dt;
    q_pid(:, k+1) = q + dq * dt;
end

% Compute tracking error for PID-only
error_pid = sqrt(mean((q_pid(1,:) - q1_d).^2 + (q_pid(2,:) - q2_d).^2));
fprintf('  PID-only RMSE: %.4f rad\n', error_pid);

%% Step 2: Prepare Training Dataset for Neural Network

fprintf('Step 2: Preparing neural network training data...\n');

% Input: [q1, q2, dq1, dq2, ddq1_d, ddq2_d]
% Output: [tau1, tau2] (inverse dynamics)

% Compute desired accelerations from PID data
ddq1_desired = ddq1_d;
ddq2_desired = ddq2_d;

% Compute ideal torques (inverse dynamics)
tau_ideal = zeros(2, N);
for k = 1:N
    q = q_pid(:, k);
    dq = dq_pid(:, k);
    ddq_d = [ddq1_desired(k); ddq2_desired(k)];
    
    M = M_matrix(q, robot);
    C = C_matrix(q, dq, robot);
    G = G_vector(q, robot);
    
    tau_ideal(:, k) = M*ddq_d + C*dq + G;
end

% Prepare dataset
X_train = [q_pid(1,:); q_pid(2,:); dq_pid(1,:); dq_pid(2,:); ddq1_desired; ddq2_desired]';
Y_train = tau_ideal';

% Normalize data for better training
X_mean = mean(X_train);
X_std = std(X_train);
X_train_norm = (X_train - X_mean) ./ (X_std + 1e-8);

Y_mean = mean(Y_train);
Y_std = std(Y_train);
Y_train_norm = (Y_train - Y_mean) ./ (Y_std + 1e-8);

fprintf('  Training samples: %d\n', size(X_train, 1));
fprintf('  Input dimension: %d\n', size(X_train, 2));
fprintf('  Output dimension: %d\n\n', size(Y_train, 2));

%% Step 3: Design and Train Neural Network

fprintf('Step 3: Training neural network for inverse dynamics...\n');

% Network architecture
hiddenLayers = [32, 32, 16];  % 3 hidden layers

fprintf('  Architecture: [%d', size(X_train, 2));
for i = 1:length(hiddenLayers)
    fprintf('-%d', hiddenLayers(i));
end
fprintf('-%d]\n', size(Y_train, 2));

% Create layer array
layers = [
    featureInputLayer(size(X_train, 2), 'Name', 'input')
    fullyConnectedLayer(hiddenLayers(1), 'Name', 'fc1')
    tanhLayer('Name', 'tanh1')
    fullyConnectedLayer(hiddenLayers(2), 'Name', 'fc2')
    tanhLayer('Name', 'tanh2')
    fullyConnectedLayer(hiddenLayers(3), 'Name', 'fc3')
    tanhLayer('Name', 'tanh3')
    fullyConnectedLayer(size(Y_train, 2), 'Name', 'output')
    regressionLayer('Name', 'regress')
];

% Training options
options = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'MiniBatchSize', 64, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 30, ...
    'Shuffle', 'every-epoch', ...
    'ValidationFrequency', 50, ...
    'Verbose', false, ...
    'Plots', 'none');

% Train network
fprintf('  Training in progress...\n');
tic;
net_robot = trainNetwork(X_train_norm, Y_train_norm, layers, options);
training_time = toc;

fprintf('  Training completed in %.2f seconds\n', training_time);

% Evaluate training performance
Y_pred_norm = predict(net_robot, X_train_norm);
Y_pred = Y_pred_norm .* Y_std + Y_mean;
train_error = sqrt(mean((Y_pred(:) - Y_train(:)).^2));
fprintf('  Training RMSE: %.4f N.m\n\n', train_error);

%% Step 4: Test Hybrid NN+PID Control

fprintf('Step 4: Testing hybrid NN+PID controller...\n');

% Reduced PID gains (NN handles most of the work)
Kp_hybrid = 0.3 * Kp;
Kd_hybrid = 0.3 * Kd;
Ki_hybrid = 0.3 * Ki;

fprintf('  Reduced PID gains (30%% of original)\n');

% Initialize
q_hybrid = zeros(2, N);
dq_hybrid = zeros(2, N);
tau_nn = zeros(2, N);
tau_pid_hybrid = zeros(2, N);
e_int_hybrid = zeros(2, N);

q_hybrid(:, 1) = [0.1; -0.1];  % Different initial condition
dq_hybrid(:, 1) = [0; 0];

% Simulation
for k = 1:N-1
    q = q_hybrid(:, k);
    dq = dq_hybrid(:, k);
    
    qd = [q1_d(k); q2_d(k)];
    dqd = [dq1_d(k); dq2_d(k)];
    ddqd = [ddq1_d(k); ddq2_d(k)];
    
    % Neural network feedforward
    X_current = [q(1), q(2), dq(1), dq(2), ddqd(1), ddqd(2)];
    X_current_norm = (X_current - X_mean) ./ (X_std + 1e-8);
    tau_nn_norm = predict(net_robot, X_current_norm);
    tau_nn(:, k) = (tau_nn_norm .* Y_std + Y_mean)';
    
    % PID feedback
    e = qd - q;
    de = dqd - dq;
    
    if k > 1
        e_int_hybrid(:, k) = e_int_hybrid(:, k-1) + e * dt;
    end
    
    tau_pid_component = Kp_hybrid*e + Kd_hybrid*de + Ki_hybrid*e_int_hybrid(:, k);
    tau_pid_hybrid(:, k) = tau_pid_component;
    
    % Total control
    tau_total = tau_nn(:, k) + tau_pid_component;
    
    % Apply torque limits
    tau_max = 100;
    tau_total = max(-tau_max, min(tau_max, tau_total));
    
    % Robot dynamics
    M = M_matrix(q, robot);
    C = C_matrix(q, dq, robot);
    G = G_vector(q, robot);
    
    ddq = M \ (tau_total - C*dq - G);
    
    % Integration
    dq_hybrid(:, k+1) = dq + ddq * dt;
    q_hybrid(:, k+1) = q + dq * dt;
end

% Compute tracking error
error_hybrid = sqrt(mean((q_hybrid(1,:) - q1_d).^2 + (q_hybrid(2,:) - q2_d).^2));
fprintf('  Hybrid NN+PID RMSE: %.4f rad\n', error_hybrid);
fprintf('  Improvement: %.1f%%\n\n', 100*(error_pid - error_hybrid)/error_pid);

%% Visualization for Robot Control

fprintf('Generating robot control visualizations...\n');

figure('Position', [100, 100, 1600, 1000]);

% Joint 1 tracking
subplot(3,3,1);
plot(t, q1_d, 'k-', 'LineWidth', 2);
hold on;
plot(t, q_pid(1,:), 'r-', 'LineWidth', 1.5);
plot(t, q_hybrid(1,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Joint 1 Angle (rad)');
legend('Desired', 'PID Only', 'NN+PID', 'Location', 'best');
title('Joint 1 Tracking Performance');

% Joint 2 tracking
subplot(3,3,2);
plot(t, q2_d, 'k-', 'LineWidth', 2);
hold on;
plot(t, q_pid(2,:), 'r-', 'LineWidth', 1.5);
plot(t, q_hybrid(2,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Joint 2 Angle (rad)');
legend('Desired', 'PID Only', 'NN+PID', 'Location', 'best');
title('Joint 2 Tracking Performance');

% Tracking errors
subplot(3,3,3);
error_pid_traj = sqrt((q_pid(1,:) - q1_d).^2 + (q_pid(2,:) - q2_d).^2);
error_hybrid_traj = sqrt((q_hybrid(1,:) - q1_d).^2 + (q_hybrid(2,:) - q2_d).^2);
plot(t, error_pid_traj, 'r-', 'LineWidth', 1.5);
hold on;
plot(t, error_hybrid_traj, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Tracking Error (rad)');
legend('PID Only', 'NN+PID', 'Location', 'best');
title('Combined Tracking Error');

% Control torques comparison
subplot(3,3,4);
plot(t, tau_pid(1,:), 'r-', 'LineWidth', 1.5);
hold on;
plot(t, tau_nn(1,:) + tau_pid_hybrid(1,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Torque (N.m)');
legend('PID Only', 'NN+PID', 'Location', 'best');
title('Joint 1 Control Torque');

subplot(3,3,5);
plot(t, tau_pid(2,:), 'r-', 'LineWidth', 1.5);
hold on;
plot(t, tau_nn(2,:) + tau_pid_hybrid(2,:), 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Torque (N.m)');
legend('PID Only', 'NN+PID', 'Location', 'best');
title('Joint 2 Control Torque');

% NN vs PID contribution
subplot(3,3,6);
plot(t, tau_nn(1,:), 'b-', 'LineWidth', 1.5);
hold on;
plot(t, tau_pid_hybrid(1,:), 'g-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Torque (N.m)');
legend('NN Feedforward', 'PID Feedback', 'Location', 'best');
title('Control Decomposition (Joint 1)');

% End-effector trajectory
subplot(3,3,7);
x_pid = robot.l1*cos(q_pid(1,:)) + robot.l2*cos(q_pid(1,:) + q_pid(2,:));
y_pid = robot.l1*sin(q_pid(1,:)) + robot.l2*sin(q_pid(1,:) + q_pid(2,:));
x_hybrid = robot.l1*cos(q_hybrid(1,:)) + robot.l2*cos(q_hybrid(1,:) + q_hybrid(2,:));
y_hybrid = robot.l1*sin(q_hybrid(1,:)) + robot.l2*sin(q_hybrid(1,:) + q_hybrid(2,:));
x_des = robot.l1*cos(q1_d) + robot.l2*cos(q1_d + q2_d);
y_des = robot.l1*sin(q1_d) + robot.l2*sin(q1_d + q2_d);

plot(x_des, y_des, 'k-', 'LineWidth', 2);
hold on;
plot(x_pid, y_pid, 'r-', 'LineWidth', 1.5);
plot(x_hybrid, y_hybrid, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('X (m)');
ylabel('Y (m)');
legend('Desired', 'PID Only', 'NN+PID', 'Location', 'best');
title('End-Effector Trajectory');
axis equal;

% Control effort comparison
subplot(3,3,8);
effort_pid = cumsum(tau_pid(1,:).^2 + tau_pid(2,:).^2) * dt;
effort_hybrid = cumsum((tau_nn(1,:) + tau_pid_hybrid(1,:)).^2 + ...
                        (tau_nn(2,:) + tau_pid_hybrid(2,:)).^2) * dt;
plot(t, effort_pid, 'r-', 'LineWidth', 1.5);
hold on;
plot(t, effort_hybrid, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (s)');
ylabel('Cumulative Energy (Nms)');
legend('PID Only', 'NN+PID', 'Location', 'best');
title('Control Effort');

% Error statistics
subplot(3,3,9);
data_comparison = [error_pid, error_hybrid;
                   max(error_pid_traj), max(error_hybrid_traj);
                   std([q_pid(1,:)-q1_d, q_pid(2,:)-q2_d]), ...
                   std([q_hybrid(1,:)-q1_d, q_hybrid(2,:)-q2_d])];
bar(data_comparison);
set(gca, 'XTickLabel', {'RMSE', 'Max Error', 'Std Dev'});
ylabel('Error (rad)');
legend('PID Only', 'NN+PID', 'Location', 'best');
title('Performance Metrics');
grid on;

sgtitle('Robotic Manipulator: Hybrid NN+PID Control', 'FontSize', 14, 'FontWeight', 'bold');

%% Part 2: Chemical Reactor - Adaptive Gain Scheduling

fprintf('\nPART 2: CHEMICAL REACTOR ADAPTIVE CONTROL\n');
fprintf('===========================================\n\n');

% CSTR parameters
cstr = struct();
cstr.F = 100;            % Flow rate (L/min)
cstr.V = 100;            % Volume (L)
cstr.CA_in = 1.0;        % Inlet concentration (mol/L)
cstr.T_in = 350;         % Inlet temperature (K)
cstr.k0 = 7.2e10;        % Pre-exponential factor (1/min)
cstr.E = 8750;           % Activation energy (K)
cstr.R = 1.987;          % Gas constant (cal/mol.K)
cstr.deltaH = -2e4;      % Heat of reaction (cal/mol)
cstr.rho = 1000;         % Density (g/L)
cstr.Cp = 1;             % Heat capacity (cal/g.K)
cstr.UA = 5e4;           % Heat transfer coeff (cal/min.K)

fprintf('CSTR Parameters:\n');
fprintf('  Volume: %d L\n', cstr.V);
fprintf('  Flow rate: %d L/min\n', cstr.F);
fprintf('  Highly nonlinear Arrhenius kinetics\n\n');

% Simulation setup
dt_cstr = 0.01;
t_end_cstr = 20;
t_cstr = 0:dt_cstr:t_end_cstr;
N_cstr = length(t_cstr);

% Setpoint changes (challenging scenario)
CA_sp = 0.1 * ones(1, N_cstr);
CA_sp(t_cstr > 5) = 0.15;
CA_sp(t_cstr > 10) = 0.08;
CA_sp(t_cstr > 15) = 0.12;

T_sp = 440 * ones(1, N_cstr);
T_sp(t_cstr > 7) = 450;
T_sp(t_cstr > 14) = 435;

fprintf('Testing with multiple setpoint changes\n');
fprintf('  CA setpoints: 0.1   0.15   0.08   0.12 mol/L\n');
fprintf('  T setpoints: 440   450   435 K\n\n');

% Fixed PID baseline
Kp_T_fixed = -500;
Ki_T_fixed = -50;
Kd_T_fixed = -100;

fprintf('Fixed PID gains: Kp=%d, Ki=%d, Kd=%d\n\n', ...
        Kp_T_fixed, Ki_T_fixed, Kd_T_fixed);

% Simulate with fixed PID
CA_fixed = zeros(1, N_cstr);
T_fixed = zeros(1, N_cstr);
Tc_fixed = zeros(1, N_cstr);
e_int_T_fixed = 0;

CA_fixed(1) = 0.5;
T_fixed(1) = 400;

for k = 1:N_cstr-1
    % States
    CA = CA_fixed(k);
    T = T_fixed(k);
    
    % Reaction rate
    k_rxn = cstr.k0 * exp(-cstr.E / (cstr.R * T));
    
    % Error
    e_T = T_sp(k) - T;
    e_int_T_fixed = e_int_T_fixed + e_T * dt_cstr;
    
    if k > 1
        de_T = (e_T - (T_sp(k-1) - T_fixed(k-1))) / dt_cstr;
    else
        de_T = 0;
    end
    
    % PID control
    Tc = Kp_T_fixed*e_T + Ki_T_fixed*e_int_T_fixed + Kd_T_fixed*de_T;
    Tc = max(300, min(500, Tc));  % Saturation
    Tc_fixed(k) = Tc;
    
    % CSTR dynamics
    dCA_dt = cstr.F/cstr.V * (cstr.CA_in - CA) - k_rxn * CA;
    dT_dt = cstr.F/cstr.V * (cstr.T_in - T) + ...
            (-cstr.deltaH)/(cstr.rho*cstr.Cp) * k_rxn * CA - ...
            cstr.UA/(cstr.rho*cstr.Cp*cstr.V) * (T - Tc);
    
    % Integration
    CA_fixed(k+1) = CA + dCA_dt * dt_cstr;
    T_fixed(k+1) = T + dT_dt * dt_cstr;
end

error_T_fixed = sqrt(mean((T_fixed - T_sp).^2));
fprintf('Fixed PID temperature RMSE: %.2f K\n', error_T_fixed);

%% Train NN for Adaptive Gain Scheduling

fprintf('Training NN gain scheduler...\n');

% Collect data for different operating points
n_points = 50;
CA_range = linspace(0.05, 0.5, n_points);
T_range = linspace(400, 460, n_points);

% Generate optimal gains through grid search
X_gain_train = [];
Y_gain_train = [];

fprintf('  Performing grid search for optimal gains...\n');

for i = 1:length(CA_range)
    for j = 1:length(T_range)
        % Operating point
        CA_op = CA_range(i);
        T_op = T_range(j);
        
        % Try different gain combinations
        best_error = inf;
        best_gains = [Kp_T_fixed, Ki_T_fixed, Kd_T_fixed];
        
        % Simple optimization: try variations around baseline
        for kp_mult = [0.5, 1.0, 1.5, 2.0]
            for ki_mult = [0.5, 1.0, 1.5]
                Kp_test = Kp_T_fixed * kp_mult;
                Ki_test = Ki_T_fixed * ki_mult;
                Kd_test = Kd_T_fixed * kp_mult * 0.2;
                
                % Quick simulation to evaluate
                test_error = evaluate_pid_performance_cstr(cstr, ...
                    CA_op, T_op, T_op+5, Kp_test, Ki_test, Kd_test, 0.5, 0.01);
                
                if test_error < best_error
                    best_error = test_error;
                    best_gains = [Kp_test, Ki_test, Kd_test];
                end
            end
        end
        
        % Store data point
        X_gain_train = [X_gain_train; CA_op, T_op, T_op];
        Y_gain_train = [Y_gain_train; best_gains];
    end
end

fprintf('  Collected %d training points\n', size(X_gain_train, 1));

% Normalize
X_gain_mean = mean(X_gain_train);
X_gain_std = std(X_gain_train);
X_gain_norm = (X_gain_train - X_gain_mean) ./ (X_gain_std + 1e-8);

Y_gain_mean = mean(Y_gain_train);
Y_gain_std = std(Y_gain_train);
Y_gain_norm = (Y_gain_train - Y_gain_mean) ./ (Y_gain_std + 1e-8);

% Create and train network
layers_gain = [
    featureInputLayer(3)
    fullyConnectedLayer(20)
    tanhLayer
    fullyConnectedLayer(15)
    tanhLayer
    fullyConnectedLayer(3)
    regressionLayer
];

options_gain = trainingOptions('adam', ...
    'MaxEpochs', 150, ...
    'MiniBatchSize', 32, ...
    'InitialLearnRate', 0.001, ...
    'Verbose', false, ...
    'Plots', 'none');

fprintf('  Training gain scheduling network...\n');
net_gain = trainNetwork(X_gain_norm, Y_gain_norm, layers_gain, options_gain);

fprintf('  Training complete\n\n');

%% Test Adaptive Gain Scheduling

fprintf('Testing adaptive NN gain scheduling...\n');

CA_adaptive = zeros(1, N_cstr);
T_adaptive = zeros(1, N_cstr);
Tc_adaptive = zeros(1, N_cstr);
e_int_T_adaptive = 0;
gains_history = zeros(N_cstr, 3);

CA_adaptive(1) = 0.5;
T_adaptive(1) = 400;

for k = 1:N_cstr-1
    CA = CA_adaptive(k);
    T = T_adaptive(k);
    
    % Get adaptive gains from NN
    X_gain_current = [CA, T, T_sp(k)];
    X_gain_current_norm = (X_gain_current - X_gain_mean) ./ (X_gain_std + 1e-8);
    gains_norm = predict(net_gain, X_gain_current_norm);
    gains = gains_norm .* Y_gain_std + Y_gain_mean;
    
    Kp_adaptive = gains(1);
    Ki_adaptive = gains(2);
    Kd_adaptive = gains(3);
    gains_history(k, :) = gains;
    
    % Reaction rate
    k_rxn = cstr.k0 * exp(-cstr.E / (cstr.R * T));
    
    % Error
    e_T = T_sp(k) - T;
    e_int_T_adaptive = e_int_T_adaptive + e_T * dt_cstr;
    
    if k > 1
        de_T = (e_T - (T_sp(k-1) - T_adaptive(k-1))) / dt_cstr;
    else
        de_T = 0;
    end
    
    % Adaptive PID
    Tc = Kp_adaptive*e_T + Ki_adaptive*e_int_T_adaptive + Kd_adaptive*de_T;
    Tc = max(300, min(500, Tc));
    Tc_adaptive(k) = Tc;
    
    % CSTR dynamics
    dCA_dt = cstr.F/cstr.V * (cstr.CA_in - CA) - k_rxn * CA;
    dT_dt = cstr.F/cstr.V * (cstr.T_in - T) + ...
            (-cstr.deltaH)/(cstr.rho*cstr.Cp) * k_rxn * CA - ...
            cstr.UA/(cstr.rho*cstr.Cp*cstr.V) * (T - Tc);
    
    % Integration
    CA_adaptive(k+1) = CA + dCA_dt * dt_cstr;
    T_adaptive(k+1) = T + dT_dt * dt_cstr;
end

error_T_adaptive = sqrt(mean((T_adaptive - T_sp).^2));
fprintf('  Adaptive NN+PID temperature RMSE: %.2f K\n', error_T_adaptive);
fprintf('  Improvement: %.1f%%\n\n', ...
        100*(error_T_fixed - error_T_adaptive)/error_T_fixed);

%% Visualization for CSTR

fprintf('Generating CSTR visualizations...\n');

figure('Position', [100, 100, 1600, 900]);

% Temperature tracking
subplot(2,3,1);
plot(t_cstr, T_sp, 'k-', 'LineWidth', 2);
hold on;
plot(t_cstr, T_fixed, 'r-', 'LineWidth', 1.5);
plot(t_cstr, T_adaptive, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (min)');
ylabel('Temperature (K)');
legend('Setpoint', 'Fixed PID', 'Adaptive NN+PID', 'Location', 'best');
title('Temperature Control');

% Concentration
subplot(2,3,2);
plot(t_cstr, CA_sp, 'k-', 'LineWidth', 2);
hold on;
plot(t_cstr, CA_fixed, 'r-', 'LineWidth', 1.5);
plot(t_cstr, CA_adaptive, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (min)');
ylabel('Concentration (mol/L)');
legend('Setpoint', 'Fixed PID', 'Adaptive NN+PID', 'Location', 'best');
title('Reactant Concentration');

% Control action
subplot(2,3,3);
plot(t_cstr, Tc_fixed, 'r-', 'LineWidth', 1.5);
hold on;
plot(t_cstr, Tc_adaptive, 'b-', 'LineWidth', 1.5);
grid on;
xlabel('Time (min)');
ylabel('Coolant Temp (K)');
legend('Fixed PID', 'Adaptive NN+PID', 'Location', 'best');
title('Control Action');

% Adaptive gain evolution
subplot(2,3,4);
plot(t_cstr, gains_history(:,1), 'LineWidth', 1.5);
hold on;
yline(Kp_T_fixed, 'r-', 'LineWidth', 2);
grid on;
xlabel('Time (min)');
ylabel('K_p');
legend('Adaptive', 'Fixed', 'Location', 'best');
title('Proportional Gain Adaptation');

subplot(2,3,5);
plot(t_cstr, gains_history(:,2), 'LineWidth', 1.5);
hold on;
yline(Ki_T_fixed, 'r-', 'LineWidth', 2);
grid on;
xlabel('Time (min)');
ylabel('K_i');
legend('Adaptive', 'Fixed', 'Location', 'best');
title('Integral Gain Adaptation');

subplot(2,3,6);
plot(t_cstr, gains_history(:,3), 'LineWidth', 1.5);
hold on;
yline(Kd_T_fixed, 'r-', 'LineWidth', 2);
grid on;
xlabel('Time (min)');
ylabel('K_d');
legend('Adaptive', 'Fixed', 'Location', 'best');
title('Derivative Gain Adaptation');

sgtitle('Chemical Reactor: Adaptive Gain Scheduling', 'FontSize', 14, 'FontWeight', 'bold');

%% Performance Summary

fprintf('\n=== PERFORMANCE SUMMARY ===\n\n');

fprintf('Robotic Manipulator:\n');
fprintf('  PID-only tracking RMSE: %.4f rad\n', error_pid);
fprintf('  NN+PID tracking RMSE: %.4f rad\n', error_hybrid);
fprintf('  Improvement: %.1f%%\n', 100*(error_pid-error_hybrid)/error_pid);
fprintf('  NN reduced PID gains to 30%% of original\n\n');

fprintf('Chemical Reactor:\n');
fprintf('  Fixed PID RMSE: %.2f K\n', error_T_fixed);
fprintf('  Adaptive NN+PID RMSE: %.2f K\n', error_T_adaptive);
fprintf('  Improvement: %.1f%%\n', ...
        100*(error_T_fixed-error_T_adaptive)/error_T_fixed);
fprintf('  NN adapts gains in real-time to operating point\n\n');

fprintf('=== KEY INSIGHTS ===\n\n');
fprintf('1. Neural Networks excel at handling nonlinearities\n');
fprintf('2. PID provides robustness and stability guarantees\n');
fprintf('3. Hybrid approach combines best of both worlds\n');
fprintf('4. Feedforward NN + feedback PID is highly effective\n');
fprintf('5. Adaptive gain scheduling handles varying conditions\n');
fprintf('6. Reduced PID gains   smoother control, less saturation\n');
fprintf('7. Safety ensured by PID backup mechanism\n\n');

fprintf('All simulations complete!\n');

%% Helper Function
function error = evaluate_pid_performance_cstr(cstr, CA0, T0, Tsp, Kp, Ki, Kd, duration, dt)
    % Quick evaluation of PID performance for gain tuning
    t_eval = 0:dt:duration;
    N_eval = length(t_eval);
    
    CA = CA0;
    T = T0;
    e_int = 0;
    e_prev = Tsp - T0;
    
    errors = zeros(1, N_eval);
    
    for k = 1:N_eval
        k_rxn = cstr.k0 * exp(-cstr.E / (cstr.R * T));
        
        e = Tsp - T;
        e_int = e_int + e * dt;
        de = (e - e_prev) / dt;
        e_prev = e;
        
        Tc = Kp*e + Ki*e_int + Kd*de;
        Tc = max(300, min(500, Tc));
        
        dCA_dt = cstr.F/cstr.V * (cstr.CA_in - CA) - k_rxn * CA;
        dT_dt = cstr.F/cstr.V * (cstr.T_in - T) + ...
                (-cstr.deltaH)/(cstr.rho*cstr.Cp) * k_rxn * CA - ...
                cstr.UA/(cstr.rho*cstr.Cp*cstr.V) * (T - Tc);
        
        CA = CA + dCA_dt * dt;
        T = T + dT_dt * dt;
        
        errors(k) = abs(e);
    end
    
    error = mean(errors);
end
