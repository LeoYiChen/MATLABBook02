%% prob1_code.m
% Comprehensive statistical analysis of tensile strength data.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob1_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Statistical Analysis: Tensile Strength Data
% File: MATLABBook02_Chapter07_Problem01.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Performs comprehensive statistical analysis on experimental
%              tensile strength measurements including distribution fitting,
%              outlier detection, and quality control assessment
% =========================================================================

function MATLABBook02_Chapter07_Problem01()
    % Main function for Problem 1: Statistical Analysis
    
    clc; clear; close all;
    
    % Generate simulated tensile strength data (MPa)
    % Realistic values for heat-treated steel: mean=450 MPa, std=25 MPa
    rng(42); % Set random seed for reproducibility
    numSpecimens = 50;
    yieldStrength = 450 + 25 * randn(numSpecimens, 1);
    
    % Introduce controlled outliers (2 specimens with defects)
    yieldStrength([5, 38]) = [380, 520];
    
    % Calculate descriptive statistics
    stats = calculateDescriptiveStatistics(yieldStrength);
    
    % Display statistical summary
    displayStatisticalSummary(stats);
    
    % Create comprehensive visualisation
    createStatisticalVisualisation(yieldStrength, stats);
    
    % Perform outlier detection
    outliers = detectOutliers(yieldStrength, stats);
    
    % Calculate process capability
    [Cp, Cpk] = calculateProcessCapability(yieldStrength, 400, 500);
    
    % Display process capability results
    fprintf('\n=== Process Capability Analysis ===\n');
    fprintf('Lower Specification Limit (LSL): 400 MPa\n');
    fprintf('Upper Specification Limit (USL): 500 MPa\n');
    fprintf('Process Capability Index (Cp): %.4f\n', Cp);
    fprintf('Process Capability Index (Cpk): %.4f\n', Cpk);
    
    if Cpk >= 1.33
        fprintf('Process Assessment: CAPABLE (Cpk >= 1.33)\n');
    elseif Cpk >= 1.00
        fprintf('Process Assessment: MARGINALLY CAPABLE (1.00 <= Cpk < 1.33)\n');
    else
        fprintf('Process Assessment: NOT CAPABLE (Cpk < 1.00)\n');
    end
end

function stats = calculateDescriptiveStatistics(data)
    % CALCULATEDESCRIPTIVESTATISTICS - Computes comprehensive statistics
    %
    % Inputs:
    %   data - Column vector of numerical measurements
    %
    % Outputs:
    %   stats - Structure containing statistical measures
    
    stats.mean = mean(data);
    stats.median = median(data);
    stats.std = std(data);
    stats.variance = var(data);
    stats.min = min(data);
    stats.max = max(data);
    stats.range = stats.max - stats.min;
    stats.Q1 = quantile(data, 0.25);
    stats.Q3 = quantile(data, 0.75);
    stats.IQR = stats.Q3 - stats.Q1;
    stats.skewness = skewness(data);
    stats.kurtosis = kurtosis(data);
    stats.n = length(data);
end

function displayStatisticalSummary(stats)
    % DISPLAYSTATICALSUMMARY - Formats and displays statistical results
    
    fprintf('\n========================================\n');
    fprintf('   STATISTICAL SUMMARY: YIELD STRENGTH\n');
    fprintf('========================================\n');
    fprintf('Sample Size (n):           %d\n', stats.n);
    fprintf('Mean:                      %.2f MPa\n', stats.mean);
    fprintf('Median:                    %.2f MPa\n', stats.median);
    fprintf('Standard Deviation:        %.2f MPa\n', stats.std);
    fprintf('Variance:                  %.2f MPa^2\n', stats.variance);
    fprintf('Minimum:                   %.2f MPa\n', stats.min);
    fprintf('Maximum:                   %.2f MPa\n', stats.max);
    fprintf('Range:                     %.2f MPa\n', stats.range);
    fprintf('First Quartile (Q1):       %.2f MPa\n', stats.Q1);
    fprintf('Third Quartile (Q3):       %.2f MPa\n', stats.Q3);
    fprintf('Interquartile Range (IQR): %.2f MPa\n', stats.IQR);
    fprintf('Skewness:                  %.4f\n', stats.skewness);
    fprintf('Kurtosis:                  %.4f\n', stats.kurtosis);
    fprintf('========================================\n');
end

function createStatisticalVisualisation(data, stats)
    % CREATESTATISTICALVISUALISATION - Generates comprehensive plots
    
    figure('Name', 'Statistical Analysis: Tensile Strength', ...
           'Position', [100, 100, 1400, 800]);
    
    % Subplot 1: Histogram with normal distribution overlay
    subplot(2, 3, 1);
    histogram(data, 'NumBins', 12, 'Normalization', 'pdf', ...
             'FaceColor', [0.3, 0.6, 0.9], 'EdgeColor', 'k', 'LineWidth', 1);
    hold on;
    
    % Generate theoretical normal distribution
    xRange = linspace(stats.min - 20, stats.max + 20, 200);
    normalPDF = normpdf(xRange, stats.mean, stats.std);
    plot(xRange, normalPDF, 'r-', 'LineWidth', 2.5);
    
    xlabel('Yield Strength (MPa)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Probability Density', 'Interpreter', 'latex', 'FontSize', 11);
    title('Histogram with Normal Distribution Fit', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    legend({'Experimental Data', 'Normal Distribution'}, 'Location', 'northwest');
    grid on;
    set(gca, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 2: Box plot
    subplot(2, 3, 2);
    boxplot(data, 'Orientation', 'horizontal', 'Colors', [0.3, 0.6, 0.9], ...
           'Symbol', 'ro', 'Widths', 0.5);
    xlabel('Yield Strength (MPa)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Box Plot with Outlier Detection', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    set(gca, 'LineWidth', 1.2, 'YTickLabel', {});
    
    % Subplot 3: Normal probability plot
    subplot(2, 3, 3);
    normplot(data);
    title('Normal Probability Plot', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    xlabel('Yield Strength (MPa)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Probability', 'Interpreter', 'latex', 'FontSize', 11);
    grid on;
    set(gca, 'LineWidth', 1.2);
    
    % Subplot 4: Cumulative distribution function
    subplot(2, 3, 4);
    [f, x] = ecdf(data);
    stairs(x, f, 'LineWidth', 2, 'Color', [0.3, 0.6, 0.9]);
    hold on;
    plot(xRange, normcdf(xRange, stats.mean, stats.std), 'r-', 'LineWidth', 2);
    xlabel('Yield Strength (MPa)', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Cumulative Probability', 'Interpreter', 'latex', 'FontSize', 11);
    title('Empirical vs. Theoretical CDF', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    legend({'Empirical CDF', 'Normal CDF'}, 'Location', 'southeast');
    grid on;
    set(gca, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 5: Scatter plot with statistical markers
    subplot(2, 3, 5);
    specimenNumbers = 1:stats.n;
    scatter(specimenNumbers, data, 50, 'filled', 'MarkerFaceColor', [0.3, 0.6, 0.9]);
    hold on;
    yline(stats.mean, 'r-', 'LineWidth', 2, 'Label', '$\mu$', ...
          'Interpreter', 'latex', 'FontSize', 12);
    yline(stats.mean + stats.std, 'g-', 'LineWidth', 1.5, ...
          'Label', '$\mu + \sigma$', 'Interpreter', 'latex', 'FontSize', 10);
    yline(stats.mean - stats.std, 'g-', 'LineWidth', 1.5, ...
          'Label', '$\mu - \sigma$', 'Interpreter', 'latex', 'FontSize', 10);
    xlabel('Specimen Number', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Yield Strength (MPa)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Individual Measurements with Statistical Bounds', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    grid on;
    set(gca, 'LineWidth', 1.2);
    hold off;
    
    % Subplot 6: Violin plot (density distribution)
    subplot(2, 3, 6);
    [density, value] = ksdensity(data);
    fill([density, -fliplr(density)], [value, fliplr(value)], ...
         [0.3, 0.6, 0.9], 'FaceAlpha', 0.6, 'EdgeColor', 'k', 'LineWidth', 1.5);
    hold on;
    plot([0, 0], [stats.min, stats.max], 'k-', 'LineWidth', 2);
    scatter(zeros(size(data)), data, 20, 'r', 'filled', 'MarkerFaceAlpha', 0.3);
    ylabel('Yield Strength (MPa)', 'Interpreter', 'latex', 'FontSize', 11);
    title('Violin Plot: Density Distribution', 'Interpreter', 'latex', ...
          'FontSize', 12, 'FontWeight', 'bold');
    xlim([-max(density)*1.2, max(density)*1.2]);
    set(gca, 'XTick', [], 'LineWidth', 1.2);
    grid on;
    hold off;
end

function outlierIndices = detectOutliers(data, stats)
    % DETECTOUTLIERS - Identifies outliers using IQR method
    %
    % Tukey's method: outliers beyond Q1-1.5*IQR or Q3+1.5*IQR
    
    lowerBound = stats.Q1 - 1.5 * stats.IQR;
    upperBound = stats.Q3 + 1.5 * stats.IQR;
    
    outlierIndices = find(data < lowerBound | data > upperBound);
    
    fprintf('\n=== Outlier Detection (Tukey Method) ===\n');
    fprintf('Lower Bound: %.2f MPa\n', lowerBound);
    fprintf('Upper Bound: %.2f MPa\n', upperBound);
    fprintf('Number of Outliers: %d\n', length(outlierIndices));
    
    if ~isempty(outlierIndices)
        fprintf('Outlier Specimen Numbers: ');
        fprintf('%d ', outlierIndices);
        fprintf('\nOutlier Values (MPa): ');
        fprintf('%.2f ', data(outlierIndices));
        fprintf('\n');
    end
end

function [Cp, Cpk] = calculateProcessCapability(data, LSL, USL)
    % CALCULATEPROCESSCAPABILITY - Computes process capability indices
    %
    % Inputs:
    %   data - Process measurements
    %   LSL - Lower Specification Limit
    %   USL - Upper Specification Limit
    %
    % Outputs:
    %   Cp - Process Capability Index (measures spread)
    %   Cpk - Process Capability Index (measures centering and spread)
    
    mu = mean(data);
    sigma = std(data);
    
    % Process capability (assumes centered process)
    Cp = (USL - LSL) / (6 * sigma);
    
    % Process capability accounting for centering
    Cpu = (USL - mu) / (3 * sigma);
    Cpl = (mu - LSL) / (3 * sigma);
    Cpk = min(Cpu, Cpl);
end
