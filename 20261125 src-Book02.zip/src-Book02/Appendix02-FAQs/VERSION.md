# VERSION - Appendix02-FAQs

| Field | Value |
| --- | --- |
| Package | `src-Book02/Appendix02-FAQs` |
| Version | 1.1.0 |
| Release date | 2026-11-10 |
| Release stamp | `Book02-src-Appendix02-FAQs-1.1.0-20261110` |
| Source manuscript | `P02-20261027` |
| SHA-256 ledger | `MANIFEST.sha256` |
| Files | 71 |

## Release notes

### 1.1.0 (2026-11-10)

- Package version metadata aligned to 1.1.0.
- Provenance headers updated to 1.1.0; SHA-256 ledger regenerated.

### 1.0.0 (2026-11-10)

- Initial extraction. 71 code environments (71 `lstlisting`,
  0 `verbatim`, 0 `\lstinputlisting`)
  comprising 8,195 lines were removed from the chapter and
  deposited here under their listing labels.
- All original `lstlisting` labels were preserved in the manuscript through
  the `\sourcecode` macro, which steps the `lstlisting` counter and re-issues
  the label. No in-text cross-reference was broken.
- Repository: `https://github.com/LeoYiChen/MATLABBook02`.

## Provenance and compatibility

The code is reproduced verbatim from the manuscript listings; it has not been
rewritten, executed or validated as part of this relocation. Toolbox and
MATLAB-version requirements, where relevant, are stated in the chapter text
and in the comments of the individual files. No toolchain claim is made here.

## Integrity

`MANIFEST.sha256` lists SHA-256 digests for every code file. Verify with:

```bash
cd src-Book02/Appendix02-FAQs && sha256sum -c MANIFEST.sha256
```
