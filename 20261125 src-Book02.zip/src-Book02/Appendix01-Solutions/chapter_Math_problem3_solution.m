%% chapter_Math_problem3_solution.m
% Complete matrix analysis solution.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_Math_problem3_solution
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function Problem3_MatrixOperations()
    % PROBLEM3_MATRIXOPERATIONS Comprehensive matrix analysis
    %
    % This function performs detailed analysis of a 3뿯½3 matrix including:
    % - Determinant computation (multiple methods)
    % - Matrix inverse and verification
    % - Eigenvalue/eigenvector analysis
    % - Matrix norms and condition number
    % - Matrix decompositions (LU, QR, SVD)
    % - Geometric interpretation
    % - Numerical stability assessment
    %
    % Author: Dr Yi Chen
    % Date: 2025
    % MATLAB Version: R2023b or later
    
    fprintf('\n=== Problem 3: Matrix Operations and Determinants ===\n\n');
    
    % Define the matrix
    A = [2, 1, -1; 
         -3, -1, 2; 
         -2, 1, 2];
    
    fprintf('Matrix A:\n');
    disp(A);
    
    % Determinant analysis
    fprintf('\n=== Determinant Computation ===\n\n');
    analyseDeterminant(A);
    
    % Matrix inverse
    fprintf('\n=== Matrix Inverse ===\n\n');
    A_inv = analyseInverse(A);
    
    % Eigenvalue analysis
    fprintf('\n=== Eigenvalue Analysis ===\n\n');
    [eigenvalues, eigenvectors] = analyseEigenvalues(A);
    
    % Matrix norms
    fprintf('\n=== Matrix Norms ===\n\n');
    analyseNorms(A);
    
    % Condition number
    fprintf('\n=== Condition Number ===\n\n');
    analyseConditionNumber(A, A_inv);
    
    % Matrix decompositions
    fprintf('\n=== Matrix Decompositions ===\n\n');
    performDecompositions(A);
    
    % Geometric interpretation
    fprintf('\n=== Geometric Interpretation ===\n\n');
    visualizeTransformation(A);
    
    % Special properties
    fprintf('\n=== Special Properties ===\n\n');
    checkSpecialProperties(A);
    
    % Applications
    fprintf('\n=== Applications ===\n\n');
    demonstrateApplications(A, eigenvalues, eigenvectors);
    
    fprintf('\nAnalysis complete!\n');
end

function analyseDeterminant(A)
    % ANALYSEDETERMINANT Compute determinant using multiple methods
    
    fprintf('Computing determinant using different methods:\n\n');
    
    % Method 1: MATLAB built-in
    tic;
    det_matlab = det(A);
    time_matlab = toc;
    fprintf('Method 1: MATLAB det() function\n');
    fprintf('  det(A) = %.10f\n', det_matlab);
    fprintf('  Time: %.6f seconds\n\n', time_matlab);
    
    % Method 2: Cofactor expansion along first row
    tic;
    det_cofactor = cofactorExpansion(A);
    time_cofactor = toc;
    fprintf('Method 2: Cofactor expansion (first row)\n');
    fprintf('  det(A) = %.10f\n', det_cofactor);
    fprintf('  Time: %.6f seconds\n', time_cofactor);
    fprintf('  Difference from MATLAB: %.2e\n\n', abs(det_cofactor - det_matlab));
    
    % Method 3: Using LU decomposition
    tic;
    [L, U, P] = lu(A);
    % det(P*A) = det(L)*det(U) = product of U diagonal elements
    % det(P) = 뿯½1, so det(A) = 뿯½det(L)*det(U)
    det_lu = prod(diag(U)) * det(P);
    time_lu = toc;
    fprintf('Method 3: LU decomposition\n');
    fprintf('  det(A) = %.10f\n', det_lu);
    fprintf('  Time: %.6f seconds\n', time_lu);
    fprintf('  Difference from MATLAB: %.2e\n\n', abs(det_lu - det_matlab));
    
    % Physical interpretation
    fprintf('Physical Interpretation:\n');
    if det_matlab > 0
        fprintf('  Determinant is POSITIVE 뿯↽ transformation preserves orientation\n');
    elseif det_matlab < 0
        fprintf('  Determinant is NEGATIVE 뿯↽ transformation reverses orientation\n');
    else
        fprintf('  Determinant is ZERO 뿯↽ transformation collapses space\n');
    end
    fprintf('  Volume scaling factor: |det(A)| = %.6f\n', abs(det_matlab));
    fprintf('  Unit cube 뿯↽ volume = %.6f cubic units\n', abs(det_matlab));
end

function det_val = cofactorExpansion(A)
    % COFACTOREXPANSION Compute determinant using cofactor expansion
    %
    % For 3뿯½3 matrix, expand along first row:
    % det(A) = a11*C11 + a12*C12 + a13*C13
    
    n = size(A, 1);
    
    if n == 2
        % Base case: 2뿯½2 determinant
        det_val = A(1,1)*A(2,2) - A(1,2)*A(2,1);
    else
        % Recursive case: expand along first row
        det_val = 0;
        for j = 1:n
            % Create minor by removing row 1 and column j
            minor = A([2:n], [1:j-1, j+1:n]);
            % Cofactor with sign (-1)^(1+j)
            cofactor = (-1)^(1+j) * cofactorExpansion(minor);
            % Add contribution
            det_val = det_val + A(1,j) * cofactor;
        end
    end
end

function A_inv = analyseInverse(A)
    % ANALYSEINVERSE Compute and verify matrix inverse
    
    det_A = det(A);
    
    fprintf('Checking invertibility:\n');
    fprintf('  det(A) = %.10f\n', det_A);
    
    if abs(det_A) < 1e-10
        fprintf('  Matrix is SINGULAR (not invertible)\n');
        fprintf('  Columns are linearly dependent\n');
        A_inv = [];
        return;
    else
        fprintf('  Matrix is INVERTIBLE (non-singular)\n\n');
    end
    
    % Method 1: MATLAB inv()
    A_inv = inv(A);
    fprintf('Inverse Matrix A^(-1):\n');
    disp(A_inv);
    
    % Method 2: Using adjugate matrix
    A_inv_adj = adjugateMethod(A, det_A);
    fprintf('Inverse via adjugate matrix:\n');
    disp(A_inv_adj);
    fprintf('Difference: %.2e\n\n', norm(A_inv - A_inv_adj, 'fro'));
    
    % Verification
    fprintf('Verification:\n');
    I_check = A * A_inv;
    fprintf('  A * A^(-1):\n');
    disp(I_check);
    
    error_from_identity = norm(I_check - eye(3), 'fro');
    fprintf('  ||A*A^(-1) - I||_F = %.2e\n', error_from_identity);
    
    if error_from_identity < 1e-10
        fprintf('  ✓ Verification successful (within numerical tolerance)\n');
    else
        fprintf('  ✗ Warning: Large deviation from identity!\n');
    end
end

function A_inv = adjugateMethod(A, det_A)
    % ADJUGATEMETHOD Compute inverse using adjugate matrix formula
    %
    % A^(-1) = (1/det(A)) * adj(A)
    % where adj(A) is transpose of cofactor matrix
    
    n = size(A, 1);
    C = zeros(n);
    
    % Compute cofactor matrix
    for i = 1:n
        for j = 1:n
            % Minor: remove row i and column j
            minor = A([1:i-1, i+1:n], [1:j-1, j+1:n]);
            % Cofactor with sign (-1)^(i+j)
            C(i,j) = (-1)^(i+j) * det(minor);
        end
    end
    
    % Adjugate is transpose of cofactor matrix
    adj_A = C';
    
    % Inverse formula
    A_inv = adj_A / det_A;
end

function [eigenvalues, eigenvectors] = analyseEigenvalues(A)
    % ANALYSEEIGENVALUES Compute and analyse eigenvalues/eigenvectors
    
    % Compute eigenvalues and eigenvectors
    [V, D] = eig(A);
    eigenvalues = diag(D);
    eigenvectors = V;
    
    fprintf('Eigenvalues:\n');
    for i = 1:length(eigenvalues)
        if isreal(eigenvalues(i))
            fprintf('  뿯ν_%d = %.6f (real)\n', i, eigenvalues(i));
        else
            fprintf('  뿯ν_%d = %.6f %+.6fi (complex)\n', i, ...
                real(eigenvalues(i)), imag(eigenvalues(i)));
        end
    end
    fprintf('\n');
    
    fprintf('Eigenvectors (column-wise):\n');
    disp(eigenvectors);
    
    % Verify eigenvalue equation: A*v = 뿯ν*v
    fprintf('Verification (A*v = 뿯ν*v):\n');
    for i = 1:length(eigenvalues)
        v = eigenvectors(:, i);
        lambda = eigenvalues(i);
        
        Av = A * v;
        lambda_v = lambda * v;
        
        error = norm(Av - lambda_v);
        fprintf('  Eigenvector %d: ||A*v - 뿯ν*v|| = %.2e\n', i, error);
    end
    fprintf('\n');
    
    % Properties
    trace_A = trace(A);
    sum_eigenvalues = sum(eigenvalues);
    det_A = det(A);
    prod_eigenvalues = prod(eigenvalues);
    
    fprintf('Eigenvalue Properties:\n');
    fprintf('  trace(A) = %.6f\n', trace_A);
    fprintf('  sum(뿯ν_i) = %.6f\n', sum_eigenvalues);
    fprintf('  Difference: %.2e ✓\n\n', abs(trace_A - sum_eigenvalues));
    
    fprintf('  det(A) = %.6f\n', det_A);
    fprintf('  prod(뿯ν_i) = %.6f\n', prod_eigenvalues);
    fprintf('  Difference: %.2e ✓\n', abs(det_A - prod_eigenvalues));
end

function analyseNorms(A)
    % ANALYSENORMS Compute various matrix norms
    
    % Frobenius norm (element-wise)
    norm_F = norm(A, 'fro');
    norm_F_manual = sqrt(sum(A(:).^2));
    
    % Infinity norm (max row sum)
    norm_inf = norm(A, inf);
    norm_inf_manual = max(sum(abs(A), 2));
    
    % 1-norm (max column sum)
    norm_1 = norm(A, 1);
    norm_1_manual = max(sum(abs(A), 1));
    
    % 2-norm (spectral norm = largest singular value)
    norm_2 = norm(A, 2);
    singular_values = svd(A);
    norm_2_manual = max(singular_values);
    
    fprintf('Matrix Norms:\n\n');
    
    fprintf('Frobenius norm ||A||_F:\n');
    fprintf('  MATLAB norm(A,''fro'') = %.6f\n', norm_F);
    fprintf('  Manual calculation = %.6f\n', norm_F_manual);
    fprintf('  Formula: sqrt(sum of all squared elements)\n\n');
    
    fprintf('Infinity norm ||A||_∞:\n');
    fprintf('  MATLAB norm(A,inf) = %.6f\n', norm_inf);
    fprintf('  Manual calculation = %.6f\n', norm_inf_manual);
    fprintf('  Formula: max row sum = max_i sum_j |a_ij|\n');
    fprintf('  Row sums: [%.2f, %.2f, %.2f]\n', sum(abs(A), 2));
    fprintf('\n');
    
    fprintf('1-norm ||A||_1:\n');
    fprintf('  MATLAB norm(A,1) = %.6f\n', norm_1);
    fprintf('  Manual calculation = %.6f\n', norm_1_manual);
    fprintf('  Formula: max column sum = max_j sum_i |a_ij|\n');
    fprintf('  Column sums: [%.2f, %.2f, %.2f]\n', sum(abs(A), 1));
    fprintf('\n');
    
    fprintf('2-norm (spectral) ||A||_2:\n');
    fprintf('  MATLAB norm(A,2) = %.6f\n', norm_2);
    fprintf('  Manual (max singular value) = %.6f\n', norm_2_manual);
    fprintf('  Formula: largest singular value of A\n');
end

function analyseConditionNumber(A, A_inv)
    % ANALYSECONDITIONUMBER Analyse matrix conditioning
    
    % Condition numbers in different norms
    kappa_2 = cond(A, 2);    % Default (2-norm)
    kappa_F = cond(A, 'fro'); % Frobenius
    kappa_1 = cond(A, 1);     % 1-norm
    kappa_inf = cond(A, inf); % Infinity norm
    
    % Manual calculation for 2-norm
    singular_values = svd(A);
    kappa_2_manual = max(singular_values) / min(singular_values);
    
    fprintf('Condition Numbers:\n\n');
    
    fprintf('뿯ν_2(A) [2-norm condition number]:\n');
    fprintf('  MATLAB cond(A) = %.6f\n', kappa_2);
    fprintf('  Manual (뿯ν_max/뿯ν_min) = %.6f\n', kappa_2_manual);
    fprintf('  Formula: ||A||_2 * ||A^(-1)||_2 = 뿯ν_max/뿯ν_min\n\n');
    
    fprintf('Other condition numbers:\n');
    fprintf('  뿯ν_F(A) = %.6f\n', kappa_F);
    fprintf('  뿯ν_1(A) = %.6f\n', kappa_1);
    fprintf('  뿯ν_∞(A) = %.6f\n\n', kappa_inf);
    
    % Interpretation
    fprintf('Interpretation:\n');
    if kappa_2 < 10
        fprintf('  뿯ν ≈ %.1f < 10: WELL-CONDITIONED\n', kappa_2);
        fprintf('  뿯↽ Matrix operations are numerically stable\n');
        fprintf('  뿯↽ Small input errors 뿯↽ small output errors\n');
    elseif kappa_2 < 100
        fprintf('  뿯ν ≈ %.1f: MODERATELY CONDITIONED\n', kappa_2);
        fprintf('  뿯↽ Acceptable for most practical computations\n');
        fprintf('  뿯↽ Expect to lose ~%.0f decimal digits\n', log10(kappa_2));
    elseif kappa_2 < 1000
        fprintf('  뿯ν ≈ %.1f: POORLY CONDITIONED\n', kappa_2);
        fprintf('  뿯↽ Numerical instability likely\n');
        fprintf('  뿯↽ May lose ~%.0f decimal digits of accuracy\n', log10(kappa_2));
    else
        fprintf('  뿯ν ≈ %.2e: ILL-CONDITIONED\n', kappa_2);
        fprintf('  뿯↽ Severe numerical instability\n');
        fprintf('  뿯↽ Results may be meaningless!\n');
    end
    
    fprintf('\n  Error amplification factor: %.2f\n', kappa_2);
    fprintf('  Relative error in solution ≤ 뿯ν * (relative error in data)\n');
    
    % Perturbation analysis
    fprintf('\nPerturbation Analysis:\n');
    epsilon = 1e-6;
    A_pert = A + epsilon * randn(size(A));
    x_exact = [1; 2; 3];
    b = A * x_exact;
    b_pert = A_pert * x_exact;
    
    relative_input_error = norm(b_pert - b) / norm(b);
    x_computed = A \ b_pert;
    relative_output_error = norm(x_computed - x_exact) / norm(x_exact);
    
    actual_amplification = relative_output_error / relative_input_error;
    
    fprintf('  Input perturbation: %.2e (relative)\n', relative_input_error);
    fprintf('  Output error: %.2e (relative)\n', relative_output_error);
    fprintf('  Actual amplification: %.2f\n', actual_amplification);
    fprintf('  Theoretical bound (뿯ν): %.2f\n', kappa_2);
    fprintf('  Amplification ≤ 뿯ν: %s\n', ...
        ternary(actual_amplification <= kappa_2, 'YES ✓', 'NO ✗'));
end

function performDecompositions(A)
    % PERFORMDECOMPOSITIONS Compute and verify matrix decompositions
    
    %% LU Decomposition
    fprintf('LU Decomposition: A = L*U\n');
    [L, U, P] = lu(A);
    
    fprintf('  Lower triangular L:\n');
    disp(L);
    fprintf('  Upper triangular U:\n');
    disp(U);
    fprintf('  Permutation P:\n');
    disp(P);
    
    % Verification
    LU_product = L * U;
    PA = P * A;
    error_LU = norm(PA - LU_product, 'fro');
    fprintf('  Verification: ||P*A - L*U||_F = %.2e\n\n', error_LU);
    
    %% QR Decomposition
    fprintf('QR Decomposition: A = Q*R\n');
    [Q, R] = qr(A);
    
    fprintf('  Orthogonal Q:\n');
    disp(Q);
    fprintf('  Upper triangular R:\n');
    disp(R);
    
    % Check orthogonality
    QtQ = Q' * Q;
    error_ortho = norm(QtQ - eye(3), 'fro');
    fprintf('  Orthogonality: ||Q''*Q - I||_F = %.2e\n', error_ortho);
    
    % Verification
    QR_product = Q * R;
    error_QR = norm(A - QR_product, 'fro');
    fprintf('  Verification: ||A - Q*R||_F = %.2e\n\n', error_QR);
    
    %% Singular Value Decomposition
    fprintf('Singular Value Decomposition: A = U*뿯ν*V''\n');
    [U, S, V] = svd(A);
    
    fprintf('  Left singular vectors U:\n');
    disp(U);
    fprintf('  Singular values 뿯ν:\n');
    disp(S);
    fprintf('  Right singular vectors V:\n');
    disp(V);
    
    singular_values = diag(S);
    fprintf('  Singular values: [%.6f, %.6f, %.6f]\n', singular_values);
    fprintf('  Condition number: 뿯ν_max/뿯ν_min = %.6f\n', ...
        max(singular_values)/min(singular_values));
    fprintf('  Matrix rank: %d (number of non-zero singular values)\n', ...
        rank(A));
    
    % Verification
    USVt = U * S * V';
    error_SVD = norm(A - USVt, 'fro');
    fprintf('  Verification: ||A - U*뿯ν*V''||_F = %.2e\n', error_SVD);
end

function visualizeTransformation(A)
    % VISUALIZETRANSFORMATION Geometric interpretation of matrix transformation
    
    figure('Position', [100, 100, 1400, 600], 'Name', ...
        'Matrix Transformation Visualization');
    
    % Generate unit sphere points
    [x, y, z] = sphere(30);
    sphere_points = [x(:), y(:), z(:)]';
    
    % Apply transformation
    transformed_points = A * sphere_points;
    
    % Reshape back
    x_t = reshape(transformed_points(1,:), size(x));
    y_t = reshape(transformed_points(2,:), size(y));
    z_t = reshape(transformed_points(3,:), size(z));
    
    % Subplot 1: Original unit sphere
    subplot(1, 3, 1);
    surf(x, y, z, 'FaceAlpha', 0.7, 'EdgeColor', 'none');
    hold on;
    
    % Draw axes
    quiver3(0,0,0,1.5,0,0,'r','LineWidth',2);
    quiver3(0,0,0,0,1.5,0,'g','LineWidth',2);
    quiver3(0,0,0,0,0,1.5,'b','LineWidth',2);
    
    axis equal;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$z$', 'Interpreter', 'latex');
    title('Unit Sphere (Input)', 'Interpreter', 'latex');
    view(45, 30);
    
    % Subplot 2: Transformed ellipsoid
    subplot(1, 3, 2);
    surf(x_t, y_t, z_t, 'FaceAlpha', 0.7, 'EdgeColor', 'none');
    hold on;
    
    % Draw transformed axes
    e1 = A * [1.5; 0; 0];
    e2 = A * [0; 1.5; 0];
    e3 = A * [0; 0; 1.5];
    
    quiver3(0,0,0,e1(1),e1(2),e1(3),'r','LineWidth',2);
    quiver3(0,0,0,e2(1),e2(2),e2(3),'g','LineWidth',2);
    quiver3(0,0,0,e3(1),e3(2),e3(3),'b','LineWidth',2);
    
    % SVD to show principal axes of ellipsoid
    [U, S, ~] = svd(A);
    sigma = diag(S);
    
    for i = 1:3
        axis_vec = sigma(i) * U(:,i);
        quiver3(0,0,0,axis_vec(1),axis_vec(2),axis_vec(3), ...
            'k','LineWidth',2.5,'MaxHeadSize',0.5);
    end
    
    axis equal;
    grid on;
    xlabel('$x''$', 'Interpreter', 'latex');
    ylabel('$y''$', 'Interpreter', 'latex');
    zlabel('$z''$', 'Interpreter', 'latex');
    title('Transformed Ellipsoid (Output)', 'Interpreter', 'latex');
    view(45, 30);
    
    % Subplot 3: Side-by-side comparison
    subplot(1, 3, 3);
    surf(x, y, z, 'FaceColor', 'b', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
    hold on;
    surf(x_t, y_t, z_t, 'FaceColor', 'r', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
    
    axis equal;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex');
    ylabel('$y$', 'Interpreter', 'latex');
    zlabel('$z$', 'Interpreter', 'latex');
    title('Comparison', 'Interpreter', 'latex');
    legend('Unit sphere', 'Transformed ellipsoid', 'Location', 'best');
    view(45, 30);
    
    % Print transformation properties
    fprintf('Geometric Properties:\n');
    fprintf('  Volume scaling: |det(A)| = %.6f\n', abs(det(A)));
    fprintf('  Unit sphere volume: 4뿯ν/3 ≈ 4.189\n');
    fprintf('  Ellipsoid volume: %.6f\n', abs(det(A)) * 4*pi/3);
    fprintf('  Ellipsoid semi-axes (singular values): [%.3f, %.3f, %.3f]\n', ...
        sigma);
end

function checkSpecialProperties(A)
    % CHECKSPECIALPROPERTIES Test for special matrix types
    
    % Symmetry
    is_symmetric = isequal(A, A');
    fprintf('Symmetric (A = A'') %s\n', ternary(is_symmetric, 'YES', 'NO'));
    if ~is_symmetric
        sym_measure = norm(A - A', 'fro') / norm(A, 'fro');
        fprintf('  Symmetry measure: %.2e (0 = symmetric)\n', sym_measure);
    end
    fprintf('\n');
    
    % Orthogonality
    AtA = A' * A;
    is_orthogonal = norm(AtA - eye(3), 'fro') < 1e-10;
    fprintf('Orthogonal (A''*A = I) %s\n', ternary(is_orthogonal, 'YES', 'NO'));
    if ~is_orthogonal
        ortho_measure = norm(AtA - eye(3), 'fro');
        fprintf('  Orthogonality measure: %.2e (0 = orthogonal)\n', ortho_measure);
    end
    fprintf('\n');
    
    % Positive definiteness (requires symmetry first)
    if is_symmetric
        eigenvalues = eig(A);
        is_positive_definite = all(eigenvalues > 0);
        fprintf('Positive definite (all 뿯ν > 0) %s\n', ...
            ternary(is_positive_definite, 'YES', 'NO'));
        if is_positive_definite
            fprintf('  All eigenvalues positive 뿯↽ matrix is positive definite\n');
        else
            fprintf('  Some eigenvalues ≤ 0 뿯↽ matrix is NOT positive definite\n');
        end
    else
        fprintf('Positive definite Cannot test (matrix not symmetric)\n');
    end
    fprintf('\n');
    
    % Diagonal dominance
    is_diag_dominant = true;
    for i = 1:size(A,1)
        row_sum = sum(abs(A(i,:))) - abs(A(i,i));
        if abs(A(i,i)) <= row_sum
            is_diag_dominant = false;
            break;
        end
    end
    fprintf('Diagonally dominant %s\n', ternary(is_diag_dominant, 'YES', 'NO'));
    fprintf('  (|a_ii| > sum of |a_ij| for j≠i)\n');
end

function demonstrateApplications(A, eigenvalues, eigenvectors)
    % DEMONSTRATEAPPLICATIONS Show practical uses of matrix operations
    
    %% Application 1: Solving linear system
    fprintf('Application 1: Solving Linear System Ax = b\n');
    b = [1; 2; 3];
    x = A \ b;
    fprintf('  Given b = [1, 2, 3]''\n');
    fprintf('  Solution x = [%.6f, %.6f, %.6f]''\n', x);
    
    % Verify
    Ax = A * x;
    error = norm(Ax - b);
    fprintf('  Verification: ||Ax - b|| = %.2e\n\n', error);
    
    %% Application 2: Matrix powers using diagonalization
    fprintf('Application 2: Computing Matrix Powers A^n\n');
    n = 10;
    
    % Direct computation
    tic;
    A_power_direct = A^n;
    time_direct = toc;
    
    % Using eigenvalue decomposition
    % A = V*D*V^(-1), so A^n = V*D^n*V^(-1)
    tic;
    D = diag(eigenvalues);
    V = eigenvectors;
    D_power = diag(eigenvalues.^n);
    A_power_eigen = V * D_power * inv(V);
    time_eigen = toc;
    
    fprintf('  A^%d computed using:\n', n);
    fprintf('    Direct: %.6f seconds\n', time_direct);
    fprintf('    Eigendecomposition: %.6f seconds\n', time_eigen);
    fprintf('    Difference: %.2e\n\n', norm(A_power_direct - A_power_eigen, 'fro'));
    
    %% Application 3: Matrix exponential
    fprintf('Application 3: Matrix Exponential e^A\n');
    expA = expm(A);
    fprintf('  e^A (using Pad뿯½ approximation):\n');
    disp(expA);
    
    % Verify property: det(e^A) = e^(trace(A))
    det_expA = det(expA);
    exp_traceA = exp(trace(A));
    fprintf('  Verification: det(e^A) = %.6f\n', det_expA);
    fprintf('  Expected: e^(trace(A)) = %.6f\n', exp_traceA);
    fprintf('  Difference: %.2e\n', abs(det_expA - exp_traceA));
end

function str = ternary(condition, true_str, false_str)
    % TERNARY Simple ternary operator
    if condition
        str = true_str;
    else
        str = false_str;
    end
end

% Execute problem solution
Problem3_MatrixOperations();
