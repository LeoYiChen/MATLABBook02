%% chapter_FundamentalMathematics_MATLABexample_SVD.m
% Singular Value Decomposition and applications.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMathematics_MATLABexample_SVD
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter05_Section5_5_2_Example01.m
% Author: Dr Leo Chen
% Date: June 3, 2025
% MATLAB Version: R2025a
% Description: Demonstrates Singular Value Decomposition (SVD) with
%              applications to image compression, pseudoinverse computation,
%              and low-rank approximation.

function demonstrateSVD()
    fprintf('Singular Value Decomposition (SVD)\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic SVD computation and properties
    demonstrateBasicSVD();
    
    % Part 2: Low-rank approximation
    demonstrateLowRankApproximation();
    
    % Part 3: Image compression via SVD
    demonstrateImageCompression();
    
    % Part 4: Pseudoinverse and least-squares
    demonstratePseudoinverse();
    
    % Part 5: Numerical rank determination
    demonstrateNumericalRank();
end

function demonstrateBasicSVD()
    % Demonstrate basic SVD computation and verify properties
    
    fprintf('Part 1: Basic SVD Computation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create rectangular matrix
    A = [3, 2, 2; 2, 3, -2];
    
    fprintf('Matrix A (2$\times$3):\n');
    disp(A);
    
    % Compute SVD
    [U, S, V] = svd(A);
    
    fprintf('SVD Decomposition: A = UΣV''\n\n');
    
    fprintf('Left singular vectors U (2$\times$2):\n');
    disp(U);
    
    fprintf('Singular values Σ (2$\times$3):\n');
    disp(S);
    
    fprintf('Right singular vectors V (3$\times$3):\n');
    disp(V);
    
    % Extract singular values
    singularValues = diag(S);
    fprintf('Singular values: σ₁ = %.6f, σ₂ = %.6f\n\n', ...
            singularValues(1), singularValues(2));
    
    % Verify decomposition
    A_reconstructed = U * S * V';
    reconstructionError = norm(A - A_reconstructed, 'fro');
    fprintf('Verification: ||A - UΣV''||_F = %.10e\n\n', reconstructionError);
    
    % Verify orthogonality of U and V
    fprintf('Orthogonality verification:\n');
    U_orthogonality = norm(U' * U - eye(size(U, 2)), 'fro');
    V_orthogonality = norm(V' * V - eye(size(V, 2)), 'fro');
    fprintf('  ||U''U - I||_F = %.10e\n', U_orthogonality);
    fprintf('  ||V''V - I||_F = %.10e\n\n', V_orthogonality);
    
    % Connection to eigenvalues
    fprintf('Connection to eigenvalue decomposition:\n');
    
    % Compute A'A and its eigenvalues
    AtA = A' * A;
    eigenvalues_AtA = sort(eig(AtA), 'descend');
    
    fprintf('Eigenvalues of A''A:\n');
    fprintf('  %.6f, %.6f, %.6f\n', eigenvalues_AtA);
    
    fprintf('Squares of singular values (σᵢ²):\n');
    fprintf('  %.6f, %.6f\n', singularValues(1)^2, singularValues(2)^2);
    
    fprintf('\nNote: Singular values of A = sqrt(eigenvalues of A''A)\n\n');
end

function demonstrateLowRankApproximation()
    % Demonstrate low-rank approximation using truncated SVD
    
    fprintf('Part 2: Low-Rank Approximation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create a rank-deficient matrix by construction
    fprintf('Creating a noisy low-rank matrix...\n');
    
    % True low-rank component (rank 2)
    m = 50;
    n = 40;
    trueRank = 2;
    
    U_true = randn(m, trueRank);
    V_true = randn(n, trueRank);
    A_true = U_true * V_true';
    
    % Add noise
    noiseLevel = 0.1;
    noise = noiseLevel * norm(A_true, 'fro') * randn(m, n) / sqrt(m * n);
    A_noisy = A_true + noise;
    
    fprintf('Matrix dimensions: %d $\times$ %d\n', m, n);
    fprintf('True rank: %d\n', trueRank);
    fprintf('Noise level: %.2f (relative to signal)\n\n', noiseLevel);
    
    % Compute SVD
    [U, S, V] = svd(A_noisy);
    singularValues = diag(S);
    
    % Display singular values
    fprintf('First 10 singular values:\n');
    for k = 1:min(10, length(singularValues))
        fprintf('  σ_%d = %.6f\n', k, singularValues(k));
    end
    fprintf('\n');
    
    % Compare approximations at different ranks
    ranks = [1, 2, 5, 10];
    
    fprintf('Low-rank approximation errors:\n');
    fprintf('%8*s %20*s %20*s\n', 'Rank k', 'Error vs True', 'Error vs Noisy');
    fprintf('%s\n', repmat('-', 1, 50));
    
    for k = ranks
        % Truncated SVD approximation
        A_approx = U(:, 1:k) * S(1:k, 1:k) * V(:, 1:k)';
        
        % Errors
        error_vs_true = norm(A_approx - A_true, 'fro') / norm(A_true, 'fro');
        error_vs_noisy = norm(A_approx - A_noisy, 'fro') / norm(A_noisy, 'fro');
        
        fprintf('%8*d %20.6*f %20.6*f\n', k, error_vs_true, error_vs_noisy);
    end
    
    fprintf('\nNote: Rank-2 approximation best recovers true signal!\n\n');
    
    % Visualize singular value decay
    figure('Position', [100, 100, 800, 600]);
    semilogy(1:min(20, length(singularValues)), ...
             singularValues(1:min(20, length(singularValues))), ...
             'b-o', 'LineWidth', 2, 'MarkerSize', 8);
    hold on;
    
    % Indicate true rank
    plot([trueRank, trueRank], ylim, 'r--', 'LineWidth', 2);
    text(trueRank, singularValues(1), ' ← True rank', ...
         'FontSize', 11, 'Color', 'r');
    
    grid on;
    xlabel('Index $i$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Singular Value $\sigma_i$', 'Interpreter', 'latex', ...
           'FontSize', 12);
    title('Singular Value Spectrum', 'Interpreter', 'latex', ...
          'FontSize', 14);
    set(gca, 'FontSize', 11);
    
    fprintf('Singular value plot shows clear gap after rank 2\n\n');
end

function demonstrateImageCompression()
    % Demonstrate image compression using truncated SVD
    
    fprintf('Part 3: Image Compression via SVD\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create or load a grayscale image
    % For demonstration, create a simple synthetic image
    [X, Y] = meshgrid(linspace(-2, 2, 200), linspace(-2, 2, 200));
    img = exp(-(X.^2 + Y.^2)) .* cos(4*X) .* sin(4*Y);
    img = mat2gray(img); % Normalize to [0, 1]
    
    fprintf('Original image size: %d $\times$ %d\n', size(img, 1), size(img, 2));
    
    % Compute SVD
    [U, S, V] = svd(img);
    singularValues = diag(S);
    
    totalSingularValues = length(singularValues);
    fprintf('Total singular values: %d\n\n', totalSingularValues);
    
    % Test different compression levels
    compressionRanks = [5, 10, 20, 50];
    
    fprintf('Compression analysis:\n');
    fprintf('%8*s %15*s %18*s %15*s\n', 'Rank k', 'Storage Ratio', ...
            'Rel. Error', 'PSNR (dB)');
    fprintf('%s\n', repmat('-', 1, 60));
    
    % Create figure for visualisation
    figure('Position', [100, 100, 1200, 800]);
    
    % Display original
    subplot(2, 3, 1);
    imshow(img);
    title('Original Image', 'Interpreter', 'latex', 'FontSize', 12);
    
    for idx = 1:length(compressionRanks)
        k = compressionRanks(idx);
        
        % Truncated SVD reconstruction
        img_compressed = U(:, 1:k) * S(1:k, 1:k) * V(:, 1:k)';
        
        % Storage ratio (compressed vs original)
        % Compressed: U(:,1:k) + S(1:k,1:k) + V(:,1:k)
        % Original: full matrix
        [m, n] = size(img);
        storage_compressed = m*k + k + n*k; % U cols + S diag + V cols
        storage_original = m * n;
        storage_ratio = storage_compressed / storage_original;
        
        % Relative error
        rel_error = norm(img - img_compressed, 'fro') / norm(img, 'fro');
        
        % Peak Signal-to-Noise Ratio
        mse = mean((img(:) - img_compressed(:)).^2);
        psnr_value = 10 * log10(1 / mse); % Peak value is 1 for normalized image
        
        fprintf('%8*d %15.2*f%% %18.6*f %15.2*f\n', ...
                k, storage_ratio * 100, rel_error, psnr_value);
        
        % Display compressed image
        subplot(2, 3, idx + 1);
        imshow(img_compressed);
        title(sprintf('Rank %d (%.1f\\%% storage)', k, storage_ratio * 100), ...
              'Interpreter', 'latex', 'FontSize', 11);
    end
    
    % Plot singular values
    subplot(2, 3, 6);
    semilogy(1:min(100, totalSingularValues), ...
             singularValues(1:min(100, totalSingularValues)), ...
             'b-', 'LineWidth', 2);
    hold on;
    
    % Mark compression ranks
    for k = compressionRanks
        plot(k, singularValues(k), 'ro', 'MarkerSize', 8, ...
             'LineWidth', 2);
    end
    
    grid on;
    xlabel('Index', 'Interpreter', 'latex', 'FontSize', 11);
    ylabel('Singular Value', 'Interpreter', 'latex', 'FontSize', 11);
    title('Singular Value Decay', 'Interpreter', 'latex', ...
          'FontSize', 12);
    set(gca, 'FontSize', 10);
    
    fprintf('\nvisualisation shows trade-off between compression and quality\n\n');
end

function demonstratePseudoinverse()
    % Demonstrate pseudoinverse computation and least-squares applications
    
    fprintf('Part 4: Pseudoinverse and Least-Squares\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Overdetermined system (more equations than unknowns)
    fprintf('Case 1: Overdetermined System (m > n)\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create data with slight noise
    x_true = [2; -1; 3];
    
    % Create overdetermined system
    A = randn(10, 3);
    b_exact = A * x_true;
    b = b_exact + 0.1 * randn(10, 1); % Add noise
    
    fprintf('System: Ax = b where A is %d $\times$ %d\n', size(A, 1), size(A, 2));
    fprintf('True solution: x = [%.2f; %.2f; %.2f]\n\n', x_true);
    
    % Solve using pseudoinverse
    A_pinv = pinv(A);
    x_pinv = A_pinv * b;
    
    fprintf('Least-squares solution via pseudoinverse:\n');
    fprintf('x = [%.6f; %.6f; %.6f]\n', x_pinv);
    
    % Compare with backslash operator
    x_backslash = A \ b;
    fprintf('\nSolution via backslash operator:\n');
    fprintf('x = [%.6f; %.6f; %.6f]\n', x_backslash);
    
    difference = norm(x_pinv - x_backslash);
    fprintf('\nDifference: ||x_pinv - x_backslash|| = %.10e\n', difference);
    
    % Compute residuals
    residual = A * x_pinv - b;
    fprintf('\nResidual norm: ||Ax - b|| = %.6f\n', norm(residual));
    
    % Verify minimum norm property
    fprintf('\nSolution norm: ||x|| = %.6f\n\n', norm(x_pinv));
    
    % Underdetermined system (fewer equations than unknowns)
    fprintf('Case 2: Underdetermined System (m < n)\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    A_under = randn(3, 5);
    b_under = randn(3, 1);
    
    fprintf('System: Ax = b where A is %d $\times$ %d\n', ...
            size(A_under, 1), size(A_under, 2));
    fprintf('(Infinitely many exact solutions exist)\n\n');
    
    % Pseudoinverse solution (minimum norm)
    x_minNorm = pinv(A_under) * b_under;
    
    fprintf('Minimum-norm solution via pseudoinverse:\n');
    fprintf('x = [%.6f; %.6f; %.6f; %.6f; %.6f]\n', x_minNorm);
    fprintf('||x|| = %.6f\n', norm(x_minNorm));
    
    % Verify it's an exact solution
    residual_under = A_under * x_minNorm - b_under;
    fprintf('\nResidual: ||Ax - b|| = %.10e (essentially zero)\n', ...
            norm(residual_under));
    
    % Show that another solution has larger norm
    % Add any vector in the null space
    [~, ~, V] = svd(A_under);
    nullSpaceVector = V(:, 4); % A vector in null space
    
    x_alternative = x_minNorm + 2 * nullSpaceVector;
    residual_alt = A_under * x_alternative - b_under;
    
    fprintf('\nAlternative solution (adding null space component):\n');
    fprintf('||x_alt|| = %.6f (larger than minimum norm)\n', ...
            norm(x_alternative));
    fprintf('||Ax_alt - b|| = %.10e (still exact solution)\n\n', ...
            norm(residual_alt));
    
    % Demonstrate pseudoinverse via SVD
    fprintf('Computing pseudoinverse explicitly via SVD:\n');
    [U, S, V] = svd(A);
    
    % Create Σ⁺ by inverting non-zero singular values
    tolerance = 1e-10;
    S_pinv = zeros(size(S'));
    for i = 1:min(size(S))
        if S(i, i) > tolerance
            S_pinv(i, i) = 1 / S(i, i);
        end
    end
    
    A_pinv_manual = V * S_pinv * U';
    
    % Verify
    error_pinv = norm(A_pinv - A_pinv_manual, 'fro');
    fprintf('||pinv(A) - VΣ⁺U''||_F = %.10e\n\n', error_pinv);
end

function demonstrateNumericalRank()
    % Demonstrate numerical rank determination using SVD
    
    fprintf('Part 5: Numerical Rank Determination\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Create matrix with known rank
    fprintf('Creating rank-deficient matrix...\n');
    
    m = 100;
    n = 80;
    trueRank = 15;
    
    % Construct exactly rank-15 matrix
    U_construct = randn(m, trueRank);
    V_construct = randn(n, trueRank);
    A_exact = U_construct * V_construct';
    
    fprintf('Matrix dimensions: %d $\times$ %d\n', m, n);
    fprintf('True rank (by construction): %d\n\n', trueRank);
    
    % Add small numerical noise
    epsilon = 1e-10;
    A_noisy = A_exact + epsilon * randn(m, n);
    
    % Compute SVD
    [~, S, ~] = svd(A_noisy);
    singularValues = diag(S);
    
    % Algebraic rank (MATLAB's rank function)
    algebraic_rank = rank(A_noisy);
    fprintf('Algebraic rank (MATLAB rank()): %d\n', algebraic_rank);
    
    % Display singular values around the rank
    fprintf('\nSingular values near the true rank:\n');
    displayRange = max(1, trueRank-2):min(trueRank+5, length(singularValues));
    for k = displayRange
        fprintf('  σ_%2*d = %.6e', k, singularValues(k));
        if k == trueRank
            fprintf(' ← True rank');
        end
        fprintf('\n');
    end
    
    % Plot singular values with different scales
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    semilogy(1:length(singularValues), singularValues, 'b-o', ...
             'LineWidth', 2, 'MarkerSize', 5);
    hold on;
    plot([trueRank, trueRank], ylim, 'r--', 'LineWidth', 2);
    grid on;
    xlabel('Index $i$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Singular Value $\sigma_i$ (log scale)', ...
           'Interpreter', 'latex', 'FontSize', 12);
    title('Singular Value Spectrum', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Singular values', 'True rank', 'Interpreter', 'latex', ...
           'Location', 'best');
    set(gca, 'FontSize', 11);
    
    subplot(1, 2, 2);
    % Ratios of consecutive singular values
    ratios = singularValues(1:end-1) ./ singularValues(2:end);
    semilogy(1:length(ratios), ratios, 'b-o', 'LineWidth', 2, ...
             'MarkerSize', 5);
    hold on;
    plot([trueRank, trueRank], ylim, 'r--', 'LineWidth', 2);
    grid on;
    xlabel('Index $i$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Ratio $\sigma_i / \sigma_{i+1}$', 'Interpreter', 'latex', ...
           'FontSize', 12);
    title('Singular Value Ratio Test', 'Interpreter', 'latex', ...
          'FontSize', 13);
    set(gca, 'FontSize', 11);
    
    fprintf('\nNote: Large gap in singular values indicates numerical rank\n');
    fprintf('The ratio σ_k/σ_{k+1} shows a jump at the true rank\n');
end
