%% C020201Maths_Fundamental_code_121.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% CVX example: least-squares with L1 regularisation (LASSO)
cvx_begin
    variable xOpt(n)
    minimise(norm(A*xOpt - b, 2) + lambda*norm(xOpt, 1))
cvx_end

fprintf('Optimal value: %.6f\n', cvx_optval);
fprintf('Number of non-zero coefficients: %d\n', nnz(xOpt));
