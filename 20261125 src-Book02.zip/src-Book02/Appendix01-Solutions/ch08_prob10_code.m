%% ch08_prob10_code.m
% Big-data visualisation dashboard with animation (MATLABBook02_Chapter08_Problem10.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob10_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem10.m
% --------------------------------
% Purpose : Multi-panel dashboard and scrolling animation.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later recommended
% --------------------------------
clc; clear; close all;

%% Step 1 - Generate large synthetic dataset
fprintf('=== Step 1: Generating 5 million observations ===\n');
rng(42, 'twister');
numRows = 5000000;
variableNames = {'Var1','Var2','Var3','Var4','Var5','TimeIndex'};

% Correlated structure via latent factors
latentFactors = randn(numRows, 2);
rawDataMatrix = zeros(numRows, 5);
rawDataMatrix(:,1) = 3*latentFactors(:,1) + 0.5*randn(numRows,1);
rawDataMatrix(:,2) = 2*latentFactors(:,1) + ...
                     2*latentFactors(:,2) + 0.5*randn(numRows,1);
rawDataMatrix(:,3) = -1.5*latentFactors(:,2) + 0.5*randn(numRows,1);
rawDataMatrix(:,4) = randn(numRows,1) * 4 + 10;
rawDataMatrix(:,5) = 1.5*latentFactors(:,1) + randn(numRows,1);
timeIndex = (1:numRows)';

fprintf('  Data matrix: %d x %d\n', numRows, 5);

%% Step 2 - Intelligent down-sampling for scatter panels
downsampleFactor = 500;
scatterIndices   = 1:downsampleFactor:numRows;
scatterData      = rawDataMatrix(scatterIndices, :);
fprintf('  Down-sampled for scatter: %d points\n', ...
    numel(scatterIndices));

%% Step 3 - Build dashboard
fprintf('\n=== Step 3: Building dashboard ===\n');
figDashboard = figure('Name', 'Big Data Dashboard', ...
    'Position', [50 50 1600 900]);
tiledLayout = tiledlayout(2, 3, 'TileSpacing', 'compact', ...
    'Padding', 'compact');
title(tiledLayout, '\textbf{Big Data Visualisation Dashboard}', ...
    'Interpreter', 'latex', 'FontSize', 16);

% Panel 1-3: Histograms of Var1, Var2, Var3
for varIdx = 1:3
    nexttile;
    histogram(rawDataMatrix(:, varIdx), 100, ...
        'FaceColor', [0.2 0.4 0.7+0.1*varIdx], ...
        'EdgeColor', 'none', 'Normalization', 'pdf');
    xlabel(sprintf('$\\mathrm{Var%d}$', varIdx), ...
        'Interpreter', 'latex');
    ylabel('Density', 'Interpreter', 'latex');
    title(sprintf('\\textbf{Distribution of Var%d}', varIdx), ...
        'Interpreter', 'latex');
    grid on;
end

% Panel 4: Scatter plot (down-sampled)
nexttile;
scatter(scatterData(:,1), scatterData(:,2), 3, ...
    scatterData(:,3), 'filled', 'MarkerFaceAlpha', 0.4);
colorbar;
colormap(nexttile(4), turbo);
xlabel('$\mathrm{Var1}$', 'Interpreter', 'latex');
ylabel('$\mathrm{Var2}$', 'Interpreter', 'latex');
title('\textbf{Scatter: Var1 vs Var2 (Colour = Var3)}', ...
    'Interpreter', 'latex');
grid on;

% Panel 5: Correlation heat map
nexttile;
corrMatrix = corrcoef(rawDataMatrix(1:min(500000,numRows), :));
imagesc(corrMatrix);
colorbar;
colormap(nexttile(5), coolwarm_approx());
caxis([-1, 1]);
set(gca, 'XTick', 1:5, 'YTick', 1:5, ...
    'XTickLabel', {'V1','V2','V3','V4','V5'}, ...
    'YTickLabel', {'V1','V2','V3','V4','V5'});
title('\textbf{Correlation Matrix}', 'Interpreter', 'latex');
% Add correlation values as text
for rowIdx = 1:5
    for colIdx = 1:5
        text(colIdx, rowIdx, sprintf('%.2f', corrMatrix(rowIdx,colIdx)), ...
            'HorizontalAlignment', 'center', 'FontSize', 8, ...
            'Color', 'k');
    end
end

% Panel 6: Time-series (aggregated by binning)
nexttile;
binSize    = 10000;
numBins    = floor(numRows / binSize);
binnedMean = zeros(numBins, 1);
binnedTime = zeros(numBins, 1);
for binIdx = 1:numBins
    rangeStart = (binIdx-1)*binSize + 1;
    rangeEnd   = binIdx * binSize;
    binnedMean(binIdx) = mean(rawDataMatrix(rangeStart:rangeEnd, 1));
    binnedTime(binIdx) = mean(timeIndex(rangeStart:rangeEnd));
end
plot(binnedTime, binnedMean, 'b-', 'LineWidth', 0.8);
xlabel('Time Index', 'Interpreter', 'latex');
ylabel('Binned Mean of Var1', 'Interpreter', 'latex');
title(sprintf('\\textbf{Time-Series (Bin Size = %d)}', binSize), ...
    'Interpreter', 'latex');
grid on;

%% Step 4 - Save dashboard
fprintf('\n=== Step 4: Saving dashboard ===\n');
savefig(figDashboard, 'Ch08_Problem10_Dashboard.fig');
exportgraphics(figDashboard, 'Ch08_Problem10_Dashboard.eps', ...
    'ContentType', 'vector');
exportgraphics(figDashboard, 'Ch08_Problem10_Dashboard.jpg', ...
    'Resolution', 300);
fprintf('  Dashboard saved: .fig, .eps, .jpg\n');

%% Step 5 - Animate scrolling time-series
fprintf('\n=== Step 5: Animating scrolling time-series ===\n');
figScroll = figure('Name', 'Scrolling Time-Series', ...
    'Position', [100 100 1000 450]);

vidWriter = VideoWriter('Ch08_Problem10_ScrollingTimeSeries.mp4', ...
    'MPEG-4');
vidWriter.FrameRate = 30;
vidWriter.Quality   = 90;
open(vidWriter);

scrollWindow = 50;   % bins visible at once
totalScrollSteps = numBins - scrollWindow;
for scrollIdx = 1:totalScrollSteps
    startBin = scrollIdx;
    endBin   = scrollIdx + scrollWindow - 1;
    cla;
    plot(binnedTime(startBin:endBin), ...
         binnedMean(startBin:endBin), 'b-', 'LineWidth', 1.2);
    hold on;
    plot(binnedTime(endBin), binnedMean(endBin), ...
        'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    xlim([binnedTime(startBin), binnedTime(endBin)]);
    ylim([min(binnedMean)*1.1, max(binnedMean)*1.1]);
    xlabel('Time Index', 'Interpreter', 'latex');
    ylabel('Binned Mean (Var1)', 'Interpreter', 'latex');
    title(sprintf('\\textbf{Scrolling Window [Bin %d - %d]}', ...
        startBin, endBin), 'Interpreter', 'latex');
    grid on;
    drawnow;
    if mod(scrollIdx, 3) == 0
        writeVideo(vidWriter, getframe(figScroll));
    end
end
close(vidWriter);
fprintf('  Video saved: Ch08_Problem10_ScrollingTimeSeries.mp4\n');

%% Step 6 - Summary statistics
fprintf('\n=== Summary Statistics ===\n');
fprintf('  %8s  %10s  %10s  %10s  %10s\n', ...
    'Variable', 'Mean', 'Std', 'Min', 'Max');
for varIdx = 1:5
    fprintf('  %8s  %10.4f  %10.4f  %10.4f  %10.4f\n', ...
        sprintf('Var%d', varIdx), ...
        mean(rawDataMatrix(:,varIdx)), ...
        std(rawDataMatrix(:,varIdx)), ...
        min(rawDataMatrix(:,varIdx)), ...
        max(rawDataMatrix(:,varIdx)));
end

fprintf('\n=== Problem 10 Complete ===\n');

%% Local helper function
function cmap = coolwarm_approx()
% coolwarm_approx  Approximate cool-warm diverging colour map.
% Author : Dr Yi Chen | Version 1.0 | 2026
    numColours = 256;
    blueEnd  = [0.23 0.30 0.75];
    whiteMiddle = [0.97 0.97 0.97];
    redEnd   = [0.71 0.02 0.15];
    halfN    = floor(numColours / 2);
    coolHalf = interp1([1 halfN], [blueEnd; whiteMiddle], 1:halfN);
    warmHalf = interp1([1 halfN], [whiteMiddle; redEnd], 1:halfN);
    cmap     = [coolHalf; warmHalf(2:end, :)];
end
% --------------------------------
% Computational Complexity:
% Data generation is O(N * D). Down-sampling is O(N / k). Histogram
% computation (100 bins) is O(N) per variable. Scatter rendering is
% O(N / k). Correlation on 500 000 rows is O(subN * D^2). Binned
% aggregation is O(N). The scrolling animation is O(numBins) and
% I/O-bound. Total is dominated by O(N * D) for full-dataset
% operations. Memory is O(N * D) for the raw data matrix.
% --------------------------------
