%% C020201Maths_Fundamental_code_101.m
% MATLAB source code for this example.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : (no label; generated name)
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Stiff ODE: van der Pol equation with large parameter
mu = 1000;
vanderPol = @(t, y) [y(2); mu * (1 - y(1)^2) * y(2) - y(1)];

% Requires stiff solver
options = odeset('RelTol', 1e-6, 'AbsTol', 1e-8);
[t, y] = ode15s(vanderPol, [0, 3000], [2; 0], options);
