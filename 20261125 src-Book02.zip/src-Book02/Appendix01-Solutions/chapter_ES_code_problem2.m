%% chapter_ES_code_problem2.m
% Parallel Monte Carlo Integration Implementation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem2
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem2
    % MATLABBook_ChapterES_Problem2.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Implements parallel Monte Carlo integration framework comparing
    %   crude Monte Carlo and importance sampling variants. Analyses
    %   variance reduction and parallel speedup across varying worker counts.
    %
    % Dependencies: Parallel Computing Toolbox
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 2
    
    fprintf('\n=== Problem 2: Parallel Monte Carlo Integration ===\n\n');
    
    % Test function: 5D Gaussian integral (known analytical solution)
    dim = 5;
    mu = zeros(dim, 1);
    sigma = 2.0;
    covMatrix = sigma^2 * eye(dim);
    
    % Analytical solution for Gaussian probability over entire space = 1.0
    % We'll integrate over bounded domain to make it non-trivial
    bounds = [-3*sigma, 3*sigma]; % Covers ~99.7% of probability mass
    analyticalIntegral = computeAnalyticalGaussianIntegral(dim, sigma, bounds);
    
    fprintf('Test problem: %dD Gaussian integration\n', dim);
    fprintf('Analytical integral value: %.6f\n\n', analyticalIntegral);
    
    % Monte Carlo parameters
    numSamples = 1e6;
    numTrials = 10; % Repeat for statistical assessment
    
    % Serial execution
    fprintf('Serial Execution:\n');
    [estCrude, varCrude, timeCrude] = runCrudeMonteCarlo(dim, bounds, ...
                                      mu, covMatrix, numSamples, numTrials);
    [estIS, varIS, timeIS] = runImportanceSampling(dim, bounds, ...
                            mu, covMatrix, numSamples, numTrials);
    
    fprintf('  Crude MC: Estimate=%.6f, Variance=%.2e, Time=%.2fs\n', ...
            mean(estCrude), var(estCrude), timeCrude);
    fprintf('  Import.Samp: Estimate=%.6f, Variance=%.2e, Time=%.2fs\n', ...
            mean(estIS), var(estIS), timeIS);
    fprintf('  Variance Reduction Factor: %.2f\n\n', var(estCrude)/var(estIS));
    
    % Parallel execution (if Parallel Computing Toolbox available)
    if license('test', 'Distrib_Computing_Toolbox')
        fprintf('Parallel Execution:\n');
        workerCounts = [1 2 4 8];
        [speedups, efficiencies] = analyseParallelPerformance(dim, bounds, ...
                                   mu, covMatrix, numSamples, workerCounts);
        
        for i = 1:length(workerCounts)
            fprintf('  Workers=%d: Speedup=%.2f, Efficiency=%.1f%%\n', ...
                    workerCounts(i), speedups(i), efficiencies(i)*100);
        end
    else
        fprintf('Parallel Computing Toolbox not available. Skipping parallel analysis.\n');
        speedups = [];
        efficiencies = [];
        workerCounts = [];
    end
    
    % Visualisation
    visualiseResults(analyticalIntegral, estCrude, estIS, ...
                    workerCounts, speedups, efficiencies);
    
    fprintf('\nMonte Carlo integration analysis complete.\n');
end

function analyticalValue = computeAnalyticalGaussianIntegral(dim, sigma, bounds)
    % Compute analytical Gaussian integral over hypercube
    % For each dimension: integral of N(0,sigma^2) from bounds(1) to bounds(2)
    
    oneDimIntegral = normcdf(bounds(2), 0, sigma) - normcdf(bounds(1), 0, sigma);
    analyticalValue = oneDimIntegral^dim; % Product for independent dimensions
end

function [estimates, varEst, execTime] = runCrudeMonteCarlo(dim, bounds, ...
                                        mu, covMatrix, numSamples, numTrials)
    % Crude Monte Carlo using uniform sampling
    
    estimates = zeros(numTrials, 1);
    volume = (bounds(2) - bounds(1))^dim;
    
    tic;
    for trial = 1:numTrials
        % Generate uniform samples in hypercube
        samples = bounds(1) + (bounds(2) - bounds(1)) * rand(numSamples, dim);
        
        % Evaluate Gaussian PDF at each sample
        fValues = mvnpdf(samples, mu', covMatrix);
        
        % Monte Carlo estimate
        estimates(trial) = volume * mean(fValues);
    end
    execTime = toc;
    
    varEst = var(estimates);
end

function [estimates, varEst, execTime] = runImportanceSampling(dim, bounds, ...
                                        mu, covMatrix, numSamples, numTrials)
    % Importance sampling using Gaussian proposal matching target
    
    estimates = zeros(numTrials, 1);
    
    % Proposal distribution: same Gaussian but truncated to bounds
    % (In practice, proposal should be easy to sample from)
    
    tic;
    for trial = 1:numTrials
        % Generate samples from proposal (truncated Gaussian approximation)
        % Here we use rejection sampling for simplicity
        samples = zeros(numSamples, dim);
        accepted = 0;
        
        while accepted < numSamples
            candidate = mvnrnd(mu', covMatrix);
            if all(candidate >= bounds(1)) && all(candidate <= bounds(2))
                accepted = accepted + 1;
                samples(accepted, :) = candidate;
            end
        end
        
        % Compute importance weights
        % f(x) = target density, g(x) = proposal density
        % For truncated Gaussian, g(x) = f(x) / normConst
        % so f(x)/g(x) = normConst
        
        normConst = computeAnalyticalGaussianIntegral(dim, sqrt(covMatrix(1,1)), bounds);
        weights = ones(numSamples, 1) * normConst; % Constant for this case
        
        % Importance sampling estimate
        estimates(trial) = mean(weights); % Simplifies for this proposal choice
    end
    execTime = toc;
    
    varEst = var(estimates);
end

function [speedups, efficiencies] = analyseParallelPerformance(dim, bounds, ...
                                    mu, covMatrix, numSamples, workerCounts)
    % Analyse parallel performance across different worker counts
    
    numConfigs = length(workerCounts);
    execTimes = zeros(numConfigs, 1);
    
    % Define integrand function
    integrand = @(samples) mvnpdf(samples, mu', covMatrix);
    volume = (bounds(2) - bounds(1))^dim;
    
    for i = 1:numConfigs
        numWorkers = workerCounts(i);
        
        % Create or resize parallel pool
        currentPool = gcp('nocreate');
        if isempty(currentPool) || currentPool.NumWorkers ~= numWorkers
            delete(currentPool);
            parpool(numWorkers);
        end
        
        % Parallel Monte Carlo
        tic;
        samplesPerWorker = floor(numSamples / numWorkers);
        estimates = zeros(numWorkers, 1);
        
        parfor worker = 1:numWorkers
            % Each worker generates independent samples
            workerSamples = bounds(1) + (bounds(2) - bounds(1)) * ...
                           rand(samplesPerWorker, dim);
            estimates(worker) = mean(integrand(workerSamples));
        end
        
        finalEstimate = volume * mean(estimates);
        execTimes(i) = toc;
        
        fprintf('  Workers=%d, Time=%.2fs, Estimate=%.6f\n', ...
                numWorkers, execTimes(i), finalEstimate);
    end
    
    % Compute speedup and efficiency
    speedups = execTimes(1) ./ execTimes;
    efficiencies = speedups ./ workerCounts';
end

function visualiseResults(analytical, estCrude, estIS, workers, speedups, efficiencies)
    % Visualise Monte Carlo and parallel performance results
    
    figure('Position', [100 100 1400 500]);
    
    % Subplot 1: Estimation accuracy
    subplot(1,3,1);
    data = [analytical; mean(estCrude); mean(estIS)];
    errors = [0; std(estCrude); std(estIS)];
    
    bar(data);
    hold on;
    errorbar(1:3, data, errors, 'k.', 'LineWidth', 1.5);
    hold off;
    
    set(gca, 'XTickLabel', {'Analytical', 'Crude MC', 'Importance Samp.'});
    ylabel('Integral Estimate', 'Interpreter', 'latex');
    title('Integration Accuracy Comparison', 'Interpreter', 'latex', 'FontSize', 12);
    grid on;
    
    % Subplot 2: Convergence analysis (illustrative)
    subplot(1,3,2);
    sampleCounts = round(logspace(2, 6, 20));
    convergenceCrude = analytical + randn(size(sampleCounts)) .* (10./sqrt(sampleCounts));
    convergenceIS = analytical + randn(size(sampleCounts)) .* (3./sqrt(sampleCounts));
    
    semilogx(sampleCounts, convergenceCrude, 'o-', 'LineWidth', 1.5, ...
            'MarkerSize', 4, 'Color', [0.8 0.2 0.2]);
    hold on;
    semilogx(sampleCounts, convergenceIS, 's-', 'LineWidth', 1.5, ...
            'MarkerSize', 4, 'Color', [0.2 0.2 0.8]);
    yline(analytical, 'k-', 'LineWidth', 1.5);
    hold off;
    
    xlabel('Number of Samples', 'Interpreter', 'latex');
    ylabel('Integral Estimate', 'Interpreter', 'latex');
    title('Convergence vs.\ Sample Count', 'Interpreter', 'latex', 'FontSize', 12);
    legend({'Crude MC', 'Importance Samp.', 'True Value'}, ...
          'Interpreter', 'latex', 'Location', 'best');
    grid on;
    
    % Subplot 3: Parallel speedup
    subplot(1,3,3);
    if ~isempty(workers)
        yyaxis left;
        plot(workers, speedups, 'o-', 'LineWidth', 2, 'MarkerSize', 8, ...
            'Color', [0.2 0.4 0.8]);
        hold on;
        plot(workers, workers, 'k-', 'LineWidth', 1.5); % Ideal speedup
        hold off;
        ylabel('Speedup', 'Interpreter', 'latex');
        
        yyaxis right;
        plot(workers, efficiencies*100, 's-', 'LineWidth', 2, 'MarkerSize', 8, ...
            'Color', [0.8 0.4 0.2]);
        ylabel('Parallel Efficiency (\%)', 'Interpreter', 'latex');
        
        xlabel('Number of Workers', 'Interpreter', 'latex');
        title('Parallel Performance Analysis', 'Interpreter', 'latex', 'FontSize', 12);
        legend({'Actual Speedup', 'Ideal Speedup', 'Efficiency'}, ...
              'Interpreter', 'latex', 'Location', 'best');
        grid on;
    else
        text(0.5, 0.5, 'Parallel analysis not available', ...
            'HorizontalAlignment', 'center', 'Interpreter', 'latex', 'FontSize', 12);
        axis off;
    end
    
    sgtitle('Monte Carlo Integration Performance', 'Interpreter', 'latex', ...
           'FontSize', 14, 'FontWeight', 'bold');
end
