%% chapter_Math_lab6_qr.m
% QR Decomposition Properties
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_lab6_qr
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Execute
Lab6_QRDecomposition();

% Local functions (moved to end so this listing is a valid MATLAB script)
function Lab6_QRDecomposition()
    % LAB6_QRDECOMPOSITION Analyse QR decomposition properties
    %   Explores orthogonality, stability, and computational aspects
    
    % Generate test matrix
    m = 200;
    n = 150;
    A = randn(m, n);
    
    fprintf('\\textbf{QR Decomposition Analysis}\n');
    fprintf('Matrix dimensions: %d x %d\n\n', m, n);
    
    % Standard QR decomposition
    fprintf('Computing QR decomposition...\n');
    tic;
    [Q, R] = qr(A);
    time_qr = toc;
    fprintf('  Computation time: %.6f seconds\n', time_qr);
    
    % Verify orthogonality of Q
    I_computed = Q' * Q;
    orthogonality_error = norm(I_computed - eye(m), 'fro');
    fprintf('  Orthogonality error ||Q^T Q - I||_F: %.2e\n', orthogonality_error);
    
    % Verify reconstruction
    reconstruction_error = norm(A - Q*R, 'fro') / norm(A, 'fro');
    fprintf('  Reconstruction error ||A - QR||_F / ||A||_F: %.2e\n', ...
        reconstruction_error);
    
    % Economic QR decomposition (only first n columns of Q)
    fprintf('\nEconomic QR decomposition...\n');
    tic;
    [Q_econ, R_econ] = qr(A, 0);
    time_qr_econ = toc;
    fprintf('  Computation time: %.6f seconds\n', time_qr_econ);
    fprintf('  Q dimensions: %d x %d\n', size(Q_econ, 1), size(Q_econ, 2));
    fprintf('  R dimensions: %d x %d\n', size(R_econ, 1), size(R_econ, 2));
    
    % Memory comparison
    memory_full = (m*m + m*n) * 8;  % bytes (double precision)
    memory_econ = (m*n + n*n) * 8;
    fprintf('  Memory savings: %.1f%% \n', ...
        100*(memory_full - memory_econ)/memory_full);
    
    % Application: Least squares solution
    fprintf('\n\\textbf{Application: Least Squares Problem}\n');
    b = randn(m, 1);
    
    % Using QR decomposition
    tic;
    x_qr = R_econ \ (Q_econ' * b);
    time_qr_solve = toc;
    
    % Using MATLAB's backslash (which internally uses QR for overdetermined systems)
    tic;
    x_backslash = A \ b;
    time_backslash = toc;
    
    % Verify solutions are identical
    solution_diff = norm(x_qr - x_backslash) / norm(x_backslash);
    
    fprintf('  QR solve time: %.6f seconds\n', time_qr_solve);
    fprintf('  Backslash solve time: %.6f seconds\n', time_backslash);
    fprintf('  Solution difference: %.2e\n', solution_diff);
    
    % Residual analysis
    residual_qr = norm(A*x_qr - b);
    residual_backslash = norm(A*x_backslash - b);
    
    fprintf('  Residual (QR): %.6e\n', residual_qr);
    fprintf('  Residual (backslash): %.6e\n', residual_backslash);
    
    % Visualise R matrix structure
    figure('Position', [200, 200, 800, 600]);
    
    subplot(1, 2, 1);
    spy(R_econ);
    title('Structure of R (Economic QR)', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel('Column Index', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Row Index', 'Interpreter', 'latex', 'FontSize', 12);
    
    subplot(1, 2, 2);
    imagesc(abs(R_econ));
    colorbar;
    title('Magnitude of R Elements', 'Interpreter', 'latex', 'FontSize', 14);
    xlabel('Column Index', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Row Index', 'Interpreter', 'latex', 'FontSize', 12);
    colormap(parula);
end
