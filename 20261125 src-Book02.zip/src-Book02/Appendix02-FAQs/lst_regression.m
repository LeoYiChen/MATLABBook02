%% lst_regression.m
% Linear regression example
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : lst:regression
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
p = polyfit(x,y,1);
yr = polyval(p,xd);
plot(x,y,'ro'); hold on;
plot(xd,yr,'r-'); grid on;
