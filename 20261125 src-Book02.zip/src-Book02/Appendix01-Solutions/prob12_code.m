%% prob12_code.m
% Benford's Law analysis for fraud detection.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob12_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Benford's Law Analysis and Fraud Detection
% File: MATLABBook02_Chapter07_Problem12.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Implements Benford's Law analysis for detecting anomalies
%              in numerical datasets using chi-squared goodness-of-fit test
% =========================================================================

function MATLABBook02_Chapter07_Problem12()
    % Main function for Problem 12: Benford's Law Analysis
    
    clc; clear; close all;
    
    % Set random seed for reproducibility
    rng(2024);
    
    % Generate or load datasets for analysis
    fprintf('=== BENFORD''S LAW ANALYSIS ===\n\n');
    
    % Dataset 1: Natural data (should conform to Benford's Law)
    naturalData = generateNaturalData(1000);
    analyseDataset(naturalData, 'Natural Dataset (Population Growth)');
    
    % Dataset 2: Manipulated data (should violate Benford's Law)
    manipulatedData = generateManipulatedData(1000);
    analyseDataset(manipulatedData, 'Manipulated Dataset (Suspected Fraud)');
    
    % Dataset 3: Uniform random data (should violate Benford's Law)
    uniformData = generateUniformData(1000);
    analyseDataset(uniformData, 'Uniform Random Dataset');
    
    fprintf('\nAnalysis completed successfully.\n');
end

function naturalData = generateNaturalData(n)
    % GENERATENATURALDATA - Creates dataset following power law
    %
    % Simulates population growth or financial data that naturally
    % conforms to Benford's Law through exponential/power-law processes
    
    alpha = 2.5; % Power law exponent
    naturalData = (rand(n, 1).^(-1/(alpha-1))) * 100;
end

function manipulatedData = generateManipulatedData(n)
    % GENERATEMANIPULATEDDATA - Creates artificially manipulated dataset
    %
    % Simulates fraudulent data where first digits are artificially
    % distributed to avoid detection (e.g., avoiding digit 1)
    
    manipulatedData = zeros(n, 1);
    for i = 1:n
        % Bias towards higher digits (fraud pattern)
        firstDigit = randi([4, 9]);
        magnitude = randi([1, 3]);
        manipulatedData(i) = firstDigit * 10^magnitude + randi([0, 10^magnitude-1]);
    end
end

function uniformData = generateUniformData(n)
    % GENERATEUNIFORMDATA - Creates uniformly distributed dataset
    %
    % Simulates data that should NOT follow Benford's Law
    % (e.g., human heights, IQ scores, telephone numbers)
    
    uniformData = 1000 + 9000 * rand(n, 1);
end

function analyseDataset(data, datasetName)
    % ANALYSEDATASET - Performs comprehensive Benford's Law analysis
    
    fprintf('\n-- Analysing: %s --\n', datasetName);
    
    % Extract first digits
    firstDigits = extractFirstDigits(data);
    
    % Calculate observed distribution
    [observedCounts, observedProbs] = calculateObservedDistribution(firstDigits);
    
    % Calculate theoretical Benford distribution
    [theoreticalProbs, theoreticalCounts] = calculateBenfordDistribution(length(firstDigits));
    
    % Perform chi-squared goodness-of-fit test
    [h, p, chi2stat, criticalValue] = performChiSquaredTest(observedCounts, theoreticalCounts);
    
    % Display results
    displayResults(observedProbs, theoreticalProbs, chi2stat, p, h, criticalValue);
    
    % Visualise comparison
    visualiseDistribution(observedProbs, theoreticalProbs, datasetName, p);
end

function firstDigits = extractFirstDigits(data)
    % EXTRACTFIRSTDIGITS - Extracts leading digit from each number
    
    % Remove zeros and take absolute values
    data = abs(data(data ~= 0));
    
    % Extract first digit using logarithmic method
    firstDigits = floor(data ./ 10.^floor(log10(data)));
end

function [counts, probs] = calculateObservedDistribution(firstDigits)
    % CALCULATEOBSERVEDDISTRIBUTION - Tabulates first digit frequencies
    
    counts = histcounts(firstDigits, 1:10);
    probs = counts / sum(counts);
end

function [probs, counts] = calculateBenfordDistribution(n)
    % CALCULATEBENFORDDISTRIBUTION - Computes theoretical Benford probabilities
    
    digits = 1:9;
    probs = log10(1 + 1./digits);
    counts = probs * n;
end

function [h, p, chi2stat, criticalValue] = performChiSquaredTest(observed, expected)
    % PERFORMCHISQUAREDTEST - Chi-squared goodness-of-fit test
    
    % Calculate chi-squared statistic
    chi2stat = sum((observed - expected).^2 ./ expected);
    
    % Degrees of freedom = number of categories - 1
    df = 8;
    
    % Critical value at alpha = 0.05
    criticalValue = chi2inv(0.95, df);
    
    % P-value
    p = 1 - chi2cdf(chi2stat, df);
    
    % Hypothesis test result
    h = chi2stat > criticalValue;
end

function displayResults(observedProbs, theoreticalProbs, chi2stat, p, h, criticalValue)
    % DISPLAYRESULTS - Formats and prints analysis results
    
    fprintf('\nFirst Digit Distribution:\n');
    fprintf('Digit | Observed | Benford | Difference\n');
    fprintf('---|-----|-----|------\n');
    for d = 1:9
        fprintf('  %d   |  %.4f  | %.4f  |   %+.4f\n', ...
                d, observedProbs(d), theoreticalProbs(d), ...
                observedProbs(d) - theoreticalProbs(d));
    end
    
    fprintf('\n=== Chi-Squared Test Results ===\n');
    fprintf('Chi-squared statistic: %.4f\n', chi2stat);
    fprintf('Critical value (alpha=0.05): %.4f\n', criticalValue);
    fprintf('P-value: %.6f\n', p);
    
    if h == 0
        fprintf('Conclusion: Data CONFORMS to Benford''s Law (p > 0.05)\n');
        fprintf('            No evidence of manipulation detected.\n');
    else
        fprintf('Conclusion: Data VIOLATES Benford''s Law (p < 0.05)\n');
        fprintf('            WARNING: Possible data manipulation or anomaly!\n');
    end
end

function visualiseDistribution(observedProbs, theoreticalProbs, datasetName, pValue)
    % VISUALISEDISTRIBUTION - Creates comparative bar chart
    
    figure('Name', sprintf('Benford Analysis: %s', datasetName), ...
           'Position', [100, 100, 900, 600]);
    
    digits = 1:9;
    x = categorical({'1', '2', '3', '4', '5', '6', '7', '8', '9'});
    
    bar(x, [observedProbs; theoreticalProbs]', 'grouped');
    
    legend({'Observed Distribution', 'Benford''s Law'}, 'Location', 'northeast', ...
           'FontSize', 11);
    xlabel('First Digit', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Probability', 'Interpreter', 'latex', 'FontSize', 12);
    
    titleStr = sprintf('%s\\\\Chi-squared test: $p = %.6f$', ...
                       strrep(datasetName, '_', '\_'), pValue);
    title(titleStr, 'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    
    grid on;
    set(gca, 'FontSize', 11, 'LineWidth', 1.2);
    ylim([0, 0.35]);
    
    % Add conformance indicator
    if pValue > 0.05
        annotation('textbox', [0.15, 0.85, 0.3, 0.1], 'String', ...
                   'CONFORMS to Benford''s Law', 'FontSize', 11, ...
                   'FontWeight', 'bold', 'Color', [0, 0.6, 0], ...
                   'EdgeColor', 'none');
    else
        annotation('textbox', [0.15, 0.85, 0.3, 0.1], 'String', ...
                   'VIOLATES Benford''s Law', 'FontSize', 11, ...
                   'FontWeight', 'bold', 'Color', [0.8, 0, 0], ...
                   'EdgeColor', 'none');
    end
end
