%% chapter_SymbolicComputing_problem2_code.m
% Multi-variable calculus and optimisation implementation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_SymbolicComputing_problem2_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% MATLABBook02_Chapter_SymbolicComputing_Problem02.m
%
% Multi-Variable Calculus with Symbolic Optimisation
%
% Author: Dr Yi Chen
% Institution: University Engineering Department
% Date: 2024
% Version: 1.0
% MATLAB Version: R2024a
%
% Description: Comprehensive multi-variable calculus system with
% advanced optimisation capabilities and symbolic constraint handling

function multivariable_calculus_optimisation_system()
    %MULTIVARIABLE_CALCULUS_OPTIMISATION_SYSTEM Advanced calculus processor
    %   Implements sophisticated multi-variable calculus and optimisation
    
    clear; clc;
    
    % Display system header
    fprintf('Multi-Variable Calculus with Symbolic Optimisation\n');
    fprintf('=================================================\n\n');
    
    % Problem 1: Critical point analysis
    solve_critical_points_problem();
    
    % Problem 2: Constrained optimisation
    solve_constrained_optimisation_problem();
    
    % Problem 3: Volume integral
    solve_volume_integral_problem();
    
    % Advanced demonstrations
    demonstrate_advanced_calculus_techniques();
    
end

function solve_critical_points_problem()
    %SOLVE_CRITICAL_POINTS_PROBLEM Find and analyse critical points
    %   Solves: f(x,y) = x + y - 3xy + 2xy - xy
    
    fprintf('Problem 1: Critical Points Analysis\n');
    fprintf('===================================\n');
    
    syms x y real
    
    % Define the function
    objective_function = x^3 + y^3 - 3*x*y + 2*x^2*y - x*y^2;
    
    fprintf('Function: f(x,y) = %s\n', char(objective_function));
    
    % Compute first-order partial derivatives
    df_dx = diff(objective_function, x);
    df_dy = diff(objective_function, y);
    
    fprintf('\nFirst-order partial derivatives:\n');
    fprintf('f/x = %s\n', char(df_dx));
    fprintf('f/y = %s\n', char(df_dy));
    
    % Find critical points
    critical_points_equations = [df_dx == 0, df_dy == 0];
    critical_points_solution = solve(critical_points_equations, [x, y]);
    
    fprintf('\nCritical points:\n');
    if isstruct(critical_points_solution)
        x_critical = critical_points_solution.x;
        y_critical = critical_points_solution.y;
        
        for point_index = 1:length(x_critical)
            fprintf('Point %d: (%.4f, %.4f)\n', point_index, ...
                   double(x_critical(point_index)), double(y_critical(point_index)));
        end
    else
        fprintf('No critical points found or infinite solutions\n');
        return;
    end
    
    % Compute second-order partial derivatives (Hessian matrix)
    d2f_dx2 = diff(df_dx, x);
    d2f_dy2 = diff(df_dy, y);
    d2f_dxdy = diff(df_dx, y);
    
    fprintf('\nSecond-order partial derivatives:\n');
    fprintf('f/x = %s\n', char(d2f_dx2));
    fprintf('f/y = %s\n', char(d2f_dy2));
    fprintf('f/xy = %s\n', char(d2f_dxdy));
    
    % Classify critical points using second derivative test
    fprintf('\nCritical point classification:\n');
    
    for point_index = 1:length(x_critical)
        x_val = double(x_critical(point_index));
        y_val = double(y_critical(point_index));
        
        % Evaluate Hessian at critical point
        H11 = double(subs(d2f_dx2, [x, y], [x_val, y_val]));
        H22 = double(subs(d2f_dy2, [x, y], [x_val, y_val]));
        H12 = double(subs(d2f_dxdy, [x, y], [x_val, y_val]));
        
        % Compute determinant and trace
        hessian_determinant = H11 * H22 - H12^2;
        hessian_trace = H11 + H22;
        
        fprintf('Point %d (%.4f, %.4f):\n', point_index, x_val, y_val);
        fprintf('  Hessian determinant: %.6f\n', hessian_determinant);
        fprintf('  Hessian trace: %.6f\n', hessian_trace);
        
        % Classification
        if hessian_determinant > 0
            if hessian_trace > 0
                classification = 'Local minimum';
            else
                classification = 'Local maximum';
            end
        elseif hessian_determinant < 0
            classification = 'Saddle point';
        else
            classification = 'Inconclusive (degenerate case)';
        end
        
        fprintf('  Classification: %s\n', classification);
        
        % Function value at critical point
        function_value = double(subs(objective_function, [x, y], [x_val, y_val]));
        fprintf('  Function value: f(%.4f, %.4f) = %.6f\n', x_val, y_val, function_value);
    end
    
    fprintf('\n');
end

function solve_constrained_optimisation_problem()
    %SOLVE_CONSTRAINED_OPTIMISATION_PROBLEM Lagrange multiplier method
    %   Minimise g(x,y,z) = x + y + z subject to constraints
    
    fprintf('Problem 2: Constrained Optimisation\n');
    fprintf('===================================\n');
    
    syms x y z lambda1 lambda2 real
    
    % Objective function
    objective_function = x^2 + y^2 + z^2;
    
    % Constraints
    constraint1 = x + y + z - 6;
    constraint2 = x*y + y*z + z*x - 9;
    
    fprintf('Objective: minimise g(x,y,z) = %s\n', char(objective_function));
    fprintf('Subject to:\n');
    fprintf('  h(x,y,z) = %s = 0\n', char(constraint1));
    fprintf('  h(x,y,z) = %s = 0\n', char(constraint2));
    
    % Form Lagrangian
    lagrangian = objective_function + lambda1 * constraint1 + lambda2 * constraint2;
    
    fprintf('\nLagrangian: L(x,y,z, , ) = %s\n', char(lagrangian));
    
    % Compute gradients for Lagrange conditions
    dL_dx = diff(lagrangian, x);
    dL_dy = diff(lagrangian, y);
    dL_dz = diff(lagrangian, z);
    dL_dlambda1 = diff(lagrangian, lambda1);
    dL_dlambda2 = diff(lagrangian, lambda2);
    
    fprintf('\nLagrange conditions:\n');
    fprintf('L/x = %s = 0\n', char(dL_dx));
    fprintf('L/y = %s = 0\n', char(dL_dy));
    fprintf('L/z = %s = 0\n', char(dL_dz));
    fprintf('L/  = %s = 0\n', char(dL_dlambda1));
    fprintf('L/  = %s = 0\n', char(dL_dlambda2));
    
    % Solve the system of equations
    lagrange_equations = [dL_dx == 0, dL_dy == 0, dL_dz == 0, ...
                         dL_dlambda1 == 0, dL_dlambda2 == 0];
    
    fprintf('\nSolving Lagrange system...\n');
    
    % This is a complex system, solve numerically for practical demonstration
    [x_opt, y_opt, z_opt, lambda1_opt, lambda2_opt] = solve_lagrange_system_numerically();
    
    fprintf('Optimal solution:\n');
    fprintf('x* = %.6f\n', x_opt);
    fprintf('y* = %.6f\n', y_opt);
    fprintf('z* = %.6f\n', z_opt);
    fprintf(' * = %.6f\n', lambda1_opt);
    fprintf(' * = %.6f\n', lambda2_opt);
    
    % Verify constraints
    constraint1_value = x_opt + y_opt + z_opt;
    constraint2_value = x_opt*y_opt + y_opt*z_opt + z_opt*x_opt;
    objective_value = x_opt^2 + y_opt^2 + z_opt^2;
    
    fprintf('\nConstraint verification:\n');
    fprintf('h(x*,y*,z*) = %.6f (should be   6)\n', constraint1_value);
    fprintf('h(x*,y*,z*) = %.6f (should be   9)\n', constraint2_value);
    fprintf('Minimum value: g(x*,y*,z*) = %.6f\n', objective_value);
    
    fprintf('\n');
end

function [x_opt, y_opt, z_opt, lambda1_opt, lambda2_opt] = solve_lagrange_system_numerically()
    %SOLVE_LAGRANGE_SYSTEM_NUMERICALLY Numerical solution for demonstration
    %   Provides numerical solution for the constrained optimisation problem
    
    % For this symmetric problem, we can use the method of substitution
    % From symmetry and the nature of constraints, we expect x = y = z
    
    % If x = y = z, then:
    % Constraint 1: 3x = 6   x = 2
    % Constraint 2: 3x = 9   x = 3   x =   3
    
    % These constraints are incompatible with x = y = z
    % Use numerical solution
    
    % Set up the problem using fsolve
    initial_guess = [1, 1, 1, 1, 1]; % [x, y, z, lambda1, lambda2]
    
    % Define the system of equations
    equations = @(vars) lagrange_system_equations(vars);
    
    % Solve numerically
    options = optimoptions('fsolve', 'Display', 'off');
    solution = fsolve(equations, initial_guess, options);
    
    x_opt = solution(1);
    y_opt = solution(2);
    z_opt = solution(3);
    lambda1_opt = solution(4);
    lambda2_opt = solution(5);
end

function F = lagrange_system_equations(vars)
    %LAGRANGE_SYSTEM_EQUATIONS Define the system for numerical solving
    %   Returns the residuals of the Lagrange system
    
    x = vars(1);
    y = vars(2);
    z = vars(3);
    lambda1 = vars(4);
    lambda2 = vars(5);
    
    % Lagrange conditions
    F(1) = 2*x + lambda1 + lambda2*(y + z);  % L/x = 0
    F(2) = 2*y + lambda1 + lambda2*(x + z);  % L/y = 0
    F(3) = 2*z + lambda1 + lambda2*(x + y);  % L/z = 0
    F(4) = x + y + z - 6;                    % L/  = 0
    F(5) = x*y + y*z + z*x - 9;             % L/  = 0
end

function solve_volume_integral_problem()
    %SOLVE_VOLUME_INTEGRAL_PROBLEM Triple integration over sphere
    %   Computes (x + y + z) dV over sphere of radius R
    
    fprintf('Problem 3: Volume Integral\n');
    fprintf('=========================\n');
    
    syms x y z R real positive
    syms rho theta phi real
    
    fprintf('Computing: _V (x + y + z) dx dy dz\n');
    fprintf('Over sphere: x + y + z   R\n\n');
    
    % Method 1: Cartesian coordinates (theoretical)
    fprintf('Method 1: Cartesian Coordinates\n');
    fprintf('----------------\n');
    
    integrand_cartesian = x^2 + y^2 + z^2;
    fprintf('Integrand: %s\n', char(integrand_cartesian));
    fprintf('Integration limits:\n');
    fprintf('  x: -R to R\n');
    fprintf('  y: - (R - x) to  (R - x)\n');
    fprintf('  z: - (R - x - y) to  (R - x - y)\n');
    
    % Method 2: Spherical coordinates (practical)
    fprintf('\nMethod 2: Spherical Coordinates\n');
    fprintf('---------------\n');
    
    % Coordinate transformation
    x_spherical = rho * sin(phi) * cos(theta);
    y_spherical = rho * sin(phi) * sin(theta);
    z_spherical = rho * cos(phi);
    
    fprintf('Coordinate transformation:\n');
    fprintf('x = %s\n', char(x_spherical));
    fprintf('y = %s\n', char(y_spherical));
    fprintf('z = %s\n', char(z_spherical));
    
    % Jacobian
    jacobian_spherical = rho^2 * sin(phi);
    fprintf('Jacobian: |J| = %s\n', char(jacobian_spherical));
    
    % Transform integrand
    integrand_spherical = subs(integrand_cartesian, [x, y, z], ...
                              [x_spherical, y_spherical, z_spherical]);
    integrand_spherical = simplify(integrand_spherical);
    
    fprintf('Transformed integrand: %s\n', char(integrand_spherical));
    fprintf('Note: x + y + z =   in spherical coordinates\n');
    
    % Complete integrand with Jacobian
    complete_integrand = integrand_spherical * jacobian_spherical;
    complete_integrand = simplify(complete_integrand);
    
    fprintf('Complete integrand: %s\n', char(complete_integrand));
    
    % Integration limits in spherical coordinates
    fprintf('\nIntegration limits (spherical):\n');
    fprintf('   : 0 to R\n');
    fprintf('   : 0 to  \n');
    fprintf('   : 0 to 2 \n');
    
    % Perform the integration symbolically
    fprintf('\nSymbolic integration:\n');
    
    % Integrate over  
    integral_theta = int(complete_integrand, theta, 0, 2*pi);
    integral_theta = simplify(integral_theta);
    fprintf('After   integration: %s\n', char(integral_theta));
    
    % Integrate over  
    integral_phi = int(integral_theta, phi, 0, pi);
    integral_phi = simplify(integral_phi);
    fprintf('After   integration: %s\n', char(integral_phi));
    
    % Integrate over  
    final_integral = int(integral_phi, rho, 0, R);
    final_integral = simplify(final_integral);
    
    fprintf('Final result: %s\n', char(final_integral));
    
    % Verification with known result
    theoretical_result = 4*pi*R^5/5;
    fprintf('\nVerification:\n');
    fprintf('Computed result: %s\n', char(final_integral));
    fprintf('Theoretical result: %s\n', char(theoretical_result));
    
    % Check if they are equal
    difference = simplify(final_integral - theoretical_result);
    fprintf('Difference: %s\n', char(difference));
    
    if isequal(difference, sym(0))
        fprintf(' Results match!\n');
    else
        fprintf(' Results do not match\n');
    end
    
    fprintf('\n');
end

function demonstrate_advanced_calculus_techniques()
    %DEMONSTRATE_ADVANCED_CALCULUS_TECHNIQUES Show sophisticated methods
    %   Demonstrates advanced multi-variable calculus capabilities
    
    fprintf('Advanced Multi-Variable Calculus Techniques\n');
    fprintf('==========================================\n');
    
    % Technique 1: Implicit differentiation
    demonstrate_implicit_differentiation();
    
    % Technique 2: Vector calculus
    demonstrate_vector_calculus();
    
    % Technique 3: Change of variables in multiple integrals
    demonstrate_coordinate_transformations();
    
end

function demonstrate_implicit_differentiation()
    %DEMONSTRATE_IMPLICIT_DIFFERENTIATION Show implicit derivative computation
    %   Computes derivatives of implicitly defined functions
    
    fprintf('Implicit Differentiation:\n');
    fprintf('------------\n');
    
    syms x y real
    
    % Implicit equation: x + y + xy = 1
    implicit_equation = x^2 + y^2 + x*y - 1;
    
    fprintf('Implicit equation: %s = 0\n', char(implicit_equation));
    
    % Compute dy/dx using implicit differentiation
    % d/dx[F(x,y)] = F/x + F/y * dy/dx = 0
    
    dF_dx = diff(implicit_equation, x);
    dF_dy = diff(implicit_equation, y);
    
    % Solve for dy/dx
    dydx_implicit = -dF_dx / dF_dy;
    dydx_implicit = simplify(dydx_implicit);
    
    fprintf('dy/dx = %s\n', char(dydx_implicit));
    
    fprintf('\n');
end

function demonstrate_vector_calculus()
    %DEMONSTRATE_VECTOR_CALCULUS Show gradient, divergence, curl operations
    %   Demonstrates vector field analysis
    
    fprintf('Vector Calculus Operations:\n');
    fprintf('-------------\n');
    
    syms x y z real
    
    % Scalar field
    scalar_field = x^2*y + y^2*z + z^2*x;
    fprintf('Scalar field:  (x,y,z) = %s\n', char(scalar_field));
    
    % Gradient
    gradient_field = [diff(scalar_field, x); diff(scalar_field, y); diff(scalar_field, z)];
    fprintf('Gradient:   = [%s; %s; %s]\n', ...
           char(gradient_field(1)), char(gradient_field(2)), char(gradient_field(3)));
    
    % Vector field
    vector_field_x = y*z;
    vector_field_y = x*z;
    vector_field_z = x*y;
    
    fprintf('\nVector field: F = [%s; %s; %s]\n', ...
           char(vector_field_x), char(vector_field_y), char(vector_field_z));
    
    % Divergence
    divergence = diff(vector_field_x, x) + diff(vector_field_y, y) + diff(vector_field_z, z);
    fprintf('Divergence:  F = %s\n', char(divergence));
    
    % Curl
    curl_x = diff(vector_field_z, y) - diff(vector_field_y, z);
    curl_y = diff(vector_field_x, z) - diff(vector_field_z, x);
    curl_z = diff(vector_field_y, x) - diff(vector_field_x, y);
    
    fprintf('Curl:  F = [%s; %s; %s]\n', char(curl_x), char(curl_y), char(curl_z));
    
    fprintf('\n');
end

function demonstrate_coordinate_transformations()
    %DEMONSTRATE_COORDINATE_TRANSFORMATIONS Show coordinate system changes
    %   Demonstrates integration with coordinate transformations
    
    fprintf('Coordinate Transformations:\n');
    fprintf('-------------\n');
    
    syms x y u v real
    
    % Example: Elliptic coordinates
    % u = a*r*cos( ), v = b*r*sin( )
    syms a b r theta real positive
    
    u_transform = a * r * cos(theta);
    v_transform = b * r * sin(theta);
    
    fprintf('Transformation:\n');
    fprintf('u = %s\n', char(u_transform));
    fprintf('v = %s\n', char(v_transform));
    
    % Compute Jacobian
    du_dr = diff(u_transform, r);
    du_dtheta = diff(u_transform, theta);
    dv_dr = diff(v_transform, r);
    dv_dtheta = diff(v_transform, theta);
    
    jacobian_matrix = [du_dr, du_dtheta; dv_dr, dv_dtheta];
    jacobian_determinant = det(jacobian_matrix);
    jacobian_determinant = simplify(jacobian_determinant);
    
    fprintf('Jacobian determinant: |J| = %s\n', char(jacobian_determinant));
    
    fprintf('\nThis allows transformation of integrals:\n');
    fprintf('_R f(x,y) dx dy = _R'' f(u(r, ), v(r, )) |J| dr d \n');
    
    fprintf('\n');
end
