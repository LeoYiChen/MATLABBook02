%% chapter_ES_code_problem6.m
% Signal Processing with Time-Frequency Analysis
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem6
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem6
    % MATLABBook_ChapterES_Problem6.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Time-frequency analysis of non-stationary signals using STFT,
    %   continuous wavelet transform, and Wigner-Ville distribution.
    %   Includes instantaneous frequency extraction and denoising.
    %
    % Dependencies: Signal Processing Toolbox, Wavelet Toolbox
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 6
    
    fprintf('\n=== Problem 6: Time-Frequency Analysis ===\n\n');
    
    %% Signal Generation
    
    % Sampling parameters
    Fs = 1000;  % Sampling frequency [Hz]
    T = 2;      % Duration [s]
    t = 0:1/Fs:T-1/Fs;
    N = length(t);
    
    % Test signal: Chirp + Transient + Noise
    % Component 1: Linear chirp (10 Hz -> 200 Hz)
    f0_chirp = 10;
    f1_chirp = 200;
    chirp_signal = chirp(t, f0_chirp, T, f1_chirp, 'linear');
    
    % Component 2: Transient sine burst (100 Hz, centered at t=1s)
    t_burst = 1.0;
    burst_width = 0.1;
    burst_freq = 100;
    burst_signal = sin(2*pi*burst_freq*t) .* ...
                   exp(-((t - t_burst)/burst_width).^2);
    
    % Component 3: Frequency modulated tone
    fm_carrier = 50;
    fm_modulation = 5;
    fm_signal = 0.5 * sin(2*pi*fm_carrier*t + 2*sin(2*pi*fm_modulation*t));
    
    % Composite signal
    x_clean = chirp_signal + burst_signal + fm_signal;
    
    % Add white Gaussian noise
    SNR_dB = 10;
    noise = randn(size(x_clean));
    noise = noise / std(noise);  % Normalize
    signal_power = var(x_clean);
    noise_power = signal_power / (10^(SNR_dB/10));
    noise = noise * sqrt(noise_power);
    
    x = x_clean + noise;
    
    fprintf('Signal parameters:\n');
    fprintf('  Sampling rate: %d Hz\n', Fs);
    fprintf('  Duration: %.1f s (%d samples)\n', T, N);
    fprintf('  SNR: %d dB\n', SNR_dB);
    fprintf('  Components: Chirp (10-200 Hz) + Burst (100 Hz) + FM (50 Hz carrier)\n\n');
    
    %% Short-Time Fourier Transform (STFT)
    
    fprintf('=== Method 1: Short-Time Fourier Transform ===\n');
    
    % STFT parameters
    window_length = 256;  % Window length [samples]
    overlap = 0.75;       % 75% overlap
    nfft = 512;           % FFT length
    
    window = hamming(window_length);
    noverlap = round(window_length * overlap);
    
    fprintf('STFT parameters:\n');
    fprintf('  Window: Hamming, length=%d (%.1f ms)\n', window_length, window_length/Fs*1000);
    fprintf('  Overlap: %.0f%%\n', overlap*100);
    fprintf('  FFT length: %d\n\n', nfft);
    
    % Compute STFT
    [S, F_stft, T_stft] = spectrogram(x, window, noverlap, nfft, Fs);
    
    % Power spectral density
    P_stft = abs(S).^2;
    P_stft_dB = 10*log10(P_stft + eps);
    
    fprintf('STFT computed: %d time slices, %d frequencies\n', ...
            length(T_stft), length(F_stft));
    
    % Time and frequency resolution
    delta_t_stft = window_length / Fs;
    delta_f_stft = Fs / nfft;
    uncertainty_product = delta_t_stft * delta_f_stft;
    
    fprintf('Time resolution: %.1f ms\n', delta_t_stft * 1000);
    fprintf('Frequency resolution: %.2f Hz\n', delta_f_stft);
    fprintf('Uncertainty product: %.4f (theoretical min: %.4f)\n\n', ...
            uncertainty_product, 1/(4*pi));
    
    %% Continuous Wavelet Transform (CWT)
    
    fprintf('=== Method 2: Continuous Wavelet Transform ===\n');
    
    % CWT parameters
    wavelet_name = 'amor';  % Analytic Morlet wavelet
    scales = 1:256;
    
    fprintf('CWT parameters:\n');
    fprintf('  Wavelet: %s (Analytic Morlet)\n', wavelet_name);
    fprintf('  Scales: %d to %d\n\n', scales(1), scales(end));
    
    % Compute CWT
    [coeffs, frequencies] = cwt(x, scales, wavelet_name, 1/Fs);
    
    % Power (scalogram)
    P_cwt = abs(coeffs).^2;
    P_cwt_dB = 10*log10(P_cwt + eps);
    
    fprintf('CWT computed: %d time samples, %d scales\n', size(coeffs, 2), size(coeffs, 1));
    fprintf('Frequency range: %.2f - %.2f Hz\n\n', min(frequencies), max(frequencies));
    
    %% Wigner-Ville Distribution
    
    fprintf('=== Method 3: Wigner-Ville Distribution ===\n');
    
    % Simplified WVD (pseudo-WVD with smoothing to reduce cross-terms)
    % For demonstration, use built-in or simplified implementation
    
    % Analytic signal via Hilbert transform
    x_analytic = hilbert(x);
    
    % Simplified WVD (not full implementation, for illustration)
    [WVD, t_wvd, f_wvd] = computeSimplifiedWVD(x_analytic, Fs);
    
    fprintf('WVD computed: %d time points, %d frequencies\n\n', ...
            length(t_wvd), length(f_wvd));
    
    %% Instantaneous Frequency Extraction
    
    fprintf('=== Instantaneous Frequency Extraction ===\n');
    
    % Method 1: From analytic signal phase
    phase = unwrap(angle(x_analytic));
    inst_freq_hilbert = diff(phase) / (2*pi) * Fs;
    inst_freq_hilbert = [inst_freq_hilbert(1), inst_freq_hilbert];  % Pad
    
    % Method 2: From wavelet ridge
    [ridge_idx, inst_freq_wavelet] = extractWaveletRidge(coeffs, frequencies);
    
    fprintf('Instantaneous frequency extracted using:\n');
    fprintf('  1. Hilbert transform (phase derivative)\n');
    fprintf('  2. Wavelet ridge detection\n\n');
    
    % Ground truth IF (from chirp component)
    chirp_rate = (f1_chirp - f0_chirp) / T;
    inst_freq_true = f0_chirp + chirp_rate * t;
    
    %% Wavelet Denoising
    
    fprintf('=== Wavelet Denoising ===\n');
    
    % Discrete wavelet transform for denoising
    wname_den = 'db4';  % Daubechies-4 wavelet
    level = 5;
    
    [C, L] = wavedec(x, level, wname_den);
    
    % Universal threshold (VisuShrink)
    sigma_noise = median(abs(C(end-L(end)+1:end))) / 0.6745;
    threshold = sigma_noise * sqrt(2 * log(N));
    
    % Soft thresholding
    C_thresh = wthresh(C, 's', threshold);
    
    % Reconstruct
    x_denoised = waverec(C_thresh, L, wname_den);
    
    % Performance metrics
    SNR_input = 10*log10(var(x_clean) / var(noise));
    SNR_output = 10*log10(var(x_clean) / var(x_clean - x_denoised));
    improvement = SNR_output - SNR_input;
    
    fprintf('Wavelet: %s, Level: %d\n', wname_den, level);
    fprintf('Threshold: %.4f (universal)\n', threshold);
    fprintf('Input SNR:  %.2f dB\n', SNR_input);
    fprintf('Output SNR: %.2f dB\n', SNR_output);
    fprintf('Improvement: %.2f dB\n\n', improvement);
    
    %% Feature Extraction
    
    fprintf('=== Spectral Features ===\n');
    
    % Compute features from STFT
    [centroid, bandwidth, rolloff] = computeSpectralFeatures(P_stft, F_stft);
    
    fprintf('Time-averaged spectral features:\n');
    fprintf('  Centroid: %.2f Hz\n', mean(centroid));
    fprintf('  Bandwidth: %.2f Hz\n', mean(bandwidth));
    fprintf('  Rolloff (95%%): %.2f Hz\n\n', mean(rolloff));
    
    %% Visualization
    
    figure('Position', [100 100 1400 1000]);
    
    % Subplot 1: Original and denoised signal
    subplot(4, 3, [1 2]);
    plot(t, x, 'Color', [0.7 0.7 0.7], 'LineWidth', 0.5, 'DisplayName', 'Noisy');
    hold on;
    plot(t, x_clean, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Clean');
    plot(t, x_denoised, 'r-', 'LineWidth', 1.2, 'DisplayName', 'Denoised');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Amplitude', 'Interpreter', 'latex');
    title('Signal Comparison', 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 T]);
    
    % Subplot 2: Power spectrum
    subplot(4, 3, 3);
    [Pxx, F_psd] = periodogram(x, hamming(N), N, Fs);
    plot(F_psd, 10*log10(Pxx), 'b-', 'LineWidth', 1);
    xlabel('Frequency [Hz]', 'Interpreter', 'latex');
    ylabel('Power [dB]', 'Interpreter', 'latex');
    title('Power Spectral Density', 'Interpreter', 'latex');
    grid on;
    xlim([0 Fs/2]);
    
    % Subplot 3: STFT Spectrogram
    subplot(4, 3, 4);
    imagesc(T_stft, F_stft, P_stft_dB);
    axis xy;
    colormap(gca, 'jet');
    colorbar;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Frequency [Hz]', 'Interpreter', 'latex');
    title('STFT Spectrogram', 'Interpreter', 'latex');
    ylim([0 250]);
    
    % Subplot 4: CWT Scalogram
    subplot(4, 3, 5);
    imagesc(t, frequencies, P_cwt_dB);
    axis xy;
    colormap(gca, 'jet');
    colorbar;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Frequency [Hz]', 'Interpreter', 'latex');
    title('CWT Scalogram', 'Interpreter', 'latex');
    ylim([0 250]);
    
    % Subplot 5: Wigner-Ville Distribution
    subplot(4, 3, 6);
    imagesc(t_wvd, f_wvd, WVD);
    axis xy;
    colormap(gca, 'jet');
    colorbar;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Frequency [Hz]', 'Interpreter', 'latex');
    title('Wigner-Ville Distribution', 'Interpreter', 'latex');
    ylim([0 250]);
    
    % Subplot 6: Instantaneous frequency
    subplot(4, 3, 7);
    plot(t, inst_freq_true, 'k-', 'LineWidth', 2, 'DisplayName', 'Ground Truth');
    hold on;
    plot(t(1:10:end), inst_freq_hilbert(1:10:end), 'b.', 'MarkerSize', 4, 'DisplayName', 'Hilbert');
    plot(t, inst_freq_wavelet, 'r-', 'LineWidth', 1, 'DisplayName', 'Wavelet Ridge');
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Frequency [Hz]', 'Interpreter', 'latex');
    title('Instantaneous Frequency', 'Interpreter', 'latex');
    legend('Location', 'northwest', 'Interpreter', 'latex');
    grid on;
    ylim([0 250]);
    xlim([0 T]);
    
    % Subplot 7: Wavelet decomposition
    subplot(4, 3, 8);
    for lev = 1:level
        detail = wrcoef('d', C, L, wname_den, lev);
        plot(t, detail + lev*2, 'LineWidth', 0.8);
        hold on;
    end
    approx = wrcoef('a', C, L, wname_den, level);
    plot(t, approx + (level+1)*2, 'k-', 'LineWidth', 1.2);
    hold off;
    xlabel('Time [s]', 'Interpreter', 'latex');
    ylabel('Wavelet Levels', 'Interpreter', 'latex');
    title('Wavelet Decomposition', 'Interpreter', 'latex');
    set(gca, 'YTick', 2:2:2*(level+1), 'YTickLabel', {'D1','D2','D3','D4','D5','A5'});
    grid on;
    xlim([0 T]);
    
    % Subplot 8: Spectral features over time
    subplot(4, 3, 9);
    yyaxis left;
    plot(T_stft, centroid, 'b-', 'LineWidth', 1.5);
    ylabel('Centroid [Hz]', 'Interpreter', 'latex');
    
    yyaxis right;
    plot(T_stft, bandwidth, 'r-', 'LineWidth', 1.5);
    ylabel('Bandwidth [Hz]', 'Interpreter', 'latex');
    
    xlabel('Time [s]', 'Interpreter', 'latex');
    title('Spectral Features Evolution', 'Interpreter', 'latex');
    grid on;
    xlim([0 T]);
    
    % Subplot 9: Time-frequency resolution comparison
    subplot(4, 3, 10);
    window_lengths = [64, 128, 256, 512];
    resolutions = zeros(length(window_lengths), 2);
    
    for i = 1:length(window_lengths)
        wlen = window_lengths(i);
        resolutions(i, 1) = wlen / Fs * 1000;  % Time res [ms]
        resolutions(i, 2) = Fs / wlen;         % Freq res [Hz]
    end
    
    yyaxis left;
    plot(window_lengths, resolutions(:,1), 'bo-', 'LineWidth', 1.5, 'MarkerSize', 8);
    ylabel('Time Resolution [ms]', 'Interpreter', 'latex');
    
    yyaxis right;
    plot(window_lengths, resolutions(:,2), 'rs-', 'LineWidth', 1.5, 'MarkerSize', 8);
    ylabel('Frequency Resolution [Hz]', 'Interpreter', 'latex');
    
    xlabel('Window Length [samples]', 'Interpreter', 'latex');
    title('STFT Resolution Trade-off', 'Interpreter', 'latex');
    grid on;
    
    % Subplot 10: SNR improvement
    subplot(4, 3, 11);
    bar([SNR_input, SNR_output], 'FaceColor', [0.3 0.6 0.9]);
    set(gca, 'XTickLabel', {'Input', 'Output'});
    ylabel('SNR [dB]', 'Interpreter', 'latex');
    title('Denoising Performance', 'Interpreter', 'latex');
    grid on;
    
    % Add improvement annotation
    text(1.5, (SNR_input + SNR_output)/2, sprintf('+%.1f dB', improvement), ...
         'HorizontalAlignment', 'center', 'FontSize', 10, 'FontWeight', 'bold');
    
    % Subplot 11: Cross-section comparison
    subplot(4, 3, 12);
    t_slice = 1.0;  % Time slice at burst center
    [~, idx_slice] = min(abs(T_stft - t_slice));
    
    plot(F_stft, P_stft_dB(:, idx_slice), 'b-', 'LineWidth', 1.5, 'DisplayName', 'STFT');
    hold on;
    [~, idx_cwt_slice] = min(abs(t - t_slice));
    plot(frequencies, P_cwt_dB(:, idx_cwt_slice), 'r-', 'LineWidth', 1.5, 'DisplayName', 'CWT');
    hold off;
    xlabel('Frequency [Hz]', 'Interpreter', 'latex');
    ylabel('Power [dB]', 'Interpreter', 'latex');
    title(sprintf('Spectrum at $t=%.1f$ s', t_slice), 'Interpreter', 'latex');
    legend('Location', 'northeast', 'Interpreter', 'latex');
    grid on;
    xlim([0 250]);
    
    sgtitle('Time-Frequency Analysis', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Figures generated.\n\n');
end

%% Helper Functions

function [WVD, t_out, f_out] = computeSimplifiedWVD(x_analytic, Fs)
    % Simplified Wigner-Ville Distribution (pseudo-WVD with smoothing)
    
    N = length(x_analytic);
    t_out = (0:N-1) / Fs;
    
    % Compute auto-correlation function
    nfft = 2^nextpow2(2*N - 1);
    f_out = linspace(0, Fs/2, nfft/2 + 1);
    
    WVD = zeros(length(f_out), N);
    
    % Simplified computation (time-smoothed to reduce cross-terms)
    window_smooth = 32;
    
    for n = 1:N
        tau_max = min(n-1, N-n);
        tau = -tau_max:tau_max;
        
        auto_corr = zeros(size(tau));
        for k = 1:length(tau)
            if n + tau(k) > 0 && n + tau(k) <= N && n - tau(k) > 0 && n - tau(k) <= N
                auto_corr(k) = x_analytic(n + tau(k)) * conj(x_analytic(n - tau(k)));
            end
        end
        
        % Apply smoothing window
        if length(auto_corr) >= window_smooth
            smooth_win = hamming(window_smooth);
            auto_corr_smooth = conv(auto_corr, smooth_win, 'same');
        else
            auto_corr_smooth = auto_corr;
        end
        
        % FFT to get WVD slice
        spec = fft(auto_corr_smooth, nfft);
        WVD(:, n) = abs(spec(1:nfft/2+1));
    end
    
    % Normalize
    WVD = WVD / max(WVD(:));
end

function [ridge_idx, inst_freq] = extractWaveletRidge(coeffs, frequencies)
    % Extract wavelet ridge (maximum energy path in time-scale plane)
    
    [n_scales, n_times] = size(coeffs);
    ridge_idx = zeros(1, n_times);
    
    power = abs(coeffs).^2;
    
    for t = 1:n_times
        [~, ridge_idx(t)] = max(power(:, t));
    end
    
    % Median filtering to smooth ridge
    ridge_idx = medfilt1(ridge_idx, 5);
    
    % Convert to instantaneous frequency
    inst_freq = frequencies(ridge_idx);
end

function [centroid, bandwidth, rolloff] = computeSpectralFeatures(P, F)
    % Compute spectral features from time-frequency representation
    
    n_times = size(P, 2);
    centroid = zeros(1, n_times);
    bandwidth = zeros(1, n_times);
    rolloff = zeros(1, n_times);
    
    for t = 1:n_times
        spectrum = P(:, t);
        total_power = sum(spectrum);
        
        if total_power > 0
            % Spectral centroid
            centroid(t) = sum(F(:) .* spectrum) / total_power;
            
            % Spectral bandwidth (standard deviation around centroid)
            bandwidth(t) = sqrt(sum(((F(:) - centroid(t)).^2) .* spectrum) / total_power);
            
            % Spectral rolloff (95% energy threshold)
            cumsum_power = cumsum(spectrum);
            rolloff_idx = find(cumsum_power >= 0.95 * total_power, 1, 'first');
            if ~isempty(rolloff_idx)
                rolloff(t) = F(rolloff_idx);
            end
        end
    end
end
