%% chapter_Math_example_symbolic.m
% Symbolic function manipulation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_symbolic
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Requires Symbolic Math Toolbox
% Define symbolic variables
syms x y z t

% Define symbolic expressions (functions)
f = x^2 + 3*x + 2;
g = sin(x) * exp(-x);
h = (x^2 + y^2) / (x*y);

% Symbolic differentiation
df_dx = diff(f, x);           % First derivative: 2*x + 3
d2f_dx2 = diff(f, x, 2);      % Second derivative: 2

% Partial derivatives
dh_dx = diff(h, x);           % Partial derivative with respect to x
dh_dy = diff(h, y);           % Partial derivative with respect to y

% Gradient (vector of partial derivatives)
gradient_h = gradient(h, [x, y]);

% Integration
int_f = int(f, x);            % Indefinite integral
int_f_definite = int(f, x, 0, 1);  % Definite integral from 0 to 1

% Limits
lim1 = limit(sin(x)/x, x, 0);      % Limit as x approaches 0
lim2 = limit((1 + 1/x)^x, x, inf); % Limit as x approaches infinity

% Taylor series expansion
taylor_sin = taylor(sin(x), x, 0, 'Order', 6);  % 6*th order at x=0

% Solving equations
solutions = solve(f == 0, x);  % Solve x^2 + 3*x + 2 = 0

% Simplification
complex_expr = (x^2 - y^2)/(x - y);
simplified = simplify(complex_expr);  % Returns x + y

% Substitution
f_subs = subs(f, x, 5);       % Evaluate f at x = 5
f_subs2 = subs(h, {x, y}, {2, 3});  % Substitute multiple values

% Convert symbolic to numeric
numeric_val = double(f_subs);
