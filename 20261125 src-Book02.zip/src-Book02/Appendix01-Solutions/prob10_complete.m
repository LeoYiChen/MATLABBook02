%% prob10_complete.m
% Problem 10: Multi-GPU Scaling Analysis.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob10_complete
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Problem 10: Multi-GPU Training and Scaling Efficiency
% Author: Dr Yi Chen
% Institution: Newcastle University
% Date: 15 January 2025
% MATLAB Version: R2023b
% Description: Comprehensive analysis of multi-GPU training, scaling laws,
%              communication overhead, and optimization strategies

%% Initialization
clear; close all; clc;

fprintf('================================================================\n');
fprintf('Problem 10: Multi-GPU Training and Scaling Efficiency\n');
fprintf('================================================================\n\n');

%% Hardware Configuration
gpuModel = 'NVIDIA V100 (32GB)';
interconnect = 'NVLink (300 GB/s)';
numGPUsAvailable = 8;

fprintf('Hardware Setup:\n');
fprintf('  GPU Model: %s\n', gpuModel);
fprintf('  Interconnect: %s\n', interconnect);
fprintf('  Available GPUs: %d\n\n', numGPUsAvailable);

%% Model and Dataset Configuration
modelName = 'ResNet-50';
modelSize_GB = 0.25;  % 25.6M parameters   4 bytes   0.1 GB
datasetName = 'ImageNet';
batchSizePerGPU = 64;
numEpochs = 90;

fprintf('Training Configuration:\n');
fprintf('  Model: %s (%.2f GB)\n', modelName, modelSize_GB);
fprintf('  Dataset: %s (1.2M training images)\n', datasetName);
fprintf('  Batch size per GPU: %d\n', batchSizePerGPU);
fprintf('  Total epochs: %d\n\n', numEpochs);

%% Part (a): Scaling Performance Analysis

numGPUs = [1, 2, 4, 8];

% Single GPU baseline
singleGPU_throughput = 425;  % images/sec
singleGPU_epochTime = 1.2e6 / singleGPU_throughput / 60;  % minutes

% Measured throughput with multiple GPUs (images/sec)
throughput = [425, 810, 1540, 2720];  % Sub-linear due to communication

% Training time per epoch (minutes)
epochTime = 1.2e6 ./ throughput / 60;

% Ideal scaling (perfect linear)
idealThroughput = singleGPU_throughput * numGPUs;
idealEpochTime = singleGPU_epochTime ./ numGPUs;

% Scaling efficiency
scalingEfficiency = throughput ./ idealThroughput * 100;

fprintf('========================================\n');
fprintf('(a) Multi-GPU Scaling Performance\n');
fprintf('========================================\n');
fprintf('%-12s %-22s %-22s %-18s %-20s\n', 'Num GPUs', ...
        'Throughput (imgs/s)', 'Ideal Throughput', 'Epoch Time (min)', ...
        'Scaling Eff (%)');
fprintf('%s\n', repmat('-', 1, 98));

for i = 1:length(numGPUs)
    fprintf('%-12d %-22.0f %-22.0f %-18.1f %-20.1f\n', ...
            numGPUs(i), throughput(i), idealThroughput(i), ...
            epochTime(i), scalingEfficiency(i));
end
fprintf('\n');

fprintf('SCALING ANALYSIS:\n');
fprintf('  2 GPUs: %.1f%% efficiency (%.1fx speedup)\n', ...
        scalingEfficiency(2), throughput(2)/throughput(1));
fprintf('  4 GPUs: %.1f%% efficiency (%.1fx speedup)\n', ...
        scalingEfficiency(3), throughput(3)/throughput(1));
fprintf('  8 GPUs: %.1f%% efficiency (%.1fx speedup)\n', ...
        scalingEfficiency(4), throughput(4)/throughput(1));
fprintf('  Efficiency degradation: Communication overhead increases with GPU count\n\n');

%% Part (b): Communication Overhead Breakdown

% Time breakdown per iteration (milliseconds)
computationTime_1GPU = 150;  % Forward + backward pass
communicationTime = [0, 8, 18, 42];  % Gradient all-reduce
otherOverhead = [5, 6, 8, 12];  % Scheduling, sync, etc.

totalIterTime = computationTime_1GPU + communicationTime + otherOverhead;
commPercentage = communicationTime ./ totalIterTime * 100;

fprintf('========================================\n');
fprintf('(b) Communication Overhead Analysis\n');
fprintf('========================================\n');
fprintf('%-12s %-20s %-22s %-22s %-18s\n', 'Num GPUs', ...
        'Computation (ms)', 'Communication (ms)', 'Total Time (ms)', 'Comm %%');
fprintf('%s\n', repmat('-', 1, 98));

for i = 1:length(numGPUs)
    fprintf('%-12d %-20.0f %-22.0f %-22.0f %-18.1f\n', ...
            numGPUs(i), computationTime_1GPU, communicationTime(i), ...
            totalIterTime(i), commPercentage(i));
end
fprintf('\n');

fprintf('COMMUNICATION INSIGHTS:\n');
fprintf('  Single GPU: 0%% communication (no synchronization needed)\n');
fprintf('  8 GPUs: %.1f%% communication (%.0f ms per iteration)\n', ...
        commPercentage(4), communicationTime(4));
fprintf('  Communication time grows with: O(log N) for ring all-reduce\n');
fprintf('  Optimization: Overlap computation and communication\n\n');

%% Part (c): Batch Size Scaling Strategy

% Effective batch size = batchSizePerGPU   numGPUs
effectiveBatchSize = batchSizePerGPU * numGPUs;

% Learning rate scaling (linear scaling rule)
baseLR = 0.1;
scaledLR = baseLR * (effectiveBatchSize / batchSizePerGPU);

% Validation accuracy with different strategies
accuracy_fixedLR = [76.5, 75.8, 72.3, 65.2];  % Fixed LR degrades
accuracy_linearScale = [76.5, 76.3, 76.0, 75.8];  % Linear scaling maintains
accuracy_warmup = [76.5, 76.8, 77.2, 77.5];  % Warmup + linear scaling improves

fprintf('========================================\n');
fprintf('(c) Batch Size and Learning Rate Scaling\n');
fprintf('========================================\n');
fprintf('%-12s %-20s %-18s %-20s %-20s %-22s\n', 'Num GPUs', ...
        'Effective Batch', 'Scaled LR', 'Acc: Fixed LR', 'Acc: Linear', ...
        'Acc: +Warmup');
fprintf('%s\n', repmat('-', 1, 118));

for i = 1:length(numGPUs)
    fprintf('%-12d %-20d %-18.3f %-20.1f %-20.1f %-22.1f\n', ...
            numGPUs(i), effectiveBatchSize(i), scaledLR(i), ...
            accuracy_fixedLR(i), accuracy_linearScale(i), accuracy_warmup(i));
end
fprintf('\n');

fprintf('BATCH SIZE STRATEGY:\n');
fprintf('  Linear Scaling Rule: LR = base_LR   (batch_size / base_batch)\n');
fprintf('  Warmup: Gradually increase LR over first 5 epochs\n');
fprintf('  Result: 8-GPU training achieves %.1f%% (vs %.1f%% single GPU)\n', ...
        accuracy_warmup(4), accuracy_warmup(1));
fprintf('  With warmup: +%.1f%% improvement over fixed LR\n\n', ...
        accuracy_warmup(4) - accuracy_fixedLR(4));

%% Part (d): Mixed Precision Training Impact

% FP32 (full precision) vs FP16 (mixed precision)
precisionModes = {'FP32', 'FP16 (Mixed)'};

% Throughput improvement with mixed precision
throughput_FP32 = throughput;
throughput_FP16 = throughput * 1.8;  % ~80% speedup from reduced memory traffic

% Memory usage (GB)
memoryUsage_FP32 = [12, 13, 14, 16];  % Increases with batch accumulation
memoryUsage_FP16 = [8, 9, 10, 11];    % ~30% reduction

% Communication time (reduced by ~50% due to half data size)
commTime_FP32 = communicationTime;
commTime_FP16 = communicationTime * 0.55;  % Not exactly 50% due to other factors

fprintf('========================================\n');
fprintf('(d) Mixed Precision Training Analysis\n');
fprintf('========================================\n\n');

fprintf('FP32 (Full Precision):\n');
fprintf('%-12s %-22s %-20s %-22s\n', 'Num GPUs', 'Throughput (imgs/s)', ...
        'Memory (GB)', 'Comm Time (ms)');
fprintf('%s\n', repmat('-', 1, 80));

for i = 1:length(numGPUs)
    fprintf('%-12d %-22.0f %-20.1f %-22.0f\n', ...
            numGPUs(i), throughput_FP32(i), memoryUsage_FP32(i), ...
            commTime_FP32(i));
end
fprintf('\n');

fprintf('FP16 (Mixed Precision):\n');
fprintf('%-12s %-22s %-20s %-22s %-20s\n', 'Num GPUs', ...
        'Throughput (imgs/s)', 'Memory (GB)', 'Comm Time (ms)', 'Speedup');
fprintf('%s\n', repmat('-', 1, 100));

for i = 1:length(numGPUs)
    speedup = throughput_FP16(i) / throughput_FP32(i);
    fprintf('%-12d %-22.0f %-20.1f %-22.0f %-20.2fx\n', ...
            numGPUs(i), throughput_FP16(i), memoryUsage_FP16(i), ...
            commTime_FP16(i), speedup);
end
fprintf('\n');

fprintf('MIXED PRECISION BENEFITS:\n');
fprintf('  Throughput: +%.0f%% average improvement\n', ...
        mean((throughput_FP16 ./ throughput_FP32 - 1) * 100));
fprintf('  Memory: ~%.0f GB saved per GPU\n', ...
        mean(memoryUsage_FP32 - memoryUsage_FP16));
fprintf('  Communication: ~%.0f%% reduction in sync time\n', ...
        mean((1 - commTime_FP16 ./ commTime_FP32) * 100));
fprintf('  Accuracy: Minimal impact (<0.1%% difference) with loss scaling\n\n');

%% Part (e): Gradient Compression Analysis

compressionRatios = [1.0, 0.5, 0.25, 0.1, 0.01];  % 1.0 = no compression
compressionMethods = {'No Compression', 'FP16', 'Top-50%%', 'Top-25%%', 'Top-1%%'};

% Communication time reduction
commTimeReduction = communicationTime(4) * compressionRatios;

% Accuracy impact (aggressive compression hurts convergence)
accuracyImpact = [0, -0.05, -0.15, -0.4, -2.1];  % Percentage points

% Compression overhead (CPU time for encoding/decoding)
compressionOverhead = [0, 2, 5, 8, 15];  % Milliseconds

fprintf('========================================\n');
fprintf('(e) Gradient Compression Strategies (8 GPUs)\n');
fprintf('========================================\n');
fprintf('%-20s %-22s %-22s %-22s %-18s\n', 'Method', 'Compression Ratio', ...
        'Comm Time (ms)', 'Overhead (ms)', 'Accuracy   (%)');
fprintf('%s\n', repmat('-', 1, 108));

for i = 1:length(compressionMethods)
    fprintf('%-20s %-22.2f %-22.1f %-22.0f ', ...
            compressionMethods{i}, compressionRatios(i), ...
            commTimeReduction(i), compressionOverhead(i));
    
    if accuracyImpact(i) >= 0
        fprintf('%-18s\n', sprintf('+%.2f', accuracyImpact(i)));
    else
        fprintf('%-18s\n', sprintf('%.2f', accuracyImpact(i)));
    end
end
fprintf('\n');

fprintf('COMPRESSION RECOMMENDATION:\n');
fprintf('  Best trade-off: Top-50%% sparsification\n');
fprintf('  - Reduces communication by 50%%\n');
fprintf('  - Minimal accuracy loss: -%.2f%%\n', accuracyImpact(3));
fprintf('  - Low overhead: %d ms per iteration\n', compressionOverhead(3));
fprintf('  Avoid: Top-1%% (loses too much information)\n\n');

%% Part (f): Optimal GPU Count Analysis

% Total training time (hours) = epochs   epoch_time
totalTrainingTime_FP32 = numEpochs * epochTime / 60;

% With mixed precision and optimizations
epochTime_optimized = epochTime * 0.6;  % 40% improvement
totalTrainingTime_optimized = numEpochs * epochTime_optimized / 60;

% Cost model: GPU-hours
gpuHours = numGPUs .* totalTrainingTime_FP32;
gpuHours_optimized = numGPUs .* totalTrainingTime_optimized;

% Cost per GPU-hour (example pricing)
costPerGPUHour = 2.50;  % USD
totalCost = gpuHours * costPerGPUHour;
totalCost_optimized = gpuHours_optimized * costPerGPUHour;

fprintf('========================================\n');
fprintf('(f) Optimal GPU Count Selection\n');
fprintf('========================================\n');
fprintf('%-12s %-20s %-22s %-20s %-18s\n', 'Num GPUs', ...
        'Train Time (hrs)', 'GPU-Hours', 'Cost (USD)', 'Efficiency');
fprintf('%s\n', repmat('-', 1, 98));

for i = 1:length(numGPUs)
    fprintf('%-12d %-20.1f %-22.1f %-20.1f %-18.1f%%\n', ...
            numGPUs(i), totalTrainingTime_FP32(i), gpuHours(i), ...
            totalCost(i), scalingEfficiency(i));
end
fprintf('\n');

% Find optimal (minimum cost or time, depending on priorities)
[minCost, minCostIdx] = min(totalCost);
[minTime, minTimeIdx] = min(totalTrainingTime_FP32);

fprintf('OPTIMIZATION TARGETS:\n');
fprintf('  Minimum cost: %d GPUs (%.1f USD, %.1f hrs)\n', ...
        numGPUs(minCostIdx), minCost, totalTrainingTime_FP32(minCostIdx));
fprintf('  Minimum time: %d GPUs (%.1f hrs, %.1f USD)\n', ...
        numGPUs(minTimeIdx), minTime, totalCost(minTimeIdx));
fprintf('  Recommended: 4 GPUs (good balance of cost/time/efficiency)\n\n');

fprintf('WITH OPTIMIZATIONS (Mixed Precision + Gradient Compression):\n');
fprintf('  4 GPUs: %.1f hrs (%.0f%% faster), %.1f USD (%.0f%% cheaper)\n', ...
        totalTrainingTime_optimized(3), ...
        (1 - totalTrainingTime_optimized(3) / totalTrainingTime_FP32(3)) * 100, ...
        totalCost_optimized(3), ...
        (1 - totalCost_optimized(3) / totalCost(3)) * 100);
fprintf('  8 GPUs: %.1f hrs (%.0f%% faster), %.1f USD (%.0f%% cheaper)\n\n', ...
        totalTrainingTime_optimized(4), ...
        (1 - totalTrainingTime_optimized(4) / totalTrainingTime_FP32(4)) * 100, ...
        totalCost_optimized(4), ...
        (1 - totalCost_optimized(4) / totalCost(4)) * 100);

%% Part (g): Data vs Model Parallelism

% Model parallelism is needed when model doesn't fit in single GPU
modelSizes_GB = [0.25, 2.5, 10, 40, 175];  % ResNet-50, VGG, GPT-2, GPT-3 small, GPT-3
modelNames = {'ResNet-50', 'VGG-19', 'GPT-2', 'GPT-3 (6.7B)', 'GPT-3 (175B)'};
singleGPU_capacity = 32;  % GB

% Can fit in single GPU
fitsInSingleGPU = modelSizes_GB <= singleGPU_capacity;

% Minimum GPUs required for model parallelism
minGPUs_model = ceil(modelSizes_GB / singleGPU_capacity);

% Recommended strategy
strategy = cell(size(modelNames));
for i = 1:length(modelNames)
    if fitsInSingleGPU(i)
        strategy{i} = 'Data Parallelism';
    elseif minGPUs_model(i) <= 8
        strategy{i} = 'Model Parallelism';
    else
        strategy{i} = 'Pipeline Parallelism';
    end
end

fprintf('========================================\n');
fprintf('(g) Data vs Model Parallelism\n');
fprintf('========================================\n');
fprintf('%-18s %-18s %-20s %-20s %-25s\n', 'Model', 'Size (GB)', ...
        'Fits Single GPU', 'Min GPUs (Model)', 'Recommended Strategy');
fprintf('%s\n', repmat('-', 1, 108));

for i = 1:length(modelNames)
    fprintf('%-18s %-18.1f %-20s %-20d %-25s\n', ...
            modelNames{i}, modelSizes_GB(i), ...
            fitsInSingleGPU(i)  'Yes' : 'No', minGPUs_model(i), ...
            strategy{i});
end
fprintf('\n');

fprintf('PARALLELISM GUIDELINES:\n');
fprintf('  Data Parallelism: Model fits in GPU, scale by replicating\n');
fprintf('  Model Parallelism: Split layers across GPUs when too large\n');
fprintf('  Pipeline Parallelism: For very large models (>100B params)\n');
fprintf('  Hybrid: Combine data + model parallelism for mega-models\n\n');

%% Visualization

figure('Position', [50, 50, 1800, 1000], 'Color', 'w');

% Panel 1: Scaling Efficiency
subplot(2, 4, 1);
plot(numGPUs, throughput, 'b-o', 'LineWidth', 2.5, 'MarkerSize', 12, ...
     'MarkerFaceColor', 'b', 'DisplayName', 'Actual');
hold on;
plot(numGPUs, idealThroughput, 'r-', 'LineWidth', 2.5, ...
     'DisplayName', 'Ideal');

xlabel('Number of GPUs', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Throughput (images/sec)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(a) Scaling Performance}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend('Interpreter', 'latex', 'Location', 'northwest', 'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 2: Scaling Efficiency Percentage
subplot(2, 4, 2);
bar(numGPUs, scalingEfficiency, 'FaceColor', [0.3, 0.7, 0.4], ...
    'EdgeColor', 'k', 'LineWidth', 1.5);
hold on;
yline(100, 'r-', 'LineWidth', 2, 'Label', 'Perfect Scaling', ...
      'Interpreter', 'latex');

xlabel('Number of GPUs', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Scaling Efficiency (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(b) Efficiency Degradation}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);
ylim([0, 110]);

% Panel 3: Time Breakdown
subplot(2, 4, 3);
bar(numGPUs, [computationTime_1GPU*ones(size(numGPUs)); ...
              communicationTime; otherOverhead]', 'stacked', ...
    'EdgeColor', 'k', 'LineWidth', 1.2);

xlabel('Number of GPUs', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Time per Iteration (ms)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(c) Time Breakdown}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend({'Computation', 'Communication', 'Other'}, 'Interpreter', 'latex', ...
       'Location', 'northwest', 'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 4: Batch Size Scaling Strategies
subplot(2, 4, 4);
plot(numGPUs, accuracy_fixedLR, 'r-o', 'LineWidth', 2.5, 'MarkerSize', 10, ...
     'DisplayName', 'Fixed LR');
hold on;
plot(numGPUs, accuracy_linearScale, 'b-s', 'LineWidth', 2.5, ...
     'MarkerSize', 10, 'DisplayName', 'Linear Scale');
plot(numGPUs, accuracy_warmup, 'g-^', 'LineWidth', 2.5, 'MarkerSize', 10, ...
     'DisplayName', 'Linear + Warmup');

xlabel('Number of GPUs', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Validation Accuracy (\%)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(d) LR Scaling Strategies}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend('Interpreter', 'latex', 'Location', 'southwest', 'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 5: Mixed Precision Speedup
subplot(2, 4, 5);
speedups = throughput_FP16 ./ throughput_FP32;
bar(numGPUs, [throughput_FP32', throughput_FP16'], 'EdgeColor', 'k', ...
    'LineWidth', 1.5);

xlabel('Number of GPUs', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Throughput (images/sec)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(e) FP32 vs FP16}', 'Interpreter', 'latex', ...
      'FontSize', 15);
legend({'FP32', 'FP16'}, 'Interpreter', 'latex', 'Location', 'northwest', ...
       'FontSize', 11);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 6: Gradient Compression Trade-off
subplot(2, 4, 6);
yyaxis left
bar(commTimeReduction, 'FaceColor', [0.5, 0.5, 0.8], 'EdgeColor', 'k');
ylabel('Communication Time (ms)', 'Interpreter', 'latex', 'FontSize', 13);

yyaxis right
plot(1:length(compressionMethods), accuracyImpact, 'r-o', ...
     'LineWidth', 2.5, 'MarkerSize', 10, 'MarkerFaceColor', 'r');
ylabel('Accuracy Impact (\%)', 'Interpreter', 'latex', 'FontSize', 13);

title('\textbf{(f) Gradient Compression}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'XTickLabel', {'None', 'FP16', '50\%', '25\%', '1\%'}, ...
         'FontSize', 11);
grid on; box on;

% Panel 7: Cost-Time Trade-off
subplot(2, 4, 7);
scatter(totalTrainingTime_FP32, totalCost, 250, numGPUs, 'filled', ...
        'MarkerEdgeColor', 'k');
colorbar;
colormap('jet');

xlabel('Training Time (hours)', 'Interpreter', 'latex', 'FontSize', 13);
ylabel('Total Cost (USD)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(g) Cost-Time Trade-off}', 'Interpreter', 'latex', ...
      'FontSize', 15);
grid on; box on;
set(gca, 'FontSize', 12);

% Panel 8: Model Parallelism Requirements
subplot(2, 4, 8);
barh(modelSizes_GB, 'FaceColor', [0.8, 0.5, 0.3], 'EdgeColor', 'k', ...
     'LineWidth', 1.5);
hold on;
xline(singleGPU_capacity, 'r-', 'LineWidth', 2.5, ...
      'Label', 'Single GPU Capacity', 'Interpreter', 'latex', ...
      'LabelHorizontalAlignment', 'left');

xlabel('Model Size (GB)', 'Interpreter', 'latex', 'FontSize', 13);
title('\textbf{(h) Model Parallelism Need}', 'Interpreter', 'latex', ...
      'FontSize', 15);
set(gca, 'YTickLabel', modelNames, 'FontSize', 11);
set(gca, 'XScale', 'log');
grid on; box on;

fprintf('========================================\n');
fprintf('FINAL RECOMMENDATIONS\n');
fprintf('========================================\n\n');

fprintf('FOR PRODUCTION TRAINING:\n');
fprintf('  1. Start with 4 GPUs for good cost/performance balance\n');
fprintf('  2. Use mixed precision (FP16) for 1.8x speedup\n');
fprintf('  3. Apply linear LR scaling with 5-epoch warmup\n');
fprintf('  4. Enable gradient compression (Top-50%%) for large models\n');
fprintf('  5. Monitor scaling efficiency add GPUs only if >80%%\n\n');

fprintf('EXPECTED PERFORMANCE (4 GPUs, Optimized):\n');
fprintf('  Training time: %.1f hours (vs %.1f for single GPU)\n', ...
        totalTrainingTime_optimized(3), totalTrainingTime_FP32(1));
fprintf('  Speedup: %.1fx\n', totalTrainingTime_FP32(1) / ...
        totalTrainingTime_optimized(3));
fprintf('  Cost: $%.1f (GPU-hours: %.1f)\n', totalCost_optimized(3), ...
        gpuHours_optimized(3));
fprintf('  Scaling efficiency: %.1f%%\n\n', scalingEfficiency(3));

fprintf('Analysis complete! Multi-GPU training enables fast, efficient model training.\n\n');
