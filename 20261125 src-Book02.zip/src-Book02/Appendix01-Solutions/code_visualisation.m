%% code_visualisation.m
% Visualisation function.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : code:visualisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function visualiseMorphing(X, Y, U_initial, U_final, F_active)
    % Visualise the morphing process
    % Inputs:
    %   X, Y - Coordinate meshgrids
    %   U_initial - Initial displacement field
    %   U_final - Final displacement field
    %   F_active - Actuation field
    
    figure('Position', [100, 100, 1400, 400]);
    
    % Initial configuration
    subplot(1, 3, 1);
    surf(X, Y, U_initial, 'EdgeColor', 'none');
    colormap(jet);
    colorbar;
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$u$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Initial Configuration', 'Interpreter', 'latex', 'FontSize', 14);
    view(45, 30);
    axis tight;
    
    % Actuation pattern
    subplot(1, 3, 2);
    contourf(X, Y, F_active, 20);
    colormap(jet);
    colorbar;
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Actuation Pattern $f_{\mathrm{active}}$', 'Interpreter', 'latex', ...
        'FontSize', 14);
    axis equal tight;
    
    % Final morphed configuration
    subplot(1, 3, 3);
    surf(X, Y, U_final, 'EdgeColor', 'none');
    colormap(jet);
    colorbar;
    xlabel('$x$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$u$ (m)', 'Interpreter', 'latex', 'FontSize', 12);
    title('Morphed Configuration', 'Interpreter', 'latex', 'FontSize', 14);
    view(45, 30);
    axis tight;
    
    sgtitle('\textbf{Active Morphing Simulation Results}', ...
        'Interpreter', 'latex', 'FontSize', 16);
end
