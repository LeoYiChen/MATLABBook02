%% chapter_AI_Mechanics_Problem1_polyreg_syntax.m
% Polynomial regression syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem1_polyreg_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Train polynomial regression model
polyDegree = 3;
[polyModel, polyStats] = fitlm(featuresTrain, targetTrain, ...
    'poly' + string(polyDegree), ...  % Polynomial order
    'RobustOpts', 'off');              % Standard least squares

% Predict on test data
predictionsPoly = predict(polyModel, featuresTest);

% Evaluate performance
rmsePoly = sqrt(mean((predictionsPoly - targetTest).^2));
r2Poly = polyStats.Rsquared.Ordinary;
