# C0201Introduction - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines |
| Chapter | Introduction |
| Package version | 1.1.0 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P02-20261027` |
| Source chapter file | `P0202main/C0201Introduction/` (included by `P02_20260830.tex`) |
| Code files | 23 |
| Code lines relocated | 1,383 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting`, every code `verbatim`
environment and every `\lstinputlisting` call in the chapter has been removed
from the main body and deposited here. Only the filename, the listing caption
and a reference to this folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `C0201Introduction_code_NNN.m`.
- Code held in a `verbatim` environment receives `C0201Introduction_verbatim_NN.m`.
- Code loaded by `\lstinputlisting` keeps the label of that call, so
  `chapter_CW04_code_runner` becomes `chapter_CW04_code_runner.m`.
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 4.3:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book02/C0201Introduction/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook02
```

Clone or download `src-Book02/` from this repository, or use the Springer
supplementary archive. The same address is printed in the preface of the book.
Keep the `src-Book02/` folder name so that the in-text `src-Book02/C0201Introduction/`
paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `C0201Introduction_code_008.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_009.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_010.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_011.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_012.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_013.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_014.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_015.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_016.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_017.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_018.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_019.m` | `(generated)` | MATLAB source code for this example. |
| `C0201Introduction_code_020.m` | `(generated)` | MATLAB source code for this example. |
| `listing_21.m` | `listing_21` | Convergence rate analysis for numerical differentiation |
| `listing_22.m` | `listing_22` | Publication-quality damped oscillatory signals |
| `listing_23.m` | `listing_23` | Colourblind-friendly palettes and line styles |
| `lst_C01_DataStructuresExample.m` | `lst:C01_DataStructuresExample` | Basic data structures in MATLAB demonstrating arrays, cell arrays, structures, and tables |
| `lst_C01_Lab01.m` | `lst:C01_Lab01` | Basic MATLAB operations with AI preprocessing context |
| `lst_C01_Lab02.m` | `lst:C01_Lab02` | Basic neural network classification using Fisher's iris dataset |
| `lst_C01_Lab03.m` | `lst:C01_Lab03` | MATLAB--Python signal filtering with a SciPy Butterworth low-pass |
| `lst_C01_Lab04.m` | `lst:C01_Lab04` | Reproducible research practices implementation |
| `lst_C01_Lab05.m` | `lst:C01_Lab05` | AI-assisted surrogate modelling of a 2D heat-transfer field in MATLAB |
| `lst_C01_VisualisationExample.m` | `lst:C01_VisualisationExample` | Basic visualisation demonstrating multiple plot types and customisation options |
