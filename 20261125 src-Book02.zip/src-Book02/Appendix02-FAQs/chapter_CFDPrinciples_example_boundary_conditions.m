%% chapter_CFDPrinciples_example_boundary_conditions.m
% Physically-consistent boundary condition specification.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_CFDPrinciples_example_boundary_conditions
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function boundaryConditions = specifyBoundaryConditions(flowConfig, ...
    geometryInfo, fluidProperties)
    % SPECIFYBOUNDARYCONDITIONS Generate physics-based boundary conditions
    % Computes inlet profiles, turbulence quantities, and wall treatments
    %
    % Inputs:
    %   flowConfig      - Struct: inletVelocity, outletPressure, temperature,
    %                     turbulenceLevel, flowType ('laminar'/'turbulent')
    %   geometryInfo    - Struct: inletDiameter, characteristicLength, 
    %                     wallRoughness
    %   fluidProperties - Struct: density, viscosity, specificHeat
    %
    % Output:
    %   boundaryConditions - Comprehensive BC specification
    %
    % Author: Dr Leo Chen
    % Institution: University of Oxford
    % Version: 3.0
    %
    % References:
    %   [1] Pope (2000) Turbulent Flows
    %   [2] Wilcox (2006) Turbulence Modeling for CFD
    %   [3] White (2011) Fluid Mechanics
    
    fprintf('=== Boundary Condition Specification ===\n\n');
    
    boundaryConditions = struct();
    
    % Compute flow Reynolds number
    Re = fluidProperties.density * flowConfig.inletVelocity * ...
         geometryInfo.characteristicLength / fluidProperties.viscosity;
    
    fprintf('Flow Reynolds number: %.2e\n\n', Re);
    
    % Inlet boundary conditions
    inletBC = specifyInletConditions(flowConfig, geometryInfo, ...
                                     fluidProperties, Re);
    boundaryConditions.inlet = inletBC;
    
    % Wall boundary conditions
    wallBC = specifyWallConditions(flowConfig, geometryInfo, Re);
    boundaryConditions.wall = wallBC;
    
    % Outlet boundary conditions
    outletBC = specifyOutletConditions(flowConfig, Re);
    boundaryConditions.outlet = outletBC;
    
    % Initial conditions
    initialConditions = specifyInitialConditions(flowConfig, inletBC);
    boundaryConditions.initial = initialConditions;
    
    % Display summary
    displayBoundarySummary(boundaryConditions);
    
    fprintf('\nBoundary condition specification completed.\n');
end

function inletBC = specifyInletConditions(flowCfg, geomInfo, fluidProps, Re)
    % Specify inlet boundary conditions with turbulence
    
    inletBC = struct();
    inletBC.type = 'velocity_inlet';
    
    % Mean velocity specification
    U_inlet = flowCfg.inletVelocity;
    inletBC.meanVelocity = U_inlet;
    
    % Determine if flow is laminar or turbulent
    if strcmp(flowCfg.flowType, 'turbulent') || Re > 4000
        inletBC.flowRegime = 'turbulent';
        
        % Turbulence intensity (empirical correlation for pipe flow)
        if Re > 0
            I = 0.16 * Re^(-1/8);
        else
            I = 0.05;  % Default 5%
        end
        
        % Override with specified turbulence level if provided
        if isfield(flowCfg, 'turbulenceLevel')
            I = flowCfg.turbulenceLevel;
        end
        
        inletBC.turbulenceIntensity = I;
        
        % Turbulent kinetic energy
        k_inlet = 1.5 * (U_inlet * I)^2;
        inletBC.turbulentKE = k_inlet;
        
        % Turbulent length scale (7% of hydraulic diameter)
        if isfield(geomInfo, 'inletDiameter')
            ell = 0.07 * geomInfo.inletDiameter;
        else
            ell = 0.07 * geomInfo.characteristicLength;
        end
        
        inletBC.turbulentLengthScale = ell;
        
        % Turbulent dissipation rate (k-epsilon model)
        C_mu = 0.09;
        epsilon_inlet = C_mu^(3/4) * k_inlet^(1.5) / ell;
        inletBC.turbulentDissipation = epsilon_inlet;
        
        % Specific dissipation rate (k-omega model)
        omega_inlet = epsilon_inlet / (C_mu * k_inlet);
        inletBC.specificDissipation = omega_inlet;
        
        fprintf('Inlet turbulence properties:\n');
        fprintf('  Turbulence intensity: %.4f (%.2f%%)\n', I, I*100);
        fprintf('  Turbulent kinetic energy k: %.4e m?/s?\n', k_inlet);
        fprintf('  Dissipation rate epsilon: %.4e m?/s?\n', epsilon_inlet);
        fprintf('  Specific dissipation omega: %.4e 1/s\n', omega_inlet);
        fprintf('  Length scale: %.4f m\n\n', ell);
        
        % Velocity profile (power-law for turbulent)
        inletBC.velocityProfile = @(r, R) U_inlet * (1 - abs(r)/R)^(1/7);
        inletBC.profileType = 'power_law_1_7th';
        
    else
        % Laminar flow
        inletBC.flowRegime = 'laminar';
        inletBC.turbulenceIntensity = 0;
        inletBC.turbulentKE = 0;
        inletBC.turbulentDissipation = 0;
        
        % Parabolic velocity profile (Hagen-Poiseuille)
        inletBC.velocityProfile = @(r, R) 2*U_inlet * (1 - (r/R)^2);
        inletBC.profileType = 'parabolic_laminar';
        
        fprintf('Laminar inlet - parabolic velocity profile\n\n');
    end
    
    % Temperature (if thermal problem)
    if isfield(flowCfg, 'temperature')
        inletBC.temperature = flowCfg.temperature;
        inletBC.thermalBC = 'fixed_temperature';
    end
end

function wallBC = specifyWallConditions(flowCfg, geomInfo, Re)
    % Specify wall boundary conditions
    
    wallBC = struct();
    wallBC.type = 'wall';
    
    % No-slip condition for velocity
    wallBC.velocityCondition = 'no_slip';
    wallBC.velocity = [0, 0, 0];
    
    % Wall function vs resolved boundary layer
    if strcmp(flowCfg.flowType, 'turbulent') || Re > 4000
        % Determine appropriate wall treatment
        
        % Estimate wall shear stress (using empirical friction factor)
        U_bulk = flowCfg.inletVelocity;
        
        if Re < 2300
            f = 64 / Re;  % Laminar
        else
            % Colebrook-White approximation (smooth pipe)
            f = 0.316 * Re^(-0.25);  % Blasius for Re < 1e5
        end
        
        wallBC.estimatedFrictionFactor = f;
        
        % Target y+ value
        if isfield(flowCfg, 'wallTreatment')
            wallBC.wallTreatment = flowCfg.wallTreatment;
        else
            % Default: wall functions
            wallBC.wallTreatment = 'wall_functions';
        end
        
        if strcmp(wallBC.wallTreatment, 'wall_functions')
            wallBC.target_yplus = 50;  % Centre of log-layer
            wallBC.yplus_range = [30, 300];
            wallBC.turbulenceBC = 'wall_functions';
            
        elseif strcmp(wallBC.wallTreatment, 'low_Re')
            wallBC.target_yplus = 1;
            wallBC.yplus_range = [0, 5];
            wallBC.turbulenceBC = 'low_Reynolds_damping';
        end
        
        fprintf('Wall treatment:\n');
        fprintf('  Method: %s\n', wallBC.wallTreatment);
        fprintf('  Target y+: %.1f\n', wallBC.target_yplus);
        fprintf('  Acceptable range: [%.1f, %.1f]\n\n', ...
                wallBC.yplus_range(1), wallBC.yplus_range(2));
        
    else
        % Laminar flow - always resolve to wall
        wallBC.target_yplus = 0.1;
        wallBC.turbulenceBC = 'not_applicable';
    end
    
    % Thermal wall condition
    if isfield(flowCfg, 'wallTemperature')
        wallBC.thermalBC = 'fixed_temperature';
        wallBC.temperature = flowCfg.wallTemperature;
    elseif isfield(flowCfg, 'wallHeatFlux')
        wallBC.thermalBC = 'fixed_heat_flux';
        wallBC.heatFlux = flowCfg.wallHeatFlux;
    else
        wallBC.thermalBC = 'adiabatic';
    end
    
    % Roughness
    if isfield(geomInfo, 'wallRoughness')
        wallBC.roughness = geomInfo.wallRoughness;
        wallBC.roughnessConstant = 9.793 * wallBC.roughness;
    else
        wallBC.roughness = 0;  % Smooth wall
    end
end

function outletBC = specifyOutletConditions(flowCfg, Re)
    % Specify outlet boundary conditions
    
    outletBC = struct();
    
    % Determine appropriate outlet BC based on flow regime
    if isfield(flowCfg, 'outletPressure')
        outletBC.type = 'pressure_outlet';
        outletBC.pressure = flowCfg.outletPressure;
        outletBC.velocityGradient = 'zero_gradient';
        
        fprintf('Outlet boundary condition:\n');
        fprintf('  Type: Pressure outlet\n');
        fprintf('  Static pressure: %.2f Pa\n\n', outletBC.pressure);
        
    else
        % Default: outflow (zero gradient for all variables)
        outletBC.type = 'outflow';
        outletBC.gradientCondition = 'zero_gradient_all_variables';
        
        fprintf('Outlet boundary condition:\n');
        fprintf('  Type: Outflow (zero gradient)\n\n');
    end
    
    % Backflow prevention (for pressure outlets)
    if strcmp(outletBC.type, 'pressure_outlet')
        outletBC.backflowPrevention = true;
        outletBC.backflowTurbulence = 'ambient_values';
    end
end

function initialCond = specifyInitialConditions(flowCfg, inletBC)
    % Specify initial field conditions
    
    initialCond = struct();
    
    % Velocity initialisation (fraction of inlet velocity)
    initialCond.velocity = 0.1 * inletBC.meanVelocity;
    
    % Pressure initialisation
    if isfield(flowCfg, 'outletPressure')
        initialCond.pressure = flowCfg.outletPressure;
    else
        initialCond.pressure = 101325;  % Atmospheric
    end
    
    % Turbulence initialisation
    if isfield(inletBC, 'turbulentKE')
        initialCond.turbulentKE = 0.1 * inletBC.turbulentKE;
        initialCond.turbulentDissipation = 0.1 * inletBC.turbulentDissipation;
    else
        initialCond.turbulentKE = 0;
        initialCond.turbulentDissipation = 0;
    end
    
    % Temperature initialisation
    if isfield(inletBC, 'temperature')
        initialCond.temperature = inletBC.temperature;
    end
    
    fprintf('Initial field conditions:\n');
    fprintf('  Velocity: %.4f m/s (10%% of inlet)\n', initialCond.velocity);
    fprintf('  Pressure: %.2f Pa\n', initialCond.pressure);
    
    if initialCond.turbulentKE > 0
        fprintf('  Turbulent KE: %.4e m?/s?\n', initialCond.turbulentKE);
    end
    
    fprintf('\n');
end

function displayBoundarySummary(bc)
    % Display comprehensive boundary condition summary
    
    fprintf('\n=== Boundary Condition Summary ===\n\n');
    
    fprintf('INLET:\n');
    fprintf('  Type: %s\n', bc.inlet.type);
    fprintf('  Flow regime: %s\n', bc.inlet.flowRegime);
    fprintf('  Mean velocity: %.4f m/s\n', bc.inlet.meanVelocity);
    fprintf('  Velocity profile: %s\n', bc.inlet.profileType);
    
    if isfield(bc.inlet, 'turbulenceIntensity') && bc.inlet.turbulenceIntensity > 0
        fprintf('  Turbulence intensity: %.4f\n', bc.inlet.turbulenceIntensity);
    end
    
    fprintf('\nWALL:\n');
    fprintf('  Velocity: No-slip\n');
    
    if isfield(bc.wall, 'wallTreatment')
        fprintf('  Wall treatment: %s\n', bc.wall.wallTreatment);
        fprintf('  Target y+: %.1f\n', bc.wall.target_yplus);
    end
    
    fprintf('  Thermal BC: %s\n', bc.wall.thermalBC);
    
    fprintf('\nOUTLET:\n');
    fprintf('  Type: %s\n', bc.outlet.type);
    
    if strcmp(bc.outlet.type, 'pressure_outlet')
        fprintf('  Pressure: %.2f Pa\n', bc.outlet.pressure);
    end
    
    fprintf('\nINITIAL CONDITIONS:\n');
    fprintf('  Velocity: %.4f m/s\n', bc.initial.velocity);
    fprintf('  Pressure: %.2f Pa\n', bc.initial.pressure);
    
    fprintf('\n=== End of Summary ===\n');
end
