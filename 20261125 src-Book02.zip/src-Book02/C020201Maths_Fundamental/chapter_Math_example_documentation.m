%% chapter_Math_example_documentation.m
% Function documentation template.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_documentation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function [output1, output2] = exampleFunction(input1, input2, options)
    % EXAMPLEFUNCTION One-line summary of function purpose
    %   Detailed description spanning multiple lines if necessary,
    %   explaining what the function does and why.
    %
    %   Syntax:
    %       output1 = exampleFunction(input1, input2)
    %       [output1, output2] = exampleFunction(input1, input2, options)
    %
    %   Inputs:
    %       input1 - Description of first input parameter
    %                (data type, size requirements, valid ranges)
    %       input2 - Description of second input parameter
    %       options - (Optional) Structure with fields:
    %                   field1: description
    %                   field2: description
    %
    %   Outputs:
    %       output1 - Description of first output
    %       output2 - Description of second output
    %
    %   Example:
    %       x = [1 2 3 4 5];
    %       y = [2 4 6 8 10];
    %       result = exampleFunction(x, y);
    %
    %   See also: RELATEDFUNCTION1, RELATEDFUNCTION2
    
    % Implementation follows...
end
