%% chapter_FundamentalMaths_syntax_Wavelet.m
% Basic wavelet transform syntax in MATLAB.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_syntax_Wavelet
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Continuous Wavelet Transform
[coefficients, frequencies] = cwt(signal, waveletName, samplingFrequency);

% Discrete Wavelet Transform
[C, L] = wavedec(signal, decompositionLevel, waveletName);

% Wavelet denoising
denoisedSignal = wdenoise(noisySignal, decompositionLevel);
