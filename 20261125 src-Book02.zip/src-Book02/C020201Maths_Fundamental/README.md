# C020201Maths_Fundamental - Supplementary MATLAB Source Code

| Field | Value |
| --- | --- |
| Book | MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines |
| Chapter | Fundamental Mathematics for Programming |
| Package version | 1.1.0 |
| Release stamp | 2026-11-10 |
| Source manuscript | `P02-20261027` |
| Source chapter file | `P0202main/C020201Maths_Fundamental/` (included by `P02_20260830.tex`) |
| Code files | 132 |
| Code lines relocated | 22,138 |

## Why this folder exists

The editor reported that a large volume of programming code was present in the
manuscript and requested that it be moved to a professional repository with the
links supplied as supplementary material. The printed book is subject to a
length target below 1100 pages and to the Springer hard-copy limit of fewer
than 950 print pages. Accordingly, every `lstlisting`, every code `verbatim`
environment and every `\lstinputlisting` call in the chapter has been removed
from the main body and deposited here. Only the filename, the listing caption
and a reference to this folder remain in the printed text.

## Naming convention

A file is named after the `label` of the listing it came from:

```latex
\begin{lstlisting}[..., caption={Basic matrix operations ...},
                     label={chapter_Introduction_example_01}]
```

is saved as `chapter_Introduction_example_01.m`.

- Listings without a `label` receive a generated name `C020201Maths_Fundamental_code_NNN.m`.
- Code held in a `verbatim` environment receives `C020201Maths_Fundamental_verbatim_NN.m`.
- Code loaded by `\lstinputlisting` keeps the label of that call, so
  `chapter_CW04_code_runner` becomes `chapter_CW04_code_runner.m`.
- Where two listings shared the same label, the later file carries a numeric
  suffix (`_02`, `_03`, ...) so nothing is overwritten. This is recorded in
  the table below.

Each file begins with a header comment giving the caption, the original label,
this folder, the version stamp and the public repository URL.

## Finding a file from the book

The main text now shows a one-line note of the form:

> **Source code 4.3:** `chapter_ICT_example_01.m` - *caption*
> (supplementary material: `src-Book02/C020201Maths_Fundamental/`)

The original listing numbers and all `\ref{...}` cross-references are
unchanged, so the in-text reference maps directly to a filename.

## Repository

```
https://github.com/LeoYiChen/MATLABBook02
```

Clone or download `src-Book02/` from this repository, or use the Springer
supplementary archive. The same address is printed in the preface of the book.
Keep the `src-Book02/` folder name so that the in-text `src-Book02/C020201Maths_Fundamental/`
paths resolve.

## Companion documents

- `VERSION.md` - version, release stamp and release notes
- `USER-GUIDE.md` - how to download, locate and run the code
- `MANIFEST.sha256` - SHA-256 ledger of every file in this folder

## Files

| Filename | Source listing label | Caption |
| --- | --- | --- |
| `C020201Maths_Fundamental_code_096.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_097.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_099.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_100.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_101.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_102.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_103.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_105.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_106.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_107.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_108.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_109.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_111.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_112.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_113.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_114.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_115.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_117.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_118.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_119.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_120.m` | `(generated)` | MATLAB source code for this example. |
| `C020201Maths_Fundamental_code_121.m` | `(generated)` | MATLAB source code for this example. |
| `chapter_Combinatorics_example_basics.m` | `chapter_Combinatorics_example_basics` | Fundamental combinatorial calculations in MATLAB. |
| `chapter_Combinatorics_example_decision.m` | `chapter_Combinatorics_example_decision` | Combinatorial analysis for multi-factor decision-making. |
| `chapter_Combinatorics_example_optimisation.m` | `chapter_Combinatorics_example_optimisation` | Modern computational approaches to combinatorial optimisation. |
| `chapter_FundamentalMathematics_Lab1_code.m` | `chapter_FundamentalMathematics_Lab1_code` | Laboratory1: Eigenvalue analysis and PCA implementation. |
| `chapter_FundamentalMathematics_Lab2_code.m` | `chapter_FundamentalMathematics_Lab2_code` | Laboratory2: Numerical calculus methods. |
| `chapter_FundamentalMathematics_Lab3_code.m` | `chapter_FundamentalMathematics_Lab3_code` | Laboratory3: Fourier analysis and signal processing. |
| `chapter_FundamentalMathematics_Lab4_code.m` | `chapter_FundamentalMathematics_Lab4_code` | Laboratory4: Statistical analysis and hypothesis testing. |
| `chapter_FundamentalMathematics_Lab5_code.m` | `chapter_FundamentalMathematics_Lab5_code` | Laboratory5: Optimisation methods. |
| `chapter_FundamentalMathematics_MATLABexample_AncientModern.m` | `chapter_FundamentalMathematics_MATLABexample_AncientModern` | Connecting Ancient Methods to Modern Matrix Theory |
| `chapter_FundamentalMathematics_MATLABexample_ArrayIndexing.m` | `chapter_FundamentalMathematics_MATLABexample_ArrayIndexing` | Comprehensive indexing techniques in MATLAB. |
| `chapter_FundamentalMathematics_MATLABexample_BuiltinMatrixCreation.m` | `chapter_FundamentalMathematics_MATLABexample_BuiltinMatrixCreation` | Creating matrices using built-in MATLAB functions. |
| `chapter_FundamentalMathematics_MATLABexample_ColonOperator.m` | `chapter_FundamentalMathematics_MATLABexample_ColonOperator` | Sequence generation using the colon operator. |
| `chapter_FundamentalMathematics_MATLABexample_Concatenation.m` | `chapter_FundamentalMathematics_MATLABexample_Concatenation` | Matrix concatenation operations. |
| `chapter_FundamentalMathematics_MATLABexample_Determinant.m` | `chapter_FundamentalMathematics_MATLABexample_Determinant` | Determinant computation and geometric interpretation. |
| `chapter_FundamentalMathematics_MATLABexample_DigitalTwinThermal.m` | `chapter_FundamentalMathematics_MATLABexample_DigitalTwinThermal` | Digital twin thermal analysis using finite difference methods. |
| `chapter_FundamentalMathematics_MATLABexample_DirectArrayCreation.m` | `chapter_FundamentalMathematics_MATLABexample_DirectArrayCreation` | Direct creation of matrices and vectors in MATLAB. |
| `chapter_FundamentalMathematics_MATLABexample_DirectMethods.m` | `chapter_FundamentalMathematics_MATLABexample_DirectMethods` | Direct methods for solving linear systems. |
| `chapter_FundamentalMathematics_MATLABexample_Eigenvalues.m` | `chapter_FundamentalMathematics_MATLABexample_Eigenvalues` | Eigenvalues, eigenvectors, and spectral decomposition. |
| `chapter_FundamentalMathematics_MATLABexample_EngineeringApplications.m` | `chapter_FundamentalMathematics_MATLABexample_EngineeringApplications` | Matrices in engineering applications: structural dynamics example. |
| `chapter_FundamentalMathematics_MATLABexample_Fangcheng.m` | `chapter_FundamentalMathematics_MATLABexample_Fangcheng` | Chinese Fangcheng Method: Ancient Algorithm in Modern Code |
| `chapter_FundamentalMathematics_MATLABexample_FundamentalOperations.m` | `chapter_FundamentalMathematics_MATLABexample_FundamentalOperations` | Fundamental matrix and vector operations. |
| `chapter_FundamentalMathematics_MATLABexample_HighDimensionalSystems.m` | `chapter_FundamentalMathematics_MATLABexample_HighDimensionalSystems` | High-dimensional linear system solution and performance analysis. |
| `chapter_FundamentalMathematics_MATLABexample_Interactive.m` | `chapter_FundamentalMathematics_MATLABexample_Interactive` | Interactive Counting Board Visualisation |
| `chapter_FundamentalMathematics_MATLABexample_IterativeMethods.m` | `chapter_FundamentalMathematics_MATLABexample_IterativeMethods` | Iterative methods for sparse linear systems. |
| `chapter_FundamentalMathematics_MATLABexample_RiceProblem.m` | `chapter_FundamentalMathematics_MATLABexample_RiceProblem` | Solving the Ancient Rice Problem |
| `chapter_FundamentalMathematics_MATLABexample_SVD.m` | `chapter_FundamentalMathematics_MATLABexample_SVD` | Singular Value Decomposition and applications. |
| `chapter_FundamentalMathematics_MATLABexample_SparseMatrices.m` | `chapter_FundamentalMathematics_MATLABexample_SparseMatrices` | Sparse matrix efficiency demonstration. |
| `chapter_FundamentalMathematics_MATLABexample_SymbolicMatrices.m` | `chapter_FundamentalMathematics_MATLABexample_SymbolicMatrices` | Symbolic computation with matrices. |
| `chapter_FundamentalMathematics_MATLABexample_TransposeOps.m` | `chapter_FundamentalMathematics_MATLABexample_TransposeOps` | Transpose operations and their applications. |
| `chapter_FundamentalMathematics_conclusion_calculus.m` | `chapter_FundamentalMathematics_conclusion_calculus` | Numerical differentiation and integration fundamentals. |
| `chapter_FundamentalMathematics_conclusion_eigen.m` | `chapter_FundamentalMathematics_conclusion_eigen` | Eigenvalue analysis demonstrating linear algebra fundamentals. |
| `chapter_FundamentalMathematics_conclusion_fourier.m` | `chapter_FundamentalMathematics_conclusion_fourier` | Fourier analysis for signal processing. |
| `chapter_FundamentalMathematics_conclusion_optimisation.m` | `chapter_FundamentalMathematics_conclusion_optimisation` | Optimisation methods for finding extrema. |
| `chapter_FundamentalMathematics_conclusion_statistics.m` | `chapter_FundamentalMathematics_conclusion_statistics` | Statistical analysis and uncertainty quantification. |
| `chapter_FundamentalMathematics_example_BabbageDifferences.m` | `chapter_FundamentalMathematics_example_BabbageDifferences` | Demonstration of Babbage's method of differences in MATLAB. |
| `chapter_FundamentalMathematics_example_ForwardPropagation.m` | `chapter_FundamentalMathematics_example_ForwardPropagation` | Simple neural network forward propagation demonstration. |
| `chapter_FundamentalMathematics_example_KahanSummation.m` | `chapter_FundamentalMathematics_example_KahanSummation` | Comparison of standard summation versus Kahan compensated summation. |
| `chapter_FundamentalMathematics_example_LinearSystems.m` | `chapter_FundamentalMathematics_example_LinearSystems` | Solving linear systems in MATLAB using different methods. |
| `chapter_FundamentalMathematics_example_MatrixBasics.m` | `chapter_FundamentalMathematics_example_MatrixBasics` | Fundamental matrix operations in MATLAB. |
| `chapter_FundamentalMathematics_example_PCA.m` | `chapter_FundamentalMathematics_example_PCA` | Principal Component Analysis using eigendecomposition. |
| `chapter_FundamentalMathematics_example_PINN.m` | `chapter_FundamentalMathematics_example_PINN` | Physics-informed loss function incorporating differential equations. |
| `chapter_FundamentalMathematics_example_QuantumGate.m` | `chapter_FundamentalMathematics_example_QuantumGate` | Simulating a simple quantum gate operation using matrix algebra. |
| `chapter_FundamentalMathematics_example_SVD.m` | `chapter_FundamentalMathematics_example_SVD` | Singular Value Decomposition for matrix analysis and compression. |
| `chapter_FundamentalMathematics_example_SymbolicVsNumeric.m` | `chapter_FundamentalMathematics_example_SymbolicVsNumeric` | Comparing numerical and symbolic computation in MATLAB. |
| `chapter_FundamentalMathematics_lst_calculus.m` | `chapter_FundamentalMathematics_lst_calculus` | Numerical differentiation and integration in MATLAB. |
| `chapter_FundamentalMathematics_lst_heat_equation.m` | `chapter_FundamentalMathematics_lst_heat_equation` | Heat equation solution using finite differences. |
| `chapter_FundamentalMathematics_lst_interpolation_fitting.m` | `chapter_FundamentalMathematics_lst_interpolation_fitting` | Interpolation and polynomial fitting in MATLAB. |
| `chapter_FundamentalMathematics_lst_ode_systems.m` | `chapter_FundamentalMathematics_lst_ode_systems` | Solving ODEs in MATLAB - Van der Pol and Lorenz systems. |
| `chapter_FundamentalMathematics_lst_root_finding.m` | `chapter_FundamentalMathematics_lst_root_finding` | Root finding using MATLAB's built-in functions. |
| `chapter_FundamentalMaths_example_Convolution.m` | `chapter_FundamentalMaths_example_Convolution` | Convolution-based filtering with time and frequency domain methods. |
| `chapter_FundamentalMaths_example_Eigenvalues.m` | `chapter_FundamentalMaths_example_Eigenvalues` | Computing and interpreting eigenvalues and eigenvectors. |
| `chapter_FundamentalMaths_example_FFT.m` | `chapter_FundamentalMaths_example_FFT` | Comprehensive FFT analysis and digital filtering in MATLAB. |
| `chapter_FundamentalMaths_example_GlobalOptimisation.m` | `chapter_FundamentalMaths_example_GlobalOptimisation` | Global optimisation using genetic algorithms and particle swarm optimisation. |
| `chapter_FundamentalMaths_example_GradientDescent.m` | `chapter_FundamentalMaths_example_GradientDescent` | Implementation of gradient descent algorithm with multiple test functions. |
| `chapter_FundamentalMaths_example_GraphAnalysis.m` | `chapter_FundamentalMaths_example_GraphAnalysis` | Comprehensive graph creation and analysis in MATLAB. |
| `chapter_FundamentalMaths_example_LinearProgramming.m` | `chapter_FundamentalMaths_example_LinearProgramming` | Linear programming resource allocation example. |
| `chapter_FundamentalMaths_example_MatrixArithmetic.m` | `chapter_FundamentalMaths_example_MatrixArithmetic` | Matrix arithmetic operations and element-wise computations. |
| `chapter_FundamentalMaths_example_MatrixCreation.m` | `chapter_FundamentalMaths_example_MatrixCreation` | Comprehensive matrix creation and indexing operations. |
| `chapter_FundamentalMaths_example_NumericalDifferentiation.m` | `chapter_FundamentalMaths_example_NumericalDifferentiation` | Comprehensive numerical differentiation using finite difference methods. |
| `chapter_FundamentalMaths_example_SVD.m` | `chapter_FundamentalMaths_example_SVD` | Singular value decomposition and applications to data compression. |
| `chapter_FundamentalMaths_example_Sampling.m` | `chapter_FundamentalMaths_example_Sampling` | Sampling theorem demonstration with aliasing and reconstruction. |
| `chapter_FundamentalMaths_example_Wavelet.m` | `chapter_FundamentalMaths_example_Wavelet` | Comprehensive wavelet transform analysis for non-stationary signals. |
| `chapter_FundamentalMaths_example_fmincon.m` | `chapter_FundamentalMaths_example_fmincon` | Constrained nonlinear optimisation using fmincon. |
| `chapter_FundamentalMaths_example_fminunc.m` | `chapter_FundamentalMaths_example_fminunc` | Unconstrained nonlinear optimisation using fminunc. |
| `chapter_FundamentalMaths_syntax_Convolution.m` | `chapter_FundamentalMaths_syntax_Convolution` | Basic convolution syntax in MATLAB. |
| `chapter_FundamentalMaths_syntax_FFT.m` | `chapter_FundamentalMaths_syntax_FFT` | Basic FFT syntax in MATLAB. |
| `chapter_FundamentalMaths_syntax_Wavelet.m` | `chapter_FundamentalMaths_syntax_Wavelet` | Basic wavelet transform syntax in MATLAB. |
| `chapter_Math_example_anonymous.m` | `chapter_Math_example_anonymous` | Anonymous function examples. |
| `chapter_Math_example_documentation.m` | `chapter_Math_example_documentation` | Function documentation template. |
| `chapter_Math_example_elementary.m` | `chapter_Math_example_elementary` | Elementary mathematical functions. |
| `chapter_Math_example_functionGeneral.m` | `chapter_Math_example_functionGeneral` | General structure of MATLAB function definition. |
| `chapter_Math_example_handles.m` | `chapter_Math_example_handles` | Function handle usage. |
| `chapter_Math_example_integration.m` | `chapter_Math_example_integration` | Anonymous functions with numerical integration. |
| `chapter_Math_example_linalg.m` | `chapter_Math_example_linalg` | Matrix and linear algebra functions. |
| `chapter_Math_example_multipleIO.m` | `chapter_Math_example_multipleIO` | Function with multiple inputs and outputs. |
| `chapter_Math_example_nested.m` | `chapter_Math_example_nested` | Nested and local functions. |
| `chapter_Math_example_rootFinding.m` | `chapter_Math_example_rootFinding` | Root-finding methods implementation. |
| `chapter_Math_example_stats.m` | `chapter_Math_example_stats` | Statistical functions. |
| `chapter_Math_example_sumSquare.m` | `chapter_Math_example_sumSquare` | Function calculating sum of squares. |
| `chapter_Math_example_symbolic.m` | `chapter_Math_example_symbolic` | Symbolic function manipulation. |
| `chapter_Math_example_testing.m` | `chapter_Math_example_testing` | Unit testing example. |
| `chapter_Math_example_validation.m` | `chapter_Math_example_validation` | Input validation techniques. |
| `chapter_Math_example_vectorMath.m` | `chapter_Math_example_vectorMath` | Vectorised mathematical operations. |
| `chapter_Math_example_vectorisation.m` | `chapter_Math_example_vectorisation` | Vectorisation examples. |
| `chapter_Math_lab10_signal.m` | `chapter_Math_lab10_signal` | Signal Processing Pipeline Implementation |
| `chapter_Math_lab11_ml.m` | `chapter_Math_lab11_ml` | Machine Learning Algorithms from Scratch |
| `chapter_Math_lab12_linalg.m` | `chapter_Math_lab12_linalg` | Advanced Numerical Linear Algebra Implementation |
| `chapter_Math_lab13_patterns.m` | `chapter_Math_lab13_patterns` | Mathematical Patterns in 2025 |
| `chapter_Math_lab14_plotting.m` | `chapter_Math_lab14_plotting` | Advanced Plotting with Dual Y-Axes |
| `chapter_Math_lab15_pendulum.m` | `chapter_Math_lab15_pendulum` | Nonlinear Pendulum Dynamics and Chaos |
| `chapter_Math_lab6_qr.m` | `chapter_Math_lab6_qr` | QR Decomposition Properties |
| `chapter_Math_lab6_svd.m` | `chapter_Math_lab6_svd` | Image Compression via SVD |
| `chapter_Math_lab7_optim.m` | `chapter_Math_lab7_optim` | Optimisation Algorithm Implementation |
| `chapter_Math_lab8_stats.m` | `chapter_Math_lab8_stats` | Statistical Hypothesis Testing Implementation |
| `chapter_Math_lab9_dynamics.m` | `chapter_Math_lab9_dynamics` | Two-Link Manipulator Dynamics |
| `chapter_Math_section_Transform_FilterDesign.m` | `chapter_Math_section_Transform_FilterDesign` | Comprehensive Digital Filter Design and Analysis in MATLAB. |
| `chapter_Numerical_syntax_bisection.m` | `chapter_Numerical_syntax_bisection` | Bisection method syntax structure. |
| `chapter_Numerical_syntax_differentiation.m` | `chapter_Numerical_syntax_differentiation` | Numerical differentiation syntax structure. |
| `chapter_Numerical_syntax_integration.m` | `chapter_Numerical_syntax_integration` | Numerical integration syntax structure. |
| `chapter_Numerical_syntax_interp.m` | `chapter_Numerical_syntax_interp` | Interpolation method syntax structure. |
| `chapter_Numerical_syntax_newton.m` | `chapter_Numerical_syntax_newton` | Newton-Raphson method syntax structure. |
| `chapter_Numerical_syntax_ode.m` | `chapter_Numerical_syntax_ode` | ODE solver syntax structure. |
| `chapter_Numerical_syntax_pdetoolbox.m` | `chapter_Numerical_syntax_pdetoolbox` | Heat equation using PDE Toolbox. |
| `chapter_UQ_algorithm_basicMC.m` | `chapter_UQ_algorithm_basicMC` | Canonical Monte Carlo algorithm expressed as pseudocode. |
| `chapter_UQ_example_FMEA.m` | `chapter_UQ_example_FMEA` | Failure mode analysis: FMEA with a critique of RPN ranking, exhaustive minimal cut set enumeration, exact importance measures, and the quantified benefit of a dual hydraulic circuit. |
| `chapter_UQ_example_confidenceIntervals.m` | `chapter_UQ_example_confidenceIntervals` | Confidence intervals: base-MATLAB t and chi-square quantiles verified against tables, percentile and BCa bootstrap intervals, exact exponential reliability bands, and a coverage study exposing non-normal fragility. |
| `chapter_UQ_example_errorPropagation.m` | `chapter_UQ_example_errorPropagation` | Error propagation: analytical, complex-step, and finite-difference gradients compared against Monte Carlo and against exact closed-form results for products of lognormal and correlated normal variables. |
| `chapter_UQ_example_monteCarlo.m` | `chapter_UQ_example_monteCarlo` | Monte Carlo uncertainty propagation for cantilever beam deflection, with Latin Hypercube variance reduction and Wilson score intervals for exceedance probability. |
| `chapter_UQ_example_sensitivityAnalysis.m` | `chapter_UQ_example_sensitivityAnalysis` | Global sensitivity analysis: pick-freeze Sobol' estimators validated on the Ishigami function, then applied to a chemical reactor model alongside local sensitivities and Morris screening. |
| `chapter_UQ_example_systemReliability.m` | `chapter_UQ_example_systemReliability` | System reliability analysis: exact Poisson-binomial k-out-of-n reliability, the unified standby formula with limit verification, bridge network pivotal decomposition, competing-risk bathtub hazard, and transient availability. |
