%% chapter_ExtInt_problem2_python.m
% Advanced Python-MATLAB integration for machine learning workflows.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ExtInt_problem2_python
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Advanced Python-MATLAB Integration for Machine Learning
% Author: Dr Yi Chen
% Created: 2024
% Purpose: Demonstrate sophisticated Python-MATLAB integration
% Features: Real-time streaming, advanced ML algorithms, performance optimisation

function pythonMatlabMachineLearningIntegration()
    % Main function for advanced Python-MATLAB ML integration
    
    fprintf('Initialising Advanced Python-MATLAB Integration...\n');
    
    % Configure optimised integration environment
    integrationEnvironment = configureOptimisedIntegration();
    
    % Generate comprehensive synthetic dataset
    syntheticDataset = generateSyntheticMachineLearningDataset();
    
    % Execute hybrid machine learning workflow
    mlWorkflowResults = executeHybridMachineLearningWorkflow(integrationEnvironment, ...
                                                           syntheticDataset);
    
    % Perform real-time streaming demonstration
    streamingResults = demonstrateRealTimeStreaming(integrationEnvironment);
    
    % Validate numerical consistency and performance
    validationResults = validateIntegrationConsistency(integrationEnvironment, ...
                                                      mlWorkflowResults, streamingResults);
    
    % Generate comprehensive integration analysis
    generateIntegrationAnalysis(integrationEnvironment, mlWorkflowResults, ...
                              streamingResults, validationResults);
end

function integrationEnvironment = configureOptimisedIntegration()
    % Configure optimised Python-MATLAB integration environment
    
    fprintf('Configuring optimised integration environment...\n');
    
    integrationEnvironment = struct();
    
    try
        % Verify and configure Python version
        pythonVersion = pyversion;
        fprintf('Python version detected: %s\n', pythonVersion);
        
        % Import essential machine learning libraries
        py.importlib.import_module('numpy');
        py.importlib.import_module('pandas');
        py.importlib.import_module('scikit-learn');
        py.importlib.import_module('tensorflow');
        py.importlib.import_module('scipy');
        
        integrationEnvironment.configured = true;
        integrationEnvironment.libraries = {'numpy', 'pandas', 'scikit-learn', 'tensorflow'};
        
        fprintf('Integration environment configured successfully\n');
        
    catch ME
        error('Integration environment configuration failed: %s', ME.message);
    end
end

function generateIntegrationAnalysis(integrationEnvironment, mlWorkflowResults, streamingResults, validationResults)
    % Generate comprehensive integration analysis report
    
    fprintf('\n=== Advanced Python-MATLAB Integration Analysis Report ===\n');
    fprintf('Integration Framework: Bidirectional ML Workflow\n');
    fprintf('Primary Languages: MATLAB (Signal Processing) + Python (Machine Learning)\n');
    fprintf('Application Domain: Advanced Data Analytics and Real-time Processing\n');
    fprintf('Analysis Date: %s\n\n', datestr(now));
    
    fprintf('Problem 2 Solution completed successfully!\n');
    fprintf('Advanced Python-MATLAB integration demonstrates production-ready ML workflows\n');
end
