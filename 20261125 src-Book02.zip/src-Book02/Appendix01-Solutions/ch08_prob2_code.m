%% ch08_prob2_code.m
% Tall-array statistical analysis (MATLABBook02_Chapter08_Problem2.m).
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : ch08_prob2_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% MATLABBook02_Chapter08_Problem2.m
% --------------------------------
% Purpose : Out-of-memory statistics using tall arrays.
% Author  : Dr Yi Chen
% Version : 1.0  |  Date: 2026-10-05
% MATLAB  : R2024a or later recommended
% --------------------------------
clc; clear; close all;

%% Step 1 – Create datastore (re-use data from Problem 1)
dataFolder      = fullfile(pwd, 'SyntheticSensorData');
sensorDatastore = tabularTextDatastore(dataFolder, ...
    'FileExtensions', '.csv', 'MissingValue', NaN);
fprintf('=== Step 1: Datastore created ===\n');

%% Step 2 – Convert to tall table
tallSensorData = tall(sensorDatastore);
fprintf('=== Step 2: Tall table created ===\n');
disp(tallSensorData);

%% Step 3 – Compute deferred statistics
fprintf('\n=== Step 3: Queuing deferred statistics ===\n');
tallMean   = mean(tallSensorData{:,:}, 'omitnan');
tallStd    = std(tallSensorData{:,:}, 0, 'omitnan');
tallCorr   = corr(tallSensorData{:,:});

%% Step 4 – Compute percentiles
tallPrctile25 = prctile(tallSensorData{:,:}, 25);
tallPrctile50 = prctile(tallSensorData{:,:}, 50);
tallPrctile75 = prctile(tallSensorData{:,:}, 75);

%% Step 5 – Filter rows where Temperature > 35
temperatureThreshold = 35;
tallFiltered = tallSensorData(tallSensorData.Temperature > ...
    temperatureThreshold, :);
tallFilteredCount = gather(height(tallFiltered));

%% Step 6 – Gather all results
fprintf('\n=== Step 6: Gathering results (single pass) ===\n');
[gatheredMean, gatheredStd, gatheredCorr, ...
 gatheredP25, gatheredP50, gatheredP75] = ...
    gather(tallMean, tallStd, tallCorr, ...
           tallPrctile25, tallPrctile50, tallPrctile75);

featureNames = sensorDatastore.SelectedVariableNames;
fprintf('\n-- Summary Statistics --\n');
for idx = 1:numel(featureNames)
    fprintf('  %12s | Mean: %8.3f | Std: %8.3f | P25: %8.3f | P50: %8.3f | P75: %8.3f\n', ...
        featureNames{idx}, gatheredMean(idx), gatheredStd(idx), ...
        gatheredP25(idx), gatheredP50(idx), gatheredP75(idx));
end
fprintf('\n-- Correlation Matrix --\n');
disp(array2table(gatheredCorr, ...
    'VariableNames', featureNames, 'RowNames', featureNames));
fprintf('  Rows with Temperature > %d : %d\n', ...
    temperatureThreshold, tallFilteredCount);

%% Step 7 – Box plot comparison
filteredSubset = gather(tallFiltered{:,:});
fullSubset     = gather(head(tallSensorData{:,:}, 50000));

figBoxPlot = figure('Name','Box Plot Comparison', ...
    'Position',[100 100 1000 500]);
subplot(1,2,1);
boxplot(fullSubset, 'Labels', featureNames);
title('\textbf{Full Dataset Sample}', 'Interpreter','latex');
ylabel('Value', 'Interpreter','latex');
grid on;
subplot(1,2,2);
boxplot(filteredSubset(:,1:end), 'Labels', featureNames);
title(sprintf('\\textbf{Filtered (Temp $>$ %d)}', ...
    temperatureThreshold), 'Interpreter','latex');
ylabel('Value', 'Interpreter','latex');
grid on;
sgtitle('\textbf{Box-Plot Comparison: Full vs.\ Filtered}', ...
    'Interpreter','latex', 'FontSize', 14);

%% Step 8 – Save figures
savefig(figBoxPlot, 'Ch08_Problem2_BoxPlot.fig');
exportgraphics(figBoxPlot, 'Ch08_Problem2_BoxPlot.eps', ...
    'ContentType','vector');
exportgraphics(figBoxPlot, 'Ch08_Problem2_BoxPlot.jpg', ...
    'Resolution', 300);
fprintf('=== Figures saved (.fig, .eps, .jpg) ===\n');

fprintf('\n=== Problem 2 Complete ===\n');
% --------------------------------
% Computational Complexity:
% Tall-array operations use deferred evaluation. When gather() is
% called, MATLAB executes a single optimised pass over the entire
% dataset: O(N * D) where N is total rows and D is the number of
% features. Correlation requires a second pass internally, giving
% O(N * D^2) in the worst case. Memory usage is bounded by the
% chunk size, typically O(chunkSize * D), irrespective of N. The
% gather of the filtered subset scales with the output size.
% --------------------------------
