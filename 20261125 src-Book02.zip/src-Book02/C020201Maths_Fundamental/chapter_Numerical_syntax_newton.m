%% chapter_Numerical_syntax_newton.m
% Newton-Raphson method syntax structure.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Numerical_syntax_newton
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function root = newtonRaphsonMethod(func, derivative, initialGuess, tolerance)
% Implements Newton-Raphson method for root finding
% Requires derivative function
currentEstimate = initialGuess;
while abs(func(currentEstimate)) > tolerance
    currentEstimate = currentEstimate - func(currentEstimate)/derivative(currentEstimate);
end
root = currentEstimate;
end
