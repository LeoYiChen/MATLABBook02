%% chapter_FundamentalMaths_example_fmincon.m
% Constrained nonlinear optimisation using fmincon.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_fmincon
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter06_CalculusOptimisation_Example05.m
% Author: Dr Leo Chen
% Date: June 5, 2025
% MATLAB Version: R2025a
% Description: Comprehensive constrained nonlinear optimisation
%              demonstrations using fmincon.

function demonstrateConstrainedOptimisation()
    fprintf('Constrained Nonlinear Optimisation with fmincon\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Simple constrained problem
    demonstrateSimpleConstrained();
    
    % Part 2: Nonlinear constraints
    demonstrateNonlinearConstraints();
    
    % Part 3: Engineering design problem
    demonstrateEngineeringDesign();
end

function demonstrateSimpleConstrained()
    fprintf('Part 1: Simple Constrained Optimisation\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Minimise: f(x,y) = x^2 + y^2
    % Subject to: x + y >= 1
    
    objective = @(x) x(1)^2 + x(2)^2;
    
    fprintf('Objective: minimise f(x,y) = x^2 + y^2\n');
    fprintf('Subject to: x + y >= 1\n');
    fprintf('Analytical solution: x = y = 0.5, f* = 0.5\n\n');
    
    % Linear inequality constraint: -x - y <= -1 (equivalent to x + y >= 1)
    A = [-1, -1];
    b = -1;
    
    % No bounds or nonlinear constraints
    lb = [];
    ub = [];
    nonlcon = [];
    
    % Initial point
    x0 = [2.0; 2.0];
    
    fprintf('Initial point: [%.6f, %.6f]\n', x0(1), x0(2));
    fprintf('Initial objective: %.6f\n\n', objective(x0));
    
    % Optimisation options
    options = optimoptions('fmincon', 'Display', 'iter', ...
                          'Algorithm', 'sqp', ...
                          'OptimalityTolerance', 1e-8, ...
                          'ConstraintTolerance', 1e-8);
    
    % Solve
    [x_opt, fval, exitflag, output] = fmincon(objective, x0, ...
                                              A, b, [], [], lb, ub, ...
                                              nonlcon, options);
    
    fprintf('\n');
    fprintf('%s\n', repmat('=', 1, 70));
    fprintf('Optimisation Results:\n');
    fprintf('  Optimal solution: [%.10f, %.10f]\n', x_opt(1), x_opt(2));
    fprintf('  Optimal value: %.10f\n', fval);
    fprintf('  Exit flag: %d\n', exitflag);
    fprintf('  Algorithm: %s\n', output.algorithm);
    fprintf('  Iterations: %d\n', output.iterations);
    fprintf('  Constraint violation: %.6e\n', x_opt(1) + x_opt(2) - 1);
    fprintf('  Error vs analytical: %.6e\n\n', abs(fval - 0.5));
    
    % Visualise
    visualiseConstrainedProblem(objective, A, b, x0, x_opt, ...
                               'Minimise $x^2 + y^2$ subject to $x + y \geq 1$');
end

function demonstrateNonlinearConstraints()
    fprintf('Part 2: Nonlinear Constraints\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Minimise: f(x,y) = (x-2)^2 + (y-2)^2
    % Subject to: x^2 + y^2 <= 1 (inside unit circle)
    
    objective = @(x) (x(1) - 2)^2 + (x(2) - 2)^2;
    
    fprintf('Objective: minimise f(x,y) = (x-2)^2 + (y-2)^2\n');
    fprintf('Subject to: x^2 + y^2 <= 1 (unit circle constraint)\n\n');
    
    % Nonlinear constraint function
    % nonlcon returns [c, ceq] where c <= 0 and ceq = 0
    nonlcon = @(x) deal(x(1)^2 + x(2)^2 - 1, []);
    
    % Initial point (feasible)
    x0 = [0.5; 0.5];
    
    fprintf('Initial point: [%.6f, %.6f]\n', x0(1), x0(2));
    fprintf('Initial objective: %.6f\n', objective(x0));
    fprintf('Constraint value: %.6f (should be <= 0)\n\n', ...
            x0(1)^2 + x0(2)^2 - 1);
    
    % No linear constraints or bounds
    A = [];
    b = [];
    Aeq = [];
    beq = [];
    lb = [];
    ub = [];
    
    % Options
    options = optimoptions('fmincon', 'Display', 'final', ...
                          'Algorithm', 'sqp', ...
                          'OptimalityTolerance', 1e-8);
    
    % Solve
    [x_opt, fval, exitflag, output] = fmincon(objective, x0, ...
                                              A, b, Aeq, beq, lb, ub, ...
                                              nonlcon, options);
    
    fprintf('\nOptimisation Results:\n');
    fprintf('  Optimal solution: [%.10f, %.10f]\n', x_opt(1), x_opt(2));
    fprintf('  Optimal value: %.10f\n', fval);
    fprintf('  Algorithm: %s\n', output.algorithm);
    fprintf('  Iterations: %d\n', output.iterations);
    fprintf('  Distance to unconstrained optimum (2,2): %.6f\n', ...
            norm(x_opt - [2; 2]));
    fprintf('  Constraint value: %.6e (should be approx 0, active)\n', ...
            x_opt(1)^2 + x_opt(2)^2 - 1);
    
    % Analytical solution: point on circle closest to (2,2)
    direction = [2; 2] / norm([2; 2]);
    x_analytical = direction;
    
    fprintf('\nComparison with analytical solution:\n');
    fprintf('  Analytical: [%.10f, %.10f]\n', ...
            x_analytical(1), x_analytical(2));
    fprintf('  Error: %.6e\n\n', norm(x_opt - x_analytical));
    
    % Visualise
    figure('Position', [100, 100, 800, 600]);
    
    % Create contour plot
    [X, Y] = meshgrid(linspace(-1.5, 2.5, 200), linspace(-1.5, 2.5, 200));
    Z = arrayfun(@(x,y) objective([x;y]), X, Y);
    
    contour(X, Y, Z, 30, 'LineWidth', 1);
    hold on;
    
    % Draw constraint boundary
    theta = linspace(0, 2*pi, 100);
    plot(cos(theta), sin(theta), 'r-', 'LineWidth', 2.5, ...
         'DisplayName', 'Constraint: $x^2+y^2=1$');
    
    % Mark points
    plot(x0(1), x0(2), 'gs', 'MarkerSize', 12, 'LineWidth', 2, ...
         'DisplayName', 'Initial Point');
    plot(x_opt(1), x_opt(2), 'r*', 'MarkerSize', 15, 'LineWidth', 2, ...
         'DisplayName', 'Optimal Point');
    plot(2, 2, 'bo', 'MarkerSize', 10, 'LineWidth', 2, ...
         'DisplayName', 'Unconstrained Optimum');
    
    colorbar;
    axis equal;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Nonlinear Constrained Optimisation', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 10);
end

function demonstrateEngineeringDesign()
    fprintf('Part 3: Engineering Design Problem\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Design a cylindrical pressure vessel
    % Variables: [radius, height]
    % Minimise: surface area = 2*pi*r^2 + 2*pi*r*h
    % Subject to: volume >= V_min
    %             radius, height > 0
    
    V_min = 10.0; % Minimum volume requirement (litres or dm^3)
    
    objective = @(x) 2*pi*x(1)^2 + 2*pi*x(1)*x(2);
    
    fprintf('Pressure Vessel Design Problem\n');
    fprintf('Minimise surface area: 2*pi*r^2 + 2*pi*r*h\n');
    fprintf('Subject to: pi*r^2*h >= %.1f (minimum volume)\n', V_min);
    fprintf('            r, h > 0\n\n');
    
    % Nonlinear constraint: volume >= V_min
    % Formulated as: -pi*r^2*h + V_min <= 0
    nonlcon = @(x) deal(-pi*x(1)^2*x(2) + V_min, []);
    
    % Bounds: r, h > 0
    lb = [0.01; 0.01];
    ub = [];
    
    % Initial guess
    x0 = [1.0; 5.0];
    
    fprintf('Initial design: r = %.6f, h = %.6f\n', x0(1), x0(2));
    fprintf('Initial volume: %.6f dm^3\n', pi*x0(1)^2*x0(2));
    fprintf('Initial surface area: %.6f dm^2\n\n', objective(x0));
    
    % Options
    options = optimoptions('fmincon', 'Display', 'final', ...
                          'Algorithm', 'interior-point');
    
    % Solve
    [x_opt, fval, exitflag, output] = fmincon(objective, x0, ...
                                              [], [], [], [], lb, ub, ...
                                              nonlcon, options);
    
    r_opt = x_opt(1);
    h_opt = x_opt(2);
    V_opt = pi * r_opt^2 * h_opt;
    
    fprintf('\nOptimal Design:\n');
    fprintf('  Radius: r = %.6f dm\n', r_opt);
    fprintf('  Height: h = %.6f dm\n', h_opt);
    fprintf('  Volume: V = %.6f dm^3 (required >= %.1f)\n', V_opt, V_min);
    fprintf('  Surface area: %.6f dm^2\n', fval);
    fprintf('  Aspect ratio (h/r): %.6f\n', h_opt/r_opt);
    fprintf('  Algorithm: %s\n', output.algorithm);
    fprintf('  Iterations: %d\n\n', output.iterations);
    
    % Analytical solution for comparison
    % For minimum surface area with volume constraint:
    % Optimal ratio is h = 2*r
    r_analytical = (V_min / (2*pi))^(1/3);
    h_analytical = 2 * r_analytical;
    area_analytical = 2*pi*r_analytical^2 + 2*pi*r_analytical*h_analytical;
    
    fprintf('Analytical Solution (h = 2*r):\n');
    fprintf('  Radius: r = %.6f dm\n', r_analytical);
    fprintf('  Height: h = %.6f dm\n', h_analytical);
    fprintf('  Surface area: %.6f dm^2\n', area_analytical);
    fprintf('  Error in area: %.6e\n', abs(fval - area_analytical));
    fprintf('  Error in h/r ratio: %.6e\n\n', abs(h_opt/r_opt - 2.0));
    
    fprintf('Theoretical result: For minimum surface area given fixed volume,\n');
    fprintf('optimal cylinder has h = 2*r (height = diameter)\n');
end

function visualiseConstrainedProblem(objective, A, b, x0, x_opt, titleStr)
    figure('Position', [100, 100, 800, 600]);
    
    [X, Y] = meshgrid(linspace(-0.5, 3, 200), linspace(-0.5, 3, 200));
    Z = arrayfun(@(x,y) objective([x;y]), X, Y);
    
    contour(X, Y, Z, 30, 'LineWidth', 1);
    hold on;
    
    % Draw constraint line: -x - y = -1, i.e., x + y = 1
    x_line = linspace(-0.5, 3, 100);
    y_line = 1 - x_line;
    plot(x_line, y_line, 'r-', 'LineWidth', 2.5, ...
         'DisplayName', 'Constraint: $x+y=1$');
    
    % Shade feasible region (x + y >= 1)
    fill([x_line, fliplr(x_line)], [y_line, 3*ones(size(y_line))], ...
         'r', 'FaceAlpha', 0.1, 'EdgeColor', 'none', ...
         'DisplayName', 'Feasible Region');
    
    % Mark points
    plot(x0(1), x0(2), 'gs', 'MarkerSize', 12, 'LineWidth', 2, ...
         'DisplayName', 'Initial Point');
    plot(x_opt(1), x_opt(2), 'r*', 'MarkerSize', 15, 'LineWidth', 2, ...
         'DisplayName', 'Optimal Point');
    
    colorbar;
    axis equal;
    xlim([-0.5, 3]);
    ylim([-0.5, 3]);
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title(titleStr, 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 10);
end
