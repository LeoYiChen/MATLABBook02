%% prob13_code.m
% Shoelace Formula implementation for polygon area calculation.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : prob13_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% =========================================================================
% Geometric Magic: Polygon Area Using Shoelace Formula
% File: MATLABBook02_Chapter07_Problem13.m
% Author: Dr Yi Chen
% Date: 2024
% Version: 1.0
% Description: Implements Shoelace Formula for efficient polygon area
%              calculation with validation and visualisation
% =========================================================================

function MATLABBook02_Chapter07_Problem13()
    % Main function for Problem 13: Shoelace Formula
    
    clc; clear; close all;
    
    fprintf('=== POLYGON AREA CALCULATION: SHOELACE FORMULA ===\n\n');
    
    % Test Case 1: Simple triangle
    fprintf('-- Test Case 1: Triangle --\n');
    x1 = [0, 4, 2];
    y1 = [0, 0, 3];
    testPolygon(x1, y1, 'Triangle');
    
    % Test Case 2: Rectangle
    fprintf('\n-- Test Case 2: Rectangle --\n');
    x2 = [0, 5, 5, 0];
    y2 = [0, 0, 3, 3];
    testPolygon(x2, y2, 'Rectangle');
    
    % Test Case 3: Irregular pentagon
    fprintf('\n-- Test Case 3: Irregular Pentagon --\n');
    x3 = [0, 3, 5, 4, 1];
    y3 = [0, 1, 3, 5, 4];
    testPolygon(x3, y3, 'Irregular Pentagon');
    
    % Test Case 4: Complex star polygon
    fprintf('\n-- Test Case 4: Star Polygon --\n');
    theta = linspace(0, 2*pi, 11);
    r = 1 + 0.5*mod(0:10, 2); % Alternating radii
    x4 = r .* cos(theta);
    y4 = r .* sin(theta);
    testPolygon(x4, y4, 'Star Polygon');
    
    % Test Case 5: Realistic GIS application (land parcel)
    fprintf('\n-- Test Case 5: Land Parcel (GIS Application) --\n');
    x5 = [0, 100, 120, 110, 90, 50, 10];
    y5 = [0, 20, 80, 120, 130, 100, 50];
    testPolygon(x5, y5, 'Land Parcel');
    
    fprintf('\n=== All tests completed successfully ===\n');
end

function testPolygon(x, y, polygonName)
    % TESTPOLYGON - Computes area and validates result
    
    % Calculate area using Shoelace Formula
    areaShoelace = shoelaceArea(x, y);
    
    % Calculate area using MATLAB's built-in function for validation
    areaBuiltin = polyarea(x, y);
    
    % Calculate relative error
    relativeError = abs(areaShoelace - areaBuiltin) / areaBuiltin * 100;
    
    % Display results
    fprintf('%s:\n', polygonName);
    fprintf('  Shoelace Formula Area: %.6f square units\n', areaShoelace);
    fprintf('  MATLAB polyarea():      %.6f square units\n', areaBuiltin);
    fprintf('  Relative Error:         %.8f%%\n', relativeError);
    
    % Validation check
    if relativeError < 1e-10
        fprintf('  Status:  VALIDATED\n');
    else
        fprintf('  Status:  ERROR DETECTED\n');
    end
    
    % Visualise polygon
    visualisePolygon(x, y, polygonName, areaShoelace);
end

function area = shoelaceArea(x, y)
    % SHOELACEAREA - Implements Shoelace Formula
    %
    % Inputs:
    %   x - Vector of x-coordinates
    %   y - Vector of y-coordinates
    %
    % Output:
    %   area - Polygon area (always positive)
    
    % Ensure vectors are column vectors
    x = x(:);
    y = y(:);
    
    % Close the polygon by appending first vertex
    x = [x; x(1)];
    y = [y; y(1)];
    
    % Apply Shoelace Formula
    area = 0.5 * abs(sum(x(1:end-1) .* y(2:end) - x(2:end) .* y(1:end-1)));
end

function visualisePolygon(x, y, polygonName, area)
    % VISUALISEPOLYGON - Creates polygon visualisation
    
    figure('Name', sprintf('Polygon: %s', polygonName), ...
           'Position', [100, 100, 700, 600]);
    
    % Plot filled polygon
    fill(x, y, [0.7, 0.85, 1.0], 'FaceAlpha', 0.6, ...
         'EdgeColor', [0.2, 0.4, 0.8], 'LineWidth', 2.5);
    hold on;
    
    % Plot vertices
    scatter(x, y, 80, 'r', 'filled', 'MarkerEdgeColor', 'k', 'LineWidth', 1.2);
    
    % Label vertices
    for i = 1:length(x)
        text(x(i), y(i), sprintf('  V%d (%.1f, %.1f)', i, x(i), y(i)), ...
             'FontSize', 9, 'FontWeight', 'bold');
    end
    
    % Add centroid marker
    cx = mean(x);
    cy = mean(y);
    plot(cx, cy, 'kx', 'MarkerSize', 15, 'LineWidth', 3);
    text(cx, cy, sprintf('  Centroid\n  (%.2f, %.2f)', cx, cy), ...
         'FontSize', 9, 'Color', 'k', 'FontWeight', 'bold');
    
    % Formatting
    xlabel('$x$ coordinate', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$ coordinate', 'Interpreter', 'latex', 'FontSize', 12);
    title(sprintf('%s\\\\Area = %.4f square units (Shoelace Formula)', ...
                  strrep(polygonName, '_', '\_'), area), ...
          'Interpreter', 'latex', 'FontSize', 13, 'FontWeight', 'bold');
    grid on;
    axis equal;
    set(gca, 'FontSize', 11, 'LineWidth', 1.2);
    hold off;
end
