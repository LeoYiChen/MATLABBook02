%% chapter_Numerical_syntax_integration.m
% Numerical integration syntax structure.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Numerical_syntax_integration
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Trapezoidal integration for discrete data
integral_trapz = trapz(X, Y);

% Adaptive quadrature for function handle
fun = @(x) exp(-x.^2);  % Gaussian function
integral_adaptive = integral(fun, 0, 1);

% Multidimensional integration
fun2d = @(x, y) exp(-x.^2 - y.^2);
integral_2d = integral2(fun2d, 0, 1, 0, 1);
