%% chapter_FundamentalMaths_example_NumericalDifferentiation.m
% Comprehensive numerical differentiation using finite difference methods.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_FundamentalMaths_example_NumericalDifferentiation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% AIi4Book01_Chapter06_CalculusOptimisation_Example01.m
% Author: Dr Leo Chen
% Date: June 5, 2025
% MATLAB Version: R2025a
% Description: Demonstrates finite difference methods for numerical 
%              differentiation, including error analysis and optimal
%              step size determination.

function demonstrateNumericalDifferentiation()
    fprintf('Numerical Differentiation using Finite Differences\n');
    fprintf('%s\n\n', repmat('=', 1, 70));
    
    % Part 1: Basic finite difference schemes
    demonstrateBasicSchemes();
    
    % Part 2: Step size analysis
    demonstrateStepSizeAnalysis();
    
    % Part 3: Higher-order derivatives
    demonstrateHigherOrderDerivatives();
    
    % Part 4: Array differentiation
    demonstrateArrayDifferentiation();
    
    % Part 5: Gradient computation
    demonstrateGradientComputation();
end

function demonstrateBasicSchemes()
    fprintf('Part 1: Basic Finite Difference Schemes\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define test function and its exact derivative
    f = @(x) x.^3 - 2*x.^2 + 3*x - 1;
    f_prime_exact = @(x) 3*x.^2 - 4*x + 3;
    
    % Evaluation point and step size
    x0 = 2.0;
    h = 0.001;
    
    % Exact derivative value
    df_exact = f_prime_exact(x0);
    
    fprintf('Test function: f(x) = x^3 - 2*x^2 + 3*x - 1\n');
    fprintf('Evaluation point: x0 = %.6f\n', x0);
    fprintf('Step size: h = %.6f\n', h);
    fprintf('Exact derivative: f''(x0) = %.10f\n\n', df_exact);
    
    % Forward difference
    df_forward = (f(x0 + h) - f(x0)) / h;
    error_forward = abs(df_exact - df_forward);
    
    fprintf('Forward Difference:\n');
    fprintf('  Formula: [f(x0+h) - f(x0)] / h\n');
    fprintf('  Approximation: %.10f\n', df_forward);
    fprintf('  Absolute error: %.10e\n', error_forward);
    fprintf('  Relative error: %.10e\n\n', error_forward / abs(df_exact));
    
    % Backward difference
    df_backward = (f(x0) - f(x0 - h)) / h;
    error_backward = abs(df_exact - df_backward);
    
    fprintf('Backward Difference:\n');
    fprintf('  Formula: [f(x0) - f(x0-h)] / h\n');
    fprintf('  Approximation: %.10f\n', df_backward);
    fprintf('  Absolute error: %.10e\n', error_backward);
    fprintf('  Relative error: %.10e\n\n', error_backward / abs(df_exact));
    
    % Central difference
    df_central = (f(x0 + h) - f(x0 - h)) / (2*h);
    error_central = abs(df_exact - df_central);
    
    fprintf('Central Difference:\n');
    fprintf('  Formula: [f(x0+h) - f(x0-h)] / (2*h)\n');
    fprintf('  Approximation: %.10f\n', df_central);
    fprintf('  Absolute error: %.10e\n', error_central);
    fprintf('  Relative error: %.10e\n\n', error_central / abs(df_exact));
    
    fprintf('Accuracy comparison:\n');
    fprintf('  Central difference error is %.2fx smaller than forward difference\n', ...
            error_forward / error_central);
    fprintf('  This demonstrates O(h^2) vs O(h) convergence\n\n');
end

function demonstrateStepSizeAnalysis()
    fprintf('Part 2: Step Size Analysis\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define function
    f = @(x) exp(x) * sin(x);
    f_prime_exact = @(x) exp(x) * (sin(x) + cos(x));
    
    x0 = 1.0;
    df_exact = f_prime_exact(x0);
    
    fprintf('Test function: f(x) = exp(x) * sin(x)\n');
    fprintf('Evaluation point: x0 = %.6f\n', x0);
    fprintf('Exact derivative: %.15f\n\n', df_exact);
    
    % Range of step sizes
    h_values = logspace(-16, 0, 100);
    
    % Compute errors for different schemes
    errors_forward = zeros(size(h_values));
    errors_backward = zeros(size(h_values));
    errors_central = zeros(size(h_values));
    
    for k = 1:length(h_values)
        h = h_values(k);
        
        % Forward difference
        df_forward = (f(x0 + h) - f(x0)) / h;
        errors_forward(k) = abs(df_exact - df_forward);
        
        % Backward difference
        df_backward = (f(x0) - f(x0 - h)) / h;
        errors_backward(k) = abs(df_exact - df_backward);
        
        % Central difference
        df_central = (f(x0 + h) - f(x0 - h)) / (2*h);
        errors_central(k) = abs(df_exact - df_central);
    end
    
    % Find optimal step sizes
    [min_error_forward, idx_forward] = min(errors_forward);
    [min_error_central, idx_central] = min(errors_central);
    
    h_opt_forward = h_values(idx_forward);
    h_opt_central = h_values(idx_central);
    
    fprintf('Optimal step sizes (minimising absolute error):\n');
    fprintf('  Forward difference: h = %.4e (error = %.4e)\n', ...
            h_opt_forward, min_error_forward);
    fprintf('  Central difference: h = %.4e (error = %.4e)\n\n', ...
            h_opt_central, min_error_central);
    
    % Visualise error behaviour
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    loglog(h_values, errors_forward, 'r-', 'LineWidth', 2, ...
           'DisplayName', 'Forward Difference');
    hold on;
    loglog(h_values, errors_backward, 'g--', 'LineWidth', 2, ...
           'DisplayName', 'Backward Difference');
    loglog(h_values, errors_central, 'b-', 'LineWidth', 2, ...
           'DisplayName', 'Central Difference');
    
    % Mark optimal points
    plot(h_opt_forward, min_error_forward, 'ro', 'MarkerSize', 10, ...
         'LineWidth', 2, 'DisplayName', 'Optimal Forward');
    plot(h_opt_central, min_error_central, 'bo', 'MarkerSize', 10, ...
         'LineWidth', 2, 'DisplayName', 'Optimal Central');
    
    % Reference lines for convergence rates
    h_ref = logspace(-8, -2, 50);
    plot(h_ref, h_ref * 10, 'k--', 'LineWidth', 1, ...
         'DisplayName', 'O(h) slope');
    plot(h_ref, h_ref.^2 * 100, 'k:', 'LineWidth', 1, ...
         'DisplayName', 'O(h^2) slope');
    
    grid on;
    xlabel('Step Size $h$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Absolute Error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Error vs Step Size', 'Interpreter', 'latex', 'FontSize', 13);
    legend('Interpreter', 'latex', 'Location', 'best', 'FontSize', 10);
    set(gca, 'FontSize', 11);
    
    subplot(1, 2, 2);
    loglog(h_values, errors_central, 'b-', 'LineWidth', 2.5);
    hold on;
    
    % Annotate regions
    text(1e-12, 1e-8, 'Round-off dominated', 'FontSize', 11, ...
         'Color', 'red', 'Rotation', 30, 'Interpreter', 'latex');
    text(1e-4, 1e-8, 'Truncation dominated', 'FontSize', 11, ...
         'Color', 'red', 'Rotation', -45, 'Interpreter', 'latex');
    plot(h_opt_central, min_error_central, 'ro', 'MarkerSize', 12, ...
         'LineWidth', 3);
    text(h_opt_central*3, min_error_central, 'Optimal $h$', ...
         'FontSize', 11, 'Interpreter', 'latex');
    
    grid on;
    xlabel('Step Size $h$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Absolute Error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Central Difference Error Analysis', 'Interpreter', 'latex', ...
          'FontSize', 13);
    set(gca, 'FontSize', 11);
    
    fprintf('The plots illustrate the trade-off between:\n');
    fprintf('  - Truncation error (decreases as h decreases)\n');
    fprintf('  - Round-off error (increases as h decreases)\n');
    fprintf('Optimal step size balances these competing effects\n\n');
end

function demonstrateHigherOrderDerivatives()
    fprintf('Part 3: Higher-Order Derivatives\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define function and derivatives
    f = @(x) x.^4 - 3*x.^3 + 2*x.^2 - 5*x + 1;
    f_prime = @(x) 4*x.^3 - 9*x.^2 + 4*x - 5;
    f_double_prime = @(x) 12*x.^2 - 18*x + 4;
    
    x0 = 1.5;
    h = 0.01;
    
    fprintf('Function: f(x) = x^4 - 3*x^3 + 2*x^2 - 5*x + 1\n');
    fprintf('Evaluation point: x0 = %.6f\n', x0);
    fprintf('Step size: h = %.6f\n\n', h);
    
    % First derivative
    df_exact = f_prime(x0);
    df_numerical = (f(x0 + h) - f(x0 - h)) / (2*h);
    
    fprintf('First Derivative:\n');
    fprintf('  Exact: %.10f\n', df_exact);
    fprintf('  Numerical: %.10f\n', df_numerical);
    fprintf('  Error: %.10e\n\n', abs(df_exact - df_numerical));
    
    % Second derivative using central difference
    d2f_exact = f_double_prime(x0);
    d2f_numerical = (f(x0 + h) - 2*f(x0) + f(x0 - h)) / h^2;
    
    fprintf('Second Derivative:\n');
    fprintf('  Formula: [f(x0+h) - 2*f(x0) + f(x0-h)] / h^2\n');
    fprintf('  Exact: %.10f\n', d2f_exact);
    fprintf('  Numerical: %.10f\n', d2f_numerical);
    fprintf('  Error: %.10e\n\n', abs(d2f_exact - d2f_numerical));
    
    % Higher-order finite difference scheme (5-point stencil)
    df_5point = (-f(x0+2*h) + 8*f(x0+h) - 8*f(x0-h) + f(x0-2*h)) / (12*h);
    
    fprintf('First Derivative (5-point stencil, O(h^4) accuracy):\n');
    fprintf('  Formula: [-f(x0+2*h) + 8*f(x0+h) - 8*f(x0-h) + f(x0-2*h)] / (12*h)\n');
    fprintf('  Numerical: %.10f\n', df_5point);
    fprintf('  Error: %.10e\n\n', abs(df_exact - df_5point));
    
    fprintf('Note: 5-point stencil provides significantly better accuracy\n');
    fprintf('Error ratio (3-point/5-point): %.2f\n\n', ...
            abs(df_exact - df_numerical) / abs(df_exact - df_5point));
end

function demonstrateArrayDifferentiation()
    fprintf('Part 4: Array Differentiation using diff()\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Generate sample data
    x = linspace(0, 2*pi, 100);
    y = sin(x) + 0.1*randn(size(x)); % Noisy sine wave
    
    % Exact derivative
    y_prime_exact = cos(x);
    
    % Numerical derivative using diff()
    dx = diff(x);
    dy = diff(y);
    dy_dx = dy ./ dx;
    
    % Centre the derivative approximation
    x_mid = (x(1:end-1) + x(2:end)) / 2;
    
    fprintf('Array differentiation of noisy sine wave\n');
    fprintf('Number of data points: %d\n', length(x));
    fprintf('After differentiation: %d points\n', length(dy_dx));
    fprintf('Note: diff() reduces array length by 1\n\n');
    
    % Compute RMS error
    y_prime_mid = cos(x_mid);
    rms_error = sqrt(mean((dy_dx - y_prime_mid).^2));
    
    fprintf('RMS error: %.6f\n', rms_error);
    fprintf('Noise amplification is inherent in numerical differentiation\n\n');
    
    % Visualise
    figure('Position', [100, 100, 1200, 800]);
    
    subplot(3, 1, 1);
    plot(x, y, 'b-', 'LineWidth', 1.5);
    hold on;
    plot(x, sin(x), 'r--', 'LineWidth', 2);
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f(x)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Original Function (Noisy Sine Wave)', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Noisy data', 'True function', 'Interpreter', 'latex', ...
           'Location', 'best', 'FontSize', 10);
    
    subplot(3, 1, 2);
    plot(x_mid, dy_dx, 'b-', 'LineWidth', 1.5);
    hold on;
    plot(x, y_prime_exact, 'r--', 'LineWidth', 2);
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$f''(x)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Numerical Derivative using diff()', 'Interpreter', 'latex', ...
          'FontSize', 13);
    legend('Numerical', 'Exact', 'Interpreter', 'latex', ...
           'Location', 'best', 'FontSize', 10);
    
    subplot(3, 1, 3);
    plot(x_mid, abs(dy_dx - y_prime_mid), 'b-', 'LineWidth', 2);
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('Absolute Error', 'Interpreter', 'latex', 'FontSize', 12);
    title('Pointwise Error in Derivative Approximation', ...
          'Interpreter', 'latex', 'FontSize', 13);
end

function demonstrateGradientComputation()
    fprintf('Part 5: Gradient Computation for Multivariable Functions\n');
    fprintf('%s\n', repmat('-', 1, 70));
    
    % Define 2*D function: f(x,y) = x^2 + 2*y^2 - xy
    f = @(x, y) x.^2 + 2*y.^2 - x.*y;
    
    % Exact partial derivatives
    df_dx_exact = @(x, y) 2*x - y;
    df_dy_exact = @(x, y) 4*y - x;
    
    % Evaluation point
    x0 = 1.5;
    y0 = 2.0;
    h = 0.001;
    
    fprintf('Function: f(x,y) = x^2 + 2*y^2 - xy\n');
    fprintf('Evaluation point: (%.6f, %.6f)\n', x0, y0);
    fprintf('Step size: h = %.6f\n\n', h);
    
    % Numerical partial derivatives
    df_dx_numerical = (f(x0 + h, y0) - f(x0 - h, y0)) / (2*h);
    df_dy_numerical = (f(x0, y0 + h) - f(x0, y0 - h)) / (2*h);
    
    % Exact values
    df_dx_exact_val = df_dx_exact(x0, y0);
    df_dy_exact_val = df_dy_exact(x0, y0);
    
    fprintf('Partial Derivative with respect to x:\n');
    fprintf('  Exact: df/dx = %.10f\n', df_dx_exact_val);
    fprintf('  Numerical: %.10f\n', df_dx_numerical);
    fprintf('  Error: %.10e\n\n', abs(df_dx_exact_val - df_dx_numerical));
    
    fprintf('Partial Derivative with respect to y:\n');
    fprintf('  Exact: df/dy = %.10f\n', df_dy_exact_val);
    fprintf('  Numerical: %.10f\n', df_dy_numerical);
    fprintf('  Error: %.10e\n\n', abs(df_dy_exact_val - df_dy_numerical));
    
    fprintf('Gradient vector at (x0, y0):\n');
    fprintf('  Exact: gradient f = [%.6f, %.6f]\n', ...
            df_dx_exact_val, df_dy_exact_val);
    fprintf('  Numerical: gradient f = [%.6f, %.6f]\n', ...
            df_dx_numerical, df_dy_numerical);
    fprintf('  Gradient magnitude: ||gradient f|| = %.6f\n\n', ...
            norm([df_dx_exact_val, df_dy_exact_val]));
    
    % Visualise function and gradient
    [X, Y] = meshgrid(linspace(-1, 3, 50), linspace(-1, 3, 50));
    Z = f(X, Y);
    
    figure('Position', [100, 100, 1200, 500]);
    
    subplot(1, 2, 1);
    contour(X, Y, Z, 20, 'LineWidth', 1.5);
    hold on;
    plot(x0, y0, 'ro', 'MarkerSize', 10, 'LineWidth', 2);
    
    % Plot gradient vector
    quiver(x0, y0, df_dx_exact_val, df_dy_exact_val, 0.3, 'r-', ...
           'LineWidth', 2.5, 'MaxHeadSize', 0.5);
    
    colorbar;
    axis equal;
    grid on;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    title('Function Contours and Gradient', 'Interpreter', 'latex', ...
          'FontSize', 13);
    
    subplot(1, 2, 2);
    surf(X, Y, Z, 'EdgeColor', 'none', 'FaceAlpha', 0.8);
    hold on;
    plot3(x0, y0, f(x0, y0), 'ro', 'MarkerSize', 12, 'LineWidth', 3);
    
    % Plot gradient as 3*D arrow
    quiver3(x0, y0, f(x0, y0), df_dx_exact_val, df_dy_exact_val, 0, ...
            0.3, 'r-', 'LineWidth', 3, 'MaxHeadSize', 1);
    
    colormap('jet');
    colorbar;
    xlabel('$x$', 'Interpreter', 'latex', 'FontSize', 12);
    ylabel('$y$', 'Interpreter', 'latex', 'FontSize', 12);
    zlabel('$f(x,y)$', 'Interpreter', 'latex', 'FontSize', 12);
    title('3*D Surface and Gradient Direction', 'Interpreter', 'latex', ...
          'FontSize', 13);
    view(45, 30);
    
    fprintf('Gradient points in direction of steepest ascent\n');
    fprintf('Perpendicular to level curves (contour lines)\n');
end
