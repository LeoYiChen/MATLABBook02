%% chapter_AI_Mechanics_Problem3_kmeans_syntax.m
% K-means clustering syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem3_kmeans_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Perform k-means clustering
numClusters = 4;
[clusterIndices, clusterCentroids, sumDistances] = kmeans(dataStandardised, numClusters, ...
    'Distance', 'sqeuclidean', ...  % Euclidean distance
    'Start', 'plus', ...             % k-means++ initialisation
    'Replicates', 10, ...            % Run 10 times, keep best
    'MaxIter', 500, ...              % Maximum iterations
    'Display', 'final');

% Calculate within-cluster sum of squares (WCSS)
wcss = sum(sumDistances);
