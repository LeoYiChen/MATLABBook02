%% problem6_code.m
% Conformal Prediction for Wind Power Forecasting
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : problem6_code
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
%% Conformal Prediction for Wind Power Forecasting Under Distribution Shift
% Author: Dr Yi Chen
% Institution: University of Newcastle, UK
% MATLAB Version: R2023b
% Date: 2024-01-17
% Description: Implements split conformal and adaptive conformal inference
%              for wind power forecasting with coverage validity analysis

clear; close all; clc;

%% 1. Synthetic Wind Power Time Series Generation
fprintf('========================================\n');
fprintf('Conformal Prediction - Wind Power Forecasting\n');
fprintf('========================================\n\n');

fprintf('Step 1: Generating synthetic wind power time series...\n');

rng(654); % Reproducibility

% Time series parameters
numDays = 365;
hoursPerDay = 24;
numHours = numDays * hoursPerDay; % 8760 hours (one year)

timeHours = (1:numHours)';
dayOfYear = ceil(timeHours / hoursPerDay);
hourOfDay = mod(timeHours - 1, hoursPerDay) + 1;

% Wind farm capacity
windCapacity = 50; % MW

% Seasonal pattern (higher wind in winter)
seasonalComponent = 0.6 + 0.3 * cos(2 * pi * (dayOfYear - 15) / 365);

% Diurnal pattern (higher wind during day)
diurnalComponent = 0.8 + 0.2 * cos(2 * pi * (hourOfDay - 14) / 24);

% Base wind power generation
windPower = windCapacity * seasonalComponent .* diurnalComponent;

% Add autocorrelated noise (simulating weather persistence)
noiseAR = zeros(numHours, 1);
arCoeff = 0.7; % Autocorrelation coefficient

for t = 2:numHours
    noiseAR(t) = arCoeff * noiseAR(t-1) + sqrt(1 - arCoeff^2) * randn();
end

windPower = windPower + 5 * noiseAR;

% Add white noise
windPower = windPower + 2 * randn(numHours, 1);

% Ensure physical constraints
windPower = max(windPower, 0);
windPower = min(windPower, windCapacity);

fprintf('Generated wind power time series: %d hours (%d days)\n', numHours, numDays);
fprintf('Wind capacity: %d MW\n', windCapacity);
fprintf('Mean generation: %.2f MW, Std: %.2f MW\n', mean(windPower), std(windPower));
fprintf('Capacity factor: %.2f%%\n\n', mean(windPower) / windCapacity * 100);

%% 2. Feature Engineering and Dataset Preparation
fprintf('Step 2: Preparing features for forecasting model...\n');

% Features: lagged wind power observations
numLags = 6; % Use past 6 hours
features = [];
targets = [];

for t = (numLags + 1):numHours
    % Feature vector: [windPower(t-1), ..., windPower(t-numLags), hourOfDay(t)]
    featureVec = [windPower(t-1:-1:t-numLags)', hourOfDay(t)];
    features = [features; featureVec];
    targets = [targets; windPower(t)];
end

numSamples = size(features, 1);

fprintf('Feature matrix: %d samples   %d features\n', size(features, 1), size(features, 2));
fprintf('Features: %d lagged observations + hour of day\n\n', numLags);

%% 3. Data Partitioning for Conformal Prediction
fprintf('Step 3: Partitioning data for conformal prediction...\n');

% Split: 50% training, 25% calibration, 25% test
trainRatio = 0.5;
calRatio = 0.25;
testRatio = 0.25;

trainEnd = floor(trainRatio * numSamples);
calEnd = floor((trainRatio + calRatio) * numSamples);

XTrain = features(1:trainEnd, :);
YTrain = targets(1:trainEnd);

XCal = features(trainEnd+1:calEnd, :);
YCal = targets(trainEnd+1:calEnd);

XTest = features(calEnd+1:end, :);
YTest = targets(calEnd+1:end);

fprintf('Training set: %d samples\n', size(XTrain, 1));
fprintf('Calibration set: %d samples\n', size(XCal, 1));
fprintf('Test set: %d samples\n\n', size(XTest, 1));

%% 4. Baseline Point Forecast Model
fprintf('Step 4: Training baseline neural network forecasting model...\n');

% Normalise features
[XTrainNorm, muTrain, sigmaTrain] = zscore(XTrain);
XCalNorm = (XCal - muTrain) ./ sigmaTrain;
XTestNorm = (XTest - muTrain) ./ sigmaTrain;

% Train neural network
hiddenLayerSize = 15;
net = feedforwardnet(hiddenLayerSize, 'trainlm');
net.trainParam.showWindow = false;
net.trainParam.epochs = 150;
net.divideParam.trainRatio = 0.85;
net.divideParam.valRatio = 0.15;
net.divideParam.testRatio = 0;

[net, tr] = train(net, XTrainNorm', YTrain');

% Predictions
YTrainPred = net(XTrainNorm')';
YCalPred = net(XCalNorm')';
YTestPred = net(XTestNorm')';

% Evaluate baseline accuracy
trainRMSE = sqrt(mean((YTrain - YTrainPred).^2));
testRMSE = sqrt(mean((YTest - YTestPred).^2));

fprintf('Baseline model trained (1-hidden layer, %d units)\n', hiddenLayerSize);
fprintf('Training RMSE: %.3f MW\n', trainRMSE);
fprintf('Test RMSE: %.3f MW\n\n', testRMSE);

%% 5. Split Conformal Prediction
fprintf('Step 5: Implementing split conformal prediction...\n');

% Miscoverage rate
alpha = 0.1; % Target: 90% coverage (1 - alpha)

% Compute nonconformity scores on calibration set
% Score = |Y - Y_pred| (absolute residuals)
calScores = abs(YCal - YCalPred);

% Compute quantile for conformal threshold
conformalQuantile = quantile(calScores, 1 - alpha);

fprintf('Split Conformal Prediction:\n');
fprintf('  Target coverage: %.1f%% (alpha = %.2f)\n', (1 - alpha) * 100, alpha);
fprintf('  Calibration set size: %d\n', length(calScores));
fprintf('  Conformal threshold (quantile): %.3f MW\n', conformalQuantile);

% Generate prediction intervals on test set
lowerBound = YTestPred - conformalQuantile;
upperBound = YTestPred + conformalQuantile;

% Evaluate coverage
coverage = mean((YTest >= lowerBound) & (YTest <= upperBound));
avgIntervalWidth = mean(upperBound - lowerBound);

fprintf('  Test set coverage: %.2f%% (target: %.1f%%)\n', coverage * 100, (1 - alpha) * 100);
fprintf('  Average interval width: %.3f MW\n\n', avgIntervalWidth);

%% 6. Adaptive Conformal Inference
fprintf('Step 6: Implementing adaptive conformal inference...\n');

% ACI parameters
gamma = 0.01; % Adaptation rate (small = slow adaptation)
alphaTarget = alpha;

% Initialise with split conformal threshold
alphaAdaptive = alpha;
thresholdAdaptive = conformalQuantile;

% Storage for adaptive results
lowerBoundAdaptive = zeros(size(YTest));
upperBoundAdaptive = zeros(size(YTest));
coverageAdaptiveHistory = zeros(size(YTest));
thresholdHistory = zeros(size(YTest));

fprintf('Adaptive Conformal Inference:\n');
fprintf('  Adaptation rate gamma: %.4f\n', gamma);
fprintf('  Target coverage: %.1f%%\n', (1 - alphaTarget) * 100);

% Adaptive conformal loop
for testIdx = 1:length(YTest)
    % Generate prediction interval
    lowerBoundAdaptive(testIdx) = YTestPred(testIdx) - thresholdAdaptive;
    upperBoundAdaptive(testIdx) = YTestPred(testIdx) + thresholdAdaptive;
    
    % Check coverage
    isCovered = (YTest(testIdx) >= lowerBoundAdaptive(testIdx)) && ...
                (YTest(testIdx) <= upperBoundAdaptive(testIdx));
    
    coverageAdaptiveHistory(testIdx) = isCovered;
    thresholdHistory(testIdx) = thresholdAdaptive;
    
    % Update adaptive alpha
    if isCovered
        alphaAdaptive = alphaAdaptive + gamma * (alphaTarget - alphaAdaptive);
    else
        alphaAdaptive = alphaAdaptive + gamma * (alphaTarget - alphaAdaptive) + gamma;
    end
    
    % Update threshold (simplified: use current alpha)
    % In practice, would recompute quantile from recent calibration window
    thresholdAdaptive = thresholdAdaptive * (1 + gamma * (alphaAdaptive - alpha));
end

% Evaluate adaptive coverage
coverageAdaptive = mean(coverageAdaptiveHistory);
avgIntervalWidthAdaptive = mean(upperBoundAdaptive - lowerBoundAdaptive);

fprintf('  Overall test coverage: %.2f%%\n', coverageAdaptive * 100);
fprintf('  Average interval width: %.3f MW\n', avgIntervalWidthAdaptive);
fprintf('  Efficiency gain: %.2f%% width reduction vs split conformal\n\n', ...
        (1 - avgIntervalWidthAdaptive / avgIntervalWidth) * 100);

%% 7. Distribution Shift Analysis
fprintf('Step 7: Analysing coverage under seasonal distribution shift...\n');

% Identify seasonal periods in test set
testTimeStart = calEnd + 1;
testDaysOfYear = dayOfYear(testTimeStart:end);

% Define seasons (Northern Hemisphere)
winterMask = (testDaysOfYear <= 79) | (testDaysOfYear >= 355); % Dec-Feb
summerMask = (testDaysOfYear >= 172) & (testDaysOfYear <= 264); % Jun-Aug

% Coverage by season (split conformal)
coverageWinter = mean((YTest(winterMask) >= lowerBound(winterMask)) & ...
                      (YTest(winterMask) <= upperBound(winterMask)));
coverageSummer = mean((YTest(summerMask) >= lowerBound(summerMask)) & ...
                      (YTest(summerMask) <= upperBound(summerMask)));

% Coverage by season (adaptive conformal)
coverageWinterAdaptive = mean(coverageAdaptiveHistory(winterMask));
coverageSummerAdaptive = mean(coverageAdaptiveHistory(summerMask));

fprintf('Seasonal Coverage Analysis:\n');
fprintf('  Split Conformal:\n');
fprintf('    Winter coverage: %.2f%%\n', coverageWinter * 100);
fprintf('    Summer coverage: %.2f%%\n', coverageSummer * 100);
fprintf('    Seasonal gap: %.2f percentage points\n', abs(coverageWinter - coverageSummer) * 100);

fprintf('  Adaptive Conformal:\n');
fprintf('    Winter coverage: %.2f%%\n', coverageWinterAdaptive * 100);
fprintf('    Summer coverage: %.2f%%\n', coverageSummerAdaptive * 100);
fprintf('    Seasonal gap: %.2f percentage points\n\n', ...
            abs(coverageWinterAdaptive - coverageSummerAdaptive) * 100);

%% 8. Asymmetric Conformal Prediction
fprintf('Step 8: Implementing asymmetric conformal prediction...\n');

% Compute separate quantiles for positive and negative residuals
calResidualsPos = YCal - YCalPred; % Positive = under-forecast
calResidualsNeg = YCalPred - YCal; % Positive = over-forecast

% Asymmetric quantiles (prioritise under-forecast protection)
alphaUpper = 0.05; % 5% miscoverage on upper side (under-forecast)
alphaLower = 0.15; % 15% miscoverage on lower side (over-forecast)

quantileUpper = quantile(calResidualsPos(calResidualsPos > 0), 1 - alphaUpper);
quantileLower = quantile(calResidualsNeg(calResidualsNeg > 0), 1 - alphaLower);

% Asymmetric prediction intervals
lowerBoundAsym = YTestPred - quantileLower;
upperBoundAsym = YTestPred + quantileUpper;

% Evaluate asymmetric coverage
coverageAsym = mean((YTest >= lowerBoundAsym) & (YTest <= upperBoundAsym));
coverageUpperAsym = mean(YTest <= upperBoundAsym); % Under-forecast protection
coverageLowerAsym = mean(YTest >= lowerBoundAsym); % Over-forecast protection

avgIntervalWidthAsym = mean(upperBoundAsym - lowerBoundAsym);

fprintf('Asymmetric Conformal Prediction:\n');
fprintf('  Target upper coverage (under-forecast): %.1f%%\n', (1 - alphaUpper) * 100);
fprintf('  Target lower coverage (over-forecast): %.1f%%\n', (1 - alphaLower) * 100);
fprintf('  Achieved overall coverage: %.2f%%\n', coverageAsym * 100);
fprintf('  Achieved upper coverage: %.2f%%\n', coverageUpperAsym * 100);
fprintf('  Achieved lower coverage: %.2f%%\n', coverageLowerAsym * 100);
fprintf('  Average interval width: %.3f MW (%.2f%% vs symmetric)\n\n', ...
        avgIntervalWidthAsym, (avgIntervalWidthAsym / avgIntervalWidth - 1) * 100);

%% 9. Visualisation
fprintf('Step 9: Generating visualisations...\n');

if ~exist('figures', 'dir')
    mkdir('figures');
end

% Figure 1: Prediction Intervals Comparison
fig1 = figure('Position', [100, 100, 1400, 900]);

% Plot subset of test data for clarity
plotRange = 1:min(168, length(YTest)); % One week

subplot(3, 1, 1);
plot(plotRange, YTest(plotRange), 'k-', 'LineWidth', 1.5, 'DisplayName', 'True');
hold on;
plot(plotRange, YTestPred(plotRange), 'b-', 'LineWidth', 1, 'DisplayName', 'Prediction');
fill([plotRange, fliplr(plotRange)], ...
     [upperBound(plotRange)', fliplr(lowerBound(plotRange)')], ...
     'b', 'FaceAlpha', 0.2, 'EdgeColor', 'none', 'DisplayName', ...
     sprintf('Split Conformal (%.1f%% PI)', (1-alpha)*100));
ylabel('Wind Power (MW)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Split Conformal Prediction}', 'Interpreter', 'latex', 'FontSize', 11);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
xlim([1, length(plotRange)]);

subplot(3, 1, 2);
plot(plotRange, YTest(plotRange), 'k-', 'LineWidth', 1.5, 'DisplayName', 'True');
hold on;
plot(plotRange, YTestPred(plotRange), 'b-', 'LineWidth', 1, 'DisplayName', 'Prediction');
fill([plotRange, fliplr(plotRange)], ...
     [upperBoundAdaptive(plotRange)', fliplr(lowerBoundAdaptive(plotRange)')], ...
     'g', 'FaceAlpha', 0.2, 'EdgeColor', 'none', 'DisplayName', ...
     sprintf('Adaptive Conformal (%.1f%% PI)', (1-alpha)*100));
ylabel('Wind Power (MW)', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Adaptive Conformal Inference}', 'Interpreter', 'latex', 'FontSize', 11);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
xlim([1, length(plotRange)]);

subplot(3, 1, 3);
plot(plotRange, YTest(plotRange), 'k-', 'LineWidth', 1.5, 'DisplayName', 'True');
hold on;
plot(plotRange, YTestPred(plotRange), 'b-', 'LineWidth', 1, 'DisplayName', 'Prediction');
fill([plotRange, fliplr(plotRange)], ...
     [upperBoundAsym(plotRange)', fliplr(lowerBoundAsym(plotRange)')], ...
     'r', 'FaceAlpha', 0.2, 'EdgeColor', 'none', 'DisplayName', ...
     'Asymmetric Conformal');
ylabel('Wind Power (MW)', 'Interpreter', 'latex', 'FontSize', 10);
xlabel('Hour', 'Interpreter', 'latex', 'FontSize', 10);
title('\textbf{Asymmetric Conformal Prediction}', 'Interpreter', 'latex', 'FontSize', 11);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
xlim([1, length(plotRange)]);

sgtitle('\textbf{Conformal Prediction Intervals - Wind Power Forecasting}', ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig1, 'figures/Problem6_Conformal_Intervals.fig');
saveas(fig1, 'figures/Problem6_Conformal_Intervals.eps', 'epsc');
saveas(fig1, 'figures/Problem6_Conformal_Intervals.jpg');
fprintf('Saved: Problem6_Conformal_Intervals\n');

% Figure 2: Coverage and Efficiency Analysis
fig2 = figure('Position', [150, 150, 1200, 500]);

subplot(1, 2, 1);
methods = categorical({'Split Conformal', 'Adaptive Conformal', 'Asymmetric Conformal'});
coverageValues = [coverage, coverageAdaptive, coverageAsym] * 100;
targetCoverage = (1 - alpha) * 100;

bar(methods, coverageValues);
hold on;
yline(targetCoverage, 'r-', 'LineWidth', 2, 'DisplayName', 'Target Coverage');
ylabel('Coverage (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Empirical Coverage Validation}', 'Interpreter', 'latex', 'FontSize', 12);
legend('Interpreter', 'latex', 'Location', 'best');
grid on;
ylim([85, 95]);

subplot(1, 2, 2);
widthValues = [avgIntervalWidth, avgIntervalWidthAdaptive, avgIntervalWidthAsym];

bar(methods, widthValues, 'FaceColor', [0.4, 0.6, 0.8]);
ylabel('Average Interval Width (MW)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Prediction Interval Efficiency}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle('\textbf{Conformal Prediction Performance Comparison}', ...
        'Interpreter', 'latex', 'FontSize', 13);

saveas(fig2, 'figures/Problem6_Coverage_Efficiency.fig');
saveas(fig2, 'figures/Problem6_Coverage_Efficiency.eps', 'epsc');
saveas(fig2, 'figures/Problem6_Coverage_Efficiency.jpg');
fprintf('Saved: Problem6_Coverage_Efficiency\n');

% Figure 3: Seasonal Distribution Shift
fig3 = figure('Position', [200, 200, 1200, 500]);

subplot(1, 2, 1);
seasons = categorical({'Winter', 'Summer'});
splitCoverages = [coverageWinter, coverageSummer] * 100;
adaptiveCoverages = [coverageWinterAdaptive, coverageSummerAdaptive] * 100;

X = 1:2;
bar(X, [splitCoverages', adaptiveCoverages']);
set(gca, 'XTickLabel', seasons);
ylabel('Coverage (\%)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Seasonal Coverage Stability}', 'Interpreter', 'latex', 'FontSize', 12);
legend('Split Conformal', 'Adaptive Conformal', 'Interpreter', 'latex', 'Location', 'best');
grid on;
yline(targetCoverage, 'r-', 'LineWidth', 1.5, 'HandleVisibility', 'off');

subplot(1, 2, 2);
plot(1:length(thresholdHistory), thresholdHistory, 'b-', 'LineWidth', 1.5);
xlabel('Test Sample Index', 'Interpreter', 'latex', 'FontSize', 11);
ylabel('Adaptive Threshold (MW)', 'Interpreter', 'latex', 'FontSize', 11);
title('\textbf{Threshold Adaptation Over Time}', 'Interpreter', 'latex', 'FontSize', 12);
grid on;

sgtitle('\textbf{Distribution Shift Analysis}', 'Interpreter', 'latex', 'FontSize', 13);

saveas(fig3, 'figures/Problem6_Distribution_Shift.fig');
saveas(fig3, 'figures/Problem6_Distribution_Shift.eps', 'epsc');
saveas(fig3, 'figures/Problem6_Distribution_Shift.jpg');
fprintf('Saved: Problem6_Distribution_Shift\n');

fprintf('\nAnalysis complete!\n');
fprintf('========================================\n');
