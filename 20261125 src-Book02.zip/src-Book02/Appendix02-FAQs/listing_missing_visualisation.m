%% listing_missing_visualisation.m
% Missing data visualisation toolkit.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : listing_missing_visualisation
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function visualiseMissingData(X_original, X_imputed, variable_names)
% visualiseMissingData - Create comprehensive missing data visualisations
%
% Inputs:
%   X_original    - Original data with missing values
%   X_imputed     - Data after imputation
%   variable_names - Cell array of variable names

    if nargin < 3
        variable_names = arrayfun(@(x) sprintf('Var_%d', x), 1:size(X_original, 2), 'UniformOutput', false);
    end
    
    % Create figure with multiple subplots
    figure('Position', [100, 100, 1200, 800]);
    
    % Subplot 1: Missing data pattern matrix
    subplot(2, 3, 1);
    missing_pattern = isnan(X_original);
    imagesc(missing_pattern);
    colormap([1 1 1; 0.8 0.2 0.2]); % White for observed, red for missing
    title('Missing Data Pattern Matrix');
    xlabel('Variables');
    ylabel('Observations');
    set(gca, 'XTick', 1:length(variable_names), 'XTickLabel', variable_names, 'XTickLabelRotation', 45);
    
    % Subplot 2: Missing data percentage by variable
    subplot(2, 3, 2);
    missing_percentages = (sum(missing_pattern, 1) / size(X_original, 1)) * 100;
    bar(missing_percentages);
    title('Missing Data Percentage by Variable');
    xlabel('Variables');
    ylabel('Missing Percentage (%)');
    set(gca, 'XTick', 1:length(variable_names), 'XTickLabel', variable_names, 'XTickLabelRotation', 45);
    
    % Subplot 3: Missing data pattern frequency
    subplot(2, 3, 3);
    [unique_patterns, ~, pattern_indices] = unique(missing_pattern, 'rows');
    pattern_counts = accumarray(pattern_indices, 1);
    [sorted_counts, sort_indices] = sort(pattern_counts, 'descend');
    bar(sorted_counts(1:min(10, length(sorted_counts))));
    title('Top Missing Data Patterns');
    xlabel('Pattern Rank');
    ylabel('Frequency');
    
    % Subplot 4-6: Histograms for first three variables (if available)
    for var_idx = 1:min(3, size(X_original, 2))
        subplot(2, 3, 3 + var_idx);
        
        original_data = X_original(:, var_idx);
        imputed_data = X_imputed(:, var_idx);
        
        % Remove NaN values for histogram
        original_clean = original_data(~isnan(original_data));
        
        if ~isempty(original_clean)
            hold on;
            histogram(original_clean, 'Normalization', 'probability', 'FaceAlpha', 0.7, 'DisplayName', 'Original');
            histogram(imputed_data, 'Normalization', 'probability', 'FaceAlpha', 0.7, 'DisplayName', 'Imputed');
            hold off;
            title(sprintf('Distribution: %s', variable_names{var_idx}));
            xlabel('Value');
            ylabel('Probability');
            legend('show');
        end
    end
    
    % Adjust layout
    sgtitle('Comprehensive Missing Data Analysis', 'FontSize', 14, 'FontWeight', 'bold');
end
