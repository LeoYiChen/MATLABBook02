%% chapter_ES_code_problem11.m
% Human-Automation Teaming Simulation
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_ES_code_problem11
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function MATLABBook_ChapterES_Problem11
    % MATLABBook_ChapterES_Problem11.m
    % Author: Dr Yi Chen
    % Email: leo.chen.yi@live.co.uk
    % Created: 2024-01-15
    % Modified: 2024-01-15
    % MATLAB Version: R2023b or later
    %
    % Description:
    %   Simulation of human-automation teaming in Level 3 autonomous
    %   vehicles. Models situation awareness, trust dynamics, workload,
    %   and takeover performance under varying conditions.
    %
    % Dependencies: None (base MATLAB)
    %
    % See also: Chapter ES, Section 8 (Problems), Problem 11
    
    fprintf('\n=== Problem 11: Human-Automation Teaming in Autonomous Vehicles ===\n\n');
    
    %% Simulation Parameters
    
    % Time parameters
    dt = 0.1;  % Time step (seconds)
    T_total = 3600;  % Total simulation time (1 hour)
    t = 0:dt:T_total;
    N = length(t);
    
    % Automation parameters
    baseline_reliability = 0.95;  % Normal operation reliability
    MTBF = 1800;  % Mean time between failures (seconds)
    
    % Driver parameters
    SA_decay_rate = 0.002;  % Situation awareness decay per second during automation
    SA_recovery_rate = 0.01;  % SA recovery during manual driving
    trust_learning_rate = 0.05;  % Trust adaptation rate
    trust_sensitivity = 0.3;  % Sensitivity to reliability changes
    
    % Takeover parameters
    takeover_time_budget = 10;  % Required response time (seconds)
    min_takeover_time = 2;  % Minimum possible takeover time (seconds)
    
    fprintf('Simulation setup:\n');
    fprintf('  Duration: %.0f seconds (%.1f minutes)\n', T_total, T_total/60);
    fprintf('  Time step: %.2f seconds\n', dt);
    fprintf('  Automation reliability: %.1f%%\n', baseline_reliability * 100);
    fprintf('  MTBF: %.0f seconds\n\n', MTBF);
    
    %% Generate Driving Scenarios
    
    fprintf('=== Generating Driving Scenarios ===\n');
    
    % Automation state (1 = engaged, 0 = manual)
    automation_active = ones(1, N);
    
    % Generate automation failures (Poisson process)
    failure_times = [];
    t_next_failure = exprnd(MTBF);
    
    while t_next_failure < T_total
        failure_times = [failure_times, t_next_failure];
        t_next_failure = t_next_failure + exprnd(MTBF);
    end
    
    num_failures = length(failure_times);
    
    fprintf('Number of automation failures: %d\n', num_failures);
    if num_failures > 0
        fprintf('Failure times: ');
        fprintf('%.1f ', failure_times(1:min(5, num_failures)));
        if num_failures > 5
            fprintf('... ');
        end
        fprintf('seconds\n');
    end
    
    % Takeover requests (at failure times)
    takeover_requests = zeros(1, N);
    for i = 1:num_failures
        [~, idx] = min(abs(t - failure_times(i)));
        takeover_requests(idx) = 1;
    end
    
    % Traffic density (varying throughout drive)
    traffic_density = 0.3 + 0.4 * sin(2*pi*t/1800) + 0.1 * randn(1, N);
    traffic_density = max(0, min(1, traffic_density));
    
    % Hazard level (increases with traffic, automation failures)
    hazard_level = 0.2 * traffic_density + 0.5 * takeover_requests;
    
    fprintf('Traffic density - Mean: %.2f, Std: %.2f\n\n', ...
            mean(traffic_density), std(traffic_density));
    
    %% Method 1: Situation Awareness Model
    
    fprintf('=== Method 1: Situation Awareness Dynamics ===\n');
    
    % SA components (0-1 scale)
    SA_level = zeros(1, N);
    SA_level(1) = 0.8;  % Initial SA (experienced driver)
    
    % SA influenced by:
    % - Automation state (decays during automation)
    % - Driver engagement (secondary tasks)
    % - Hazard level (increases during critical events)
    
    secondary_task_engagement = 0.3 * ones(1, N);  % Baseline engagement
    
    for k = 1:N-1
        if automation_active(k) == 1
            % SA decays during automation (vigilance decrement)
            SA_decay = SA_decay_rate * (1 + secondary_task_engagement(k));
            SA_level(k+1) = SA_level(k) - SA_decay * dt;
            
            % Partial recovery when hazards detected
            if hazard_level(k) > 0.5
                SA_level(k+1) = SA_level(k+1) + 0.1 * hazard_level(k) * dt;
            end
        else
            % SA recovers during manual driving
            SA_level(k+1) = SA_level(k) + SA_recovery_rate * dt;
        end
        
        % Bound SA to [0, 1]
        SA_level(k+1) = max(0, min(1, SA_level(k+1)));
    end
    
    fprintf('Situation awareness:\n');
    fprintf('  Initial: %.2f\n', SA_level(1));
    fprintf('  Final: %.2f\n', SA_level(end));
    fprintf('  Mean: %.2f, Std: %.2f\n', mean(SA_level), std(SA_level));
    fprintf('  Min: %.2f (occurred at t=%.1fs)\n\n', ...
            min(SA_level), t(find(SA_level == min(SA_level), 1)));
    
    %% Method 2: Trust Dynamics Model
    
    fprintf('=== Method 2: Trust Dynamics ===\n');
    
    % Trust level (0-1 scale)
    trust = zeros(1, N);
    trust(1) = 0.7;  % Initial moderate trust
    
    % Perceived reliability (based on recent performance)
    perceived_reliability = zeros(1, N);
    perceived_reliability(1) = baseline_reliability;
    
    % Performance history (sliding window)
    window_size = 100;  % 10 seconds
    performance_history = baseline_reliability * ones(1, window_size);
    
    for k = 1:N-1
        % Update perceived reliability (exponential moving average)
        if takeover_requests(k) == 1
            % Failure detected
            current_performance = 0;
        else
            % Normal operation
            current_performance = baseline_reliability + 0.05 * randn();
        end
        
        performance_history = [performance_history(2:end), current_performance];
        perceived_reliability(k+1) = mean(performance_history);
        
        % Trust update (Lee & Moray model)
        delta_reliability = perceived_reliability(k+1) - perceived_reliability(k);
        
        trust(k+1) = trust(k) + ...
                     trust_learning_rate * (perceived_reliability(k+1) - trust(k)) + ...
                     trust_sensitivity * delta_reliability;
        
        % Bound trust to [0, 1]
        trust(k+1) = max(0, min(1, trust(k+1)));
    end
    
    fprintf('Trust dynamics:\n');
    fprintf('  Initial: %.2f\n', trust(1));
    fprintf('  Final: %.2f\n', trust(end));
    fprintf('  Mean: %.2f, Std: %.2f\n', mean(trust), std(trust));
    
    % Trust calibration error
    trust_error = abs(trust - perceived_reliability);
    fprintf('  Trust calibration error - Mean: %.3f, Max: %.3f\n\n', ...
            mean(trust_error), max(trust_error));
    
    %% Method 3: Workload Model
    
    fprintf('=== Method 3: Workload Assessment ===\n');
    
    % Workload components (NASA-TLX scale 0-100)
    mental_demand = zeros(1, N);
    temporal_demand = zeros(1, N);
    
    for k = 1:N
        if automation_active(k) == 1
            % Low workload during automation (monitoring only)
            mental_demand(k) = 20 + 10 * traffic_density(k);
            temporal_demand(k) = 15;
        else
            % High workload during manual driving
            mental_demand(k) = 60 + 30 * traffic_density(k);
            temporal_demand(k) = 50 + 30 * traffic_density(k);
        end
        
        % Spike during takeovers
        if takeover_requests(k) == 1
            mental_demand(k) = mental_demand(k) + 40;
            temporal_demand(k) = temporal_demand(k) + 50;
        end
    end
    
    % Overall workload (simplified aggregate)
    workload = 0.6 * mental_demand + 0.4 * temporal_demand;
    
    fprintf('Workload (NASA-TLX scale):\n');
    fprintf('  Mean: %.1f, Std: %.1f\n', mean(workload), std(workload));
    fprintf('  During automation: %.1f\n', mean(workload(automation_active==1)));
    fprintf('  Peak workload: %.1f\n\n', max(workload));
    
    %% Method 4: Takeover Performance
    
    fprintf('=== Method 4: Takeover Performance ===\n');
    
    % Takeover metrics for each failure event
    takeover_times = zeros(1, num_failures);
    takeover_success = zeros(1, num_failures);
    
    for i = 1:num_failures
        [~, idx] = min(abs(t - failure_times(i)));
        
        % Takeover time depends on SA and workload
        base_time = min_takeover_time;
        SA_penalty = 3 * (1 - SA_level(idx));  % Low SA increases time
        workload_penalty = 2 * (workload(idx) / 100);  % High workload increases time
        
        takeover_times(i) = base_time + SA_penalty + workload_penalty + ...
                           0.5 * randn();  % Individual variability
        
        % Success if takeover within budget
        takeover_success(i) = (takeover_times(i) <= takeover_time_budget);
    end
    
    success_rate = sum(takeover_success) / num_failures * 100;
    
    fprintf('Takeover performance (%d events):\n', num_failures);
    fprintf('  Success rate: %.1f%%\n', success_rate);
    fprintf('  Mean takeover time: %.2f s\n', mean(takeover_times));
    fprintf('  Std takeover time: %.2f s\n', std(takeover_times));
    fprintf('  Max takeover time: %.2f s\n', max(takeover_times));
    fprintf('  Within budget (<%.0fs): %d/%d\n\n', ...
            takeover_time_budget, sum(takeover_success), num_failures);
    
    %% Method 5: Interface Design Comparison
    
    fprintf('=== Method 5: Transparency Interface Impact ===\n');
    
    % Simulate effect of transparency interface
    % (displays automation confidence and sensor coverage)
    
    % Re-run simulation with enhanced interface
    SA_level_enhanced = zeros(1, N);
    SA_level_enhanced(1) = 0.8;
    
    % Enhanced interface reduces SA decay by 40%
    SA_decay_rate_enhanced = SA_decay_rate * 0.6;
    
    for k = 1:N-1
        if automation_active(k) == 1
            SA_decay = SA_decay_rate_enhanced * (1 + secondary_task_engagement(k));
            SA_level_enhanced(k+1) = SA_level_enhanced(k) - SA_decay * dt;
            
            if hazard_level(k) > 0.5
                SA_level_enhanced(k+1) = SA_level_enhanced(k+1) + 0.1 * hazard_level(k) * dt;
            end
        else
            SA_level_enhanced(k+1) = SA_level_enhanced(k) + SA_recovery_rate * dt;
        end
        
        SA_level_enhanced(k+1) = max(0, min(1, SA_level_enhanced(k+1)));
    end
    
    % Recompute takeover performance with enhanced SA
    takeover_times_enhanced = zeros(1, num_failures);
    takeover_success_enhanced = zeros(1, num_failures);
    
    for i = 1:num_failures
        [~, idx] = min(abs(t - failure_times(i)));
        
        base_time = min_takeover_time;
        SA_penalty = 3 * (1 - SA_level_enhanced(idx));
        workload_penalty = 2 * (workload(idx) / 100);
        
        takeover_times_enhanced(i) = base_time + SA_penalty + workload_penalty + ...
                                     0.5 * randn();
        
        takeover_success_enhanced(i) = (takeover_times_enhanced(i) <= takeover_time_budget);
    end
    
    success_rate_enhanced = sum(takeover_success_enhanced) / num_failures * 100;
    
    fprintf('Baseline interface:\n');
    fprintf('  Mean SA: %.3f, Success rate: %.1f%%\n', ...
            mean(SA_level), success_rate);
    
    fprintf('Enhanced transparency interface:\n');
    fprintf('  Mean SA: %.3f, Success rate: %.1f%%\n', ...
            mean(SA_level_enhanced), success_rate_enhanced);
    
    fprintf('Improvement:\n');
    fprintf('  SA gain: +%.3f (%.1f%% relative)\n', ...
            mean(SA_level_enhanced) - mean(SA_level), ...
            (mean(SA_level_enhanced) / mean(SA_level) - 1) * 100);
    fprintf('  Success rate gain: +%.1f%%\n\n', ...
            success_rate_enhanced - success_rate);
    
    %% Visualization
    
    fprintf('Generating visualizations...\n');
    
    % Figure 1: Time series of key variables
    figure('Position', [50 50 1600 900]);
    
    % Plot 1: Automation state and failures
    subplot(4, 2, 1);
    plot(t/60, automation_active, 'b-', 'LineWidth', 1.5);
    hold on;
    scatter(failure_times/60, ones(size(failure_times)), 80, 'r', 'filled');
    hold off;
    xlabel('Time (minutes)', 'Interpreter', 'latex');
    ylabel('Automation State', 'Interpreter', 'latex');
    title('Automation Engagement', 'Interpreter', 'latex');
    ylim([-0.1 1.1]);
    grid on;
    legend({'Engaged', 'Failures'}, 'Location', 'southeast', 'Interpreter', 'latex');
    
    % Plot 2: Situation awareness
    subplot(4, 2, 2);
    plot(t/60, SA_level, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Baseline');
    hold on;
    plot(t/60, SA_level_enhanced, 'g-', 'LineWidth', 1.5, 'DisplayName', 'Enhanced UI');
    yline(0.5, 'r-', 'LineWidth', 1, 'DisplayName', 'Critical threshold');
    hold off;
    xlabel('Time (minutes)', 'Interpreter', 'latex');
    ylabel('SA Level', 'Interpreter', 'latex');
    title('Situation Awareness Dynamics', 'Interpreter', 'latex');
    legend('Location', 'southwest', 'Interpreter', 'latex');
    grid on;
    
    % Plot 3: Trust dynamics
    subplot(4, 2, 3);
    plot(t/60, trust, 'b-', 'LineWidth', 1.5, 'DisplayName', 'Trust');
    hold on;
    plot(t/60, perceived_reliability, 'r-', 'LineWidth', 1.5, 'DisplayName', 'Perceived Reliability');
    hold off;
    xlabel('Time (minutes)', 'Interpreter', 'latex');
    ylabel('Level', 'Interpreter', 'latex');
    title('Trust Calibration', 'Interpreter', 'latex');
    legend('Location', 'southwest', 'Interpreter', 'latex');
    grid on;
    
    % Plot 4: Workload
    subplot(4, 2, 4);
    plot(t/60, workload, 'b-', 'LineWidth', 1.5);
    xlabel('Time (minutes)', 'Interpreter', 'latex');
    ylabel('Workload (NASA-TLX)', 'Interpreter', 'latex');
    title('Driver Workload', 'Interpreter', 'latex');
    grid on;
    
    % Plot 5: Traffic density
    subplot(4, 2, 5);
    plot(t/60, traffic_density, 'b-', 'LineWidth', 1.5);
    xlabel('Time (minutes)', 'Interpreter', 'latex');
    ylabel('Density', 'Interpreter', 'latex');
    title('Traffic Conditions', 'Interpreter', 'latex');
    grid on;
    
    % Plot 6: Takeover times
    subplot(4, 2, 6);
    if num_failures > 0
        bar(categorical({'Baseline', 'Enhanced'}), ...
            [mean(takeover_times), mean(takeover_times_enhanced)], ...
            'FaceColor', [0.3 0.6 0.9]);
        hold on;
        yline(takeover_time_budget, 'r-', 'LineWidth', 2, 'DisplayName', 'Budget');
        hold off;
        ylabel('Mean Takeover Time (s)', 'Interpreter', 'latex');
        title('Takeover Performance', 'Interpreter', 'latex');
        legend('Location', 'northeast', 'Interpreter', 'latex');
        grid on;
    end
    
    % Plot 7: SA vs Takeover performance
    subplot(4, 2, 7);
    if num_failures > 0
        SA_at_failures = zeros(1, num_failures);
        for i = 1:num_failures
            [~, idx] = min(abs(t - failure_times(i)));
            SA_at_failures(i) = SA_level(idx);
        end
        
        scatter(SA_at_failures, takeover_times, 80, takeover_success*2+1, 'filled');
        xlabel('SA Level at Takeover', 'Interpreter', 'latex');
        ylabel('Takeover Time (s)', 'Interpreter', 'latex');
        title('SA-Performance Relationship', 'Interpreter', 'latex');
        colormap([1 0 0; 0 1 0]);
        grid on;
    end
    
    % Plot 8: Trust calibration error
    subplot(4, 2, 8);
    histogram(trust_error, 20, 'FaceColor', [0.8 0.4 0.4], 'EdgeColor', 'none');
    xlabel('Trust Calibration Error', 'Interpreter', 'latex');
    ylabel('Frequency', 'Interpreter', 'latex');
    title('Trust Miscalibration Distribution', 'Interpreter', 'latex');
    grid on;
    
    sgtitle('Human-Automation Teaming Simulation Results', 'Interpreter', 'latex', ...
            'FontSize', 14, 'FontWeight', 'bold');
    
    fprintf('Simulation completed. Visualizations generated.\n\n');
end
