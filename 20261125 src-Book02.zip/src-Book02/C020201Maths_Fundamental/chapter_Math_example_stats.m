%% chapter_Math_example_stats.m
% Statistical functions.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/C020201Maths_Fundamental/
% Listing label         : chapter_Math_example_stats
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Generate sample data
data = randn(1000, 1);  % 1000 random numbers from standard normal

% Descriptive statistics
meanVal = mean(data);         % Mean
medianVal = median(data);     % Median
stdDev = std(data);           % Standard deviation
variance = var(data);         % Variance
minVal = min(data);           % Minimum
maxVal = max(data);           % Maximum
rangeVal = range(data);       % Range (max - min)

% Quantiles and percentiles
q25 = quantile(data, 0.25);   % 25*th percentile
q75 = quantile(data, 0.75);   % 75*th percentile
iqr_val = iqr(data);          % Interquartile range

% Correlation and covariance
data2 = randn(1000, 1);
corrCoef = corrcoef(data, data2);  % Correlation coefficient
covMat = cov(data, data2);         % Covariance

% Distribution fitting (requires Statistics Toolbox)
% pd = fitdist(data, 'Normal');    % Fit normal distribution
% params = paramci(pd);             % Confidence intervals
