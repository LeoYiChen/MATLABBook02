%% chapter_AI_Mechanics_Problem9_posterior_syntax.m
% Posterior distribution analysis syntax.
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix01-Solutions/
% Listing label         : chapter_AI_Mechanics_Problem9_posterior_syntax
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
% Analyse MCMC samples to extract posterior statistics
% samples: (numSamples   numParams) matrix
% burnInRatio: fraction of samples to discard (e.g., 0.2 for 20%)

function stats = analysePosterior(samples, burnInRatio, paramNames)
    % Remove burn-in
    numSamples = size(samples, 1);
    burnIn = floor(burnInRatio * numSamples);
    samplesPost = samples(burnIn+1:end, :);
    
    numParams = size(samplesPost, 2);
    stats.mean = mean(samplesPost, 1);
    stats.median = median(samplesPost, 1);
    stats.std = std(samplesPost, 0, 1);
    
    % Credible intervals (95%)
    stats.CI95_lower = prctile(samplesPost, 2.5, 1);
    stats.CI95_upper = prctile(samplesPost, 97.5, 1);
    
    % MAP estimate (mode approximation via KDE)
    [~, maxIdx] = max(mvksdensity(samplesPost, samplesPost));
    stats.MAP = samplesPost(maxIdx, :);
    
    % Correlation matrix
    stats.corrMatrix = corrcoef(samplesPost);
    
    % Effective sample size (accounting for autocorrelation)
    for i = 1:numParams
        acf = autocorr(samplesPost(:, i), 100);
        stats.ESS(i) = numSamples / (1 + 2*sum(acf(2:end)));
    end
    
    % Print summary
    fprintf('\n-- Posterior Summary --\n');
    for i = 1:numParams
        fprintf('%s: %.4f   %.4f (95%% CI: [%.4f, %.4f])\n', ...
            paramNames{i}, stats.mean(i), stats.std(i), ...
            stats.CI95_lower(i), stats.CI95_upper(i));
    end
    fprintf('Correlation(C10, C01): %.3f\n', stats.corrMatrix(1,2));
    fprintf('Effective Sample Size: %d\n', round(min(stats.ESS)));
end
