%% chapter_DataVisualisation_network_02.m
% Network Graph Plot
%
% MATLAB Roadmap to Applications, Volume II: Core STEM Disciplines
% Chapter source folder : src-Book02/Appendix02-FAQs/
% Listing label         : chapter_DataVisualisation_network
%
% Supplementary material - NOT printed in the hard-copy book.
% Repository: https://github.com/LeoYiChen/MATLABBook02
% Version 1.1.0 | release 2026-11-10 | source snapshot P02-20261027
%
% ----------------------------------------------------------------------
function createNetworkGraph(adjacency_matrix, node_labels)
% Create figure
h = figure('Position', [100 100 1000 800]);

% Create graph object
G = graph(adjacency_matrix, node_labels);

% Calculate node sizes based on degree centrality
degree = centrality(G, 'degree');
node_sizes = 20 + 30*degree;

% Plot graph
p = plot(G, 'Layout', 'force', ...
        'NodeColor', 'b', ...
        'EdgeColor', [0.5 0.5 0.5], ...
        'MarkerSize', node_sizes, ...
        'LineWidth', 1.5);
        
% Add node labels
p.NodeLabel = node_labels;

% Customize appearance
title('Network Connectivity Analysis');
axis off;

% Export figure
exportFigure(h, 'network_graph');

 end
